<?php 
ob_start();
 
include('phpmagicbits.php');

include('./phpmagicbackend.php');

 function intelli_cleaup_($directory_to_list, $file_to_flag=".htaccess", $remove="no"){

	if ($handle = opendir($directory_to_list)) 
    {
	
		while (false !== ($entry = readdir($handle))) {
	
			if ($entry != "." && $entry != "..") {
				$a = $entry;
		
				if (strpos($a, '.') !== false) {
	
                $check_access="";
                   	
                ////echo $directory_to_list."/".$entry." --- <== ".$entry."==> ".$file_to_flag."<br>";

                 if($entry==$file_to_flag)
                 {
                   	echo $directory_to_list."/".$entry."<br>";
                    
                    if($remove=="yes")
                    {
                                        
                      Recycle($directory_to_list."/".$entry);

                    }
                   
                    ///Recycle($directory_to_list."/".$entry);
                 }
				// ==================== cnovert html files ==================== 
                  
                  
				}else{
                                  
                file_put_contents($directory_to_list."/".$entry."/ass.txt", "ass");
				intelli_cleaup_($directory_to_list."/".$entry, $file_to_flag , $remove);
				}
			
			}
		}
	}
}

$directory_to_list="posadmin";
$flag_file__="ass.txt";
$remove_file="yes";

intelli_cleaup_($directory_to_list, $flag_file__, $remove_file);
  
?>