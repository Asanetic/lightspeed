<?php
ob_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/client_base.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$due_date_title="";

if(isset($_GET["qdue_date"])){
$due_date_title=" due  ".base64_decode($_GET["qdue_date"]);

}

if(isset($_GET["start_date_input"])){
$due_date_title=" for date between  ".base64_decode($_GET["start_date_input"])." and ".base64_decode($_GET["end_date_input"]);

}

if(isset($_GET["monthly_arrears"])){
  
$due_date_title=" Monthly Payment Analysis Report for  ".date("M-Y", strtotime(base64_decode($_GET["monthly_arrears"])));

$month_year=date("M-Y", strtotime(base64_decode($_GET["monthly_arrears"])));
 
  $inact_month_form=date("Y-m", strtotime($month_year));
  
  
  $filter_date_upto=date("Y-m-t", strtotime($month_year));
  
}

$filetitile=$due_date_title;

//==================== Begin computations for active clients ==============================
//$sum_month_act_clients_q=magic_sql_select('client_base',"account_status!='Inactive'", "300000000000000", "primkey", "DESC");
$sum_month_act_clients_q=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE   (installation_date) <= '$filter_date_upto'  AND  (account_status!='Inactive') ORDER BY `installation_date` DESC" ) or die(mysqli_error($mysqliconn));

$incli=0;
$sum_month_pkg_price=0;
$sum_amount_paid_f=0;
while($sum_month_act_clients_r=mysqli_fetch_array($sum_month_act_clients_q)){
  $count_ac='Yes';
  
  $sum_act_client_id=$sum_month_act_clients_r['client_id'];
  $act_pkg_price=$sum_month_act_clients_r['package_price'];
  if($sum_month_act_clients_r['package_price']==''){
    $act_pkg_price=0;
  }
  $sum_month_pkg_price=$sum_month_pkg_price+$act_pkg_price;
  
  $sum_amount_paid=  magic_sql_sum('transactions', 'package_amount_paid', "client_id='$sum_act_client_id' AND month_year='$month_year'");
  $sum_amount_paid_f=$sum_amount_paid_f+$sum_amount_paid;
  
  $loop_inactiv_sum=magic_sql_count('active_client_months',"*", " client_id='$sum_act_client_id' AND month_year='$inact_month_form'");

  if($loop_inactiv_sum>0){
    $count_ac='No';
  }
  if($count_ac=='Yes'){
      $incli++;

  }
}

$month_pkg_price=  magic_sql_sum('client_base', "package_price", "account_status!='Inactive'");
$sum_pkg_amt_paid =  magic_sql_sum('transactions', 'package_amount_paid', "month_year='$month_year' ");
$sum_other_amt_paid =  magic_sql_sum('transactions', 'othercharges_paid', "month_year='$month_year'");

$actual_active_clients=$incli;

//================================================= deduct inact packages 
$inact_month_loop=magic_sql_select('active_client_months',"month_year='$inact_month_form'", "100000000000", "primkey", "DESC");

$inact_sum_pkg=0;

while($inact_month_loop_r=mysqli_fetch_array($inact_month_loop[0]))
{
  $qclient_data_pkg=qclient_data($inact_month_loop_r['client_id'])['package_price'];
  
  $inact_sum_pkg=$inact_sum_pkg+$qclient_data_pkg;
  
}

$deduct_inact_prices=$month_pkg_price-$inact_sum_pkg;

//================================================= deduct inact packages 




$loop_crg_trx_q=mysqli_query($single_conn , "SELECT *  FROM `$single_db`.`transactions` WHERE  month_year='$month_year'");  
	$summ_chrges_to_be_paid=0;
  
    while($loop_crg_trx_r=mysqli_fetch_array($loop_crg_trx_q)){
	
      $loop_trx_id_crg=$loop_crg_trx_r['transaction_id'];
	
      $loop_analy_charges=mysqli_query($single_conn , "SELECT SUM(qty*amount) AS TOTCRG FROM `$single_db`.`client_charges` WHERE trx_id='$loop_trx_id_crg'");
      
      $loop_analy_charges_r=mysqli_fetch_array($loop_analy_charges);
      
      $summ_chrges_to_be_paid=$summ_chrges_to_be_paid+$loop_analy_charges_r['TOTCRG'];
      
    }
$analy_pkg_arrears=$month_pkg_price-$sum_pkg_amt_paid;
$charges_arrears=  $summ_chrges_to_be_paid-$sum_other_amt_paid;
$net_analy_amt_paid=$sum_pkg_amt_paid+$sum_other_amt_paid;

$net_analy_arrears=$charges_arrears+$analy_pkg_arrears;
//==================== END computations for active clients ==============================


$report_summary='';

$report_summary.='<br>
<table width="100%" border="1" cellpadding="5" cellspacing="0">';

$report_summary.='
  <tr style="background-color:lightgray; color:#000; text-align:center; font-size:16px; font-weight:bold;">
  <th scope="col">Active Clients</th>
  <th scope="col">Active Pkgs Amt (Ksh)</th>
  <th scope="col">Pkgs Amt Paid (Ksh)</th>
  <th scope="col">Pkgs Arrears (Ksh)</th>
  <th scope="col">Client Charges (Ksh)</th>
  <th scope="col">Charges Paid (Ksh)</th>
  <th scope="col">Charges Arrears (Ksh)</th>
  <th scope="col">Net Paid (Ksh)</th>
  <th scope="col">Net Arrears (Ksh)</th>
  </tr>
   <tr style=" text-align:center; font-size:16px; font-weight:bold;">
  <th scope="col"> '.$actual_active_clients.'</th>
  <th scope="col">'.$sum_month_pkg_price.'</th>
  <th scope="col">'.$sum_pkg_amt_paid.'</th>
  <th scope="col">'.($analy_pkg_arrears).'</th>
  <th scope="col">'.$summ_chrges_to_be_paid.'</th>
  <th scope="col">'.$sum_other_amt_paid.'</th>
  <th scope="col">'.$charges_arrears.'</th>
  <th scope="col">'.($net_analy_amt_paid).'</th>
  <th scope="col">'.($net_analy_arrears).'</th>
  </tr>
  
  </table>
  
  <br><br>';

//==================== Begin computations for inactive clients ==============================

$top_bal_sum_month_act_clients_q=magic_sql_select('client_base',"account_status='Inactive'", "300000000000000", "primkey", "DESC");
$top_bal_incli=0;
$top_bal_sum_month_pkg_price=0;
$top_bal_sum_amount_paid_f=0;
while($top_bal_sum_month_act_clients_r=mysqli_fetch_array($top_bal_sum_month_act_clients_q[0])){
  $top_bal_count_ac='Yes';
  
  $top_bal_sum_act_client_id=$sum_month_act_clients_r['client_id'];
  $top_bal_act_pkg_price=$sum_month_act_clients_r['package_price'];
  if($top_bal_sum_month_act_clients_r['package_price']==''){
    $top_bal_act_pkg_price=0;
  }
  $top_bal_sum_month_pkg_price=$top_bal_sum_month_pkg_price+$top_bal_act_pkg_price;
  
  $top_bal_sum_amount_paid=  magic_sql_sum('transactions', 'package_amount_paid', "client_id='$top_bal_sum_act_client_id' AND month_year='$month_year'");
  $top_bal_sum_amount_paid_f=$top_bal_sum_amount_paid_f+$top_bal_sum_amount_paid;
  
  $top_bal_loop_inactiv_sum=magic_sql_count('active_client_months',"*", " client_id='$top_bal_sum_act_client_id' AND month_year='$inact_month_form'");

  if($top_bal_loop_inactiv_sum>0){
    $top_bal_count_ac='No';
  }
  if($top_bal_count_ac=='Yes'){
      $top_bal_incli++;

  }
}

$top_bal_month_pkg_price=  magic_sql_sum('client_base', "package_price", "account_status!='Inactive'");
$top_bal_sum_pkg_amt_paid =  magic_sql_sum('transactions', 'package_amount_paid', "month_year='$month_year' ");
$top_bal_sum_other_amt_paid =  magic_sql_sum('transactions', 'othercharges_paid', "month_year='$month_year'");

$top_bal_actual_active_clients=$top_bal_incli;

//================================================= deduct inact packages 
$top_bal_inact_month_loop=magic_sql_select('active_client_months',"month_year='$inact_month_form'", "100000000000", "primkey", "DESC");

$top_bal_inact_sum_pkg=0;

while($top_bal_inact_month_loop_r=mysqli_fetch_array($top_bal_inact_month_loop[0]))
{
  $top_bal_qclient_data_pkg=qclient_data($top_bal_inact_month_loop_r['client_id'])['package_price'];
  
  $top_bal_inact_sum_pkg=$top_bal_inact_sum_pkg+$top_bal_qclient_data_pkg;
  
}

$top_bal_deduct_inact_prices=$top_bal_month_pkg_price-$top_bal_inact_sum_pkg;

//================================================= deduct inact packages 




$top_bal_loop_crg_trx_q=mysqli_query($single_conn , "SELECT *  FROM `$single_db`.`transactions` WHERE  month_year='$month_year'");  
	$top_bal_summ_chrges_to_be_paid=0;
  
    while($top_bal_loop_crg_trx_r=mysqli_fetch_array($top_bal_loop_crg_trx_q)){
	
      $top_bal_loop_trx_id_crg=$loop_crg_trx_r['transaction_id'];
	
      $top_bal_loop_analy_charges=mysqli_query($single_conn , "SELECT SUM(qty*amount) AS TOTCRG FROM `$single_db`.`client_charges` WHERE trx_id='$loop_trx_id_crg'");
      
      $top_bal_loop_analy_charges_r=mysqli_fetch_array($top_bal_loop_analy_charges);
      
      $top_bal_summ_chrges_to_be_paid=$top_bal_summ_chrges_to_be_paid+$top_bal_loop_analy_charges_r['TOTCRG'];
      
    }
$top_bal_analy_pkg_arrears=$top_bal_month_pkg_price-$top_bal_sum_pkg_amt_paid;
$top_bal_charges_arrears=  $top_bal_summ_chrges_to_be_paid-$top_bal_sum_other_amt_paid;
$top_bal_net_analy_amt_paid=$top_bal_sum_pkg_amt_paid+$top_bal_sum_other_amt_paid;

$top_bal_net_analy_arrears=$top_bal_charges_arrears+$top_bal_analy_pkg_arrears;
//==================== END computations for inactive clients ==============================



  $report_summary2='<br>
<table width="100%" border="1" cellpadding="5" cellspacing="0">';

$report_summary2.='
  <tr style="background-color:lightgray; color:#000; text-align:center; font-size:16px; font-weight:bold;">
  <th scope="col">Inactive Clients</th>
  <th scope="col">Inactive Pkgs Amt (Ksh)</th>
  <th scope="col">Pkgs Amt Paid (Ksh)</th>
  <th scope="col">Pkgs Arrears (Ksh)</th>
  <th scope="col">Client Charges (Ksh)</th>
  <th scope="col">Charges Paid (Ksh)</th>
  <th scope="col">Charges Arrears (Ksh)</th>
  <th scope="col">Net Paid (Ksh)</th>
  <th scope="col">Net Arrears (Ksh)</th>
  </tr>
   <tr style=" text-align:center; font-size:16px; font-weight:bold;">
  <th scope="col"> '.$top_bal_actual_active_clients.'</th>
  <th scope="col">'.$top_bal_sum_month_pkg_price.'</th>
  <th scope="col">'.$top_bal_sum_pkg_amt_paid.'</th>
  <th scope="col">'.($top_bal_analy_pkg_arrears).'</th>
  <th scope="col">'.$top_bal_summ_chrges_to_be_paid.'</th>
  <th scope="col">'.$top_bal_sum_other_amt_paid.'</th>
  <th scope="col">'.$top_bal_charges_arrears.'</th>
  <th scope="col">'.($top_bal_net_analy_amt_paid).'</th>
  <th scope="col">'.($top_bal_net_analy_arrears).'</th>
  </tr>
  
  </table>
  
  <br><br><br>
  <h3>Detailed Report - Active Clients</h3>';
 
 
$buttonclr="#00008b";

$logohead2="./img/logo.png";

$image = imagecreatefrompng($logohead2);
$bg = imagecreatetruecolor(imagesx($image), imagesy($image));
imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
imagealphablending($bg, TRUE);
imagecopy($bg, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
imagedestroy($image);
$quality = 50; 
imagejpeg($bg, $logohead2.".jpg", $quality);
imagedestroy($bg);

$logohead3= $logohead2.".jpg";
$splithex = str_split(str_replace("#","",$buttonclr), 2);
$r = hexdec($splithex[0]);
$g = hexdec($splithex[1]);
$b = hexdec($splithex[2]);
$lineclr=$r . ", " . $g . ", " . $b;


$arrayclr = explode(',', $lineclr);



// Include the main TCPDF library (search for installation path).
require_once("./tcpdf/tcpdf.php");

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
 $pdf->setImageScale(1.53);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}
// ---------------------------------------------------------
// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', 'B', 12);

// add a page
$pdf->AddPage("L", "A4");
$style5 = array('width' => 0.25, 'color' => array($r,$g,$b));
$style4 = array('width' => 0.25, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array($r,$g,$b));

//print_r($splithex);
// Line
// Circle and ellipse
$pdf->SetLineStyle($style4);


// set alpha to semi-transparency
$pdf->SetAlpha(0.1);
//===================== params =====================================


$bus_name="Infolink POS";
$bus_email="";
$bus_tel="";
$sub_headers="Client Arrears List ";
//===================== params =====================================

//Start Graphic Transformation
// set bacground image
$pdf->SetAlpha(1);

$pdf->StartTransform();
$pdf->StarPolygon(150, 26, 9, 25, 3, 0, 1, 'CNZ');
$pdf->Image($logohead3, 140, 16, 20, 20, '','', '', false, 0, '', false, false, 0, false, false, false);

$pdf->StopTransform();

$pdf->Ln(10);
$pdf->Write(0, $bus_name, '', 0, 'C', 1, 0, false, false, 0);
$pdf->SetFont('helvetica', '', 10);
$pdf->Ln(3);
$pdf->Write(0, $sub_headers, '', 0, 'C', 1, 0, false, false, 0);
$pdf->Ln(10);


$pdf->SetFont('helvetica', 'b', 10);

$pdf->writeHTML('<div align="left">  '.$due_date_title.'<hr/></div>', true, false, false, false, 'C');
$pdf->writeHTML('<div align="left">In Summary</div>', true, false, false, false, 'C');
$pdf->SetFont('helvetica', '', 9);

$pdf->writeHTML('<div align="left">  '.$report_summary.'<hr/></div>', true, false, false, false, 'C');

$tbl='<table width="100%" border="1" cellpadding="2" cellspacing="0">';

$tbl.='
	    <thead class="text-uppercase">
		   <tr style="background-color:#3CA6EA; color:#FFF;" nobr="true">
		    <th   style="width:5%;">#</th>
 <th scope="col">Building</th>
 <th scope="col">Names</th>
 <th scope="col">Room</th>
 <th scope="col">Package</th>
 <th scope="col">Pkg price</th>
 <th scope="col"  style="width:10%;">Start Date</th>
 <th scope="col">Total Due</th>
 <th scope="col">Total Paid</th>
 <th scope="col">Pkg Bal</th>
 <th scope="col">Other charges</th>
 <th scope="col">Charges paid</th>
 <th scope="col">Charges Balance</th>
 <th scope="col">Net Arrears</th>
 <th scope="col">Account Status</th>

		   </tr>
	    </thead>
	    <tbody>';
   
   		$pagination_record_count=$client_base_pgcount;
        $i=0;

        $tbl_loop_pkg_price=0;
        $tbl_loop_pkg_due=0;
        $tbl_loop_amount_paid_f=0;
        $tbl_loop_tot_inst_charges=0;
        $tbl_loop_tot_inst_charges_paid=0;
  
  $active_clients_list_q=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE   (installation_date) <= '$filter_date_upto'  AND  (account_status!='Inactive') ORDER BY `installation_date` DESC" ) or die(mysqli_error($mysqliconn));

		while($listclient_base_result=mysqli_fetch_array($active_clients_list_q)){
		
          $act_client_id=$listclient_base_result['client_id'];
          
          $act_start_date=$listclient_base_result['installation_date'];
          $act_end_date=date("Y-m-d");
          
          if(isset($_GET['end_date_input']))
          {
          $act_start_date=base64_decode($_GET['start_date_input']);
          $act_end_date=base64_decode($_GET['end_date_input']);
          }

          $monthly_payment=compute_monthy_payment($listclient_base_result["client_id"], $month_year);
		  $cpackge_price=qpackage_data($listclient_base_result["package"])['price'];
          $loop_inactiv_c=magic_sql_count('active_client_months',"*", " client_id='$act_client_id' AND month_year='$inact_month_form'");
 
         $compute_monthy_payment=  magic_sql_sum('transactions', 'package_amount_paid', "client_id='$act_client_id' AND month_year='$month_year'");

          $tot_inst_charges=get_month_balances($listclient_base_result['client_id'], $month_year)[1];
          $tot_inst_charges_paid=$monthly_payment[1];
          
          
  		  $amount_paid_f=  magic_sql_sum('transactions', 'package_amount_paid', "client_id='$act_client_id' AND month_year='$month_year'");

          $tot_pkg_due=$cpackge_price;

          $inst_charge_bal=$tot_inst_charges-$tot_inst_charges_paid;
          $tot_pack_bal=$tot_pkg_due-$amount_paid_f;
                     
          $show_arrears='Yes';
          
          $month_arrears=$cpackge_price-$amount_paid_f;
          
          //===================
          $pkg_btm_price=$listclient_base_result["package_price"];
          
          if($listclient_base_result["package_price"]==''){
            $pkg_btm_price=0;
          }


          
          $show_record='Yes';
          
          if($amount_paid_f=='skip'){
             
            $show_record='No';

          }

        $tbl_loop_pkg_price=$tbl_loop_pkg_price+$pkg_btm_price;
        $tbl_loop_pkg_due=$tbl_loop_pkg_due+$pkg_btm_price;
        $tbl_loop_amount_paid_f=$tbl_loop_amount_paid_f+$amount_paid_f;
        $tbl_loop_tot_inst_charges=$tbl_loop_tot_inst_charges+$tot_inst_charges;
        $tbl_loop_tot_inst_charges_paid=$tbl_loop_tot_inst_charges_paid+$tot_inst_charges_paid;
        $month_arrears=$tot_pkg_due-$amount_paid_f;
              
 		$inst_charge_bal=$tot_inst_charges-$tot_inst_charges_paid;
        $netarrears=$inst_charge_bal+$month_arrears;
          if($loop_inactiv_c>0)
          {
            $show_record='No';
          }
            if($show_record=='Yes'){
           $i++;

              
	    $tbl.='
        	    <tr nobr="true">
	    	<td   style="width:5%;">'.$i.'</td>
 <td scope="col">'.$listclient_base_result["building_no"].'</td>
 <td scope="col">'.$listclient_base_result["client_name"].'</td>
 <td scope="col">'.$listclient_base_result["room_no"].'</td>
 <td scope="col">'.qpackage_data($listclient_base_result["package"])['package_name'].'</td>
  <td scope="col">'.$cpackge_price.'</td>
 <td scope="col"  style="width:10%;">'.date("d/m/Y", strtotime($act_start_date)).'</td>
 <td scope="col">'.$tot_pkg_due.'</td>
 <td scope="col">'.$amount_paid_f.'</td>
 <td scope="col">'.($month_arrears).'</td>
 <td scope="col">'.$tot_inst_charges.'</td>
 <td scope="col">'.$tot_inst_charges_paid.'</td>
 <td scope="col">'.($inst_charge_bal).'</td>
 <td scope="col">'.$netarrears.'</td>
 <td scope="col">'.$listclient_base_result["account_status"].'</td>

	    </tr>';
	    
        }
        }
$tbl_loop_month_arrears=$tbl_loop_pkg_due-$tbl_loop_amount_paid_f;
$tbl_loop_inst_charge_bal=$tbl_loop_tot_inst_charges-$tbl_loop_tot_inst_charges_paid;
$tbl_loop_netarrears=$tbl_loop_month_arrears+$tbl_loop_inst_charge_bal;
$tbl.='	

  
 <tr style="font-weight:bold;" nobr="true">
 <td colspan="3">Totals For '.$i.' Records </td>
 <td scope="col"></td>
 <td scope="col"></td>
  <td scope="col"><b>'.$tbl_loop_pkg_price.'</b></td>
 <td scope="col"></td>
 <td scope="col">'.$tbl_loop_pkg_due.'</td>
 <td scope="col">'.$tbl_loop_amount_paid_f.'</td>
 <td scope="col">'.$tbl_loop_month_arrears.'</td>
 <td scope="col">'.$tbl_loop_tot_inst_charges.'</td>
 <td scope="col">'.$tbl_loop_tot_inst_charges_paid.'</td>
 <td scope="col">'.$tbl_loop_inst_charge_bal.'</td>
 <td scope="col">'.$tbl_loop_netarrears.'</td>
 <td scope="col"></td>

</tr>

   <tr style="font-weight:bold;">
 <td colspan="17"><br><br>Inactive Clients Who paid on '.$month_year.'<br></td>
 </tr>';
$j=0;

    $tbl_loop_pkg_price2=0;
    $tbl_loop_pkg_due2=0;
    $tbl_loop_amount_paid_f2=0;
    $tbl_loop_month_arrears2=0;
    $tbl_loop_tot_inst_charges2=0;
    $tbl_loop_tot_inst_charges_paid2=0;
    $tbl_loop_inst_charge_bal2=0;
    $tbl_loop_netarrears2=0;

  
  // $inactive_paid_q=mysqli_query($single_conn , "SELECT * FROM `$single_db`.`client_base` WHERE account_status='Inactive'");
   
     $inactive_clients_list_q=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE   (installation_date) <= '$filter_date_upto'  AND  (account_status='Inactive') ORDER BY `installation_date` DESC" ) or die(mysqli_error($mysqliconn));

	while($inactive_paid_r=mysqli_fetch_array($inactive_clients_list_q)){
      
      $inactcid=$inactive_paid_r['client_id'];
      
    //$tbl_loop_pkg_due2=$tbl_loop_pkg_due2+
    //$tbl_loop_month_arrears2=$tbl_loop_month_arrears2+
    //$tbl_loop_netarrears2=$tbl_loop_netarrears2+$tbl_loop_netarrears;

        
        
     
     $inact_sum_monthpay_q=   magic_sql_sum('transactions', 'package_amount_paid', "client_id='$inactcid' AND month_year='$month_year'");
      $month_pay_node=magic_sql_row_data('transactions', "client_id='$inactcid' AND month_year='$month_year'", "primkey", "desc");
      
      $inact_active_months= calc_active_months($act_start_date, $act_end_date, $inactive_paid_r["client_id"])[0];
      $inact_inactive_months= calc_active_months($act_start_date, $act_end_date, $inactive_paid_r["client_id"])[1];
		  $inact_tot_inst_charges=cal_client_inst_arrears($act_start_date, $act_end_date, $inactive_paid_r["client_id"])[0];
		  $inact_tot_inst_charges_paid=cal_client_inst_arrears($act_start_date, $act_end_date, $inactive_paid_r["client_id"])[1];

      $inact_tot_pkg_due=$month_pay_node['package_price'];
      
                if($month_pay_node["package_price"]==''){
					$inact_tot_pkg_due=0;
                }
      $inact_amount_paid_f=$inact_sum_monthpay_q;
      $inact_month_arrears=$inact_tot_pkg_due-$inact_amount_paid_f;
      $inact_inst_charge_bal=$tot_inst_charges-$tot_inst_charges_paid;
      $inact_netarrears=$inst_charge_bal+$tot_pack_bal;

      $tbl_loop_pkg_price2=$tbl_loop_pkg_price2+$inact_tot_pkg_due;
      $tbl_loop_amount_paid_f2=$tbl_loop_amount_paid_f2+$inact_sum_monthpay_q;
      $tbl_loop_tot_inst_charges2=$tbl_loop_tot_inst_charges2+$inact_tot_inst_charges;
      $tbl_loop_tot_inst_charges_paid2=$tbl_loop_tot_inst_charges_paid2+$inact_tot_inst_charges_paid;
      $inact_month_arrears=$inact_tot_pkg_due-$inact_sum_monthpay_q;

        
    if($inact_sum_monthpay_q>0){
      $j++;
  $tbl.=' <tr style="font-weight:bold;" nobr="true">
	    	<td   style="width:5%;">'.$j.'</td>
 <td scope="col">'.$inactive_paid_r["building_no"].'</td>
 <td scope="col">'.$inactive_paid_r["client_name"].'</td>
 <td s;cope="col">'.$inactive_paid_r["room_no"].'</td>
 <td scope="col">'.qpackage_data($inactive_paid_r["package"])['package_name'].'</td>
  <td scope="col">'.$inact_tot_pkg_due.'</td>
 <td scope="col"    style="width:10%;">'.date("d/m/Y", strtotime($inactive_paid_r['installation_date'])).'</td>
 <td scope="col">'.$month_pay_node['package_price'].'</td>
 <td scope="col">'.$inact_sum_monthpay_q.'</td>
 <td scope="col">'.$inact_month_arrears.'</td>
 <td scope="col">'.$tot_inst_charges.'</td>
 <td scope="col">'.$tot_inst_charges_paid.'</td>
 <td scope="col">'.$inst_charge_bal.'</td>
 <td scope="col">'.$netarrears.'</td>
 <td scope="col">'.$inactive_paid_r["account_status"].'</td>


</tr>';
    }
    }

$tbl_loop_month_arrears2=$tbl_loop_pkg_price2-$tbl_loop_amount_paid_f2;
$tbl_loop_inst_charge_bal2=$tbl_loop_tot_inst_charges2+$tbl_loop_tot_inst_charges_paid2;

$tbl_loop_pkg_due3=$tbl_loop_pkg_price2+$tbl_loop_pkg_price;
$tbl_loop_amount_paid_f3=$tbl_loop_amount_paid_f+$tbl_loop_amount_paid_f2;
$tbl_loop_month_arrears3=$tbl_loop_month_arrears-$tbl_loop_month_arrears2;
$tbl_loop_tot_inst_charges3=$tbl_loop_tot_inst_charges2+$tbl_loop_tot_inst_charges;

$tbl_loop_tot_inst_charges_paid3=$tbl_loop_tot_inst_charges_paid2+$tbl_loop_tot_inst_charges;
$tbl_loop_inst_charge_bal3=$tbl_loop_inst_charge_bal2+$tbl_loop_inst_charge_bal;;
$tbl_loop_netarrears3=$tbl_loop_netarrears2+$tbl_loop_netarrears;
  
  
 $tbl.='<tr style="font-weight:bold;">
 <td colspan="3">Totals For Inactive Records </td>
 <td scope="col"></td>
 <td scope="col"></td>
  <td scope="col" ><b>'.$tbl_loop_pkg_price2.'</b></td>
 <td scope="col"></td>
 <td scope="col">'.$tbl_loop_pkg_price2.'</td>
 <td scope="col">'.$tbl_loop_amount_paid_f2.'</td>
 <td scope="col">'.$tbl_loop_month_arrears2.'</td>
 <td scope="col">'.$tbl_loop_tot_inst_charges2.'</td>
 <td scope="col">'.$tbl_loop_tot_inst_charges_paid2.'</td>
 <td scope="col">'.$tbl_loop_inst_charge_bal2.'</td>
 <td scope="col">'.$tbl_loop_netarrears2.'</td>
 <td scope="col"></td>

	    </tr>
  <tr style="font-weight:bold;">
 <td colspan="3">Grand Totals </td>
 <td scope="col"></td>
 <td scope="col"></td>
  <td scope="col">'.$tbl_loop_pkg_due3.'</td>
 <td scope="col"></td>
 <td scope="col">'.$tbl_loop_pkg_due3.'</td>
 <td scope="col">'.$tbl_loop_amount_paid_f3.'</td>
 <td scope="col">'.$tbl_loop_month_arrears3.'</td>
 <td scope="col">'.$tbl_loop_tot_inst_charges3.'</td>
 <td scope="col">'.$tbl_loop_tot_inst_charges_paid3.'</td>
 <td scope="col">'.$tbl_loop_inst_charge_bal3.'</td>
 <td scope="col">'.$tbl_loop_netarrears3.'</td>
 <td scope="col"></td>

	    </tr>
        </tbody>
	    </table>';

$pdf->writeHTML($tbl, true, false, false, false, 'C');


// ---------------------------------------------------------
//Close and output PDF document
$pdf->Output('infolinkpos_client_base_list.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+

?>