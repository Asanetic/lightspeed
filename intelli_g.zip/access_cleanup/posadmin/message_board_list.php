<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');



$default_home_crumb="";
if(isset($home_crumb))
{
$default_home_crumb=$home_crumb;
}
   	
$message_board_list_query=get_message_board("*", "$gft_message_board Order by primkey DESC", "l:qmessage_board_token");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Message Board</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
	<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">
      <div class="row mt-5 pt-5 justify-content-center pl-1 pr-1">
        
      <div class="col-md-12 pb-2 pl-0 text-dark " style="text-align: left;">
      	<span class="btn_neoo2 slanted_tray p-2 font-weight-bold rounded" >
        	<?php echo $default_home_crumb; ?>
        	<span class="text-white">Message Board List </span> 
        </span>
          <div class="col-md-12 d-lg-none  mb-2"></div>
          <!--{nbuttongh}-->
          <input type="text" class="col-md-2 mb-2 ml-2 bg-transparent" placeholder="Search Message Board" name="txt_message_board" style="color:<?php echo $body_txt ?>; border:none; border-bottom:1px solid <?php echo $btn_bg ?>;"/>
     <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="qmessage_board_btn"><i class="fa fa-search"></i> Go</button>
     <a href="./message_board_list.php" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3"><i class="fa fa-refresh"></i> Refresh </a> 
     <a href="overdue_panel.php" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3"><i class="fa fa-warning"></i> Overdue client list </a> 
      </div>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          
  <style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="message_board_data_table">
	    <thead class="text-uppercase">
		   <tr>
		    <th scope="col">#</th>             
             <th scope="col">Date Sent</th>
             <th scope="col">Subject</th>            	
             <th scope="col">Message Details</th>
             <th scope="col">Receivers</th>

		   </tr>
	    </thead>
	    <tbody>
      <?php 
          $default_message_board_profile="./message_board_list.php";
          if(isset($message_board_profile))
          {
          $default_message_board_profile=$message_board_list;
          } 
          
          $default_message_board_listing="./message_board_list.php";
          if(isset($message_board_listing))
          {
          $default_message_board_listing=$message_board_listing;
          } 
          
          $default_message_board_show_edit_btn="yes";
          if(isset($message_board_show_edit_btn))
          {
          $default_message_board_show_edit_btn=$message_board_show_edit_btn;
          } 
      echo drop_css();
          $i=0;
        
        //<--outloop-dope-->
 
 	while($listmessage_board_result=mysqli_fetch_array($message_board_list_query[0])){
        $i++;
		
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_message_board_show_edit_btn=="yes"){
          $edit_drop_link=magic_link($default_message_board_profile.'?message_board_uptoken='.base64_encode($listmessage_board_result["primkey"]).'','<i class="fa fa-edit"></i> View More', '');
          }
          
           //{{edit_drop_link}}
           if($default_message_board_show_edit_btn=="yes")
           {
            $delete_drop_link=magic_link($default_message_board_profile.'?after_delete='.base64_encode(magic_current_url()).'&message_board_uptoken='.base64_encode($listmessage_board_result["primkey"]).'&deletemessage_board','<i class="fa fa-trash"></i> Delete', '');
		   }
	        $dropdown_items =$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr class="cpointer" onclick="mosytoggle_class('mssg_card_<?php echo $listmessage_board_result['primkey'] ?>', 'd-block')">
             <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>           
             <td scope="col"><?php echo $listmessage_board_result["msg_date"];?></td>
             <td scope="col"><?php echo $listmessage_board_result["subject"];?></td>              
             <td scope="col"><?php echo magic_strip_if($listmessage_board_result["message"], 50 ,50);?>
              <div class="col-md-12  bg-white p-4 shadow d-none rounded_big" id="mssg_card_<?php echo $listmessage_board_result['primkey'] ?>"><?php echo ($listmessage_board_result["message"]);?></div>
              </td>
             <td scope="col"><?php echo magic_strip_if($listmessage_board_result["to"], 20 ,20);?></td>              
			</tr>
       <?php }?>

          <tr>
          <th></th>
          
           <th scope="col"></th>
           <th scope="col"></th>
           <th scope="col"></th>
           <th scope="col"></th>
           <th scope="col"></th>
           <th scope="col"></th>
           <th scope="col"></th>
           <th scope="col"></th>

          </tr>
  <!--add_new_row_here-->
	    </tbody>
	    </table>
             <?php if($i==0){?>
            <h4 class="col-md-12 text-center p-3"><i class="fa fa-search"></i> Sorry, no message board records found</h4>
            <div class="col-md-12 text-center">
            	<?php $search_message_board_class="ml-0"; if($default_message_board_show_edit_btn=="yes"){
                $search_message_board_class="ml-4";
                ?>
            	<a href="<?php echo $default_message_board_profile ?>" class="badge badge-primary mb-3 btn_neo p-2"><i class="fa fa-plus"></i>  Add new </a>
                <?php }?>
            	<a href="<?php echo  $default_message_board_listing?>" class="badge badge-primary mb-3 <?php echo $search_message_board_class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
            </div>
          <?php }?>
         <?php echo mosy_paginate_ui($message_board_list_query[1], $datalimit, "qmessage_board_token")?>
        </div>
       
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>