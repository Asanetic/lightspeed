<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/packages.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Packages</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Package Profile<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  <!--Start Sql input-->  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./packages.php', '<i class="fa fa-arrow-left"></i> Back to list', "");?>

    	<?php echo magic_button_link('./editpackages.php?newrecord', '<i class="fa fa-plus"></i> Add new', "");?> 

		<?php if(isset($_GET['packages_uptoken'])) echo magic_button_link('./editpackages.php?packages_uptoken='.($_GET["packages_uptoken"]).'&deletepackages','<i class="fa fa-trash"></i> Delete', 'style="background-color:red;"');?>
	</div>     
	<div class="row p-md-3 justify-content-center bg-white col-md-11">
	

<div class="col-md-7">
 <div class="form-group">
  <label >Package Name</label>
  <input required class="form-control" id="txt_package_name" name="txt_package_name" value="<?php echo $packages_node["package_name"];?>" placeholder="Package Name" type="text">
 </div>
 <div class="form-group">
  <label >Price</label>
  <input class="form-control" id="txt_price" name="txt_price" value="<?php echo $packages_node["price"];?>" placeholder="Price" type="number" requred>
 </div>
 <div class="form-group">
  <label >Description</label>
  <input class="form-control" id="txt_description" name="txt_description" value="<?php echo $packages_node["description"];?>" placeholder="Description" type="text">

  </div>
</div>
                   
		<div align="center" style="width: 98%">
			<?php if(!isset($_GET['packages_uptoken'])) echo magic_button("packages_insert_btn","Proceed","");?>
			<?php if(isset($_GET['packages_uptoken'])) echo magic_button("packages_update_btn","Save Changes","");?>
		</div>
		</div>

<!--End Sql input-->
<!--<{ncgh}/>-->
        
  <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
