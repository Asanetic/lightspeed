<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include("./data_control/chart_db.php");
include('./adminsessionmonitor.php');

//========== columns ======
;
$skinclr="rgba(255,255,255,0.6)";
$buttonclr='darkblue';
$gentxtclr="#000";
$buttontxtclr="#FFF";
$conttxtclr="#FFF";
$contbgclr="rgba(255,255,255,0.6)";

//========== columns ======


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard</title>
<style>
.btn-light{
 margin-bottom:10px; 
}
</style>
    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
  <script type="text/javascript" src="./gstatic/loader.js"></script>
	<script>google.charts.load('current', {'packages':['corechart']});</script>
    
<script type="text/javascript" i>
      google.charts.setOnLoadCallback(drawChart_sumamount_paid_transactions_status_payments_by_status);

      function drawChart_sumamount_paid_transactions_status_payments_by_status() {

        var data = google.visualization.arrayToDataTable([
          ['Status', 'Amount Paid'],
		  <?php while($amount_paid_transactions_status_payments_by_status_sumres=mysqli_fetch_array($amount_paid_transactions_status_payments_by_status_sumquery)){
          echo '[\''.$amount_paid_transactions_status_payments_by_status_sumres["status"].'\',     '.$amount_paid_transactions_status_payments_by_status_sumres["amount_paid_sum"].'],';
		  }?>
        ]);

        var options = {
          title: 'Payments By Status',
		  		   pieHole: 0.4,
				   
		  curveType: 'function',
      backgroundColor: {
        fill: '<?php echo $skinclr;?>',
        fillOpacity: 0.6
      },
		hAxis: {
    textStyle:{color: '<?php echo $gentxtclr;?>'}
			},
		vAxis: {
    	textStyle:{color: '<?php echo $gentxtclr;?>'}
		},
    legendTextStyle: { color: '<?php echo $gentxtclr;?>' },
    titleTextStyle: { color: '<?php echo $gentxtclr;?>' },
	        slices: {0: {color: '<?php echo $buttonclr;?>'},},
        };

        var chart = new google.visualization.PieChart(document.getElementById('chartsumamount_paid_transactions_status_payments_by_status'));

        chart.draw(data, options);
      }
    </script>
<script type="text/javascript" i>
      google.charts.setOnLoadCallback(drawChart_sumamount_paid_expenses_transaction_id_expenditure_by_tag);

      function drawChart_sumamount_paid_expenses_transaction_id_expenditure_by_tag() {

        var data = google.visualization.arrayToDataTable([
          ['Transaction Type', 'Amount Paid'],
		  <?php while($amount_paid_expenses_transaction_id_expenditure_by_tag_sumres=mysqli_fetch_array($amount_paid_expenses_transaction_id_expenditure_by_tag_sumquery)){


          echo '[\''.$amount_paid_expenses_transaction_id_expenditure_by_tag_sumres["transaction_type"].'\',     '.$amount_paid_expenses_transaction_id_expenditure_by_tag_sumres["amount_paid_sum"].'],';
		  }?>
        ]);

        var options = {
          title: 'Expenditure By Tag',
		  		   
				   
		  curveType: 'function',
      backgroundColor: {
        fill: '<?php echo $skinclr;?>',
        fillOpacity: 0.6
      },
		hAxis: {
    textStyle:{color: '<?php echo $gentxtclr;?>'}
			},
		vAxis: {
    	textStyle:{color: '<?php echo $gentxtclr;?>'}
		},
    legendTextStyle: { color: '<?php echo $gentxtclr;?>' },
    titleTextStyle: { color: '<?php echo $gentxtclr;?>' },
	        slices: {0: {color: '<?php echo $buttonclr;?>'},},
        };

        var chart = new google.visualization.PieChart(document.getElementById('chartsumamount_paid_expenses_transaction_id_expenditure_by_tag'));

        chart.draw(data, options);
      }
    </script>
<script type="text/javascript" i>
      google.charts.setOnLoadCallback(drawChart_sumamount_paid_transactions_month_year_payments_by_month);

      function drawChart_sumamount_paid_transactions_month_year_payments_by_month() {

        var data = google.visualization.arrayToDataTable([
          ['Month Year', 'Amount Paid'],
		  <?php while($amount_paid_transactions_month_year_payments_by_month_sumres=mysqli_fetch_array($amount_paid_transactions_month_year_payments_by_month_sumquery)){
          echo '[\''.$amount_paid_transactions_month_year_payments_by_month_sumres["month_year"].'\',     '.$amount_paid_transactions_month_year_payments_by_month_sumres["amount_paid_sum"].'],';
		  }?>
        ]);

        var options = {
          title: 'Payments By Month',
		  		   
				   
		  curveType: 'function',
      backgroundColor: {
        fill: '<?php echo $skinclr;?>',
        fillOpacity: 0.6
      },
		hAxis: {
    textStyle:{color: '<?php echo $gentxtclr;?>'}
			},
		vAxis: {
    	textStyle:{color: '<?php echo $gentxtclr;?>'}
		},
    legendTextStyle: { color: '<?php echo $gentxtclr;?>' },
    titleTextStyle: { color: '<?php echo $gentxtclr;?>' },
	        slices: {0: {color: '<?php echo $buttonclr;?>'},},
        };

        var chart = new google.visualization.ColumnChart(document.getElementById('chartsumamount_paid_transactions_month_year_payments_by_month'));

        chart.draw(data, options);
      }
    </script>
<script type="text/javascript" i>
      google.charts.setOnLoadCallback(drawChart_sumamount_paid_transactions_package_name_transactions_by_package);

      function drawChart_sumamount_paid_transactions_package_name_transactions_by_package() {

        var data = google.visualization.arrayToDataTable([
          ['Package Name', 'Amount Paid'],
		  <?php while($amount_paid_transactions_package_name_transactions_by_package_sumres=mysqli_fetch_array($amount_paid_transactions_package_name_transactions_by_package_sumquery)){

        $package_id=$amount_paid_transactions_package_name_transactions_by_package_sumres["package_name"];

        $package_name= magic_sql_row_data('packages', "package_id='$package_id'", "primkey", "DESC")['package_name'];


          echo '[\''.$package_name.'\',     '.$amount_paid_transactions_package_name_transactions_by_package_sumres["amount_paid_sum"].'],';
		  }?>
        ]);

        var options = {
          title: 'Transactions By Package',
		  		   
				   
		  curveType: 'function',
      backgroundColor: {
        fill: '<?php echo $skinclr;?>',
        fillOpacity: 0.6
      },
		hAxis: {
    textStyle:{color: '<?php echo $gentxtclr;?>'}
			},
		vAxis: {
    	textStyle:{color: '<?php echo $gentxtclr;?>'}
		},
    legendTextStyle: { color: '<?php echo $gentxtclr;?>' },
    titleTextStyle: { color: '<?php echo $gentxtclr;?>' },
	        slices: {0: {color: '<?php echo $buttonclr;?>'},},
        };

        var chart = new google.visualization.ColumnChart(document.getElementById('chartsumamount_paid_transactions_package_name_transactions_by_package'));

        chart.draw(data, options);
      }
    </script>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Dashboard<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  
<div align="center" class="row justify-content-center pl-2 m-0">
  
    <div class="col-md-3 text-center" >
      <a href="./expenses.php"  class="btn btn-light mb-3 p-3 shadow rounded text-dark mr-lg-1">
      <div class="count_card" style="font-size:14px; font-weight:bold;">
          Expenditure this month : 
          <?php echo $expenses_expenditure_this_month_card_sum_res["amount_paid_COUNT"];?> 
      </div>
      </a>
      <a href="./transactions-viewlist.php" class="btn btn-light p-3 mr-lg-1">
      <div class="count_card" style="font-size:14px; font-weight:bold;">
              Payments This month : 
              <?php echo $transactions_payments_this_month_card_sum_res["amount_paid_COUNT"];?> 
        </div>
      </a>
    <div class="col-md-10 mt-5 pl-lg-2 ml-lg-5 text-left shadow pt-3 pb-5" style="border-left:2px solid green; border-top:2px solid #ccc;">
      <b>Quick Menu<br><br></b>
    <a href="arrears" class="col-md-12 text-dark text-left mt-3">
		<i class="fa fa-users"></i> Clients With Arrears
	</a><br><br>
    <a href="client_base?qdue_date=<?php echo base64_encode(date('d'))?>" class="col-md-12 text-dark text-left mt-3">
		<i class="fa fa-list"></i> Due Today
	</a><br><br>
    <a href="transactions" class="col-md-12 text-dark text-left mt-3">
		<i class="fa fa-credit-card"></i> Payment List
	</a><br><br>
    <a href="arrears" class="col-md-12 text-dark text-left mt-3">
		<i class="fa fa-plus"></i> Record Payment
	</a><br><br>
    <a href="packages" class="col-md-12 text-dark text-left mt-3">
		<i class="fa fa-copy"></i> Packages
	</a><br><br>
    <a href="editinventory" class="col-md-12 text-dark text-left mt-3">
		<i class="fa fa-truck"></i> Add Inventory
	</a><br><br>
    <a href="inventory" class="col-md-12 text-dark text-left mt-3">
		<i class="fa fa-table"></i> List Inventory
	</a><br><br>
    <a href="reportpanel" class="col-md-12 text-dark text-left mt-3">
		<i class="fa fa-bar-chart"></i> Reports
	</a>
	</div>
    </div>
    <div class="col-md-9 text-center p-3">
    <a href="./client-base-viewlist.php" class="btn btn-light p-3 mb-3 shadow">
    <div class="count_card">
      <i class="fa fa-users"></i>
      Clients | <?php echo $client_base_clients_card_count_res["0"];?> 
    </div>
    </a>
    <a href="./transactions-viewlist.php" class="btn btn-light p-3 mb-3 mr-lg-1">
    <div class="count_card">
		<i class="fa fa-database"></i>

      Pending Payments | <?php echo $transactions_pending_payments_card_count_res["0"];?> 
    </div>
    </a>
    <a href="./expenses-viewlist.php" class="btn btn-light p-3 shadow mb-3 mr-lg-1">
    <div class="count_card">
		<i class="fa fa-arrow-up"></i>
      Total Expenditure | <?php echo $expenses_total_expenditure_card_sum_res["amount_paid_COUNT"];?> </div></a>
    <a href="./transactions-viewlist.php" class="btn btn-light p-3 shadow mb-3 ">
      <div class="count_card">
          <i class="fa fa-credit-card"></i>
      Total Payments | <?php echo $transactions_total_payments_card_sum_res["amount_paid_COUNT"];?> 
      </div>
    </a>
<div class="row justify-content-center col-md-12 mt-4">

      <div id="chartsumamount_paid_transactions_status_payments_by_status" class="col-md-6 " style="height:300px;">No Data</div>
      <div id="chartsumamount_paid_expenses_transaction_id_expenditure_by_tag" class="col-md-6 " style="height:300px;" >No Data</div>
      <div id="chartsumamount_paid_transactions_month_year_payments_by_month" class="col-md-12  mt-4 mb-4" style="height:300px;" >No Data</div>
      <div id="chartsumamount_paid_transactions_package_name_transactions_by_package" class="col-md-12 "style="height:300px;" >No Data</div>
</div>

    <br>
    <br>
    <br>
    <br>

    </div>
</div>
          <!--<{ncgh}/>-->
</div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>

                
                
                
                
                
                
                
                
                
                
                
                
                