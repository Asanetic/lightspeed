<?php

ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./data_control/client_base.php');
include('./adminsessionmonitor.php');;

$due_date_title="";

if(isset($_GET["qdue_date"])){
$due_date_title=" due  ".base64_decode($_GET["qdue_date"]);

}

if(isset($_GET["start_date_input"])){
$due_date_title=" With arrears for date between  ".base64_decode($_GET["start_date_input"])." and ".base64_decode($_GET["end_date_input"]);

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Client Base</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Client List <?php echo $due_date_title;?><br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
       
    <div align="left" class="col-md-12">
       <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
		<a href="./editclient_base.php?newrecord" class="btn btn-info mb-3"> <i class="fa fa-plus"></i> Register new client </a>

		<div  onclick="pop_arr_month('./monthly_arrears', 'arrears', '')"  class="btn btn-danger mb-3"><i class="fa fa-calendar"></i> Monthly Arrears</div>      
        <a href="client_base?qstart_due_date=<?php echo base64_encode(date('d'))?>&qend_due_date=<?php echo base64_encode(date('d'))?>" class="btn btn-dark mb-3"> <i class="fa fa-warning"></i> Due Today</a>
		<a href="./inactive_clients?qstate=inactive" class="btn btn-secondary mb-3"> <i class="fa fa-times"></i> Inactive </a>
		<a href="client_base?qstate=Active" class="btn btn-success mb-3"> <i class="fa fa-heart"></i> Active </a>
		<div  onclick="pop_due_date('./client_base.php')" class="btn btn-success mb-3"> <i class="fa fa-calendar"></i> Filter Due Date </div>
        <div onclick="pop_report_date('./client_base', 'Installation Date', 'install_date')"  class="btn btn-primary mb-3"><i class="fa fa-wifi"></i> Filter by install date</div>

        <?php echo magic_button_link('./client_base.php', '<i class="fa fa-refresh"></i> View All', 'style=";"');?> 
		<hr><input type="text" placeholder="Search client base" name="txt_client_base" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button('qclient_base_btn', 'Search', 'style="display:inline-block;"');?> 

	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">
	<table class="table table-hover text-left" id="client_base_data_table">
	    <thead class="text-upperckase">
		   <tr>
             <th scope="col">#</th>
             <th scope="col">Building</th>
             <th scope="col">Names</th>
             <th scope="col">Room</th>
             <th scope="col">Package</th>
             <th scope="col">Pkg_amt</th>
             <th scope="col">Start_Date</th>
             <th scope="col">Act mth</th>
             <th scope="col">Inact mth</th>
             <th scope="col">Total Due</th>
             <th scope="col">Total Paid</th>
             <th scope="col">Pkg Bal</th>
             <th scope="col">Other charges</th>
             <th scope="col">Charges paid</th>
             <th scope="col">Charges Balance</th>
             <th scope="col">Net Arrears</th>
             <th scope="col">Account Status</th>
		   </tr>
	    </thead>
	    <tbody>
		<?php 
		$pagination_record_count=$client_base_pgcount;
        $i=0;
		while($listclient_base_result=mysqli_fetch_array($client_base_list_query)){
	        $i++;

	        $edit_drop_link=magic_link('./editclient_base.php?client_base_uptoken='.base64_encode($listclient_base_result["primkey"]).'','<i class="fa fa-arrow-right"></i> View More', '');

	        $delete_drop_link=magic_link('./edittransactions.php?client_id='.base64_encode($listclient_base_result["client_id"]).'','<i class="fa fa-credit-card"></i> Add Payment', '');
	        $delete_drop_link.=magic_link('#','<i class="fa fa-times"></i> Inactive Months', 'onclick="pop_manage_active_months(\''.$listclient_base_result['client_id'].'\')"');
	        $delete_drop_link.=magic_link('./transactions.php?qclient_id='.base64_encode($listclient_base_result["client_id"]).'','<i class="fa fa-history"></i>Payment History', '');
     
	        $delete_drop_link.=magic_link('./editclient_base.php?client_base_uptoken='.base64_encode($listclient_base_result["primkey"]).'&deleteclient_base','<i class="fa fa-trash"></i> Delete', '');
          
          
          $act_start_date=$listclient_base_result['installation_date'];
          $act_end_date=date("Y-m-d");
          
          if(isset($_GET['end_date_input']))
          {
          $act_start_date=base64_decode($_GET['start_date_input']);
          $act_end_date=base64_decode($_GET['end_date_input']);
          }
          
          
          $tot_pkg_paid=cal_client_payments($act_start_date, $act_end_date,  $listclient_base_result["client_id"]);
		  $tot_inst_charges=cal_client_inst_arrears($act_start_date, $act_end_date, $listclient_base_result["client_id"])[0];
		  $tot_inst_charges_paid=cal_client_inst_arrears($act_start_date, $act_end_date, $listclient_base_result["client_id"])[1];
		  $cpackge_price=qpackage_data($listclient_base_result["package"])['price'];
          

          $active_months= calc_active_months($act_start_date, $act_end_date, $listclient_base_result["client_id"])[0];
          $inactive_months= calc_active_months($act_start_date, $act_end_date, $listclient_base_result["client_id"])[1];
	      $tot_pkg_due=$active_months*$cpackge_price;
          $tot_pack_bal=$tot_pkg_due-$tot_pkg_paid;
          $inst_charge_bal=$tot_inst_charges-$tot_inst_charges_paid;
           
          $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
	    <tr>
		<?php 
          
          include('./data_ui/mainclient_list.php');
          
         ?>

	    </tr>
	    <?php }?>
	    </tbody>
	    </table>
	 <hr>
	 <?php include("./pagination.php");?>
	</div>
 
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>

          
          
          
          