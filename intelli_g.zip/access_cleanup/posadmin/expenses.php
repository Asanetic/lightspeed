<?php

ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./data_control/expenses.php');
include('./adminsessionmonitor.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Expenses</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Expenses<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          
    <div align="left" class="col-md-6">
       <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./editexpenses.php?newrecord', '<i class="fa fa-plus"></i> Add new', 'style="display:inline-block;"');?> 
    	<?php echo magic_button_link('./expenses.php', '<i class="fa fa-refresh"></i> Refresh', 'style="display:inline-block;"');?> 

		<hr><input type="text" placeholder="Search expenses" name="txt_expenses" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button('qexpenses_btn', 'Search', 'style="display:inline-block;"');?> 

	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">
	<table class="table table-hover text-left" id="expenses_data_table">
	    <thead class="text-uppercase">
		   <tr>
		    <th scope="col">#</th>
 <th scope="col">RefNo</th>
 <th scope="col">Amount</th>
 <th scope="col">Type</th>
 <th scope="col">Transaction_Date</th>
 <th scope="col">Month Year</th>
 <th scope="col">Remark</th>
 <th scope="col">Payment_Mode</th>

		   </tr>
	    </thead>
	    <tbody>
		<?php 
		$pagination_record_count=$expenses_pgcount;
        $i=0;
		while($listexpenses_result=mysqli_fetch_array($expenses_list_query)){
	        $i++;

	        $edit_drop_link=magic_link('./editexpenses.php?expenses_uptoken='.base64_encode($listexpenses_result["primkey"]).'','<i class="fa fa-edit"></i> Edit', '');

	        $delete_drop_link=magic_link('./editexpenses.php?expenses_uptoken='.base64_encode($listexpenses_result["primkey"]).'&deleteexpenses','<i class="fa fa-trash"></i> Delete', '');

	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
	    <tr>
	    	<td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
 <td scope="col"><?php echo $listexpenses_result["transaction_ref"];?></td>
 <td scope="col"><?php echo $listexpenses_result["amount_paid"];?></td>
 <td scope="col"><?php echo $listexpenses_result["transaction_type"];?></td>
 <td scope="col"><?php echo $listexpenses_result["transaction_date"];?></td>
 <td scope="col"><?php echo $listexpenses_result["month_year"];?></td>
 <td scope="col"><?php echo $listexpenses_result["remark"];?></td>
 <td scope="col"><?php echo $listexpenses_result["payment_mode"];?></td>

	    </tr>
	    <?php }?>
	    </tbody>
	    </table>
	 <hr>
	 <?php include("./pagination.php");?>
	</div>
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
