<?php
ob_start();

include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/client_base.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Client Base</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Due today List<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
       
    <div align="left" class="col-md-8">
       <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
		<a href="./editclient_base.php?newrecord" class="btn btn-info mb-3"> <i class="fa fa-plus"></i> Register new client </a>
		<a href="./client_base" class="btn btn-danger mb-3"><i class="fa fa-exclamation"></i> With arrears</a>
		<a href="" class="btn btn-dark mb-3"> <i class="fa fa-warning"></i> Due Today</a>
		<a href="client_base?qstate=inactive" class="btn btn-secondary mb-3"> <i class="fa fa-times"></i> Inactive </a>
		<a href="client_base?qstate=Active" class="btn btn-success mb-3"> <i class="fa fa-heart"></i> Active </a>
        <?php echo magic_button_link('./client_base.php', '<i class="fa fa-refresh"></i> Refresh List', 'style="display:inline-block;"');?> 

		<hr><input type="text" placeholder="Search client base" name="txt_client_base" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button('qclient_base_btn', 'Search', 'style="display:inline-block;"');?> 

	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">
	<table class="table table-hover text-left" id="client_base_data_table">
	    <thead class="text-uppercase">
		   <tr>
		    <th scope="col">#</th>
 <th scope="col">Names</th>
 <th scope="col">Mobile</th>
 <th scope="col">Location</th>
 <th scope="col">Building</th>
 <th scope="col">Floor</th>
 <th scope="col">Room</th>
 <th scope="col">Package</th>
 <th scope="col">Package_price</th>
 <th scope="col">Installation_Date</th>
 <th scope="col">Signed_By</th>
 <th scope="col">Comment</th>
 <th scope="col">Account_Status</th>

		   </tr>
	    </thead>
	    <tbody>
		<?php 
		$pagination_record_count=$client_base_pgcount;
        $i=0;
		while($listclient_base_result=mysqli_fetch_array($client_base_list_query)){
	        $i++;

	        $edit_drop_link=magic_link('./editclient_base.php?client_base_uptoken='.base64_encode($listclient_base_result["primkey"]).'','<i class="fa fa-arrow-right"></i> View More', '');

	        $delete_drop_link=magic_link('./edittransactions.php?client_id='.base64_encode($listclient_base_result["client_id"]).'','<i class="fa fa-credit-card"></i> Add Payment', '');
	        $delete_drop_link.=magic_link('./editclient_base.php?client_base_uptoken='.base64_encode($listclient_base_result["primkey"]).'&deleteclient_base','<i class="fa fa-trash"></i> Delete', '');

	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
	    <tr>
	    	<td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
 <td scope="col"><?php echo $listclient_base_result["client_name"];?></td>
 <td scope="col"><?php echo $listclient_base_result["client_tel"];?></td>
 <td scope="col"><?php echo $listclient_base_result["location"];?></td>
 <td scope="col"><?php echo $listclient_base_result["building_no"];?></td>
 <td scope="col"><?php echo $listclient_base_result["floor_no"];?></td>
 <td scope="col"><?php echo $listclient_base_result["room_no"];?></td>
 <td scope="col"><?php echo  qpackage_data($listclient_base_result["package"])['package_name'];?></td>
 <td scope="col"><?php echo  qpackage_data($listclient_base_result["package"])['price'];?></td>
 <td scope="col"><?php echo $listclient_base_result["installation_date"];?></td>
 <td scope="col"><?php echo qteam_data($listclient_base_result["signed_by"])['username'];?></td>
 <td scope="col"><?php echo $listclient_base_result["comment"];?></td>
 <td scope="col"><?php echo $listclient_base_result["account_status"];?></td>

	    </tr>
	    <?php }?>
	    </tbody>
	    </table>
	 <hr>
	 <?php include("./pagination.php");?>
	</div>
  <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>

          
          
          
          