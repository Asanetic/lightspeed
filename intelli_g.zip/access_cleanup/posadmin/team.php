<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/team.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Team</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Team<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  
    <div align="left" class="col-md-6">
       <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./editteam.php?newrecord', '<i class="fa fa-plus"></i> Add new', 'style="display:inline-block;"');?> 
    	<?php echo magic_button_link('./team.php', '<i class="fa fa-refresh"></i> Refresh', 'style="display:inline-block;"');?> 

		<hr><input type="text" placeholder="Search team" name="txt_team" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button('qteam_btn', 'Search', 'style="display:inline-block;"');?> 

	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">
	<table class="table table-hover text-left" id="team_data_table">
	    <thead class="text-uppercase">
		   <tr>
		    <th scope="col">#</th>
           <th scope="col">Names</th>
           <th scope="col">Username</th>
           <th scope="col">Role</th>
           <th scope="col">Telephone</th>
		   </tr>
	    </thead>
	    <tbody>
		<?php 
		$pagination_record_count=$team_pgcount;
        $i=0;
		while($listteam_result=mysqli_fetch_array($team_list_query)){
	        $i++;

	        $edit_drop_link=magic_link('./editteam.php?team_uptoken='.base64_encode($listteam_result["primkey"]).'','<i class="fa fa-edit"></i> Edit', '');

	        $delete_drop_link=magic_link('./editteam.php?team_uptoken='.base64_encode($listteam_result["primkey"]).'&deleteteam','<i class="fa fa-trash"></i> Delete', '');

	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
	    <tr>
	    	<td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
 <td scope="col"><?php echo $listteam_result["names"];?></td>
 <td scope="col"><?php echo $listteam_result["username"];?></td>
 <td scope="col"><?php echo $listteam_result["role"];?></td>
 <td scope="col"><?php echo $listteam_result["telephone"];?></td>

	    </tr>
	    <?php }?>
	    </tbody>
	    </table>
	 <hr>
	 <?php include("./pagination.php");?>
	</div>
          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
