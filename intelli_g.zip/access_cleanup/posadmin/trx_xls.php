<?php
 ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/transactions.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$due_date_title="Transactions Report";

if(isset($_GET["qdue_date"])){
$due_date_title=" due  ".base64_decode($_GET["qdue_date"]);

}

if(isset($_GET["start_date_input"])){
$due_date_title="Client_With_arrears_for_date_between_".base64_decode($_GET["start_date_input"])."_and_".base64_decode($_GET["end_date_input"]);

}
	header("Content-Type: application/xls");    
	header("Content-Disposition: attachment; filename=infolink__".$due_date_title.".xls");  
	header("Pragma: no-cache"); 
	header("Expires: 0");


$tbl='<table width="100%" border="1" cellpadding="2" cellspacing="0">';

$tbl.='
	    <thead class="text-uppercase">
		   <tr style="background-color:#3CA6EA; color:#FFF;">
		    <th   style="width:5%;">#</th>
 <th   style="width:10%;"  >Client</th>
 <th   style="width:10%;"  >Package</th>
 <th  >Pkg_Price</th>
  <th  >Arrears</th>
 <th  >Pkg_Paid</th>
 <th  >Inst_Chrg</th>
 <th  >Chrg_Paid</th>
 <th  >Bal</th>
 <th  >Mth_Yr</th>
 <th  >Date</th>
 <th  >Mode</th>
 <th  >RefNo</th>

		   </tr>
	    </thead>
	    <tbody>';

        $i=0;
        $tot_pkpr=0;
        $tot_pkamt_paid=0;
        $tot_client_btm_charges=0;
        $other_charges_paid_btm=0;
		$pkg_btm_bal=0;
		$new_bal_btm=0;
		while($listtransactions_result=mysqli_fetch_array($transactions_list_query)){
	        $i++;


          $loop_trx_id=$listtransactions_result['transaction_id'];
          $loop_client_id=$listtransactions_result['client_id'];
          
          $sum_stalltion_charges_q=mysqli_query($mysqliconn , "SELECT SUM(qty*amount) AS TOTCHARGES FROM `$infolinkdb`.`client_charges`  WHERE client_id='$loop_client_id' AND trx_id='$loop_trx_id'");
          $sum_stalltion_charges_r=mysqli_fetch_array($sum_stalltion_charges_q);
		$loop_pkg_price=$listtransactions_result["package_price"];
        if($listtransactions_result["package_price"]==''){
        $loop_pkg_price=0;
        }
        $tot_pkpr=$tot_pkpr+$loop_pkg_price;
        $tot_pkamt_paid=$tot_pkamt_paid+$listtransactions_result["package_amount_paid"];
        $tot_client_btm_charges=$tot_client_btm_charges+$sum_stalltion_charges_r['TOTCHARGES'];
        $other_charges_paid_btm=$other_charges_paid_btm+$listtransactions_result["othercharges_paid"];
		$pkg_btm_bal=$pkg_btm_bal+$listtransactions_result["old_balances"];
		$new_bal_btm=(($listtransactions_result["old_balances"]+$sum_stalltion_charges_r['TOTCHARGES'])-($listtransactions_result["package_amount_paid"]+ $listtransactions_result["othercharges_paid"]));

        
	    $tbl.='<tr>
	    	<td   style="width:5%;">'. $i.'</td>
  <td   style="width:10%;" >'. qclient_data($listtransactions_result["client_id"])['client_name'].'</td>
 <td    style="width:10%;">'. qpackage_data($listtransactions_result["package_name"])['package_name'].'</td>
 <td  >'. $listtransactions_result["package_price"].'</td>
 <td  >'. $listtransactions_result["old_balances"].'</td>
 <td  >'. $listtransactions_result["package_amount_paid"].'</td>
 <td  >'. $sum_stalltion_charges_r['TOTCHARGES'].'</td>
 <td  >'. $listtransactions_result["othercharges_paid"].'</td>
 <td  >'. $listtransactions_result["balance"].'</td>
 <td  >'. date("M-Y", strtotime($listtransactions_result["month_year"])).'</td>
 <td  >'. date("d/m/Y", strtotime($listtransactions_result["transaction_date"])).'</td>
 <td  >'. $listtransactions_result["payment_mode"].'</td>
  <td  >'. $listtransactions_result["transaction_ref"].'</td>


	    </tr>';
	    }
		   $tbl.='<tr style="font-size:14px; font-weight:bold;">
		    <th   style="width:5%;"></th>
 <th  style="width:10%;"   ></th>
 <th  style="width:10%;"   >Totals</th>
 <th  ></th>
  <th  ></th>
 <th  >'. $tot_pkamt_paid.'</th>
 <th  >'. $tot_client_btm_charges.'</th>
 <th  >'. $other_charges_paid_btm.'</th>
 <th  ></th>
 <th  ></th>
 <th  ></th>
 <th  ></th>
 <th  ></th>

		   </tr>';

$tbl.='	</tbody>
	    </table>';

echo $tbl;