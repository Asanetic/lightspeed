<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/adminlogin.php');

if(isset($_SESSION["infocms_admin_session"]) && !isset($_GET['ref_url_go_to'])){
header('location:./dashboard');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Infolink POS Admin Panel<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  
          
<div class="col-md-12" style="text-align: center;">
	<img src="./img/logo.png" style="height: 90px;">
</div>

<!--Start system_admins Login inputs-->  


<div class="col-md-4 p-4 mt-md-5 rounded-lg  shadow-sm" style="background-color: rgba(255,255,255, 0.5);  border-top: 2px solid darkblue;">
  <h6>Login to proceed</h6>
	<div class="form-group mt-3">
		<label ><i class="fa fa-user"></i> Username</label>
		<input class="form-control" id="txt_username" name="txt_username" placeholder="Username" type="text" required="">
	</div>
	<div class="form-group">
		<label ><i class="fa fa-lock"></i> Password </label>
		<input class="form-control" id="txt_password" name="txt_password" placeholder="Password" type="password" required="">
	</div>
	<div align="center" style="width: 98%">
		<?php   echo magic_button("btn_login","Proceed","");?>
		<br>
		<br>
	</div>

</div><!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
