<nav class="navbar navbar-expand-md navbar-light bg-light shadow-sm fixed-top bg-white border-bottom border-primary mb-3">
    <a class="navbar-brand text-dark" href="#">
        <img src="./img/logo.png" style="width: 50px; height: 50px;" /> Infolink Pos
          <div class="ml-lg-2" style="font-size:11px; padding-left: 50px; font-weight: bold; border-top: 0px solid #FFF; margin-top: -16px;">Client Management System</div>

  </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse ml-lg-5" id="navbarsExampleDefault">
  <?php if(isset($_SESSION["infocms_admin_session"])){?>

        <ul class="navbar-nav mr-auto text-dark">
            <li class="nav-item">
                <a class="nav-link text-dark" href="./dashboard">Dashboard </a>
            </li>

            <li class="nav-item dropdown ml-lg-4">
                <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Clients
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="./editclient_base.php">Add New</a>
                  <a class="dropdown-item" href="./client_base.php">View Client List</a>
                  <a class="dropdown-item" href="#"  onclick="pop_arr_month('./monthly_arrears')">With Arrears</a>
                  <a class="dropdown-item" href="./arrears" >All With Arrears</a>
                  <a class="dropdown-item" href="./client_base?qstart_due_date=<?php echo base64_encode(date('d'))?>&qend_due_date=<?php echo base64_encode(date('d'))?>">Due Today</a>
                  <a class="dropdown-item" href="#" onclick="pop_due_date('./client_base.php')" >Filter Due Today</a>
                  <a class="dropdown-item" href="./inactive_clients.php">Inactive</a>
                  <a class="dropdown-item" href="./client_base.php">Active Clients</a>
                  <a class="dropdown-item" href="./overdue_panel.php">Overdue Accounts</a>
                </div>
           </li>
            <li class="nav-item dropdown ml-lg-3">
                <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Payments
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="#" onclick="pop_client_search('')">Record Client Payment</a>
                  <a class="dropdown-item" href="./arrears.php">Repay Balances</a>
                  <a class="dropdown-item" href="./transactions.php">View Transactions</a>
                  <a class="dropdown-item" href="./transactions.php?qstatus=Pending">Pending Transactions</a>
                  <a class="dropdown-item" href="./transactions.php?qstatus=Cleared">Cleared Transactions</a>
                  <a class="dropdown-item" href="./reportpanel.php">Report Sheets</a>
                </div>
           </li>
            <li class="nav-item dropdown ml-lg-3">
                <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Inventory
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="./editinventory.php">Add New</a>
                  <a class="dropdown-item" href="./inventory.php">Inventory</a>
                  <a class="dropdown-item" href="./suppliers.php">Suppliers</a>
                  <a class="dropdown-item" href="./stock_history.php">Stock History</a>
                </div>
           </li>
 
          <li class="nav-item dropdown ml-lg-3">
                <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Packages
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="./editpackages.php">Add New</a>
                  <a class="dropdown-item" href="./packages.php">View All</a>
                </div>
           </li>
    
          <li class="nav-item dropdown ml-lg-3">
                <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  More
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="./team">Team</a>
                  <a class="dropdown-item" href="./admin">Admins</a>
                  <a class="dropdown-item" href="./expenses">Expenses</a>
                  <a class="dropdown-item" href="./vcf_client_base.php">Export Contacts</a>
                </div>
           </li>
           <li class="nav-item ml-lg-3">
                <a class="nav-link  text-dark" href="./reportpanel" target="_blank" >
                  Reports
                </a>
           </li>
        </ul>
    <?php }?>
      <?php if(isset($_SESSION["infocms_admin_session"])){?>
        <div class="mr-2"> 
          <i class="fa fa-user"></i>  <?php echo  daytime()." ". $_SESSION['infocms_admin_session_username']; ?> | <a href="./adminlogout" class="link">Logout <i class="fa fa-arrow-right"></i>  </a> 
        </div>
      <?php }?>
    </div>
</nav>
  <?php echo drop_css();?>




