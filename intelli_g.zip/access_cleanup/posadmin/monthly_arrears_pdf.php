<?php
ob_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/client_base.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$due_date_title="";

if(isset($_GET["qdue_date"])){
$due_date_title=" due  ".base64_decode($_GET["qdue_date"]);

}

if(isset($_GET["start_date_input"])){
$due_date_title=" for date between  ".base64_decode($_GET["start_date_input"])." and ".base64_decode($_GET["end_date_input"]);

}

if(isset($_GET["monthly_arrears"])){
  
$due_date_title=" Clients with arrears for  ".date("M-Y", strtotime(base64_decode($_GET["monthly_arrears"])));

$month_year=date("M-Y", strtotime(base64_decode($_GET["monthly_arrears"])));
}

$filetitile=$due_date_title;


$buttonclr="#00008b";

$logohead2="./img/logo.png";

$image = imagecreatefrompng($logohead2);
$bg = imagecreatetruecolor(imagesx($image), imagesy($image));
imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
imagealphablending($bg, TRUE);
imagecopy($bg, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
imagedestroy($image);
$quality = 50; 
imagejpeg($bg, $logohead2.".jpg", $quality);
imagedestroy($bg);

$logohead3= $logohead2.".jpg";
$splithex = str_split(str_replace("#","",$buttonclr), 2);
$r = hexdec($splithex[0]);
$g = hexdec($splithex[1]);
$b = hexdec($splithex[2]);
$lineclr=$r . ", " . $g . ", " . $b;


$arrayclr = explode(',', $lineclr);



// Include the main TCPDF library (search for installation path).
require_once("./tcpdf/tcpdf.php");

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
 $pdf->setImageScale(1.53);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}
// ---------------------------------------------------------
// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', 'B', 12);

// add a page
$pdf->AddPage("L", "A4");
$style5 = array('width' => 0.25, 'color' => array($r,$g,$b));
$style4 = array('width' => 0.25, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array($r,$g,$b));

//print_r($splithex);
// Line
// Circle and ellipse
$pdf->SetLineStyle($style4);


// set alpha to semi-transparency
$pdf->SetAlpha(0.1);
//===================== params =====================================


$bus_name="Infolink POS";
$bus_email="";
$bus_tel="";
$sub_headers="Client Arrears List ";
//===================== params =====================================

//Start Graphic Transformation
// set bacground image
$pdf->SetAlpha(1);

$pdf->StartTransform();
$pdf->StarPolygon(150, 26, 9, 25, 3, 0, 1, 'CNZ');
$pdf->Image($logohead3, 140, 16, 20, 20, '','', '', false, 0, '', false, false, 0, false, false, false);

$pdf->StopTransform();

$pdf->Ln(10);
$pdf->Write(0, $bus_name, '', 0, 'C', 1, 0, false, false, 0);
$pdf->SetFont('helvetica', '', 10);
$pdf->Ln(3);
$pdf->Write(0, $sub_headers, '', 0, 'C', 1, 0, false, false, 0);
$pdf->Ln(10);


$pdf->SetFont('helvetica', 'b', 10);

$pdf->writeHTML('<div align="left">  '.$due_date_title.'<hr/></div>', true, false, false, false, 'C');

$pdf->SetFont('helvetica', '', 8);
$tbl='<table width="100%" border="1" cellpadding="2" cellspacing="0">';

$tbl.='
	    <thead class="text-uppercase">
		   <tr style="background-color:#3CA6EA; color:#FFF;">
		    <th   style="width:5%;">#</th>
 <th scope="col">Building</th>
 <th scope="col">Names</th>
 <th scope="col">Room</th>
 <th scope="col">Package</th>
 <th scope="col">Pkg price</th>
 <th scope="col">Start Date</th>
 <th scope="col">Active Months</th>
 <th scope="col">Inactive Months</th>
 <th scope="col">Total Due</th>
 <th scope="col">Total Paid</th>
 <th scope="col">Pkg Bal</th>
 <th scope="col">Other charges</th>
 <th scope="col">Charges paid</th>
 <th scope="col">Charges Balance</th>
 <th scope="col">Net Arrears</th>
 <th scope="col">Account Status</th>

		   </tr>
	    </thead>
	    <tbody>';
   
   		$pagination_record_count=$client_base_pgcount;
        $i=0;
		while($listclient_base_result=mysqli_fetch_array($client_base_list_query)){

          
          $act_start_date=$listclient_base_result['installation_date'];
          $act_end_date=date("Y-m-d");
          
          if(isset($_GET['end_date_input']))
          {
          $act_start_date=base64_decode($_GET['start_date_input']);
          $act_end_date=base64_decode($_GET['end_date_input']);
          }
          
          
          $tot_pkg_paid=cal_client_payments($act_start_date, $act_end_date,  $listclient_base_result["client_id"]);
		  $tot_inst_charges=cal_client_inst_arrears($act_start_date, $act_end_date, $listclient_base_result["client_id"])[0];
		  $tot_inst_charges_paid=cal_client_inst_arrears($act_start_date, $act_end_date, $listclient_base_result["client_id"])[1];
		  $cpackge_price=qpackage_data($listclient_base_result["package"])['price'];
          

          $active_months= calc_active_months($act_start_date, $act_end_date, $listclient_base_result["client_id"])[0];
                    $inactive_months= calc_active_months($act_start_date, $act_end_date, $listclient_base_result["client_id"])[1];


	      $tot_pkg_due=$active_months*$cpackge_price;
          $tot_pack_bal=$tot_pkg_due-$tot_pkg_paid;
          $inst_charge_bal=$tot_inst_charges-$tot_inst_charges_paid;
                     
          $netarrears=$inst_charge_bal+$tot_pack_bal;
          
          $amount_paid_f= compute_monthy_payment($listclient_base_result["client_id"], $month_year)[0];
          if($amount_paid_f=='skip'){
            $amount_paid_f=$cpackge_price;
          }
          
          $month_arrears=$cpackge_price-$amount_paid_f;
            
        if($month_arrears>0){
           $i++;

	    $tbl.='
        	    <tr>
	    	<td   style="width:5%;">'.$i.'</td>
 <td scope="col">'.$listclient_base_result["building_no"].'</td>
 <td scope="col">'.$listclient_base_result["client_name"].'</td>
 <td scope="col">'.$listclient_base_result["room_no"].'</td>
 <td scope="col">'.qpackage_data($listclient_base_result["package"])['package_name'].'</td>
  <td scope="col">'.$cpackge_price.'</td>
 <td scope="col">'.date("d/m/Y", strtotime($act_start_date)).'</td>
 <td scope="col">'.$active_months.'</td>
 <td scope="col">'.$inactive_months.'</td>
 <td scope="col">'.$tot_pkg_due.'</td>
 <td scope="col">'.$amount_paid_f.'</td>
 <td scope="col">'.$month_arrears.'</td>
 <td scope="col">'.$tot_inst_charges.'</td>
 <td scope="col">'.$tot_inst_charges_paid.'</td>
 <td scope="col">'.$inst_charge_bal.'</td>
 <td scope="col">'.$netarrears.'</td>
 <td scope="col">'.$listclient_base_result["account_status"].'</td>

	    </tr>';
	    }
        }
$tbl.='	</tbody>
	    </table>';

$pdf->writeHTML($tbl, true, false, false, false, 'C');


// ---------------------------------------------------------
//Close and output PDF document
$pdf->Output('infolinkpos_client_base_list.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+

?>