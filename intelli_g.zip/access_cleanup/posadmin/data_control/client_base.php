<?php 

		//== initialize edit token variables

		$client_base_uptoken="";

		if(isset($_GET["client_base_uptoken"]))
		{
		$client_base_uptoken=base64_decode($_GET["client_base_uptoken"]);
		}
$file_acc_state='Active';

$qstart_due_date=date("d");
$qend_due_date=date("d");

if(isset($_GET["qstart_due_date"])){
  
$qstart_due_date=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['qstart_due_date']));
$qend_due_date=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['qend_due_date']));


}
  
if(isset($_GET["cloneclient_base"])){

$conf_clone_client_base_btn=magic_button_link("./editclient_base.php?client_base_uptoken=".$_GET["client_base_uptoken"]."&conf_cloneclient_base", "Yes", 'style="margin-right:10px;"');

$cancel_clone_client_base_btn=magic_button_link("./editclient_base.php?client_base_uptoken=".$_GET["client_base_uptoken"], "No", "");

echo magic_screen("Clone this Record? The current record will be marked as Inactive<hr>".$conf_clone_client_base_btn." ".$cancel_clone_client_base_btn."");
}


//************* START INSERT QUERY 
if(isset($_POST["client_base_insert_btn"])){
//------- begin Create Update record from client_base --> 
$client_id=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$client_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_name"]);
$gender=mysqli_real_escape_string($mysqliconn, $_POST["txt_gender"]);
$client_tel=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_tel"]);
$client_email=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_email"]);
$city=mysqli_real_escape_string($mysqliconn, $_POST["txt_city"]);
$location=mysqli_real_escape_string($mysqliconn, $_POST["txt_location"]);
$building_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_building_no"]);
$floor_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_floor_no"]);
$room_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_room_no"]);
$package=mysqli_real_escape_string($mysqliconn, $_POST["txt_package"]);
$package_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_price"]);
$photo=mysqli_real_escape_string($mysqliconn, "");
$installation_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_installation_date"]);
$signed_by=mysqli_real_escape_string($mysqliconn, $_POST["txt_signed_by"]);
$comment=mysqli_real_escape_string($mysqliconn, $_POST["txt_comment"]);
$ip_address=mysqli_real_escape_string($mysqliconn, "");
$account_status=mysqli_real_escape_string($mysqliconn, $_POST["txt_account_status"]);
$admin_id=mysqli_real_escape_string($mysqliconn, "");
$instdate=mysqli_real_escape_string($mysqliconn, $_POST["txt_installation_date"]);
//===-- End Create Update record from client_base -->

$dupclient=magic_sql_count('client_base',"*", "building_no='$building_no' AND room_no='$room_no'");
  if($dupclient==0){
$client_base_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`client_base` (`primkey`,`client_id`,`client_name`,`gender`,`client_tel`,`client_email`,`city`,`location`,`building_no`,`floor_no`,`room_no`,`package`,`package_price`,`photo`,`installation_date`,`signed_by`,`comment`,`ip_address`,`account_status`,`admin_id`,`instdate`) 
 VALUES 
(NULL,'$client_id','$client_name','$gender','$client_tel','$client_email','$city','$location','$building_no','$floor_no','$room_no','$package','$package_price','$photo','$installation_date','$signed_by','$comment','$ip_address','$account_status','$admin_id','$instdate')");

 //--- get primary key id
$client_base_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?client_base_uptoken='.base64_encode($client_base_return_key).'&table_alert=Record added Succesfully');
  }else{
   echo magic_message('Duplicate client found, please try a different building and room');
  }
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["client_base_update_btn"])){
//------- begin Create Update record from client_base --> 
$client_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_name"]);
$gender=mysqli_real_escape_string($mysqliconn, $_POST["txt_gender"]);
$client_tel=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_tel"]);
$client_email=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_email"]);
$city=mysqli_real_escape_string($mysqliconn, $_POST["txt_city"]);
$location=mysqli_real_escape_string($mysqliconn, $_POST["txt_location"]);
$building_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_building_no"]);
$floor_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_floor_no"]);
$room_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_room_no"]);
$package=mysqli_real_escape_string($mysqliconn, $_POST["txt_package"]);
$package_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_price"]);
$installation_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_installation_date"]);
$signed_by=mysqli_real_escape_string($mysqliconn, $_POST["txt_signed_by"]);
$comment=mysqli_real_escape_string($mysqliconn, $_POST["txt_comment"]);
$ip_address=mysqli_real_escape_string($mysqliconn, "");
$account_status=mysqli_real_escape_string($mysqliconn, $_POST["txt_account_status"]);
$instdate=mysqli_real_escape_string($mysqliconn, $_POST["txt_installation_date"]);
//===-- End Create Update record from client_base -->

  $client_base_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`client_base` SET `client_name`='$client_name',`gender`='$gender',`client_tel`='$client_tel',`client_email`='$client_email',`city`='$city',`location`='$location', `floor_no`='$floor_no',`package`='$package',`package_price`='$package_price',`installation_date`='$installation_date',`signed_by`='$signed_by',`comment`='$comment',`ip_address`='$ip_address',`account_status`='$account_status',`instdate`='$instdate' WHERE primkey='$client_base_uptoken'");

  
$dupclient=magic_sql_count('client_base',"*", "building_no='$building_no' AND room_no='$room_no' AND primkey!='$client_base_uptoken'");
  if($dupclient==0){
    
$client_base_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`client_base` SET `building_no`='$building_no', `room_no`='$room_no' WHERE primkey='$client_base_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?client_base_uptoken='.base64_encode($client_base_uptoken).'&table_alert=Record Updated Succesfully');
  }else{
       echo magic_message('Duplicate client found, please try a different building and room');

  }

}
//************* END UPDATE QUERY 


//=== start client_base select Find client_base Records Profile query 

$find_client_base_records_profile_client_base_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base` WHERE `primkey`='$client_base_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$client_base_node=mysqli_fetch_array($find_client_base_records_profile_client_base_query);

//=== End client_base select Find client_base Records Profile  query



//************* START INSERT QUERY 
if(isset($_GET["conf_cloneclient_base"])){
//------- begin Create Update record from client_base --> 
$client_id=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$client_name=mysqli_real_escape_string($mysqliconn, $client_base_node["client_name"]);
$gender=mysqli_real_escape_string($mysqliconn, $client_base_node["gender"]);
$client_tel=mysqli_real_escape_string($mysqliconn, $client_base_node["client_tel"]);
$client_email=mysqli_real_escape_string($mysqliconn, $client_base_node["client_email"]);
$city=mysqli_real_escape_string($mysqliconn, $client_base_node["city"]);
$location=mysqli_real_escape_string($mysqliconn, $client_base_node["location"]);
$building_no=mysqli_real_escape_string($mysqliconn, $client_base_node["building_no"]);
$floor_no=mysqli_real_escape_string($mysqliconn, $client_base_node["floor_no"]);
$room_no=mysqli_real_escape_string($mysqliconn, $client_base_node["room_no"]);
$package=mysqli_real_escape_string($mysqliconn, $client_base_node["package"]);
$package_price=mysqli_real_escape_string($mysqliconn, $client_base_node["package_price"]);
$photo=mysqli_real_escape_string($mysqliconn, "");
$installation_date=mysqli_real_escape_string($mysqliconn, $client_base_node["installation_date"]);
$signed_by=mysqli_real_escape_string($mysqliconn, $client_base_node["signed_by"]);
$comment=mysqli_real_escape_string($mysqliconn, $client_base_node["comment"]);
$ip_address=mysqli_real_escape_string($mysqliconn, "");
$account_status=mysqli_real_escape_string($mysqliconn, "Inactive");
$admin_id=mysqli_real_escape_string($mysqliconn, "");
$instdate=mysqli_real_escape_string($mysqliconn, $client_base_node["installation_date"]);
//===-- End Create Update record from client_base -->

magic_sql_update('client_base', '{"room_no":"'.$room_no.'_Inactive_on_'.date('d_m_Y').'", "building_no":"'.$building_no.'_old_'.date('d_m_Y').'", "account_status":"Inactive"}', "primkey='$client_base_uptoken'");

 $client_base_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`client_base` (`primkey`,`client_id`,`client_name`,`gender`,`client_tel`,`client_email`,`city`,`location`,`building_no`,`floor_no`,`room_no`,`package`,`package_price`,`photo`,`installation_date`,`signed_by`,`comment`,`ip_address`,`account_status`,`admin_id`,`instdate`) 
 VALUES 
(NULL,'$client_id','$client_name','$gender','$client_tel','$client_email','$city','$location','$building_no','$floor_no','$room_no','$package','$package_price','$photo','$installation_date','$signed_by','$comment','$ip_address','$account_status','$admin_id','$instdate')");

 //--- get primary key id
$client_base_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?client_base_uptoken='.base64_encode($client_base_return_key).'&table_alert=Record Cloned Succesfully');
 
}
//************* END INSERT QUERY 


if(isset($_POST["qclient_base_btn"])){


$qclient_base_str=base64_encode($_POST["txt_client_base"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qclient_base='.($qclient_base_str).'');

}

if(isset($_GET["qclient_base"])){


$qclient_base=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qclient_base"]));



//===== limit record value

$client_base_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_base` WHERE (`primkey` LIKE '%".$qclient_base."%' OR  `client_id` LIKE '%".$qclient_base."%' OR  `client_name` LIKE '%".$qclient_base."%' OR  `gender` LIKE '%".$qclient_base."%' OR  `client_tel` LIKE '%".$qclient_base."%' OR  `client_email` LIKE '%".$qclient_base."%' OR  `city` LIKE '%".$qclient_base."%' OR  `location` LIKE '%".$qclient_base."%' OR  `building_no` LIKE '%".$qclient_base."%' OR  `floor_no` LIKE '%".$qclient_base."%' OR  `room_no` LIKE '%".$qclient_base."%' OR  `package` LIKE '%".$qclient_base."%' OR  `package_price` LIKE '%".$qclient_base."%' OR  `photo` LIKE '%".$qclient_base."%' OR  `installation_date` LIKE '%".$qclient_base."%' OR  `signed_by` LIKE '%".$qclient_base."%' OR  `comment` LIKE '%".$qclient_base."%' OR  `ip_address` LIKE '%".$qclient_base."%') AND  (account_status ='$file_acc_state'  OR account_status ='')";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE (`primkey` LIKE '%".$qclient_base."%' OR  `client_id` LIKE '%".$qclient_base."%' OR  `client_name` LIKE '%".$qclient_base."%' OR  `gender` LIKE '%".$qclient_base."%' OR  `client_tel` LIKE '%".$qclient_base."%' OR  `client_email` LIKE '%".$qclient_base."%' OR  `city` LIKE '%".$qclient_base."%' OR  `location` LIKE '%".$qclient_base."%' OR  `building_no` LIKE '%".$qclient_base."%' OR  `floor_no` LIKE '%".$qclient_base."%' OR  `room_no` LIKE '%".$qclient_base."%' OR  `package` LIKE '%".$qclient_base."%' OR  `package_price` LIKE '%".$qclient_base."%' OR  `photo` LIKE '%".$qclient_base."%' OR  `installation_date` LIKE '%".$qclient_base."%' OR  `signed_by` LIKE '%".$qclient_base."%' OR  `comment` LIKE '%".$qclient_base."%' OR  `ip_address` LIKE '%".$qclient_base."%' OR  `account_status` LIKE '%".$qclient_base."%' OR  `admin_id` LIKE '%".$qclient_base."%' OR  `instdate` LIKE '%".$qclient_base."%')  AND (account_status ='$file_acc_state'  OR account_status ='') ORDER BY `installation_date` DESC LIMIT $client_base_firstproduct, $datalimit" );



//=== End client_base select  Like Query String client_base list
;

}elseif(isset($_GET["qstate"])){

$qstate=mysqli_real_escape_string($mysqliconn, $_GET["qstate"]);

//===== limit record value

$client_base_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_base` WHERE (account_status ='$qstate') ";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE (account_status ='$qstate') ORDER BY `installation_date` DESC LIMIT $client_base_firstproduct, $datalimit" );

//$client_base_list_res=mysqli_fetch_array($client_base_list_query);

//=== End client_base select  Like Query String client_base list

}elseif(isset($_GET["qstart_due_date"])){


//===== limit record value

$client_base_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_base` WHERE DAY(installation_date) between '$qstart_due_date' AND '$qend_due_date'  AND (account_status ='$file_acc_state'  OR account_status ='')";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE  DAY(installation_date) between '$qstart_due_date' AND '$qend_due_date'  AND  (account_status ='$file_acc_state'  OR account_status ='') ORDER BY `installation_date` DESC  LIMIT $client_base_firstproduct, $datalimit" ) or die(mysqli_error($mysqliconn));

//$client_base_list_res=mysqli_fetch_array($client_base_list_query);

//=== End client_base select  Like Query String client_base list

}elseif(isset($_GET["qstart_inst_date"])){

$qstart_inst_date=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['qstart_inst_date']));

$qend_inst_date=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['qend_inst_date']));
  
//===== limit record value

$client_base_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_base` WHERE (installation_date) between '$qstart_inst_date' AND '$qend_inst_date'  AND  (account_status ='$file_acc_state'  OR account_status ='')";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE   (installation_date) between '$qstart_inst_date' AND '$qend_inst_date'  AND  (account_status ='$file_acc_state'  OR account_status ='') ORDER BY `installation_date` DESC  LIMIT $client_base_firstproduct, $datalimit" ) or die(mysqli_error($mysqliconn));

//$client_base_list_res=mysqli_fetch_array($client_base_list_query);

//=== End client_base select  Like Query String client_base list

}elseif(isset($_GET["qclient_id"])){

$qclient_id=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['qclient_id']));
  
//===== limit record value

$client_base_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_base` WHERE client_id='$qclient_id'";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE client_id='$qclient_id' ORDER BY `installation_date` DESC  LIMIT $client_base_firstproduct, $datalimit" ) or die(mysqli_error($mysqliconn));

//$client_base_list_res=mysqli_fetch_array($client_base_list_query);

//=== End client_base select  Like Query String client_base list

}else{

//===== limit record value

$client_base_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_base`  WHERE (account_status ='$file_acc_state'  OR account_status ='')";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE  (account_status ='$file_acc_state'  OR account_status ='') ORDER BY `installation_date` DESC LIMIT $client_base_firstproduct, $datalimit" );

//$client_base_list_res=mysqli_fetch_array($client_base_list_query);

//=== End client_base select  Like Query String client_base list


}


//== Start  **** Delete client_base Records  

if(isset($_GET["deleteclient_base"]))
{

//======confirm pop up 

$conf_del_client_base_btn=magic_button_link("./editclient_base.php?client_base_uptoken=".$_GET["client_base_uptoken"]."&conf_deleteclient_base", "Yes", 'style="margin-right:10px;"');

$cancel_del_client_base_btn=magic_button_link("./editclient_base.php?client_base_uptoken=".$_GET["client_base_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_client_base_btn." ".$cancel_del_client_base_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteclient_base"]))
{

  $del_client_id=$client_base_node['client_id'];
  
mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`client_base` WHERE `primkey`='$client_base_uptoken'");
mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`active_client_months` WHERE `client_id`='$del_client_id'");

//==add your redirect here 

header("location:./client_base.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete client_base Records 

?>