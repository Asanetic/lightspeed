<?php 

		//== initialize edit token variables

		$team_uptoken="";

		if(isset($_GET["team_uptoken"]))
		{
		$team_uptoken=base64_decode($_GET["team_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["team_insert_btn"])){
//------- begin Create Update record from team --> 
$user_id=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$names=mysqli_real_escape_string($mysqliconn, $_POST["txt_names"]);
$username=mysqli_real_escape_string($mysqliconn, $_POST["txt_username"]);
$password=mysqli_real_escape_string($mysqliconn, $_POST["txt_password"]);
$role=mysqli_real_escape_string($mysqliconn, $_POST["txt_role"]);
$last_seen=mysqli_real_escape_string($mysqliconn, "");
$photo=mysqli_real_escape_string($mysqliconn, "");
$telephone=mysqli_real_escape_string($mysqliconn, $_POST["txt_telephone"]);
$admin_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_admin_id"]);
//===-- End Create Update record from team -->


$team_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`team` (`primkey`,`user_id`,`names`,`username`,`password`,`role`,`last_seen`,`photo`,`telephone`,`admin_id`) 
 VALUES 
(NULL,'$user_id','$names','$username','$password','$role','$last_seen','$photo','$telephone','$admin_id')");

 //--- get primary key id
$team_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?team_uptoken='.base64_encode($team_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["team_update_btn"])){
//------- begin Create Update record from team --> 
$names=mysqli_real_escape_string($mysqliconn, $_POST["txt_names"]);
$username=mysqli_real_escape_string($mysqliconn, $_POST["txt_username"]);
$password=mysqli_real_escape_string($mysqliconn, $_POST["txt_password"]);
$role=mysqli_real_escape_string($mysqliconn, $_POST["txt_role"]);
$telephone=mysqli_real_escape_string($mysqliconn, $_POST["txt_telephone"]);
//===-- End Create Update record from team -->


$team_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`team` SET `names`='$names',`username`='$username',`password`='$password',`role`='$role',`last_seen`='$last_seen',`photo`='$photo',`telephone`='$telephone',`admin_id`='$admin_id' WHERE primkey='$team_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?team_uptoken='.base64_encode($team_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start team select Find team Records Profile query 

$find_team_records_profile_team_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`team` WHERE `primkey`='$team_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$team_node=mysqli_fetch_array($find_team_records_profile_team_query);

//=== End team select Find team Records Profile  query




if(isset($_POST["qteam_btn"])){


$qteam_str=base64_encode($_POST["txt_team"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qteam='.($qteam_str).'');

}

if(isset($_GET["qteam"])){


$qteam=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qteam"]));



//===== limit record value

$team_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`team` WHERE (`primkey` LIKE '%".$qteam."%' OR  `user_id` LIKE '%".$qteam."%' OR  `names` LIKE '%".$qteam."%' OR  `username` LIKE '%".$qteam."%' OR  `password` LIKE '%".$qteam."%' OR  `role` LIKE '%".$qteam."%' OR  `last_seen` LIKE '%".$qteam."%' OR  `photo` LIKE '%".$qteam."%' OR  `telephone` LIKE '%".$qteam."%' OR  `admin_id` LIKE '%".$qteam."%')";

//===== Pagination function

$team_pagination= list_record_per_page($mysqliconn, $team_sqlstring, $datalimit);


//===== get return values


$team_firstproduct=$team_pagination["0"];

$team_pgcount=$team_pagination["1"];

//=== start team select  Like Query String team list  

$team_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`team`  WHERE (`primkey` LIKE '%".$qteam."%' OR  `user_id` LIKE '%".$qteam."%' OR  `names` LIKE '%".$qteam."%' OR  `username` LIKE '%".$qteam."%' OR  `password` LIKE '%".$qteam."%' OR  `role` LIKE '%".$qteam."%' OR  `last_seen` LIKE '%".$qteam."%' OR  `photo` LIKE '%".$qteam."%' OR  `telephone` LIKE '%".$qteam."%' OR  `admin_id` LIKE '%".$qteam."%') ORDER BY `primkey` DESC LIMIT $team_firstproduct, $datalimit" );



//=== End team select  Like Query String team list
;

}else{

//===== limit record value

$team_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`team`";

//===== Pagination function

$team_pagination= list_record_per_page($mysqliconn, $team_sqlstring, $datalimit);


//===== get return values


$team_firstproduct=$team_pagination["0"];

$team_pgcount=$team_pagination["1"];

//=== start team select  Like Query String team list  

$team_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`team`  ORDER BY `primkey` DESC LIMIT $team_firstproduct, $datalimit" );

//$team_list_res=mysqli_fetch_array($team_list_query);

//=== End team select  Like Query String team list

}


//== Start  **** Delete team Records  

if(isset($_GET["deleteteam"]))
{

//======confirm pop up 

$conf_del_team_btn=magic_button_link("./editteam.php?team_uptoken=".$_GET["team_uptoken"]."&conf_deleteteam", "Yes", 'style="margin-right:10px;"');

$cancel_del_team_btn=magic_button_link("./editteam.php?team_uptoken=".$_GET["team_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_team_btn." ".$cancel_del_team_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteteam"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`team` WHERE `primkey`='$team_uptoken'");

//==add your redirect here 

header("location:./team.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete team Records 



//=== start team select Find team Records Profile query 

$find_team_records_profile_team_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`team` WHERE `primkey`='$team_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$team_node=mysqli_fetch_array($find_team_records_profile_team_query);

//=== End team select Find team Records Profile  query




if(isset($_POST["qteam_btn"])){


$qteam_str=base64_encode($_POST["txt_team"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qteam='.($qteam_str).'');

}

if(isset($_GET["qteam"])){


$qteam=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qteam"]));



//===== limit record value

$team_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`team` WHERE (`primkey` LIKE '%".$qteam."%' OR  `user_id` LIKE '%".$qteam."%' OR  `names` LIKE '%".$qteam."%' OR  `username` LIKE '%".$qteam."%' OR  `password` LIKE '%".$qteam."%' OR  `role` LIKE '%".$qteam."%' OR  `last_seen` LIKE '%".$qteam."%' OR  `photo` LIKE '%".$qteam."%' OR  `telephone` LIKE '%".$qteam."%' OR  `admin_id` LIKE '%".$qteam."%')";

//===== Pagination function

$team_pagination= list_record_per_page($mysqliconn, $team_sqlstring, $datalimit);


//===== get return values


$team_firstproduct=$team_pagination["0"];

$team_pgcount=$team_pagination["1"];

//=== start team select  Like Query String team list  

$team_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`team`  WHERE (`primkey` LIKE '%".$qteam."%' OR  `user_id` LIKE '%".$qteam."%' OR  `names` LIKE '%".$qteam."%' OR  `username` LIKE '%".$qteam."%' OR  `password` LIKE '%".$qteam."%' OR  `role` LIKE '%".$qteam."%' OR  `last_seen` LIKE '%".$qteam."%' OR  `photo` LIKE '%".$qteam."%' OR  `telephone` LIKE '%".$qteam."%' OR  `admin_id` LIKE '%".$qteam."%') ORDER BY `primkey` DESC LIMIT $team_firstproduct, $datalimit" );



//=== End team select  Like Query String team list
;

}else{

//===== limit record value

$team_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`team`";

//===== Pagination function

$team_pagination= list_record_per_page($mysqliconn, $team_sqlstring, $datalimit);


//===== get return values


$team_firstproduct=$team_pagination["0"];

$team_pgcount=$team_pagination["1"];

//=== start team select  Like Query String team list  

$team_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`team`  ORDER BY `primkey` DESC LIMIT $team_firstproduct, $datalimit" );

//$team_list_res=mysqli_fetch_array($team_list_query);

//=== End team select  Like Query String team list

}


//== Start  **** Delete team Records  

if(isset($_GET["deleteteam"]))
{

//======confirm pop up 

$conf_del_team_btn=magic_button_link("./editteam.php?team_uptoken=".$_GET["team_uptoken"]."&conf_deleteteam", "Yes", 'style="margin-right:10px;"');

$cancel_del_team_btn=magic_button_link("./editteam.php?team_uptoken=".$_GET["team_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_team_btn." ".$cancel_del_team_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteteam"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`team` WHERE `primkey`='$team_uptoken'");

//==add your redirect here 

header("location:./team.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete team Records 

//--<{ncgh}/>
?>