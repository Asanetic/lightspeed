<?php 

		//== initialize edit token variables

		$client_charges_uptoken="";

		if(isset($_GET["client_charges_uptoken"]))
		{
		$client_charges_uptoken=base64_decode($_GET["client_charges_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["client_charges_insert_btn"])){
//------- begin Create Update record from client_charges --> 
$charge_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_charge_id"]);
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$package_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_id"]);
$trx_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_trx_id"]);
$amount=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount"]);
$balance=mysqli_real_escape_string($mysqliconn, $_POST["txt_balance"]);
$remark=mysqli_real_escape_string($mysqliconn, $_POST["txt_remark"]);
$qty=mysqli_real_escape_string($mysqliconn, $_POST["txt_qty"]);
//===-- End Create Update record from client_charges -->


$client_charges_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`client_charges` (`primkey`,`charge_id`,`client_id`,`package_id`,`trx_id`,`amount`,`balance`,`remark`,`qty`) 
 VALUES 
(NULL,'$charge_id','$client_id','$package_id','$trx_id','$amount','$balance','$remark','$qty')");

 //--- get primary key id
$client_charges_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?client_charges_uptoken='.base64_encode($client_charges_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["client_charges_update_btn"])){
//------- begin Create Update record from client_charges --> 
$charge_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_charge_id"]);
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$package_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_id"]);
$trx_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_trx_id"]);
$amount=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount"]);
$balance=mysqli_real_escape_string($mysqliconn, $_POST["txt_balance"]);
$remark=mysqli_real_escape_string($mysqliconn, $_POST["txt_remark"]);
$qty=mysqli_real_escape_string($mysqliconn, $_POST["txt_qty"]);
//===-- End Create Update record from client_charges -->


$client_charges_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`client_charges` SET `primkey`='$primkey',`charge_id`='$charge_id',`client_id`='$client_id',`package_id`='$package_id',`trx_id`='$trx_id',`amount`='$amount',`balance`='$balance',`remark`='$remark',`qty`='$qty' WHERE primkey='$client_charges_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?client_charges_uptoken='.base64_encode($client_charges_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start client_charges select Find client_charges Records Profile query 

$find_client_charges_records_profile_client_charges_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_charges` WHERE `primkey`='$client_charges_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$client_charges_node=mysqli_fetch_array($find_client_charges_records_profile_client_charges_query);

//=== End client_charges select Find client_charges Records Profile  query




if(isset($_POST["qclient_charges_btn"])){


$qclient_charges_str=base64_encode($_POST["txt_client_charges"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qclient_charges='.($qclient_charges_str).'');

}

if(isset($_GET["qclient_charges"])){


$qclient_charges=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qclient_charges"]));



//===== limit record value

$client_charges_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_charges` WHERE (`primkey` LIKE '%".$qclient_charges."%' OR  `charge_id` LIKE '%".$qclient_charges."%' OR  `client_id` LIKE '%".$qclient_charges."%' OR  `package_id` LIKE '%".$qclient_charges."%' OR  `trx_id` LIKE '%".$qclient_charges."%' OR  `amount` LIKE '%".$qclient_charges."%' OR  `balance` LIKE '%".$qclient_charges."%' OR  `remark` LIKE '%".$qclient_charges."%' OR  `qty` LIKE '%".$qclient_charges."%')";

//===== Pagination function

$client_charges_pagination= list_record_per_page($mysqliconn, $client_charges_sqlstring, $datalimit);


//===== get return values


$client_charges_firstproduct=$client_charges_pagination["0"];

$client_charges_pgcount=$client_charges_pagination["1"];

//=== start client_charges select  Like Query String client_charges list  

$client_charges_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_charges`  WHERE (`primkey` LIKE '%".$qclient_charges."%' OR  `charge_id` LIKE '%".$qclient_charges."%' OR  `client_id` LIKE '%".$qclient_charges."%' OR  `package_id` LIKE '%".$qclient_charges."%' OR  `trx_id` LIKE '%".$qclient_charges."%' OR  `amount` LIKE '%".$qclient_charges."%' OR  `balance` LIKE '%".$qclient_charges."%' OR  `remark` LIKE '%".$qclient_charges."%' OR  `qty` LIKE '%".$qclient_charges."%') ORDER BY `primkey` DESC LIMIT $client_charges_firstproduct, $datalimit" );



//=== End client_charges select  Like Query String client_charges list
;

}elseif(isset($_GET['qitem_id'])){

$qitem_id=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qitem_id"]));

//===== limit record value

$client_charges_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_charges` WHERE charge_id='$qitem_id'";

//===== Pagination function

$client_charges_pagination= list_record_per_page($mysqliconn, $client_charges_sqlstring, $datalimit);


//===== get return values


$client_charges_firstproduct=$client_charges_pagination["0"];

$client_charges_pgcount=$client_charges_pagination["1"];

//=== start client_charges select  Like Query String client_charges list  

$client_charges_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_charges` WHERE charge_id='$qitem_id' ORDER BY `primkey` DESC LIMIT $client_charges_firstproduct, $datalimit" );

//$client_charges_list_res=mysqli_fetch_array($client_charges_list_query);

//=== End client_charges select  Like Query String client_charges list

}else{

//===== limit record value

$client_charges_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`client_charges`";

//===== Pagination function

$client_charges_pagination= list_record_per_page($mysqliconn, $client_charges_sqlstring, $datalimit);


//===== get return values


$client_charges_firstproduct=$client_charges_pagination["0"];

$client_charges_pgcount=$client_charges_pagination["1"];

//=== start client_charges select  Like Query String client_charges list  

$client_charges_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_charges`  ORDER BY `primkey` DESC LIMIT $client_charges_firstproduct, $datalimit" );

//$client_charges_list_res=mysqli_fetch_array($client_charges_list_query);

//=== End client_charges select  Like Query String client_charges list

}


//== Start  **** Delete client_charges Records  

if(isset($_GET["deleteclient_charges"]))
{

//======confirm pop up 

$conf_del_client_charges_btn=magic_button_link("./editclient_charges.php?client_charges_uptoken=".$_GET["client_charges_uptoken"]."&conf_deleteclient_charges", "Yes", 'style="margin-right:10px;"');

$cancel_del_client_charges_btn=magic_button_link("./editclient_charges.php?client_charges_uptoken=".$_GET["client_charges_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_client_charges_btn." ".$cancel_del_client_charges_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteclient_charges"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`client_charges` WHERE `primkey`='$client_charges_uptoken'");

//==add your redirect here 

header("location:./client_charges.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete client_charges Records 

//--<{ncgh}/>
?>