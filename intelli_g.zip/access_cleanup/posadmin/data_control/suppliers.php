<?php 

		//== initialize edit token variables

		$suppliers_uptoken="";

		if(isset($_GET["suppliers_uptoken"]))
		{
		$suppliers_uptoken=base64_decode($_GET["suppliers_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["suppliers_insert_btn"])){
//------- begin Create Update record from suppliers --> 
$supp_id=mysqli_real_escape_string($mysqliconn, "INFSUP/".magic_random_str(7));
$contact_person=mysqli_real_escape_string($mysqliconn, $_POST["txt_contact_person"]);
$supplier_tel=mysqli_real_escape_string($mysqliconn, $_POST["txt_supplier_tel"]);
$supplier_ocation=mysqli_real_escape_string($mysqliconn, $_POST["txt_supplier_ocation"]);
$business_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_business_name"]);
$speciality=mysqli_real_escape_string($mysqliconn, $_POST["txt_speciality"]);
$comment=mysqli_real_escape_string($mysqliconn, $_POST["txt_comment"]);
//===-- End Create Update record from suppliers -->


$suppliers_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`suppliers` (`primkey`,`supp_id`,`contact_person`,`supplier_tel`,`supplier_ocation`,`business_name`,`speciality`,`comment`) 
 VALUES 
(NULL,'$supp_id','$contact_person','$supplier_tel','$supplier_ocation','$business_name','$speciality','$comment')");

 //--- get primary key id
$suppliers_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?suppliers_uptoken='.base64_encode($suppliers_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["suppliers_update_btn"])){
//------- begin Create Update record from suppliers --> 

  $contact_person=mysqli_real_escape_string($mysqliconn, $_POST["txt_contact_person"]);
$supplier_tel=mysqli_real_escape_string($mysqliconn, $_POST["txt_supplier_tel"]);
$supplier_ocation=mysqli_real_escape_string($mysqliconn, $_POST["txt_supplier_ocation"]);
$business_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_business_name"]);
$speciality=mysqli_real_escape_string($mysqliconn, $_POST["txt_speciality"]);
$comment=mysqli_real_escape_string($mysqliconn, $_POST["txt_comment"]);
//===-- End Create Update record from suppliers -->


$suppliers_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`suppliers` SET `contact_person`='$contact_person',`supplier_tel`='$supplier_tel',`supplier_ocation`='$supplier_ocation',`business_name`='$business_name',`speciality`='$speciality',`comment`='$comment' WHERE primkey='$suppliers_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?suppliers_uptoken='.base64_encode($suppliers_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start suppliers select Find suppliers Records Profile query 

$find_suppliers_records_profile_suppliers_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`suppliers` WHERE `primkey`='$suppliers_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$suppliers_node=mysqli_fetch_array($find_suppliers_records_profile_suppliers_query);

//=== End suppliers select Find suppliers Records Profile  query




if(isset($_POST["qsuppliers_btn"])){


$qsuppliers_str=base64_encode($_POST["txt_suppliers"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qsuppliers='.($qsuppliers_str).'');

}

if(isset($_GET["qsuppliers"])){


$qsuppliers=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qsuppliers"]));



//===== limit record value

$suppliers_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`suppliers` WHERE (`primkey` LIKE '%".$qsuppliers."%' OR  `supp_id` LIKE '%".$qsuppliers."%' OR  `contact_person` LIKE '%".$qsuppliers."%' OR  `supplier_tel` LIKE '%".$qsuppliers."%' OR  `supplier_ocation` LIKE '%".$qsuppliers."%' OR  `business_name` LIKE '%".$qsuppliers."%' OR  `speciality` LIKE '%".$qsuppliers."%' OR  `comment` LIKE '%".$qsuppliers."%')";

//===== Pagination function

$suppliers_pagination= list_record_per_page($mysqliconn, $suppliers_sqlstring, $datalimit);


//===== get return values


$suppliers_firstproduct=$suppliers_pagination["0"];

$suppliers_pgcount=$suppliers_pagination["1"];

//=== start suppliers select  Like Query String suppliers list  

$suppliers_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`suppliers`  WHERE (`primkey` LIKE '%".$qsuppliers."%' OR  `supp_id` LIKE '%".$qsuppliers."%' OR  `contact_person` LIKE '%".$qsuppliers."%' OR  `supplier_tel` LIKE '%".$qsuppliers."%' OR  `supplier_ocation` LIKE '%".$qsuppliers."%' OR  `business_name` LIKE '%".$qsuppliers."%' OR  `speciality` LIKE '%".$qsuppliers."%' OR  `comment` LIKE '%".$qsuppliers."%') ORDER BY `primkey` DESC LIMIT $suppliers_firstproduct, $datalimit" );



//=== End suppliers select  Like Query String suppliers list
;

}else{

//===== limit record value

$suppliers_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`suppliers`";

//===== Pagination function

$suppliers_pagination= list_record_per_page($mysqliconn, $suppliers_sqlstring, $datalimit);


//===== get return values


$suppliers_firstproduct=$suppliers_pagination["0"];

$suppliers_pgcount=$suppliers_pagination["1"];

//=== start suppliers select  Like Query String suppliers list  

$suppliers_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`suppliers`  ORDER BY `primkey` DESC LIMIT $suppliers_firstproduct, $datalimit" );

//$suppliers_list_res=mysqli_fetch_array($suppliers_list_query);

//=== End suppliers select  Like Query String suppliers list

}


//== Start  **** Delete suppliers Records  

if(isset($_GET["deletesuppliers"]))
{

//======confirm pop up 

$conf_del_suppliers_btn=magic_button_link("./editsuppliers.php?suppliers_uptoken=".$_GET["suppliers_uptoken"]."&conf_deletesuppliers", "Yes", 'style="margin-right:10px;"');

$cancel_del_suppliers_btn=magic_button_link("./editsuppliers.php?suppliers_uptoken=".$_GET["suppliers_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_suppliers_btn." ".$cancel_del_suppliers_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deletesuppliers"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`suppliers` WHERE `primkey`='$suppliers_uptoken'");

//==add your redirect here 

header("location:./suppliers.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete suppliers Records 

//--<{ncgh}/>
?>