<?php 
ob_start();

include('./conn.php');
include('./phpmagicbits.php');
include('./datafeed.php');

if(isset($_POST["compute_monthy_payment"])){

 echo json_encode(compute_monthy_payment($_POST['client_id'], $_POST['month_year']), JSON_FORCE_OBJECT);


}

if(isset($_POST["get_month_balances"])){

 echo json_encode(get_month_balances($_POST['client_id'], $_POST['month_year']), JSON_FORCE_OBJECT);
}

  if(isset($_POST["get_month_arrears"])){

		echo get_month_arrears($_POST['client_id'], $_POST['month_year']);
  
    }


if(isset($_POST["qsuppliers_list"])){

$qsuppliers=mysqli_real_escape_string($mysqliconn, ($_POST["qstr"])); 

$suppliers_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`suppliers`  WHERE (`primkey` LIKE '%".$qsuppliers."%' OR  `supp_id` LIKE '%".$qsuppliers."%' OR  `contact_person` LIKE '%".$qsuppliers."%' OR  `supplier_tel` LIKE '%".$qsuppliers."%' OR  `supplier_ocation` LIKE '%".$qsuppliers."%' OR  `business_name` LIKE '%".$qsuppliers."%' OR  `speciality` LIKE '%".$qsuppliers."%' OR  `comment` LIKE '%".$qsuppliers."%') ORDER BY `primkey` desc LIMIT 5" );

//=== End suppliers select  Like Query String suppliers list
$card_str="";
  
while($suppliers_list_res=mysqli_fetch_array($suppliers_list_query)){

	$card_str.='<div class="row col-md-12 p-3 text-left">  <span class="cpointer mr-2 badge badge-success" onclick="select_supplier(\''.$suppliers_list_res['supp_id'].'\', \''.$suppliers_list_res['business_name'].'\')"><i class="fa fa-check"></i> Select</span> '.$suppliers_list_res['business_name'].'</div>';
  
}
  
  echo $card_str;
}

//--<{ncgh}/>

if(isset($_POST["change_trx_state"])){

  $statevalue=mysqli_real_escape_string($mysqliconn, ($_POST["statevalue"]));
  $statekey=mysqli_real_escape_string($mysqliconn, ($_POST["statekey"]));

  magic_sql_update('transactions', '{"status":"'.$statevalue.'", "confirmed_by":"'.$_SESSION['infocms_admin_session_admin_id'].'"}', "primkey='$statekey'");
  
  echo "Status Updated";
}


if(isset($_POST["qpackages"]))
{
  
$qpackages=mysqli_real_escape_string($mysqliconn, ($_POST["qstr"]));


//=== start packages select  Like Query String packages list  

$packages_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`packages`  WHERE (`primkey` LIKE '%".$qpackages."%' OR  `package_id` LIKE '%".$qpackages."%' OR  `package_name` LIKE '%".$qpackages."%' OR  `price` LIKE '%".$qpackages."%' OR  `description` LIKE '%".$qpackages."%' OR  `admin_id` LIKE '%".$qpackages."%') ORDER BY `primkey` desc LIMIT 100" );

$pack_str="";
  
while($packages_list_res=mysqli_fetch_array($packages_list_query)){

	$pack_str.='<div class="row col-md-12 p-3 text-left">  <span class="cpointer mr-2 badge badge-success" onclick="pop_package_id(\''.$packages_list_res['package_id'].'\', \''.$packages_list_res['package_name'].'\', \''.$packages_list_res['price'].'\')"><i class="fa fa-"></i> Select</span> '.$packages_list_res['package_name'].' @ '.$packages_list_res['price'].' 
</div>';
  
}	

echo $pack_str;
  
}


if(isset($_POST["qclient_list"])){


$qclient_base=mysqli_real_escape_string($mysqliconn, $_POST["qstr"]);
$context="";
if(isset($_POST["context"])){
$context=mysqli_real_escape_string($mysqliconn, $_POST["context"]);

}


//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`client_base`  WHERE (`client_name` LIKE '%".$qclient_base."%' OR  `client_tel` LIKE '%".$qclient_base."%' OR  `client_email` LIKE '%".$qclient_base."%' OR `building_no` LIKE '%".$qclient_base."%' OR  `floor_no` LIKE '%".$qclient_base."%' OR  `room_no` LIKE '%".$qclient_base."%' OR  `package` LIKE '%".$qclient_base."%' OR  `package_price` LIKE '%".$qclient_base."%'  OR  `installation_date` LIKE '%".$qclient_base."%' OR  `account_status` LIKE '%".$qclient_base."%') AND account_status!='Inactive' ORDER BY `primkey` desc LIMIT 6" );

$newcotext='./edittransactions.php?client_id';
  if($context=='report_panel_pdf'){
$newcotext='./trx_pdf.php?qclient_id';
}
  if($context=='report_panel_xls'){
$newcotext='./trx_xls.php?qclient_id';
}  
    if($context=='trx_client'){
$newcotext='./transactions.php?qclient_id';
}

//=== End client_base select  Like Query String client_base list
$client_card_str="Top Results for `".$qclient_base."`<hr>";
  
while($client_list_res=mysqli_fetch_array($client_base_list_query)){

	$client_card_str.='<div class="col-md-12 border border-primary pb-2 mb-2 text-left"><b>Name : </b> '.$client_list_res['client_name'].' <br> <b>Room : </b> '.$client_list_res['room_no'].'  <br> <b>Bld : </b>  '.$client_list_res['building_no'].'  <br> <b>Package : </b>  '.qpackage_data($client_list_res['package'])['package_name'].'   <br> <a href="'.$newcotext.'='.base64_encode($client_list_res['client_id']).'" class="cpointer ml-2 badge badge-success p-1 mt-2" ><i class="fa fa-check"></i> Select</a> 
</div>';
  
}	

echo $client_card_str;

}


if(isset($_POST["qinventory_list"])){

$qinventory=mysqli_real_escape_string($mysqliconn, $_POST["qstr"]);

//=== start inventory select  Like Query String inventory list  

$inventory_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`inventory`  WHERE (`item_id` LIKE '%".$qinventory."%' OR  `item_name` LIKE '%".$qinventory."%' OR  `buying_price` LIKE '%".$qinventory."%' OR  `description` LIKE '%".$qinventory."%' OR  `selling_price` LIKE '%".$qinventory."%') ORDER BY `primkey` desc LIMIT 6" );

$pack_str="";
  
while($inventory_list_res=mysqli_fetch_array($inventory_list_query)){

	$pack_str.='<div class="row col-md-12 p-3 text-left">  <span class="cpointer mr-2 badge badge-success" onclick="add_from_inventory(\''.$inventory_list_res['item_id'].'\', \''.magic_clean_str($inventory_list_res['item_name']).'\', \''.$inventory_list_res['selling_price'].'\')"><i class="fa fa-"></i> Select </span> '.$inventory_list_res['item_name'].' @ '.$inventory_list_res['selling_price'].' 
</div>';
  
}	

echo $pack_str;

//=== End inventory select  Like Query String inventory list
;

}

//************* START INSERT QUERY 
if(isset($_POST["add_charge_tbl_item"])){
//------- begin Create Update record from client_charges --> 
$charge_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_charge_id"]);
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$package_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_id"]);
$trx_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_trx_id"]);
$amount=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount"]);
$balance=mysqli_real_escape_string($mysqliconn, $_POST["txt_balance"]);
$remark=mysqli_real_escape_string($mysqliconn, date('Y-m-d h:i:s A'));
$qty=mysqli_real_escape_string($mysqliconn, $_POST["txt_qty"]);
//===-- End Create Update record from client_charges -->


$client_charges_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`client_charges` (`primkey`,`charge_id`,`client_id`,`package_id`,`trx_id`,`amount`,`balance`,`remark`, `qty`) 
 VALUES 
(NULL,'$charge_id','$client_id','$package_id','$trx_id','$amount','$balance','$remark', '$qty')");

  echo $qty;
}
if(isset($_POST["loop_charge_items"])){

  
  $trx_id=$_POST['trx_id'];
  
  $loop_rowe='';
  $row_tots=0;
  
        $i=0;
		$client_charges_list_query=magic_sql_select('client_charges',  "trx_id='$trx_id'", "1000", "primkey", "desc");
		while($listclient_charges_result=mysqli_fetch_array($client_charges_list_query[0])){
	        $i++;

	      $curr_item_name=qinventory_data($listclient_charges_result["charge_id"])['item_name'];
          
          $item_tots=($listclient_charges_result["amount"]*$listclient_charges_result["qty"]);
          
          $row_tots=$row_tots+$item_tots;
          
          if($curr_item_name==''){
            
           $curr_item_name=$listclient_charges_result["charge_id"];

          }
             
	    $loop_rowe.='<tr>
	    	<td scope="col">'.$i.' <i class="fa fa-trash text-danger" onclick="delete_charge(\''.$listclient_charges_result["primkey"].'\')"></i> </td>
 <td scope="col">'.$curr_item_name.'</td>
 <td scope="col">'.$listclient_charges_result["amount"].'</td>
 <td scope="col">'.$listclient_charges_result["qty"].'</td>
 <td scope="col">'.$item_tots.'</td>

	    </tr>';
         
              
          }
 	    $loop_rowe.='<tr class="bg-light font-weight-bold">
	    	<td scope="col"> </td>
 <td scope="col"></td>
 <td scope="col"></td>
 <td scope="col">Totals</td>
 <td scope="col"><span id="tot_items_charge">'.$row_tots.'</div></td>

	    </tr>';
  
 echo $loop_rowe;
              
}   

if(isset($_POST["delete_charge"])){
  
$delkey=mysqli_real_escape_string($mysqliconn, $_POST['delkey']);

    magic_sql_delete('client_charges', "`primkey`='$delkey'");
}



if(isset($_POST["qactive_client_months"])){


$qactive_client_months=mysqli_real_escape_string($mysqliconn, ($_POST["client_id"]));
$monthyear=mysqli_real_escape_string($mysqliconn, ($_POST["qstr"]));


//=== start active_client_months select  Like Query String active_client_months list  

$active_client_months_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`active_client_months` WHERE client_id='$qactive_client_months' AND month_year LIKE '%".$monthyear."%' ORDER BY `month_year` ASC LIMIT 1000" );



$pack_str="";
  
while($active_client_months_list_res=mysqli_fetch_array($active_client_months_list_query)){

	$pack_str.='<div class="row col-md-12 p-3 text-left">  <span class="cpointer mr-2 badge badge-danger p-2" onclick="remove_month_year(\''.$active_client_months_list_res['primkey'].'\', \''.$active_client_months_list_res['client_id'].'\')"><i class="fa fa-trash"></i> Remove </span> '.date("M-Y", strtotime($active_client_months_list_res['month_year'])).' 
</div>';
  
}	

echo $pack_str;

  
}

if(isset($_POST["remove_month_year"])){

  $delkey=mysqli_real_escape_string($mysqliconn, ($_POST["delkey"]));

    magic_sql_delete('active_client_months', "primkey='$delkey'");
 
  echo "Month removed";
}

if(isset($_POST["add_inactive_month"])){
//------- begin Insert Query  --> 

//------- begin sql_comment --> 
$arrid=mysqli_real_escape_string($mysqliconn,  magic_random_str(7));
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$month_year=mysqli_real_escape_string($mysqliconn, $_POST["txt_month_year"]);
$reamark=mysqli_real_escape_string($mysqliconn, "");
$status=mysqli_real_escape_string($mysqliconn, "");
//===-- End sql_comment -->

  
 $dup_month=  magic_sql_count('active_client_months', "*", "client_id='$client_id' AND month_year='$month_year'");
  
 if($dup_month==0){
$active_client_months_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`active_client_months` (`primkey`,`arrid`,`client_id`,`month_year`,`reamark`,`status`) 
 VALUES 
(NULL,'$arrid','$client_id','$month_year','$reamark','$status')");

  echo "Month Added";
 }else{
     echo "Month Already Added ";

 }
//------- End insert Query  --> 
}

if(isset($_POST["export_contacts"]))
{
  
$cont_key=mysqli_real_escape_string($mysqliconn, ($_POST["cont_key"]));


//=== start packages select  Like Query String packages list  
$cont_adress=magic_sql_row_data('client_base', "primkey='$cont_key'", "primkey", "desc");
  
magic_sql_update('client_base', '{"vcf_exported":"Exported"}', "primkey='$cont_key'");
  
$add_cont_str= $cont_adress['client_name']."-".$cont_adress['client_tel'];

  
$contact_id=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$address=mysqli_real_escape_string($mysqliconn, str_replace(" ", "", $cont_adress['client_tel']));
$type=mysqli_real_escape_string($mysqliconn, "From POS Export");
$comment=mysqli_real_escape_string($mysqliconn, $cont_adress['client_name']);
//===-- End Create Update record from address_book -->

$count_cont_no=magic_sql_count('address_book',"*", "address='$address'");
  
if($count_cont_no==0){
$address_book_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`address_book` (`primkey`,`contact_id`,`address`,`type`,`comment`) 
 VALUES 
(NULL,'$contact_id','$address','$type','$comment')");

 //--- get primary key id
$address_book_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key

    echo "Contact Added";
}else{
    echo "Contact Already Exist";
}
  
}
?>
  
  
  
