<?php 

		//== initialize edit token variables

		$arrears_uptoken="";

		if(isset($_GET["arrears_uptoken"]))
		{
		$arrears_uptoken=base64_decode($_GET["arrears_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["arrears_insert_btn"])){
//------- begin Create Update record from arrears --> 
$arrid=mysqli_real_escape_string($mysqliconn, $_POST["txt_arrid"]);
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$month_year=mysqli_real_escape_string($mysqliconn, $_POST["txt_month_year"]);
$amount=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount"]);
$reamark=mysqli_real_escape_string($mysqliconn, $_POST["txt_reamark"]);
$status=mysqli_real_escape_string($mysqliconn, $_POST["txt_status"]);
//===-- End Create Update record from arrears -->


$arrears_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`arrears` (`primkey`,`arrid`,`client_id`,`month_year`,`amount`,`reamark`,`status`) 
 VALUES 
(NULL,'$arrid','$client_id','$month_year','$amount','$reamark','$status')");

 //--- get primary key id
$arrears_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?arrears_uptoken='.base64_encode($arrears_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["arrears_update_btn"])){
//------- begin Create Update record from arrears --> 
$arrid=mysqli_real_escape_string($mysqliconn, $_POST["txt_arrid"]);
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$month_year=mysqli_real_escape_string($mysqliconn, $_POST["txt_month_year"]);
$amount=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount"]);
$reamark=mysqli_real_escape_string($mysqliconn, $_POST["txt_reamark"]);
$status=mysqli_real_escape_string($mysqliconn, $_POST["txt_status"]);
//===-- End Create Update record from arrears -->


$arrears_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`arrears` SET `primkey`='$primkey',`arrid`='$arrid',`client_id`='$client_id',`month_year`='$month_year',`amount`='$amount',`reamark`='$reamark',`status`='$status' WHERE primkey='$arrears_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?arrears_uptoken='.base64_encode($arrears_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start arrears select Find arrears Records Profile query 

$find_arrears_records_profile_arrears_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`arrears` WHERE `primkey`='$arrears_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$arrears_node=mysqli_fetch_array($find_arrears_records_profile_arrears_query);

//=== End arrears select Find arrears Records Profile  query




if(isset($_POST["qarrears_btn"])){


$qarrears_str=base64_encode($_POST["txt_arrears"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qarrears='.($qarrears_str).'');

}

if(isset($_GET["qarrears"])){


$qarrears=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qarrears"]));



//===== limit record value

$arrears_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`arrears` WHERE (`primkey` LIKE '%".$qarrears."%' OR  `arrid` LIKE '%".$qarrears."%' OR  `client_id` LIKE '%".$qarrears."%' OR  `month_year` LIKE '%".$qarrears."%' OR  `amount` LIKE '%".$qarrears."%' OR  `reamark` LIKE '%".$qarrears."%' OR  `status` LIKE '%".$qarrears."%')";

//===== Pagination function

$arrears_pagination= list_record_per_page($mysqliconn, $arrears_sqlstring, $datalimit);


//===== get return values


$arrears_firstproduct=$arrears_pagination["0"];

$arrears_pgcount=$arrears_pagination["1"];

//=== start arrears select  Like Query String arrears list  

$arrears_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`arrears`  WHERE (`primkey` LIKE '%".$qarrears."%' OR  `arrid` LIKE '%".$qarrears."%' OR  `client_id` LIKE '%".$qarrears."%' OR  `month_year` LIKE '%".$qarrears."%' OR  `amount` LIKE '%".$qarrears."%' OR  `reamark` LIKE '%".$qarrears."%' OR  `status` LIKE '%".$qarrears."%') ORDER BY `primkey` DESC LIMIT $arrears_firstproduct, $datalimit" );



//=== End arrears select  Like Query String arrears list
;

}else{

//===== limit record value

$arrears_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`arrears`";

//===== Pagination function

$arrears_pagination= list_record_per_page($mysqliconn, $arrears_sqlstring, $datalimit);


//===== get return values


$arrears_firstproduct=$arrears_pagination["0"];

$arrears_pgcount=$arrears_pagination["1"];

//=== start arrears select  Like Query String arrears list  

$arrears_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`arrears`  ORDER BY `primkey` DESC LIMIT $arrears_firstproduct, $datalimit" );

//$arrears_list_res=mysqli_fetch_array($arrears_list_query);

//=== End arrears select  Like Query String arrears list

}


//== Start  **** Delete arrears Records  

if(isset($_GET["deletearrears"]))
{

//======confirm pop up 

$conf_del_arrears_btn=magic_button_link("./editarrears.php?arrears_uptoken=".$_GET["arrears_uptoken"]."&conf_deletearrears", "Yes", 'style="margin-right:10px;"');

$cancel_del_arrears_btn=magic_button_link("./editarrears.php?arrears_uptoken=".$_GET["arrears_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_arrears_btn." ".$cancel_del_arrears_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deletearrears"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`arrears` WHERE `primkey`='$arrears_uptoken'");

//==add your redirect here 

header("location:./arrears.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete arrears Records 

//--<{ncgh}/>
?>