<?php 
//===============Start DATA HANDLER QUERIES ===================
				
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section active_client_months
  //************************************************* START  active_client_months OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize active_client_months edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['active_client_months_table_alert']))
              	{	
                  if(isset($active_client_months_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$active_client_months_uptoken="";

		if(isset($_GET["active_client_months_uptoken"]))
		{
		$active_client_months_uptoken=base64_decode($_GET["active_client_months_uptoken"]);
		}
        
        if(isset($_POST["active_client_months_uptoken"]))
		{
		$active_client_months_uptoken=base64_decode($_POST["active_client_months_uptoken"]);
		}
        //
        
          $active_client_months_alias_name="ACTIVE CLIENT MONTHS";

          if(isset($active_client_months_alias))
          {
             $active_client_months_alias_name=$active_client_months_alias;

          }
          
        //get single data record query with $active_client_months_uptoken
        
        ///$active_client_months_node=get_active_client_months("*", "WHERE primkey='$active_client_months_uptoken'", "r");
        
	
//************* START INSERT  active_client_months QUERY 
if(isset($_POST["active_client_months_insert_btn"])){
//------- begin active_client_months_arr_ins --> 
$active_client_months_arr_ins_=array(

"primkey"=>"NULL",
"arrid"=>magic_random_str(7),
"client_id"=>"?",
"month_year"=>"?",
"reamark"=>"?",
"status"=>"?"

);
//===-- End active_client_months_arr_ins -->


          
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "insert","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {

              $active_client_months_validated_ins_str=$active_client_months_arr_ins_;

              if(isset($active_client_months_ins_inputs))
              {
                $active_client_months_validated_ins_str=$active_client_months_ins_inputs;	
              }

              if(empty($active_client_months_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$active_client_months_alias_name." request cannot be empty. Record not added");
              }else{

                $active_client_months_return_key=add_active_client_months($active_client_months_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $active_client_months_return_key; 

                      } 

                    }else{ 

                                    
                $active_client_months_custom_redir1=add_url_param ("active_client_months_uptoken", base64_encode($active_client_months_return_key), "");
                $active_client_months_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$active_client_months_custom_redir1);
                $active_client_months_custom_redir3=add_url_param ("active_client_months_table_alert", "active_client_months_added",$active_client_months_custom_redir2);
                
                ///echo magic_message($active_client_months_custom_redir1." -- ".$active_client_months_custom_redir2."--".$active_client_months_custom_redir3);
                
                $active_client_months_custom_redir=$active_client_months_custom_redir3;
                
               header('location:'.$active_client_months_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_active_client_months_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");
         
         }
      
}
//************* END  active_client_months INSERT QUERY 	
	

//************* START active_client_months  UPDATE QUERY 
if(isset($_POST["active_client_months_update_btn"])){
//------- begin active_client_months_arr_updt --> 
$active_client_months_arr_updt_=array(
"client_id"=>"?",
"month_year"=>"?",
"reamark"=>"?",
"status"=>"?"

);
//===-- End active_client_months_arr_updt -->
                     
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "update","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {
         
            $active_client_months_validated_updt_str=$active_client_months_arr_updt_;

            if(isset($active_client_months_updt_inputs))
            {
              $active_client_months_validated_updt_str=$active_client_months_updt_inputs;	
            }

            if(empty($active_client_months_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$active_client_months_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$active_client_months_key_salt=initialize_active_client_months()["arrid"];
              update_active_client_months($active_client_months_validated_updt_str, "primkey='$active_client_months_uptoken' and arrid='$active_client_months_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $active_client_months_uptoken; 

                    } 

                  }else{ 

                $active_client_months_custom_redir1=add_url_param ("active_client_months_uptoken", base64_encode($active_client_months_uptoken), "");
                $active_client_months_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$active_client_months_custom_redir1);
                $active_client_months_custom_redir3=add_url_param ("active_client_months_table_alert", "active_client_months_updated",$active_client_months_custom_redir2);
                
                ///echo magic_message($active_client_months_custom_redir1." -- ".$active_client_months_custom_redir2."--".$active_client_months_custom_redir3);
                
                $active_client_months_custom_redir=$active_client_months_custom_redir3;
                
               header('location:'.$active_client_months_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_active_client_months_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");
         
         }

      

      
}
//************* END active_client_months  UPDATE QUERY 

    
    
      //== Start active_client_months delete record

      if(isset($_GET["deleteactive_client_months"]))
      {
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "super_delete_request","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_active_client_months_btn=magic_button_link("./".$current_file_url."?active_client_months_uptoken=".$_GET["active_client_months_uptoken"]."&conf_deleteactive_client_months&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_active_client_months_btn=magic_button_link("./".$current_file_url."?active_client_months_uptoken=".$_GET["active_client_months_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_active_client_months_btn." ".$cancel_del_active_client_months_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_active_client_months_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteactive_client_months"]))
      {
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "super_delete_confirm","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $active_client_months_del_key_salt=initialize_active_client_months()["arrid"];
      drop_active_client_months("primkey='$active_client_months_uptoken' and arrid='$active_client_months_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_active_client_months_);

      }
      }

      //== End active_client_months delete record  
    
       ///SELECT STRING FOR active_client_months============================
              
       if(isset($_POST["qactive_client_months_btn"])){
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "qactive_client_months_btn","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {
            $current_active_client_months_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_active_client_months_current_url=$current_active_client_months_url_params.'?qactive_client_months=';
            if (strpos($current_active_client_months_url_params, '?') !== false) {

                $clean_active_client_months_current_url=$current_active_client_months_url_params.'&qactive_client_months=';

            }
            if (strpos($current_active_client_months_url_params, '?qactive_client_months')) {

                $remove_active_client_months_old_token = substr($current_active_client_months_url_params, 0, strpos($current_active_client_months_url_params, "?qactive_client_months"));

                $clean_active_client_months_current_url=$remove_active_client_months_old_token.'?qactive_client_months=';

            }
            if(strpos($current_active_client_months_url_params, '&qactive_client_months')) {

                $remove_active_client_months_old_token = substr($current_active_client_months_url_params, 0, strpos($current_active_client_months_url_params, "&qactive_client_months"));

                $clean_active_client_months_current_url=$remove_active_client_months_old_token.'&qactive_client_months=';

            }
        $qactive_client_months_str=base64_encode($_POST["txt_active_client_months"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_active_client_months_current_url.($qactive_client_months_str);
            } 

          }else{ 
             header('location:'.$clean_active_client_months_current_url.($qactive_client_months_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_active_client_months_);

        }
        }
        $qactive_client_months="";
		if(isset($_GET["active_client_months_mosyfilter"]) && isset($_GET["qactive_client_months"])){
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "active_client_months_mosyfilter_n_query","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {
         $qactive_client_months=mmres(base64_decode($_GET["qactive_client_months"]));
         
         $gft_active_client_months_where_query="(`arrid` LIKE '%".$qactive_client_months."%' OR  `client_id` LIKE '%".$qactive_client_months."%' OR  `month_year` LIKE '%".$qactive_client_months."%' OR  `reamark` LIKE '%".$qactive_client_months."%' OR  `status` LIKE '%".$qactive_client_months."%')";
         
         if($_GET["active_client_months_mosyfilter"]!=""){
         
         $mosyfilter_active_client_months_queries_str=(base64_decode($_GET["active_client_months_mosyfilter"]));
        
         $gft_active_client_months_where_query="(`arrid` LIKE '%".$qactive_client_months."%' OR  `client_id` LIKE '%".$qactive_client_months."%' OR  `month_year` LIKE '%".$qactive_client_months."%' OR  `reamark` LIKE '%".$qactive_client_months."%' OR  `status` LIKE '%".$qactive_client_months."%') AND ".$mosyfilter_active_client_months_queries_str."";
         
         }
         
		 $gft_active_client_months="WHERE ".$gft_active_client_months_where_query;
         
         $gft_active_client_months_and=$gft_active_client_months_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_active_client_months_);
        }
        }elseif(isset($_GET["qactive_client_months"])){
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "get_qactive_client_months","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {
		 $qactive_client_months=mmres(base64_decode($_GET["qactive_client_months"]));
        
         $gft_active_client_months_where_query="(`arrid` LIKE '%".$qactive_client_months."%' OR  `client_id` LIKE '%".$qactive_client_months."%' OR  `month_year` LIKE '%".$qactive_client_months."%' OR  `reamark` LIKE '%".$qactive_client_months."%' OR  `status` LIKE '%".$qactive_client_months."%')";
         
         $gft_active_client_months="WHERE ".$gft_active_client_months_where_query;
         
         $gft_active_client_months_and=$gft_active_client_months_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_active_client_months_);

        }
        }elseif(isset($_GET["active_client_months_mosyfilter"])){
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "active_client_months_mosyfilter","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {
         $gft_active_client_months_where_query="";
         $gft_active_client_months="";

         if($_GET["active_client_months_mosyfilter"]!=""){
          $gft_active_client_months_where_query=(base64_decode($_GET["active_client_months_mosyfilter"]));
          $gft_active_client_months="WHERE ".$gft_active_client_months_where_query;
         }
         
         
         $gft_active_client_months_and=$gft_active_client_months_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_active_client_months_);

        }
        }else{
         $gft_active_client_months="";
         $gft_active_client_months_and="";
         $gft_active_client_months_where_query="";
        }
       
    //************************************************* END  active_client_months OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section address_book
  //************************************************* START  address_book OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize address_book edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['address_book_table_alert']))
              	{	
                  if(isset($address_book_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$address_book_uptoken="";

		if(isset($_GET["address_book_uptoken"]))
		{
		$address_book_uptoken=base64_decode($_GET["address_book_uptoken"]);
		}
        
        if(isset($_POST["address_book_uptoken"]))
		{
		$address_book_uptoken=base64_decode($_POST["address_book_uptoken"]);
		}
        //
        
          $address_book_alias_name="ADDRESS BOOK";

          if(isset($address_book_alias))
          {
             $address_book_alias_name=$address_book_alias;

          }
          
        //get single data record query with $address_book_uptoken
        
        ///$address_book_node=get_address_book("*", "WHERE primkey='$address_book_uptoken'", "r");
        
	
//************* START INSERT  address_book QUERY 
if(isset($_POST["address_book_insert_btn"])){
//------- begin address_book_arr_ins --> 
$address_book_arr_ins_=array(

"primkey"=>"NULL",
"contact_id"=>magic_random_str(7),
"address"=>"?",
"type"=>"?",
"comment"=>"?"

);
//===-- End address_book_arr_ins -->


          
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "insert","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {

              $address_book_validated_ins_str=$address_book_arr_ins_;

              if(isset($address_book_ins_inputs))
              {
                $address_book_validated_ins_str=$address_book_ins_inputs;	
              }

              if(empty($address_book_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$address_book_alias_name." request cannot be empty. Record not added");
              }else{

                $address_book_return_key=add_address_book($address_book_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $address_book_return_key; 

                      } 

                    }else{ 

                                    
                $address_book_custom_redir1=add_url_param ("address_book_uptoken", base64_encode($address_book_return_key), "");
                $address_book_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$address_book_custom_redir1);
                $address_book_custom_redir3=add_url_param ("address_book_table_alert", "address_book_added",$address_book_custom_redir2);
                
                ///echo magic_message($address_book_custom_redir1." -- ".$address_book_custom_redir2."--".$address_book_custom_redir3);
                
                $address_book_custom_redir=$address_book_custom_redir3;
                
               header('location:'.$address_book_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_address_book_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");
         
         }
      
}
//************* END  address_book INSERT QUERY 	
	

//************* START address_book  UPDATE QUERY 
if(isset($_POST["address_book_update_btn"])){
//------- begin address_book_arr_updt --> 
$address_book_arr_updt_=array(
"address"=>"?",
"type"=>"?",
"comment"=>"?"

);
//===-- End address_book_arr_updt -->
                     
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "update","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {
         
            $address_book_validated_updt_str=$address_book_arr_updt_;

            if(isset($address_book_updt_inputs))
            {
              $address_book_validated_updt_str=$address_book_updt_inputs;	
            }

            if(empty($address_book_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$address_book_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$address_book_key_salt=initialize_address_book()["contact_id"];
              update_address_book($address_book_validated_updt_str, "primkey='$address_book_uptoken' and contact_id='$address_book_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $address_book_uptoken; 

                    } 

                  }else{ 

                $address_book_custom_redir1=add_url_param ("address_book_uptoken", base64_encode($address_book_uptoken), "");
                $address_book_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$address_book_custom_redir1);
                $address_book_custom_redir3=add_url_param ("address_book_table_alert", "address_book_updated",$address_book_custom_redir2);
                
                ///echo magic_message($address_book_custom_redir1." -- ".$address_book_custom_redir2."--".$address_book_custom_redir3);
                
                $address_book_custom_redir=$address_book_custom_redir3;
                
               header('location:'.$address_book_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_address_book_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");
         
         }

      

      
}
//************* END address_book  UPDATE QUERY 

    
    
      //== Start address_book delete record

      if(isset($_GET["deleteaddress_book"]))
      {
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "super_delete_request","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_address_book_btn=magic_button_link("./".$current_file_url."?address_book_uptoken=".$_GET["address_book_uptoken"]."&conf_deleteaddress_book&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_address_book_btn=magic_button_link("./".$current_file_url."?address_book_uptoken=".$_GET["address_book_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_address_book_btn." ".$cancel_del_address_book_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_address_book_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteaddress_book"]))
      {
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "super_delete_confirm","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $address_book_del_key_salt=initialize_address_book()["contact_id"];
      drop_address_book("primkey='$address_book_uptoken' and contact_id='$address_book_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_address_book_);

      }
      }

      //== End address_book delete record  
    
       ///SELECT STRING FOR address_book============================
              
       if(isset($_POST["qaddress_book_btn"])){
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "qaddress_book_btn","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {
            $current_address_book_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_address_book_current_url=$current_address_book_url_params.'?qaddress_book=';
            if (strpos($current_address_book_url_params, '?') !== false) {

                $clean_address_book_current_url=$current_address_book_url_params.'&qaddress_book=';

            }
            if (strpos($current_address_book_url_params, '?qaddress_book')) {

                $remove_address_book_old_token = substr($current_address_book_url_params, 0, strpos($current_address_book_url_params, "?qaddress_book"));

                $clean_address_book_current_url=$remove_address_book_old_token.'?qaddress_book=';

            }
            if(strpos($current_address_book_url_params, '&qaddress_book')) {

                $remove_address_book_old_token = substr($current_address_book_url_params, 0, strpos($current_address_book_url_params, "&qaddress_book"));

                $clean_address_book_current_url=$remove_address_book_old_token.'&qaddress_book=';

            }
        $qaddress_book_str=base64_encode($_POST["txt_address_book"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_address_book_current_url.($qaddress_book_str);
            } 

          }else{ 
             header('location:'.$clean_address_book_current_url.($qaddress_book_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_address_book_);

        }
        }
        $qaddress_book="";
		if(isset($_GET["address_book_mosyfilter"]) && isset($_GET["qaddress_book"])){
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "address_book_mosyfilter_n_query","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {
         $qaddress_book=mmres(base64_decode($_GET["qaddress_book"]));
         
         $gft_address_book_where_query="(`contact_id` LIKE '%".$qaddress_book."%' OR  `address` LIKE '%".$qaddress_book."%' OR  `type` LIKE '%".$qaddress_book."%' OR  `comment` LIKE '%".$qaddress_book."%')";
         
         if($_GET["address_book_mosyfilter"]!=""){
         
         $mosyfilter_address_book_queries_str=(base64_decode($_GET["address_book_mosyfilter"]));
        
         $gft_address_book_where_query="(`contact_id` LIKE '%".$qaddress_book."%' OR  `address` LIKE '%".$qaddress_book."%' OR  `type` LIKE '%".$qaddress_book."%' OR  `comment` LIKE '%".$qaddress_book."%') AND ".$mosyfilter_address_book_queries_str."";
         
         }
         
		 $gft_address_book="WHERE ".$gft_address_book_where_query;
         
         $gft_address_book_and=$gft_address_book_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_address_book_);
        }
        }elseif(isset($_GET["qaddress_book"])){
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "get_qaddress_book","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {
		 $qaddress_book=mmres(base64_decode($_GET["qaddress_book"]));
        
         $gft_address_book_where_query="(`contact_id` LIKE '%".$qaddress_book."%' OR  `address` LIKE '%".$qaddress_book."%' OR  `type` LIKE '%".$qaddress_book."%' OR  `comment` LIKE '%".$qaddress_book."%')";
         
         $gft_address_book="WHERE ".$gft_address_book_where_query;
         
         $gft_address_book_and=$gft_address_book_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_address_book_);

        }
        }elseif(isset($_GET["address_book_mosyfilter"])){
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "address_book_mosyfilter","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {
         $gft_address_book_where_query="";
         $gft_address_book="";

         if($_GET["address_book_mosyfilter"]!=""){
          $gft_address_book_where_query=(base64_decode($_GET["address_book_mosyfilter"]));
          $gft_address_book="WHERE ".$gft_address_book_where_query;
         }
         
         
         $gft_address_book_and=$gft_address_book_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_address_book_);

        }
        }else{
         $gft_address_book="";
         $gft_address_book_and="";
         $gft_address_book_where_query="";
        }
       
    //************************************************* END  address_book OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section admin
  //************************************************* START  admin OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize admin edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['admin_table_alert']))
              	{	
                  if(isset($admin_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$admin_uptoken="";

		if(isset($_GET["admin_uptoken"]))
		{
		$admin_uptoken=base64_decode($_GET["admin_uptoken"]);
		}
        
        if(isset($_POST["admin_uptoken"]))
		{
		$admin_uptoken=base64_decode($_POST["admin_uptoken"]);
		}
        //
        
          $admin_alias_name="ADMIN";

          if(isset($admin_alias))
          {
             $admin_alias_name=$admin_alias;

          }
          
        //get single data record query with $admin_uptoken
        
        ///$admin_node=get_admin("*", "WHERE primkey='$admin_uptoken'", "r");
        
	
//************* START INSERT  admin QUERY 
if(isset($_POST["admin_insert_btn"])){
//------- begin admin_arr_ins --> 
$admin_arr_ins_=array(

"primkey"=>"NULL",
"admin_id"=>magic_random_str(7),
"names"=>"?",
"username"=>"?",
"password"=>"?",
"role"=>"?",
"last_seen"=>"?",
"telephone"=>"?",
"photo"=>"?"

);
//===-- End admin_arr_ins -->


          
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "insert","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {

              $admin_validated_ins_str=$admin_arr_ins_;

              if(isset($admin_ins_inputs))
              {
                $admin_validated_ins_str=$admin_ins_inputs;	
              }

              if(empty($admin_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$admin_alias_name." request cannot be empty. Record not added");
              }else{

                $admin_return_key=add_admin($admin_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $admin_return_key; 

                      } 

                    }else{ 

                                    
                $admin_custom_redir1=add_url_param ("admin_uptoken", base64_encode($admin_return_key), "");
                $admin_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$admin_custom_redir1);
                $admin_custom_redir3=add_url_param ("admin_table_alert", "admin_added",$admin_custom_redir2);
                
                ///echo magic_message($admin_custom_redir1." -- ".$admin_custom_redir2."--".$admin_custom_redir3);
                
                $admin_custom_redir=$admin_custom_redir3;
                
               header('location:'.$admin_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_admin_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");
         
         }
      
}
//************* END  admin INSERT QUERY 	
	

//************* START admin  UPDATE QUERY 
if(isset($_POST["admin_update_btn"])){
//------- begin admin_arr_updt --> 
$admin_arr_updt_=array(
"names"=>"?",
"username"=>"?",
"password"=>"?",
"role"=>"?",
"last_seen"=>"?",
"telephone"=>"?",
"photo"=>"?"

);
//===-- End admin_arr_updt -->
                     
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "update","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
         
            $admin_validated_updt_str=$admin_arr_updt_;

            if(isset($admin_updt_inputs))
            {
              $admin_validated_updt_str=$admin_updt_inputs;	
            }

            if(empty($admin_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$admin_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$admin_key_salt=initialize_admin()["admin_id"];
              update_admin($admin_validated_updt_str, "primkey='$admin_uptoken' and admin_id='$admin_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $admin_uptoken; 

                    } 

                  }else{ 

                $admin_custom_redir1=add_url_param ("admin_uptoken", base64_encode($admin_uptoken), "");
                $admin_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$admin_custom_redir1);
                $admin_custom_redir3=add_url_param ("admin_table_alert", "admin_updated",$admin_custom_redir2);
                
                ///echo magic_message($admin_custom_redir1." -- ".$admin_custom_redir2."--".$admin_custom_redir3);
                
                $admin_custom_redir=$admin_custom_redir3;
                
               header('location:'.$admin_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_admin_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");
         
         }

      

      
}
//************* END admin  UPDATE QUERY 

    

          //===-====Start upload admin_photo 
          if(isset($_POST["btn_upload_admin_photo"]))
          {
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "upload_admin_photo","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_admin_photo']['tmp_name'])){

				upload_admin_photo('txt_admin_photo', "primkey='$admin_uptoken'");
                
                $admin_custom_redir1=add_url_param ("admin_uptoken", base64_encode($admin_uptoken), "");
                $admin_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$admin_custom_redir1);
                $admin_custom_redir3=add_url_param ("admin_table_alert", "admin_uploaded",$admin_custom_redir2);
                
                ///echo magic_message($admin_custom_redir1." -- ".$admin_custom_redir2."--".$admin_custom_redir3);
                
                $admin_custom_redir=$admin_custom_redir3;
                
               header('location:'.$admin_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_admin_);

          }
          }
          //===-====End upload admin_photo  

			//drop admin_photo image 
            
          if(isset($_GET["conf_deleteadmin"]))
          {
          	if($admin_node["photo"]!="")
            {
          	 unlink($admin_node["photo"]);
            }
          }
          
          
    
      //== Start admin delete record

      if(isset($_GET["deleteadmin"]))
      {
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "super_delete_request","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_admin_btn=magic_button_link("./".$current_file_url."?admin_uptoken=".$_GET["admin_uptoken"]."&conf_deleteadmin&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_admin_btn=magic_button_link("./".$current_file_url."?admin_uptoken=".$_GET["admin_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_admin_btn." ".$cancel_del_admin_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_admin_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteadmin"]))
      {
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "super_delete_confirm","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $admin_del_key_salt=initialize_admin()["admin_id"];
      drop_admin("primkey='$admin_uptoken' and admin_id='$admin_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_admin_);

      }
      }

      //== End admin delete record  
    
       ///SELECT STRING FOR admin============================
              
       if(isset($_POST["qadmin_btn"])){
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "qadmin_btn","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
            $current_admin_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_admin_current_url=$current_admin_url_params.'?qadmin=';
            if (strpos($current_admin_url_params, '?') !== false) {

                $clean_admin_current_url=$current_admin_url_params.'&qadmin=';

            }
            if (strpos($current_admin_url_params, '?qadmin')) {

                $remove_admin_old_token = substr($current_admin_url_params, 0, strpos($current_admin_url_params, "?qadmin"));

                $clean_admin_current_url=$remove_admin_old_token.'?qadmin=';

            }
            if(strpos($current_admin_url_params, '&qadmin')) {

                $remove_admin_old_token = substr($current_admin_url_params, 0, strpos($current_admin_url_params, "&qadmin"));

                $clean_admin_current_url=$remove_admin_old_token.'&qadmin=';

            }
        $qadmin_str=base64_encode($_POST["txt_admin"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_admin_current_url.($qadmin_str);
            } 

          }else{ 
             header('location:'.$clean_admin_current_url.($qadmin_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_admin_);

        }
        }
        $qadmin="";
		if(isset($_GET["admin_mosyfilter"]) && isset($_GET["qadmin"])){
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "admin_mosyfilter_n_query","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
         $qadmin=mmres(base64_decode($_GET["qadmin"]));
         
         $gft_admin_where_query="(`admin_id` LIKE '%".$qadmin."%' OR  `names` LIKE '%".$qadmin."%' OR  `username` LIKE '%".$qadmin."%' OR  `password` LIKE '%".$qadmin."%' OR  `role` LIKE '%".$qadmin."%' OR  `last_seen` LIKE '%".$qadmin."%' OR  `telephone` LIKE '%".$qadmin."%' OR  `photo` LIKE '%".$qadmin."%')";
         
         if($_GET["admin_mosyfilter"]!=""){
         
         $mosyfilter_admin_queries_str=(base64_decode($_GET["admin_mosyfilter"]));
        
         $gft_admin_where_query="(`admin_id` LIKE '%".$qadmin."%' OR  `names` LIKE '%".$qadmin."%' OR  `username` LIKE '%".$qadmin."%' OR  `password` LIKE '%".$qadmin."%' OR  `role` LIKE '%".$qadmin."%' OR  `last_seen` LIKE '%".$qadmin."%' OR  `telephone` LIKE '%".$qadmin."%' OR  `photo` LIKE '%".$qadmin."%') AND ".$mosyfilter_admin_queries_str."";
         
         }
         
		 $gft_admin="WHERE ".$gft_admin_where_query;
         
         $gft_admin_and=$gft_admin_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_admin_);
        }
        }elseif(isset($_GET["qadmin"])){
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "get_qadmin","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
		 $qadmin=mmres(base64_decode($_GET["qadmin"]));
        
         $gft_admin_where_query="(`admin_id` LIKE '%".$qadmin."%' OR  `names` LIKE '%".$qadmin."%' OR  `username` LIKE '%".$qadmin."%' OR  `password` LIKE '%".$qadmin."%' OR  `role` LIKE '%".$qadmin."%' OR  `last_seen` LIKE '%".$qadmin."%' OR  `telephone` LIKE '%".$qadmin."%' OR  `photo` LIKE '%".$qadmin."%')";
         
         $gft_admin="WHERE ".$gft_admin_where_query;
         
         $gft_admin_and=$gft_admin_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_admin_);

        }
        }elseif(isset($_GET["admin_mosyfilter"])){
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "admin_mosyfilter","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
         $gft_admin_where_query="";
         $gft_admin="";

         if($_GET["admin_mosyfilter"]!=""){
          $gft_admin_where_query=(base64_decode($_GET["admin_mosyfilter"]));
          $gft_admin="WHERE ".$gft_admin_where_query;
         }
         
         
         $gft_admin_and=$gft_admin_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_admin_);

        }
        }else{
         $gft_admin="";
         $gft_admin_and="";
         $gft_admin_where_query="";
        }
       
    //************************************************* END  admin OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section client_base
  //************************************************* START  client_base OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize client_base edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['client_base_table_alert']))
              	{	
                  if(isset($client_base_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$client_base_uptoken="";

		if(isset($_GET["client_base_uptoken"]))
		{
		$client_base_uptoken=base64_decode($_GET["client_base_uptoken"]);
		}
        
        if(isset($_POST["client_base_uptoken"]))
		{
		$client_base_uptoken=base64_decode($_POST["client_base_uptoken"]);
		}
        //
        
          $client_base_alias_name="CLIENT BASE";

          if(isset($client_base_alias))
          {
             $client_base_alias_name=$client_base_alias;

          }
          
        //get single data record query with $client_base_uptoken
        
        ///$client_base_node=get_client_base("*", "WHERE primkey='$client_base_uptoken'", "r");
        
	
//************* START INSERT  client_base QUERY 
if(isset($_POST["client_base_insert_btn"])){
//------- begin client_base_arr_ins --> 
$client_base_arr_ins_=array(

"primkey"=>"NULL",
"client_id"=>magic_random_str(7),
"client_name"=>"?",
"gender"=>"?",
"client_tel"=>"?",
"client_email"=>"?",
"city"=>"?",
"location"=>"?",
"building_no"=>"?",
"floor_no"=>"?",
"room_no"=>"?",
"package"=>"?",
"package_price"=>"?",
"photo"=>"?",
"installation_date"=>"?",
"signed_by"=>"?",
"comment"=>"?",
"ip_address"=>"?",
"account_status"=>"?",
"admin_id"=>"?",
"instdate"=>"?",
"vcf_exported"=>"?"

);
//===-- End client_base_arr_ins -->


          
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "insert","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {

              $client_base_validated_ins_str=$client_base_arr_ins_;

              if(isset($client_base_ins_inputs))
              {
                $client_base_validated_ins_str=$client_base_ins_inputs;	
              }

              if(empty($client_base_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$client_base_alias_name." request cannot be empty. Record not added");
              }else{

                $client_base_return_key=add_client_base($client_base_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $client_base_return_key; 

                      } 

                    }else{ 

                                    
                $client_base_custom_redir1=add_url_param ("client_base_uptoken", base64_encode($client_base_return_key), "");
                $client_base_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$client_base_custom_redir1);
                $client_base_custom_redir3=add_url_param ("client_base_table_alert", "client_base_added",$client_base_custom_redir2);
                
                ///echo magic_message($client_base_custom_redir1." -- ".$client_base_custom_redir2."--".$client_base_custom_redir3);
                
                $client_base_custom_redir=$client_base_custom_redir3;
                
               header('location:'.$client_base_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_client_base_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");
         
         }
      
}
//************* END  client_base INSERT QUERY 	
	

//************* START client_base  UPDATE QUERY 
if(isset($_POST["client_base_update_btn"])){
//------- begin client_base_arr_updt --> 
$client_base_arr_updt_=array(
"client_name"=>"?",
"gender"=>"?",
"client_tel"=>"?",
"client_email"=>"?",
"city"=>"?",
"location"=>"?",
"building_no"=>"?",
"floor_no"=>"?",
"room_no"=>"?",
"package"=>"?",
"package_price"=>"?",
"photo"=>"?",
"installation_date"=>"?",
"signed_by"=>"?",
"comment"=>"?",
"ip_address"=>"?",
"account_status"=>"?",
"admin_id"=>"?",
"instdate"=>"?",
"vcf_exported"=>"?"

);
//===-- End client_base_arr_updt -->
                     
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "update","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
         
            $client_base_validated_updt_str=$client_base_arr_updt_;

            if(isset($client_base_updt_inputs))
            {
              $client_base_validated_updt_str=$client_base_updt_inputs;	
            }

            if(empty($client_base_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$client_base_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$client_base_key_salt=initialize_client_base()["client_id"];
              update_client_base($client_base_validated_updt_str, "primkey='$client_base_uptoken' and client_id='$client_base_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $client_base_uptoken; 

                    } 

                  }else{ 

                $client_base_custom_redir1=add_url_param ("client_base_uptoken", base64_encode($client_base_uptoken), "");
                $client_base_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$client_base_custom_redir1);
                $client_base_custom_redir3=add_url_param ("client_base_table_alert", "client_base_updated",$client_base_custom_redir2);
                
                ///echo magic_message($client_base_custom_redir1." -- ".$client_base_custom_redir2."--".$client_base_custom_redir3);
                
                $client_base_custom_redir=$client_base_custom_redir3;
                
               header('location:'.$client_base_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_client_base_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");
         
         }

      

      
}
//************* END client_base  UPDATE QUERY 

    

          //===-====Start upload client_base_photo 
          if(isset($_POST["btn_upload_client_base_photo"]))
          {
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "upload_client_base_photo","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_client_base_photo']['tmp_name'])){

				upload_client_base_photo('txt_client_base_photo', "primkey='$client_base_uptoken'");
                
                $client_base_custom_redir1=add_url_param ("client_base_uptoken", base64_encode($client_base_uptoken), "");
                $client_base_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$client_base_custom_redir1);
                $client_base_custom_redir3=add_url_param ("client_base_table_alert", "client_base_uploaded",$client_base_custom_redir2);
                
                ///echo magic_message($client_base_custom_redir1." -- ".$client_base_custom_redir2."--".$client_base_custom_redir3);
                
                $client_base_custom_redir=$client_base_custom_redir3;
                
               header('location:'.$client_base_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_client_base_);

          }
          }
          //===-====End upload client_base_photo  

			//drop client_base_photo image 
            
          if(isset($_GET["conf_deleteclient_base"]))
          {
          	if($client_base_node["photo"]!="")
            {
          	 unlink($client_base_node["photo"]);
            }
          }
          
          
    
      //== Start client_base delete record

      if(isset($_GET["deleteclient_base"]))
      {
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "super_delete_request","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_client_base_btn=magic_button_link("./".$current_file_url."?client_base_uptoken=".$_GET["client_base_uptoken"]."&conf_deleteclient_base&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_client_base_btn=magic_button_link("./".$current_file_url."?client_base_uptoken=".$_GET["client_base_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_client_base_btn." ".$cancel_del_client_base_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_client_base_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteclient_base"]))
      {
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "super_delete_confirm","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $client_base_del_key_salt=initialize_client_base()["client_id"];
      drop_client_base("primkey='$client_base_uptoken' and client_id='$client_base_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_client_base_);

      }
      }

      //== End client_base delete record  
    
       ///SELECT STRING FOR client_base============================
              
       if(isset($_POST["qclient_base_btn"])){
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "qclient_base_btn","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
            $current_client_base_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_client_base_current_url=$current_client_base_url_params.'?qclient_base=';
            if (strpos($current_client_base_url_params, '?') !== false) {

                $clean_client_base_current_url=$current_client_base_url_params.'&qclient_base=';

            }
            if (strpos($current_client_base_url_params, '?qclient_base')) {

                $remove_client_base_old_token = substr($current_client_base_url_params, 0, strpos($current_client_base_url_params, "?qclient_base"));

                $clean_client_base_current_url=$remove_client_base_old_token.'?qclient_base=';

            }
            if(strpos($current_client_base_url_params, '&qclient_base')) {

                $remove_client_base_old_token = substr($current_client_base_url_params, 0, strpos($current_client_base_url_params, "&qclient_base"));

                $clean_client_base_current_url=$remove_client_base_old_token.'&qclient_base=';

            }
        $qclient_base_str=base64_encode($_POST["txt_client_base"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_client_base_current_url.($qclient_base_str);
            } 

          }else{ 
             header('location:'.$clean_client_base_current_url.($qclient_base_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_client_base_);

        }
        }
        $qclient_base="";
		if(isset($_GET["client_base_mosyfilter"]) && isset($_GET["qclient_base"])){
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "client_base_mosyfilter_n_query","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
         $qclient_base=mmres(base64_decode($_GET["qclient_base"]));
         
         $gft_client_base_where_query="(`client_id` LIKE '%".$qclient_base."%' OR  `client_name` LIKE '%".$qclient_base."%' OR  `gender` LIKE '%".$qclient_base."%' OR  `client_tel` LIKE '%".$qclient_base."%' OR  `client_email` LIKE '%".$qclient_base."%' OR  `city` LIKE '%".$qclient_base."%' OR  `location` LIKE '%".$qclient_base."%' OR  `building_no` LIKE '%".$qclient_base."%' OR  `floor_no` LIKE '%".$qclient_base."%' OR  `room_no` LIKE '%".$qclient_base."%' OR  `package` LIKE '%".$qclient_base."%' OR  `package_price` LIKE '%".$qclient_base."%' OR  `photo` LIKE '%".$qclient_base."%' OR  `installation_date` LIKE '%".$qclient_base."%' OR  `signed_by` LIKE '%".$qclient_base."%' OR  `comment` LIKE '%".$qclient_base."%' OR  `ip_address` LIKE '%".$qclient_base."%' OR  `account_status` LIKE '%".$qclient_base."%' OR  `admin_id` LIKE '%".$qclient_base."%' OR  `instdate` LIKE '%".$qclient_base."%' OR  `vcf_exported` LIKE '%".$qclient_base."%')";
         
         if($_GET["client_base_mosyfilter"]!=""){
         
         $mosyfilter_client_base_queries_str=(base64_decode($_GET["client_base_mosyfilter"]));
        
         $gft_client_base_where_query="(`client_id` LIKE '%".$qclient_base."%' OR  `client_name` LIKE '%".$qclient_base."%' OR  `gender` LIKE '%".$qclient_base."%' OR  `client_tel` LIKE '%".$qclient_base."%' OR  `client_email` LIKE '%".$qclient_base."%' OR  `city` LIKE '%".$qclient_base."%' OR  `location` LIKE '%".$qclient_base."%' OR  `building_no` LIKE '%".$qclient_base."%' OR  `floor_no` LIKE '%".$qclient_base."%' OR  `room_no` LIKE '%".$qclient_base."%' OR  `package` LIKE '%".$qclient_base."%' OR  `package_price` LIKE '%".$qclient_base."%' OR  `photo` LIKE '%".$qclient_base."%' OR  `installation_date` LIKE '%".$qclient_base."%' OR  `signed_by` LIKE '%".$qclient_base."%' OR  `comment` LIKE '%".$qclient_base."%' OR  `ip_address` LIKE '%".$qclient_base."%' OR  `account_status` LIKE '%".$qclient_base."%' OR  `admin_id` LIKE '%".$qclient_base."%' OR  `instdate` LIKE '%".$qclient_base."%' OR  `vcf_exported` LIKE '%".$qclient_base."%') AND ".$mosyfilter_client_base_queries_str."";
         
         }
         
		 $gft_client_base="WHERE ".$gft_client_base_where_query;
         
         $gft_client_base_and=$gft_client_base_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_client_base_);
        }
        }elseif(isset($_GET["qclient_base"])){
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "get_qclient_base","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
		 $qclient_base=mmres(base64_decode($_GET["qclient_base"]));
        
         $gft_client_base_where_query="(`client_id` LIKE '%".$qclient_base."%' OR  `client_name` LIKE '%".$qclient_base."%' OR  `gender` LIKE '%".$qclient_base."%' OR  `client_tel` LIKE '%".$qclient_base."%' OR  `client_email` LIKE '%".$qclient_base."%' OR  `city` LIKE '%".$qclient_base."%' OR  `location` LIKE '%".$qclient_base."%' OR  `building_no` LIKE '%".$qclient_base."%' OR  `floor_no` LIKE '%".$qclient_base."%' OR  `room_no` LIKE '%".$qclient_base."%' OR  `package` LIKE '%".$qclient_base."%' OR  `package_price` LIKE '%".$qclient_base."%' OR  `photo` LIKE '%".$qclient_base."%' OR  `installation_date` LIKE '%".$qclient_base."%' OR  `signed_by` LIKE '%".$qclient_base."%' OR  `comment` LIKE '%".$qclient_base."%' OR  `ip_address` LIKE '%".$qclient_base."%' OR  `account_status` LIKE '%".$qclient_base."%' OR  `admin_id` LIKE '%".$qclient_base."%' OR  `instdate` LIKE '%".$qclient_base."%' OR  `vcf_exported` LIKE '%".$qclient_base."%')";
         
         $gft_client_base="WHERE ".$gft_client_base_where_query;
         
         $gft_client_base_and=$gft_client_base_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_client_base_);

        }
        }elseif(isset($_GET["client_base_mosyfilter"])){
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "client_base_mosyfilter","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
         $gft_client_base_where_query="";
         $gft_client_base="";

         if($_GET["client_base_mosyfilter"]!=""){
          $gft_client_base_where_query=(base64_decode($_GET["client_base_mosyfilter"]));
          $gft_client_base="WHERE ".$gft_client_base_where_query;
         }
         
         
         $gft_client_base_and=$gft_client_base_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_client_base_);

        }
        }else{
         $gft_client_base="";
         $gft_client_base_and="";
         $gft_client_base_where_query="";
        }
       
    //************************************************* END  client_base OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section client_charges
  //************************************************* START  client_charges OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize client_charges edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['client_charges_table_alert']))
              	{	
                  if(isset($client_charges_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$client_charges_uptoken="";

		if(isset($_GET["client_charges_uptoken"]))
		{
		$client_charges_uptoken=base64_decode($_GET["client_charges_uptoken"]);
		}
        
        if(isset($_POST["client_charges_uptoken"]))
		{
		$client_charges_uptoken=base64_decode($_POST["client_charges_uptoken"]);
		}
        //
        
          $client_charges_alias_name="CLIENT CHARGES";

          if(isset($client_charges_alias))
          {
             $client_charges_alias_name=$client_charges_alias;

          }
          
        //get single data record query with $client_charges_uptoken
        
        ///$client_charges_node=get_client_charges("*", "WHERE primkey='$client_charges_uptoken'", "r");
        
	
//************* START INSERT  client_charges QUERY 
if(isset($_POST["client_charges_insert_btn"])){
//------- begin client_charges_arr_ins --> 
$client_charges_arr_ins_=array(

"primkey"=>"NULL",
"charge_id"=>magic_random_str(7),
"client_id"=>"?",
"package_id"=>"?",
"trx_id"=>"?",
"amount"=>"?",
"balance"=>"?",
"remark"=>"?",
"qty"=>"?"

);
//===-- End client_charges_arr_ins -->


          
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "insert","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {

              $client_charges_validated_ins_str=$client_charges_arr_ins_;

              if(isset($client_charges_ins_inputs))
              {
                $client_charges_validated_ins_str=$client_charges_ins_inputs;	
              }

              if(empty($client_charges_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$client_charges_alias_name." request cannot be empty. Record not added");
              }else{

                $client_charges_return_key=add_client_charges($client_charges_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $client_charges_return_key; 

                      } 

                    }else{ 

                                    
                $client_charges_custom_redir1=add_url_param ("client_charges_uptoken", base64_encode($client_charges_return_key), "");
                $client_charges_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$client_charges_custom_redir1);
                $client_charges_custom_redir3=add_url_param ("client_charges_table_alert", "client_charges_added",$client_charges_custom_redir2);
                
                ///echo magic_message($client_charges_custom_redir1." -- ".$client_charges_custom_redir2."--".$client_charges_custom_redir3);
                
                $client_charges_custom_redir=$client_charges_custom_redir3;
                
               header('location:'.$client_charges_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_client_charges_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");
         
         }
      
}
//************* END  client_charges INSERT QUERY 	
	

//************* START client_charges  UPDATE QUERY 
if(isset($_POST["client_charges_update_btn"])){
//------- begin client_charges_arr_updt --> 
$client_charges_arr_updt_=array(
"client_id"=>"?",
"package_id"=>"?",
"trx_id"=>"?",
"amount"=>"?",
"balance"=>"?",
"remark"=>"?",
"qty"=>"?"

);
//===-- End client_charges_arr_updt -->
                     
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "update","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {
         
            $client_charges_validated_updt_str=$client_charges_arr_updt_;

            if(isset($client_charges_updt_inputs))
            {
              $client_charges_validated_updt_str=$client_charges_updt_inputs;	
            }

            if(empty($client_charges_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$client_charges_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$client_charges_key_salt=initialize_client_charges()["charge_id"];
              update_client_charges($client_charges_validated_updt_str, "primkey='$client_charges_uptoken' and charge_id='$client_charges_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $client_charges_uptoken; 

                    } 

                  }else{ 

                $client_charges_custom_redir1=add_url_param ("client_charges_uptoken", base64_encode($client_charges_uptoken), "");
                $client_charges_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$client_charges_custom_redir1);
                $client_charges_custom_redir3=add_url_param ("client_charges_table_alert", "client_charges_updated",$client_charges_custom_redir2);
                
                ///echo magic_message($client_charges_custom_redir1." -- ".$client_charges_custom_redir2."--".$client_charges_custom_redir3);
                
                $client_charges_custom_redir=$client_charges_custom_redir3;
                
               header('location:'.$client_charges_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_client_charges_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");
         
         }

      

      
}
//************* END client_charges  UPDATE QUERY 

    
    
      //== Start client_charges delete record

      if(isset($_GET["deleteclient_charges"]))
      {
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "super_delete_request","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_client_charges_btn=magic_button_link("./".$current_file_url."?client_charges_uptoken=".$_GET["client_charges_uptoken"]."&conf_deleteclient_charges&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_client_charges_btn=magic_button_link("./".$current_file_url."?client_charges_uptoken=".$_GET["client_charges_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_client_charges_btn." ".$cancel_del_client_charges_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_client_charges_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteclient_charges"]))
      {
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "super_delete_confirm","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $client_charges_del_key_salt=initialize_client_charges()["charge_id"];
      drop_client_charges("primkey='$client_charges_uptoken' and charge_id='$client_charges_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_client_charges_);

      }
      }

      //== End client_charges delete record  
    
       ///SELECT STRING FOR client_charges============================
              
       if(isset($_POST["qclient_charges_btn"])){
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "qclient_charges_btn","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {
            $current_client_charges_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_client_charges_current_url=$current_client_charges_url_params.'?qclient_charges=';
            if (strpos($current_client_charges_url_params, '?') !== false) {

                $clean_client_charges_current_url=$current_client_charges_url_params.'&qclient_charges=';

            }
            if (strpos($current_client_charges_url_params, '?qclient_charges')) {

                $remove_client_charges_old_token = substr($current_client_charges_url_params, 0, strpos($current_client_charges_url_params, "?qclient_charges"));

                $clean_client_charges_current_url=$remove_client_charges_old_token.'?qclient_charges=';

            }
            if(strpos($current_client_charges_url_params, '&qclient_charges')) {

                $remove_client_charges_old_token = substr($current_client_charges_url_params, 0, strpos($current_client_charges_url_params, "&qclient_charges"));

                $clean_client_charges_current_url=$remove_client_charges_old_token.'&qclient_charges=';

            }
        $qclient_charges_str=base64_encode($_POST["txt_client_charges"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_client_charges_current_url.($qclient_charges_str);
            } 

          }else{ 
             header('location:'.$clean_client_charges_current_url.($qclient_charges_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_client_charges_);

        }
        }
        $qclient_charges="";
		if(isset($_GET["client_charges_mosyfilter"]) && isset($_GET["qclient_charges"])){
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "client_charges_mosyfilter_n_query","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {
         $qclient_charges=mmres(base64_decode($_GET["qclient_charges"]));
         
         $gft_client_charges_where_query="(`charge_id` LIKE '%".$qclient_charges."%' OR  `client_id` LIKE '%".$qclient_charges."%' OR  `package_id` LIKE '%".$qclient_charges."%' OR  `trx_id` LIKE '%".$qclient_charges."%' OR  `amount` LIKE '%".$qclient_charges."%' OR  `balance` LIKE '%".$qclient_charges."%' OR  `remark` LIKE '%".$qclient_charges."%' OR  `qty` LIKE '%".$qclient_charges."%')";
         
         if($_GET["client_charges_mosyfilter"]!=""){
         
         $mosyfilter_client_charges_queries_str=(base64_decode($_GET["client_charges_mosyfilter"]));
        
         $gft_client_charges_where_query="(`charge_id` LIKE '%".$qclient_charges."%' OR  `client_id` LIKE '%".$qclient_charges."%' OR  `package_id` LIKE '%".$qclient_charges."%' OR  `trx_id` LIKE '%".$qclient_charges."%' OR  `amount` LIKE '%".$qclient_charges."%' OR  `balance` LIKE '%".$qclient_charges."%' OR  `remark` LIKE '%".$qclient_charges."%' OR  `qty` LIKE '%".$qclient_charges."%') AND ".$mosyfilter_client_charges_queries_str."";
         
         }
         
		 $gft_client_charges="WHERE ".$gft_client_charges_where_query;
         
         $gft_client_charges_and=$gft_client_charges_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_client_charges_);
        }
        }elseif(isset($_GET["qclient_charges"])){
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "get_qclient_charges","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {
		 $qclient_charges=mmres(base64_decode($_GET["qclient_charges"]));
        
         $gft_client_charges_where_query="(`charge_id` LIKE '%".$qclient_charges."%' OR  `client_id` LIKE '%".$qclient_charges."%' OR  `package_id` LIKE '%".$qclient_charges."%' OR  `trx_id` LIKE '%".$qclient_charges."%' OR  `amount` LIKE '%".$qclient_charges."%' OR  `balance` LIKE '%".$qclient_charges."%' OR  `remark` LIKE '%".$qclient_charges."%' OR  `qty` LIKE '%".$qclient_charges."%')";
         
         $gft_client_charges="WHERE ".$gft_client_charges_where_query;
         
         $gft_client_charges_and=$gft_client_charges_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_client_charges_);

        }
        }elseif(isset($_GET["client_charges_mosyfilter"])){
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "client_charges_mosyfilter","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {
         $gft_client_charges_where_query="";
         $gft_client_charges="";

         if($_GET["client_charges_mosyfilter"]!=""){
          $gft_client_charges_where_query=(base64_decode($_GET["client_charges_mosyfilter"]));
          $gft_client_charges="WHERE ".$gft_client_charges_where_query;
         }
         
         
         $gft_client_charges_and=$gft_client_charges_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_client_charges_);

        }
        }else{
         $gft_client_charges="";
         $gft_client_charges_and="";
         $gft_client_charges_where_query="";
        }
       
    //************************************************* END  client_charges OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section dtclean
  //************************************************* START  dtclean OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize dtclean edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['dtclean_table_alert']))
              	{	
                  if(isset($dtclean_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$dtclean_uptoken="";

		if(isset($_GET["dtclean_uptoken"]))
		{
		$dtclean_uptoken=base64_decode($_GET["dtclean_uptoken"]);
		}
        
        if(isset($_POST["dtclean_uptoken"]))
		{
		$dtclean_uptoken=base64_decode($_POST["dtclean_uptoken"]);
		}
        //
        
          $dtclean_alias_name="DTCLEAN";

          if(isset($dtclean_alias))
          {
             $dtclean_alias_name=$dtclean_alias;

          }
          
        //get single data record query with $dtclean_uptoken
        
        ///$dtclean_node=get_dtclean("*", "WHERE primkey='$dtclean_uptoken'", "r");
        
	
//************* START INSERT  dtclean QUERY 
if(isset($_POST["dtclean_insert_btn"])){
//------- begin dtclean_arr_ins --> 
$dtclean_arr_ins_=array(

"primkey"=>"NULL",
"building_no"=>magic_random_str(7),
"client_name"=>"?",
"room_no"=>"?",
"package"=>"?",
"package_amt"=>"?",
"insta_date"=>"?"

);
//===-- End dtclean_arr_ins -->


          
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "insert","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {

              $dtclean_validated_ins_str=$dtclean_arr_ins_;

              if(isset($dtclean_ins_inputs))
              {
                $dtclean_validated_ins_str=$dtclean_ins_inputs;	
              }

              if(empty($dtclean_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$dtclean_alias_name." request cannot be empty. Record not added");
              }else{

                $dtclean_return_key=add_dtclean($dtclean_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $dtclean_return_key; 

                      } 

                    }else{ 

                                    
                $dtclean_custom_redir1=add_url_param ("dtclean_uptoken", base64_encode($dtclean_return_key), "");
                $dtclean_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$dtclean_custom_redir1);
                $dtclean_custom_redir3=add_url_param ("dtclean_table_alert", "dtclean_added",$dtclean_custom_redir2);
                
                ///echo magic_message($dtclean_custom_redir1." -- ".$dtclean_custom_redir2."--".$dtclean_custom_redir3);
                
                $dtclean_custom_redir=$dtclean_custom_redir3;
                
               header('location:'.$dtclean_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_dtclean_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");
         
         }
      
}
//************* END  dtclean INSERT QUERY 	
	

//************* START dtclean  UPDATE QUERY 
if(isset($_POST["dtclean_update_btn"])){
//------- begin dtclean_arr_updt --> 
$dtclean_arr_updt_=array(
"client_name"=>"?",
"room_no"=>"?",
"package"=>"?",
"package_amt"=>"?",
"insta_date"=>"?"

);
//===-- End dtclean_arr_updt -->
                     
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "update","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {
         
            $dtclean_validated_updt_str=$dtclean_arr_updt_;

            if(isset($dtclean_updt_inputs))
            {
              $dtclean_validated_updt_str=$dtclean_updt_inputs;	
            }

            if(empty($dtclean_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$dtclean_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$dtclean_key_salt=initialize_dtclean()["building_no"];
              update_dtclean($dtclean_validated_updt_str, "primkey='$dtclean_uptoken' and building_no='$dtclean_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $dtclean_uptoken; 

                    } 

                  }else{ 

                $dtclean_custom_redir1=add_url_param ("dtclean_uptoken", base64_encode($dtclean_uptoken), "");
                $dtclean_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$dtclean_custom_redir1);
                $dtclean_custom_redir3=add_url_param ("dtclean_table_alert", "dtclean_updated",$dtclean_custom_redir2);
                
                ///echo magic_message($dtclean_custom_redir1." -- ".$dtclean_custom_redir2."--".$dtclean_custom_redir3);
                
                $dtclean_custom_redir=$dtclean_custom_redir3;
                
               header('location:'.$dtclean_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_dtclean_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");
         
         }

      

      
}
//************* END dtclean  UPDATE QUERY 

    
    
      //== Start dtclean delete record

      if(isset($_GET["deletedtclean"]))
      {
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "super_delete_request","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_dtclean_btn=magic_button_link("./".$current_file_url."?dtclean_uptoken=".$_GET["dtclean_uptoken"]."&conf_deletedtclean&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_dtclean_btn=magic_button_link("./".$current_file_url."?dtclean_uptoken=".$_GET["dtclean_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_dtclean_btn." ".$cancel_del_dtclean_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_dtclean_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletedtclean"]))
      {
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "super_delete_confirm","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $dtclean_del_key_salt=initialize_dtclean()["building_no"];
      drop_dtclean("primkey='$dtclean_uptoken' and building_no='$dtclean_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_dtclean_);

      }
      }

      //== End dtclean delete record  
    
       ///SELECT STRING FOR dtclean============================
              
       if(isset($_POST["qdtclean_btn"])){
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "qdtclean_btn","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {
            $current_dtclean_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_dtclean_current_url=$current_dtclean_url_params.'?qdtclean=';
            if (strpos($current_dtclean_url_params, '?') !== false) {

                $clean_dtclean_current_url=$current_dtclean_url_params.'&qdtclean=';

            }
            if (strpos($current_dtclean_url_params, '?qdtclean')) {

                $remove_dtclean_old_token = substr($current_dtclean_url_params, 0, strpos($current_dtclean_url_params, "?qdtclean"));

                $clean_dtclean_current_url=$remove_dtclean_old_token.'?qdtclean=';

            }
            if(strpos($current_dtclean_url_params, '&qdtclean')) {

                $remove_dtclean_old_token = substr($current_dtclean_url_params, 0, strpos($current_dtclean_url_params, "&qdtclean"));

                $clean_dtclean_current_url=$remove_dtclean_old_token.'&qdtclean=';

            }
        $qdtclean_str=base64_encode($_POST["txt_dtclean"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_dtclean_current_url.($qdtclean_str);
            } 

          }else{ 
             header('location:'.$clean_dtclean_current_url.($qdtclean_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_dtclean_);

        }
        }
        $qdtclean="";
		if(isset($_GET["dtclean_mosyfilter"]) && isset($_GET["qdtclean"])){
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "dtclean_mosyfilter_n_query","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {
         $qdtclean=mmres(base64_decode($_GET["qdtclean"]));
         
         $gft_dtclean_where_query="(`building_no` LIKE '%".$qdtclean."%' OR  `client_name` LIKE '%".$qdtclean."%' OR  `room_no` LIKE '%".$qdtclean."%' OR  `package` LIKE '%".$qdtclean."%' OR  `package_amt` LIKE '%".$qdtclean."%' OR  `insta_date` LIKE '%".$qdtclean."%')";
         
         if($_GET["dtclean_mosyfilter"]!=""){
         
         $mosyfilter_dtclean_queries_str=(base64_decode($_GET["dtclean_mosyfilter"]));
        
         $gft_dtclean_where_query="(`building_no` LIKE '%".$qdtclean."%' OR  `client_name` LIKE '%".$qdtclean."%' OR  `room_no` LIKE '%".$qdtclean."%' OR  `package` LIKE '%".$qdtclean."%' OR  `package_amt` LIKE '%".$qdtclean."%' OR  `insta_date` LIKE '%".$qdtclean."%') AND ".$mosyfilter_dtclean_queries_str."";
         
         }
         
		 $gft_dtclean="WHERE ".$gft_dtclean_where_query;
         
         $gft_dtclean_and=$gft_dtclean_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_dtclean_);
        }
        }elseif(isset($_GET["qdtclean"])){
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "get_qdtclean","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {
		 $qdtclean=mmres(base64_decode($_GET["qdtclean"]));
        
         $gft_dtclean_where_query="(`building_no` LIKE '%".$qdtclean."%' OR  `client_name` LIKE '%".$qdtclean."%' OR  `room_no` LIKE '%".$qdtclean."%' OR  `package` LIKE '%".$qdtclean."%' OR  `package_amt` LIKE '%".$qdtclean."%' OR  `insta_date` LIKE '%".$qdtclean."%')";
         
         $gft_dtclean="WHERE ".$gft_dtclean_where_query;
         
         $gft_dtclean_and=$gft_dtclean_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_dtclean_);

        }
        }elseif(isset($_GET["dtclean_mosyfilter"])){
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "dtclean_mosyfilter","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {
         $gft_dtclean_where_query="";
         $gft_dtclean="";

         if($_GET["dtclean_mosyfilter"]!=""){
          $gft_dtclean_where_query=(base64_decode($_GET["dtclean_mosyfilter"]));
          $gft_dtclean="WHERE ".$gft_dtclean_where_query;
         }
         
         
         $gft_dtclean_and=$gft_dtclean_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_dtclean_);

        }
        }else{
         $gft_dtclean="";
         $gft_dtclean_and="";
         $gft_dtclean_where_query="";
        }
       
    //************************************************* END  dtclean OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section expenses
  //************************************************* START  expenses OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize expenses edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['expenses_table_alert']))
              	{	
                  if(isset($expenses_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$expenses_uptoken="";

		if(isset($_GET["expenses_uptoken"]))
		{
		$expenses_uptoken=base64_decode($_GET["expenses_uptoken"]);
		}
        
        if(isset($_POST["expenses_uptoken"]))
		{
		$expenses_uptoken=base64_decode($_POST["expenses_uptoken"]);
		}
        //
        
          $expenses_alias_name="EXPENSES";

          if(isset($expenses_alias))
          {
             $expenses_alias_name=$expenses_alias;

          }
          
        //get single data record query with $expenses_uptoken
        
        ///$expenses_node=get_expenses("*", "WHERE primkey='$expenses_uptoken'", "r");
        
	
//************* START INSERT  expenses QUERY 
if(isset($_POST["expenses_insert_btn"])){
//------- begin expenses_arr_ins --> 
$expenses_arr_ins_=array(

"primkey"=>"NULL",
"transaction_id"=>magic_random_str(7),
"transaction_ref"=>"?",
"amount_paid"=>"?",
"transaction_type"=>"?",
"transaction_date"=>"?",
"month_year"=>"?",
"client_id"=>"?",
"received_by"=>"?",
"confirmed_by"=>"?",
"remark"=>"?",
"admin_id"=>"?",
"payment_mode"=>"?"

);
//===-- End expenses_arr_ins -->


          
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "insert","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {

              $expenses_validated_ins_str=$expenses_arr_ins_;

              if(isset($expenses_ins_inputs))
              {
                $expenses_validated_ins_str=$expenses_ins_inputs;	
              }

              if(empty($expenses_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$expenses_alias_name." request cannot be empty. Record not added");
              }else{

                $expenses_return_key=add_expenses($expenses_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $expenses_return_key; 

                      } 

                    }else{ 

                                    
                $expenses_custom_redir1=add_url_param ("expenses_uptoken", base64_encode($expenses_return_key), "");
                $expenses_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$expenses_custom_redir1);
                $expenses_custom_redir3=add_url_param ("expenses_table_alert", "expenses_added",$expenses_custom_redir2);
                
                ///echo magic_message($expenses_custom_redir1." -- ".$expenses_custom_redir2."--".$expenses_custom_redir3);
                
                $expenses_custom_redir=$expenses_custom_redir3;
                
               header('location:'.$expenses_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_expenses_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");
         
         }
      
}
//************* END  expenses INSERT QUERY 	
	

//************* START expenses  UPDATE QUERY 
if(isset($_POST["expenses_update_btn"])){
//------- begin expenses_arr_updt --> 
$expenses_arr_updt_=array(
"transaction_ref"=>"?",
"amount_paid"=>"?",
"transaction_type"=>"?",
"transaction_date"=>"?",
"month_year"=>"?",
"client_id"=>"?",
"received_by"=>"?",
"confirmed_by"=>"?",
"remark"=>"?",
"admin_id"=>"?",
"payment_mode"=>"?"

);
//===-- End expenses_arr_updt -->
                     
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "update","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {
         
            $expenses_validated_updt_str=$expenses_arr_updt_;

            if(isset($expenses_updt_inputs))
            {
              $expenses_validated_updt_str=$expenses_updt_inputs;	
            }

            if(empty($expenses_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$expenses_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$expenses_key_salt=initialize_expenses()["transaction_id"];
              update_expenses($expenses_validated_updt_str, "primkey='$expenses_uptoken' and transaction_id='$expenses_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $expenses_uptoken; 

                    } 

                  }else{ 

                $expenses_custom_redir1=add_url_param ("expenses_uptoken", base64_encode($expenses_uptoken), "");
                $expenses_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$expenses_custom_redir1);
                $expenses_custom_redir3=add_url_param ("expenses_table_alert", "expenses_updated",$expenses_custom_redir2);
                
                ///echo magic_message($expenses_custom_redir1." -- ".$expenses_custom_redir2."--".$expenses_custom_redir3);
                
                $expenses_custom_redir=$expenses_custom_redir3;
                
               header('location:'.$expenses_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_expenses_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");
         
         }

      

      
}
//************* END expenses  UPDATE QUERY 

    
    
      //== Start expenses delete record

      if(isset($_GET["deleteexpenses"]))
      {
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "super_delete_request","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_expenses_btn=magic_button_link("./".$current_file_url."?expenses_uptoken=".$_GET["expenses_uptoken"]."&conf_deleteexpenses&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_expenses_btn=magic_button_link("./".$current_file_url."?expenses_uptoken=".$_GET["expenses_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_expenses_btn." ".$cancel_del_expenses_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_expenses_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteexpenses"]))
      {
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "super_delete_confirm","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $expenses_del_key_salt=initialize_expenses()["transaction_id"];
      drop_expenses("primkey='$expenses_uptoken' and transaction_id='$expenses_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_expenses_);

      }
      }

      //== End expenses delete record  
    
       ///SELECT STRING FOR expenses============================
              
       if(isset($_POST["qexpenses_btn"])){
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "qexpenses_btn","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {
            $current_expenses_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_expenses_current_url=$current_expenses_url_params.'?qexpenses=';
            if (strpos($current_expenses_url_params, '?') !== false) {

                $clean_expenses_current_url=$current_expenses_url_params.'&qexpenses=';

            }
            if (strpos($current_expenses_url_params, '?qexpenses')) {

                $remove_expenses_old_token = substr($current_expenses_url_params, 0, strpos($current_expenses_url_params, "?qexpenses"));

                $clean_expenses_current_url=$remove_expenses_old_token.'?qexpenses=';

            }
            if(strpos($current_expenses_url_params, '&qexpenses')) {

                $remove_expenses_old_token = substr($current_expenses_url_params, 0, strpos($current_expenses_url_params, "&qexpenses"));

                $clean_expenses_current_url=$remove_expenses_old_token.'&qexpenses=';

            }
        $qexpenses_str=base64_encode($_POST["txt_expenses"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_expenses_current_url.($qexpenses_str);
            } 

          }else{ 
             header('location:'.$clean_expenses_current_url.($qexpenses_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_expenses_);

        }
        }
        $qexpenses="";
		if(isset($_GET["expenses_mosyfilter"]) && isset($_GET["qexpenses"])){
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "expenses_mosyfilter_n_query","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {
         $qexpenses=mmres(base64_decode($_GET["qexpenses"]));
         
         $gft_expenses_where_query="(`transaction_id` LIKE '%".$qexpenses."%' OR  `transaction_ref` LIKE '%".$qexpenses."%' OR  `amount_paid` LIKE '%".$qexpenses."%' OR  `transaction_type` LIKE '%".$qexpenses."%' OR  `transaction_date` LIKE '%".$qexpenses."%' OR  `month_year` LIKE '%".$qexpenses."%' OR  `client_id` LIKE '%".$qexpenses."%' OR  `received_by` LIKE '%".$qexpenses."%' OR  `confirmed_by` LIKE '%".$qexpenses."%' OR  `remark` LIKE '%".$qexpenses."%' OR  `admin_id` LIKE '%".$qexpenses."%' OR  `payment_mode` LIKE '%".$qexpenses."%')";
         
         if($_GET["expenses_mosyfilter"]!=""){
         
         $mosyfilter_expenses_queries_str=(base64_decode($_GET["expenses_mosyfilter"]));
        
         $gft_expenses_where_query="(`transaction_id` LIKE '%".$qexpenses."%' OR  `transaction_ref` LIKE '%".$qexpenses."%' OR  `amount_paid` LIKE '%".$qexpenses."%' OR  `transaction_type` LIKE '%".$qexpenses."%' OR  `transaction_date` LIKE '%".$qexpenses."%' OR  `month_year` LIKE '%".$qexpenses."%' OR  `client_id` LIKE '%".$qexpenses."%' OR  `received_by` LIKE '%".$qexpenses."%' OR  `confirmed_by` LIKE '%".$qexpenses."%' OR  `remark` LIKE '%".$qexpenses."%' OR  `admin_id` LIKE '%".$qexpenses."%' OR  `payment_mode` LIKE '%".$qexpenses."%') AND ".$mosyfilter_expenses_queries_str."";
         
         }
         
		 $gft_expenses="WHERE ".$gft_expenses_where_query;
         
         $gft_expenses_and=$gft_expenses_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_expenses_);
        }
        }elseif(isset($_GET["qexpenses"])){
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "get_qexpenses","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {
		 $qexpenses=mmres(base64_decode($_GET["qexpenses"]));
        
         $gft_expenses_where_query="(`transaction_id` LIKE '%".$qexpenses."%' OR  `transaction_ref` LIKE '%".$qexpenses."%' OR  `amount_paid` LIKE '%".$qexpenses."%' OR  `transaction_type` LIKE '%".$qexpenses."%' OR  `transaction_date` LIKE '%".$qexpenses."%' OR  `month_year` LIKE '%".$qexpenses."%' OR  `client_id` LIKE '%".$qexpenses."%' OR  `received_by` LIKE '%".$qexpenses."%' OR  `confirmed_by` LIKE '%".$qexpenses."%' OR  `remark` LIKE '%".$qexpenses."%' OR  `admin_id` LIKE '%".$qexpenses."%' OR  `payment_mode` LIKE '%".$qexpenses."%')";
         
         $gft_expenses="WHERE ".$gft_expenses_where_query;
         
         $gft_expenses_and=$gft_expenses_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_expenses_);

        }
        }elseif(isset($_GET["expenses_mosyfilter"])){
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "expenses_mosyfilter","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {
         $gft_expenses_where_query="";
         $gft_expenses="";

         if($_GET["expenses_mosyfilter"]!=""){
          $gft_expenses_where_query=(base64_decode($_GET["expenses_mosyfilter"]));
          $gft_expenses="WHERE ".$gft_expenses_where_query;
         }
         
         
         $gft_expenses_and=$gft_expenses_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_expenses_);

        }
        }else{
         $gft_expenses="";
         $gft_expenses_and="";
         $gft_expenses_where_query="";
        }
       
    //************************************************* END  expenses OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section files_and_photos
  //************************************************* START  files_and_photos OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize files_and_photos edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['files_and_photos_table_alert']))
              	{	
                  if(isset($files_and_photos_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$files_and_photos_uptoken="";

		if(isset($_GET["files_and_photos_uptoken"]))
		{
		$files_and_photos_uptoken=base64_decode($_GET["files_and_photos_uptoken"]);
		}
        
        if(isset($_POST["files_and_photos_uptoken"]))
		{
		$files_and_photos_uptoken=base64_decode($_POST["files_and_photos_uptoken"]);
		}
        //
        
          $files_and_photos_alias_name="FILES AND PHOTOS";

          if(isset($files_and_photos_alias))
          {
             $files_and_photos_alias_name=$files_and_photos_alias;

          }
          
        //get single data record query with $files_and_photos_uptoken
        
        ///$files_and_photos_node=get_files_and_photos("*", "WHERE primkey='$files_and_photos_uptoken'", "r");
        
	
//************* START INSERT  files_and_photos QUERY 
if(isset($_POST["files_and_photos_insert_btn"])){
//------- begin files_and_photos_arr_ins --> 
$files_and_photos_arr_ins_=array(

"primkey"=>"NULL",
"file_id"=>magic_random_str(7),
"file_path"=>"?",
"admin_id"=>"?"

);
//===-- End files_and_photos_arr_ins -->


          
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "insert","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {

              $files_and_photos_validated_ins_str=$files_and_photos_arr_ins_;

              if(isset($files_and_photos_ins_inputs))
              {
                $files_and_photos_validated_ins_str=$files_and_photos_ins_inputs;	
              }

              if(empty($files_and_photos_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$files_and_photos_alias_name." request cannot be empty. Record not added");
              }else{

                $files_and_photos_return_key=add_files_and_photos($files_and_photos_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $files_and_photos_return_key; 

                      } 

                    }else{ 

                                    
                $files_and_photos_custom_redir1=add_url_param ("files_and_photos_uptoken", base64_encode($files_and_photos_return_key), "");
                $files_and_photos_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$files_and_photos_custom_redir1);
                $files_and_photos_custom_redir3=add_url_param ("files_and_photos_table_alert", "files_and_photos_added",$files_and_photos_custom_redir2);
                
                ///echo magic_message($files_and_photos_custom_redir1." -- ".$files_and_photos_custom_redir2."--".$files_and_photos_custom_redir3);
                
                $files_and_photos_custom_redir=$files_and_photos_custom_redir3;
                
               header('location:'.$files_and_photos_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_files_and_photos_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");
         
         }
      
}
//************* END  files_and_photos INSERT QUERY 	
	

//************* START files_and_photos  UPDATE QUERY 
if(isset($_POST["files_and_photos_update_btn"])){
//------- begin files_and_photos_arr_updt --> 
$files_and_photos_arr_updt_=array(
"file_path"=>"?",
"admin_id"=>"?"

);
//===-- End files_and_photos_arr_updt -->
                     
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "update","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {
         
            $files_and_photos_validated_updt_str=$files_and_photos_arr_updt_;

            if(isset($files_and_photos_updt_inputs))
            {
              $files_and_photos_validated_updt_str=$files_and_photos_updt_inputs;	
            }

            if(empty($files_and_photos_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$files_and_photos_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$files_and_photos_key_salt=initialize_files_and_photos()["file_id"];
              update_files_and_photos($files_and_photos_validated_updt_str, "primkey='$files_and_photos_uptoken' and file_id='$files_and_photos_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $files_and_photos_uptoken; 

                    } 

                  }else{ 

                $files_and_photos_custom_redir1=add_url_param ("files_and_photos_uptoken", base64_encode($files_and_photos_uptoken), "");
                $files_and_photos_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$files_and_photos_custom_redir1);
                $files_and_photos_custom_redir3=add_url_param ("files_and_photos_table_alert", "files_and_photos_updated",$files_and_photos_custom_redir2);
                
                ///echo magic_message($files_and_photos_custom_redir1." -- ".$files_and_photos_custom_redir2."--".$files_and_photos_custom_redir3);
                
                $files_and_photos_custom_redir=$files_and_photos_custom_redir3;
                
               header('location:'.$files_and_photos_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_files_and_photos_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");
         
         }

      

      
}
//************* END files_and_photos  UPDATE QUERY 

    
    
      //== Start files_and_photos delete record

      if(isset($_GET["deletefiles_and_photos"]))
      {
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "super_delete_request","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_files_and_photos_btn=magic_button_link("./".$current_file_url."?files_and_photos_uptoken=".$_GET["files_and_photos_uptoken"]."&conf_deletefiles_and_photos&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_files_and_photos_btn=magic_button_link("./".$current_file_url."?files_and_photos_uptoken=".$_GET["files_and_photos_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_files_and_photos_btn." ".$cancel_del_files_and_photos_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_files_and_photos_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletefiles_and_photos"]))
      {
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "super_delete_confirm","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $files_and_photos_del_key_salt=initialize_files_and_photos()["file_id"];
      drop_files_and_photos("primkey='$files_and_photos_uptoken' and file_id='$files_and_photos_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_files_and_photos_);

      }
      }

      //== End files_and_photos delete record  
    
       ///SELECT STRING FOR files_and_photos============================
              
       if(isset($_POST["qfiles_and_photos_btn"])){
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "qfiles_and_photos_btn","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {
            $current_files_and_photos_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_files_and_photos_current_url=$current_files_and_photos_url_params.'?qfiles_and_photos=';
            if (strpos($current_files_and_photos_url_params, '?') !== false) {

                $clean_files_and_photos_current_url=$current_files_and_photos_url_params.'&qfiles_and_photos=';

            }
            if (strpos($current_files_and_photos_url_params, '?qfiles_and_photos')) {

                $remove_files_and_photos_old_token = substr($current_files_and_photos_url_params, 0, strpos($current_files_and_photos_url_params, "?qfiles_and_photos"));

                $clean_files_and_photos_current_url=$remove_files_and_photos_old_token.'?qfiles_and_photos=';

            }
            if(strpos($current_files_and_photos_url_params, '&qfiles_and_photos')) {

                $remove_files_and_photos_old_token = substr($current_files_and_photos_url_params, 0, strpos($current_files_and_photos_url_params, "&qfiles_and_photos"));

                $clean_files_and_photos_current_url=$remove_files_and_photos_old_token.'&qfiles_and_photos=';

            }
        $qfiles_and_photos_str=base64_encode($_POST["txt_files_and_photos"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_files_and_photos_current_url.($qfiles_and_photos_str);
            } 

          }else{ 
             header('location:'.$clean_files_and_photos_current_url.($qfiles_and_photos_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_files_and_photos_);

        }
        }
        $qfiles_and_photos="";
		if(isset($_GET["files_and_photos_mosyfilter"]) && isset($_GET["qfiles_and_photos"])){
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "files_and_photos_mosyfilter_n_query","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {
         $qfiles_and_photos=mmres(base64_decode($_GET["qfiles_and_photos"]));
         
         $gft_files_and_photos_where_query="(`file_id` LIKE '%".$qfiles_and_photos."%' OR  `file_path` LIKE '%".$qfiles_and_photos."%' OR  `admin_id` LIKE '%".$qfiles_and_photos."%')";
         
         if($_GET["files_and_photos_mosyfilter"]!=""){
         
         $mosyfilter_files_and_photos_queries_str=(base64_decode($_GET["files_and_photos_mosyfilter"]));
        
         $gft_files_and_photos_where_query="(`file_id` LIKE '%".$qfiles_and_photos."%' OR  `file_path` LIKE '%".$qfiles_and_photos."%' OR  `admin_id` LIKE '%".$qfiles_and_photos."%') AND ".$mosyfilter_files_and_photos_queries_str."";
         
         }
         
		 $gft_files_and_photos="WHERE ".$gft_files_and_photos_where_query;
         
         $gft_files_and_photos_and=$gft_files_and_photos_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_files_and_photos_);
        }
        }elseif(isset($_GET["qfiles_and_photos"])){
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "get_qfiles_and_photos","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {
		 $qfiles_and_photos=mmres(base64_decode($_GET["qfiles_and_photos"]));
        
         $gft_files_and_photos_where_query="(`file_id` LIKE '%".$qfiles_and_photos."%' OR  `file_path` LIKE '%".$qfiles_and_photos."%' OR  `admin_id` LIKE '%".$qfiles_and_photos."%')";
         
         $gft_files_and_photos="WHERE ".$gft_files_and_photos_where_query;
         
         $gft_files_and_photos_and=$gft_files_and_photos_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_files_and_photos_);

        }
        }elseif(isset($_GET["files_and_photos_mosyfilter"])){
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "files_and_photos_mosyfilter","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {
         $gft_files_and_photos_where_query="";
         $gft_files_and_photos="";

         if($_GET["files_and_photos_mosyfilter"]!=""){
          $gft_files_and_photos_where_query=(base64_decode($_GET["files_and_photos_mosyfilter"]));
          $gft_files_and_photos="WHERE ".$gft_files_and_photos_where_query;
         }
         
         
         $gft_files_and_photos_and=$gft_files_and_photos_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_files_and_photos_);

        }
        }else{
         $gft_files_and_photos="";
         $gft_files_and_photos_and="";
         $gft_files_and_photos_where_query="";
        }
       
    //************************************************* END  files_and_photos OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section inventory
  //************************************************* START  inventory OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize inventory edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['inventory_table_alert']))
              	{	
                  if(isset($inventory_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$inventory_uptoken="";

		if(isset($_GET["inventory_uptoken"]))
		{
		$inventory_uptoken=base64_decode($_GET["inventory_uptoken"]);
		}
        
        if(isset($_POST["inventory_uptoken"]))
		{
		$inventory_uptoken=base64_decode($_POST["inventory_uptoken"]);
		}
        //
        
          $inventory_alias_name="INVENTORY";

          if(isset($inventory_alias))
          {
             $inventory_alias_name=$inventory_alias;

          }
          
        //get single data record query with $inventory_uptoken
        
        ///$inventory_node=get_inventory("*", "WHERE primkey='$inventory_uptoken'", "r");
        
	
//************* START INSERT  inventory QUERY 
if(isset($_POST["inventory_insert_btn"])){
//------- begin inventory_arr_ins --> 
$inventory_arr_ins_=array(

"primkey"=>"NULL",
"item_id"=>magic_random_str(7),
"item_name"=>"?",
"buying_price"=>"?",
"description"=>"?",
"selling_price"=>"?"

);
//===-- End inventory_arr_ins -->


          
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "insert","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {

              $inventory_validated_ins_str=$inventory_arr_ins_;

              if(isset($inventory_ins_inputs))
              {
                $inventory_validated_ins_str=$inventory_ins_inputs;	
              }

              if(empty($inventory_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$inventory_alias_name." request cannot be empty. Record not added");
              }else{

                $inventory_return_key=add_inventory($inventory_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $inventory_return_key; 

                      } 

                    }else{ 

                                    
                $inventory_custom_redir1=add_url_param ("inventory_uptoken", base64_encode($inventory_return_key), "");
                $inventory_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$inventory_custom_redir1);
                $inventory_custom_redir3=add_url_param ("inventory_table_alert", "inventory_added",$inventory_custom_redir2);
                
                ///echo magic_message($inventory_custom_redir1." -- ".$inventory_custom_redir2."--".$inventory_custom_redir3);
                
                $inventory_custom_redir=$inventory_custom_redir3;
                
               header('location:'.$inventory_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_inventory_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");
         
         }
      
}
//************* END  inventory INSERT QUERY 	
	

//************* START inventory  UPDATE QUERY 
if(isset($_POST["inventory_update_btn"])){
//------- begin inventory_arr_updt --> 
$inventory_arr_updt_=array(
"item_name"=>"?",
"buying_price"=>"?",
"description"=>"?",
"selling_price"=>"?"

);
//===-- End inventory_arr_updt -->
                     
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "update","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {
         
            $inventory_validated_updt_str=$inventory_arr_updt_;

            if(isset($inventory_updt_inputs))
            {
              $inventory_validated_updt_str=$inventory_updt_inputs;	
            }

            if(empty($inventory_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$inventory_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$inventory_key_salt=initialize_inventory()["item_id"];
              update_inventory($inventory_validated_updt_str, "primkey='$inventory_uptoken' and item_id='$inventory_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $inventory_uptoken; 

                    } 

                  }else{ 

                $inventory_custom_redir1=add_url_param ("inventory_uptoken", base64_encode($inventory_uptoken), "");
                $inventory_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$inventory_custom_redir1);
                $inventory_custom_redir3=add_url_param ("inventory_table_alert", "inventory_updated",$inventory_custom_redir2);
                
                ///echo magic_message($inventory_custom_redir1." -- ".$inventory_custom_redir2."--".$inventory_custom_redir3);
                
                $inventory_custom_redir=$inventory_custom_redir3;
                
               header('location:'.$inventory_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_inventory_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");
         
         }

      

      
}
//************* END inventory  UPDATE QUERY 

    
    
      //== Start inventory delete record

      if(isset($_GET["deleteinventory"]))
      {
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "super_delete_request","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_inventory_btn=magic_button_link("./".$current_file_url."?inventory_uptoken=".$_GET["inventory_uptoken"]."&conf_deleteinventory&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_inventory_btn=magic_button_link("./".$current_file_url."?inventory_uptoken=".$_GET["inventory_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_inventory_btn." ".$cancel_del_inventory_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_inventory_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteinventory"]))
      {
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "super_delete_confirm","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $inventory_del_key_salt=initialize_inventory()["item_id"];
      drop_inventory("primkey='$inventory_uptoken' and item_id='$inventory_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_inventory_);

      }
      }

      //== End inventory delete record  
    
       ///SELECT STRING FOR inventory============================
              
       if(isset($_POST["qinventory_btn"])){
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "qinventory_btn","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {
            $current_inventory_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_inventory_current_url=$current_inventory_url_params.'?qinventory=';
            if (strpos($current_inventory_url_params, '?') !== false) {

                $clean_inventory_current_url=$current_inventory_url_params.'&qinventory=';

            }
            if (strpos($current_inventory_url_params, '?qinventory')) {

                $remove_inventory_old_token = substr($current_inventory_url_params, 0, strpos($current_inventory_url_params, "?qinventory"));

                $clean_inventory_current_url=$remove_inventory_old_token.'?qinventory=';

            }
            if(strpos($current_inventory_url_params, '&qinventory')) {

                $remove_inventory_old_token = substr($current_inventory_url_params, 0, strpos($current_inventory_url_params, "&qinventory"));

                $clean_inventory_current_url=$remove_inventory_old_token.'&qinventory=';

            }
        $qinventory_str=base64_encode($_POST["txt_inventory"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_inventory_current_url.($qinventory_str);
            } 

          }else{ 
             header('location:'.$clean_inventory_current_url.($qinventory_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_inventory_);

        }
        }
        $qinventory="";
		if(isset($_GET["inventory_mosyfilter"]) && isset($_GET["qinventory"])){
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "inventory_mosyfilter_n_query","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {
         $qinventory=mmres(base64_decode($_GET["qinventory"]));
         
         $gft_inventory_where_query="(`item_id` LIKE '%".$qinventory."%' OR  `item_name` LIKE '%".$qinventory."%' OR  `buying_price` LIKE '%".$qinventory."%' OR  `description` LIKE '%".$qinventory."%' OR  `selling_price` LIKE '%".$qinventory."%')";
         
         if($_GET["inventory_mosyfilter"]!=""){
         
         $mosyfilter_inventory_queries_str=(base64_decode($_GET["inventory_mosyfilter"]));
        
         $gft_inventory_where_query="(`item_id` LIKE '%".$qinventory."%' OR  `item_name` LIKE '%".$qinventory."%' OR  `buying_price` LIKE '%".$qinventory."%' OR  `description` LIKE '%".$qinventory."%' OR  `selling_price` LIKE '%".$qinventory."%') AND ".$mosyfilter_inventory_queries_str."";
         
         }
         
		 $gft_inventory="WHERE ".$gft_inventory_where_query;
         
         $gft_inventory_and=$gft_inventory_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_inventory_);
        }
        }elseif(isset($_GET["qinventory"])){
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "get_qinventory","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {
		 $qinventory=mmres(base64_decode($_GET["qinventory"]));
        
         $gft_inventory_where_query="(`item_id` LIKE '%".$qinventory."%' OR  `item_name` LIKE '%".$qinventory."%' OR  `buying_price` LIKE '%".$qinventory."%' OR  `description` LIKE '%".$qinventory."%' OR  `selling_price` LIKE '%".$qinventory."%')";
         
         $gft_inventory="WHERE ".$gft_inventory_where_query;
         
         $gft_inventory_and=$gft_inventory_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_inventory_);

        }
        }elseif(isset($_GET["inventory_mosyfilter"])){
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "inventory_mosyfilter","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {
         $gft_inventory_where_query="";
         $gft_inventory="";

         if($_GET["inventory_mosyfilter"]!=""){
          $gft_inventory_where_query=(base64_decode($_GET["inventory_mosyfilter"]));
          $gft_inventory="WHERE ".$gft_inventory_where_query;
         }
         
         
         $gft_inventory_and=$gft_inventory_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_inventory_);

        }
        }else{
         $gft_inventory="";
         $gft_inventory_and="";
         $gft_inventory_where_query="";
        }
       
    //************************************************* END  inventory OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section message_board
  //************************************************* START  message_board OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize message_board edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['message_board_table_alert']))
              	{	
                  if(isset($message_board_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$message_board_uptoken="";

		if(isset($_GET["message_board_uptoken"]))
		{
		$message_board_uptoken=base64_decode($_GET["message_board_uptoken"]);
		}
        
        if(isset($_POST["message_board_uptoken"]))
		{
		$message_board_uptoken=base64_decode($_POST["message_board_uptoken"]);
		}
        //
        
          $message_board_alias_name="MESSAGE BOARD";

          if(isset($message_board_alias))
          {
             $message_board_alias_name=$message_board_alias;

          }
          
        //get single data record query with $message_board_uptoken
        
        ///$message_board_node=get_message_board("*", "WHERE primkey='$message_board_uptoken'", "r");
        
	
//************* START INSERT  message_board QUERY 
if(isset($_POST["message_board_insert_btn"])){
//------- begin message_board_arr_ins --> 
$message_board_arr_ins_=array(

"primkey"=>"NULL",
"message_id"=>magic_random_str(7),
"from"=>"?",
"to"=>"?",
"msg_date"=>"?",
"admin"=>"?",
"read"=>"?",
"message"=>"?",
"msg_type"=>"?",
"subject"=>"?"

);
//===-- End message_board_arr_ins -->


          
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "insert","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {

              $message_board_validated_ins_str=$message_board_arr_ins_;

              if(isset($message_board_ins_inputs))
              {
                $message_board_validated_ins_str=$message_board_ins_inputs;	
              }

              if(empty($message_board_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$message_board_alias_name." request cannot be empty. Record not added");
              }else{

                $message_board_return_key=add_message_board($message_board_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $message_board_return_key; 

                      } 

                    }else{ 

                                    
                $message_board_custom_redir1=add_url_param ("message_board_uptoken", base64_encode($message_board_return_key), "");
                $message_board_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$message_board_custom_redir1);
                $message_board_custom_redir3=add_url_param ("message_board_table_alert", "message_board_added",$message_board_custom_redir2);
                
                ///echo magic_message($message_board_custom_redir1." -- ".$message_board_custom_redir2."--".$message_board_custom_redir3);
                
                $message_board_custom_redir=$message_board_custom_redir3;
                
               header('location:'.$message_board_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_message_board_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");
         
         }
      
}
//************* END  message_board INSERT QUERY 	
	

//************* START message_board  UPDATE QUERY 
if(isset($_POST["message_board_update_btn"])){
//------- begin message_board_arr_updt --> 
$message_board_arr_updt_=array(
"from"=>"?",
"to"=>"?",
"msg_date"=>"?",
"admin"=>"?",
"read"=>"?",
"message"=>"?",
"msg_type"=>"?",
"subject"=>"?"

);
//===-- End message_board_arr_updt -->
                     
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "update","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {
         
            $message_board_validated_updt_str=$message_board_arr_updt_;

            if(isset($message_board_updt_inputs))
            {
              $message_board_validated_updt_str=$message_board_updt_inputs;	
            }

            if(empty($message_board_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$message_board_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$message_board_key_salt=initialize_message_board()["message_id"];
              update_message_board($message_board_validated_updt_str, "primkey='$message_board_uptoken' and message_id='$message_board_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $message_board_uptoken; 

                    } 

                  }else{ 

                $message_board_custom_redir1=add_url_param ("message_board_uptoken", base64_encode($message_board_uptoken), "");
                $message_board_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$message_board_custom_redir1);
                $message_board_custom_redir3=add_url_param ("message_board_table_alert", "message_board_updated",$message_board_custom_redir2);
                
                ///echo magic_message($message_board_custom_redir1." -- ".$message_board_custom_redir2."--".$message_board_custom_redir3);
                
                $message_board_custom_redir=$message_board_custom_redir3;
                
               header('location:'.$message_board_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_message_board_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");
         
         }

      

      
}
//************* END message_board  UPDATE QUERY 

    
    
      //== Start message_board delete record

      if(isset($_GET["deletemessage_board"]))
      {
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "super_delete_request","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_message_board_btn=magic_button_link("./".$current_file_url."?message_board_uptoken=".$_GET["message_board_uptoken"]."&conf_deletemessage_board&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_message_board_btn=magic_button_link("./".$current_file_url."?message_board_uptoken=".$_GET["message_board_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_message_board_btn." ".$cancel_del_message_board_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_message_board_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemessage_board"]))
      {
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "super_delete_confirm","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $message_board_del_key_salt=initialize_message_board()["message_id"];
      drop_message_board("primkey='$message_board_uptoken' and message_id='$message_board_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_message_board_);

      }
      }

      //== End message_board delete record  
    
       ///SELECT STRING FOR message_board============================
              
       if(isset($_POST["qmessage_board_btn"])){
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "qmessage_board_btn","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {
            $current_message_board_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_message_board_current_url=$current_message_board_url_params.'?qmessage_board=';
            if (strpos($current_message_board_url_params, '?') !== false) {

                $clean_message_board_current_url=$current_message_board_url_params.'&qmessage_board=';

            }
            if (strpos($current_message_board_url_params, '?qmessage_board')) {

                $remove_message_board_old_token = substr($current_message_board_url_params, 0, strpos($current_message_board_url_params, "?qmessage_board"));

                $clean_message_board_current_url=$remove_message_board_old_token.'?qmessage_board=';

            }
            if(strpos($current_message_board_url_params, '&qmessage_board')) {

                $remove_message_board_old_token = substr($current_message_board_url_params, 0, strpos($current_message_board_url_params, "&qmessage_board"));

                $clean_message_board_current_url=$remove_message_board_old_token.'&qmessage_board=';

            }
        $qmessage_board_str=base64_encode($_POST["txt_message_board"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_message_board_current_url.($qmessage_board_str);
            } 

          }else{ 
             header('location:'.$clean_message_board_current_url.($qmessage_board_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_message_board_);

        }
        }
        $qmessage_board="";
		if(isset($_GET["message_board_mosyfilter"]) && isset($_GET["qmessage_board"])){
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "message_board_mosyfilter_n_query","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {
         $qmessage_board=mmres(base64_decode($_GET["qmessage_board"]));
         
         $gft_message_board_where_query="(`message_id` LIKE '%".$qmessage_board."%' OR  `from` LIKE '%".$qmessage_board."%' OR  `to` LIKE '%".$qmessage_board."%' OR  `msg_date` LIKE '%".$qmessage_board."%' OR  `admin` LIKE '%".$qmessage_board."%' OR  `read` LIKE '%".$qmessage_board."%' OR  `message` LIKE '%".$qmessage_board."%' OR  `msg_type` LIKE '%".$qmessage_board."%' OR  `subject` LIKE '%".$qmessage_board."%')";
         
         if($_GET["message_board_mosyfilter"]!=""){
         
         $mosyfilter_message_board_queries_str=(base64_decode($_GET["message_board_mosyfilter"]));
        
         $gft_message_board_where_query="(`message_id` LIKE '%".$qmessage_board."%' OR  `from` LIKE '%".$qmessage_board."%' OR  `to` LIKE '%".$qmessage_board."%' OR  `msg_date` LIKE '%".$qmessage_board."%' OR  `admin` LIKE '%".$qmessage_board."%' OR  `read` LIKE '%".$qmessage_board."%' OR  `message` LIKE '%".$qmessage_board."%' OR  `msg_type` LIKE '%".$qmessage_board."%' OR  `subject` LIKE '%".$qmessage_board."%') AND ".$mosyfilter_message_board_queries_str."";
         
         }
         
		 $gft_message_board="WHERE ".$gft_message_board_where_query;
         
         $gft_message_board_and=$gft_message_board_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_message_board_);
        }
        }elseif(isset($_GET["qmessage_board"])){
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "get_qmessage_board","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {
		 $qmessage_board=mmres(base64_decode($_GET["qmessage_board"]));
        
         $gft_message_board_where_query="(`message_id` LIKE '%".$qmessage_board."%' OR  `from` LIKE '%".$qmessage_board."%' OR  `to` LIKE '%".$qmessage_board."%' OR  `msg_date` LIKE '%".$qmessage_board."%' OR  `admin` LIKE '%".$qmessage_board."%' OR  `read` LIKE '%".$qmessage_board."%' OR  `message` LIKE '%".$qmessage_board."%' OR  `msg_type` LIKE '%".$qmessage_board."%' OR  `subject` LIKE '%".$qmessage_board."%')";
         
         $gft_message_board="WHERE ".$gft_message_board_where_query;
         
         $gft_message_board_and=$gft_message_board_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_message_board_);

        }
        }elseif(isset($_GET["message_board_mosyfilter"])){
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "message_board_mosyfilter","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {
         $gft_message_board_where_query="";
         $gft_message_board="";

         if($_GET["message_board_mosyfilter"]!=""){
          $gft_message_board_where_query=(base64_decode($_GET["message_board_mosyfilter"]));
          $gft_message_board="WHERE ".$gft_message_board_where_query;
         }
         
         
         $gft_message_board_and=$gft_message_board_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_message_board_);

        }
        }else{
         $gft_message_board="";
         $gft_message_board_and="";
         $gft_message_board_where_query="";
        }
       
    //************************************************* END  message_board OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section notes
  //************************************************* START  notes OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize notes edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['notes_table_alert']))
              	{	
                  if(isset($notes_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$notes_uptoken="";

		if(isset($_GET["notes_uptoken"]))
		{
		$notes_uptoken=base64_decode($_GET["notes_uptoken"]);
		}
        
        if(isset($_POST["notes_uptoken"]))
		{
		$notes_uptoken=base64_decode($_POST["notes_uptoken"]);
		}
        //
        
          $notes_alias_name="NOTES";

          if(isset($notes_alias))
          {
             $notes_alias_name=$notes_alias;

          }
          
        //get single data record query with $notes_uptoken
        
        ///$notes_node=get_notes("*", "WHERE primkey='$notes_uptoken'", "r");
        
	
//************* START INSERT  notes QUERY 
if(isset($_POST["notes_insert_btn"])){
//------- begin notes_arr_ins --> 
$notes_arr_ins_=array(

"primkey"=>"NULL",
"note_id"=>magic_random_str(7),
"title"=>"?",
"admin_id"=>"?",
"note"=>"?",
"note_date"=>"?",
"note_tag"=>"?",
"user_id"=>"?",
"client_id"=>"?"

);
//===-- End notes_arr_ins -->


          
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "insert","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {

              $notes_validated_ins_str=$notes_arr_ins_;

              if(isset($notes_ins_inputs))
              {
                $notes_validated_ins_str=$notes_ins_inputs;	
              }

              if(empty($notes_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$notes_alias_name." request cannot be empty. Record not added");
              }else{

                $notes_return_key=add_notes($notes_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $notes_return_key; 

                      } 

                    }else{ 

                                    
                $notes_custom_redir1=add_url_param ("notes_uptoken", base64_encode($notes_return_key), "");
                $notes_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$notes_custom_redir1);
                $notes_custom_redir3=add_url_param ("notes_table_alert", "notes_added",$notes_custom_redir2);
                
                ///echo magic_message($notes_custom_redir1." -- ".$notes_custom_redir2."--".$notes_custom_redir3);
                
                $notes_custom_redir=$notes_custom_redir3;
                
               header('location:'.$notes_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_notes_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");
         
         }
      
}
//************* END  notes INSERT QUERY 	
	

//************* START notes  UPDATE QUERY 
if(isset($_POST["notes_update_btn"])){
//------- begin notes_arr_updt --> 
$notes_arr_updt_=array(
"title"=>"?",
"admin_id"=>"?",
"note"=>"?",
"note_date"=>"?",
"note_tag"=>"?",
"user_id"=>"?",
"client_id"=>"?"

);
//===-- End notes_arr_updt -->
                     
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "update","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {
         
            $notes_validated_updt_str=$notes_arr_updt_;

            if(isset($notes_updt_inputs))
            {
              $notes_validated_updt_str=$notes_updt_inputs;	
            }

            if(empty($notes_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$notes_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$notes_key_salt=initialize_notes()["note_id"];
              update_notes($notes_validated_updt_str, "primkey='$notes_uptoken' and note_id='$notes_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $notes_uptoken; 

                    } 

                  }else{ 

                $notes_custom_redir1=add_url_param ("notes_uptoken", base64_encode($notes_uptoken), "");
                $notes_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$notes_custom_redir1);
                $notes_custom_redir3=add_url_param ("notes_table_alert", "notes_updated",$notes_custom_redir2);
                
                ///echo magic_message($notes_custom_redir1." -- ".$notes_custom_redir2."--".$notes_custom_redir3);
                
                $notes_custom_redir=$notes_custom_redir3;
                
               header('location:'.$notes_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_notes_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");
         
         }

      

      
}
//************* END notes  UPDATE QUERY 

    
    
      //== Start notes delete record

      if(isset($_GET["deletenotes"]))
      {
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "super_delete_request","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_notes_btn=magic_button_link("./".$current_file_url."?notes_uptoken=".$_GET["notes_uptoken"]."&conf_deletenotes&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_notes_btn=magic_button_link("./".$current_file_url."?notes_uptoken=".$_GET["notes_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_notes_btn." ".$cancel_del_notes_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_notes_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletenotes"]))
      {
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "super_delete_confirm","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $notes_del_key_salt=initialize_notes()["note_id"];
      drop_notes("primkey='$notes_uptoken' and note_id='$notes_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_notes_);

      }
      }

      //== End notes delete record  
    
       ///SELECT STRING FOR notes============================
              
       if(isset($_POST["qnotes_btn"])){
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "qnotes_btn","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {
            $current_notes_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_notes_current_url=$current_notes_url_params.'?qnotes=';
            if (strpos($current_notes_url_params, '?') !== false) {

                $clean_notes_current_url=$current_notes_url_params.'&qnotes=';

            }
            if (strpos($current_notes_url_params, '?qnotes')) {

                $remove_notes_old_token = substr($current_notes_url_params, 0, strpos($current_notes_url_params, "?qnotes"));

                $clean_notes_current_url=$remove_notes_old_token.'?qnotes=';

            }
            if(strpos($current_notes_url_params, '&qnotes')) {

                $remove_notes_old_token = substr($current_notes_url_params, 0, strpos($current_notes_url_params, "&qnotes"));

                $clean_notes_current_url=$remove_notes_old_token.'&qnotes=';

            }
        $qnotes_str=base64_encode($_POST["txt_notes"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_notes_current_url.($qnotes_str);
            } 

          }else{ 
             header('location:'.$clean_notes_current_url.($qnotes_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_notes_);

        }
        }
        $qnotes="";
		if(isset($_GET["notes_mosyfilter"]) && isset($_GET["qnotes"])){
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "notes_mosyfilter_n_query","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {
         $qnotes=mmres(base64_decode($_GET["qnotes"]));
         
         $gft_notes_where_query="(`note_id` LIKE '%".$qnotes."%' OR  `title` LIKE '%".$qnotes."%' OR  `admin_id` LIKE '%".$qnotes."%' OR  `note` LIKE '%".$qnotes."%' OR  `note_date` LIKE '%".$qnotes."%' OR  `note_tag` LIKE '%".$qnotes."%' OR  `user_id` LIKE '%".$qnotes."%' OR  `client_id` LIKE '%".$qnotes."%')";
         
         if($_GET["notes_mosyfilter"]!=""){
         
         $mosyfilter_notes_queries_str=(base64_decode($_GET["notes_mosyfilter"]));
        
         $gft_notes_where_query="(`note_id` LIKE '%".$qnotes."%' OR  `title` LIKE '%".$qnotes."%' OR  `admin_id` LIKE '%".$qnotes."%' OR  `note` LIKE '%".$qnotes."%' OR  `note_date` LIKE '%".$qnotes."%' OR  `note_tag` LIKE '%".$qnotes."%' OR  `user_id` LIKE '%".$qnotes."%' OR  `client_id` LIKE '%".$qnotes."%') AND ".$mosyfilter_notes_queries_str."";
         
         }
         
		 $gft_notes="WHERE ".$gft_notes_where_query;
         
         $gft_notes_and=$gft_notes_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_notes_);
        }
        }elseif(isset($_GET["qnotes"])){
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "get_qnotes","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {
		 $qnotes=mmres(base64_decode($_GET["qnotes"]));
        
         $gft_notes_where_query="(`note_id` LIKE '%".$qnotes."%' OR  `title` LIKE '%".$qnotes."%' OR  `admin_id` LIKE '%".$qnotes."%' OR  `note` LIKE '%".$qnotes."%' OR  `note_date` LIKE '%".$qnotes."%' OR  `note_tag` LIKE '%".$qnotes."%' OR  `user_id` LIKE '%".$qnotes."%' OR  `client_id` LIKE '%".$qnotes."%')";
         
         $gft_notes="WHERE ".$gft_notes_where_query;
         
         $gft_notes_and=$gft_notes_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_notes_);

        }
        }elseif(isset($_GET["notes_mosyfilter"])){
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "notes_mosyfilter","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {
         $gft_notes_where_query="";
         $gft_notes="";

         if($_GET["notes_mosyfilter"]!=""){
          $gft_notes_where_query=(base64_decode($_GET["notes_mosyfilter"]));
          $gft_notes="WHERE ".$gft_notes_where_query;
         }
         
         
         $gft_notes_and=$gft_notes_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_notes_);

        }
        }else{
         $gft_notes="";
         $gft_notes_and="";
         $gft_notes_where_query="";
        }
       
    //************************************************* END  notes OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section packages
  //************************************************* START  packages OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize packages edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['packages_table_alert']))
              	{	
                  if(isset($packages_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$packages_uptoken="";

		if(isset($_GET["packages_uptoken"]))
		{
		$packages_uptoken=base64_decode($_GET["packages_uptoken"]);
		}
        
        if(isset($_POST["packages_uptoken"]))
		{
		$packages_uptoken=base64_decode($_POST["packages_uptoken"]);
		}
        //
        
          $packages_alias_name="PACKAGES";

          if(isset($packages_alias))
          {
             $packages_alias_name=$packages_alias;

          }
          
        //get single data record query with $packages_uptoken
        
        ///$packages_node=get_packages("*", "WHERE primkey='$packages_uptoken'", "r");
        
	
//************* START INSERT  packages QUERY 
if(isset($_POST["packages_insert_btn"])){
//------- begin packages_arr_ins --> 
$packages_arr_ins_=array(

"primkey"=>"NULL",
"package_id"=>magic_random_str(7),
"package_name"=>"?",
"price"=>"?",
"description"=>"?",
"admin_id"=>"?"

);
//===-- End packages_arr_ins -->


          
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "insert","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {

              $packages_validated_ins_str=$packages_arr_ins_;

              if(isset($packages_ins_inputs))
              {
                $packages_validated_ins_str=$packages_ins_inputs;	
              }

              if(empty($packages_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$packages_alias_name." request cannot be empty. Record not added");
              }else{

                $packages_return_key=add_packages($packages_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $packages_return_key; 

                      } 

                    }else{ 

                                    
                $packages_custom_redir1=add_url_param ("packages_uptoken", base64_encode($packages_return_key), "");
                $packages_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$packages_custom_redir1);
                $packages_custom_redir3=add_url_param ("packages_table_alert", "packages_added",$packages_custom_redir2);
                
                ///echo magic_message($packages_custom_redir1." -- ".$packages_custom_redir2."--".$packages_custom_redir3);
                
                $packages_custom_redir=$packages_custom_redir3;
                
               header('location:'.$packages_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_packages_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");
         
         }
      
}
//************* END  packages INSERT QUERY 	
	

//************* START packages  UPDATE QUERY 
if(isset($_POST["packages_update_btn"])){
//------- begin packages_arr_updt --> 
$packages_arr_updt_=array(
"package_name"=>"?",
"price"=>"?",
"description"=>"?",
"admin_id"=>"?"

);
//===-- End packages_arr_updt -->
                     
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "update","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {
         
            $packages_validated_updt_str=$packages_arr_updt_;

            if(isset($packages_updt_inputs))
            {
              $packages_validated_updt_str=$packages_updt_inputs;	
            }

            if(empty($packages_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$packages_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$packages_key_salt=initialize_packages()["package_id"];
              update_packages($packages_validated_updt_str, "primkey='$packages_uptoken' and package_id='$packages_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $packages_uptoken; 

                    } 

                  }else{ 

                $packages_custom_redir1=add_url_param ("packages_uptoken", base64_encode($packages_uptoken), "");
                $packages_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$packages_custom_redir1);
                $packages_custom_redir3=add_url_param ("packages_table_alert", "packages_updated",$packages_custom_redir2);
                
                ///echo magic_message($packages_custom_redir1." -- ".$packages_custom_redir2."--".$packages_custom_redir3);
                
                $packages_custom_redir=$packages_custom_redir3;
                
               header('location:'.$packages_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_packages_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");
         
         }

      

      
}
//************* END packages  UPDATE QUERY 

    
    
      //== Start packages delete record

      if(isset($_GET["deletepackages"]))
      {
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "super_delete_request","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_packages_btn=magic_button_link("./".$current_file_url."?packages_uptoken=".$_GET["packages_uptoken"]."&conf_deletepackages&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_packages_btn=magic_button_link("./".$current_file_url."?packages_uptoken=".$_GET["packages_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_packages_btn." ".$cancel_del_packages_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_packages_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletepackages"]))
      {
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "super_delete_confirm","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $packages_del_key_salt=initialize_packages()["package_id"];
      drop_packages("primkey='$packages_uptoken' and package_id='$packages_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_packages_);

      }
      }

      //== End packages delete record  
    
       ///SELECT STRING FOR packages============================
              
       if(isset($_POST["qpackages_btn"])){
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "qpackages_btn","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {
            $current_packages_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_packages_current_url=$current_packages_url_params.'?qpackages=';
            if (strpos($current_packages_url_params, '?') !== false) {

                $clean_packages_current_url=$current_packages_url_params.'&qpackages=';

            }
            if (strpos($current_packages_url_params, '?qpackages')) {

                $remove_packages_old_token = substr($current_packages_url_params, 0, strpos($current_packages_url_params, "?qpackages"));

                $clean_packages_current_url=$remove_packages_old_token.'?qpackages=';

            }
            if(strpos($current_packages_url_params, '&qpackages')) {

                $remove_packages_old_token = substr($current_packages_url_params, 0, strpos($current_packages_url_params, "&qpackages"));

                $clean_packages_current_url=$remove_packages_old_token.'&qpackages=';

            }
        $qpackages_str=base64_encode($_POST["txt_packages"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_packages_current_url.($qpackages_str);
            } 

          }else{ 
             header('location:'.$clean_packages_current_url.($qpackages_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_packages_);

        }
        }
        $qpackages="";
		if(isset($_GET["packages_mosyfilter"]) && isset($_GET["qpackages"])){
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "packages_mosyfilter_n_query","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {
         $qpackages=mmres(base64_decode($_GET["qpackages"]));
         
         $gft_packages_where_query="(`package_id` LIKE '%".$qpackages."%' OR  `package_name` LIKE '%".$qpackages."%' OR  `price` LIKE '%".$qpackages."%' OR  `description` LIKE '%".$qpackages."%' OR  `admin_id` LIKE '%".$qpackages."%')";
         
         if($_GET["packages_mosyfilter"]!=""){
         
         $mosyfilter_packages_queries_str=(base64_decode($_GET["packages_mosyfilter"]));
        
         $gft_packages_where_query="(`package_id` LIKE '%".$qpackages."%' OR  `package_name` LIKE '%".$qpackages."%' OR  `price` LIKE '%".$qpackages."%' OR  `description` LIKE '%".$qpackages."%' OR  `admin_id` LIKE '%".$qpackages."%') AND ".$mosyfilter_packages_queries_str."";
         
         }
         
		 $gft_packages="WHERE ".$gft_packages_where_query;
         
         $gft_packages_and=$gft_packages_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_packages_);
        }
        }elseif(isset($_GET["qpackages"])){
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "get_qpackages","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {
		 $qpackages=mmres(base64_decode($_GET["qpackages"]));
        
         $gft_packages_where_query="(`package_id` LIKE '%".$qpackages."%' OR  `package_name` LIKE '%".$qpackages."%' OR  `price` LIKE '%".$qpackages."%' OR  `description` LIKE '%".$qpackages."%' OR  `admin_id` LIKE '%".$qpackages."%')";
         
         $gft_packages="WHERE ".$gft_packages_where_query;
         
         $gft_packages_and=$gft_packages_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_packages_);

        }
        }elseif(isset($_GET["packages_mosyfilter"])){
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "packages_mosyfilter","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {
         $gft_packages_where_query="";
         $gft_packages="";

         if($_GET["packages_mosyfilter"]!=""){
          $gft_packages_where_query=(base64_decode($_GET["packages_mosyfilter"]));
          $gft_packages="WHERE ".$gft_packages_where_query;
         }
         
         
         $gft_packages_and=$gft_packages_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_packages_);

        }
        }else{
         $gft_packages="";
         $gft_packages_and="";
         $gft_packages_where_query="";
        }
       
    //************************************************* END  packages OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section sqlpro_themes
  //************************************************* START  sqlpro_themes OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize sqlpro_themes edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['sqlpro_themes_table_alert']))
              	{	
                  if(isset($sqlpro_themes_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$sqlpro_themes_uptoken="";

		if(isset($_GET["sqlpro_themes_uptoken"]))
		{
		$sqlpro_themes_uptoken=base64_decode($_GET["sqlpro_themes_uptoken"]);
		}
        
        if(isset($_POST["sqlpro_themes_uptoken"]))
		{
		$sqlpro_themes_uptoken=base64_decode($_POST["sqlpro_themes_uptoken"]);
		}
        //
        
          $sqlpro_themes_alias_name="SQLPRO THEMES";

          if(isset($sqlpro_themes_alias))
          {
             $sqlpro_themes_alias_name=$sqlpro_themes_alias;

          }
          
        //get single data record query with $sqlpro_themes_uptoken
        
        ///$sqlpro_themes_node=get_sqlpro_themes("*", "WHERE webtemp_key='$sqlpro_themes_uptoken'", "r");
        
	
//************* START INSERT  sqlpro_themes QUERY 
if(isset($_POST["sqlpro_themes_insert_btn"])){
//------- begin sqlpro_themes_arr_ins --> 
$sqlpro_themes_arr_ins_=array(

"webtemp_key"=>"NULL",
"webtemp_name"=>magic_random_str(7),
"webtemp_id"=>"?",
"webtemp_skinclr"=>"?",
"webtemp_btnclr"=>"?",
"webtemp_gentxtclr"=>"?",
"webtemp_btntxtclr"=>"?",
"webtemp_url"=>"?",
"webtemp_bgimg"=>"?",
"site_id"=>"?",
"webtemp_contbg"=>"?",
"webtemp_conttxtclr"=>"?",
"webtemp_type"=>"?",
"owner"=>"?"

);
//===-- End sqlpro_themes_arr_ins -->


          
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "insert","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {

              $sqlpro_themes_validated_ins_str=$sqlpro_themes_arr_ins_;

              if(isset($sqlpro_themes_ins_inputs))
              {
                $sqlpro_themes_validated_ins_str=$sqlpro_themes_ins_inputs;	
              }

              if(empty($sqlpro_themes_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$sqlpro_themes_alias_name." request cannot be empty. Record not added");
              }else{

                $sqlpro_themes_return_key=add_sqlpro_themes($sqlpro_themes_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $sqlpro_themes_return_key; 

                      } 

                    }else{ 

                                    
                $sqlpro_themes_custom_redir1=add_url_param ("sqlpro_themes_uptoken", base64_encode($sqlpro_themes_return_key), "");
                $sqlpro_themes_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$sqlpro_themes_custom_redir1);
                $sqlpro_themes_custom_redir3=add_url_param ("sqlpro_themes_table_alert", "sqlpro_themes_added",$sqlpro_themes_custom_redir2);
                
                ///echo magic_message($sqlpro_themes_custom_redir1." -- ".$sqlpro_themes_custom_redir2."--".$sqlpro_themes_custom_redir3);
                
                $sqlpro_themes_custom_redir=$sqlpro_themes_custom_redir3;
                
               header('location:'.$sqlpro_themes_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_sqlpro_themes_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");
         
         }
      
}
//************* END  sqlpro_themes INSERT QUERY 	
	

//************* START sqlpro_themes  UPDATE QUERY 
if(isset($_POST["sqlpro_themes_update_btn"])){
//------- begin sqlpro_themes_arr_updt --> 
$sqlpro_themes_arr_updt_=array(
"webtemp_id"=>"?",
"webtemp_skinclr"=>"?",
"webtemp_btnclr"=>"?",
"webtemp_gentxtclr"=>"?",
"webtemp_btntxtclr"=>"?",
"webtemp_url"=>"?",
"webtemp_bgimg"=>"?",
"site_id"=>"?",
"webtemp_contbg"=>"?",
"webtemp_conttxtclr"=>"?",
"webtemp_type"=>"?",
"owner"=>"?"

);
//===-- End sqlpro_themes_arr_updt -->
                     
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "update","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {
         
            $sqlpro_themes_validated_updt_str=$sqlpro_themes_arr_updt_;

            if(isset($sqlpro_themes_updt_inputs))
            {
              $sqlpro_themes_validated_updt_str=$sqlpro_themes_updt_inputs;	
            }

            if(empty($sqlpro_themes_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$sqlpro_themes_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$sqlpro_themes_key_salt=initialize_sqlpro_themes()["webtemp_name"];
              update_sqlpro_themes($sqlpro_themes_validated_updt_str, "webtemp_key='$sqlpro_themes_uptoken' and webtemp_name='$sqlpro_themes_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $sqlpro_themes_uptoken; 

                    } 

                  }else{ 

                $sqlpro_themes_custom_redir1=add_url_param ("sqlpro_themes_uptoken", base64_encode($sqlpro_themes_uptoken), "");
                $sqlpro_themes_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$sqlpro_themes_custom_redir1);
                $sqlpro_themes_custom_redir3=add_url_param ("sqlpro_themes_table_alert", "sqlpro_themes_updated",$sqlpro_themes_custom_redir2);
                
                ///echo magic_message($sqlpro_themes_custom_redir1." -- ".$sqlpro_themes_custom_redir2."--".$sqlpro_themes_custom_redir3);
                
                $sqlpro_themes_custom_redir=$sqlpro_themes_custom_redir3;
                
               header('location:'.$sqlpro_themes_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_sqlpro_themes_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");
         
         }

      

      
}
//************* END sqlpro_themes  UPDATE QUERY 

    
    
      //== Start sqlpro_themes delete record

      if(isset($_GET["deletesqlpro_themes"]))
      {
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "super_delete_request","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_sqlpro_themes_btn=magic_button_link("./".$current_file_url."?sqlpro_themes_uptoken=".$_GET["sqlpro_themes_uptoken"]."&conf_deletesqlpro_themes&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_sqlpro_themes_btn=magic_button_link("./".$current_file_url."?sqlpro_themes_uptoken=".$_GET["sqlpro_themes_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_sqlpro_themes_btn." ".$cancel_del_sqlpro_themes_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_sqlpro_themes_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesqlpro_themes"]))
      {
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "super_delete_confirm","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $sqlpro_themes_del_key_salt=initialize_sqlpro_themes()["webtemp_name"];
      drop_sqlpro_themes("webtemp_key='$sqlpro_themes_uptoken' and webtemp_name='$sqlpro_themes_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_sqlpro_themes_);

      }
      }

      //== End sqlpro_themes delete record  
    
       ///SELECT STRING FOR sqlpro_themes============================
              
       if(isset($_POST["qsqlpro_themes_btn"])){
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "qsqlpro_themes_btn","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {
            $current_sqlpro_themes_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_sqlpro_themes_current_url=$current_sqlpro_themes_url_params.'?qsqlpro_themes=';
            if (strpos($current_sqlpro_themes_url_params, '?') !== false) {

                $clean_sqlpro_themes_current_url=$current_sqlpro_themes_url_params.'&qsqlpro_themes=';

            }
            if (strpos($current_sqlpro_themes_url_params, '?qsqlpro_themes')) {

                $remove_sqlpro_themes_old_token = substr($current_sqlpro_themes_url_params, 0, strpos($current_sqlpro_themes_url_params, "?qsqlpro_themes"));

                $clean_sqlpro_themes_current_url=$remove_sqlpro_themes_old_token.'?qsqlpro_themes=';

            }
            if(strpos($current_sqlpro_themes_url_params, '&qsqlpro_themes')) {

                $remove_sqlpro_themes_old_token = substr($current_sqlpro_themes_url_params, 0, strpos($current_sqlpro_themes_url_params, "&qsqlpro_themes"));

                $clean_sqlpro_themes_current_url=$remove_sqlpro_themes_old_token.'&qsqlpro_themes=';

            }
        $qsqlpro_themes_str=base64_encode($_POST["txt_sqlpro_themes"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_sqlpro_themes_current_url.($qsqlpro_themes_str);
            } 

          }else{ 
             header('location:'.$clean_sqlpro_themes_current_url.($qsqlpro_themes_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_sqlpro_themes_);

        }
        }
        $qsqlpro_themes="";
		if(isset($_GET["sqlpro_themes_mosyfilter"]) && isset($_GET["qsqlpro_themes"])){
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "sqlpro_themes_mosyfilter_n_query","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {
         $qsqlpro_themes=mmres(base64_decode($_GET["qsqlpro_themes"]));
         
         $gft_sqlpro_themes_where_query="(`webtemp_name` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_id` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_skinclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_btnclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_gentxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_btntxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_url` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_bgimg` LIKE '%".$qsqlpro_themes."%' OR  `site_id` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_contbg` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_conttxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_type` LIKE '%".$qsqlpro_themes."%' OR  `owner` LIKE '%".$qsqlpro_themes."%')";
         
         if($_GET["sqlpro_themes_mosyfilter"]!=""){
         
         $mosyfilter_sqlpro_themes_queries_str=(base64_decode($_GET["sqlpro_themes_mosyfilter"]));
        
         $gft_sqlpro_themes_where_query="(`webtemp_name` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_id` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_skinclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_btnclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_gentxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_btntxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_url` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_bgimg` LIKE '%".$qsqlpro_themes."%' OR  `site_id` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_contbg` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_conttxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_type` LIKE '%".$qsqlpro_themes."%' OR  `owner` LIKE '%".$qsqlpro_themes."%') AND ".$mosyfilter_sqlpro_themes_queries_str."";
         
         }
         
		 $gft_sqlpro_themes="WHERE ".$gft_sqlpro_themes_where_query;
         
         $gft_sqlpro_themes_and=$gft_sqlpro_themes_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_sqlpro_themes_);
        }
        }elseif(isset($_GET["qsqlpro_themes"])){
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "get_qsqlpro_themes","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {
		 $qsqlpro_themes=mmres(base64_decode($_GET["qsqlpro_themes"]));
        
         $gft_sqlpro_themes_where_query="(`webtemp_name` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_id` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_skinclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_btnclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_gentxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_btntxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_url` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_bgimg` LIKE '%".$qsqlpro_themes."%' OR  `site_id` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_contbg` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_conttxtclr` LIKE '%".$qsqlpro_themes."%' OR  `webtemp_type` LIKE '%".$qsqlpro_themes."%' OR  `owner` LIKE '%".$qsqlpro_themes."%')";
         
         $gft_sqlpro_themes="WHERE ".$gft_sqlpro_themes_where_query;
         
         $gft_sqlpro_themes_and=$gft_sqlpro_themes_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_sqlpro_themes_);

        }
        }elseif(isset($_GET["sqlpro_themes_mosyfilter"])){
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "sqlpro_themes_mosyfilter","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {
         $gft_sqlpro_themes_where_query="";
         $gft_sqlpro_themes="";

         if($_GET["sqlpro_themes_mosyfilter"]!=""){
          $gft_sqlpro_themes_where_query=(base64_decode($_GET["sqlpro_themes_mosyfilter"]));
          $gft_sqlpro_themes="WHERE ".$gft_sqlpro_themes_where_query;
         }
         
         
         $gft_sqlpro_themes_and=$gft_sqlpro_themes_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_sqlpro_themes_);

        }
        }else{
         $gft_sqlpro_themes="";
         $gft_sqlpro_themes_and="";
         $gft_sqlpro_themes_where_query="";
        }
       
    //************************************************* END  sqlpro_themes OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section stock_history
  //************************************************* START  stock_history OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize stock_history edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['stock_history_table_alert']))
              	{	
                  if(isset($stock_history_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$stock_history_uptoken="";

		if(isset($_GET["stock_history_uptoken"]))
		{
		$stock_history_uptoken=base64_decode($_GET["stock_history_uptoken"]);
		}
        
        if(isset($_POST["stock_history_uptoken"]))
		{
		$stock_history_uptoken=base64_decode($_POST["stock_history_uptoken"]);
		}
        //
        
          $stock_history_alias_name="STOCK HISTORY";

          if(isset($stock_history_alias))
          {
             $stock_history_alias_name=$stock_history_alias;

          }
          
        //get single data record query with $stock_history_uptoken
        
        ///$stock_history_node=get_stock_history("*", "WHERE primkey='$stock_history_uptoken'", "r");
        
	
//************* START INSERT  stock_history QUERY 
if(isset($_POST["stock_history_insert_btn"])){
//------- begin stock_history_arr_ins --> 
$stock_history_arr_ins_=array(

"primkey"=>"NULL",
"stocked"=>magic_random_str(7),
"amount"=>"?",
"stock_date"=>"?",
"supplier"=>"?",
"comment"=>"?",
"item_id"=>"?"

);
//===-- End stock_history_arr_ins -->


          
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "insert","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {

              $stock_history_validated_ins_str=$stock_history_arr_ins_;

              if(isset($stock_history_ins_inputs))
              {
                $stock_history_validated_ins_str=$stock_history_ins_inputs;	
              }

              if(empty($stock_history_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$stock_history_alias_name." request cannot be empty. Record not added");
              }else{

                $stock_history_return_key=add_stock_history($stock_history_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $stock_history_return_key; 

                      } 

                    }else{ 

                                    
                $stock_history_custom_redir1=add_url_param ("stock_history_uptoken", base64_encode($stock_history_return_key), "");
                $stock_history_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$stock_history_custom_redir1);
                $stock_history_custom_redir3=add_url_param ("stock_history_table_alert", "stock_history_added",$stock_history_custom_redir2);
                
                ///echo magic_message($stock_history_custom_redir1." -- ".$stock_history_custom_redir2."--".$stock_history_custom_redir3);
                
                $stock_history_custom_redir=$stock_history_custom_redir3;
                
               header('location:'.$stock_history_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_stock_history_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
         
         }
      
}
//************* END  stock_history INSERT QUERY 	
	

//************* START stock_history  UPDATE QUERY 
if(isset($_POST["stock_history_update_btn"])){
//------- begin stock_history_arr_updt --> 
$stock_history_arr_updt_=array(
"amount"=>"?",
"stock_date"=>"?",
"supplier"=>"?",
"comment"=>"?",
"item_id"=>"?"

);
//===-- End stock_history_arr_updt -->
                     
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "update","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
         
            $stock_history_validated_updt_str=$stock_history_arr_updt_;

            if(isset($stock_history_updt_inputs))
            {
              $stock_history_validated_updt_str=$stock_history_updt_inputs;	
            }

            if(empty($stock_history_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$stock_history_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$stock_history_key_salt=initialize_stock_history()["stocked"];
              update_stock_history($stock_history_validated_updt_str, "primkey='$stock_history_uptoken' and stocked='$stock_history_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $stock_history_uptoken; 

                    } 

                  }else{ 

                $stock_history_custom_redir1=add_url_param ("stock_history_uptoken", base64_encode($stock_history_uptoken), "");
                $stock_history_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$stock_history_custom_redir1);
                $stock_history_custom_redir3=add_url_param ("stock_history_table_alert", "stock_history_updated",$stock_history_custom_redir2);
                
                ///echo magic_message($stock_history_custom_redir1." -- ".$stock_history_custom_redir2."--".$stock_history_custom_redir3);
                
                $stock_history_custom_redir=$stock_history_custom_redir3;
                
               header('location:'.$stock_history_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_stock_history_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
         
         }

      

      
}
//************* END stock_history  UPDATE QUERY 

    
    
      //== Start stock_history delete record

      if(isset($_GET["deletestock_history"]))
      {
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "super_delete_request","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_stock_history_btn=magic_button_link("./".$current_file_url."?stock_history_uptoken=".$_GET["stock_history_uptoken"]."&conf_deletestock_history&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_stock_history_btn=magic_button_link("./".$current_file_url."?stock_history_uptoken=".$_GET["stock_history_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_stock_history_btn." ".$cancel_del_stock_history_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_stock_history_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletestock_history"]))
      {
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "super_delete_confirm","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $stock_history_del_key_salt=initialize_stock_history()["stocked"];
      drop_stock_history("primkey='$stock_history_uptoken' and stocked='$stock_history_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_stock_history_);

      }
      }

      //== End stock_history delete record  
    
       ///SELECT STRING FOR stock_history============================
              
       if(isset($_POST["qstock_history_btn"])){
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "qstock_history_btn","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
            $current_stock_history_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_stock_history_current_url=$current_stock_history_url_params.'?qstock_history=';
            if (strpos($current_stock_history_url_params, '?') !== false) {

                $clean_stock_history_current_url=$current_stock_history_url_params.'&qstock_history=';

            }
            if (strpos($current_stock_history_url_params, '?qstock_history')) {

                $remove_stock_history_old_token = substr($current_stock_history_url_params, 0, strpos($current_stock_history_url_params, "?qstock_history"));

                $clean_stock_history_current_url=$remove_stock_history_old_token.'?qstock_history=';

            }
            if(strpos($current_stock_history_url_params, '&qstock_history')) {

                $remove_stock_history_old_token = substr($current_stock_history_url_params, 0, strpos($current_stock_history_url_params, "&qstock_history"));

                $clean_stock_history_current_url=$remove_stock_history_old_token.'&qstock_history=';

            }
        $qstock_history_str=base64_encode($_POST["txt_stock_history"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_stock_history_current_url.($qstock_history_str);
            } 

          }else{ 
             header('location:'.$clean_stock_history_current_url.($qstock_history_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_stock_history_);

        }
        }
        $qstock_history="";
		if(isset($_GET["stock_history_mosyfilter"]) && isset($_GET["qstock_history"])){
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "stock_history_mosyfilter_n_query","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
         $qstock_history=mmres(base64_decode($_GET["qstock_history"]));
         
         $gft_stock_history_where_query="(`stocked` LIKE '%".$qstock_history."%' OR  `amount` LIKE '%".$qstock_history."%' OR  `stock_date` LIKE '%".$qstock_history."%' OR  `supplier` LIKE '%".$qstock_history."%' OR  `comment` LIKE '%".$qstock_history."%' OR  `item_id` LIKE '%".$qstock_history."%')";
         
         if($_GET["stock_history_mosyfilter"]!=""){
         
         $mosyfilter_stock_history_queries_str=(base64_decode($_GET["stock_history_mosyfilter"]));
        
         $gft_stock_history_where_query="(`stocked` LIKE '%".$qstock_history."%' OR  `amount` LIKE '%".$qstock_history."%' OR  `stock_date` LIKE '%".$qstock_history."%' OR  `supplier` LIKE '%".$qstock_history."%' OR  `comment` LIKE '%".$qstock_history."%' OR  `item_id` LIKE '%".$qstock_history."%') AND ".$mosyfilter_stock_history_queries_str."";
         
         }
         
		 $gft_stock_history="WHERE ".$gft_stock_history_where_query;
         
         $gft_stock_history_and=$gft_stock_history_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_stock_history_);
        }
        }elseif(isset($_GET["qstock_history"])){
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "get_qstock_history","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
		 $qstock_history=mmres(base64_decode($_GET["qstock_history"]));
        
         $gft_stock_history_where_query="(`stocked` LIKE '%".$qstock_history."%' OR  `amount` LIKE '%".$qstock_history."%' OR  `stock_date` LIKE '%".$qstock_history."%' OR  `supplier` LIKE '%".$qstock_history."%' OR  `comment` LIKE '%".$qstock_history."%' OR  `item_id` LIKE '%".$qstock_history."%')";
         
         $gft_stock_history="WHERE ".$gft_stock_history_where_query;
         
         $gft_stock_history_and=$gft_stock_history_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_stock_history_);

        }
        }elseif(isset($_GET["stock_history_mosyfilter"])){
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "stock_history_mosyfilter","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
         $gft_stock_history_where_query="";
         $gft_stock_history="";

         if($_GET["stock_history_mosyfilter"]!=""){
          $gft_stock_history_where_query=(base64_decode($_GET["stock_history_mosyfilter"]));
          $gft_stock_history="WHERE ".$gft_stock_history_where_query;
         }
         
         
         $gft_stock_history_and=$gft_stock_history_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_stock_history_);

        }
        }else{
         $gft_stock_history="";
         $gft_stock_history_and="";
         $gft_stock_history_where_query="";
        }
       
    //************************************************* END  stock_history OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section suppliers
  //************************************************* START  suppliers OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize suppliers edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['suppliers_table_alert']))
              	{	
                  if(isset($suppliers_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$suppliers_uptoken="";

		if(isset($_GET["suppliers_uptoken"]))
		{
		$suppliers_uptoken=base64_decode($_GET["suppliers_uptoken"]);
		}
        
        if(isset($_POST["suppliers_uptoken"]))
		{
		$suppliers_uptoken=base64_decode($_POST["suppliers_uptoken"]);
		}
        //
        
          $suppliers_alias_name="SUPPLIERS";

          if(isset($suppliers_alias))
          {
             $suppliers_alias_name=$suppliers_alias;

          }
          
        //get single data record query with $suppliers_uptoken
        
        ///$suppliers_node=get_suppliers("*", "WHERE primkey='$suppliers_uptoken'", "r");
        
	
//************* START INSERT  suppliers QUERY 
if(isset($_POST["suppliers_insert_btn"])){
//------- begin suppliers_arr_ins --> 
$suppliers_arr_ins_=array(

"primkey"=>"NULL",
"supp_id"=>magic_random_str(7),
"contact_person"=>"?",
"supplier_tel"=>"?",
"supplier_ocation"=>"?",
"business_name"=>"?",
"speciality"=>"?",
"comment"=>"?"

);
//===-- End suppliers_arr_ins -->


          
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "insert","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {

              $suppliers_validated_ins_str=$suppliers_arr_ins_;

              if(isset($suppliers_ins_inputs))
              {
                $suppliers_validated_ins_str=$suppliers_ins_inputs;	
              }

              if(empty($suppliers_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$suppliers_alias_name." request cannot be empty. Record not added");
              }else{

                $suppliers_return_key=add_suppliers($suppliers_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $suppliers_return_key; 

                      } 

                    }else{ 

                                    
                $suppliers_custom_redir1=add_url_param ("suppliers_uptoken", base64_encode($suppliers_return_key), "");
                $suppliers_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$suppliers_custom_redir1);
                $suppliers_custom_redir3=add_url_param ("suppliers_table_alert", "suppliers_added",$suppliers_custom_redir2);
                
                ///echo magic_message($suppliers_custom_redir1." -- ".$suppliers_custom_redir2."--".$suppliers_custom_redir3);
                
                $suppliers_custom_redir=$suppliers_custom_redir3;
                
               header('location:'.$suppliers_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_suppliers_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
         
         }
      
}
//************* END  suppliers INSERT QUERY 	
	

//************* START suppliers  UPDATE QUERY 
if(isset($_POST["suppliers_update_btn"])){
//------- begin suppliers_arr_updt --> 
$suppliers_arr_updt_=array(
"contact_person"=>"?",
"supplier_tel"=>"?",
"supplier_ocation"=>"?",
"business_name"=>"?",
"speciality"=>"?",
"comment"=>"?"

);
//===-- End suppliers_arr_updt -->
                     
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "update","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
         
            $suppliers_validated_updt_str=$suppliers_arr_updt_;

            if(isset($suppliers_updt_inputs))
            {
              $suppliers_validated_updt_str=$suppliers_updt_inputs;	
            }

            if(empty($suppliers_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$suppliers_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$suppliers_key_salt=initialize_suppliers()["supp_id"];
              update_suppliers($suppliers_validated_updt_str, "primkey='$suppliers_uptoken' and supp_id='$suppliers_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $suppliers_uptoken; 

                    } 

                  }else{ 

                $suppliers_custom_redir1=add_url_param ("suppliers_uptoken", base64_encode($suppliers_uptoken), "");
                $suppliers_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$suppliers_custom_redir1);
                $suppliers_custom_redir3=add_url_param ("suppliers_table_alert", "suppliers_updated",$suppliers_custom_redir2);
                
                ///echo magic_message($suppliers_custom_redir1." -- ".$suppliers_custom_redir2."--".$suppliers_custom_redir3);
                
                $suppliers_custom_redir=$suppliers_custom_redir3;
                
               header('location:'.$suppliers_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_suppliers_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
         
         }

      

      
}
//************* END suppliers  UPDATE QUERY 

    
    
      //== Start suppliers delete record

      if(isset($_GET["deletesuppliers"]))
      {
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "super_delete_request","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_suppliers_btn=magic_button_link("./".$current_file_url."?suppliers_uptoken=".$_GET["suppliers_uptoken"]."&conf_deletesuppliers&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_suppliers_btn=magic_button_link("./".$current_file_url."?suppliers_uptoken=".$_GET["suppliers_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_suppliers_btn." ".$cancel_del_suppliers_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_suppliers_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesuppliers"]))
      {
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "super_delete_confirm","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $suppliers_del_key_salt=initialize_suppliers()["supp_id"];
      drop_suppliers("primkey='$suppliers_uptoken' and supp_id='$suppliers_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_suppliers_);

      }
      }

      //== End suppliers delete record  
    
       ///SELECT STRING FOR suppliers============================
              
       if(isset($_POST["qsuppliers_btn"])){
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "qsuppliers_btn","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
            $current_suppliers_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_suppliers_current_url=$current_suppliers_url_params.'?qsuppliers=';
            if (strpos($current_suppliers_url_params, '?') !== false) {

                $clean_suppliers_current_url=$current_suppliers_url_params.'&qsuppliers=';

            }
            if (strpos($current_suppliers_url_params, '?qsuppliers')) {

                $remove_suppliers_old_token = substr($current_suppliers_url_params, 0, strpos($current_suppliers_url_params, "?qsuppliers"));

                $clean_suppliers_current_url=$remove_suppliers_old_token.'?qsuppliers=';

            }
            if(strpos($current_suppliers_url_params, '&qsuppliers')) {

                $remove_suppliers_old_token = substr($current_suppliers_url_params, 0, strpos($current_suppliers_url_params, "&qsuppliers"));

                $clean_suppliers_current_url=$remove_suppliers_old_token.'&qsuppliers=';

            }
        $qsuppliers_str=base64_encode($_POST["txt_suppliers"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_suppliers_current_url.($qsuppliers_str);
            } 

          }else{ 
             header('location:'.$clean_suppliers_current_url.($qsuppliers_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_suppliers_);

        }
        }
        $qsuppliers="";
		if(isset($_GET["suppliers_mosyfilter"]) && isset($_GET["qsuppliers"])){
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "suppliers_mosyfilter_n_query","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
         $qsuppliers=mmres(base64_decode($_GET["qsuppliers"]));
         
         $gft_suppliers_where_query="(`supp_id` LIKE '%".$qsuppliers."%' OR  `contact_person` LIKE '%".$qsuppliers."%' OR  `supplier_tel` LIKE '%".$qsuppliers."%' OR  `supplier_ocation` LIKE '%".$qsuppliers."%' OR  `business_name` LIKE '%".$qsuppliers."%' OR  `speciality` LIKE '%".$qsuppliers."%' OR  `comment` LIKE '%".$qsuppliers."%')";
         
         if($_GET["suppliers_mosyfilter"]!=""){
         
         $mosyfilter_suppliers_queries_str=(base64_decode($_GET["suppliers_mosyfilter"]));
        
         $gft_suppliers_where_query="(`supp_id` LIKE '%".$qsuppliers."%' OR  `contact_person` LIKE '%".$qsuppliers."%' OR  `supplier_tel` LIKE '%".$qsuppliers."%' OR  `supplier_ocation` LIKE '%".$qsuppliers."%' OR  `business_name` LIKE '%".$qsuppliers."%' OR  `speciality` LIKE '%".$qsuppliers."%' OR  `comment` LIKE '%".$qsuppliers."%') AND ".$mosyfilter_suppliers_queries_str."";
         
         }
         
		 $gft_suppliers="WHERE ".$gft_suppliers_where_query;
         
         $gft_suppliers_and=$gft_suppliers_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_suppliers_);
        }
        }elseif(isset($_GET["qsuppliers"])){
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "get_qsuppliers","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
		 $qsuppliers=mmres(base64_decode($_GET["qsuppliers"]));
        
         $gft_suppliers_where_query="(`supp_id` LIKE '%".$qsuppliers."%' OR  `contact_person` LIKE '%".$qsuppliers."%' OR  `supplier_tel` LIKE '%".$qsuppliers."%' OR  `supplier_ocation` LIKE '%".$qsuppliers."%' OR  `business_name` LIKE '%".$qsuppliers."%' OR  `speciality` LIKE '%".$qsuppliers."%' OR  `comment` LIKE '%".$qsuppliers."%')";
         
         $gft_suppliers="WHERE ".$gft_suppliers_where_query;
         
         $gft_suppliers_and=$gft_suppliers_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_suppliers_);

        }
        }elseif(isset($_GET["suppliers_mosyfilter"])){
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "suppliers_mosyfilter","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
         $gft_suppliers_where_query="";
         $gft_suppliers="";

         if($_GET["suppliers_mosyfilter"]!=""){
          $gft_suppliers_where_query=(base64_decode($_GET["suppliers_mosyfilter"]));
          $gft_suppliers="WHERE ".$gft_suppliers_where_query;
         }
         
         
         $gft_suppliers_and=$gft_suppliers_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_suppliers_);

        }
        }else{
         $gft_suppliers="";
         $gft_suppliers_and="";
         $gft_suppliers_where_query="";
        }
       
    //************************************************* END  suppliers OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section team
  //************************************************* START  team OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize team edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['team_table_alert']))
              	{	
                  if(isset($team_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$team_uptoken="";

		if(isset($_GET["team_uptoken"]))
		{
		$team_uptoken=base64_decode($_GET["team_uptoken"]);
		}
        
        if(isset($_POST["team_uptoken"]))
		{
		$team_uptoken=base64_decode($_POST["team_uptoken"]);
		}
        //
        
          $team_alias_name="TEAM";

          if(isset($team_alias))
          {
             $team_alias_name=$team_alias;

          }
          
        //get single data record query with $team_uptoken
        
        ///$team_node=get_team("*", "WHERE primkey='$team_uptoken'", "r");
        
	
//************* START INSERT  team QUERY 
if(isset($_POST["team_insert_btn"])){
//------- begin team_arr_ins --> 
$team_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"names"=>"?",
"username"=>"?",
"password"=>"?",
"role"=>"?",
"last_seen"=>"?",
"photo"=>"?",
"telephone"=>"?",
"admin_id"=>"?"

);
//===-- End team_arr_ins -->


          
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "insert","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {

              $team_validated_ins_str=$team_arr_ins_;

              if(isset($team_ins_inputs))
              {
                $team_validated_ins_str=$team_ins_inputs;	
              }

              if(empty($team_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$team_alias_name." request cannot be empty. Record not added");
              }else{

                $team_return_key=add_team($team_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $team_return_key; 

                      } 

                    }else{ 

                                    
                $team_custom_redir1=add_url_param ("team_uptoken", base64_encode($team_return_key), "");
                $team_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$team_custom_redir1);
                $team_custom_redir3=add_url_param ("team_table_alert", "team_added",$team_custom_redir2);
                
                ///echo magic_message($team_custom_redir1." -- ".$team_custom_redir2."--".$team_custom_redir3);
                
                $team_custom_redir=$team_custom_redir3;
                
               header('location:'.$team_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_team_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");
         
         }
      
}
//************* END  team INSERT QUERY 	
	

//************* START team  UPDATE QUERY 
if(isset($_POST["team_update_btn"])){
//------- begin team_arr_updt --> 
$team_arr_updt_=array(
"names"=>"?",
"username"=>"?",
"password"=>"?",
"role"=>"?",
"last_seen"=>"?",
"photo"=>"?",
"telephone"=>"?",
"admin_id"=>"?"

);
//===-- End team_arr_updt -->
                     
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "update","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
         
            $team_validated_updt_str=$team_arr_updt_;

            if(isset($team_updt_inputs))
            {
              $team_validated_updt_str=$team_updt_inputs;	
            }

            if(empty($team_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$team_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$team_key_salt=initialize_team()["user_id"];
              update_team($team_validated_updt_str, "primkey='$team_uptoken' and user_id='$team_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $team_uptoken; 

                    } 

                  }else{ 

                $team_custom_redir1=add_url_param ("team_uptoken", base64_encode($team_uptoken), "");
                $team_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$team_custom_redir1);
                $team_custom_redir3=add_url_param ("team_table_alert", "team_updated",$team_custom_redir2);
                
                ///echo magic_message($team_custom_redir1." -- ".$team_custom_redir2."--".$team_custom_redir3);
                
                $team_custom_redir=$team_custom_redir3;
                
               header('location:'.$team_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_team_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");
         
         }

      

      
}
//************* END team  UPDATE QUERY 

    

          //===-====Start upload team_photo 
          if(isset($_POST["btn_upload_team_photo"]))
          {
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "upload_team_photo","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_team_photo']['tmp_name'])){

				upload_team_photo('txt_team_photo', "primkey='$team_uptoken'");
                
                $team_custom_redir1=add_url_param ("team_uptoken", base64_encode($team_uptoken), "");
                $team_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$team_custom_redir1);
                $team_custom_redir3=add_url_param ("team_table_alert", "team_uploaded",$team_custom_redir2);
                
                ///echo magic_message($team_custom_redir1." -- ".$team_custom_redir2."--".$team_custom_redir3);
                
                $team_custom_redir=$team_custom_redir3;
                
               header('location:'.$team_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_team_);

          }
          }
          //===-====End upload team_photo  

			//drop team_photo image 
            
          if(isset($_GET["conf_deleteteam"]))
          {
          	if($team_node["photo"]!="")
            {
          	 unlink($team_node["photo"]);
            }
          }
          
          
    
      //== Start team delete record

      if(isset($_GET["deleteteam"]))
      {
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "super_delete_request","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_team_btn=magic_button_link("./".$current_file_url."?team_uptoken=".$_GET["team_uptoken"]."&conf_deleteteam&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_team_btn=magic_button_link("./".$current_file_url."?team_uptoken=".$_GET["team_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_team_btn." ".$cancel_del_team_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_team_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteteam"]))
      {
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "super_delete_confirm","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $team_del_key_salt=initialize_team()["user_id"];
      drop_team("primkey='$team_uptoken' and user_id='$team_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_team_);

      }
      }

      //== End team delete record  
    
       ///SELECT STRING FOR team============================
              
       if(isset($_POST["qteam_btn"])){
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "qteam_btn","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
            $current_team_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_team_current_url=$current_team_url_params.'?qteam=';
            if (strpos($current_team_url_params, '?') !== false) {

                $clean_team_current_url=$current_team_url_params.'&qteam=';

            }
            if (strpos($current_team_url_params, '?qteam')) {

                $remove_team_old_token = substr($current_team_url_params, 0, strpos($current_team_url_params, "?qteam"));

                $clean_team_current_url=$remove_team_old_token.'?qteam=';

            }
            if(strpos($current_team_url_params, '&qteam')) {

                $remove_team_old_token = substr($current_team_url_params, 0, strpos($current_team_url_params, "&qteam"));

                $clean_team_current_url=$remove_team_old_token.'&qteam=';

            }
        $qteam_str=base64_encode($_POST["txt_team"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_team_current_url.($qteam_str);
            } 

          }else{ 
             header('location:'.$clean_team_current_url.($qteam_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_team_);

        }
        }
        $qteam="";
		if(isset($_GET["team_mosyfilter"]) && isset($_GET["qteam"])){
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "team_mosyfilter_n_query","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
         $qteam=mmres(base64_decode($_GET["qteam"]));
         
         $gft_team_where_query="(`user_id` LIKE '%".$qteam."%' OR  `names` LIKE '%".$qteam."%' OR  `username` LIKE '%".$qteam."%' OR  `password` LIKE '%".$qteam."%' OR  `role` LIKE '%".$qteam."%' OR  `last_seen` LIKE '%".$qteam."%' OR  `photo` LIKE '%".$qteam."%' OR  `telephone` LIKE '%".$qteam."%' OR  `admin_id` LIKE '%".$qteam."%')";
         
         if($_GET["team_mosyfilter"]!=""){
         
         $mosyfilter_team_queries_str=(base64_decode($_GET["team_mosyfilter"]));
        
         $gft_team_where_query="(`user_id` LIKE '%".$qteam."%' OR  `names` LIKE '%".$qteam."%' OR  `username` LIKE '%".$qteam."%' OR  `password` LIKE '%".$qteam."%' OR  `role` LIKE '%".$qteam."%' OR  `last_seen` LIKE '%".$qteam."%' OR  `photo` LIKE '%".$qteam."%' OR  `telephone` LIKE '%".$qteam."%' OR  `admin_id` LIKE '%".$qteam."%') AND ".$mosyfilter_team_queries_str."";
         
         }
         
		 $gft_team="WHERE ".$gft_team_where_query;
         
         $gft_team_and=$gft_team_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_team_);
        }
        }elseif(isset($_GET["qteam"])){
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "get_qteam","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
		 $qteam=mmres(base64_decode($_GET["qteam"]));
        
         $gft_team_where_query="(`user_id` LIKE '%".$qteam."%' OR  `names` LIKE '%".$qteam."%' OR  `username` LIKE '%".$qteam."%' OR  `password` LIKE '%".$qteam."%' OR  `role` LIKE '%".$qteam."%' OR  `last_seen` LIKE '%".$qteam."%' OR  `photo` LIKE '%".$qteam."%' OR  `telephone` LIKE '%".$qteam."%' OR  `admin_id` LIKE '%".$qteam."%')";
         
         $gft_team="WHERE ".$gft_team_where_query;
         
         $gft_team_and=$gft_team_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_team_);

        }
        }elseif(isset($_GET["team_mosyfilter"])){
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "team_mosyfilter","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
         $gft_team_where_query="";
         $gft_team="";

         if($_GET["team_mosyfilter"]!=""){
          $gft_team_where_query=(base64_decode($_GET["team_mosyfilter"]));
          $gft_team="WHERE ".$gft_team_where_query;
         }
         
         
         $gft_team_and=$gft_team_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_team_);

        }
        }else{
         $gft_team="";
         $gft_team_and="";
         $gft_team_where_query="";
        }
       
    //************************************************* END  team OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section transactions
  //************************************************* START  transactions OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize transactions edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['transactions_table_alert']))
              	{	
                  if(isset($transactions_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$transactions_uptoken="";

		if(isset($_GET["transactions_uptoken"]))
		{
		$transactions_uptoken=base64_decode($_GET["transactions_uptoken"]);
		}
        
        if(isset($_POST["transactions_uptoken"]))
		{
		$transactions_uptoken=base64_decode($_POST["transactions_uptoken"]);
		}
        //
        
          $transactions_alias_name="TRANSACTIONS";

          if(isset($transactions_alias))
          {
             $transactions_alias_name=$transactions_alias;

          }
          
        //get single data record query with $transactions_uptoken
        
        ///$transactions_node=get_transactions("*", "WHERE primkey='$transactions_uptoken'", "r");
        
	
//************* START INSERT  transactions QUERY 
if(isset($_POST["transactions_insert_btn"])){
//------- begin transactions_arr_ins --> 
$transactions_arr_ins_=array(

"primkey"=>"NULL",
"transaction_id"=>magic_random_str(7),
"transaction_ref"=>"?",
"package_name"=>"?",
"package_price"=>"?",
"amount_paid"=>"?",
"balance"=>"?",
"transaction_type"=>"?",
"transaction_date"=>"?",
"month_year"=>"?",
"client_id"=>"?",
"received_by"=>"?",
"confirmed_by"=>"?",
"remark"=>"?",
"status"=>"?",
"admin_id"=>"?",
"old_balances"=>"?",
"total_due"=>"?",
"discount"=>"?",
"payment_mode"=>"?",
"installation_fee"=>"?",
"trxdate"=>"?",
"package_amount_paid"=>"?",
"othercharges_paid"=>"?",
"date_paid"=>"?"

);
//===-- End transactions_arr_ins -->


          
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "insert","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {

              $transactions_validated_ins_str=$transactions_arr_ins_;

              if(isset($transactions_ins_inputs))
              {
                $transactions_validated_ins_str=$transactions_ins_inputs;	
              }

              if(empty($transactions_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$transactions_alias_name." request cannot be empty. Record not added");
              }else{

                $transactions_return_key=add_transactions($transactions_validated_ins_str);
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $transactions_return_key; 

                      } 

                    }else{ 

                                    
                $transactions_custom_redir1=add_url_param ("transactions_uptoken", base64_encode($transactions_return_key), "");
                $transactions_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$transactions_custom_redir1);
                $transactions_custom_redir3=add_url_param ("transactions_table_alert", "transactions_added",$transactions_custom_redir2);
                
                ///echo magic_message($transactions_custom_redir1." -- ".$transactions_custom_redir2."--".$transactions_custom_redir3);
                
                $transactions_custom_redir=$transactions_custom_redir3;
                
               header('location:'.$transactions_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_transactions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");
         
         }
      
}
//************* END  transactions INSERT QUERY 	
	

//************* START transactions  UPDATE QUERY 
if(isset($_POST["transactions_update_btn"])){
//------- begin transactions_arr_updt --> 
$transactions_arr_updt_=array(
"transaction_ref"=>"?",
"package_name"=>"?",
"package_price"=>"?",
"amount_paid"=>"?",
"balance"=>"?",
"transaction_type"=>"?",
"transaction_date"=>"?",
"month_year"=>"?",
"client_id"=>"?",
"received_by"=>"?",
"confirmed_by"=>"?",
"remark"=>"?",
"status"=>"?",
"admin_id"=>"?",
"old_balances"=>"?",
"total_due"=>"?",
"discount"=>"?",
"payment_mode"=>"?",
"installation_fee"=>"?",
"trxdate"=>"?",
"package_amount_paid"=>"?",
"othercharges_paid"=>"?",
"date_paid"=>"?"

);
//===-- End transactions_arr_updt -->
                     
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "update","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {
         
            $transactions_validated_updt_str=$transactions_arr_updt_;

            if(isset($transactions_updt_inputs))
            {
              $transactions_validated_updt_str=$transactions_updt_inputs;	
            }

            if(empty($transactions_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$transactions_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$transactions_key_salt=initialize_transactions()["transaction_id"];
              update_transactions($transactions_validated_updt_str, "primkey='$transactions_uptoken' and transaction_id='$transactions_key_salt'");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $transactions_uptoken; 

                    } 

                  }else{ 

                $transactions_custom_redir1=add_url_param ("transactions_uptoken", base64_encode($transactions_uptoken), "");
                $transactions_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$transactions_custom_redir1);
                $transactions_custom_redir3=add_url_param ("transactions_table_alert", "transactions_updated",$transactions_custom_redir2);
                
                ///echo magic_message($transactions_custom_redir1." -- ".$transactions_custom_redir2."--".$transactions_custom_redir3);
                
                $transactions_custom_redir=$transactions_custom_redir3;
                
               header('location:'.$transactions_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_transactions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");
         
         }

      

      
}
//************* END transactions  UPDATE QUERY 

    
    
      //== Start transactions delete record

      if(isset($_GET["deletetransactions"]))
      {
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "super_delete_request","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_transactions_btn=magic_button_link("./".$current_file_url."?transactions_uptoken=".$_GET["transactions_uptoken"]."&conf_deletetransactions&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_transactions_btn=magic_button_link("./".$current_file_url."?transactions_uptoken=".$_GET["transactions_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_transactions_btn." ".$cancel_del_transactions_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_transactions_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletetransactions"]))
      {
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "super_delete_confirm","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $transactions_del_key_salt=initialize_transactions()["transaction_id"];
      drop_transactions("primkey='$transactions_uptoken' and transaction_id='$transactions_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_transactions_);

      }
      }

      //== End transactions delete record  
    
       ///SELECT STRING FOR transactions============================
              
       if(isset($_POST["qtransactions_btn"])){
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "qtransactions_btn","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {
            $current_transactions_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_transactions_current_url=$current_transactions_url_params.'?qtransactions=';
            if (strpos($current_transactions_url_params, '?') !== false) {

                $clean_transactions_current_url=$current_transactions_url_params.'&qtransactions=';

            }
            if (strpos($current_transactions_url_params, '?qtransactions')) {

                $remove_transactions_old_token = substr($current_transactions_url_params, 0, strpos($current_transactions_url_params, "?qtransactions"));

                $clean_transactions_current_url=$remove_transactions_old_token.'?qtransactions=';

            }
            if(strpos($current_transactions_url_params, '&qtransactions')) {

                $remove_transactions_old_token = substr($current_transactions_url_params, 0, strpos($current_transactions_url_params, "&qtransactions"));

                $clean_transactions_current_url=$remove_transactions_old_token.'&qtransactions=';

            }
        $qtransactions_str=base64_encode($_POST["txt_transactions"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_transactions_current_url.($qtransactions_str);
            } 

          }else{ 
             header('location:'.$clean_transactions_current_url.($qtransactions_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_transactions_);

        }
        }
        $qtransactions="";
		if(isset($_GET["transactions_mosyfilter"]) && isset($_GET["qtransactions"])){
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "transactions_mosyfilter_n_query","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {
         $qtransactions=mmres(base64_decode($_GET["qtransactions"]));
         
         $gft_transactions_where_query="(`transaction_id` LIKE '%".$qtransactions."%' OR  `transaction_ref` LIKE '%".$qtransactions."%' OR  `package_name` LIKE '%".$qtransactions."%' OR  `package_price` LIKE '%".$qtransactions."%' OR  `amount_paid` LIKE '%".$qtransactions."%' OR  `balance` LIKE '%".$qtransactions."%' OR  `transaction_type` LIKE '%".$qtransactions."%' OR  `transaction_date` LIKE '%".$qtransactions."%' OR  `month_year` LIKE '%".$qtransactions."%' OR  `client_id` LIKE '%".$qtransactions."%' OR  `received_by` LIKE '%".$qtransactions."%' OR  `confirmed_by` LIKE '%".$qtransactions."%' OR  `remark` LIKE '%".$qtransactions."%' OR  `status` LIKE '%".$qtransactions."%' OR  `admin_id` LIKE '%".$qtransactions."%' OR  `old_balances` LIKE '%".$qtransactions."%' OR  `total_due` LIKE '%".$qtransactions."%' OR  `discount` LIKE '%".$qtransactions."%' OR  `payment_mode` LIKE '%".$qtransactions."%' OR  `installation_fee` LIKE '%".$qtransactions."%' OR  `trxdate` LIKE '%".$qtransactions."%' OR  `package_amount_paid` LIKE '%".$qtransactions."%' OR  `othercharges_paid` LIKE '%".$qtransactions."%' OR  `date_paid` LIKE '%".$qtransactions."%')";
         
         if($_GET["transactions_mosyfilter"]!=""){
         
         $mosyfilter_transactions_queries_str=(base64_decode($_GET["transactions_mosyfilter"]));
        
         $gft_transactions_where_query="(`transaction_id` LIKE '%".$qtransactions."%' OR  `transaction_ref` LIKE '%".$qtransactions."%' OR  `package_name` LIKE '%".$qtransactions."%' OR  `package_price` LIKE '%".$qtransactions."%' OR  `amount_paid` LIKE '%".$qtransactions."%' OR  `balance` LIKE '%".$qtransactions."%' OR  `transaction_type` LIKE '%".$qtransactions."%' OR  `transaction_date` LIKE '%".$qtransactions."%' OR  `month_year` LIKE '%".$qtransactions."%' OR  `client_id` LIKE '%".$qtransactions."%' OR  `received_by` LIKE '%".$qtransactions."%' OR  `confirmed_by` LIKE '%".$qtransactions."%' OR  `remark` LIKE '%".$qtransactions."%' OR  `status` LIKE '%".$qtransactions."%' OR  `admin_id` LIKE '%".$qtransactions."%' OR  `old_balances` LIKE '%".$qtransactions."%' OR  `total_due` LIKE '%".$qtransactions."%' OR  `discount` LIKE '%".$qtransactions."%' OR  `payment_mode` LIKE '%".$qtransactions."%' OR  `installation_fee` LIKE '%".$qtransactions."%' OR  `trxdate` LIKE '%".$qtransactions."%' OR  `package_amount_paid` LIKE '%".$qtransactions."%' OR  `othercharges_paid` LIKE '%".$qtransactions."%' OR  `date_paid` LIKE '%".$qtransactions."%') AND ".$mosyfilter_transactions_queries_str."";
         
         }
         
		 $gft_transactions="WHERE ".$gft_transactions_where_query;
         
         $gft_transactions_and=$gft_transactions_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_transactions_);
        }
        }elseif(isset($_GET["qtransactions"])){
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "get_qtransactions","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {
		 $qtransactions=mmres(base64_decode($_GET["qtransactions"]));
        
         $gft_transactions_where_query="(`transaction_id` LIKE '%".$qtransactions."%' OR  `transaction_ref` LIKE '%".$qtransactions."%' OR  `package_name` LIKE '%".$qtransactions."%' OR  `package_price` LIKE '%".$qtransactions."%' OR  `amount_paid` LIKE '%".$qtransactions."%' OR  `balance` LIKE '%".$qtransactions."%' OR  `transaction_type` LIKE '%".$qtransactions."%' OR  `transaction_date` LIKE '%".$qtransactions."%' OR  `month_year` LIKE '%".$qtransactions."%' OR  `client_id` LIKE '%".$qtransactions."%' OR  `received_by` LIKE '%".$qtransactions."%' OR  `confirmed_by` LIKE '%".$qtransactions."%' OR  `remark` LIKE '%".$qtransactions."%' OR  `status` LIKE '%".$qtransactions."%' OR  `admin_id` LIKE '%".$qtransactions."%' OR  `old_balances` LIKE '%".$qtransactions."%' OR  `total_due` LIKE '%".$qtransactions."%' OR  `discount` LIKE '%".$qtransactions."%' OR  `payment_mode` LIKE '%".$qtransactions."%' OR  `installation_fee` LIKE '%".$qtransactions."%' OR  `trxdate` LIKE '%".$qtransactions."%' OR  `package_amount_paid` LIKE '%".$qtransactions."%' OR  `othercharges_paid` LIKE '%".$qtransactions."%' OR  `date_paid` LIKE '%".$qtransactions."%')";
         
         $gft_transactions="WHERE ".$gft_transactions_where_query;
         
         $gft_transactions_and=$gft_transactions_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_transactions_);

        }
        }elseif(isset($_GET["transactions_mosyfilter"])){
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "transactions_mosyfilter","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {
         $gft_transactions_where_query="";
         $gft_transactions="";

         if($_GET["transactions_mosyfilter"]!=""){
          $gft_transactions_where_query=(base64_decode($_GET["transactions_mosyfilter"]));
          $gft_transactions="WHERE ".$gft_transactions_where_query;
         }
         
         
         $gft_transactions_and=$gft_transactions_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_transactions_);

        }
        }else{
         $gft_transactions="";
         $gft_transactions_and="";
         $gft_transactions_where_query="";
        }
       
    //************************************************* END  transactions OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  

//<--ncgh-->

?>