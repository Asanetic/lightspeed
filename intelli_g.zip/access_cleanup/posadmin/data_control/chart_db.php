<?php 

$infolink_cms=$infolinkdb;


//===========================count card client_base_clients========================
; $client_base_clients_card_count_query=mysqli_query($mysqliconn, "SELECT COUNT(client_id)  FROM `$infolink_cms`.`client_base` WHERE account_status!='Inactive'");

 $client_base_clients_card_count_res=mysqli_fetch_array($client_base_clients_card_count_query);
//===========================count card client_base_clients========================


//===========================count card transactions_pending_payments========================
; $transactions_pending_payments_card_count_query=mysqli_query($mysqliconn, "SELECT COUNT(transaction_id)  FROM `$infolink_cms`.`transactions` WHERE status='Pending'  ");

 $transactions_pending_payments_card_count_res=mysqli_fetch_array($transactions_pending_payments_card_count_query);
//===========================count card transactions_pending_payments========================


//===========================sum card expenses_total_expenditure========================
 ; $expenses_total_expenditure_card_sum_query=mysqli_query($mysqliconn, "SELECT SUM(amount_paid) AS amount_paid_COUNT  FROM `$infolink_cms`.`expenses` ");

 $expenses_total_expenditure_card_sum_res=mysqli_fetch_array($expenses_total_expenditure_card_sum_query);
//===========================sum card expenses_total_expenditure========================


//===========================sum card expenses_expenditure_this_month========================
 $date_years=date("M-Y");; $expenses_expenditure_this_month_card_sum_query=mysqli_query($mysqliconn, "SELECT SUM(amount_paid) AS amount_paid_COUNT  FROM `$infolink_cms`.`expenses` WHERE  month_year='$date_years'");

 $expenses_expenditure_this_month_card_sum_res=mysqli_fetch_array($expenses_expenditure_this_month_card_sum_query);
//===========================sum card expenses_expenditure_this_month========================


//===========================sum card transactions_payments_this_month========================
 $date_years=date("M-Y");; $transactions_payments_this_month_card_sum_query=mysqli_query($mysqliconn, "SELECT SUM(package_amount_paid) AS amount_paid_COUNT  FROM `$infolink_cms`.`transactions` WHERE  month_year='$date_years'");

 $transactions_payments_this_month_card_sum_res=mysqli_fetch_array($transactions_payments_this_month_card_sum_query);
//===========================sum card transactions_payments_this_month========================


//===========================sum card transactions_total_payments========================
 $date_years=date("M-Y");; $transactions_total_payments_card_sum_query=mysqli_query($mysqliconn, "SELECT SUM(package_amount_paid) AS amount_paid_COUNT  FROM `$infolink_cms`.`transactions` ");

 $transactions_total_payments_card_sum_res=mysqli_fetch_array($transactions_total_payments_card_sum_query);
//===========================sum card transactions_total_payments========================

//============newdbcard_query=============


//===========================Chart SUM tile card transactions_payments_by_status========================
; $amount_paid_transactions_status_payments_by_status_sumquery=mysqli_query($mysqliconn, "SELECT SUM(package_amount_paid) AS amount_paid_sum,  status   FROM `$infolink_cms`.`transactions`   GROUP BY status ");
//===========================Chart SUM tile  card transactions========================


//===========================Chart SUM tile card expenses_expenditure_by_tag========================
; $amount_paid_expenses_transaction_id_expenditure_by_tag_sumquery=mysqli_query($mysqliconn, "SELECT SUM(amount_paid) AS amount_paid_sum,  transaction_type   FROM `$infolink_cms`.`expenses`   GROUP BY transaction_type ");
//===========================Chart SUM tile  card expenses========================


//===========================Chart SUM tile card transactions_payments_by_month========================
$date_years=date("M-Y");; $amount_paid_transactions_month_year_payments_by_month_sumquery=mysqli_query($mysqliconn, "SELECT SUM(package_amount_paid) AS amount_paid_sum,  month_year   FROM `$infolink_cms`.`transactions`  WHERE  month_year='$date_years' GROUP BY month_year ");
//===========================Chart SUM tile  card transactions========================


//===========================Chart SUM tile card transactions_transactions_by_package========================
; $amount_paid_transactions_package_name_transactions_by_package_sumquery=mysqli_query($mysqliconn, "SELECT SUM(package_amount_paid) AS amount_paid_sum,  package_name   FROM `$infolink_cms`.`transactions`  GROUP BY package_name ");
//===========================Chart SUM tile  card transactions========================

//============newdbcard_query_chart=============

?>
  
  
  