<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


 $parent_path=[
'http://localhost/mosy/infolinkv2/',
//{{next_root_str}}
];

$active_parent_dir=date('dmyhisa');
if(isset($_SESSION['active_parent_dir'])){
 $active_parent_dir=$_SESSION['active_parent_dir'];
 ///echo $active_parent_dir;
}
$access_arr=[

    ///start access clearance array for $active_parent_dir.'client_base_list.php
    $active_parent_dir.'client_base_list.php'=>
      [
      'client_base'=>['select','qclient_base_btn','get_qclient_base','{{next_client_base_list.php_client_base}}'],
        //next_client_base_list.php_access

      ],
      ///end access clearance array for $active_parent_dir.'client_base_list.php

      
    ///start access clearance array for $active_parent_dir.'client_base_profile.php
    $active_parent_dir.'client_base_profile.php'=>
      [
      'client_base'=>['select','{{next_client_base_profile.php_client_base}}'],
        //next_client_base_profile.php_access

      ],
      ///end access clearance array for $active_parent_dir.'client_base_profile.php

      
    ///start access clearance array for $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php
    $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php'=>
      [
      'team'=>['qddata','select','{{next_load_preview_iframe_23_01_21_438pm.php_team}}'],
        
      'client_base'=>['select','update','{{next_load_preview_iframe_23_01_21_438pm.php_client_base}}'],
      
      'packages'=>['qdata','select','{{next_load_preview_iframe_23_01_21_438pm.php_packages}}'],
      
      'transactions'=>['qdata','select','{{next_load_preview_iframe_23_01_21_438pm.php_transactions}}'],
      
      'message_board'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_message_board}}'],
      //next_load_preview_iframe_23_01_21_438pm.php_access

      ],
      ///end access clearance array for $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php

      
    ///start access clearance array for $active_parent_dir.'overdue_panel.php
    $active_parent_dir.'overdue_panel.php'=>
      [
      'client_base'=>['select','qclient_base_btn','get_qclient_base','update','{{next_overdue_panel.php_client_base}}'],
        
      'transactions'=>['select','{{next_overdue_panel.php_transactions}}'],
      
      'packages'=>['qdata','select','{{next_overdue_panel.php_packages}}'],
      
      'message_board'=>['insert','{{next_overdue_panel.php_message_board}}'],
      //next_overdue_panel.php_access

      ],
      ///end access clearance array for $active_parent_dir.'overdue_panel.php

      
    ///start access clearance array for $active_parent_dir.'message_board_list.php
    $active_parent_dir.'message_board_list.php'=>
      [
      'message_board'=>['select','super_delete_request','super_delete_confirm','drop_data','{{next_message_board_list.php_message_board}}'],
        //next_message_board_list.php_access

      ],
      ///end access clearance array for $active_parent_dir.'message_board_list.php

      
    ///start access clearance array for $active_parent_dir.'message_board_profile.php
    $active_parent_dir.'message_board_profile.php'=>
      [
      'message_board'=>['select','super_delete_request','{{next_message_board_profile.php_message_board}}'],
        //next_message_board_profile.php_access

      ],
      ///end access clearance array for $active_parent_dir.'message_board_profile.php

      
    ///start access clearance array for $active_parent_dir.'ajaxreqhandler.php
    $active_parent_dir.'ajaxreqhandler.php'=>
      [
      'message_board'=>['insert','{{next_ajaxreqhandler.php_message_board}}'],
        //next_ajaxreqhandler.php_access

      ],
      ///end access clearance array for $active_parent_dir.'ajaxreqhandler.php

      //{{next_file_block}}







];
?>