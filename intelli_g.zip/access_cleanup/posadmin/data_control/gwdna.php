<?php
$gwdna_file="./data_control/gw_access.php";
$access_trail_file='./acess_trail.php';
$entry_attampts_log='./data_control/hacklog.txt';

if (!file_exists($gwdna_file))
{
   
  magic_write_to_file($gwdna_file, '<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

'.PHP_EOL.' $parent_path=['.PHP_EOL.'//{{next_root_str}}'.PHP_EOL.'];'.PHP_EOL.PHP_EOL."\$active_parent_dir=date('dmyhisa');".PHP_EOL."if(isset(\$_SESSION['active_parent_dir'])){".PHP_EOL." \$active_parent_dir=\$_SESSION['active_parent_dir'];".PHP_EOL." ///echo \$active_parent_dir;".PHP_EOL."}".PHP_EOL."\$access_arr=[".PHP_EOL."//{{next_file_block}}".PHP_EOL."];".PHP_EOL.'?>');
   
}

if (!file_exists($entry_attampts_log)){ magic_write_to_file($entry_attampts_log, "{{next_log}}");};
                                       
include($gwdna_file);
$new_access_arr=$access_arr;
$roots_array=$parent_path;
$register_new_access='yes';
$drop_cache_session='';
$access_type="open";

///print_r($new_access_arr[$file_url][$function]);
////////////////////////====================================  authorize check  ==================================================

function gw_oauth($table=null, $link_src,$function,$options)
{
  global $new_access_arr;
  global $access_type;
  global $roots_array;
  global $register_new_access;
  global $entry_attampts_log;
  
  $pos = strpos($link_src, "?");
  $link = substr($link_src, 0, $pos);
  if($link=='')
  {
    $link=$link_src;
  }
  $full_link=$link;
  
  $parentdir=dirname($full_link)."/";

  $basename=basename($full_link);

  
  if (strpos($basename, ".php") === false) 
  {

    $basename=$basename.".php";

  }

  $full_comb_link=$parentdir.$basename;  
  $register_url_key="\$active_parent_dir.'".$basename."";
  
  $lock_status='{"response":"0000", "response_message":"Invalid request. Request doesnt meet the required conditions"}';
  $register_state=0;
  
  if($access_type=='open')
  {
    
    $lock_status='{"response":"ok", "response_message":"Open Access Granted"}';
    
  }else{
            
  if(in_array($parentdir,$roots_array))
  {  
      $_SESSION['active_parent_dir']=$parentdir;

    if(isset($new_access_arr[$full_comb_link]))
    {
          

       if(isset($new_access_arr[$full_comb_link][$function]))
	   {
         if(in_array($options, $new_access_arr[$full_comb_link][$function]))
         {
           $lock_status='{"response":"ok", "response_message":"'.$full_link.' access '.$function.' for '.$options.' option access granted", "request_string":" '.$link_src.' '.$function.' '.$options.' '.$full_comb_link.'"}';
           
         }else{
          
    $lock_status='{"response":"access denied", "response_message":"'.$full_link.' access '.$function.' for '.$options.' option access denied. Reason : OPTION '.$options.' NOT AVAILABLE FOR '.$full_link.'.", "request_string":" '.$link_src.', '.$function.', '.$options.', '.$full_comb_link.'"}';
           if($register_new_access=='yes')
           {
      		register_gw_url($register_url_key, $function, $options);  
           }

           magic_replace_file_contents($entry_attampts_log, '{{next_log}}', $lock_status.PHP_EOL."{{next_log}}");

         }
       }else{
                   
    $lock_status='{"response":"access denied", "response_message":"'.$full_link.' access '.$function.' for '.$options.' option access denied. Reason : FUNCTION '.$function.' NOT AVAILABLE FOR '.$full_link.'.", "request_string":" '.$link_src.', '.$function.', '.$options.', '.$full_comb_link.'"}';
         if($register_new_access=='yes')
         {
      		register_gw_url($register_url_key, $function, $options);  
         }

         magic_replace_file_contents($entry_attampts_log, '{{next_log}}', $lock_status.PHP_EOL."{{next_log}}");

       }

    }else{
            
    $lock_status='{"response":"access denied", "response_message":"'.$full_link.' access '.$function.' for '.$options.' option access denied. Reason : INVALID REQUEST URL.", "request_string":" '.$link_src.', '.$function.', '.$options.', '.$full_comb_link.'"}';
      
      if($register_new_access=='yes')
      {
      		register_gw_url($register_url_key, $function, $options);  
      }
                 
      magic_replace_file_contents($entry_attampts_log, '{{next_log}}', $lock_status.PHP_EOL."{{next_log}}");


    }
  }else{
         
    $lock_status='{"response":"access denied", "response_message":"'.$full_link.' access '.$function.' for '.$options.' option access denied. Reason : INVALID ROOT DOMAIN OR PARENT DIRECTORY.", "request_string":" '.$link_src.', '.$function.', '.$options.', '.$full_comb_link.'"}';
    
      if($register_new_access=='yes')
      {
        register_gw_root($parentdir);  
      }
  }

  }
  

 // echo  " Lock status === > ".$lock_status;
    return $lock_status;

}

function register_gw_root($root)
{
  global $gwdna_file;
  global $roots_array;
  
  if(!in_array($root, $roots_array)){
    
      
  $prepared_root="'".$root."',"."".PHP_EOL."//{{next_root_str}}";

  magic_replace_file_contents($gwdna_file, "//{{next_root_str}}", $prepared_root);
    
  }


  
}

function register_gw_url($file_url, $function, $options)
{ 
  global $gwdna_file;
  global $new_access_arr; 
  global $drop_cache_session;
  global $access_trail_file;
  
  
  $access_trail_file_str='<?php
ob_start();
include("./data_control/conn.php");
include("./data_control/phpmagicbits.php");
include("./data_control/gwdna.php");

  //{{next_gw_oauth}}
    
  ?>  
  ';
  
  $next_gw_fun_str='//{{next_gw_oauth}}';
  
  if(!file_exists($access_trail_file))
  {
    magic_write_to_file($access_trail_file, $access_trail_file_str);
  }
   
  $check_url_key=file_get_contents($gwdna_file);
  $url_key="".$file_url."'=>";
  $replacer_str="";
  $new_security_block="";

  $register_parent=date("dmyhisa");

  if(isset($_SESSION['active_parent_dir'])){
   $register_parent=$_SESSION['active_parent_dir'];
  }
    
  $url_string_node=explode(".'", $file_url)[1];
  
  $working_url=$register_parent.$url_string_node;
  
  $trail_function='gw_oauth("tbl", "'.$working_url.'","'.$function.'","'.$options.'");'.PHP_EOL.$next_gw_fun_str;
  
  
   if($drop_cache_session=='yes')
   {
             
     unset($_SESSION[$url_string_node."-". $function."-".$options]);
     
   }

              
   if(isset($_SESSION[$url_string_node."-". $function."-".$options]))
   {

     //echo " session ".$url_string_node."-". $function."-".$options." is set ".$_SESSION[$url_string_node."-". $function."-".$options];
     
     $curr_time=date("d-m-Y h:i:s A");
     
     //echo " ".$_SESSION[$url_string_node."-". $function."-".$options]." -- ".$curr_time;
     

     $timediff_in_sec=strtotime($curr_time) - strtotime($_SESSION[$url_string_node."-". $function."-".$options]);
     
     
     if($timediff_in_sec>20)
     {
           
       unset($_SESSION[$url_string_node."-". $function."-".$options]);

     }
     
     //echo " Time since last set ==== > ".$timediff_in_sec;

   }else{
      
  ///echo $url_string_node."-". $function."-".$options." is not set now ---";
   }

  if(strpos($check_url_key, $url_key)===false)
  {
    $new_security_block="
    ///start access clearance array for ".$file_url."
    ".$file_url."'=>
      [
      '".$function."'=>['".$options."','{{next_".$url_string_node."_".$function."}}'],
        //next_".$url_string_node."_access

      ],
      ///end access clearance array for ".$file_url."

      //{{next_file_block}}".PHP_EOL;
    
   	$replacer_str="//{{next_file_block}}";

    echo "Please refresh page to Register ".$function." and ".$options." BLOCK FOR ".$working_url." ";

    magic_replace_file_contents($gwdna_file, $replacer_str, $new_security_block);
    
    magic_replace_file_contents($access_trail_file, $next_gw_fun_str, $trail_function);

    //echo "key is not there ";
   }else{
    //echo "url key available <br>";    
    
      if(strpos($check_url_key, "{{next_".$url_string_node."_".$function."}}")===false)
      {

      $new_security_block="
      '".$function."'=>['".$options."','{{next_".$url_string_node."_".$function."}}'],
      //next_".$url_string_node."_access";
      $replacer_str="//next_".$url_string_node."_access"; 
        
      // echo "{{next_".$url_string_node."_".$function."}} next option not available <br>";
        
    echo "Please refresh page to Register ".$function." and ".$options." NODE FOR ".$working_url." ";
        
       magic_replace_file_contents($gwdna_file, $replacer_str, $new_security_block);

       magic_replace_file_contents($access_trail_file, $next_gw_fun_str, $trail_function);

      }else{

        
          if(isset($new_access_arr[$working_url][$function]))
          {

            //echo " function arr set  <br>";

            if(in_array($options, $new_access_arr[$working_url][$function]))
            { 
              
              $replacer_str="";
              $new_security_block=""; 
              
            }else{
              
              $replacer_str="";
              $new_security_block=""; 
                                         
              if(!isset($_SESSION[$url_string_node."-". $function."-".$options]))
              {
                
              	$replacer_str="'{{next_".$url_string_node."_".$function."}}'";
                  
              	$new_security_block="'".$options."','{{next_".$url_string_node."_".$function."}}'";
                                
               //	echo " session ".$url_string_node."-". $function."-".$options." is NOT set ";

                magic_replace_file_contents($gwdna_file, $replacer_str, $new_security_block);

                magic_replace_file_contents($access_trail_file, $next_gw_fun_str, $trail_function);

              
                $_SESSION[$url_string_node."-". $function."-".$options]=date("d-m-Y h:i:s A");
                                                 
              	//echo " SETTING session ".$url_string_node."-". $function."-".$options." NOW <HR> ";

               // echo "Please refresh page to Register ".$function." and ".$options." OPTION NODE FOR ".$working_url." ";

                
              }
            
          }
            
        //echo "{{next_".$url_string_node."_".$function."}} next option available <br>";

      }
    
  }
  
  }
	  //sleep(7);
                  	

}


function mosy_authenticate($function, $option)
{
   $gwauthenticate_=gw_oauth("table", $_SERVER['HTTP_REFERER'], $function, $option,"");

   $gwauthenticate_json=json_decode($gwauthenticate_, true);
  
   $oauth_state_=$gwauthenticate_json;

    if($gwauthenticate_json["response"]=="ok")
    {
      $oauth_state_="true";
    }
  
   return $oauth_state_;
  
}
?>