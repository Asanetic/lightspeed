<?php 

		//== initialize edit token variables

		$client_base_uptoken="";

		if(isset($_GET["client_base_uptoken"]))
		{
		$client_base_uptoken=base64_decode($_GET["client_base_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["client_base_insert_btn"])){
//------- begin Create Update record from client_base --> 
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$client_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_name"]);
$gender=mysqli_real_escape_string($mysqliconn, $_POST["txt_gender"]);
$client_tel=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_tel"]);
$client_email=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_email"]);
$city=mysqli_real_escape_string($mysqliconn, $_POST["txt_city"]);
$location=mysqli_real_escape_string($mysqliconn, $_POST["txt_location"]);
$building_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_building_no"]);
$floor_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_floor_no"]);
$room_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_room_no"]);
$package=mysqli_real_escape_string($mysqliconn, $_POST["txt_package"]);
$package_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_price"]);
$photo=mysqli_real_escape_string($mysqliconn, $_POST["txt_photo"]);
$installation_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_installation_date"]);
$signed_by=mysqli_real_escape_string($mysqliconn, $_POST["txt_signed_by"]);
$comment=mysqli_real_escape_string($mysqliconn, $_POST["txt_comment"]);
$ip_address=mysqli_real_escape_string($mysqliconn, $_POST["txt_ip_address"]);
$account_status=mysqli_real_escape_string($mysqliconn, $_POST["txt_account_status"]);
$admin_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_admin_id"]);
$instdate=mysqli_real_escape_string($mysqliconn, $_POST["txt_instdate"]);
//===-- End Create Update record from client_base -->


$client_base_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolink_cmsv2`.`client_base` (`primkey`,`client_id`,`client_name`,`gender`,`client_tel`,`client_email`,`city`,`location`,`building_no`,`floor_no`,`room_no`,`package`,`package_price`,`photo`,`installation_date`,`signed_by`,`comment`,`ip_address`,`account_status`,`admin_id`,`instdate`) 
 VALUES 
(NULL,'$client_id','$client_name','$gender','$client_tel','$client_email','$city','$location','$building_no','$floor_no','$room_no','$package','$package_price','$photo','$installation_date','$signed_by','$comment','$ip_address','$account_status','$admin_id','$instdate')");

 //--- get primary key id
$client_base_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?client_base_uptoken='.base64_encode($client_base_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["client_base_update_btn"])){
//------- begin Create Update record from client_base --> 
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$client_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_name"]);
$gender=mysqli_real_escape_string($mysqliconn, $_POST["txt_gender"]);
$client_tel=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_tel"]);
$client_email=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_email"]);
$city=mysqli_real_escape_string($mysqliconn, $_POST["txt_city"]);
$location=mysqli_real_escape_string($mysqliconn, $_POST["txt_location"]);
$building_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_building_no"]);
$floor_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_floor_no"]);
$room_no=mysqli_real_escape_string($mysqliconn, $_POST["txt_room_no"]);
$package=mysqli_real_escape_string($mysqliconn, $_POST["txt_package"]);
$package_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_price"]);
$photo=mysqli_real_escape_string($mysqliconn, $_POST["txt_photo"]);
$installation_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_installation_date"]);
$signed_by=mysqli_real_escape_string($mysqliconn, $_POST["txt_signed_by"]);
$comment=mysqli_real_escape_string($mysqliconn, $_POST["txt_comment"]);
$ip_address=mysqli_real_escape_string($mysqliconn, $_POST["txt_ip_address"]);
$account_status=mysqli_real_escape_string($mysqliconn, $_POST["txt_account_status"]);
$admin_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_admin_id"]);
$instdate=mysqli_real_escape_string($mysqliconn, $_POST["txt_instdate"]);
//===-- End Create Update record from client_base -->


$client_base_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolink_cmsv2`.`client_base` SET `client_id`='$client_id',`client_name`='$client_name',`gender`='$gender',`client_tel`='$client_tel',`client_email`='$client_email',`city`='$city',`location`='$location',`building_no`='$building_no',`floor_no`='$floor_no',`room_no`='$room_no',`package`='$package',`package_price`='$package_price',`photo`='$photo',`installation_date`='$installation_date',`signed_by`='$signed_by',`comment`='$comment',`ip_address`='$ip_address',`account_status`='$account_status',`admin_id`='$admin_id',`instdate`='$instdate' WHERE primkey='$client_base_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?client_base_uptoken='.base64_encode($client_base_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start client_base select Find client_base Records Profile query 

$find_client_base_records_profile_client_base_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolink_cmsv2`.`client_base` WHERE `primkey`='$client_base_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$client_base_node=mysqli_fetch_array($find_client_base_records_profile_client_base_query);

//=== End client_base select Find client_base Records Profile  query




if(isset($_POST["qclient_base_btn"])){


$qclient_base_str=base64_encode($_POST["txt_client_base"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qclient_base='.($qclient_base_str).'');

}

if(isset($_GET["qclient_base"])){


$qclient_base=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qclient_base"]));



//===== limit record value

$client_base_sqlstring="SELECT COUNT(*) FROM `$infolink_cmsv2`.`client_base` WHERE (`primkey` LIKE '%".$qclient_base."%' OR  `client_id` LIKE '%".$qclient_base."%' OR  `client_name` LIKE '%".$qclient_base."%' OR  `gender` LIKE '%".$qclient_base."%' OR  `client_tel` LIKE '%".$qclient_base."%' OR  `client_email` LIKE '%".$qclient_base."%' OR  `city` LIKE '%".$qclient_base."%' OR  `location` LIKE '%".$qclient_base."%' OR  `building_no` LIKE '%".$qclient_base."%' OR  `floor_no` LIKE '%".$qclient_base."%' OR  `room_no` LIKE '%".$qclient_base."%' OR  `package` LIKE '%".$qclient_base."%' OR  `package_price` LIKE '%".$qclient_base."%' OR  `photo` LIKE '%".$qclient_base."%' OR  `installation_date` LIKE '%".$qclient_base."%' OR  `signed_by` LIKE '%".$qclient_base."%' OR  `comment` LIKE '%".$qclient_base."%' OR  `ip_address` LIKE '%".$qclient_base."%' OR  `account_status` LIKE '%".$qclient_base."%' OR  `admin_id` LIKE '%".$qclient_base."%' OR  `instdate` LIKE '%".$qclient_base."%') AND account_status!='Inactive'";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolink_cmsv2`.`client_base`  WHERE (`primkey` LIKE '%".$qclient_base."%' OR  `client_id` LIKE '%".$qclient_base."%' OR  `client_name` LIKE '%".$qclient_base."%' OR  `gender` LIKE '%".$qclient_base."%' OR  `client_tel` LIKE '%".$qclient_base."%' OR  `client_email` LIKE '%".$qclient_base."%' OR  `city` LIKE '%".$qclient_base."%' OR  `location` LIKE '%".$qclient_base."%' OR  `building_no` LIKE '%".$qclient_base."%' OR  `floor_no` LIKE '%".$qclient_base."%' OR  `room_no` LIKE '%".$qclient_base."%' OR  `package` LIKE '%".$qclient_base."%' OR  `package_price` LIKE '%".$qclient_base."%' OR  `photo` LIKE '%".$qclient_base."%' OR  `installation_date` LIKE '%".$qclient_base."%' OR  `signed_by` LIKE '%".$qclient_base."%' OR  `comment` LIKE '%".$qclient_base."%' OR  `ip_address` LIKE '%".$qclient_base."%' OR  `account_status` LIKE '%".$qclient_base."%' OR  `admin_id` LIKE '%".$qclient_base."%' OR  `instdate` LIKE '%".$qclient_base."%') AND account_status!='Inactive' ORDER BY `primkey` DESC LIMIT $client_base_firstproduct, $datalimit" );



//=== End client_base select  Like Query String client_base list
;

}elseif(isset($_GET['export_state'])){

//===== limit record value
$export_state=mysqli_real_escape_string($mysqliconn, $_GET["export_state"]);
  
 $export_str="WHERE vcf_exported='Exported' AND account_status!='Inactive'";

if($export_state=='Not Exported')
{
  $export_state="";
  
   $export_str="WHERE vcf_exported!='Exported' AND account_status!='Inactive'";
}
  
  
$client_base_sqlstring="SELECT COUNT(*) FROM `$infolink_cmsv2`.`client_base` ".$export_str."";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolink_cmsv2`.`client_base` ".$export_str." ORDER BY `primkey` DESC LIMIT $client_base_firstproduct, $datalimit" ) ;

//$client_base_list_res=mysqli_fetch_array($client_base_list_query);

//=== End client_base select  Like Query String client_base list

}
else{

//===== limit record value

$client_base_sqlstring="SELECT COUNT(*) FROM `$infolink_cmsv2`.`client_base` WHERE account_status!='Inactive'";

//===== Pagination function

$client_base_pagination= list_record_per_page($mysqliconn, $client_base_sqlstring, $datalimit);


//===== get return values


$client_base_firstproduct=$client_base_pagination["0"];

$client_base_pgcount=$client_base_pagination["1"];

//=== start client_base select  Like Query String client_base list  

$client_base_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolink_cmsv2`.`client_base` WHERE account_status!='Inactive' ORDER BY `primkey` DESC LIMIT $client_base_firstproduct, $datalimit" );

//$client_base_list_res=mysqli_fetch_array($client_base_list_query);

//=== End client_base select  Like Query String client_base list

}


//== Start  **** Delete client_base Records  

if(isset($_GET["deleteclient_base"]))
{

//======confirm pop up 
$current_file_url=magic_basename(magic_current_url());
  
$after_delete=base64_encode($current_file_url);
  
if(isset($_GET['after_delete']))
{
  $after_delete=$_GET['after_delete'];
}
  

$conf_del_client_base_btn=magic_button_link("./".$current_file_url."?client_base_uptoken=".$_GET["client_base_uptoken"]."&conf_deleteclient_base&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

$cancel_del_client_base_btn=magic_button_link("./".$current_file_url."?client_base_uptoken=".$_GET["client_base_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_client_base_btn." ".$cancel_del_client_base_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteclient_base"]))
{

//====== start back to list file after delete 
  
$current_file_url=magic_basename(magic_current_url());
  
$after_delete=($current_file_url);
  
if(isset($_GET['after_delete']))
{
  $after_delete=magic_basename(base64_decode($_GET['after_delete']));
}
  //====== End  back to list file after delete 

mysqli_query($mysqliconn, "DELETE FROM `$infolink_cmsv2`.`client_base` WHERE `primkey`='$client_base_uptoken'");

//==add your redirect here 

header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete client_base Records 

//--<{ncgh}/>
?>