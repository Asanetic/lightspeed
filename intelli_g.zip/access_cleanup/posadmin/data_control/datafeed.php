<?php
function qtrx_data($trx_id)
{
  
  global $fun_resonse;
  
  $fun_resonse=magic_sql_row_data('transactions', "transaction_id='$trx_id'", "primkey", "DESC");
  
  return $fun_resonse;
}


  function items_remaining($item_id)
{

$stock_out=qstock_out($item_id);
$stockin=qrestocked($item_id);
  
$qstockin_value=qstockin_value($item_id);
$stock_out_value= qstockout_value($item_id);

$rem_val=$qstockin_value-$stock_out_value;
  
$rem_items=$stockin-$stock_out;

return   array($rem_items, $rem_val);
}


 function qstockin_value($item_id)
{

  global $qstockin_value;

	$qstockin_value=  magic_sql_sum('stock_history', "amount", "item_id='$item_id'");
  
  return $qstockin_value;
  
  
}

function qstockout_value($item_id)
{
  global $qstockout_value;
  global $single_conn;
  global $single_db;

  
  $qstockout_value_q=mysqli_query($single_conn , "SELECT SUM(qty*amount) AS TOTITEM_SOLD FROM `$single_db`.`client_charges` WHERE charge_id='$item_id'");

  $qstockout_value_qr=mysqli_fetch_array($qstockout_value_q);
  
  
  return $qstockout_value_qr['TOTITEM_SOLD'];

}


function qstock_out($item_id)
{
  global $qstock_out;
  
  global $single_conn;
  global $single_db;

  
  $qstockout_value_q=mysqli_query($single_conn , "SELECT SUM(qty) AS TOTITEM_SOLD FROM `$single_db`.`client_charges` WHERE charge_id='$item_id'");

  $qstockout_value_qr=mysqli_fetch_array($qstockout_value_q);
  
  
  return $qstockout_value_qr['TOTITEM_SOLD'];

}

 function qrestocked($item_id)
{
global $qrestocked;
  
  $qrestocked=magic_sql_sum('stock_history', "stocked", "item_id='$item_id'");
  
  return $qrestocked;
}

function compute_monthy_payment($client_id, $month_year)
{
  
  global $compute_monthy_payment;
  global $single_conn;
  global $single_db;
  
  $formated_ym= date("Y-m", strtotime($month_year));
  $formated_fy= date("M-Y", strtotime($month_year));
  
  $compute_monthy_payment=  magic_sql_sum('transactions', 'package_amount_paid', "client_id='$client_id' AND month_year='$formated_fy'");
  
  $check_if_month_active = magic_sql_count('active_client_months', "*", "client_id='$client_id' AND month_year='$formated_ym'");
  
  $tot_charges_paid=  magic_sql_sum('transactions','othercharges_paid', "client_id='$client_id' AND month_year='$formated_fy'");
   
  if($check_if_month_active>0)
  {
    $compute_monthy_payment='skip';
  }
  
  return array($compute_monthy_payment, $tot_charges_paid);
}

function get_month_balances($client_id, $month_year)
{
    global $get_month_balances;
    global $single_conn;
    global $single_db;
  
  $formated_fy= date("M-Y", strtotime($month_year));
  
  $pkg_to_be_paid=mysqli_query($single_conn , "SELECT package_price FROM `$single_db`.`transactions` WHERE client_id='$client_id' AND month_year='$formated_fy' ORDER BY primkey DESC");
  $pkg_to_be_paid_r=mysqli_fetch_array($pkg_to_be_paid);
  
  $curr_pkg_price=$pkg_to_be_paid_r['package_price'];
  
	$loop_all_trx_q=mysqli_query($single_conn , "SELECT *  FROM `$single_db`.`transactions` WHERE client_id='$client_id' AND month_year='$formated_fy'");  
	$chrges_to_be_paid=0;
  
    while($loop_all_trx_r=mysqli_fetch_array($loop_all_trx_q)){
	
      $loop_trx_id=$loop_all_trx_r['transaction_id'];
	
      $loop_tx_charges=mysqli_query($single_conn , "SELECT SUM(qty*amount) AS TOTCRG FROM `$single_db`.`client_charges` WHERE trx_id='$loop_trx_id'");
      
      $loop_tx_charges_r=mysqli_fetch_array($loop_tx_charges);
      
      $chrges_to_be_paid=$chrges_to_be_paid+$loop_tx_charges_r['TOTCRG'];
      
    }
  
  return array($curr_pkg_price, $chrges_to_be_paid);
}


function get_month_arrears($client_id, $month_year)
{
  $client_data=qclient_data($client_id);
  
  $client_pkg_price=qpackage_data($client_data['package'])['price'];
  
  $month_amount_paid = compute_monthy_payment($client_id, $month_year);
  $month_amt_to_be_paid = get_month_balances($client_id, $month_year);
  
  $pkg_month_amount_paid=$month_amount_paid[0];
  $chrg_amt_paid= $month_amount_paid[1];
  
  $crg_amt_to_be_paid=$month_amt_to_be_paid[1];
  $pkg_amt_to_be_paid = $month_amt_to_be_paid[0];

  if($pkg_month_amount_paid=='skip')
  {
    $pkg_month_amount_paid=0;
    $pkg_amt_to_be_paid=0;
  }
  
  
  if($pkg_amt_to_be_paid==0 && $pkg_month_amount_paid!='skip')
  {
    $pkg_amt_to_be_paid=$client_pkg_price;
    
  }
  
  $pcg_amt_bal=$pkg_amt_to_be_paid-$pkg_month_amount_paid;
  
  $chrg_amt_bal=$crg_amt_to_be_paid-$chrg_amt_paid;
  
  $old_arrears_for_the_month = $pcg_amt_bal+$chrg_amt_bal;

  
  return ($old_arrears_for_the_month);
  
  
}


function qsupplier_data($supplier_id)
{
  
  global $qsupplier_data;
  
  $qsupplier_data=magic_sql_row_data('suppliers', "supp_id='$supplier_id'", "primkey", "DESC");
  
  return $qsupplier_data;
}
  
function cal_client_payments($start_date, $end_date, $client_id)
{

	global $cal_client_arrears;
  	global $single_conn;
	global $single_db;
  
  $instal_date=qclient_data($client_id)['installation_date'];
  $client_package=qclient_data($client_id)['package'];
  $client_package_price=qpackage_data($client_package)['price'];
  
  $tot_package_paid_q=mysqli_query($single_conn , "SELECT SUM(package_amount_paid) AS TOTPAID FROM `$single_db`.`transactions` WHERE client_id='$client_id' AND DATE(transaction_date) BETWEEN '$start_date' AND '$end_date'");
  $tot_package_paid_r=mysqli_fetch_array($tot_package_paid_q);
  
  $cal_client_arrears= $tot_package_paid_r['TOTPAID'];
  
  return $cal_client_arrears;
    
}

function calc_active_months($start_date, $end_date , $client_id)
{
	global $calc_active_months;
  	global $single_conn;
	global $single_db;
  
  $installation_date2=qclient_data($client_id)['installation_date'];
  
  $installation_date=date("Y-m-d", strtotime($installation_date2));
 
  $curr_start_date=$start_date;
   
 if($start_date<$installation_date)
 {
   
   $curr_start_date=$installation_date;
   
 }
   
 $d1=new DateTime($end_date); 
 $d2=new DateTime($curr_start_date); 
  
 $Months = $d2->diff($d1); 
 $calc_active_months = (($Months->y) * 12) + ($Months->m);
 
 $add_inactive_month=0;
  $count_i;
  
$contractDateBegin = date('Y-m-d', strtotime($curr_start_date));
$contractDateEnd = date('Y-m-d', strtotime($end_date));
  
  
 $loop_months_between_q=mysqli_query($single_conn, "SELECT * FROM `$single_db`.`active_client_months` WHERE client_id='$client_id'" );
 while($loop_months_between_r=mysqli_fetch_array($loop_months_between_q)){
   
   $found_month=date("Y-m-01", strtotime($loop_months_between_r['month_year']));
                                   
if (($found_month >= $contractDateBegin) && ($found_month <= $contractDateEnd)){
     $add_inactive_month=$add_inactive_month+1;
   }
 }
   
 $calc_active_months=$calc_active_months+1;
  
 if($installation_date<$start_date){
   $calc_active_months=0;
 }
  
 if($installation_date>$end_date){
   $calc_active_months=0;
 }
  
 $active_months=$calc_active_months-$add_inactive_month;
  
  return array($active_months, $add_inactive_month);

}


function cal_client_inst_arrears($start_date, $end_date, $client_id)
{

	global $cal_client_inst_arrears;
  	global $single_conn;
	global $single_db;
  
  $instal_date=qclient_data($client_id)['installation_date'];
  $client_package=qclient_data($client_id)['package'];
  $client_package_price=qpackage_data($client_package)['price'];
  
  $tot_package_paid_q=mysqli_query($single_conn , "SELECT SUM(othercharges_paid) AS TOTINS_PAID, transaction_id  FROM `$single_db`.`transactions` WHERE client_id='$client_id' AND DATE(transaction_date) BETWEEN '$start_date' AND '$end_date'");
  $tot_inst_charges=0;
  $tot_inst_charges_paid=0;
  
  while($tot_package_paid_r=mysqli_fetch_array($tot_package_paid_q)){
    
   $chrge_trx_id=$tot_package_paid_r['transaction_id'];
   
   $suminst_charges_q=mysqli_query($single_conn , "SELECT SUM(qty*amount) AS INSTTOTS  FROM `$single_db`.`client_charges` WHERE trx_id='$chrge_trx_id'");
   $suminst_charges_r=mysqli_fetch_array($suminst_charges_q);
   $tot_inst_charges=$tot_inst_charges+$suminst_charges_r['INSTTOTS'];
   $tot_inst_charges_paid=$tot_inst_charges_paid+$tot_package_paid_r['TOTINS_PAID'];
  }
  
  $cal_client_inst_arrears=$tot_inst_charges;
  
  return array($cal_client_inst_arrears, $tot_inst_charges_paid);
    
}
function daytime()
{
  global $daytime;

  $daytime='Hello';

  $fromdate=date('A');

  if($fromdate=='AM'){
 	 $daytime='Morning';
  }

  if($fromdate=='PM'){
  	$daytime='Evening';
  }

  return $daytime;
}

function qclient_data($client_id)
{
  global $qclient_data;
  
  $qclient_data=magic_sql_row_data('client_base', "client_id='$client_id'", "primkey", "desc");
  
  return $qclient_data;
}

function qpackage_data($package_id)
{
  global $qpackage_data;
  
  $qpackage_data=magic_sql_row_data('packages', "package_id='$package_id'", "primkey", "desc");
  
  return $qpackage_data;
}

function qteam_data($team_id)
{

   global $qteam_data;
  
  $qteam_data=magic_sql_row_data('team', "user_id='$team_id'", "primkey", "desc");
  
  return $qteam_data;

}

function qadmin_data($team_id)
{

   global $qadmin_data;
  
  $qadmin_data=magic_sql_row_data('admin', "admin_id='$team_id'", "primkey", "desc");
  
  return $qadmin_data;

}

function qinventory_data($item_id)
{

   global $qinventory_data;
  
  $qinventory_data=magic_sql_row_data('inventory', "item_id='$item_id'", "primkey", "desc");
  
  return $qinventory_data;

}
?>