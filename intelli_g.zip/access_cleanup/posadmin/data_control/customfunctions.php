<?php
if(isset($_POST['sync_expiry_dates']))
{

    $curr_client_list=get_client_base("*", " where $gft_client_base_and account_status='active' ", "l"); 
                        
    while($get_client_r=mysqli_fetch_array($curr_client_list))
    { 

    	$client_id=$get_client_r['client_id'];

		$last_trx_date=get_transactions("*", " where client_id='$client_id' order by transaction_date desc", "r");
		$next_expiry=date("Y-m-d", strtotime("+30 days", strtotime($last_trx_date['transaction_date'])));
                                                  
    	update_client_base(['expiry_date'=>$next_expiry], "client_id='$client_id'");
                          
    
    }
}
  
function push_infolink_sms($recp, $sms_body)
{

  $smsapi_url='https://api.infolinkcommunications.co.ke/infosms/sendsms.php';

  $sms_request='pushsms&recp='.$recp.'&body='.$sms_body.'';

  return magic_post_curl($smsapi_url, '', '', $sms_request, 'POST');

}

if(isset($_POST['send_sms_ajax']))
{
  push_infolink_sms($_POST['txt_to'], $_POST['txt_message']);
}
?>