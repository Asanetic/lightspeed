<?php 

		//== initialize edit token variables

		$inventory_uptoken="";

		if(isset($_GET["inventory_uptoken"]))
		{
		$inventory_uptoken=base64_decode($_GET["inventory_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["inventory_insert_btn"])){
//------- begin Create Update record from inventory --> 
$item_id=mysqli_real_escape_string($mysqliconn, "INFLNK/".magic_random_str(4));
$item_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_item_name"]);
$buying_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_buying_price"]);
$selling_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_selling_price"]);
$description=mysqli_real_escape_string($mysqliconn, $_POST["txt_description"]);
//===-- End Create Update record from inventory -->


$inventory_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`inventory` (`primkey`,`item_id`,`item_name`,`buying_price`,`selling_price`,`description`) 
 VALUES 
(NULL,'$item_id','$item_name','$buying_price','$selling_price','$description')");

 //--- get primary key id
$inventory_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?inventory_uptoken='.base64_encode($inventory_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["inventory_update_btn"])){
//------- begin Create Update record from inventory --> 
$item_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_item_name"]);
$buying_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_buying_price"]);
$selling_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_selling_price"]);
$description=mysqli_real_escape_string($mysqliconn, $_POST["txt_description"]);
//===-- End Create Update record from inventory -->


$inventory_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`inventory` SET `item_name`='$item_name',`buying_price`='$buying_price',`selling_price`='$selling_price',`description`='$description' WHERE primkey='$inventory_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?inventory_uptoken='.base64_encode($inventory_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start inventory select Find inventory Records Profile query 

$find_inventory_records_profile_inventory_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`inventory` WHERE `primkey`='$inventory_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$inventory_node=mysqli_fetch_array($find_inventory_records_profile_inventory_query);

//=== End inventory select Find inventory Records Profile  query




if(isset($_POST["qinventory_btn"])){


$qinventory_str=base64_encode($_POST["txt_inventory"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qinventory='.($qinventory_str).'');

}

if(isset($_GET["qinventory"])){


$qinventory=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qinventory"]));



//===== limit record value

$inventory_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`inventory` WHERE (`primkey` LIKE '%".$qinventory."%' OR  `item_id` LIKE '%".$qinventory."%' OR  `item_name` LIKE '%".$qinventory."%' OR  `buying_price` LIKE '%".$qinventory."%' OR  `selling_price` LIKE '%".$qinventory."%' OR  `description` LIKE '%".$qinventory."%')";

//===== Pagination function

$inventory_pagination= list_record_per_page($mysqliconn, $inventory_sqlstring, $datalimit);


//===== get return values


$inventory_firstproduct=$inventory_pagination["0"];

$inventory_pgcount=$inventory_pagination["1"];

//=== start inventory select  Like Query String inventory list  

$inventory_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`inventory`  WHERE (`primkey` LIKE '%".$qinventory."%' OR  `item_id` LIKE '%".$qinventory."%' OR  `item_name` LIKE '%".$qinventory."%' OR  `buying_price` LIKE '%".$qinventory."%' OR  `selling_price` LIKE '%".$qinventory."%' OR  `description` LIKE '%".$qinventory."%') ORDER BY `primkey` DESC LIMIT $inventory_firstproduct, $datalimit" );



//=== End inventory select  Like Query String inventory list
;

}else{

//===== limit record value

$inventory_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`inventory`";

//===== Pagination function

$inventory_pagination= list_record_per_page($mysqliconn, $inventory_sqlstring, $datalimit);


//===== get return values


$inventory_firstproduct=$inventory_pagination["0"];

$inventory_pgcount=$inventory_pagination["1"];

//=== start inventory select  Like Query String inventory list  

$inventory_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`inventory`  ORDER BY `primkey` DESC LIMIT $inventory_firstproduct, $datalimit" );

//$inventory_list_res=mysqli_fetch_array($inventory_list_query);

//=== End inventory select  Like Query String inventory list

}


//== Start  **** Delete inventory Records  

if(isset($_GET["deleteinventory"]))
{

//======confirm pop up 

$conf_del_inventory_btn=magic_button_link("./editinventory.php?inventory_uptoken=".$_GET["inventory_uptoken"]."&conf_deleteinventory", "Yes", 'style="margin-right:10px;"');

$cancel_del_inventory_btn=magic_button_link("./editinventory.php?inventory_uptoken=".$_GET["inventory_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_inventory_btn." ".$cancel_del_inventory_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteinventory"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`inventory` WHERE `primkey`='$inventory_uptoken'");

//==add your redirect here 

header("location:./inventory.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete inventory Records 

//--<{ncgh}/>
?>