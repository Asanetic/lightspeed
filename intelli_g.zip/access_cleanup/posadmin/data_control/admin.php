<?php 

		//== initialize edit token variables

		$admin_uptoken="";

		if(isset($_GET["admin_uptoken"]))
		{
		$admin_uptoken=base64_decode($_GET["admin_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["admin_insert_btn"])){
//------- begin Create Update record from admin --> 
$admin_id=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$names=mysqli_real_escape_string($mysqliconn, $_POST["txt_names"]);
$username=mysqli_real_escape_string($mysqliconn, $_POST["txt_username"]);
$password=mysqli_real_escape_string($mysqliconn, $_POST["txt_password"]);
$role=mysqli_real_escape_string($mysqliconn, $_POST["txt_role"]);
$last_seen=mysqli_real_escape_string($mysqliconn, $_POST["txt_last_seen"]);
$telephone=mysqli_real_escape_string($mysqliconn, $_POST["txt_telephone"]);
$photo=mysqli_real_escape_string($mysqliconn, $_POST["txt_photo"]);
//===-- End Create Update record from admin -->


$admin_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`admin` (`primkey`,`admin_id`,`names`,`username`,`password`,`role`,`last_seen`,`telephone`,`photo`) 
 VALUES 
(NULL,'$admin_id','$names','$username','$password','$role','$last_seen','$telephone','$photo')");

 //--- get primary key id
$admin_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?admin_uptoken='.base64_encode($admin_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["admin_update_btn"])){
//------- begin Create Update record from admin --> 
$admin_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_admin_id"]);
$names=mysqli_real_escape_string($mysqliconn, $_POST["txt_names"]);
$username=mysqli_real_escape_string($mysqliconn, $_POST["txt_username"]);
$password=mysqli_real_escape_string($mysqliconn, $_POST["txt_password"]);
$role=mysqli_real_escape_string($mysqliconn, $_POST["txt_role"]);
$last_seen=mysqli_real_escape_string($mysqliconn, $_POST["txt_last_seen"]);
$telephone=mysqli_real_escape_string($mysqliconn, $_POST["txt_telephone"]);
$photo=mysqli_real_escape_string($mysqliconn, $_POST["txt_photo"]);
//===-- End Create Update record from admin -->


$admin_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`admin` SET `names`='$names',`username`='$username',`password`='$password',`role`='$role',`last_seen`='$last_seen',`telephone`='$telephone',`photo`='$photo' WHERE primkey='$admin_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?admin_uptoken='.base64_encode($admin_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start admin select Find admin Records Profile query 

$find_admin_records_profile_admin_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`admin` WHERE `primkey`='$admin_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$admin_node=mysqli_fetch_array($find_admin_records_profile_admin_query);

//=== End admin select Find admin Records Profile  query




if(isset($_POST["qadmin_btn"])){


$qadmin_str=base64_encode($_POST["txt_admin"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qadmin='.($qadmin_str).'');

}

if(isset($_GET["qadmin"])){


$qadmin=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qadmin"]));



//===== limit record value

$admin_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`admin` WHERE (`primkey` LIKE '%".$qadmin."%' OR  `admin_id` LIKE '%".$qadmin."%' OR  `names` LIKE '%".$qadmin."%' OR  `username` LIKE '%".$qadmin."%' OR  `password` LIKE '%".$qadmin."%' OR  `role` LIKE '%".$qadmin."%' OR  `last_seen` LIKE '%".$qadmin."%' OR  `telephone` LIKE '%".$qadmin."%' OR  `photo` LIKE '%".$qadmin."%')";

//===== Pagination function

$admin_pagination= list_record_per_page($mysqliconn, $admin_sqlstring, $datalimit);


//===== get return values


$admin_firstproduct=$admin_pagination["0"];

$admin_pgcount=$admin_pagination["1"];

//=== start admin select  Like Query String admin list  

$admin_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`admin`  WHERE (`primkey` LIKE '%".$qadmin."%' OR  `admin_id` LIKE '%".$qadmin."%' OR  `names` LIKE '%".$qadmin."%' OR  `username` LIKE '%".$qadmin."%' OR  `password` LIKE '%".$qadmin."%' OR  `role` LIKE '%".$qadmin."%' OR  `last_seen` LIKE '%".$qadmin."%' OR  `telephone` LIKE '%".$qadmin."%' OR  `photo` LIKE '%".$qadmin."%') ORDER BY `primkey` DESC LIMIT $admin_firstproduct, $datalimit" );



//=== End admin select  Like Query String admin list
;

}else{

//===== limit record value

$admin_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`admin`";

//===== Pagination function

$admin_pagination= list_record_per_page($mysqliconn, $admin_sqlstring, $datalimit);


//===== get return values


$admin_firstproduct=$admin_pagination["0"];

$admin_pgcount=$admin_pagination["1"];

//=== start admin select  Like Query String admin list  

$admin_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`admin`  ORDER BY `primkey` DESC LIMIT $admin_firstproduct, $datalimit" );

//$admin_list_res=mysqli_fetch_array($admin_list_query);

//=== End admin select  Like Query String admin list

}


//== Start  **** Delete admin Records  

if(isset($_GET["deleteadmin"]))
{

//======confirm pop up 

$conf_del_admin_btn=magic_button_link("./editadmin.php?admin_uptoken=".$_GET["admin_uptoken"]."&conf_deleteadmin", "Yes", 'style="margin-right:10px;"');

$cancel_del_admin_btn=magic_button_link("./editadmin.php?admin_uptoken=".$_GET["admin_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_admin_btn." ".$cancel_del_admin_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteadmin"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`admin` WHERE `primkey`='$admin_uptoken'");

//==add your redirect here 

header("location:./admin.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete admin Records 



//=== start admin select Find admin Records Profile query 

$find_admin_records_profile_admin_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`admin` WHERE `primkey`='$admin_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$admin_node=mysqli_fetch_array($find_admin_records_profile_admin_query);

//=== End admin select Find admin Records Profile  query




if(isset($_POST["qadmin_btn"])){


$qadmin_str=base64_encode($_POST["txt_admin"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qadmin='.($qadmin_str).'');

}

if(isset($_GET["qadmin"])){


$qadmin=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qadmin"]));



//===== limit record value

$admin_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`admin` WHERE (`primkey` LIKE '%".$qadmin."%' OR  `admin_id` LIKE '%".$qadmin."%' OR  `names` LIKE '%".$qadmin."%' OR  `username` LIKE '%".$qadmin."%' OR  `password` LIKE '%".$qadmin."%' OR  `role` LIKE '%".$qadmin."%' OR  `last_seen` LIKE '%".$qadmin."%' OR  `telephone` LIKE '%".$qadmin."%' OR  `photo` LIKE '%".$qadmin."%')";

//===== Pagination function

$admin_pagination= list_record_per_page($mysqliconn, $admin_sqlstring, $datalimit);


//===== get return values


$admin_firstproduct=$admin_pagination["0"];

$admin_pgcount=$admin_pagination["1"];

//=== start admin select  Like Query String admin list  

$admin_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`admin`  WHERE (`primkey` LIKE '%".$qadmin."%' OR  `admin_id` LIKE '%".$qadmin."%' OR  `names` LIKE '%".$qadmin."%' OR  `username` LIKE '%".$qadmin."%' OR  `password` LIKE '%".$qadmin."%' OR  `role` LIKE '%".$qadmin."%' OR  `last_seen` LIKE '%".$qadmin."%' OR  `telephone` LIKE '%".$qadmin."%' OR  `photo` LIKE '%".$qadmin."%') ORDER BY `primkey` DESC LIMIT $admin_firstproduct, $datalimit" );



//=== End admin select  Like Query String admin list
;

}else{

//===== limit record value

$admin_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`admin`";

//===== Pagination function

$admin_pagination= list_record_per_page($mysqliconn, $admin_sqlstring, $datalimit);


//===== get return values


$admin_firstproduct=$admin_pagination["0"];

$admin_pgcount=$admin_pagination["1"];

//=== start admin select  Like Query String admin list  

$admin_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`admin`  ORDER BY `primkey` DESC LIMIT $admin_firstproduct, $datalimit" );

//$admin_list_res=mysqli_fetch_array($admin_list_query);

//=== End admin select  Like Query String admin list

}


//== Start  **** Delete admin Records  

if(isset($_GET["deleteadmin"]))
{

//======confirm pop up 

$conf_del_admin_btn=magic_button_link("./editadmin.php?admin_uptoken=".$_GET["admin_uptoken"]."&conf_deleteadmin", "Yes", 'style="margin-right:10px;"');

$cancel_del_admin_btn=magic_button_link("./editadmin.php?admin_uptoken=".$_GET["admin_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_admin_btn." ".$cancel_del_admin_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteadmin"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`admin` WHERE `primkey`='$admin_uptoken'");

//==add your redirect here 

header("location:./admin.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete admin Records 

//--<{ncgh}/>
?>