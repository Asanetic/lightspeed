<?php 

		//== initialize edit token variables

		$transactions_uptoken="";

		if(isset($_GET["transactions_uptoken"]))
		{
		$transactions_uptoken=base64_decode($_GET["transactions_uptoken"]);
		}


$start_tx_date="";
$end_tx_id="";

if(isset($_GET['start_tx_date'])){

$start_tx_date=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['start_tx_date']));
$end_tx_id=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['end_tx_id']));

}

//************* START INSERT QUERY 
if(isset($_POST["transactions_insert_btn"])){
//------- begin Create Update record from transactions --> 
$transaction_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_id"]);
$transaction_ref=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_ref"]);
$package_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_name"]);
$package_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_price"]);
$amount_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount_paid"]);
$balance=mysqli_real_escape_string($mysqliconn, $_POST["txt_balance"]);
$transaction_type=mysqli_real_escape_string($mysqliconn, $_POST["txt_payment_mode"]);
$transaction_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_date"]);
$month_year=mysqli_real_escape_string($mysqliconn, date("M-Y", strtotime($_POST["txt_month_year"])));
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$received_by=mysqli_real_escape_string($mysqliconn, $_POST["txt_received_by"]);
$confirmed_by=mysqli_real_escape_string($mysqliconn, $_POST["txt_confirmed_by"]);
$remark=mysqli_real_escape_string($mysqliconn, $_POST["txt_remark"]);
$status=mysqli_real_escape_string($mysqliconn, $_POST["txt_status"]);
$admin_id=mysqli_real_escape_string($mysqliconn, "");
$old_balances=mysqli_real_escape_string($mysqliconn, $_POST["txt_old_balances"]);
$total_due=mysqli_real_escape_string($mysqliconn, $_POST["txt_total_due"]);
$discount=mysqli_real_escape_string($mysqliconn, $_POST["txt_discount"]);
$payment_mode=mysqli_real_escape_string($mysqliconn, $_POST["txt_payment_mode"]);
$installation_fee=mysqli_real_escape_string($mysqliconn, "");
$trxdate=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_date"]);
$package_amount_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_amount_paid"]);
$othercharges_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_othercharges_paid"]);
$date_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_date_paid"]);

//===-- End Create Update record from transactions -->


$transactions_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`transactions` (`primkey`,`transaction_id`,`transaction_ref`,`package_name`,`package_price`,`amount_paid`,`balance`,`transaction_type`,`transaction_date`,`month_year`,`client_id`,`received_by`,`confirmed_by`,`remark`,`status`,`admin_id`,`old_balances`,`total_due`,`discount`,`payment_mode`,`installation_fee`,`trxdate`, `othercharges_paid`, `package_amount_paid`,`date_paid`) 
 VALUES 
(NULL,'$transaction_id','$transaction_ref','$package_name','$package_price','$amount_paid','$balance','$transaction_type','$transaction_date','$month_year','$client_id','$received_by','$confirmed_by','$remark','$status','$admin_id','$old_balances','$total_due','$discount','$payment_mode','$installation_fee','$trxdate', '$othercharges_paid', '$package_amount_paid', '$date_paid')");


 //--- get primary key id
$transactions_return_key=mysqli_insert_id($mysqliconn);

  if(isset($_SESSION["session_trx_id_active"])){

 unset($_SESSION["session_trx_id_active"]);
 unset($_SESSION["session_trx_id"]);
  } 
 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?transactions_uptoken='.base64_encode($transactions_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["transactions_update_btn"])){
//------- begin Create Update record from transactions --> 
$transaction_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_id"]);
$transaction_ref=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_ref"]);
$package_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_name"]);
$package_price=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_price"]);
$amount_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount_paid"]);
$balance=mysqli_real_escape_string($mysqliconn, $_POST["txt_balance"]);
$transaction_type=mysqli_real_escape_string($mysqliconn, "");
$transaction_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_date"]);
$month_year=mysqli_real_escape_string($mysqliconn, date("M-Y", strtotime($_POST["txt_month_year"])));
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$received_by=mysqli_real_escape_string($mysqliconn, $_POST["txt_received_by"]);
$confirmed_by=mysqli_real_escape_string($mysqliconn, $_POST["txt_confirmed_by"]);
$remark=mysqli_real_escape_string($mysqliconn, $_POST["txt_remark"]);
$status=mysqli_real_escape_string($mysqliconn, $_POST["txt_status"]);
$admin_id=mysqli_real_escape_string($mysqliconn, "");
$old_balances=mysqli_real_escape_string($mysqliconn, $_POST["txt_old_balances"]);
$total_due=mysqli_real_escape_string($mysqliconn, $_POST["txt_total_due"]);
$discounted=mysqli_real_escape_string($mysqliconn, $_POST["txt_discount"]);
$payment_mode=mysqli_real_escape_string($mysqliconn, $_POST["txt_payment_mode"]);
$installation_fee=mysqli_real_escape_string($mysqliconn, "");
$trxdate=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_date"]);
$package_amount_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_amount_paid"]);
$othercharges_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_othercharges_paid"]);
$date_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_date_paid"]);

  //===-- End Create Update record from transactions -->


$transactions_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`transactions` SET `transaction_ref`='$transaction_ref',`package_name`='$package_name',`package_price`='$package_price',`amount_paid`='$amount_paid',`balance`='$balance',`transaction_type`='$transaction_type',`transaction_date`='$transaction_date',`month_year`='$month_year',`client_id`='$client_id',`received_by`='$received_by',`confirmed_by`='$confirmed_by',`remark`='$remark',`status`='$status',`admin_id`='$admin_id',`old_balances`='$old_balances',`total_due`='$total_due',`discount`='$discounted',`payment_mode`='$payment_mode',`installation_fee`='$installation_fee',`trxdate`='$trxdate', `package_amount_paid`='$package_amount_paid', `othercharges_paid`='$othercharges_paid', `date_paid`='$date_paid' WHERE primkey='$transactions_uptoken'");

  if(isset($_SESSION["session_trx_id_active"])){

 unset($_SESSION["session_trx_id_active"]);
 unset($_SESSION["session_trx_id"]);
  } 
 
 
//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?transactions_uptoken='.base64_encode($transactions_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start transactions select Find transactions Records Profile query 

$find_transactions_records_profile_transactions_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`transactions` WHERE `primkey`='$transactions_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$transactions_node=mysqli_fetch_array($find_transactions_records_profile_transactions_query);

//=== End transactions select Find transactions Records Profile  query




if(isset($_POST["qtransactions_btn"])){


$qtransactions_str=base64_encode($_POST["txt_transactions"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qtransactions='.($qtransactions_str).'');

}

if(isset($_GET["qtransactions"])){


$qtransactions=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qtransactions"]));


//===== limit record value

$transactions_sqlstring="SELECT COUNT(*) FROM transactions LEFT JOIN  client_base ON client_base.client_id=transactions.client_id  WHERE (client_base.primkey LIKE '%".$qtransactions."%' OR  client_base.client_id LIKE '%".$qtransactions."%' OR  client_base.client_name LIKE '%".$qtransactions."%' OR  client_base.gender LIKE '%".$qtransactions."%' OR  client_base.client_tel LIKE '%".$qtransactions."%' OR  client_base.client_email LIKE '%".$qtransactions."%' OR  client_base.city LIKE '%".$qtransactions."%' OR  client_base.location LIKE '%".$qtransactions."%' OR  client_base.building_no LIKE '%".$qtransactions."%' OR  client_base.floor_no LIKE '%".$qtransactions."%' OR  client_base.room_no LIKE '%".$qtransactions."%' OR  client_base.package LIKE '%".$qtransactions."%' OR  client_base.package_price LIKE '%".$qtransactions."%' OR  client_base.photo LIKE '%".$qtransactions."%' OR  client_base.installation_date LIKE '%".$qtransactions."%' OR  client_base.signed_by LIKE '%".$qtransactions."%' OR  client_base.comment LIKE '%".$qtransactions."%' OR  client_base.ip_address LIKE '%".$qtransactions."%' OR  client_base.account_status LIKE '%".$qtransactions."%' OR  client_base.admin_id LIKE '%".$qtransactions."%' OR  client_base.instdate LIKE '%".$qtransactions."%'  OR transactions.primkey LIKE '%".$qtransactions."%' OR  transactions.transaction_id LIKE '%".$qtransactions."%' OR  transactions.transaction_ref LIKE '%".$qtransactions."%' OR  transactions.package_name LIKE '%".$qtransactions."%' OR  transactions.package_price LIKE '%".$qtransactions."%' OR  transactions.amount_paid LIKE '%".$qtransactions."%' OR  transactions.balance LIKE '%".$qtransactions."%' OR  transactions.transaction_type LIKE '%".$qtransactions."%' OR  transactions.transaction_date LIKE '%".$qtransactions."%' OR  transactions.month_year LIKE '%".$qtransactions."%' OR  transactions.client_id LIKE '%".$qtransactions."%' OR  transactions.received_by LIKE '%".$qtransactions."%' OR  transactions.confirmed_by LIKE '%".$qtransactions."%' OR  transactions.remark LIKE '%".$qtransactions."%' OR  transactions.status LIKE '%".$qtransactions."%' OR  transactions.admin_id LIKE '%".$qtransactions."%' OR  transactions.old_balances LIKE '%".$qtransactions."%' OR  transactions.total_due LIKE '%".$qtransactions."%' OR  transactions.discount LIKE '%".$qtransactions."%' OR  transactions.payment_mode LIKE '%".$qtransactions."%' OR  transactions.installation_fee LIKE '%".$qtransactions."%' OR  transactions.trxdate LIKE '%".$qtransactions."%' OR  transactions.package_amount_paid LIKE '%".$qtransactions."%' OR  transactions.othercharges_paid LIKE '%".$qtransactions."%')";

//===== Pagination function

$transactions_pagination= list_record_per_page($mysqliconn, $transactions_sqlstring, $datalimit);


//===== get return values


$transactions_firstproduct=$transactions_pagination["0"];

$transactions_pgcount=$transactions_pagination["1"];

//=== start transactions select  LEFT JOIN Query for transactions as main table and child client_base list  

$transactions_list_query=mysqli_query($mysqliconn, "SELECT  client_base.primkey ,  client_base.client_id ,  client_base.client_name ,  client_base.gender ,  client_base.client_tel ,  client_base.client_email ,  client_base.city ,  client_base.location ,  client_base.building_no ,  client_base.floor_no ,  client_base.room_no ,  client_base.package ,  client_base.package_price ,  client_base.photo ,  client_base.installation_date ,  client_base.signed_by ,  client_base.comment ,  client_base.ip_address ,  client_base.account_status ,  client_base.admin_id ,  client_base.instdate , transactions.primkey ,  transactions.transaction_id ,  transactions.transaction_ref ,  transactions.package_name ,  transactions.package_price ,  transactions.amount_paid ,  transactions.balance ,  transactions.transaction_type ,  transactions.transaction_date ,  transactions.month_year ,  transactions.client_id ,  transactions.received_by ,  transactions.confirmed_by ,  transactions.remark ,  transactions.status ,  transactions.admin_id ,  transactions.old_balances ,  transactions.total_due ,  transactions.discount ,  transactions.payment_mode ,  transactions.installation_fee ,  transactions.trxdate ,  transactions.package_amount_paid ,  transactions.othercharges_paid FROM  transactions LEFT JOIN  client_base ON client_base.client_id=transactions.client_id    WHERE (client_base.primkey LIKE '%".$qtransactions."%' OR  client_base.client_id LIKE '%".$qtransactions."%' OR  client_base.client_name LIKE '%".$qtransactions."%' OR  client_base.gender LIKE '%".$qtransactions."%' OR  client_base.client_tel LIKE '%".$qtransactions."%' OR  client_base.client_email LIKE '%".$qtransactions."%' OR  client_base.city LIKE '%".$qtransactions."%' OR  client_base.location LIKE '%".$qtransactions."%' OR  client_base.building_no LIKE '%".$qtransactions."%' OR  client_base.floor_no LIKE '%".$qtransactions."%' OR  client_base.room_no LIKE '%".$qtransactions."%' OR  client_base.package LIKE '%".$qtransactions."%' OR  client_base.package_price LIKE '%".$qtransactions."%' OR  client_base.photo LIKE '%".$qtransactions."%' OR  client_base.installation_date LIKE '%".$qtransactions."%' OR  client_base.signed_by LIKE '%".$qtransactions."%' OR  client_base.comment LIKE '%".$qtransactions."%' OR  client_base.ip_address LIKE '%".$qtransactions."%' OR  client_base.account_status LIKE '%".$qtransactions."%' OR  client_base.admin_id LIKE '%".$qtransactions."%' OR  client_base.instdate LIKE '%".$qtransactions."%'  OR transactions.primkey LIKE '%".$qtransactions."%' OR  transactions.transaction_id LIKE '%".$qtransactions."%' OR  transactions.transaction_ref LIKE '%".$qtransactions."%' OR  transactions.package_name LIKE '%".$qtransactions."%' OR  transactions.package_price LIKE '%".$qtransactions."%' OR  transactions.amount_paid LIKE '%".$qtransactions."%' OR  transactions.balance LIKE '%".$qtransactions."%' OR  transactions.transaction_type LIKE '%".$qtransactions."%' OR  transactions.transaction_date LIKE '%".$qtransactions."%' OR  transactions.month_year LIKE '%".$qtransactions."%' OR  transactions.client_id LIKE '%".$qtransactions."%' OR  transactions.received_by LIKE '%".$qtransactions."%' OR  transactions.confirmed_by LIKE '%".$qtransactions."%' OR  transactions.remark LIKE '%".$qtransactions."%' OR  transactions.status LIKE '%".$qtransactions."%' OR  transactions.admin_id LIKE '%".$qtransactions."%' OR  transactions.old_balances LIKE '%".$qtransactions."%' OR  transactions.total_due LIKE '%".$qtransactions."%' OR  transactions.discount LIKE '%".$qtransactions."%' OR  transactions.payment_mode LIKE '%".$qtransactions."%' OR  transactions.installation_fee LIKE '%".$qtransactions."%' OR  transactions.trxdate LIKE '%".$qtransactions."%' OR  transactions.package_amount_paid LIKE '%".$qtransactions."%' OR  transactions.othercharges_paid LIKE '%".$qtransactions."%') ORDER BY transactions.primkey DESC LIMIT $transactions_firstproduct, $datalimit" ) or die(mysqli_error($mysqliconn));


//=== End transactions select  LEFT JOIN Query for transactions as main table and child client_base list



}elseif(isset($_GET['start_tx_date'])){

//===== limit record value

$transactions_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`transactions` WHERE DATE(transaction_date) between '$start_tx_date' and '$end_tx_id' ";

//===== Pagination function

$transactions_pagination= list_record_per_page($mysqliconn, $transactions_sqlstring, $datalimit);


//===== get return values


$transactions_firstproduct=$transactions_pagination["0"];

$transactions_pgcount=$transactions_pagination["1"];

//=== start transactions select  Like Query String transactions list  

$transactions_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`transactions` WHERE DATE(transaction_date) between '$start_tx_date' and '$end_tx_id' ORDER BY `primkey` DESC LIMIT $transactions_firstproduct, $datalimit" );

//$transactions_list_res=mysqli_fetch_array($transactions_list_query);

//=== End transactions select  Like Query String transactions list

}elseif(isset($_GET['qmonthly_report'])){

//===== limit record value
$qmonthly_report1=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['qmonthly_report']));

$qmonthly_report=date('M-Y', strtotime($qmonthly_report1));

$transactions_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`transactions` WHERE month_year='$qmonthly_report' ";

//===== Pagination function

$transactions_pagination= list_record_per_page($mysqliconn, $transactions_sqlstring, $datalimit);


//===== get return values


$transactions_firstproduct=$transactions_pagination["0"];

$transactions_pgcount=$transactions_pagination["1"];

//=== start transactions select  Like Query String transactions list  

$transactions_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`transactions` WHERE month_year='$qmonthly_report'  ORDER BY `primkey` DESC LIMIT $transactions_firstproduct, $datalimit" );

//$transactions_list_res=mysqli_fetch_array($transactions_list_query);

//=== End transactions select  Like Query String transactions list

}elseif(isset($_GET['qclient_id'])){
  
$qclient_id=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['qclient_id']));


//===== limit record value

$transactions_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`transactions` WHERE client_id='$qclient_id'";

//===== Pagination function

$transactions_pagination= list_record_per_page($mysqliconn, $transactions_sqlstring, $datalimit);


//===== get return values


$transactions_firstproduct=$transactions_pagination["0"];

$transactions_pgcount=$transactions_pagination["1"];

//=== start transactions select  Like Query String transactions list  

$transactions_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`transactions` WHERE client_id='$qclient_id'  ORDER BY `transaction_date` DESC  LIMIT $transactions_firstproduct, $datalimit" );

//$transactions_list_res=mysqli_fetch_array($transactions_list_query);

//=== End transactions select  Like Query String transactions list

}elseif(isset($_GET['qstatus'])){
  
$qstatus=mysqli_real_escape_string($mysqliconn, ($_GET['qstatus']));


//===== limit record value

$transactions_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`transactions` WHERE status='$qstatus'";

//===== Pagination function

$transactions_pagination= list_record_per_page($mysqliconn, $transactions_sqlstring, $datalimit);


//===== get return values


$transactions_firstproduct=$transactions_pagination["0"];

$transactions_pgcount=$transactions_pagination["1"];

//=== start transactions select  Like Query String transactions list  

$transactions_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`transactions` WHERE status='$qstatus'  ORDER BY `primkey` DESC LIMIT $transactions_firstproduct, $datalimit" );

//$transactions_list_res=mysqli_fetch_array($transactions_list_query);

//=== End transactions select  Like Query String transactions list

}else{

//===== limit record value

$transactions_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`transactions`";

//===== Pagination function

$transactions_pagination= list_record_per_page($mysqliconn, $transactions_sqlstring, $datalimit);


//===== get return values


$transactions_firstproduct=$transactions_pagination["0"];

$transactions_pgcount=$transactions_pagination["1"];

//=== start transactions select  Like Query String transactions list  

$transactions_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`transactions`  ORDER BY `primkey` DESC LIMIT $transactions_firstproduct, $datalimit" );

//$transactions_list_res=mysqli_fetch_array($transactions_list_query);

//=== End transactions select  Like Query String transactions list

}


//== Start  **** Delete transactions Records  

if(isset($_GET["deletetransactions"]))
{

//======confirm pop up 

$conf_del_transactions_btn=magic_button_link("./edittransactions.php?transactions_uptoken=".$_GET["transactions_uptoken"]."&conf_deletetransactions", "Yes", 'style="margin-right:10px;"');

$cancel_del_transactions_btn=magic_button_link("./edittransactions.php?transactions_uptoken=".$_GET["transactions_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_transactions_btn." ".$cancel_del_transactions_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deletetransactions"]))
{
$trx_primkey=$transactions_node['transaction_id'];

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`transactions` WHERE `primkey`='$transactions_uptoken'");
mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`client_charges` WHERE `trx_id`='$trx_primkey'");

//==add your redirect here 

header("location:./transactions.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete transactions Records 

//--<{ncgh}/>
?>