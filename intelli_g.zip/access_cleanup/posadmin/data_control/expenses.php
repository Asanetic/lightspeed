<?php 

		//== initialize edit token variables

		$expenses_uptoken="";

		if(isset($_GET["expenses_uptoken"]))
		{
		$expenses_uptoken=base64_decode($_GET["expenses_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["expenses_insert_btn"])){
//------- begin Create Update record from expenses --> 
$transaction_id=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$transaction_ref=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_ref"]);
$amount_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount_paid"]);
$transaction_type=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_type"]);
$transaction_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_date"]);
$month_year=mysqli_real_escape_string($mysqliconn, date("M-Y", strtotime($_POST["txt_transaction_date"])));
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$received_by=mysqli_real_escape_string($mysqliconn,"");
$confirmed_by=mysqli_real_escape_string($mysqliconn, "");
$remark=mysqli_real_escape_string($mysqliconn, $_POST["txt_remark"]);
$admin_id=mysqli_real_escape_string($mysqliconn, $_SESSION['infocms_admin_session_admin_id']);
$payment_mode=mysqli_real_escape_string($mysqliconn, $_POST["txt_payment_mode"]);
//===-- End Create Update record from expenses -->


$expenses_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolink_cmsv2`.`expenses` (`primkey`,`transaction_id`,`transaction_ref`,`amount_paid`,`transaction_type`,`transaction_date`,`month_year`,`client_id`,`received_by`,`confirmed_by`,`remark`,`admin_id`,`payment_mode`) 
 VALUES 
(NULL,'$transaction_id','$transaction_ref','$amount_paid','$transaction_type','$transaction_date','$month_year','$client_id','$received_by','$confirmed_by','$remark','$admin_id','$payment_mode')");

 //--- get primary key id
$expenses_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?expenses_uptoken='.base64_encode($expenses_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["expenses_update_btn"])){
//------- begin Create Update record from expenses --> 
$transaction_ref=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_ref"]);
$amount_paid=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount_paid"]);
$transaction_type=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_type"]);
$transaction_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_transaction_date"]);
$month_year=mysqli_real_escape_string($mysqliconn, date("M-Y", strtotime($_POST["txt_transaction_date"])));
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
$received_by=mysqli_real_escape_string($mysqliconn,"");
$confirmed_by=mysqli_real_escape_string($mysqliconn, "");
$remark=mysqli_real_escape_string($mysqliconn, $_POST["txt_remark"]);
$admin_id=mysqli_real_escape_string($mysqliconn, $_SESSION['infocms_admin_session_admin_id']);
$payment_mode=mysqli_real_escape_string($mysqliconn, $_POST["txt_payment_mode"]);
//===-- End Create Update record from expenses -->


$expenses_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolink_cmsv2`.`expenses` SET `transaction_ref`='$transaction_ref',`amount_paid`='$amount_paid',`transaction_type`='$transaction_type',`transaction_date`='$transaction_date',`month_year`='$month_year',`client_id`='$client_id',`received_by`='$received_by',`confirmed_by`='$confirmed_by',`remark`='$remark',`admin_id`='$admin_id',`payment_mode`='$payment_mode' WHERE primkey='$expenses_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?expenses_uptoken='.base64_encode($expenses_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start expenses select Find expenses Records Profile query 

$find_expenses_records_profile_expenses_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolink_cmsv2`.`expenses` WHERE `primkey`='$expenses_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$expenses_node=mysqli_fetch_array($find_expenses_records_profile_expenses_query);

//=== End expenses select Find expenses Records Profile  query




if(isset($_POST["qexpenses_btn"])){


$qexpenses_str=base64_encode($_POST["txt_expenses"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qexpenses='.($qexpenses_str).'');

}

if(isset($_GET["qexpenses"])){


$qexpenses=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qexpenses"]));



//===== limit record value

$expenses_sqlstring="SELECT COUNT(*) FROM `$infolink_cmsv2`.`expenses` WHERE (`primkey` LIKE '%".$qexpenses."%' OR  `transaction_id` LIKE '%".$qexpenses."%' OR  `transaction_ref` LIKE '%".$qexpenses."%' OR  `amount_paid` LIKE '%".$qexpenses."%' OR  `transaction_type` LIKE '%".$qexpenses."%' OR  `transaction_date` LIKE '%".$qexpenses."%' OR  `month_year` LIKE '%".$qexpenses."%' OR  `client_id` LIKE '%".$qexpenses."%' OR  `received_by` LIKE '%".$qexpenses."%' OR  `confirmed_by` LIKE '%".$qexpenses."%' OR  `remark` LIKE '%".$qexpenses."%' OR  `admin_id` LIKE '%".$qexpenses."%' OR  `payment_mode` LIKE '%".$qexpenses."%')";

//===== Pagination function

$expenses_pagination= list_record_per_page($mysqliconn, $expenses_sqlstring, $datalimit);


//===== get return values


$expenses_firstproduct=$expenses_pagination["0"];

$expenses_pgcount=$expenses_pagination["1"];

//=== start expenses select  Like Query String expenses list  

$expenses_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolink_cmsv2`.`expenses`  WHERE (`primkey` LIKE '%".$qexpenses."%' OR  `transaction_id` LIKE '%".$qexpenses."%' OR  `transaction_ref` LIKE '%".$qexpenses."%' OR  `amount_paid` LIKE '%".$qexpenses."%' OR  `transaction_type` LIKE '%".$qexpenses."%' OR  `transaction_date` LIKE '%".$qexpenses."%' OR  `month_year` LIKE '%".$qexpenses."%' OR  `client_id` LIKE '%".$qexpenses."%' OR  `received_by` LIKE '%".$qexpenses."%' OR  `confirmed_by` LIKE '%".$qexpenses."%' OR  `remark` LIKE '%".$qexpenses."%' OR  `admin_id` LIKE '%".$qexpenses."%' OR  `payment_mode` LIKE '%".$qexpenses."%') ORDER BY `primkey` DESC LIMIT $expenses_firstproduct, $datalimit" );



//=== End expenses select  Like Query String expenses list
;

}else{

//===== limit record value

$expenses_sqlstring="SELECT COUNT(*) FROM `$infolink_cmsv2`.`expenses`";

//===== Pagination function

$expenses_pagination= list_record_per_page($mysqliconn, $expenses_sqlstring, $datalimit);


//===== get return values


$expenses_firstproduct=$expenses_pagination["0"];

$expenses_pgcount=$expenses_pagination["1"];

//=== start expenses select  Like Query String expenses list  

$expenses_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolink_cmsv2`.`expenses`  ORDER BY `primkey` DESC LIMIT $expenses_firstproduct, $datalimit" );

//$expenses_list_res=mysqli_fetch_array($expenses_list_query);

//=== End expenses select  Like Query String expenses list

}


//== Start  **** Delete expenses Records  

if(isset($_GET["deleteexpenses"]))
{

//======confirm pop up 

$conf_del_expenses_btn=magic_button_link("./editexpenses.php?expenses_uptoken=".$_GET["expenses_uptoken"]."&conf_deleteexpenses", "Yes", 'style="margin-right:10px;"');

$cancel_del_expenses_btn=magic_button_link("./editexpenses.php?expenses_uptoken=".$_GET["expenses_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_expenses_btn." ".$cancel_del_expenses_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deleteexpenses"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolink_cmsv2`.`expenses` WHERE `primkey`='$expenses_uptoken'");

//==add your redirect here 

header("location:./expenses.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete expenses Records 

//--<{ncgh}/>
?>