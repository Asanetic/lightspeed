<?php 
//===============Start Mosy queries-============ 

    
 	//Start Add active_client_months Data ===============
 	function add_active_client_months($active_client_months_arr_)
    {
     $gw_active_client_months_cols=array();
     
     foreach($active_client_months_arr_ as $active_client_months_arr_gw => $active_client_months_arr_gw_val)
     {
     
     	$gw_active_client_months_cols[]=$active_client_months_arr_gw;
        
     }
     
     $gw_active_client_months_cols_str=implode(",", $gw_active_client_months_cols);
     
     $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "insert",$gw_active_client_months_cols_str);
     
     $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
     
     if($gwauthenticate_active_client_months_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("active_client_months", $active_client_months_arr_);
     
     	//echo $gwauthenticate_active_client_months_;

     }else{
     
     	echo $gwauthenticate_active_client_months_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");

     }
     
    }
    
       function initialize_active_client_months()
        {
        
         global $active_client_months_uptoken;
             
         $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "select","");

         $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
         	
          //echo $gwauthenticate_active_client_months_;

         if($gwauthenticate_active_client_months_json["response"]=="ok")
         {
         
         	return get_active_client_months("*", "WHERE primkey='$active_client_months_uptoken'", "r");
         
            echo $gwauthenticate_active_client_months_;

         }else{

         	echo $gwauthenticate_active_client_months_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");
         
         }
        }   
    //End Add active_client_months Data ===============
                
    //Start Update active_client_months Data ===============
    
 	function update_active_client_months($active_client_months_arr_, $where_str)
    {
         $gw_active_client_months_cols=array();
     
     foreach($active_client_months_arr_ as $active_client_months_arr_gw => $active_client_months_arr_gw_val)
     {
     
     	$gw_active_client_months_cols[]=$active_client_months_arr_gw;
        
     }
     
     $gw_active_client_months_cols_str=implode(",", $gw_active_client_months_cols);
     
     $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "update",$gw_active_client_months_cols_str);
     
     $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
     
     if($gwauthenticate_active_client_months_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("active_client_months", $active_client_months_arr_, $where_str);

       // echo $gwauthenticate_active_client_months_;
        
        exit;

     }else{

        echo $gwauthenticate_active_client_months_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");


      }
    
    }
 	
    
    //End Update active_client_months Data ===============

    //Start get  active_client_months Data ===============
    
    function get_active_client_months($colstr, $where_str, $type)
    {
          
     $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "select","");
     
     $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
     
     if($gwauthenticate_active_client_months_json["response"]=="ok")
     {
    	return mosyflex_sel("active_client_months", $colstr, $where_str, $type);

        //echo $gwauthenticate_active_client_months_;

	  }else{
     
     	echo $gwauthenticate_active_client_months_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");


     }    
    }
    //End get  active_client_months Data ===============
    
    
    //======== qactive_client_months_data qsingle query function
    
    function qactive_client_months_data($qarrid_key)
    {
          
     $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "qdata","");
     
     $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
     
     if($gwauthenticate_active_client_months_json["response"]=="ok")
     {    
    	return get_active_client_months("*", "WHERE arrid='$qarrid_key'", "r");

		//echo $gwauthenticate_active_client_months_;

      }else{
     
     	echo $gwauthenticate_active_client_months_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");


     }  
    }
   
    //======== qactive_client_months_data qsingle query function
    
        
    //======== qactive_client_months_ddata qsingle query function    
    function qactive_client_months_ddata($arrid_col, $qarrid_key)
    {
     
     $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "qddata","");
     
     $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
     
     if($gwauthenticate_active_client_months_json["response"]=="ok")
     {    
    	return get_active_client_months("*", "WHERE $arrid_col='$qarrid_key'", "r");

		//echo $gwauthenticate_active_client_months_;

     }else{
     
     	echo $gwauthenticate_active_client_months_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");


     }   
    }
    //======== qactive_client_months_ddata qsingle query function

    //======== count active_client_months data function
    
    function count_active_client_months($active_client_months_wherestr)
    {
     
     $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "count_data","");
     
     $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
     
     if($gwauthenticate_active_client_months_json["response"]=="ok")
     {    
      $clean_active_client_months_where_str="";
  
      if($active_client_months_wherestr!='')
      {
        $clean_active_client_months_where_str="Where ".$active_client_months_wherestr;
      }

      return get_active_client_months("count(*) as return_result", " ".$clean_active_client_months_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_active_client_months_;

      }else{
     
     	echo $gwauthenticate_active_client_months_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");


     }    
    }
    //======== count active_client_months data function

    //======== sum  active_client_months data function
    
    function sum_active_client_months($active_client_months_sumcol, $active_client_months_wherestr)
    {
     
     $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "sum_data","");
     
     $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
     
     if($gwauthenticate_active_client_months_json["response"]=="ok")
     {    
      $clean_active_client_months_where_str="";
  
      if($active_client_months_wherestr!='')
      {
        $clean_active_client_months_where_str="Where ".$active_client_months_wherestr;
      }

      return get_active_client_months("sum($active_client_months_sumcol) as return_result", " ".$clean_active_client_months_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_active_client_months_;


      }else{
     
     	echo $gwauthenticate_active_client_months_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");
        


     }    
    }
    
    //======== sum  active_client_months data function   
    
    
    //Start drop  active_client_months Data ===============
    
    function drop_active_client_months($where_str)
    {
     
     $gwauthenticate_active_client_months_=gw_oauth("table", magic_current_url(), "active_client_months", "drop_data","");
     
     $gwauthenticate_active_client_months_json=json_decode($gwauthenticate_active_client_months_, true);
     
     if($gwauthenticate_active_client_months_json["response"]=="ok")
     {    
    	return magic_sql_delete("active_client_months", $where_str);

		//echo $gwauthenticate_active_client_months_;

      }else{
     
     	echo $gwauthenticate_active_client_months_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_active_client_months_)."");
		

     }
    }
    //End drop  active_client_months Data ===============    
    
    
   

    
 	//Start Add address_book Data ===============
 	function add_address_book($address_book_arr_)
    {
     $gw_address_book_cols=array();
     
     foreach($address_book_arr_ as $address_book_arr_gw => $address_book_arr_gw_val)
     {
     
     	$gw_address_book_cols[]=$address_book_arr_gw;
        
     }
     
     $gw_address_book_cols_str=implode(",", $gw_address_book_cols);
     
     $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "insert",$gw_address_book_cols_str);
     
     $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
     
     if($gwauthenticate_address_book_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("address_book", $address_book_arr_);
     
     	//echo $gwauthenticate_address_book_;

     }else{
     
     	echo $gwauthenticate_address_book_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");

     }
     
    }
    
       function initialize_address_book()
        {
        
         global $address_book_uptoken;
             
         $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "select","");

         $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
         	
          //echo $gwauthenticate_address_book_;

         if($gwauthenticate_address_book_json["response"]=="ok")
         {
         
         	return get_address_book("*", "WHERE primkey='$address_book_uptoken'", "r");
         
            echo $gwauthenticate_address_book_;

         }else{

         	echo $gwauthenticate_address_book_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");
         
         }
        }   
    //End Add address_book Data ===============
                
    //Start Update address_book Data ===============
    
 	function update_address_book($address_book_arr_, $where_str)
    {
         $gw_address_book_cols=array();
     
     foreach($address_book_arr_ as $address_book_arr_gw => $address_book_arr_gw_val)
     {
     
     	$gw_address_book_cols[]=$address_book_arr_gw;
        
     }
     
     $gw_address_book_cols_str=implode(",", $gw_address_book_cols);
     
     $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "update",$gw_address_book_cols_str);
     
     $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
     
     if($gwauthenticate_address_book_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("address_book", $address_book_arr_, $where_str);

       // echo $gwauthenticate_address_book_;
        
        exit;

     }else{

        echo $gwauthenticate_address_book_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");


      }
    
    }
 	
    
    //End Update address_book Data ===============

    //Start get  address_book Data ===============
    
    function get_address_book($colstr, $where_str, $type)
    {
          
     $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "select","");
     
     $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
     
     if($gwauthenticate_address_book_json["response"]=="ok")
     {
    	return mosyflex_sel("address_book", $colstr, $where_str, $type);

        //echo $gwauthenticate_address_book_;

	  }else{
     
     	echo $gwauthenticate_address_book_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");


     }    
    }
    //End get  address_book Data ===============
    
    
    //======== qaddress_book_data qsingle query function
    
    function qaddress_book_data($qcontact_id_key)
    {
          
     $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "qdata","");
     
     $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
     
     if($gwauthenticate_address_book_json["response"]=="ok")
     {    
    	return get_address_book("*", "WHERE contact_id='$qcontact_id_key'", "r");

		//echo $gwauthenticate_address_book_;

      }else{
     
     	echo $gwauthenticate_address_book_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");


     }  
    }
   
    //======== qaddress_book_data qsingle query function
    
        
    //======== qaddress_book_ddata qsingle query function    
    function qaddress_book_ddata($contact_id_col, $qcontact_id_key)
    {
     
     $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "qddata","");
     
     $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
     
     if($gwauthenticate_address_book_json["response"]=="ok")
     {    
    	return get_address_book("*", "WHERE $contact_id_col='$qcontact_id_key'", "r");

		//echo $gwauthenticate_address_book_;

     }else{
     
     	echo $gwauthenticate_address_book_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");


     }   
    }
    //======== qaddress_book_ddata qsingle query function

    //======== count address_book data function
    
    function count_address_book($address_book_wherestr)
    {
     
     $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "count_data","");
     
     $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
     
     if($gwauthenticate_address_book_json["response"]=="ok")
     {    
      $clean_address_book_where_str="";
  
      if($address_book_wherestr!='')
      {
        $clean_address_book_where_str="Where ".$address_book_wherestr;
      }

      return get_address_book("count(*) as return_result", " ".$clean_address_book_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_address_book_;

      }else{
     
     	echo $gwauthenticate_address_book_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");


     }    
    }
    //======== count address_book data function

    //======== sum  address_book data function
    
    function sum_address_book($address_book_sumcol, $address_book_wherestr)
    {
     
     $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "sum_data","");
     
     $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
     
     if($gwauthenticate_address_book_json["response"]=="ok")
     {    
      $clean_address_book_where_str="";
  
      if($address_book_wherestr!='')
      {
        $clean_address_book_where_str="Where ".$address_book_wherestr;
      }

      return get_address_book("sum($address_book_sumcol) as return_result", " ".$clean_address_book_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_address_book_;


      }else{
     
     	echo $gwauthenticate_address_book_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");
        


     }    
    }
    
    //======== sum  address_book data function   
    
    
    //Start drop  address_book Data ===============
    
    function drop_address_book($where_str)
    {
     
     $gwauthenticate_address_book_=gw_oauth("table", magic_current_url(), "address_book", "drop_data","");
     
     $gwauthenticate_address_book_json=json_decode($gwauthenticate_address_book_, true);
     
     if($gwauthenticate_address_book_json["response"]=="ok")
     {    
    	return magic_sql_delete("address_book", $where_str);

		//echo $gwauthenticate_address_book_;

      }else{
     
     	echo $gwauthenticate_address_book_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_address_book_)."");
		

     }
    }
    //End drop  address_book Data ===============    
    
    
   

    
 	//Start Add admin Data ===============
 	function add_admin($admin_arr_)
    {
     $gw_admin_cols=array();
     
     foreach($admin_arr_ as $admin_arr_gw => $admin_arr_gw_val)
     {
     
     	$gw_admin_cols[]=$admin_arr_gw;
        
     }
     
     $gw_admin_cols_str=implode(",", $gw_admin_cols);
     
     $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "insert",$gw_admin_cols_str);
     
     $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
     
     if($gwauthenticate_admin_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("admin", $admin_arr_);
     
     	//echo $gwauthenticate_admin_;

     }else{
     
     	echo $gwauthenticate_admin_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");

     }
     
    }
    
       function initialize_admin()
        {
        
         global $admin_uptoken;
             
         $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "select","");

         $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
         	
          //echo $gwauthenticate_admin_;

         if($gwauthenticate_admin_json["response"]=="ok")
         {
         
         	return get_admin("*", "WHERE primkey='$admin_uptoken'", "r");
         
            echo $gwauthenticate_admin_;

         }else{

         	echo $gwauthenticate_admin_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");
         
         }
        }   
    //End Add admin Data ===============
                
    //Start Update admin Data ===============
    
 	function update_admin($admin_arr_, $where_str)
    {
         $gw_admin_cols=array();
     
     foreach($admin_arr_ as $admin_arr_gw => $admin_arr_gw_val)
     {
     
     	$gw_admin_cols[]=$admin_arr_gw;
        
     }
     
     $gw_admin_cols_str=implode(",", $gw_admin_cols);
     
     $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "update",$gw_admin_cols_str);
     
     $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
     
     if($gwauthenticate_admin_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("admin", $admin_arr_, $where_str);

       // echo $gwauthenticate_admin_;
        
        exit;

     }else{

        echo $gwauthenticate_admin_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");


      }
    
    }
 	
    
    //End Update admin Data ===============

    //Start get  admin Data ===============
    
    function get_admin($colstr, $where_str, $type)
    {
          
     $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "select","");
     
     $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
     
     if($gwauthenticate_admin_json["response"]=="ok")
     {
    	return mosyflex_sel("admin", $colstr, $where_str, $type);

        //echo $gwauthenticate_admin_;

	  }else{
     
     	echo $gwauthenticate_admin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");


     }    
    }
    //End get  admin Data ===============
    
    
    //======== qadmin_data qsingle query function
    
    function qadmin_data($qadmin_id_key)
    {
          
     $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "qdata","");
     
     $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
     
     if($gwauthenticate_admin_json["response"]=="ok")
     {    
    	return get_admin("*", "WHERE admin_id='$qadmin_id_key'", "r");

		//echo $gwauthenticate_admin_;

      }else{
     
     	echo $gwauthenticate_admin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");


     }  
    }
   
    //======== qadmin_data qsingle query function
    
        
    //======== qadmin_ddata qsingle query function    
    function qadmin_ddata($admin_id_col, $qadmin_id_key)
    {
     
     $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "qddata","");
     
     $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
     
     if($gwauthenticate_admin_json["response"]=="ok")
     {    
    	return get_admin("*", "WHERE $admin_id_col='$qadmin_id_key'", "r");

		//echo $gwauthenticate_admin_;

     }else{
     
     	echo $gwauthenticate_admin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");


     }   
    }
    //======== qadmin_ddata qsingle query function

    //======== count admin data function
    
    function count_admin($admin_wherestr)
    {
     
     $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "count_data","");
     
     $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
     
     if($gwauthenticate_admin_json["response"]=="ok")
     {    
      $clean_admin_where_str="";
  
      if($admin_wherestr!='')
      {
        $clean_admin_where_str="Where ".$admin_wherestr;
      }

      return get_admin("count(*) as return_result", " ".$clean_admin_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_admin_;

      }else{
     
     	echo $gwauthenticate_admin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");


     }    
    }
    //======== count admin data function

    //======== sum  admin data function
    
    function sum_admin($admin_sumcol, $admin_wherestr)
    {
     
     $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "sum_data","");
     
     $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
     
     if($gwauthenticate_admin_json["response"]=="ok")
     {    
      $clean_admin_where_str="";
  
      if($admin_wherestr!='')
      {
        $clean_admin_where_str="Where ".$admin_wherestr;
      }

      return get_admin("sum($admin_sumcol) as return_result", " ".$clean_admin_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_admin_;


      }else{
     
     	echo $gwauthenticate_admin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");
        


     }    
    }
    
    //======== sum  admin data function   
    
    
    //Start drop  admin Data ===============
    
    function drop_admin($where_str)
    {
     
     $gwauthenticate_admin_=gw_oauth("table", magic_current_url(), "admin", "drop_data","");
     
     $gwauthenticate_admin_json=json_decode($gwauthenticate_admin_, true);
     
     if($gwauthenticate_admin_json["response"]=="ok")
     {    
    	return magic_sql_delete("admin", $where_str);

		//echo $gwauthenticate_admin_;

      }else{
     
     	echo $gwauthenticate_admin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_admin_)."");
		

     }
    }
    //End drop  admin Data ===============    
    
    
            //Start Upload admin_photo Function 
            function upload_admin_photo($txt_admin_photo, $where_str){
              
			  $file_name1=explode(".", basename($_FILES[$txt_admin_photo]['name']))[0];

              $file_name=str_replace(" ", "_", $file_name1);
 				
              if (!file_exists('./img/admin_photo')) @mkdir('./img/admin_photo');

              $cur_item_photos=magic_upload_file('./img/admin_photo/', $txt_admin_photo, $file_name."_".magic_random_str(5));

              $item_photo=mmres($cur_item_photos);

              magic_compress_file($cur_item_photos, $cur_item_photos, 50);
              
              $admin_node=get_admin("*", "WHERE ".$where_str."", "r");

              unlink($admin_node["photo"]);

              magic_sql_update('admin', '{"photo":"'.$cur_item_photos.'"}', $where_str);

			}
           //End Upload admin_photo Function 

            
   

    
 	//Start Add client_base Data ===============
 	function add_client_base($client_base_arr_)
    {
     $gw_client_base_cols=array();
     
     foreach($client_base_arr_ as $client_base_arr_gw => $client_base_arr_gw_val)
     {
     
     	$gw_client_base_cols[]=$client_base_arr_gw;
        
     }
     
     $gw_client_base_cols_str=implode(",", $gw_client_base_cols);
     
     $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "insert",$gw_client_base_cols_str);
     
     $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
     
     if($gwauthenticate_client_base_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("client_base", $client_base_arr_);
     
     	//echo $gwauthenticate_client_base_;

     }else{
     
     	echo $gwauthenticate_client_base_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");

     }
     
    }
    
       function initialize_client_base()
        {
        
         global $client_base_uptoken;
             
         $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "select","");

         $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
         	
          //echo $gwauthenticate_client_base_;

         if($gwauthenticate_client_base_json["response"]=="ok")
         {
         
         	return get_client_base("*", "WHERE primkey='$client_base_uptoken'", "r");
         
            echo $gwauthenticate_client_base_;

         }else{

         	echo $gwauthenticate_client_base_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");
         
         }
        }   
    //End Add client_base Data ===============
                
    //Start Update client_base Data ===============
    
 	function update_client_base($client_base_arr_, $where_str)
    {
         $gw_client_base_cols=array();
     
     foreach($client_base_arr_ as $client_base_arr_gw => $client_base_arr_gw_val)
     {
     
     	$gw_client_base_cols[]=$client_base_arr_gw;
        
     }
     
     $gw_client_base_cols_str=implode(",", $gw_client_base_cols);
     
     $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "update",$gw_client_base_cols_str);
     
     $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
     
     if($gwauthenticate_client_base_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("client_base", $client_base_arr_, $where_str);

       // echo $gwauthenticate_client_base_;
        
        exit;

     }else{

        echo $gwauthenticate_client_base_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");


      }
    
    }
 	
    
    //End Update client_base Data ===============

    //Start get  client_base Data ===============
    
    function get_client_base($colstr, $where_str, $type)
    {
          
     $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "select","");
     
     $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
     
     if($gwauthenticate_client_base_json["response"]=="ok")
     {
    	return mosyflex_sel("client_base", $colstr, $where_str, $type);

        //echo $gwauthenticate_client_base_;

	  }else{
     
     	echo $gwauthenticate_client_base_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");


     }    
    }
    //End get  client_base Data ===============
    
    
    //======== qclient_base_data qsingle query function
    
    function qclient_base_data($qclient_id_key)
    {
          
     $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "qdata","");
     
     $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
     
     if($gwauthenticate_client_base_json["response"]=="ok")
     {    
    	return get_client_base("*", "WHERE client_id='$qclient_id_key'", "r");

		//echo $gwauthenticate_client_base_;

      }else{
     
     	echo $gwauthenticate_client_base_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");


     }  
    }
   
    //======== qclient_base_data qsingle query function
    
        
    //======== qclient_base_ddata qsingle query function    
    function qclient_base_ddata($client_id_col, $qclient_id_key)
    {
     
     $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "qddata","");
     
     $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
     
     if($gwauthenticate_client_base_json["response"]=="ok")
     {    
    	return get_client_base("*", "WHERE $client_id_col='$qclient_id_key'", "r");

		//echo $gwauthenticate_client_base_;

     }else{
     
     	echo $gwauthenticate_client_base_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");


     }   
    }
    //======== qclient_base_ddata qsingle query function

    //======== count client_base data function
    
    function count_client_base($client_base_wherestr)
    {
     
     $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "count_data","");
     
     $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
     
     if($gwauthenticate_client_base_json["response"]=="ok")
     {    
      $clean_client_base_where_str="";
  
      if($client_base_wherestr!='')
      {
        $clean_client_base_where_str="Where ".$client_base_wherestr;
      }

      return get_client_base("count(*) as return_result", " ".$clean_client_base_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_client_base_;

      }else{
     
     	echo $gwauthenticate_client_base_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");


     }    
    }
    //======== count client_base data function

    //======== sum  client_base data function
    
    function sum_client_base($client_base_sumcol, $client_base_wherestr)
    {
     
     $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "sum_data","");
     
     $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
     
     if($gwauthenticate_client_base_json["response"]=="ok")
     {    
      $clean_client_base_where_str="";
  
      if($client_base_wherestr!='')
      {
        $clean_client_base_where_str="Where ".$client_base_wherestr;
      }

      return get_client_base("sum($client_base_sumcol) as return_result", " ".$clean_client_base_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_client_base_;


      }else{
     
     	echo $gwauthenticate_client_base_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");
        


     }    
    }
    
    //======== sum  client_base data function   
    
    
    //Start drop  client_base Data ===============
    
    function drop_client_base($where_str)
    {
     
     $gwauthenticate_client_base_=gw_oauth("table", magic_current_url(), "client_base", "drop_data","");
     
     $gwauthenticate_client_base_json=json_decode($gwauthenticate_client_base_, true);
     
     if($gwauthenticate_client_base_json["response"]=="ok")
     {    
    	return magic_sql_delete("client_base", $where_str);

		//echo $gwauthenticate_client_base_;

      }else{
     
     	echo $gwauthenticate_client_base_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_base_)."");
		

     }
    }
    //End drop  client_base Data ===============    
    
    
            //Start Upload client_base_photo Function 
            function upload_client_base_photo($txt_client_base_photo, $where_str){
              
			  $file_name1=explode(".", basename($_FILES[$txt_client_base_photo]['name']))[0];

              $file_name=str_replace(" ", "_", $file_name1);
 				
              if (!file_exists('./img/client_base_photo')) @mkdir('./img/client_base_photo');

              $cur_item_photos=magic_upload_file('./img/client_base_photo/', $txt_client_base_photo, $file_name."_".magic_random_str(5));

              $item_photo=mmres($cur_item_photos);

              magic_compress_file($cur_item_photos, $cur_item_photos, 50);
              
              $client_base_node=get_client_base("*", "WHERE ".$where_str."", "r");

              unlink($client_base_node["photo"]);

              magic_sql_update('client_base', '{"photo":"'.$cur_item_photos.'"}', $where_str);

			}
           //End Upload client_base_photo Function 

            
   

    
 	//Start Add client_charges Data ===============
 	function add_client_charges($client_charges_arr_)
    {
     $gw_client_charges_cols=array();
     
     foreach($client_charges_arr_ as $client_charges_arr_gw => $client_charges_arr_gw_val)
     {
     
     	$gw_client_charges_cols[]=$client_charges_arr_gw;
        
     }
     
     $gw_client_charges_cols_str=implode(",", $gw_client_charges_cols);
     
     $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "insert",$gw_client_charges_cols_str);
     
     $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
     
     if($gwauthenticate_client_charges_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("client_charges", $client_charges_arr_);
     
     	//echo $gwauthenticate_client_charges_;

     }else{
     
     	echo $gwauthenticate_client_charges_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");

     }
     
    }
    
       function initialize_client_charges()
        {
        
         global $client_charges_uptoken;
             
         $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "select","");

         $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
         	
          //echo $gwauthenticate_client_charges_;

         if($gwauthenticate_client_charges_json["response"]=="ok")
         {
         
         	return get_client_charges("*", "WHERE primkey='$client_charges_uptoken'", "r");
         
            echo $gwauthenticate_client_charges_;

         }else{

         	echo $gwauthenticate_client_charges_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");
         
         }
        }   
    //End Add client_charges Data ===============
                
    //Start Update client_charges Data ===============
    
 	function update_client_charges($client_charges_arr_, $where_str)
    {
         $gw_client_charges_cols=array();
     
     foreach($client_charges_arr_ as $client_charges_arr_gw => $client_charges_arr_gw_val)
     {
     
     	$gw_client_charges_cols[]=$client_charges_arr_gw;
        
     }
     
     $gw_client_charges_cols_str=implode(",", $gw_client_charges_cols);
     
     $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "update",$gw_client_charges_cols_str);
     
     $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
     
     if($gwauthenticate_client_charges_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("client_charges", $client_charges_arr_, $where_str);

       // echo $gwauthenticate_client_charges_;
        
        exit;

     }else{

        echo $gwauthenticate_client_charges_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");


      }
    
    }
 	
    
    //End Update client_charges Data ===============

    //Start get  client_charges Data ===============
    
    function get_client_charges($colstr, $where_str, $type)
    {
          
     $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "select","");
     
     $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
     
     if($gwauthenticate_client_charges_json["response"]=="ok")
     {
    	return mosyflex_sel("client_charges", $colstr, $where_str, $type);

        //echo $gwauthenticate_client_charges_;

	  }else{
     
     	echo $gwauthenticate_client_charges_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");


     }    
    }
    //End get  client_charges Data ===============
    
    
    //======== qclient_charges_data qsingle query function
    
    function qclient_charges_data($qcharge_id_key)
    {
          
     $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "qdata","");
     
     $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
     
     if($gwauthenticate_client_charges_json["response"]=="ok")
     {    
    	return get_client_charges("*", "WHERE charge_id='$qcharge_id_key'", "r");

		//echo $gwauthenticate_client_charges_;

      }else{
     
     	echo $gwauthenticate_client_charges_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");


     }  
    }
   
    //======== qclient_charges_data qsingle query function
    
        
    //======== qclient_charges_ddata qsingle query function    
    function qclient_charges_ddata($charge_id_col, $qcharge_id_key)
    {
     
     $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "qddata","");
     
     $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
     
     if($gwauthenticate_client_charges_json["response"]=="ok")
     {    
    	return get_client_charges("*", "WHERE $charge_id_col='$qcharge_id_key'", "r");

		//echo $gwauthenticate_client_charges_;

     }else{
     
     	echo $gwauthenticate_client_charges_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");


     }   
    }
    //======== qclient_charges_ddata qsingle query function

    //======== count client_charges data function
    
    function count_client_charges($client_charges_wherestr)
    {
     
     $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "count_data","");
     
     $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
     
     if($gwauthenticate_client_charges_json["response"]=="ok")
     {    
      $clean_client_charges_where_str="";
  
      if($client_charges_wherestr!='')
      {
        $clean_client_charges_where_str="Where ".$client_charges_wherestr;
      }

      return get_client_charges("count(*) as return_result", " ".$clean_client_charges_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_client_charges_;

      }else{
     
     	echo $gwauthenticate_client_charges_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");


     }    
    }
    //======== count client_charges data function

    //======== sum  client_charges data function
    
    function sum_client_charges($client_charges_sumcol, $client_charges_wherestr)
    {
     
     $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "sum_data","");
     
     $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
     
     if($gwauthenticate_client_charges_json["response"]=="ok")
     {    
      $clean_client_charges_where_str="";
  
      if($client_charges_wherestr!='')
      {
        $clean_client_charges_where_str="Where ".$client_charges_wherestr;
      }

      return get_client_charges("sum($client_charges_sumcol) as return_result", " ".$clean_client_charges_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_client_charges_;


      }else{
     
     	echo $gwauthenticate_client_charges_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");
        


     }    
    }
    
    //======== sum  client_charges data function   
    
    
    //Start drop  client_charges Data ===============
    
    function drop_client_charges($where_str)
    {
     
     $gwauthenticate_client_charges_=gw_oauth("table", magic_current_url(), "client_charges", "drop_data","");
     
     $gwauthenticate_client_charges_json=json_decode($gwauthenticate_client_charges_, true);
     
     if($gwauthenticate_client_charges_json["response"]=="ok")
     {    
    	return magic_sql_delete("client_charges", $where_str);

		//echo $gwauthenticate_client_charges_;

      }else{
     
     	echo $gwauthenticate_client_charges_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_client_charges_)."");
		

     }
    }
    //End drop  client_charges Data ===============    
    
    
   

    
 	//Start Add dtclean Data ===============
 	function add_dtclean($dtclean_arr_)
    {
     $gw_dtclean_cols=array();
     
     foreach($dtclean_arr_ as $dtclean_arr_gw => $dtclean_arr_gw_val)
     {
     
     	$gw_dtclean_cols[]=$dtclean_arr_gw;
        
     }
     
     $gw_dtclean_cols_str=implode(",", $gw_dtclean_cols);
     
     $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "insert",$gw_dtclean_cols_str);
     
     $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
     
     if($gwauthenticate_dtclean_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("dtclean", $dtclean_arr_);
     
     	//echo $gwauthenticate_dtclean_;

     }else{
     
     	echo $gwauthenticate_dtclean_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");

     }
     
    }
    
       function initialize_dtclean()
        {
        
         global $dtclean_uptoken;
             
         $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "select","");

         $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
         	
          //echo $gwauthenticate_dtclean_;

         if($gwauthenticate_dtclean_json["response"]=="ok")
         {
         
         	return get_dtclean("*", "WHERE primkey='$dtclean_uptoken'", "r");
         
            echo $gwauthenticate_dtclean_;

         }else{

         	echo $gwauthenticate_dtclean_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");
         
         }
        }   
    //End Add dtclean Data ===============
                
    //Start Update dtclean Data ===============
    
 	function update_dtclean($dtclean_arr_, $where_str)
    {
         $gw_dtclean_cols=array();
     
     foreach($dtclean_arr_ as $dtclean_arr_gw => $dtclean_arr_gw_val)
     {
     
     	$gw_dtclean_cols[]=$dtclean_arr_gw;
        
     }
     
     $gw_dtclean_cols_str=implode(",", $gw_dtclean_cols);
     
     $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "update",$gw_dtclean_cols_str);
     
     $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
     
     if($gwauthenticate_dtclean_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("dtclean", $dtclean_arr_, $where_str);

       // echo $gwauthenticate_dtclean_;
        
        exit;

     }else{

        echo $gwauthenticate_dtclean_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");


      }
    
    }
 	
    
    //End Update dtclean Data ===============

    //Start get  dtclean Data ===============
    
    function get_dtclean($colstr, $where_str, $type)
    {
          
     $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "select","");
     
     $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
     
     if($gwauthenticate_dtclean_json["response"]=="ok")
     {
    	return mosyflex_sel("dtclean", $colstr, $where_str, $type);

        //echo $gwauthenticate_dtclean_;

	  }else{
     
     	echo $gwauthenticate_dtclean_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");


     }    
    }
    //End get  dtclean Data ===============
    
    
    //======== qdtclean_data qsingle query function
    
    function qdtclean_data($qbuilding_no_key)
    {
          
     $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "qdata","");
     
     $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
     
     if($gwauthenticate_dtclean_json["response"]=="ok")
     {    
    	return get_dtclean("*", "WHERE building_no='$qbuilding_no_key'", "r");

		//echo $gwauthenticate_dtclean_;

      }else{
     
     	echo $gwauthenticate_dtclean_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");


     }  
    }
   
    //======== qdtclean_data qsingle query function
    
        
    //======== qdtclean_ddata qsingle query function    
    function qdtclean_ddata($building_no_col, $qbuilding_no_key)
    {
     
     $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "qddata","");
     
     $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
     
     if($gwauthenticate_dtclean_json["response"]=="ok")
     {    
    	return get_dtclean("*", "WHERE $building_no_col='$qbuilding_no_key'", "r");

		//echo $gwauthenticate_dtclean_;

     }else{
     
     	echo $gwauthenticate_dtclean_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");


     }   
    }
    //======== qdtclean_ddata qsingle query function

    //======== count dtclean data function
    
    function count_dtclean($dtclean_wherestr)
    {
     
     $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "count_data","");
     
     $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
     
     if($gwauthenticate_dtclean_json["response"]=="ok")
     {    
      $clean_dtclean_where_str="";
  
      if($dtclean_wherestr!='')
      {
        $clean_dtclean_where_str="Where ".$dtclean_wherestr;
      }

      return get_dtclean("count(*) as return_result", " ".$clean_dtclean_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_dtclean_;

      }else{
     
     	echo $gwauthenticate_dtclean_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");


     }    
    }
    //======== count dtclean data function

    //======== sum  dtclean data function
    
    function sum_dtclean($dtclean_sumcol, $dtclean_wherestr)
    {
     
     $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "sum_data","");
     
     $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
     
     if($gwauthenticate_dtclean_json["response"]=="ok")
     {    
      $clean_dtclean_where_str="";
  
      if($dtclean_wherestr!='')
      {
        $clean_dtclean_where_str="Where ".$dtclean_wherestr;
      }

      return get_dtclean("sum($dtclean_sumcol) as return_result", " ".$clean_dtclean_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_dtclean_;


      }else{
     
     	echo $gwauthenticate_dtclean_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");
        


     }    
    }
    
    //======== sum  dtclean data function   
    
    
    //Start drop  dtclean Data ===============
    
    function drop_dtclean($where_str)
    {
     
     $gwauthenticate_dtclean_=gw_oauth("table", magic_current_url(), "dtclean", "drop_data","");
     
     $gwauthenticate_dtclean_json=json_decode($gwauthenticate_dtclean_, true);
     
     if($gwauthenticate_dtclean_json["response"]=="ok")
     {    
    	return magic_sql_delete("dtclean", $where_str);

		//echo $gwauthenticate_dtclean_;

      }else{
     
     	echo $gwauthenticate_dtclean_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_dtclean_)."");
		

     }
    }
    //End drop  dtclean Data ===============    
    
    
   

    
 	//Start Add expenses Data ===============
 	function add_expenses($expenses_arr_)
    {
     $gw_expenses_cols=array();
     
     foreach($expenses_arr_ as $expenses_arr_gw => $expenses_arr_gw_val)
     {
     
     	$gw_expenses_cols[]=$expenses_arr_gw;
        
     }
     
     $gw_expenses_cols_str=implode(",", $gw_expenses_cols);
     
     $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "insert",$gw_expenses_cols_str);
     
     $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
     
     if($gwauthenticate_expenses_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("expenses", $expenses_arr_);
     
     	//echo $gwauthenticate_expenses_;

     }else{
     
     	echo $gwauthenticate_expenses_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");

     }
     
    }
    
       function initialize_expenses()
        {
        
         global $expenses_uptoken;
             
         $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "select","");

         $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
         	
          //echo $gwauthenticate_expenses_;

         if($gwauthenticate_expenses_json["response"]=="ok")
         {
         
         	return get_expenses("*", "WHERE primkey='$expenses_uptoken'", "r");
         
            echo $gwauthenticate_expenses_;

         }else{

         	echo $gwauthenticate_expenses_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");
         
         }
        }   
    //End Add expenses Data ===============
                
    //Start Update expenses Data ===============
    
 	function update_expenses($expenses_arr_, $where_str)
    {
         $gw_expenses_cols=array();
     
     foreach($expenses_arr_ as $expenses_arr_gw => $expenses_arr_gw_val)
     {
     
     	$gw_expenses_cols[]=$expenses_arr_gw;
        
     }
     
     $gw_expenses_cols_str=implode(",", $gw_expenses_cols);
     
     $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "update",$gw_expenses_cols_str);
     
     $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
     
     if($gwauthenticate_expenses_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("expenses", $expenses_arr_, $where_str);

       // echo $gwauthenticate_expenses_;
        
        exit;

     }else{

        echo $gwauthenticate_expenses_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");


      }
    
    }
 	
    
    //End Update expenses Data ===============

    //Start get  expenses Data ===============
    
    function get_expenses($colstr, $where_str, $type)
    {
          
     $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "select","");
     
     $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
     
     if($gwauthenticate_expenses_json["response"]=="ok")
     {
    	return mosyflex_sel("expenses", $colstr, $where_str, $type);

        //echo $gwauthenticate_expenses_;

	  }else{
     
     	echo $gwauthenticate_expenses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");


     }    
    }
    //End get  expenses Data ===============
    
    
    //======== qexpenses_data qsingle query function
    
    function qexpenses_data($qtransaction_id_key)
    {
          
     $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "qdata","");
     
     $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
     
     if($gwauthenticate_expenses_json["response"]=="ok")
     {    
    	return get_expenses("*", "WHERE transaction_id='$qtransaction_id_key'", "r");

		//echo $gwauthenticate_expenses_;

      }else{
     
     	echo $gwauthenticate_expenses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");


     }  
    }
   
    //======== qexpenses_data qsingle query function
    
        
    //======== qexpenses_ddata qsingle query function    
    function qexpenses_ddata($transaction_id_col, $qtransaction_id_key)
    {
     
     $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "qddata","");
     
     $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
     
     if($gwauthenticate_expenses_json["response"]=="ok")
     {    
    	return get_expenses("*", "WHERE $transaction_id_col='$qtransaction_id_key'", "r");

		//echo $gwauthenticate_expenses_;

     }else{
     
     	echo $gwauthenticate_expenses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");


     }   
    }
    //======== qexpenses_ddata qsingle query function

    //======== count expenses data function
    
    function count_expenses($expenses_wherestr)
    {
     
     $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "count_data","");
     
     $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
     
     if($gwauthenticate_expenses_json["response"]=="ok")
     {    
      $clean_expenses_where_str="";
  
      if($expenses_wherestr!='')
      {
        $clean_expenses_where_str="Where ".$expenses_wherestr;
      }

      return get_expenses("count(*) as return_result", " ".$clean_expenses_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_expenses_;

      }else{
     
     	echo $gwauthenticate_expenses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");


     }    
    }
    //======== count expenses data function

    //======== sum  expenses data function
    
    function sum_expenses($expenses_sumcol, $expenses_wherestr)
    {
     
     $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "sum_data","");
     
     $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
     
     if($gwauthenticate_expenses_json["response"]=="ok")
     {    
      $clean_expenses_where_str="";
  
      if($expenses_wherestr!='')
      {
        $clean_expenses_where_str="Where ".$expenses_wherestr;
      }

      return get_expenses("sum($expenses_sumcol) as return_result", " ".$clean_expenses_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_expenses_;


      }else{
     
     	echo $gwauthenticate_expenses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");
        


     }    
    }
    
    //======== sum  expenses data function   
    
    
    //Start drop  expenses Data ===============
    
    function drop_expenses($where_str)
    {
     
     $gwauthenticate_expenses_=gw_oauth("table", magic_current_url(), "expenses", "drop_data","");
     
     $gwauthenticate_expenses_json=json_decode($gwauthenticate_expenses_, true);
     
     if($gwauthenticate_expenses_json["response"]=="ok")
     {    
    	return magic_sql_delete("expenses", $where_str);

		//echo $gwauthenticate_expenses_;

      }else{
     
     	echo $gwauthenticate_expenses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_)."");
		

     }
    }
    //End drop  expenses Data ===============    
    
    
   

    
 	//Start Add files_and_photos Data ===============
 	function add_files_and_photos($files_and_photos_arr_)
    {
     $gw_files_and_photos_cols=array();
     
     foreach($files_and_photos_arr_ as $files_and_photos_arr_gw => $files_and_photos_arr_gw_val)
     {
     
     	$gw_files_and_photos_cols[]=$files_and_photos_arr_gw;
        
     }
     
     $gw_files_and_photos_cols_str=implode(",", $gw_files_and_photos_cols);
     
     $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "insert",$gw_files_and_photos_cols_str);
     
     $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
     
     if($gwauthenticate_files_and_photos_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("files_and_photos", $files_and_photos_arr_);
     
     	//echo $gwauthenticate_files_and_photos_;

     }else{
     
     	echo $gwauthenticate_files_and_photos_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");

     }
     
    }
    
       function initialize_files_and_photos()
        {
        
         global $files_and_photos_uptoken;
             
         $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "select","");

         $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
         	
          //echo $gwauthenticate_files_and_photos_;

         if($gwauthenticate_files_and_photos_json["response"]=="ok")
         {
         
         	return get_files_and_photos("*", "WHERE primkey='$files_and_photos_uptoken'", "r");
         
            echo $gwauthenticate_files_and_photos_;

         }else{

         	echo $gwauthenticate_files_and_photos_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");
         
         }
        }   
    //End Add files_and_photos Data ===============
                
    //Start Update files_and_photos Data ===============
    
 	function update_files_and_photos($files_and_photos_arr_, $where_str)
    {
         $gw_files_and_photos_cols=array();
     
     foreach($files_and_photos_arr_ as $files_and_photos_arr_gw => $files_and_photos_arr_gw_val)
     {
     
     	$gw_files_and_photos_cols[]=$files_and_photos_arr_gw;
        
     }
     
     $gw_files_and_photos_cols_str=implode(",", $gw_files_and_photos_cols);
     
     $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "update",$gw_files_and_photos_cols_str);
     
     $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
     
     if($gwauthenticate_files_and_photos_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("files_and_photos", $files_and_photos_arr_, $where_str);

       // echo $gwauthenticate_files_and_photos_;
        
        exit;

     }else{

        echo $gwauthenticate_files_and_photos_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");


      }
    
    }
 	
    
    //End Update files_and_photos Data ===============

    //Start get  files_and_photos Data ===============
    
    function get_files_and_photos($colstr, $where_str, $type)
    {
          
     $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "select","");
     
     $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
     
     if($gwauthenticate_files_and_photos_json["response"]=="ok")
     {
    	return mosyflex_sel("files_and_photos", $colstr, $where_str, $type);

        //echo $gwauthenticate_files_and_photos_;

	  }else{
     
     	echo $gwauthenticate_files_and_photos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");


     }    
    }
    //End get  files_and_photos Data ===============
    
    
    //======== qfiles_and_photos_data qsingle query function
    
    function qfiles_and_photos_data($qfile_id_key)
    {
          
     $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "qdata","");
     
     $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
     
     if($gwauthenticate_files_and_photos_json["response"]=="ok")
     {    
    	return get_files_and_photos("*", "WHERE file_id='$qfile_id_key'", "r");

		//echo $gwauthenticate_files_and_photos_;

      }else{
     
     	echo $gwauthenticate_files_and_photos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");


     }  
    }
   
    //======== qfiles_and_photos_data qsingle query function
    
        
    //======== qfiles_and_photos_ddata qsingle query function    
    function qfiles_and_photos_ddata($file_id_col, $qfile_id_key)
    {
     
     $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "qddata","");
     
     $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
     
     if($gwauthenticate_files_and_photos_json["response"]=="ok")
     {    
    	return get_files_and_photos("*", "WHERE $file_id_col='$qfile_id_key'", "r");

		//echo $gwauthenticate_files_and_photos_;

     }else{
     
     	echo $gwauthenticate_files_and_photos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");


     }   
    }
    //======== qfiles_and_photos_ddata qsingle query function

    //======== count files_and_photos data function
    
    function count_files_and_photos($files_and_photos_wherestr)
    {
     
     $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "count_data","");
     
     $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
     
     if($gwauthenticate_files_and_photos_json["response"]=="ok")
     {    
      $clean_files_and_photos_where_str="";
  
      if($files_and_photos_wherestr!='')
      {
        $clean_files_and_photos_where_str="Where ".$files_and_photos_wherestr;
      }

      return get_files_and_photos("count(*) as return_result", " ".$clean_files_and_photos_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_files_and_photos_;

      }else{
     
     	echo $gwauthenticate_files_and_photos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");


     }    
    }
    //======== count files_and_photos data function

    //======== sum  files_and_photos data function
    
    function sum_files_and_photos($files_and_photos_sumcol, $files_and_photos_wherestr)
    {
     
     $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "sum_data","");
     
     $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
     
     if($gwauthenticate_files_and_photos_json["response"]=="ok")
     {    
      $clean_files_and_photos_where_str="";
  
      if($files_and_photos_wherestr!='')
      {
        $clean_files_and_photos_where_str="Where ".$files_and_photos_wherestr;
      }

      return get_files_and_photos("sum($files_and_photos_sumcol) as return_result", " ".$clean_files_and_photos_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_files_and_photos_;


      }else{
     
     	echo $gwauthenticate_files_and_photos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");
        


     }    
    }
    
    //======== sum  files_and_photos data function   
    
    
    //Start drop  files_and_photos Data ===============
    
    function drop_files_and_photos($where_str)
    {
     
     $gwauthenticate_files_and_photos_=gw_oauth("table", magic_current_url(), "files_and_photos", "drop_data","");
     
     $gwauthenticate_files_and_photos_json=json_decode($gwauthenticate_files_and_photos_, true);
     
     if($gwauthenticate_files_and_photos_json["response"]=="ok")
     {    
    	return magic_sql_delete("files_and_photos", $where_str);

		//echo $gwauthenticate_files_and_photos_;

      }else{
     
     	echo $gwauthenticate_files_and_photos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_files_and_photos_)."");
		

     }
    }
    //End drop  files_and_photos Data ===============    
    
    
   

    
 	//Start Add inventory Data ===============
 	function add_inventory($inventory_arr_)
    {
     $gw_inventory_cols=array();
     
     foreach($inventory_arr_ as $inventory_arr_gw => $inventory_arr_gw_val)
     {
     
     	$gw_inventory_cols[]=$inventory_arr_gw;
        
     }
     
     $gw_inventory_cols_str=implode(",", $gw_inventory_cols);
     
     $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "insert",$gw_inventory_cols_str);
     
     $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
     
     if($gwauthenticate_inventory_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("inventory", $inventory_arr_);
     
     	//echo $gwauthenticate_inventory_;

     }else{
     
     	echo $gwauthenticate_inventory_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");

     }
     
    }
    
       function initialize_inventory()
        {
        
         global $inventory_uptoken;
             
         $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "select","");

         $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
         	
          //echo $gwauthenticate_inventory_;

         if($gwauthenticate_inventory_json["response"]=="ok")
         {
         
         	return get_inventory("*", "WHERE primkey='$inventory_uptoken'", "r");
         
            echo $gwauthenticate_inventory_;

         }else{

         	echo $gwauthenticate_inventory_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");
         
         }
        }   
    //End Add inventory Data ===============
                
    //Start Update inventory Data ===============
    
 	function update_inventory($inventory_arr_, $where_str)
    {
         $gw_inventory_cols=array();
     
     foreach($inventory_arr_ as $inventory_arr_gw => $inventory_arr_gw_val)
     {
     
     	$gw_inventory_cols[]=$inventory_arr_gw;
        
     }
     
     $gw_inventory_cols_str=implode(",", $gw_inventory_cols);
     
     $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "update",$gw_inventory_cols_str);
     
     $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
     
     if($gwauthenticate_inventory_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("inventory", $inventory_arr_, $where_str);

       // echo $gwauthenticate_inventory_;
        
        exit;

     }else{

        echo $gwauthenticate_inventory_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");


      }
    
    }
 	
    
    //End Update inventory Data ===============

    //Start get  inventory Data ===============
    
    function get_inventory($colstr, $where_str, $type)
    {
          
     $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "select","");
     
     $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
     
     if($gwauthenticate_inventory_json["response"]=="ok")
     {
    	return mosyflex_sel("inventory", $colstr, $where_str, $type);

        //echo $gwauthenticate_inventory_;

	  }else{
     
     	echo $gwauthenticate_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");


     }    
    }
    //End get  inventory Data ===============
    
    
    //======== qinventory_data qsingle query function
    
    function qinventory_data($qitem_id_key)
    {
          
     $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "qdata","");
     
     $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
     
     if($gwauthenticate_inventory_json["response"]=="ok")
     {    
    	return get_inventory("*", "WHERE item_id='$qitem_id_key'", "r");

		//echo $gwauthenticate_inventory_;

      }else{
     
     	echo $gwauthenticate_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");


     }  
    }
   
    //======== qinventory_data qsingle query function
    
        
    //======== qinventory_ddata qsingle query function    
    function qinventory_ddata($item_id_col, $qitem_id_key)
    {
     
     $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "qddata","");
     
     $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
     
     if($gwauthenticate_inventory_json["response"]=="ok")
     {    
    	return get_inventory("*", "WHERE $item_id_col='$qitem_id_key'", "r");

		//echo $gwauthenticate_inventory_;

     }else{
     
     	echo $gwauthenticate_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");


     }   
    }
    //======== qinventory_ddata qsingle query function

    //======== count inventory data function
    
    function count_inventory($inventory_wherestr)
    {
     
     $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "count_data","");
     
     $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
     
     if($gwauthenticate_inventory_json["response"]=="ok")
     {    
      $clean_inventory_where_str="";
  
      if($inventory_wherestr!='')
      {
        $clean_inventory_where_str="Where ".$inventory_wherestr;
      }

      return get_inventory("count(*) as return_result", " ".$clean_inventory_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_inventory_;

      }else{
     
     	echo $gwauthenticate_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");


     }    
    }
    //======== count inventory data function

    //======== sum  inventory data function
    
    function sum_inventory($inventory_sumcol, $inventory_wherestr)
    {
     
     $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "sum_data","");
     
     $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
     
     if($gwauthenticate_inventory_json["response"]=="ok")
     {    
      $clean_inventory_where_str="";
  
      if($inventory_wherestr!='')
      {
        $clean_inventory_where_str="Where ".$inventory_wherestr;
      }

      return get_inventory("sum($inventory_sumcol) as return_result", " ".$clean_inventory_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_inventory_;


      }else{
     
     	echo $gwauthenticate_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");
        


     }    
    }
    
    //======== sum  inventory data function   
    
    
    //Start drop  inventory Data ===============
    
    function drop_inventory($where_str)
    {
     
     $gwauthenticate_inventory_=gw_oauth("table", magic_current_url(), "inventory", "drop_data","");
     
     $gwauthenticate_inventory_json=json_decode($gwauthenticate_inventory_, true);
     
     if($gwauthenticate_inventory_json["response"]=="ok")
     {    
    	return magic_sql_delete("inventory", $where_str);

		//echo $gwauthenticate_inventory_;

      }else{
     
     	echo $gwauthenticate_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_inventory_)."");
		

     }
    }
    //End drop  inventory Data ===============    
    
    
   

    
 	//Start Add message_board Data ===============
 	function add_message_board($message_board_arr_)
    {
     $gw_message_board_cols=array();
     
     foreach($message_board_arr_ as $message_board_arr_gw => $message_board_arr_gw_val)
     {
     
     	$gw_message_board_cols[]=$message_board_arr_gw;
        
     }
     
     $gw_message_board_cols_str=implode(",", $gw_message_board_cols);
     
     $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "insert",$gw_message_board_cols_str);
     
     $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
     
     if($gwauthenticate_message_board_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("message_board", $message_board_arr_);
     
     	//echo $gwauthenticate_message_board_;

     }else{
     
     	echo $gwauthenticate_message_board_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");

     }
     
    }
    
       function initialize_message_board()
        {
        
         global $message_board_uptoken;
             
         $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "select","");

         $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
         	
          //echo $gwauthenticate_message_board_;

         if($gwauthenticate_message_board_json["response"]=="ok")
         {
         
         	return get_message_board("*", "WHERE primkey='$message_board_uptoken'", "r");
         
            echo $gwauthenticate_message_board_;

         }else{

         	echo $gwauthenticate_message_board_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");
         
         }
        }   
    //End Add message_board Data ===============
                
    //Start Update message_board Data ===============
    
 	function update_message_board($message_board_arr_, $where_str)
    {
         $gw_message_board_cols=array();
     
     foreach($message_board_arr_ as $message_board_arr_gw => $message_board_arr_gw_val)
     {
     
     	$gw_message_board_cols[]=$message_board_arr_gw;
        
     }
     
     $gw_message_board_cols_str=implode(",", $gw_message_board_cols);
     
     $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "update",$gw_message_board_cols_str);
     
     $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
     
     if($gwauthenticate_message_board_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("message_board", $message_board_arr_, $where_str);

       // echo $gwauthenticate_message_board_;
        
        exit;

     }else{

        echo $gwauthenticate_message_board_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");


      }
    
    }
 	
    
    //End Update message_board Data ===============

    //Start get  message_board Data ===============
    
    function get_message_board($colstr, $where_str, $type)
    {
          
     $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "select","");
     
     $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
     
     if($gwauthenticate_message_board_json["response"]=="ok")
     {
    	return mosyflex_sel("message_board", $colstr, $where_str, $type);

        //echo $gwauthenticate_message_board_;

	  }else{
     
     	echo $gwauthenticate_message_board_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");


     }    
    }
    //End get  message_board Data ===============
    
    
    //======== qmessage_board_data qsingle query function
    
    function qmessage_board_data($qmessage_id_key)
    {
          
     $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "qdata","");
     
     $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
     
     if($gwauthenticate_message_board_json["response"]=="ok")
     {    
    	return get_message_board("*", "WHERE message_id='$qmessage_id_key'", "r");

		//echo $gwauthenticate_message_board_;

      }else{
     
     	echo $gwauthenticate_message_board_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");


     }  
    }
   
    //======== qmessage_board_data qsingle query function
    
        
    //======== qmessage_board_ddata qsingle query function    
    function qmessage_board_ddata($message_id_col, $qmessage_id_key)
    {
     
     $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "qddata","");
     
     $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
     
     if($gwauthenticate_message_board_json["response"]=="ok")
     {    
    	return get_message_board("*", "WHERE $message_id_col='$qmessage_id_key'", "r");

		//echo $gwauthenticate_message_board_;

     }else{
     
     	echo $gwauthenticate_message_board_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");


     }   
    }
    //======== qmessage_board_ddata qsingle query function

    //======== count message_board data function
    
    function count_message_board($message_board_wherestr)
    {
     
     $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "count_data","");
     
     $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
     
     if($gwauthenticate_message_board_json["response"]=="ok")
     {    
      $clean_message_board_where_str="";
  
      if($message_board_wherestr!='')
      {
        $clean_message_board_where_str="Where ".$message_board_wherestr;
      }

      return get_message_board("count(*) as return_result", " ".$clean_message_board_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_message_board_;

      }else{
     
     	echo $gwauthenticate_message_board_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");


     }    
    }
    //======== count message_board data function

    //======== sum  message_board data function
    
    function sum_message_board($message_board_sumcol, $message_board_wherestr)
    {
     
     $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "sum_data","");
     
     $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
     
     if($gwauthenticate_message_board_json["response"]=="ok")
     {    
      $clean_message_board_where_str="";
  
      if($message_board_wherestr!='')
      {
        $clean_message_board_where_str="Where ".$message_board_wherestr;
      }

      return get_message_board("sum($message_board_sumcol) as return_result", " ".$clean_message_board_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_message_board_;


      }else{
     
     	echo $gwauthenticate_message_board_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");
        


     }    
    }
    
    //======== sum  message_board data function   
    
    
    //Start drop  message_board Data ===============
    
    function drop_message_board($where_str)
    {
     
     $gwauthenticate_message_board_=gw_oauth("table", magic_current_url(), "message_board", "drop_data","");
     
     $gwauthenticate_message_board_json=json_decode($gwauthenticate_message_board_, true);
     
     if($gwauthenticate_message_board_json["response"]=="ok")
     {    
    	return magic_sql_delete("message_board", $where_str);

		//echo $gwauthenticate_message_board_;

      }else{
     
     	echo $gwauthenticate_message_board_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_message_board_)."");
		

     }
    }
    //End drop  message_board Data ===============    
    
    
   

    
 	//Start Add notes Data ===============
 	function add_notes($notes_arr_)
    {
     $gw_notes_cols=array();
     
     foreach($notes_arr_ as $notes_arr_gw => $notes_arr_gw_val)
     {
     
     	$gw_notes_cols[]=$notes_arr_gw;
        
     }
     
     $gw_notes_cols_str=implode(",", $gw_notes_cols);
     
     $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "insert",$gw_notes_cols_str);
     
     $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
     
     if($gwauthenticate_notes_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("notes", $notes_arr_);
     
     	//echo $gwauthenticate_notes_;

     }else{
     
     	echo $gwauthenticate_notes_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");

     }
     
    }
    
       function initialize_notes()
        {
        
         global $notes_uptoken;
             
         $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "select","");

         $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
         	
          //echo $gwauthenticate_notes_;

         if($gwauthenticate_notes_json["response"]=="ok")
         {
         
         	return get_notes("*", "WHERE primkey='$notes_uptoken'", "r");
         
            echo $gwauthenticate_notes_;

         }else{

         	echo $gwauthenticate_notes_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");
         
         }
        }   
    //End Add notes Data ===============
                
    //Start Update notes Data ===============
    
 	function update_notes($notes_arr_, $where_str)
    {
         $gw_notes_cols=array();
     
     foreach($notes_arr_ as $notes_arr_gw => $notes_arr_gw_val)
     {
     
     	$gw_notes_cols[]=$notes_arr_gw;
        
     }
     
     $gw_notes_cols_str=implode(",", $gw_notes_cols);
     
     $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "update",$gw_notes_cols_str);
     
     $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
     
     if($gwauthenticate_notes_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("notes", $notes_arr_, $where_str);

       // echo $gwauthenticate_notes_;
        
        exit;

     }else{

        echo $gwauthenticate_notes_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");


      }
    
    }
 	
    
    //End Update notes Data ===============

    //Start get  notes Data ===============
    
    function get_notes($colstr, $where_str, $type)
    {
          
     $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "select","");
     
     $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
     
     if($gwauthenticate_notes_json["response"]=="ok")
     {
    	return mosyflex_sel("notes", $colstr, $where_str, $type);

        //echo $gwauthenticate_notes_;

	  }else{
     
     	echo $gwauthenticate_notes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");


     }    
    }
    //End get  notes Data ===============
    
    
    //======== qnotes_data qsingle query function
    
    function qnotes_data($qnote_id_key)
    {
          
     $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "qdata","");
     
     $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
     
     if($gwauthenticate_notes_json["response"]=="ok")
     {    
    	return get_notes("*", "WHERE note_id='$qnote_id_key'", "r");

		//echo $gwauthenticate_notes_;

      }else{
     
     	echo $gwauthenticate_notes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");


     }  
    }
   
    //======== qnotes_data qsingle query function
    
        
    //======== qnotes_ddata qsingle query function    
    function qnotes_ddata($note_id_col, $qnote_id_key)
    {
     
     $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "qddata","");
     
     $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
     
     if($gwauthenticate_notes_json["response"]=="ok")
     {    
    	return get_notes("*", "WHERE $note_id_col='$qnote_id_key'", "r");

		//echo $gwauthenticate_notes_;

     }else{
     
     	echo $gwauthenticate_notes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");


     }   
    }
    //======== qnotes_ddata qsingle query function

    //======== count notes data function
    
    function count_notes($notes_wherestr)
    {
     
     $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "count_data","");
     
     $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
     
     if($gwauthenticate_notes_json["response"]=="ok")
     {    
      $clean_notes_where_str="";
  
      if($notes_wherestr!='')
      {
        $clean_notes_where_str="Where ".$notes_wherestr;
      }

      return get_notes("count(*) as return_result", " ".$clean_notes_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_notes_;

      }else{
     
     	echo $gwauthenticate_notes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");


     }    
    }
    //======== count notes data function

    //======== sum  notes data function
    
    function sum_notes($notes_sumcol, $notes_wherestr)
    {
     
     $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "sum_data","");
     
     $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
     
     if($gwauthenticate_notes_json["response"]=="ok")
     {    
      $clean_notes_where_str="";
  
      if($notes_wherestr!='')
      {
        $clean_notes_where_str="Where ".$notes_wherestr;
      }

      return get_notes("sum($notes_sumcol) as return_result", " ".$clean_notes_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_notes_;


      }else{
     
     	echo $gwauthenticate_notes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");
        


     }    
    }
    
    //======== sum  notes data function   
    
    
    //Start drop  notes Data ===============
    
    function drop_notes($where_str)
    {
     
     $gwauthenticate_notes_=gw_oauth("table", magic_current_url(), "notes", "drop_data","");
     
     $gwauthenticate_notes_json=json_decode($gwauthenticate_notes_, true);
     
     if($gwauthenticate_notes_json["response"]=="ok")
     {    
    	return magic_sql_delete("notes", $where_str);

		//echo $gwauthenticate_notes_;

      }else{
     
     	echo $gwauthenticate_notes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_)."");
		

     }
    }
    //End drop  notes Data ===============    
    
    
   

    
 	//Start Add packages Data ===============
 	function add_packages($packages_arr_)
    {
     $gw_packages_cols=array();
     
     foreach($packages_arr_ as $packages_arr_gw => $packages_arr_gw_val)
     {
     
     	$gw_packages_cols[]=$packages_arr_gw;
        
     }
     
     $gw_packages_cols_str=implode(",", $gw_packages_cols);
     
     $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "insert",$gw_packages_cols_str);
     
     $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
     
     if($gwauthenticate_packages_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("packages", $packages_arr_);
     
     	//echo $gwauthenticate_packages_;

     }else{
     
     	echo $gwauthenticate_packages_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");

     }
     
    }
    
       function initialize_packages()
        {
        
         global $packages_uptoken;
             
         $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "select","");

         $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
         	
          //echo $gwauthenticate_packages_;

         if($gwauthenticate_packages_json["response"]=="ok")
         {
         
         	return get_packages("*", "WHERE primkey='$packages_uptoken'", "r");
         
            echo $gwauthenticate_packages_;

         }else{

         	echo $gwauthenticate_packages_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");
         
         }
        }   
    //End Add packages Data ===============
                
    //Start Update packages Data ===============
    
 	function update_packages($packages_arr_, $where_str)
    {
         $gw_packages_cols=array();
     
     foreach($packages_arr_ as $packages_arr_gw => $packages_arr_gw_val)
     {
     
     	$gw_packages_cols[]=$packages_arr_gw;
        
     }
     
     $gw_packages_cols_str=implode(",", $gw_packages_cols);
     
     $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "update",$gw_packages_cols_str);
     
     $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
     
     if($gwauthenticate_packages_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("packages", $packages_arr_, $where_str);

       // echo $gwauthenticate_packages_;
        
        exit;

     }else{

        echo $gwauthenticate_packages_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");


      }
    
    }
 	
    
    //End Update packages Data ===============

    //Start get  packages Data ===============
    
    function get_packages($colstr, $where_str, $type)
    {
          
     $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "select","");
     
     $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
     
     if($gwauthenticate_packages_json["response"]=="ok")
     {
    	return mosyflex_sel("packages", $colstr, $where_str, $type);

        //echo $gwauthenticate_packages_;

	  }else{
     
     	echo $gwauthenticate_packages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");


     }    
    }
    //End get  packages Data ===============
    
    
    //======== qpackages_data qsingle query function
    
    function qpackages_data($qpackage_id_key)
    {
          
     $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "qdata","");
     
     $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
     
     if($gwauthenticate_packages_json["response"]=="ok")
     {    
    	return get_packages("*", "WHERE package_id='$qpackage_id_key'", "r");

		//echo $gwauthenticate_packages_;

      }else{
     
     	echo $gwauthenticate_packages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");


     }  
    }
   
    //======== qpackages_data qsingle query function
    
        
    //======== qpackages_ddata qsingle query function    
    function qpackages_ddata($package_id_col, $qpackage_id_key)
    {
     
     $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "qddata","");
     
     $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
     
     if($gwauthenticate_packages_json["response"]=="ok")
     {    
    	return get_packages("*", "WHERE $package_id_col='$qpackage_id_key'", "r");

		//echo $gwauthenticate_packages_;

     }else{
     
     	echo $gwauthenticate_packages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");


     }   
    }
    //======== qpackages_ddata qsingle query function

    //======== count packages data function
    
    function count_packages($packages_wherestr)
    {
     
     $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "count_data","");
     
     $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
     
     if($gwauthenticate_packages_json["response"]=="ok")
     {    
      $clean_packages_where_str="";
  
      if($packages_wherestr!='')
      {
        $clean_packages_where_str="Where ".$packages_wherestr;
      }

      return get_packages("count(*) as return_result", " ".$clean_packages_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_packages_;

      }else{
     
     	echo $gwauthenticate_packages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");


     }    
    }
    //======== count packages data function

    //======== sum  packages data function
    
    function sum_packages($packages_sumcol, $packages_wherestr)
    {
     
     $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "sum_data","");
     
     $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
     
     if($gwauthenticate_packages_json["response"]=="ok")
     {    
      $clean_packages_where_str="";
  
      if($packages_wherestr!='')
      {
        $clean_packages_where_str="Where ".$packages_wherestr;
      }

      return get_packages("sum($packages_sumcol) as return_result", " ".$clean_packages_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_packages_;


      }else{
     
     	echo $gwauthenticate_packages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");
        


     }    
    }
    
    //======== sum  packages data function   
    
    
    //Start drop  packages Data ===============
    
    function drop_packages($where_str)
    {
     
     $gwauthenticate_packages_=gw_oauth("table", magic_current_url(), "packages", "drop_data","");
     
     $gwauthenticate_packages_json=json_decode($gwauthenticate_packages_, true);
     
     if($gwauthenticate_packages_json["response"]=="ok")
     {    
    	return magic_sql_delete("packages", $where_str);

		//echo $gwauthenticate_packages_;

      }else{
     
     	echo $gwauthenticate_packages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_packages_)."");
		

     }
    }
    //End drop  packages Data ===============    
    
    
   

    
 	//Start Add sqlpro_themes Data ===============
 	function add_sqlpro_themes($sqlpro_themes_arr_)
    {
     $gw_sqlpro_themes_cols=array();
     
     foreach($sqlpro_themes_arr_ as $sqlpro_themes_arr_gw => $sqlpro_themes_arr_gw_val)
     {
     
     	$gw_sqlpro_themes_cols[]=$sqlpro_themes_arr_gw;
        
     }
     
     $gw_sqlpro_themes_cols_str=implode(",", $gw_sqlpro_themes_cols);
     
     $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "insert",$gw_sqlpro_themes_cols_str);
     
     $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
     
     if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("sqlpro_themes", $sqlpro_themes_arr_);
     
     	//echo $gwauthenticate_sqlpro_themes_;

     }else{
     
     	echo $gwauthenticate_sqlpro_themes_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");

     }
     
    }
    
       function initialize_sqlpro_themes()
        {
        
         global $sqlpro_themes_uptoken;
             
         $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "select","");

         $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
         	
          //echo $gwauthenticate_sqlpro_themes_;

         if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
         {
         
         	return get_sqlpro_themes("*", "WHERE webtemp_key='$sqlpro_themes_uptoken'", "r");
         
            echo $gwauthenticate_sqlpro_themes_;

         }else{

         	echo $gwauthenticate_sqlpro_themes_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");
         
         }
        }   
    //End Add sqlpro_themes Data ===============
                
    //Start Update sqlpro_themes Data ===============
    
 	function update_sqlpro_themes($sqlpro_themes_arr_, $where_str)
    {
         $gw_sqlpro_themes_cols=array();
     
     foreach($sqlpro_themes_arr_ as $sqlpro_themes_arr_gw => $sqlpro_themes_arr_gw_val)
     {
     
     	$gw_sqlpro_themes_cols[]=$sqlpro_themes_arr_gw;
        
     }
     
     $gw_sqlpro_themes_cols_str=implode(",", $gw_sqlpro_themes_cols);
     
     $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "update",$gw_sqlpro_themes_cols_str);
     
     $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
     
     if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("sqlpro_themes", $sqlpro_themes_arr_, $where_str);

       // echo $gwauthenticate_sqlpro_themes_;
        
        exit;

     }else{

        echo $gwauthenticate_sqlpro_themes_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");


      }
    
    }
 	
    
    //End Update sqlpro_themes Data ===============

    //Start get  sqlpro_themes Data ===============
    
    function get_sqlpro_themes($colstr, $where_str, $type)
    {
          
     $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "select","");
     
     $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
     
     if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
     {
    	return mosyflex_sel("sqlpro_themes", $colstr, $where_str, $type);

        //echo $gwauthenticate_sqlpro_themes_;

	  }else{
     
     	echo $gwauthenticate_sqlpro_themes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");


     }    
    }
    //End get  sqlpro_themes Data ===============
    
    
    //======== qsqlpro_themes_data qsingle query function
    
    function qsqlpro_themes_data($qwebtemp_name_key)
    {
          
     $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "qdata","");
     
     $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
     
     if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
     {    
    	return get_sqlpro_themes("*", "WHERE webtemp_name='$qwebtemp_name_key'", "r");

		//echo $gwauthenticate_sqlpro_themes_;

      }else{
     
     	echo $gwauthenticate_sqlpro_themes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");


     }  
    }
   
    //======== qsqlpro_themes_data qsingle query function
    
        
    //======== qsqlpro_themes_ddata qsingle query function    
    function qsqlpro_themes_ddata($webtemp_name_col, $qwebtemp_name_key)
    {
     
     $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "qddata","");
     
     $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
     
     if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
     {    
    	return get_sqlpro_themes("*", "WHERE $webtemp_name_col='$qwebtemp_name_key'", "r");

		//echo $gwauthenticate_sqlpro_themes_;

     }else{
     
     	echo $gwauthenticate_sqlpro_themes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");


     }   
    }
    //======== qsqlpro_themes_ddata qsingle query function

    //======== count sqlpro_themes data function
    
    function count_sqlpro_themes($sqlpro_themes_wherestr)
    {
     
     $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "count_data","");
     
     $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
     
     if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
     {    
      $clean_sqlpro_themes_where_str="";
  
      if($sqlpro_themes_wherestr!='')
      {
        $clean_sqlpro_themes_where_str="Where ".$sqlpro_themes_wherestr;
      }

      return get_sqlpro_themes("count(*) as return_result", " ".$clean_sqlpro_themes_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_sqlpro_themes_;

      }else{
     
     	echo $gwauthenticate_sqlpro_themes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");


     }    
    }
    //======== count sqlpro_themes data function

    //======== sum  sqlpro_themes data function
    
    function sum_sqlpro_themes($sqlpro_themes_sumcol, $sqlpro_themes_wherestr)
    {
     
     $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "sum_data","");
     
     $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
     
     if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
     {    
      $clean_sqlpro_themes_where_str="";
  
      if($sqlpro_themes_wherestr!='')
      {
        $clean_sqlpro_themes_where_str="Where ".$sqlpro_themes_wherestr;
      }

      return get_sqlpro_themes("sum($sqlpro_themes_sumcol) as return_result", " ".$clean_sqlpro_themes_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_sqlpro_themes_;


      }else{
     
     	echo $gwauthenticate_sqlpro_themes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");
        


     }    
    }
    
    //======== sum  sqlpro_themes data function   
    
    
    //Start drop  sqlpro_themes Data ===============
    
    function drop_sqlpro_themes($where_str)
    {
     
     $gwauthenticate_sqlpro_themes_=gw_oauth("table", magic_current_url(), "sqlpro_themes", "drop_data","");
     
     $gwauthenticate_sqlpro_themes_json=json_decode($gwauthenticate_sqlpro_themes_, true);
     
     if($gwauthenticate_sqlpro_themes_json["response"]=="ok")
     {    
    	return magic_sql_delete("sqlpro_themes", $where_str);

		//echo $gwauthenticate_sqlpro_themes_;

      }else{
     
     	echo $gwauthenticate_sqlpro_themes_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_sqlpro_themes_)."");
		

     }
    }
    //End drop  sqlpro_themes Data ===============    
    
    
   

    
 	//Start Add stock_history Data ===============
 	function add_stock_history($stock_history_arr_)
    {
     $gw_stock_history_cols=array();
     
     foreach($stock_history_arr_ as $stock_history_arr_gw => $stock_history_arr_gw_val)
     {
     
     	$gw_stock_history_cols[]=$stock_history_arr_gw;
        
     }
     
     $gw_stock_history_cols_str=implode(",", $gw_stock_history_cols);
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "insert",$gw_stock_history_cols_str);
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("stock_history", $stock_history_arr_);
     
     	//echo $gwauthenticate_stock_history_;

     }else{
     
     	echo $gwauthenticate_stock_history_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");

     }
     
    }
    
       function initialize_stock_history()
        {
        
         global $stock_history_uptoken;
             
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "select","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
         
         	return get_stock_history("*", "WHERE primkey='$stock_history_uptoken'", "r");
         
            echo $gwauthenticate_stock_history_;

         }else{

         	echo $gwauthenticate_stock_history_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
         
         }
        }   
    //End Add stock_history Data ===============
                
    //Start Update stock_history Data ===============
    
 	function update_stock_history($stock_history_arr_, $where_str)
    {
         $gw_stock_history_cols=array();
     
     foreach($stock_history_arr_ as $stock_history_arr_gw => $stock_history_arr_gw_val)
     {
     
     	$gw_stock_history_cols[]=$stock_history_arr_gw;
        
     }
     
     $gw_stock_history_cols_str=implode(",", $gw_stock_history_cols);
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "update",$gw_stock_history_cols_str);
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("stock_history", $stock_history_arr_, $where_str);

       // echo $gwauthenticate_stock_history_;
        
        exit;

     }else{

        echo $gwauthenticate_stock_history_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


      }
    
    }
 	
    
    //End Update stock_history Data ===============

    //Start get  stock_history Data ===============
    
    function get_stock_history($colstr, $where_str, $type)
    {
          
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "select","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {
    	return mosyflex_sel("stock_history", $colstr, $where_str, $type);

        //echo $gwauthenticate_stock_history_;

	  }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }    
    }
    //End get  stock_history Data ===============
    
    
    //======== qstock_history_data qsingle query function
    
    function qstock_history_data($qstocked_key)
    {
          
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "qdata","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
    	return get_stock_history("*", "WHERE stocked='$qstocked_key'", "r");

		//echo $gwauthenticate_stock_history_;

      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }  
    }
   
    //======== qstock_history_data qsingle query function
    
        
    //======== qstock_history_ddata qsingle query function    
    function qstock_history_ddata($stocked_col, $qstocked_key)
    {
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "qddata","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
    	return get_stock_history("*", "WHERE $stocked_col='$qstocked_key'", "r");

		//echo $gwauthenticate_stock_history_;

     }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }   
    }
    //======== qstock_history_ddata qsingle query function

    //======== count stock_history data function
    
    function count_stock_history($stock_history_wherestr)
    {
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "count_data","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
      $clean_stock_history_where_str="";
  
      if($stock_history_wherestr!='')
      {
        $clean_stock_history_where_str="Where ".$stock_history_wherestr;
      }

      return get_stock_history("count(*) as return_result", " ".$clean_stock_history_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_stock_history_;

      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }    
    }
    //======== count stock_history data function

    //======== sum  stock_history data function
    
    function sum_stock_history($stock_history_sumcol, $stock_history_wherestr)
    {
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "sum_data","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
      $clean_stock_history_where_str="";
  
      if($stock_history_wherestr!='')
      {
        $clean_stock_history_where_str="Where ".$stock_history_wherestr;
      }

      return get_stock_history("sum($stock_history_sumcol) as return_result", " ".$clean_stock_history_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_stock_history_;


      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
        


     }    
    }
    
    //======== sum  stock_history data function   
    
    
    //Start drop  stock_history Data ===============
    
    function drop_stock_history($where_str)
    {
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "drop_data","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
    	return magic_sql_delete("stock_history", $where_str);

		//echo $gwauthenticate_stock_history_;

      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
		

     }
    }
    //End drop  stock_history Data ===============    
    
    
   

    
 	//Start Add suppliers Data ===============
 	function add_suppliers($suppliers_arr_)
    {
     $gw_suppliers_cols=array();
     
     foreach($suppliers_arr_ as $suppliers_arr_gw => $suppliers_arr_gw_val)
     {
     
     	$gw_suppliers_cols[]=$suppliers_arr_gw;
        
     }
     
     $gw_suppliers_cols_str=implode(",", $gw_suppliers_cols);
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "insert",$gw_suppliers_cols_str);
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("suppliers", $suppliers_arr_);
     
     	//echo $gwauthenticate_suppliers_;

     }else{
     
     	echo $gwauthenticate_suppliers_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");

     }
     
    }
    
       function initialize_suppliers()
        {
        
         global $suppliers_uptoken;
             
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "select","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
         
         	return get_suppliers("*", "WHERE primkey='$suppliers_uptoken'", "r");
         
            echo $gwauthenticate_suppliers_;

         }else{

         	echo $gwauthenticate_suppliers_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
         
         }
        }   
    //End Add suppliers Data ===============
                
    //Start Update suppliers Data ===============
    
 	function update_suppliers($suppliers_arr_, $where_str)
    {
         $gw_suppliers_cols=array();
     
     foreach($suppliers_arr_ as $suppliers_arr_gw => $suppliers_arr_gw_val)
     {
     
     	$gw_suppliers_cols[]=$suppliers_arr_gw;
        
     }
     
     $gw_suppliers_cols_str=implode(",", $gw_suppliers_cols);
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "update",$gw_suppliers_cols_str);
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("suppliers", $suppliers_arr_, $where_str);

       // echo $gwauthenticate_suppliers_;
        
        exit;

     }else{

        echo $gwauthenticate_suppliers_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


      }
    
    }
 	
    
    //End Update suppliers Data ===============

    //Start get  suppliers Data ===============
    
    function get_suppliers($colstr, $where_str, $type)
    {
          
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "select","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {
    	return mosyflex_sel("suppliers", $colstr, $where_str, $type);

        //echo $gwauthenticate_suppliers_;

	  }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }    
    }
    //End get  suppliers Data ===============
    
    
    //======== qsuppliers_data qsingle query function
    
    function qsuppliers_data($qsupp_id_key)
    {
          
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "qdata","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
    	return get_suppliers("*", "WHERE supp_id='$qsupp_id_key'", "r");

		//echo $gwauthenticate_suppliers_;

      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }  
    }
   
    //======== qsuppliers_data qsingle query function
    
        
    //======== qsuppliers_ddata qsingle query function    
    function qsuppliers_ddata($supp_id_col, $qsupp_id_key)
    {
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "qddata","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
    	return get_suppliers("*", "WHERE $supp_id_col='$qsupp_id_key'", "r");

		//echo $gwauthenticate_suppliers_;

     }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }   
    }
    //======== qsuppliers_ddata qsingle query function

    //======== count suppliers data function
    
    function count_suppliers($suppliers_wherestr)
    {
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "count_data","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
      $clean_suppliers_where_str="";
  
      if($suppliers_wherestr!='')
      {
        $clean_suppliers_where_str="Where ".$suppliers_wherestr;
      }

      return get_suppliers("count(*) as return_result", " ".$clean_suppliers_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_suppliers_;

      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }    
    }
    //======== count suppliers data function

    //======== sum  suppliers data function
    
    function sum_suppliers($suppliers_sumcol, $suppliers_wherestr)
    {
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "sum_data","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
      $clean_suppliers_where_str="";
  
      if($suppliers_wherestr!='')
      {
        $clean_suppliers_where_str="Where ".$suppliers_wherestr;
      }

      return get_suppliers("sum($suppliers_sumcol) as return_result", " ".$clean_suppliers_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_suppliers_;


      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
        


     }    
    }
    
    //======== sum  suppliers data function   
    
    
    //Start drop  suppliers Data ===============
    
    function drop_suppliers($where_str)
    {
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "drop_data","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
    	return magic_sql_delete("suppliers", $where_str);

		//echo $gwauthenticate_suppliers_;

      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
		

     }
    }
    //End drop  suppliers Data ===============    
    
    
   

    
 	//Start Add team Data ===============
 	function add_team($team_arr_)
    {
     $gw_team_cols=array();
     
     foreach($team_arr_ as $team_arr_gw => $team_arr_gw_val)
     {
     
     	$gw_team_cols[]=$team_arr_gw;
        
     }
     
     $gw_team_cols_str=implode(",", $gw_team_cols);
     
     $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "insert",$gw_team_cols_str);
     
     $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
     
     if($gwauthenticate_team_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("team", $team_arr_);
     
     	//echo $gwauthenticate_team_;

     }else{
     
     	echo $gwauthenticate_team_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");

     }
     
    }
    
       function initialize_team()
        {
        
         global $team_uptoken;
             
         $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "select","");

         $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
         	
          //echo $gwauthenticate_team_;

         if($gwauthenticate_team_json["response"]=="ok")
         {
         
         	return get_team("*", "WHERE primkey='$team_uptoken'", "r");
         
            echo $gwauthenticate_team_;

         }else{

         	echo $gwauthenticate_team_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");
         
         }
        }   
    //End Add team Data ===============
                
    //Start Update team Data ===============
    
 	function update_team($team_arr_, $where_str)
    {
         $gw_team_cols=array();
     
     foreach($team_arr_ as $team_arr_gw => $team_arr_gw_val)
     {
     
     	$gw_team_cols[]=$team_arr_gw;
        
     }
     
     $gw_team_cols_str=implode(",", $gw_team_cols);
     
     $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "update",$gw_team_cols_str);
     
     $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
     
     if($gwauthenticate_team_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("team", $team_arr_, $where_str);

       // echo $gwauthenticate_team_;
        
        exit;

     }else{

        echo $gwauthenticate_team_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");


      }
    
    }
 	
    
    //End Update team Data ===============

    //Start get  team Data ===============
    
    function get_team($colstr, $where_str, $type)
    {
          
     $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "select","");
     
     $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
     
     if($gwauthenticate_team_json["response"]=="ok")
     {
    	return mosyflex_sel("team", $colstr, $where_str, $type);

        //echo $gwauthenticate_team_;

	  }else{
     
     	echo $gwauthenticate_team_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");


     }    
    }
    //End get  team Data ===============
    
    
    //======== qteam_data qsingle query function
    
    function qteam_data($quser_id_key)
    {
          
     $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "qdata","");
     
     $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
     
     if($gwauthenticate_team_json["response"]=="ok")
     {    
    	return get_team("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_team_;

      }else{
     
     	echo $gwauthenticate_team_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");


     }  
    }
   
    //======== qteam_data qsingle query function
    
        
    //======== qteam_ddata qsingle query function    
    function qteam_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "qddata","");
     
     $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
     
     if($gwauthenticate_team_json["response"]=="ok")
     {    
    	return get_team("*", "WHERE $user_id_col='$quser_id_key'", "r");

		//echo $gwauthenticate_team_;

     }else{
     
     	echo $gwauthenticate_team_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");


     }   
    }
    //======== qteam_ddata qsingle query function

    //======== count team data function
    
    function count_team($team_wherestr)
    {
     
     $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "count_data","");
     
     $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
     
     if($gwauthenticate_team_json["response"]=="ok")
     {    
      $clean_team_where_str="";
  
      if($team_wherestr!='')
      {
        $clean_team_where_str="Where ".$team_wherestr;
      }

      return get_team("count(*) as return_result", " ".$clean_team_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_team_;

      }else{
     
     	echo $gwauthenticate_team_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");


     }    
    }
    //======== count team data function

    //======== sum  team data function
    
    function sum_team($team_sumcol, $team_wherestr)
    {
     
     $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "sum_data","");
     
     $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
     
     if($gwauthenticate_team_json["response"]=="ok")
     {    
      $clean_team_where_str="";
  
      if($team_wherestr!='')
      {
        $clean_team_where_str="Where ".$team_wherestr;
      }

      return get_team("sum($team_sumcol) as return_result", " ".$clean_team_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_team_;


      }else{
     
     	echo $gwauthenticate_team_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");
        


     }    
    }
    
    //======== sum  team data function   
    
    
    //Start drop  team Data ===============
    
    function drop_team($where_str)
    {
     
     $gwauthenticate_team_=gw_oauth("table", magic_current_url(), "team", "drop_data","");
     
     $gwauthenticate_team_json=json_decode($gwauthenticate_team_, true);
     
     if($gwauthenticate_team_json["response"]=="ok")
     {    
    	return magic_sql_delete("team", $where_str);

		//echo $gwauthenticate_team_;

      }else{
     
     	echo $gwauthenticate_team_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_team_)."");
		

     }
    }
    //End drop  team Data ===============    
    
    
            //Start Upload team_photo Function 
            function upload_team_photo($txt_team_photo, $where_str){
              
			  $file_name1=explode(".", basename($_FILES[$txt_team_photo]['name']))[0];

              $file_name=str_replace(" ", "_", $file_name1);
 				
              if (!file_exists('./img/team_photo')) @mkdir('./img/team_photo');

              $cur_item_photos=magic_upload_file('./img/team_photo/', $txt_team_photo, $file_name."_".magic_random_str(5));

              $item_photo=mmres($cur_item_photos);

              magic_compress_file($cur_item_photos, $cur_item_photos, 50);
              
              $team_node=get_team("*", "WHERE ".$where_str."", "r");

              unlink($team_node["photo"]);

              magic_sql_update('team', '{"photo":"'.$cur_item_photos.'"}', $where_str);

			}
           //End Upload team_photo Function 

            
   

    
 	//Start Add transactions Data ===============
 	function add_transactions($transactions_arr_)
    {
     $gw_transactions_cols=array();
     
     foreach($transactions_arr_ as $transactions_arr_gw => $transactions_arr_gw_val)
     {
     
     	$gw_transactions_cols[]=$transactions_arr_gw;
        
     }
     
     $gw_transactions_cols_str=implode(",", $gw_transactions_cols);
     
     $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "insert",$gw_transactions_cols_str);
     
     $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
     
     if($gwauthenticate_transactions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("transactions", $transactions_arr_);
     
     	//echo $gwauthenticate_transactions_;

     }else{
     
     	echo $gwauthenticate_transactions_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");

     }
     
    }
    
       function initialize_transactions()
        {
        
         global $transactions_uptoken;
             
         $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "select","");

         $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
         	
          //echo $gwauthenticate_transactions_;

         if($gwauthenticate_transactions_json["response"]=="ok")
         {
         
         	return get_transactions("*", "WHERE primkey='$transactions_uptoken'", "r");
         
            echo $gwauthenticate_transactions_;

         }else{

         	echo $gwauthenticate_transactions_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");
         
         }
        }   
    //End Add transactions Data ===============
                
    //Start Update transactions Data ===============
    
 	function update_transactions($transactions_arr_, $where_str)
    {
         $gw_transactions_cols=array();
     
     foreach($transactions_arr_ as $transactions_arr_gw => $transactions_arr_gw_val)
     {
     
     	$gw_transactions_cols[]=$transactions_arr_gw;
        
     }
     
     $gw_transactions_cols_str=implode(",", $gw_transactions_cols);
     
     $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "update",$gw_transactions_cols_str);
     
     $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
     
     if($gwauthenticate_transactions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("transactions", $transactions_arr_, $where_str);

       // echo $gwauthenticate_transactions_;
        
        exit;

     }else{

        echo $gwauthenticate_transactions_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");


      }
    
    }
 	
    
    //End Update transactions Data ===============

    //Start get  transactions Data ===============
    
    function get_transactions($colstr, $where_str, $type)
    {
          
     $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "select","");
     
     $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
     
     if($gwauthenticate_transactions_json["response"]=="ok")
     {
    	return mosyflex_sel("transactions", $colstr, $where_str, $type);

        //echo $gwauthenticate_transactions_;

	  }else{
     
     	echo $gwauthenticate_transactions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");


     }    
    }
    //End get  transactions Data ===============
    
    
    //======== qtransactions_data qsingle query function
    
    function qtransactions_data($qtransaction_id_key)
    {
          
     $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "qdata","");
     
     $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
     
     if($gwauthenticate_transactions_json["response"]=="ok")
     {    
    	return get_transactions("*", "WHERE transaction_id='$qtransaction_id_key'", "r");

		//echo $gwauthenticate_transactions_;

      }else{
     
     	echo $gwauthenticate_transactions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");


     }  
    }
   
    //======== qtransactions_data qsingle query function
    
        
    //======== qtransactions_ddata qsingle query function    
    function qtransactions_ddata($transaction_id_col, $qtransaction_id_key)
    {
     
     $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "qddata","");
     
     $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
     
     if($gwauthenticate_transactions_json["response"]=="ok")
     {    
    	return get_transactions("*", "WHERE $transaction_id_col='$qtransaction_id_key'", "r");

		//echo $gwauthenticate_transactions_;

     }else{
     
     	echo $gwauthenticate_transactions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");


     }   
    }
    //======== qtransactions_ddata qsingle query function

    //======== count transactions data function
    
    function count_transactions($transactions_wherestr)
    {
     
     $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "count_data","");
     
     $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
     
     if($gwauthenticate_transactions_json["response"]=="ok")
     {    
      $clean_transactions_where_str="";
  
      if($transactions_wherestr!='')
      {
        $clean_transactions_where_str="Where ".$transactions_wherestr;
      }

      return get_transactions("count(*) as return_result", " ".$clean_transactions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_transactions_;

      }else{
     
     	echo $gwauthenticate_transactions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");


     }    
    }
    //======== count transactions data function

    //======== sum  transactions data function
    
    function sum_transactions($transactions_sumcol, $transactions_wherestr)
    {
     
     $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "sum_data","");
     
     $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
     
     if($gwauthenticate_transactions_json["response"]=="ok")
     {    
      $clean_transactions_where_str="";
  
      if($transactions_wherestr!='')
      {
        $clean_transactions_where_str="Where ".$transactions_wherestr;
      }

      return get_transactions("sum($transactions_sumcol) as return_result", " ".$clean_transactions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_transactions_;


      }else{
     
     	echo $gwauthenticate_transactions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");
        


     }    
    }
    
    //======== sum  transactions data function   
    
    
    //Start drop  transactions Data ===============
    
    function drop_transactions($where_str)
    {
     
     $gwauthenticate_transactions_=gw_oauth("table", magic_current_url(), "transactions", "drop_data","");
     
     $gwauthenticate_transactions_json=json_decode($gwauthenticate_transactions_, true);
     
     if($gwauthenticate_transactions_json["response"]=="ok")
     {    
    	return magic_sql_delete("transactions", $where_str);

		//echo $gwauthenticate_transactions_;

      }else{
     
     	echo $gwauthenticate_transactions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_)."");
		

     }
    }
    //End drop  transactions Data ===============    
    
    
  //===============End Mosy queries-============

//============= Start Sql chart  Script =====================

function get_mosychart_data($tbl, $colstr, $where_str, $xcol, $ycol, $groupby)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str="";
   $groupby_cols="";
   
   if($where_str!='')
   {
     $fun_where_str=" WHERE ".$where_str;
   }
   
   if($groupby!='')
   {
     $groupby_cols=" GROUP BY ".$groupby;
   }
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ".$groupby_cols." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================


//============= Start   mosy flex select script =====================

function mosyflex_sel($tbl, $colstr, $where_str, $loop_or_row_l_r)
{
   global $single_conn;
   global $single_db;
   global $flex_result;
   global $datalimit;
  
  $paginate_q="";
  $paginate_state="";
  
  $pagination_token=$tbl."_mpgtkn";
  
  $loop_or_row_l_rtype=$loop_or_row_l_r;
  
  if (strpos($loop_or_row_l_r, ':') !== false)
  {
    $loop_or_row_l_r_str=explode(":", $loop_or_row_l_r);

    $pagination_token=$loop_or_row_l_r_str[1];

    $loop_or_row_l_rtype=$loop_or_row_l_r_str[0];

    $paginate_state="paginate";
    
    $pagination_sql="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

    $process_pagination=mysqli_query($single_conn, $pagination_sql) or die(mysqli_error($single_conn));

    $paginate_q=mosy_paginate($process_pagination, $datalimit, $pagination_token);

    $new_where_str=$where_str." LIMIT ".$paginate_q[0].", $datalimit ";

    $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_str."";
    

  }else{
    
      $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

  }
   
    
  $flex_result_q=mysqli_query($single_conn, $sql_str) or die(mysqli_error($single_conn));
  
  $flex_result=$flex_result_q;

  if($loop_or_row_l_rtype=='r')
  {
    $flex_result_r=mysqli_fetch_array($flex_result_q);
    
    $flex_result=$flex_result_r;
    
  }
  
  if($paginate_state=='paginate')
  {
  	$flex_result=array($flex_result_q, $paginate_q[1], $paginate_q[0], $sql_str, $pagination_sql);  
  }
  
  return $flex_result;
  
}

function mosy_paginate($sqlstring, $reclimit, $token_name)
{

  $requested_page = isset($_GET[$token_name]) ? intval(base64_decode($_GET[$token_name])) : 1;

  $rows_count = mysqli_num_rows($sqlstring);

  $items_per_page = $reclimit;

  $page_count = ceil($rows_count / $items_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_row = ($requested_page - 1) * $items_per_page;

  $recordperpage_data=array($first_row,$page_count);

  return $recordperpage_data;
  
}
//============= End  mosy flex select script =====================

  function tonum($number_str)
  {
	if($number_str=='')
    {
      $number_str=0;
    }
  	return number_format($number_str, 0, ".", ",");
  	

  }
  
//checkblank fuction

function checkblank($value, $return_val)
{
  
  global $fun_resonse;

  if($value!='')
  {
  $fun_resonse=$value;
  }else{
    $fun_resonse=$return_val;

  }
  return $fun_resonse;

}

//get date foramrt

function ftime($time_st, $type)
{
  	global $timeresp;
    
  $timeresp=date("l, jS, M, y, @ H:i:s");

  if($time_st=="") 
  {
    $timeresp=date("l, jS, M, y, @ H:i:s");

  	if($type=="date")
    {
    $timeresp=date("l, jS, M, y");
    }
    
  }
  
  if($time_st!=""){
  
     $timeresp=date("l, jS, M, y, @ H:i:s", strtotime($time_st));

    if($type=="date")
    {
    	$timeresp=date("l, jS, M, y", strtotime($time_st));
    }
    
  }
	return $timeresp;
}

function date_time_input($time_st, $full_date_time)
{
  	global $timeresp;
    
    $date_form="Y-m-d\TH:i:s";
    
    if($full_date_time=="date")
    {
    $date_form="Y-m-d";
    }
    
    if($full_date_time=="time")
    {
    $date_form="H:i:s";
    }
    
  if($time_st==""){
  	$timeresp=date($date_form);
  }else{
   
   $timeresp=date($date_form, strtotime($time_st));

  }
	return $timeresp;
}
function daytime()
{
  global $daytime;

  $daytime='Hello';

  $fromdate=date('A');

  if($fromdate=='AM'){
 	 $daytime='Morning';
  }

  if($fromdate=='PM'){
  	$daytime='Evening';
  }

  return $daytime;
}
function time_elapsed_string($datetime, $full = false) 
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        "y" => "year",
        "m" => "month",
        "w" => "week",
        "d" => "day",
        "h" => "hour",
        "i" => "minute",
        "s" => "second",
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . " " . $v . ($diff->$k > 1 ? "s" : "");
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(", ", $string) . " ago" : "just now";
}

if (file_exists("./mosy_paginate.php")){
include("./mosy_paginate.php");
}

function pdf_url($current, $pdfurl)
{
  
  $filter_param=str_replace($current."", $pdfurl."", (magic_current_url()));

  if(strpos($filter_param, '?') !== false) 
  {
    $filter_param=str_replace($current."?", $pdfurl."?", (magic_current_url()));

  }

  if(strpos($filter_param, '.php?') !== false) 
  {
    $filter_param=str_replace($current.".php?", $pdfurl."?", (magic_current_url()));

  }

  return $filter_param;
  
}

function add_url_param( $key, $value, $passed_url) 
{
  $url=$passed_url;
  if($passed_url=='')
  {
    $url=magic_current_url();
  }
  
  $info = parse_url( $url );

  if(isset($info['query']))
  {
    parse_str( $info['query'], $query );
  }else{
    $query="";
  }
    return $info['scheme'] . '://' . $info['host'] . $info['path'] . '?' . http_build_query( $query ? array_merge( $query, array($key => $value ) ) : array( $key => $value ) );
}


function dmy($time_st, $full_date_time)
{
  	global $timeresp;
    
    $date_form="d-m-Y H:i:s";
    
    if($full_date_time=="date")
    {
    $date_form="d-m-Y";
    }
    
    if($full_date_time=="time")
    {
    $date_form="H:i:s";
    }
    
  if($time_st==""){
  	$timeresp=date($date_form);
  }else{
   
   $timeresp=date($date_form, strtotime($time_st));

  }
	return $timeresp;
}
//<--ncgh-->
?>