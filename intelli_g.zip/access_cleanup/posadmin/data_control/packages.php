<?php 

		//== initialize edit token variables

		$packages_uptoken="";

		if(isset($_GET["packages_uptoken"]))
		{
		$packages_uptoken=base64_decode($_GET["packages_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["packages_insert_btn"])){
//------- begin Create Update record from packages --> 
$package_id=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$package_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_name"]);
$price=mysqli_real_escape_string($mysqliconn, $_POST["txt_price"]);
$description=mysqli_real_escape_string($mysqliconn, $_POST["txt_description"]);
$admin_id=mysqli_real_escape_string($mysqliconn, "");
//===-- End Create Update record from packages -->


$packages_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`packages` (`primkey`,`package_id`,`package_name`,`price`,`description`,`admin_id`) 
 VALUES 
(NULL,'$package_id','$package_name','$price','$description','$admin_id')");

 //--- get primary key id
$packages_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?packages_uptoken='.base64_encode($packages_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["packages_update_btn"])){
//------- begin Create Update record from packages --> 
$package_name=mysqli_real_escape_string($mysqliconn, $_POST["txt_package_name"]);
$price=mysqli_real_escape_string($mysqliconn, $_POST["txt_price"]);
$description=mysqli_real_escape_string($mysqliconn, $_POST["txt_description"]);
$admin_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_admin_id"]);
//===-- End Create Update record from packages -->


$packages_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`packages` SET `package_name`='$package_name',`price`='$price',`description`='$description',`admin_id`='$admin_id' WHERE primkey='$packages_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?packages_uptoken='.base64_encode($packages_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start packages select Find packages Records Profile query 

$find_packages_records_profile_packages_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`packages` WHERE `primkey`='$packages_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$packages_node=mysqli_fetch_array($find_packages_records_profile_packages_query);

//=== End packages select Find packages Records Profile  query




if(isset($_POST["qpackages_btn"])){


$qpackages_str=base64_encode($_POST["txt_packages"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qpackages='.($qpackages_str).'');

}

if(isset($_GET["qpackages"])){


$qpackages=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qpackages"]));



//===== limit record value

$packages_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`packages` WHERE (`primkey` LIKE '%".$qpackages."%' OR  `package_id` LIKE '%".$qpackages."%' OR  `package_name` LIKE '%".$qpackages."%' OR  `price` LIKE '%".$qpackages."%' OR  `description` LIKE '%".$qpackages."%' OR  `admin_id` LIKE '%".$qpackages."%')";

//===== Pagination function

$packages_pagination= list_record_per_page($mysqliconn, $packages_sqlstring, $datalimit);


//===== get return values


$packages_firstproduct=$packages_pagination["0"];

$packages_pgcount=$packages_pagination["1"];

//=== start packages select  Like Query String packages list  

$packages_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`packages`  WHERE (`primkey` LIKE '%".$qpackages."%' OR  `package_id` LIKE '%".$qpackages."%' OR  `package_name` LIKE '%".$qpackages."%' OR  `price` LIKE '%".$qpackages."%' OR  `description` LIKE '%".$qpackages."%' OR  `admin_id` LIKE '%".$qpackages."%') ORDER BY `primkey` DESC LIMIT $packages_firstproduct, $datalimit" );



//=== End packages select  Like Query String packages list
;

}else{

//===== limit record value

$packages_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`packages`";

//===== Pagination function

$packages_pagination= list_record_per_page($mysqliconn, $packages_sqlstring, $datalimit);


//===== get return values


$packages_firstproduct=$packages_pagination["0"];

$packages_pgcount=$packages_pagination["1"];

//=== start packages select  Like Query String packages list  

$packages_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`packages`  ORDER BY `primkey` DESC LIMIT $packages_firstproduct, $datalimit" );

//$packages_list_res=mysqli_fetch_array($packages_list_query);

//=== End packages select  Like Query String packages list

}


//== Start  **** Delete packages Records  

if(isset($_GET["deletepackages"]))
{

//======confirm pop up 

$conf_del_packages_btn=magic_button_link("./editpackages.php?packages_uptoken=".$_GET["packages_uptoken"]."&conf_deletepackages", "Yes", 'style="margin-right:10px;"');

$cancel_del_packages_btn=magic_button_link("./editpackages.php?packages_uptoken=".$_GET["packages_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_packages_btn." ".$cancel_del_packages_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deletepackages"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`packages` WHERE `primkey`='$packages_uptoken'");

//==add your redirect here 

header("location:./packages.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete packages Records 

//--<{ncgh}/>
?>