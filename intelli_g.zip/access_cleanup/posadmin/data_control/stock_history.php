<?php 

		//== initialize edit token variables

		$stock_history_uptoken="";

		if(isset($_GET["stock_history_uptoken"]))
		{
		$stock_history_uptoken=base64_decode($_GET["stock_history_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["stock_history_insert_btn"])){
//------- begin Create Update record from stock_history --> 
$item_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_item_id"]);
$stocked=mysqli_real_escape_string($mysqliconn, $_POST["txt_stocked"]);
$amount=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount"]);
$stock_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_stock_date"]);
$supplier=mysqli_real_escape_string($mysqliconn, $_POST["txt_supplier"]);
$comment=mysqli_real_escape_string($mysqliconn, $_POST["txt_comment"]);
//===-- End Create Update record from stock_history -->


$stock_history_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`stock_history` (`primkey`,`item_id`,`stocked`,`amount`,`stock_date`,`supplier`,`comment`) 
 VALUES 
(NULL,'$item_id','$stocked','$amount','$stock_date','$supplier','$comment')");

 //--- get primary key id
$stock_history_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?stock_history_uptoken='.base64_encode($stock_history_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["stock_history_update_btn"])){
//------- begin Create Update record from stock_history --> 
$item_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_item_id"]);
$stocked=mysqli_real_escape_string($mysqliconn, $_POST["txt_stocked"]);
$amount=mysqli_real_escape_string($mysqliconn, $_POST["txt_amount"]);
$stock_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_stock_date"]);
$supplier=mysqli_real_escape_string($mysqliconn, $_POST["txt_supplier"]);
$comment=mysqli_real_escape_string($mysqliconn, $_POST["txt_comment"]);
//===-- End Create Update record from stock_history -->


$stock_history_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`stock_history` SET `item_id`='$item_id',`stocked`='$stocked',`amount`='$amount',`stock_date`='$stock_date',`supplier`='$supplier',`comment`='$comment' WHERE primkey='$stock_history_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?stock_history_uptoken='.base64_encode($stock_history_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start stock_history select Find stock_history Records Profile query 

$find_stock_history_records_profile_stock_history_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`stock_history` WHERE `primkey`='$stock_history_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$stock_history_node=mysqli_fetch_array($find_stock_history_records_profile_stock_history_query);

//=== End stock_history select Find stock_history Records Profile  query




if(isset($_POST["qstock_history_btn"])){


$qstock_history_str=base64_encode($_POST["txt_stock_history"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qstock_history='.($qstock_history_str).'');

}

if(isset($_GET["qstock_history"])){


$qstock_history=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qstock_history"]));



//===== limit record value

$stock_history_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`stock_history` WHERE (`primkey` LIKE '%".$qstock_history."%' OR  `item_id` LIKE '%".$qstock_history."%' OR  `stocked` LIKE '%".$qstock_history."%' OR  `amount` LIKE '%".$qstock_history."%' OR  `stock_date` LIKE '%".$qstock_history."%' OR  `supplier` LIKE '%".$qstock_history."%' OR  `comment` LIKE '%".$qstock_history."%')";

//===== Pagination function

$stock_history_pagination= list_record_per_page($mysqliconn, $stock_history_sqlstring, $datalimit);


//===== get return values


$stock_history_firstproduct=$stock_history_pagination["0"];

$stock_history_pgcount=$stock_history_pagination["1"];

//=== start stock_history select  Like Query String stock_history list  

$stock_history_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`stock_history`  WHERE (`primkey` LIKE '%".$qstock_history."%' OR  `item_id` LIKE '%".$qstock_history."%' OR  `stocked` LIKE '%".$qstock_history."%' OR  `amount` LIKE '%".$qstock_history."%' OR  `stock_date` LIKE '%".$qstock_history."%' OR  `supplier` LIKE '%".$qstock_history."%' OR  `comment` LIKE '%".$qstock_history."%') ORDER BY `primkey` DESC LIMIT $stock_history_firstproduct, $datalimit" );



//=== End stock_history select  Like Query String stock_history list
;

}else{

//===== limit record value

$stock_history_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`stock_history`";

//===== Pagination function

$stock_history_pagination= list_record_per_page($mysqliconn, $stock_history_sqlstring, $datalimit);


//===== get return values


$stock_history_firstproduct=$stock_history_pagination["0"];

$stock_history_pgcount=$stock_history_pagination["1"];

//=== start stock_history select  Like Query String stock_history list  

$stock_history_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`stock_history`  ORDER BY `primkey` DESC LIMIT $stock_history_firstproduct, $datalimit" );

//$stock_history_list_res=mysqli_fetch_array($stock_history_list_query);

//=== End stock_history select  Like Query String stock_history list

}


//== Start  **** Delete stock_history Records  

if(isset($_GET["deletestock_history"]))
{

//======confirm pop up 

$conf_del_stock_history_btn=magic_button_link("./editstock_history.php?stock_history_uptoken=".$_GET["stock_history_uptoken"]."&conf_deletestock_history", "Yes", 'style="margin-right:10px;"');

$cancel_del_stock_history_btn=magic_button_link("./editstock_history.php?stock_history_uptoken=".$_GET["stock_history_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_stock_history_btn." ".$cancel_del_stock_history_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deletestock_history"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`stock_history` WHERE `primkey`='$stock_history_uptoken'");

//==add your redirect here 

header("location:./stock_history.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete stock_history Records 

//--<{ncgh}/>
?>