<?php 

		//== initialize edit token variables

		$notes_uptoken="";

		if(isset($_GET["notes_uptoken"]))
		{
		$notes_uptoken=base64_decode($_GET["notes_uptoken"]);
		}

//************* START INSERT QUERY 
if(isset($_POST["notes_insert_btn"])){
//------- begin Create Update record from notes --> 
$note_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_note_id"]);
$title=mysqli_real_escape_string($mysqliconn, $_POST["txt_title"]);
$admin_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_admin_id"]);
$note=mysqli_real_escape_string($mysqliconn, $_POST["txt_note"]);
$note_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_note_date"]);
$note_tag=mysqli_real_escape_string($mysqliconn, $_POST["txt_note_tag"]);
$user_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_user_id"]);
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
//===-- End Create Update record from notes -->


$notes_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$infolinkdb`.`notes` (`primkey`,`note_id`,`title`,`admin_id`,`note`,`note_date`,`note_tag`,`user_id`,`client_id`) 
 VALUES 
(NULL,'$note_id','$title','$admin_id','$note','$note_date','$note_tag','$user_id','$client_id')");

 //--- get primary key id
$notes_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?notes_uptoken='.base64_encode($notes_return_key).'&table_alert=Record added Succesfully');
}
//************* END INSERT QUERY 



//************* START UPDATE QUERY 
if(isset($_POST["notes_update_btn"])){
//------- begin Create Update record from notes --> 
$note_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_note_id"]);
$title=mysqli_real_escape_string($mysqliconn, $_POST["txt_title"]);
$admin_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_admin_id"]);
$note=mysqli_real_escape_string($mysqliconn, $_POST["txt_note"]);
$note_date=mysqli_real_escape_string($mysqliconn, $_POST["txt_note_date"]);
$note_tag=mysqli_real_escape_string($mysqliconn, $_POST["txt_note_tag"]);
$user_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_user_id"]);
$client_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_client_id"]);
//===-- End Create Update record from notes -->


$notes_update_query = mysqli_query($mysqliconn, "UPDATE  `$infolinkdb`.`notes` SET `primkey`='$primkey',`note_id`='$note_id',`title`='$title',`admin_id`='$admin_id',`note`='$note',`note_date`='$note_date',`note_tag`='$note_tag',`user_id`='$user_id',`client_id`='$client_id' WHERE primkey='$notes_uptoken'");

//--- Redirect to current location with primary key
header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?notes_uptoken='.base64_encode($notes_uptoken).'&table_alert=Record Updated Succesfully');

}
//************* END UPDATE QUERY 


//=== start notes select Find notes Records Profile query 

$find_notes_records_profile_notes_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`notes` WHERE `primkey`='$notes_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$notes_node=mysqli_fetch_array($find_notes_records_profile_notes_query);

//=== End notes select Find notes Records Profile  query




if(isset($_POST["qnotes_btn"])){


$qnotes_str=base64_encode($_POST["txt_notes"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qnotes='.($qnotes_str).'');

}

if(isset($_GET["qnotes"])){


$qnotes=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qnotes"]));



//===== limit record value

$notes_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`notes` WHERE (`primkey` LIKE '%".$qnotes."%' OR  `note_id` LIKE '%".$qnotes."%' OR  `title` LIKE '%".$qnotes."%' OR  `admin_id` LIKE '%".$qnotes."%' OR  `note` LIKE '%".$qnotes."%' OR  `note_date` LIKE '%".$qnotes."%' OR  `note_tag` LIKE '%".$qnotes."%' OR  `user_id` LIKE '%".$qnotes."%' OR  `client_id` LIKE '%".$qnotes."%')";

//===== Pagination function

$notes_pagination= list_record_per_page($mysqliconn, $notes_sqlstring, $datalimit);


//===== get return values


$notes_firstproduct=$notes_pagination["0"];

$notes_pgcount=$notes_pagination["1"];

//=== start notes select  Like Query String notes list  

$notes_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`notes`  WHERE (`primkey` LIKE '%".$qnotes."%' OR  `note_id` LIKE '%".$qnotes."%' OR  `title` LIKE '%".$qnotes."%' OR  `admin_id` LIKE '%".$qnotes."%' OR  `note` LIKE '%".$qnotes."%' OR  `note_date` LIKE '%".$qnotes."%' OR  `note_tag` LIKE '%".$qnotes."%' OR  `user_id` LIKE '%".$qnotes."%' OR  `client_id` LIKE '%".$qnotes."%') ORDER BY `primkey` DESC LIMIT $notes_firstproduct, $datalimit" );



//=== End notes select  Like Query String notes list
;

}else{

//===== limit record value

$notes_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`notes`";

//===== Pagination function

$notes_pagination= list_record_per_page($mysqliconn, $notes_sqlstring, $datalimit);


//===== get return values


$notes_firstproduct=$notes_pagination["0"];

$notes_pgcount=$notes_pagination["1"];

//=== start notes select  Like Query String notes list  

$notes_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`notes`  ORDER BY `primkey` DESC LIMIT $notes_firstproduct, $datalimit" );

//$notes_list_res=mysqli_fetch_array($notes_list_query);

//=== End notes select  Like Query String notes list

}


//== Start  **** Delete notes Records  

if(isset($_GET["deletenotes"]))
{

//======confirm pop up 

$conf_del_notes_btn=magic_button_link("./editnotes.php?notes_uptoken=".$_GET["notes_uptoken"]."&conf_deletenotes", "Yes", 'style="margin-right:10px;"');

$cancel_del_notes_btn=magic_button_link("./editnotes.php?notes_uptoken=".$_GET["notes_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_notes_btn." ".$cancel_del_notes_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deletenotes"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`notes` WHERE `primkey`='$notes_uptoken'");

//==add your redirect here 

header("location:./notes.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete notes Records 



//=== start notes select Find notes Records Profile query 

$find_notes_records_profile_notes_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`notes` WHERE `primkey`='$notes_uptoken' ORDER BY `primkey` DESC LIMIT 1" );

$notes_node=mysqli_fetch_array($find_notes_records_profile_notes_query);

//=== End notes select Find notes Records Profile  query




if(isset($_POST["qnotes_btn"])){


$qnotes_str=base64_encode($_POST["txt_notes"]);


header('location:./'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).'?qnotes='.($qnotes_str).'');

}

if(isset($_GET["qnotes"])){


$qnotes=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qnotes"]));



//===== limit record value

$notes_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`notes` WHERE (`primkey` LIKE '%".$qnotes."%' OR  `note_id` LIKE '%".$qnotes."%' OR  `title` LIKE '%".$qnotes."%' OR  `admin_id` LIKE '%".$qnotes."%' OR  `note` LIKE '%".$qnotes."%' OR  `note_date` LIKE '%".$qnotes."%' OR  `note_tag` LIKE '%".$qnotes."%' OR  `user_id` LIKE '%".$qnotes."%' OR  `client_id` LIKE '%".$qnotes."%')";

//===== Pagination function

$notes_pagination= list_record_per_page($mysqliconn, $notes_sqlstring, $datalimit);


//===== get return values


$notes_firstproduct=$notes_pagination["0"];

$notes_pgcount=$notes_pagination["1"];

//=== start notes select  Like Query String notes list  

$notes_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`notes`  WHERE (`primkey` LIKE '%".$qnotes."%' OR  `note_id` LIKE '%".$qnotes."%' OR  `title` LIKE '%".$qnotes."%' OR  `admin_id` LIKE '%".$qnotes."%' OR  `note` LIKE '%".$qnotes."%' OR  `note_date` LIKE '%".$qnotes."%' OR  `note_tag` LIKE '%".$qnotes."%' OR  `user_id` LIKE '%".$qnotes."%' OR  `client_id` LIKE '%".$qnotes."%') ORDER BY `primkey` DESC LIMIT $notes_firstproduct, $datalimit" );



//=== End notes select  Like Query String notes list
;

}else{

//===== limit record value

$notes_sqlstring="SELECT COUNT(*) FROM `$infolinkdb`.`notes`";

//===== Pagination function

$notes_pagination= list_record_per_page($mysqliconn, $notes_sqlstring, $datalimit);


//===== get return values


$notes_firstproduct=$notes_pagination["0"];

$notes_pgcount=$notes_pagination["1"];

//=== start notes select  Like Query String notes list  

$notes_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$infolinkdb`.`notes`  ORDER BY `primkey` DESC LIMIT $notes_firstproduct, $datalimit" );

//$notes_list_res=mysqli_fetch_array($notes_list_query);

//=== End notes select  Like Query String notes list

}


//== Start  **** Delete notes Records  

if(isset($_GET["deletenotes"]))
{

//======confirm pop up 

$conf_del_notes_btn=magic_button_link("./editnotes.php?notes_uptoken=".$_GET["notes_uptoken"]."&conf_deletenotes", "Yes", 'style="margin-right:10px;"');

$cancel_del_notes_btn=magic_button_link("./editnotes.php?notes_uptoken=".$_GET["notes_uptoken"], "No", "");

echo magic_screen("Delete this record?<hr>".$conf_del_notes_btn." ".$cancel_del_notes_btn."");

}

//==Delete Record 

if(isset($_GET["conf_deletenotes"]))
{

mysqli_query($mysqliconn, "DELETE FROM `$infolinkdb`.`notes` WHERE `primkey`='$notes_uptoken'");

//==add your redirect here 

header("location:./notes.php?table_alert=Record Deleted Succesfully");
}

//== End  **** Delete notes Records 

//--<{ncgh}/>
?>