<?php 

if(!isset($_SESSION["infocms_admin_session"])){
header('location:./adminlogin?ref_url_go_to='.base64_encode(magic_current_url()).'');
}
?>