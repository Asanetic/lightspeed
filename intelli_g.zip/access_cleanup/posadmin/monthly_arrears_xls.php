<?php
 ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/client_base.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$due_date_title="";

if(isset($_GET["qdue_date"])){
$due_date_title=" due  ".base64_decode($_GET["qdue_date"]);

}

if(isset($_GET["start_date_input"])){
$due_date_title=" for date between  ".base64_decode($_GET["start_date_input"])." and ".base64_decode($_GET["end_date_input"]);

}

if(isset($_GET["monthly_arrears"])){
  
$due_date_title=" for  ".date("M-Y", strtotime(base64_decode($_GET["monthly_arrears"])));

$month_year=date("M-Y", strtotime(base64_decode($_GET["monthly_arrears"])));
}


	header("Content-Type: application/xls");    
	header("Content-Disposition: attachment; filename=infolink_monthly_arrears_".$due_date_title.".xls");  
	header("Pragma: no-cache"); 
	header("Expires: 0");




  
 $tbl= '<table class="table table-hover text-left" id="client_base_data_table">
	    <thead class="text-upperckase">
		   <tr>
  <th scope="col">Building</th>
 <th scope="col">Names</th>
 <th scope="col">Room</th>
 <th scope="col">Package</th>
 <th scope="col">Pkg price</th>
 <th scope="col">Start Date</th>
 <th scope="col">Active Months</th>
 <th scope="col">Inactive Months</th>
 <th scope="col">Total Due</th>
 <th scope="col">Total Paid</th>
 <th scope="col">Pkg Bal</th>
 <th scope="col">Other charges</th>
 <th scope="col">Charges paid</th>
 <th scope="col">Charges Balance</th>
 <th scope="col">Net Arrears</th>
 <th scope="col">Account Status</th>

		   </tr>
	    </thead>
	    <tbody>';
   
   		$pagination_record_count=$client_base_pgcount;
        $i=0;
		while($listclient_base_result=mysqli_fetch_array($client_base_list_query)){

          
          $act_start_date=$listclient_base_result['installation_date'];
          $act_end_date=date("Y-m-d");
          
          if(isset($_GET['end_date_input']))
          {
          $act_start_date=base64_decode($_GET['start_date_input']);
          $act_end_date=base64_decode($_GET['end_date_input']);
          }
          
          
          $tot_pkg_paid=cal_client_payments($act_start_date, $act_end_date,  $listclient_base_result["client_id"]);
		  $tot_inst_charges=cal_client_inst_arrears($act_start_date, $act_end_date, $listclient_base_result["client_id"])[0];
		  $tot_inst_charges_paid=cal_client_inst_arrears($act_start_date, $act_end_date, $listclient_base_result["client_id"])[1];
		  $cpackge_price=qpackage_data($listclient_base_result["package"])['price'];
          

          $active_months= calc_active_months($act_start_date, $act_end_date, $listclient_base_result["client_id"])[0];
                    $inactive_months= calc_active_months($act_start_date, $act_end_date, $listclient_base_result["client_id"])[1];


	      $tot_pkg_due=$active_months*$cpackge_price;
          $tot_pack_bal=$tot_pkg_due-$tot_pkg_paid;
          $inst_charge_bal=$tot_inst_charges-$tot_inst_charges_paid;
                     
          $netarrears=$inst_charge_bal+$tot_pack_bal;
          
          $amount_paid_f= compute_monthy_payment($listclient_base_result["client_id"], $month_year)[0];
          if($amount_paid_f=='skip'){
            $amount_paid_f=$cpackge_price;
          }
          
          $month_arrears=$cpackge_price-$amount_paid_f;
            
        if($month_arrears>0){
           $i++;

       $tbl.='<tr>
 <td scope="col">'.$listclient_base_result["building_no"].'</td>
 <td scope="col">'.$listclient_base_result["client_name"].'</td>
 <td scope="col">'.$listclient_base_result["room_no"].'</td>
 <td scope="col">'.qpackage_data($listclient_base_result["package"])['package_name'].'</td>
  <td scope="col">'.$cpackge_price.'</td>
 <td scope="col">'.date("d/m/Y", strtotime($act_start_date)).'</td>
 <td scope="col">'.$active_months.'</td>
 <td scope="col">'.$inactive_months.'</td>
 <td scope="col">'.$tot_pkg_due.'</td>
 <td scope="col">'.$amount_paid_f.'</td>
 <td scope="col">'.$month_arrears.'</td>
 <td scope="col">'.$tot_inst_charges.'</td>
 <td scope="col">'.$tot_inst_charges_paid.'</td>
 <td scope="col">'.$inst_charge_bal.'</td>
 <td scope="col">'.$netarrears.'</td>
 <td scope="col">'.$listclient_base_result["account_status"].'</td>


	    </tr>';
        } }
$tbl.'	</tbody>
	    </table>';

echo $tbl;