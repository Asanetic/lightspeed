<?php

ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./data_control/vcf_client_base.php');
include('./adminsessionmonitor.php');;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Client Base</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
	<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">
      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Client Base<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          
    <div align="left" class="col-md-6">
       <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
		<a href="./vcf_client_base" class="btn btn-primary mb-3"><i class="fa fa-refresh"></i> Refresh</a>
		<a href="./vcf_client_base?export_state=Not Exported" class="btn btn-primary bg-light mb-3 border border-light font-weight-bold text-primary"><i class="fa fa-exclamation"></i> Not Exported</a>
		<a href="./vcf_client_base?export_state=Exported" class="btn btn-primary bg-success mb-3 border border-success"><i class="fa fa-check"></i> Exported</a>
		<!--<a href="./vcf_client_base" class="btn btn-primary bg-info mb-3 border border-info"><i class="fa fa-arrow-right"></i> Export All</a>-->
		<hr><input type="text" placeholder="Search client base" name="txt_client_base" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button('qclient_base_btn', 'Search', 'style="display:inline-block;"');?> 

	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">
	<table class="table table-hover text-left" id="client_base_data_table">
	    <thead class="text-uppercase">
		   <tr>
          <th scope="col">#</th>
         <th scope="col">Client_Name</th>
         <th scope="col">Client_Tel</th>
         <th scope="col">Location</th>
         <th scope="col">Building_No</th>
         <th scope="col">Floor_No</th>
         <th scope="col">Room_No</th>
         <th scope="col">Package_name</th>
         <th scope="col">Installation_Date</th>
         <th scope="col">Account_Status</th>
		   </tr>
	    </thead>
	    <tbody>
		<?php 

		  echo drop_css();

		$pagination_record_count=$client_base_pgcount;
        $i=0;

        //<--outloop-dope-->

		while($listclient_base_result=mysqli_fetch_array($client_base_list_query)){
	        $i++;

	       //<--inloop-dope-->

	        $edit_drop_link='<div class="p-2 cpointer" style="" onclick="export_contacts(\''.$listclient_base_result['primkey'].'\')"> Export <i class="fa fa-arrow-right "></i></div>';


	        $dropdown_items =$edit_drop_link;
          $exported_bg="bg-light font-weight-bold text-primary";
          if($listclient_base_result['vcf_exported']=='Exported')
          {
            $exported_bg="bg-white";
          }
        ?>
	    <tr class="<?php echo $exported_bg;?>">
	    							  <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
 						 <td scope="col"><?php echo $listclient_base_result["client_name"];?></td>
 						 <td scope="col"><?php echo $listclient_base_result["client_tel"];?></td>
 						 <td scope="col"><?php echo $listclient_base_result["location"];?></td>
 						 <td scope="col"><?php echo $listclient_base_result["building_no"];?></td>
 						 <td scope="col"><?php echo $listclient_base_result["floor_no"];?></td>
 						 <td scope="col"><?php echo $listclient_base_result["room_no"];?></td>
 						 <td scope="col"><?php echo qpackage_data($listclient_base_result["package"])['package_name'];?></td>
 						 <td scope="col"><?php echo date("jS, M Y", strtotime($listclient_base_result["installation_date"]));?></td>
 						 <td scope="col"><?php echo $listclient_base_result["account_status"];?></td>

	    </tr>
	    <?php }?>
	    <!--add_new_row_here-->
	    </tbody>
	    </table>
	 <hr>
	 <?php include("./pagination.php");?>
	</div>
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>