<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/client_base.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

if(!isset($_SESSION['recordlimit'])){
$_SESSION['recordlimit']=TRUE;
$_SESSION['filelim']="15";
}


$limit_per_page='Show '.$_SESSION['filelim'].' Rows per Page'; 

if($_SESSION['filelim']=='100000000000000000'){
$limit_per_page=" Showing All Records ";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Report Panel</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Report Panel<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  <div class="row justify-content-center col-md-12">
  <div class="col-md-12 mb-4 row justify-content-center text-center ">
<select name="" class="form-control col-md-3" id="rep_doc_type">
   <option  value="pdf">Select Document Type</option>
   <option  value="xls">Excel</option>
   <option  value="pdf">PDF</option>
</select>
  <div class="col-md-6">
<select class="form-control col-md-5" onChange="changelim(this.value);" name="reclimcmb" id="reclimcmb">
<option><?php echo $limit_per_page?></option>
<option>1</option>
<option>2</option>
<option>5</option>
<option>10</option>
<option>50</option>
<option>100</option>
<option>200</option>
<option>500</option>
<option>1000</option>
<option value="100000000000000000">All Records</option>
</select></div>
</div>
<!-- Start  Title ribbon-->
<h4 class="col-md-12 row p-2 mb-4 justify-content-center">
  <div class="col-md-4 bg-dark mt-3 " style="height: 1px"></div>
  <div class="col-md-3 mr-lg-2 ml-lg-2 text-center"> Client Report</div>
  <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>
</h4>
<!-- End Title ribbon-->
		<div class="btn btn-info mb-3 mr-lg-3" onclick="window.open('./client_base_arrears_'+document.getElementById('rep_doc_type').value+'.php')"><i class="fa fa-database"></i> All With arrears</div>
  	
   <div  onclick="pop_arr_month('./monthly_arrears_'+document.getElementById('rep_doc_type').value+'.php', 'arrears', '')"  class="btn btn-danger mb-3 mr-lg-3"><i class="fa fa-calendar"></i> Monthly Arrears</div>      
   
  
		<div  onclick="window.open('./client_base_'+document.getElementById('rep_doc_type').value+'.php?qstate=Active')" class="btn btn-success mb-3 mr-lg-3"> <i class="fa fa-heart"></i> Active </div>
		<div onclick="window.open('./client_base_'+document.getElementById('rep_doc_type').value+'.php?qstate=Inactive')" class="btn btn-dark mb-3 mr-lg-3"> <i class="fa fa-warning"></i> Inactive </div>
		<div  onclick="pop_due_date('./client_base_'+document.getElementById('rep_doc_type').value+'.php')" class="btn btn-success mb-3 mr-lg-3"> <i class="fa fa-calendar"></i> Filter Due Date </div>
        <div  onclick="pop_report_date('./client_base_'+document.getElementById('rep_doc_type').value+'.php', 'Installation Date', 'install_date')"  class="btn btn-primary mb-3"><i class="fa fa-wifi"></i> Filter by install date</div>
  
</div> 
 
<!-- End  panel tray-->
 <div class="col-md-12 mt-4 row p-2 justify-content-center">

<!-- Start  Title ribbon-->
<h4 class="col-md-12 row p-2 mb-4 justify-content-center">
  <div class="col-md-4 bg-dark mt-3 " style="height: 1px"></div>
  <div class="col-md-3 mr-lg-2 ml-lg-2 text-center"> Transactions</div>
  <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>
</h4>
<!-- End Title ribbon-->
        <div  onclick="pop_report_date('./trx_'+document.getElementById('rep_doc_type').value+'.php', 'Transaction Date', 'trxfilter')"  class="btn btn-primary mb-3 mr-lg-3"><i class="fa fa-calendar"></i> Filter by date</div>

		<div  onclick="window.open('trx_'+document.getElementById('rep_doc_type').value+'.php')" class="btn btn-success mb-3 mr-lg-3"> <i class="fa fa-list"></i> All Transactions </div>
        <div  onclick="pop_client_search('report_panel_'+document.getElementById('rep_doc_type').value+'')" class="btn btn-primary mb-3"><i class="fa fa-users"></i> Payment By client</div>
        <div onclick="pop_payment_months('trx_'+document.getElementById('rep_doc_type').value+'.php')" class="btn btn-primary mb-3 ml-lg-3"><i class="fa fa-money"></i> Monthly payments</div>
        <div onclick="pop_analy_month('monthly_analysis_pdf.php')" class="btn btn-warning text-dark mb-3 ml-lg-3"><i class="fa fa-line-chart"></i> Monthly Analysis</div>
        <div onclick="pop_analy_month_year('annual_analysis.php')" class="btn btn-secondary text-white mb-3 ml-lg-3"><i class="fa fa-star"></i> Annual Analysis</div>
  
</div> 
 
<!-- End  panel tray-->
  
  

  <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    //===================== change records limit ===============
  <?php if(isset($_GET['txtreclim'])){
$_SESSION['filelim']=$_GET['txtreclim'];

	?>
	<script>
	currrecloc=window.location.href;
	var paramtotrim = "?txtreclim";
	if (currrecloc.indexOf("&txtreclim") >= 0){
	paramtotrim ="&txtreclim";
	}
	
	window.location=window.location.href.split(paramtotrim)[0];
	</script>
	<?php
  }
  ?>
<script type="text/javascript">
//=========================== push write limit to file
function changelim(newlimit){
var pgtkn=newlimit;

var iofile = "?txtreclim="+pgtkn;
var currloc2 = window.location.href;
if (currloc2.indexOf("?") >= 0){
iofile = "&txtreclim="+pgtkn;
}
window.location=currloc2 +iofile;
//=========================== push write limit to file

}
</script>
    </form>
</body>
</html>

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  