 
//===============Start Mosy queries-============ 

    //Start get  active_client_months Data ===============
    
      function get_active_client_months(active_client_months_colstr, active_client_months_filter_col, active_client_months_cols, active_client_months_node_function_name, active_client_months_callback_function_string, active_client_months_ui_tag)
      {
        mosyflex_sel("active_client_months", active_client_months_colstr, active_client_months_filter_col , active_client_months_cols, active_client_months_node_function_name, active_client_months_callback_function_string, active_client_months_ui_tag);
        
      }
    //End get  active_client_months Data ===============

    //Start insert  active_client_months Data ===============

	function add_active_client_months(active_client_months_cols, active_client_months_vals, active_client_months_callback_function_string)
    {
		
        mosyajax_create_data("active_client_months", active_client_months_cols, active_client_months_vals, active_client_months_callback_function_string);
     }
     
    //End insert  active_client_months Data ===============

    
    //Start update  active_client_months Data ===============

    function update_active_client_months(active_client_months_update_str, active_client_months_where_str, active_client_months_callback_function_string){
    
		mosyajax_update("active_client_months", active_client_months_update_str, active_client_months_where_str, active_client_months_callback_function_string)
    
    }
    //end  update  active_client_months Data ===============

	//Start drop  active_client_months Data ===============
    function active_client_months_drop(active_client_months_where_str, active_client_months_callback_function_string)
    {
        mosyajax_drop("active_client_months", active_client_months_where_str, active_client_months_callback_function_string)

    }
	//End drop  active_client_months Data ===============
    
    function initialize_active_client_months(qstr, active_client_months_callback_function_string)
    {
      var active_client_months_token_query =qstr;
      if(qstr=="")
      {
       var active_client_months_token_query_param="";
       var active_client_months_js_uptoken=mosy_get_param("active_client_months_uptoken");
       
       if(active_client_months_js_uptoken!==undefined)
       {
        active_client_months_token_query_param = atob(active_client_months_js_uptoken);
       }
        active_client_months_token_query = " where primkey='"+(active_client_months_token_query_param)+"'";
      }
      
      var active_client_months_push_ui_data_to =active_client_months_callback_function_string;
      if(active_client_months_callback_function_string=="")
      {
      active_client_months_push_ui_data_to = "add_active_client_months_ui_data";
      }
                
      console.log(active_client_months_token_query+" -- "+active_client_months_js_uptoken);

	  //alert(active_client_months_push_ui_data_to);

     get_active_client_months("*", active_client_months_token_query, "primkey", "blackhole", active_client_months_push_ui_data_to, "");
    }
    
    function add_active_client_months_ui_data(active_client_months_server_resp) 
    {
    var json_decoded_str=JSON.parse(active_client_months_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load active_client_months data on the fly ==============
    
	var gft_active_client_months_str="(arrid LIKE '%{{qactive_client_months}}%' OR  client_id LIKE '%{{qactive_client_months}}%' OR  month_year LIKE '%{{qactive_client_months}}%' OR  reamark LIKE '%{{qactive_client_months}}%' OR  status LIKE '%{{qactive_client_months}}%')";
    
    function  gft_active_client_months(qactive_client_months_str)
    {
        	var clean_active_client_months_filter_str=gft_active_client_months_str.replace(/{{qactive_client_months}}/g, magic_clean_str(qactive_client_months_str));
            
            return  clean_active_client_months_filter_str;

    }
    
    function load_active_client_months(active_client_months_qstr, active_client_months_where_str, active_client_months_ret_cols, active_client_months_user_function, active_client_months_result_function, active_client_months_data_tray)
    {
    
    var factive_client_months_result_function="push_result";
      
    if(active_client_months_result_function!="")
    {
          var factive_client_months_result_function=active_client_months_result_function;

    }
    	var clean_active_client_months_filter_str=gft_active_client_months_str.replace(/{{qactive_client_months}}/g, magic_clean_str(active_client_months_qstr));
        
        var factive_client_months_where_str=" where "+clean_active_client_months_filter_str;

    if(active_client_months_where_str!="")
    {
          var factive_client_months_where_str=" "+active_client_months_where_str;

    }
       
      get_active_client_months("*", factive_client_months_where_str, active_client_months_ret_cols, active_client_months_user_function, factive_client_months_result_function, active_client_months_data_tray);
      
    }
    ///=============== load active_client_months data on the fly ==============

   

    //Start get  address_book Data ===============
    
      function get_address_book(address_book_colstr, address_book_filter_col, address_book_cols, address_book_node_function_name, address_book_callback_function_string, address_book_ui_tag)
      {
        mosyflex_sel("address_book", address_book_colstr, address_book_filter_col , address_book_cols, address_book_node_function_name, address_book_callback_function_string, address_book_ui_tag);
        
      }
    //End get  address_book Data ===============

    //Start insert  address_book Data ===============

	function add_address_book(address_book_cols, address_book_vals, address_book_callback_function_string)
    {
		
        mosyajax_create_data("address_book", address_book_cols, address_book_vals, address_book_callback_function_string);
     }
     
    //End insert  address_book Data ===============

    
    //Start update  address_book Data ===============

    function update_address_book(address_book_update_str, address_book_where_str, address_book_callback_function_string){
    
		mosyajax_update("address_book", address_book_update_str, address_book_where_str, address_book_callback_function_string)
    
    }
    //end  update  address_book Data ===============

	//Start drop  address_book Data ===============
    function address_book_drop(address_book_where_str, address_book_callback_function_string)
    {
        mosyajax_drop("address_book", address_book_where_str, address_book_callback_function_string)

    }
	//End drop  address_book Data ===============
    
    function initialize_address_book(qstr, address_book_callback_function_string)
    {
      var address_book_token_query =qstr;
      if(qstr=="")
      {
       var address_book_token_query_param="";
       var address_book_js_uptoken=mosy_get_param("address_book_uptoken");
       
       if(address_book_js_uptoken!==undefined)
       {
        address_book_token_query_param = atob(address_book_js_uptoken);
       }
        address_book_token_query = " where primkey='"+(address_book_token_query_param)+"'";
      }
      
      var address_book_push_ui_data_to =address_book_callback_function_string;
      if(address_book_callback_function_string=="")
      {
      address_book_push_ui_data_to = "add_address_book_ui_data";
      }
                
      console.log(address_book_token_query+" -- "+address_book_js_uptoken);

	  //alert(address_book_push_ui_data_to);

     get_address_book("*", address_book_token_query, "primkey", "blackhole", address_book_push_ui_data_to, "");
    }
    
    function add_address_book_ui_data(address_book_server_resp) 
    {
    var json_decoded_str=JSON.parse(address_book_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load address_book data on the fly ==============
    
	var gft_address_book_str="(contact_id LIKE '%{{qaddress_book}}%' OR  address LIKE '%{{qaddress_book}}%' OR  type LIKE '%{{qaddress_book}}%' OR  comment LIKE '%{{qaddress_book}}%')";
    
    function  gft_address_book(qaddress_book_str)
    {
        	var clean_address_book_filter_str=gft_address_book_str.replace(/{{qaddress_book}}/g, magic_clean_str(qaddress_book_str));
            
            return  clean_address_book_filter_str;

    }
    
    function load_address_book(address_book_qstr, address_book_where_str, address_book_ret_cols, address_book_user_function, address_book_result_function, address_book_data_tray)
    {
    
    var faddress_book_result_function="push_result";
      
    if(address_book_result_function!="")
    {
          var faddress_book_result_function=address_book_result_function;

    }
    	var clean_address_book_filter_str=gft_address_book_str.replace(/{{qaddress_book}}/g, magic_clean_str(address_book_qstr));
        
        var faddress_book_where_str=" where "+clean_address_book_filter_str;

    if(address_book_where_str!="")
    {
          var faddress_book_where_str=" "+address_book_where_str;

    }
       
      get_address_book("*", faddress_book_where_str, address_book_ret_cols, address_book_user_function, faddress_book_result_function, address_book_data_tray);
      
    }
    ///=============== load address_book data on the fly ==============

   

    //Start get  admin Data ===============
    
      function get_admin(admin_colstr, admin_filter_col, admin_cols, admin_node_function_name, admin_callback_function_string, admin_ui_tag)
      {
        mosyflex_sel("admin", admin_colstr, admin_filter_col , admin_cols, admin_node_function_name, admin_callback_function_string, admin_ui_tag);
        
      }
    //End get  admin Data ===============

    //Start insert  admin Data ===============

	function add_admin(admin_cols, admin_vals, admin_callback_function_string)
    {
		
        mosyajax_create_data("admin", admin_cols, admin_vals, admin_callback_function_string);
     }
     
    //End insert  admin Data ===============

    
    //Start update  admin Data ===============

    function update_admin(admin_update_str, admin_where_str, admin_callback_function_string){
    
		mosyajax_update("admin", admin_update_str, admin_where_str, admin_callback_function_string)
    
    }
    //end  update  admin Data ===============

	//Start drop  admin Data ===============
    function admin_drop(admin_where_str, admin_callback_function_string)
    {
        mosyajax_drop("admin", admin_where_str, admin_callback_function_string)

    }
	//End drop  admin Data ===============
    
    function initialize_admin(qstr, admin_callback_function_string)
    {
      var admin_token_query =qstr;
      if(qstr=="")
      {
       var admin_token_query_param="";
       var admin_js_uptoken=mosy_get_param("admin_uptoken");
       
       if(admin_js_uptoken!==undefined)
       {
        admin_token_query_param = atob(admin_js_uptoken);
       }
        admin_token_query = " where primkey='"+(admin_token_query_param)+"'";
      }
      
      var admin_push_ui_data_to =admin_callback_function_string;
      if(admin_callback_function_string=="")
      {
      admin_push_ui_data_to = "add_admin_ui_data";
      }
                
      console.log(admin_token_query+" -- "+admin_js_uptoken);

	  //alert(admin_push_ui_data_to);

     get_admin("*", admin_token_query, "primkey", "blackhole", admin_push_ui_data_to, "");
    }
    
    function add_admin_ui_data(admin_server_resp) 
    {
    var json_decoded_str=JSON.parse(admin_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load admin data on the fly ==============
    
	var gft_admin_str="(admin_id LIKE '%{{qadmin}}%' OR  names LIKE '%{{qadmin}}%' OR  username LIKE '%{{qadmin}}%' OR  password LIKE '%{{qadmin}}%' OR  role LIKE '%{{qadmin}}%' OR  last_seen LIKE '%{{qadmin}}%' OR  telephone LIKE '%{{qadmin}}%' OR  photo LIKE '%{{qadmin}}%')";
    
    function  gft_admin(qadmin_str)
    {
        	var clean_admin_filter_str=gft_admin_str.replace(/{{qadmin}}/g, magic_clean_str(qadmin_str));
            
            return  clean_admin_filter_str;

    }
    
    function load_admin(admin_qstr, admin_where_str, admin_ret_cols, admin_user_function, admin_result_function, admin_data_tray)
    {
    
    var fadmin_result_function="push_result";
      
    if(admin_result_function!="")
    {
          var fadmin_result_function=admin_result_function;

    }
    	var clean_admin_filter_str=gft_admin_str.replace(/{{qadmin}}/g, magic_clean_str(admin_qstr));
        
        var fadmin_where_str=" where "+clean_admin_filter_str;

    if(admin_where_str!="")
    {
          var fadmin_where_str=" "+admin_where_str;

    }
       
      get_admin("*", fadmin_where_str, admin_ret_cols, admin_user_function, fadmin_result_function, admin_data_tray);
      
    }
    ///=============== load admin data on the fly ==============

   

    //Start get  client_base Data ===============
    
      function get_client_base(client_base_colstr, client_base_filter_col, client_base_cols, client_base_node_function_name, client_base_callback_function_string, client_base_ui_tag)
      {
        mosyflex_sel("client_base", client_base_colstr, client_base_filter_col , client_base_cols, client_base_node_function_name, client_base_callback_function_string, client_base_ui_tag);
        
      }
    //End get  client_base Data ===============

    //Start insert  client_base Data ===============

	function add_client_base(client_base_cols, client_base_vals, client_base_callback_function_string)
    {
		
        mosyajax_create_data("client_base", client_base_cols, client_base_vals, client_base_callback_function_string);
     }
     
    //End insert  client_base Data ===============

    
    //Start update  client_base Data ===============

    function update_client_base(client_base_update_str, client_base_where_str, client_base_callback_function_string){
    
		mosyajax_update("client_base", client_base_update_str, client_base_where_str, client_base_callback_function_string)
    
    }
    //end  update  client_base Data ===============

	//Start drop  client_base Data ===============
    function client_base_drop(client_base_where_str, client_base_callback_function_string)
    {
        mosyajax_drop("client_base", client_base_where_str, client_base_callback_function_string)

    }
	//End drop  client_base Data ===============
    
    function initialize_client_base(qstr, client_base_callback_function_string)
    {
      var client_base_token_query =qstr;
      if(qstr=="")
      {
       var client_base_token_query_param="";
       var client_base_js_uptoken=mosy_get_param("client_base_uptoken");
       
       if(client_base_js_uptoken!==undefined)
       {
        client_base_token_query_param = atob(client_base_js_uptoken);
       }
        client_base_token_query = " where primkey='"+(client_base_token_query_param)+"'";
      }
      
      var client_base_push_ui_data_to =client_base_callback_function_string;
      if(client_base_callback_function_string=="")
      {
      client_base_push_ui_data_to = "add_client_base_ui_data";
      }
                
      console.log(client_base_token_query+" -- "+client_base_js_uptoken);

	  //alert(client_base_push_ui_data_to);

     get_client_base("*", client_base_token_query, "primkey", "blackhole", client_base_push_ui_data_to, "");
    }
    
    function add_client_base_ui_data(client_base_server_resp) 
    {
    var json_decoded_str=JSON.parse(client_base_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load client_base data on the fly ==============
    
	var gft_client_base_str="(client_id LIKE '%{{qclient_base}}%' OR  client_name LIKE '%{{qclient_base}}%' OR  gender LIKE '%{{qclient_base}}%' OR  client_tel LIKE '%{{qclient_base}}%' OR  client_email LIKE '%{{qclient_base}}%' OR  city LIKE '%{{qclient_base}}%' OR  location LIKE '%{{qclient_base}}%' OR  building_no LIKE '%{{qclient_base}}%' OR  floor_no LIKE '%{{qclient_base}}%' OR  room_no LIKE '%{{qclient_base}}%' OR  package LIKE '%{{qclient_base}}%' OR  package_price LIKE '%{{qclient_base}}%' OR  photo LIKE '%{{qclient_base}}%' OR  installation_date LIKE '%{{qclient_base}}%' OR  signed_by LIKE '%{{qclient_base}}%' OR  comment LIKE '%{{qclient_base}}%' OR  ip_address LIKE '%{{qclient_base}}%' OR  account_status LIKE '%{{qclient_base}}%' OR  admin_id LIKE '%{{qclient_base}}%' OR  instdate LIKE '%{{qclient_base}}%' OR  vcf_exported LIKE '%{{qclient_base}}%' OR  expiry_date LIKE '%{{qclient_base}}%')";
    
    function  gft_client_base(qclient_base_str)
    {
        	var clean_client_base_filter_str=gft_client_base_str.replace(/{{qclient_base}}/g, magic_clean_str(qclient_base_str));
            
            return  clean_client_base_filter_str;

    }
    
    function load_client_base(client_base_qstr, client_base_where_str, client_base_ret_cols, client_base_user_function, client_base_result_function, client_base_data_tray)
    {
    
    var fclient_base_result_function="push_result";
      
    if(client_base_result_function!="")
    {
          var fclient_base_result_function=client_base_result_function;

    }
    	var clean_client_base_filter_str=gft_client_base_str.replace(/{{qclient_base}}/g, magic_clean_str(client_base_qstr));
        
        var fclient_base_where_str=" where "+clean_client_base_filter_str;

    if(client_base_where_str!="")
    {
          var fclient_base_where_str=" "+client_base_where_str;

    }
       
      get_client_base("*", fclient_base_where_str, client_base_ret_cols, client_base_user_function, fclient_base_result_function, client_base_data_tray);
      
    }
    ///=============== load client_base data on the fly ==============

   

    //Start get  client_charges Data ===============
    
      function get_client_charges(client_charges_colstr, client_charges_filter_col, client_charges_cols, client_charges_node_function_name, client_charges_callback_function_string, client_charges_ui_tag)
      {
        mosyflex_sel("client_charges", client_charges_colstr, client_charges_filter_col , client_charges_cols, client_charges_node_function_name, client_charges_callback_function_string, client_charges_ui_tag);
        
      }
    //End get  client_charges Data ===============

    //Start insert  client_charges Data ===============

	function add_client_charges(client_charges_cols, client_charges_vals, client_charges_callback_function_string)
    {
		
        mosyajax_create_data("client_charges", client_charges_cols, client_charges_vals, client_charges_callback_function_string);
     }
     
    //End insert  client_charges Data ===============

    
    //Start update  client_charges Data ===============

    function update_client_charges(client_charges_update_str, client_charges_where_str, client_charges_callback_function_string){
    
		mosyajax_update("client_charges", client_charges_update_str, client_charges_where_str, client_charges_callback_function_string)
    
    }
    //end  update  client_charges Data ===============

	//Start drop  client_charges Data ===============
    function client_charges_drop(client_charges_where_str, client_charges_callback_function_string)
    {
        mosyajax_drop("client_charges", client_charges_where_str, client_charges_callback_function_string)

    }
	//End drop  client_charges Data ===============
    
    function initialize_client_charges(qstr, client_charges_callback_function_string)
    {
      var client_charges_token_query =qstr;
      if(qstr=="")
      {
       var client_charges_token_query_param="";
       var client_charges_js_uptoken=mosy_get_param("client_charges_uptoken");
       
       if(client_charges_js_uptoken!==undefined)
       {
        client_charges_token_query_param = atob(client_charges_js_uptoken);
       }
        client_charges_token_query = " where primkey='"+(client_charges_token_query_param)+"'";
      }
      
      var client_charges_push_ui_data_to =client_charges_callback_function_string;
      if(client_charges_callback_function_string=="")
      {
      client_charges_push_ui_data_to = "add_client_charges_ui_data";
      }
                
      console.log(client_charges_token_query+" -- "+client_charges_js_uptoken);

	  //alert(client_charges_push_ui_data_to);

     get_client_charges("*", client_charges_token_query, "primkey", "blackhole", client_charges_push_ui_data_to, "");
    }
    
    function add_client_charges_ui_data(client_charges_server_resp) 
    {
    var json_decoded_str=JSON.parse(client_charges_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load client_charges data on the fly ==============
    
	var gft_client_charges_str="(charge_id LIKE '%{{qclient_charges}}%' OR  client_id LIKE '%{{qclient_charges}}%' OR  package_id LIKE '%{{qclient_charges}}%' OR  trx_id LIKE '%{{qclient_charges}}%' OR  amount LIKE '%{{qclient_charges}}%' OR  balance LIKE '%{{qclient_charges}}%' OR  remark LIKE '%{{qclient_charges}}%' OR  qty LIKE '%{{qclient_charges}}%')";
    
    function  gft_client_charges(qclient_charges_str)
    {
        	var clean_client_charges_filter_str=gft_client_charges_str.replace(/{{qclient_charges}}/g, magic_clean_str(qclient_charges_str));
            
            return  clean_client_charges_filter_str;

    }
    
    function load_client_charges(client_charges_qstr, client_charges_where_str, client_charges_ret_cols, client_charges_user_function, client_charges_result_function, client_charges_data_tray)
    {
    
    var fclient_charges_result_function="push_result";
      
    if(client_charges_result_function!="")
    {
          var fclient_charges_result_function=client_charges_result_function;

    }
    	var clean_client_charges_filter_str=gft_client_charges_str.replace(/{{qclient_charges}}/g, magic_clean_str(client_charges_qstr));
        
        var fclient_charges_where_str=" where "+clean_client_charges_filter_str;

    if(client_charges_where_str!="")
    {
          var fclient_charges_where_str=" "+client_charges_where_str;

    }
       
      get_client_charges("*", fclient_charges_where_str, client_charges_ret_cols, client_charges_user_function, fclient_charges_result_function, client_charges_data_tray);
      
    }
    ///=============== load client_charges data on the fly ==============

   

    //Start get  dtclean Data ===============
    
      function get_dtclean(dtclean_colstr, dtclean_filter_col, dtclean_cols, dtclean_node_function_name, dtclean_callback_function_string, dtclean_ui_tag)
      {
        mosyflex_sel("dtclean", dtclean_colstr, dtclean_filter_col , dtclean_cols, dtclean_node_function_name, dtclean_callback_function_string, dtclean_ui_tag);
        
      }
    //End get  dtclean Data ===============

    //Start insert  dtclean Data ===============

	function add_dtclean(dtclean_cols, dtclean_vals, dtclean_callback_function_string)
    {
		
        mosyajax_create_data("dtclean", dtclean_cols, dtclean_vals, dtclean_callback_function_string);
     }
     
    //End insert  dtclean Data ===============

    
    //Start update  dtclean Data ===============

    function update_dtclean(dtclean_update_str, dtclean_where_str, dtclean_callback_function_string){
    
		mosyajax_update("dtclean", dtclean_update_str, dtclean_where_str, dtclean_callback_function_string)
    
    }
    //end  update  dtclean Data ===============

	//Start drop  dtclean Data ===============
    function dtclean_drop(dtclean_where_str, dtclean_callback_function_string)
    {
        mosyajax_drop("dtclean", dtclean_where_str, dtclean_callback_function_string)

    }
	//End drop  dtclean Data ===============
    
    function initialize_dtclean(qstr, dtclean_callback_function_string)
    {
      var dtclean_token_query =qstr;
      if(qstr=="")
      {
       var dtclean_token_query_param="";
       var dtclean_js_uptoken=mosy_get_param("dtclean_uptoken");
       
       if(dtclean_js_uptoken!==undefined)
       {
        dtclean_token_query_param = atob(dtclean_js_uptoken);
       }
        dtclean_token_query = " where primkey='"+(dtclean_token_query_param)+"'";
      }
      
      var dtclean_push_ui_data_to =dtclean_callback_function_string;
      if(dtclean_callback_function_string=="")
      {
      dtclean_push_ui_data_to = "add_dtclean_ui_data";
      }
                
      console.log(dtclean_token_query+" -- "+dtclean_js_uptoken);

	  //alert(dtclean_push_ui_data_to);

     get_dtclean("*", dtclean_token_query, "primkey", "blackhole", dtclean_push_ui_data_to, "");
    }
    
    function add_dtclean_ui_data(dtclean_server_resp) 
    {
    var json_decoded_str=JSON.parse(dtclean_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load dtclean data on the fly ==============
    
	var gft_dtclean_str="(building_no LIKE '%{{qdtclean}}%' OR  client_name LIKE '%{{qdtclean}}%' OR  room_no LIKE '%{{qdtclean}}%' OR  package LIKE '%{{qdtclean}}%' OR  package_amt LIKE '%{{qdtclean}}%' OR  insta_date LIKE '%{{qdtclean}}%')";
    
    function  gft_dtclean(qdtclean_str)
    {
        	var clean_dtclean_filter_str=gft_dtclean_str.replace(/{{qdtclean}}/g, magic_clean_str(qdtclean_str));
            
            return  clean_dtclean_filter_str;

    }
    
    function load_dtclean(dtclean_qstr, dtclean_where_str, dtclean_ret_cols, dtclean_user_function, dtclean_result_function, dtclean_data_tray)
    {
    
    var fdtclean_result_function="push_result";
      
    if(dtclean_result_function!="")
    {
          var fdtclean_result_function=dtclean_result_function;

    }
    	var clean_dtclean_filter_str=gft_dtclean_str.replace(/{{qdtclean}}/g, magic_clean_str(dtclean_qstr));
        
        var fdtclean_where_str=" where "+clean_dtclean_filter_str;

    if(dtclean_where_str!="")
    {
          var fdtclean_where_str=" "+dtclean_where_str;

    }
       
      get_dtclean("*", fdtclean_where_str, dtclean_ret_cols, dtclean_user_function, fdtclean_result_function, dtclean_data_tray);
      
    }
    ///=============== load dtclean data on the fly ==============

   

    //Start get  expenses Data ===============
    
      function get_expenses(expenses_colstr, expenses_filter_col, expenses_cols, expenses_node_function_name, expenses_callback_function_string, expenses_ui_tag)
      {
        mosyflex_sel("expenses", expenses_colstr, expenses_filter_col , expenses_cols, expenses_node_function_name, expenses_callback_function_string, expenses_ui_tag);
        
      }
    //End get  expenses Data ===============

    //Start insert  expenses Data ===============

	function add_expenses(expenses_cols, expenses_vals, expenses_callback_function_string)
    {
		
        mosyajax_create_data("expenses", expenses_cols, expenses_vals, expenses_callback_function_string);
     }
     
    //End insert  expenses Data ===============

    
    //Start update  expenses Data ===============

    function update_expenses(expenses_update_str, expenses_where_str, expenses_callback_function_string){
    
		mosyajax_update("expenses", expenses_update_str, expenses_where_str, expenses_callback_function_string)
    
    }
    //end  update  expenses Data ===============

	//Start drop  expenses Data ===============
    function expenses_drop(expenses_where_str, expenses_callback_function_string)
    {
        mosyajax_drop("expenses", expenses_where_str, expenses_callback_function_string)

    }
	//End drop  expenses Data ===============
    
    function initialize_expenses(qstr, expenses_callback_function_string)
    {
      var expenses_token_query =qstr;
      if(qstr=="")
      {
       var expenses_token_query_param="";
       var expenses_js_uptoken=mosy_get_param("expenses_uptoken");
       
       if(expenses_js_uptoken!==undefined)
       {
        expenses_token_query_param = atob(expenses_js_uptoken);
       }
        expenses_token_query = " where primkey='"+(expenses_token_query_param)+"'";
      }
      
      var expenses_push_ui_data_to =expenses_callback_function_string;
      if(expenses_callback_function_string=="")
      {
      expenses_push_ui_data_to = "add_expenses_ui_data";
      }
                
      console.log(expenses_token_query+" -- "+expenses_js_uptoken);

	  //alert(expenses_push_ui_data_to);

     get_expenses("*", expenses_token_query, "primkey", "blackhole", expenses_push_ui_data_to, "");
    }
    
    function add_expenses_ui_data(expenses_server_resp) 
    {
    var json_decoded_str=JSON.parse(expenses_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load expenses data on the fly ==============
    
	var gft_expenses_str="(transaction_id LIKE '%{{qexpenses}}%' OR  transaction_ref LIKE '%{{qexpenses}}%' OR  amount_paid LIKE '%{{qexpenses}}%' OR  transaction_type LIKE '%{{qexpenses}}%' OR  transaction_date LIKE '%{{qexpenses}}%' OR  month_year LIKE '%{{qexpenses}}%' OR  client_id LIKE '%{{qexpenses}}%' OR  received_by LIKE '%{{qexpenses}}%' OR  confirmed_by LIKE '%{{qexpenses}}%' OR  remark LIKE '%{{qexpenses}}%' OR  admin_id LIKE '%{{qexpenses}}%' OR  payment_mode LIKE '%{{qexpenses}}%')";
    
    function  gft_expenses(qexpenses_str)
    {
        	var clean_expenses_filter_str=gft_expenses_str.replace(/{{qexpenses}}/g, magic_clean_str(qexpenses_str));
            
            return  clean_expenses_filter_str;

    }
    
    function load_expenses(expenses_qstr, expenses_where_str, expenses_ret_cols, expenses_user_function, expenses_result_function, expenses_data_tray)
    {
    
    var fexpenses_result_function="push_result";
      
    if(expenses_result_function!="")
    {
          var fexpenses_result_function=expenses_result_function;

    }
    	var clean_expenses_filter_str=gft_expenses_str.replace(/{{qexpenses}}/g, magic_clean_str(expenses_qstr));
        
        var fexpenses_where_str=" where "+clean_expenses_filter_str;

    if(expenses_where_str!="")
    {
          var fexpenses_where_str=" "+expenses_where_str;

    }
       
      get_expenses("*", fexpenses_where_str, expenses_ret_cols, expenses_user_function, fexpenses_result_function, expenses_data_tray);
      
    }
    ///=============== load expenses data on the fly ==============

   

    //Start get  files_and_photos Data ===============
    
      function get_files_and_photos(files_and_photos_colstr, files_and_photos_filter_col, files_and_photos_cols, files_and_photos_node_function_name, files_and_photos_callback_function_string, files_and_photos_ui_tag)
      {
        mosyflex_sel("files_and_photos", files_and_photos_colstr, files_and_photos_filter_col , files_and_photos_cols, files_and_photos_node_function_name, files_and_photos_callback_function_string, files_and_photos_ui_tag);
        
      }
    //End get  files_and_photos Data ===============

    //Start insert  files_and_photos Data ===============

	function add_files_and_photos(files_and_photos_cols, files_and_photos_vals, files_and_photos_callback_function_string)
    {
		
        mosyajax_create_data("files_and_photos", files_and_photos_cols, files_and_photos_vals, files_and_photos_callback_function_string);
     }
     
    //End insert  files_and_photos Data ===============

    
    //Start update  files_and_photos Data ===============

    function update_files_and_photos(files_and_photos_update_str, files_and_photos_where_str, files_and_photos_callback_function_string){
    
		mosyajax_update("files_and_photos", files_and_photos_update_str, files_and_photos_where_str, files_and_photos_callback_function_string)
    
    }
    //end  update  files_and_photos Data ===============

	//Start drop  files_and_photos Data ===============
    function files_and_photos_drop(files_and_photos_where_str, files_and_photos_callback_function_string)
    {
        mosyajax_drop("files_and_photos", files_and_photos_where_str, files_and_photos_callback_function_string)

    }
	//End drop  files_and_photos Data ===============
    
    function initialize_files_and_photos(qstr, files_and_photos_callback_function_string)
    {
      var files_and_photos_token_query =qstr;
      if(qstr=="")
      {
       var files_and_photos_token_query_param="";
       var files_and_photos_js_uptoken=mosy_get_param("files_and_photos_uptoken");
       
       if(files_and_photos_js_uptoken!==undefined)
       {
        files_and_photos_token_query_param = atob(files_and_photos_js_uptoken);
       }
        files_and_photos_token_query = " where primkey='"+(files_and_photos_token_query_param)+"'";
      }
      
      var files_and_photos_push_ui_data_to =files_and_photos_callback_function_string;
      if(files_and_photos_callback_function_string=="")
      {
      files_and_photos_push_ui_data_to = "add_files_and_photos_ui_data";
      }
                
      console.log(files_and_photos_token_query+" -- "+files_and_photos_js_uptoken);

	  //alert(files_and_photos_push_ui_data_to);

     get_files_and_photos("*", files_and_photos_token_query, "primkey", "blackhole", files_and_photos_push_ui_data_to, "");
    }
    
    function add_files_and_photos_ui_data(files_and_photos_server_resp) 
    {
    var json_decoded_str=JSON.parse(files_and_photos_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load files_and_photos data on the fly ==============
    
	var gft_files_and_photos_str="(file_id LIKE '%{{qfiles_and_photos}}%' OR  file_path LIKE '%{{qfiles_and_photos}}%' OR  admin_id LIKE '%{{qfiles_and_photos}}%')";
    
    function  gft_files_and_photos(qfiles_and_photos_str)
    {
        	var clean_files_and_photos_filter_str=gft_files_and_photos_str.replace(/{{qfiles_and_photos}}/g, magic_clean_str(qfiles_and_photos_str));
            
            return  clean_files_and_photos_filter_str;

    }
    
    function load_files_and_photos(files_and_photos_qstr, files_and_photos_where_str, files_and_photos_ret_cols, files_and_photos_user_function, files_and_photos_result_function, files_and_photos_data_tray)
    {
    
    var ffiles_and_photos_result_function="push_result";
      
    if(files_and_photos_result_function!="")
    {
          var ffiles_and_photos_result_function=files_and_photos_result_function;

    }
    	var clean_files_and_photos_filter_str=gft_files_and_photos_str.replace(/{{qfiles_and_photos}}/g, magic_clean_str(files_and_photos_qstr));
        
        var ffiles_and_photos_where_str=" where "+clean_files_and_photos_filter_str;

    if(files_and_photos_where_str!="")
    {
          var ffiles_and_photos_where_str=" "+files_and_photos_where_str;

    }
       
      get_files_and_photos("*", ffiles_and_photos_where_str, files_and_photos_ret_cols, files_and_photos_user_function, ffiles_and_photos_result_function, files_and_photos_data_tray);
      
    }
    ///=============== load files_and_photos data on the fly ==============

   

    //Start get  inventory Data ===============
    
      function get_inventory(inventory_colstr, inventory_filter_col, inventory_cols, inventory_node_function_name, inventory_callback_function_string, inventory_ui_tag)
      {
        mosyflex_sel("inventory", inventory_colstr, inventory_filter_col , inventory_cols, inventory_node_function_name, inventory_callback_function_string, inventory_ui_tag);
        
      }
    //End get  inventory Data ===============

    //Start insert  inventory Data ===============

	function add_inventory(inventory_cols, inventory_vals, inventory_callback_function_string)
    {
		
        mosyajax_create_data("inventory", inventory_cols, inventory_vals, inventory_callback_function_string);
     }
     
    //End insert  inventory Data ===============

    
    //Start update  inventory Data ===============

    function update_inventory(inventory_update_str, inventory_where_str, inventory_callback_function_string){
    
		mosyajax_update("inventory", inventory_update_str, inventory_where_str, inventory_callback_function_string)
    
    }
    //end  update  inventory Data ===============

	//Start drop  inventory Data ===============
    function inventory_drop(inventory_where_str, inventory_callback_function_string)
    {
        mosyajax_drop("inventory", inventory_where_str, inventory_callback_function_string)

    }
	//End drop  inventory Data ===============
    
    function initialize_inventory(qstr, inventory_callback_function_string)
    {
      var inventory_token_query =qstr;
      if(qstr=="")
      {
       var inventory_token_query_param="";
       var inventory_js_uptoken=mosy_get_param("inventory_uptoken");
       
       if(inventory_js_uptoken!==undefined)
       {
        inventory_token_query_param = atob(inventory_js_uptoken);
       }
        inventory_token_query = " where primkey='"+(inventory_token_query_param)+"'";
      }
      
      var inventory_push_ui_data_to =inventory_callback_function_string;
      if(inventory_callback_function_string=="")
      {
      inventory_push_ui_data_to = "add_inventory_ui_data";
      }
                
      console.log(inventory_token_query+" -- "+inventory_js_uptoken);

	  //alert(inventory_push_ui_data_to);

     get_inventory("*", inventory_token_query, "primkey", "blackhole", inventory_push_ui_data_to, "");
    }
    
    function add_inventory_ui_data(inventory_server_resp) 
    {
    var json_decoded_str=JSON.parse(inventory_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load inventory data on the fly ==============
    
	var gft_inventory_str="(item_id LIKE '%{{qinventory}}%' OR  item_name LIKE '%{{qinventory}}%' OR  buying_price LIKE '%{{qinventory}}%' OR  description LIKE '%{{qinventory}}%' OR  selling_price LIKE '%{{qinventory}}%')";
    
    function  gft_inventory(qinventory_str)
    {
        	var clean_inventory_filter_str=gft_inventory_str.replace(/{{qinventory}}/g, magic_clean_str(qinventory_str));
            
            return  clean_inventory_filter_str;

    }
    
    function load_inventory(inventory_qstr, inventory_where_str, inventory_ret_cols, inventory_user_function, inventory_result_function, inventory_data_tray)
    {
    
    var finventory_result_function="push_result";
      
    if(inventory_result_function!="")
    {
          var finventory_result_function=inventory_result_function;

    }
    	var clean_inventory_filter_str=gft_inventory_str.replace(/{{qinventory}}/g, magic_clean_str(inventory_qstr));
        
        var finventory_where_str=" where "+clean_inventory_filter_str;

    if(inventory_where_str!="")
    {
          var finventory_where_str=" "+inventory_where_str;

    }
       
      get_inventory("*", finventory_where_str, inventory_ret_cols, inventory_user_function, finventory_result_function, inventory_data_tray);
      
    }
    ///=============== load inventory data on the fly ==============

   

    //Start get  message_board Data ===============
    
      function get_message_board(message_board_colstr, message_board_filter_col, message_board_cols, message_board_node_function_name, message_board_callback_function_string, message_board_ui_tag)
      {
        mosyflex_sel("message_board", message_board_colstr, message_board_filter_col , message_board_cols, message_board_node_function_name, message_board_callback_function_string, message_board_ui_tag);
        
      }
    //End get  message_board Data ===============

    //Start insert  message_board Data ===============

	function add_message_board(message_board_cols, message_board_vals, message_board_callback_function_string)
    {
		
        mosyajax_create_data("message_board", message_board_cols, message_board_vals, message_board_callback_function_string);
     }
     
    //End insert  message_board Data ===============

    
    //Start update  message_board Data ===============

    function update_message_board(message_board_update_str, message_board_where_str, message_board_callback_function_string){
    
		mosyajax_update("message_board", message_board_update_str, message_board_where_str, message_board_callback_function_string)
    
    }
    //end  update  message_board Data ===============

	//Start drop  message_board Data ===============
    function message_board_drop(message_board_where_str, message_board_callback_function_string)
    {
        mosyajax_drop("message_board", message_board_where_str, message_board_callback_function_string)

    }
	//End drop  message_board Data ===============
    
    function initialize_message_board(qstr, message_board_callback_function_string)
    {
      var message_board_token_query =qstr;
      if(qstr=="")
      {
       var message_board_token_query_param="";
       var message_board_js_uptoken=mosy_get_param("message_board_uptoken");
       
       if(message_board_js_uptoken!==undefined)
       {
        message_board_token_query_param = atob(message_board_js_uptoken);
       }
        message_board_token_query = " where primkey='"+(message_board_token_query_param)+"'";
      }
      
      var message_board_push_ui_data_to =message_board_callback_function_string;
      if(message_board_callback_function_string=="")
      {
      message_board_push_ui_data_to = "add_message_board_ui_data";
      }
                
      console.log(message_board_token_query+" -- "+message_board_js_uptoken);

	  //alert(message_board_push_ui_data_to);

     get_message_board("*", message_board_token_query, "primkey", "blackhole", message_board_push_ui_data_to, "");
    }
    
    function add_message_board_ui_data(message_board_server_resp) 
    {
    var json_decoded_str=JSON.parse(message_board_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load message_board data on the fly ==============
    
	var gft_message_board_str="(message_id LIKE '%{{qmessage_board}}%' OR  from LIKE '%{{qmessage_board}}%' OR  to LIKE '%{{qmessage_board}}%' OR  msg_date LIKE '%{{qmessage_board}}%' OR  admin LIKE '%{{qmessage_board}}%' OR  read LIKE '%{{qmessage_board}}%' OR  message LIKE '%{{qmessage_board}}%' OR  msg_type LIKE '%{{qmessage_board}}%' OR  subject LIKE '%{{qmessage_board}}%')";
    
    function  gft_message_board(qmessage_board_str)
    {
        	var clean_message_board_filter_str=gft_message_board_str.replace(/{{qmessage_board}}/g, magic_clean_str(qmessage_board_str));
            
            return  clean_message_board_filter_str;

    }
    
    function load_message_board(message_board_qstr, message_board_where_str, message_board_ret_cols, message_board_user_function, message_board_result_function, message_board_data_tray)
    {
    
    var fmessage_board_result_function="push_result";
      
    if(message_board_result_function!="")
    {
          var fmessage_board_result_function=message_board_result_function;

    }
    	var clean_message_board_filter_str=gft_message_board_str.replace(/{{qmessage_board}}/g, magic_clean_str(message_board_qstr));
        
        var fmessage_board_where_str=" where "+clean_message_board_filter_str;

    if(message_board_where_str!="")
    {
          var fmessage_board_where_str=" "+message_board_where_str;

    }
       
      get_message_board("*", fmessage_board_where_str, message_board_ret_cols, message_board_user_function, fmessage_board_result_function, message_board_data_tray);
      
    }
    ///=============== load message_board data on the fly ==============

   

    //Start get  notes Data ===============
    
      function get_notes(notes_colstr, notes_filter_col, notes_cols, notes_node_function_name, notes_callback_function_string, notes_ui_tag)
      {
        mosyflex_sel("notes", notes_colstr, notes_filter_col , notes_cols, notes_node_function_name, notes_callback_function_string, notes_ui_tag);
        
      }
    //End get  notes Data ===============

    //Start insert  notes Data ===============

	function add_notes(notes_cols, notes_vals, notes_callback_function_string)
    {
		
        mosyajax_create_data("notes", notes_cols, notes_vals, notes_callback_function_string);
     }
     
    //End insert  notes Data ===============

    
    //Start update  notes Data ===============

    function update_notes(notes_update_str, notes_where_str, notes_callback_function_string){
    
		mosyajax_update("notes", notes_update_str, notes_where_str, notes_callback_function_string)
    
    }
    //end  update  notes Data ===============

	//Start drop  notes Data ===============
    function notes_drop(notes_where_str, notes_callback_function_string)
    {
        mosyajax_drop("notes", notes_where_str, notes_callback_function_string)

    }
	//End drop  notes Data ===============
    
    function initialize_notes(qstr, notes_callback_function_string)
    {
      var notes_token_query =qstr;
      if(qstr=="")
      {
       var notes_token_query_param="";
       var notes_js_uptoken=mosy_get_param("notes_uptoken");
       
       if(notes_js_uptoken!==undefined)
       {
        notes_token_query_param = atob(notes_js_uptoken);
       }
        notes_token_query = " where primkey='"+(notes_token_query_param)+"'";
      }
      
      var notes_push_ui_data_to =notes_callback_function_string;
      if(notes_callback_function_string=="")
      {
      notes_push_ui_data_to = "add_notes_ui_data";
      }
                
      console.log(notes_token_query+" -- "+notes_js_uptoken);

	  //alert(notes_push_ui_data_to);

     get_notes("*", notes_token_query, "primkey", "blackhole", notes_push_ui_data_to, "");
    }
    
    function add_notes_ui_data(notes_server_resp) 
    {
    var json_decoded_str=JSON.parse(notes_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load notes data on the fly ==============
    
	var gft_notes_str="(note_id LIKE '%{{qnotes}}%' OR  title LIKE '%{{qnotes}}%' OR  admin_id LIKE '%{{qnotes}}%' OR  note LIKE '%{{qnotes}}%' OR  note_date LIKE '%{{qnotes}}%' OR  note_tag LIKE '%{{qnotes}}%' OR  user_id LIKE '%{{qnotes}}%' OR  client_id LIKE '%{{qnotes}}%')";
    
    function  gft_notes(qnotes_str)
    {
        	var clean_notes_filter_str=gft_notes_str.replace(/{{qnotes}}/g, magic_clean_str(qnotes_str));
            
            return  clean_notes_filter_str;

    }
    
    function load_notes(notes_qstr, notes_where_str, notes_ret_cols, notes_user_function, notes_result_function, notes_data_tray)
    {
    
    var fnotes_result_function="push_result";
      
    if(notes_result_function!="")
    {
          var fnotes_result_function=notes_result_function;

    }
    	var clean_notes_filter_str=gft_notes_str.replace(/{{qnotes}}/g, magic_clean_str(notes_qstr));
        
        var fnotes_where_str=" where "+clean_notes_filter_str;

    if(notes_where_str!="")
    {
          var fnotes_where_str=" "+notes_where_str;

    }
       
      get_notes("*", fnotes_where_str, notes_ret_cols, notes_user_function, fnotes_result_function, notes_data_tray);
      
    }
    ///=============== load notes data on the fly ==============

   

    //Start get  packages Data ===============
    
      function get_packages(packages_colstr, packages_filter_col, packages_cols, packages_node_function_name, packages_callback_function_string, packages_ui_tag)
      {
        mosyflex_sel("packages", packages_colstr, packages_filter_col , packages_cols, packages_node_function_name, packages_callback_function_string, packages_ui_tag);
        
      }
    //End get  packages Data ===============

    //Start insert  packages Data ===============

	function add_packages(packages_cols, packages_vals, packages_callback_function_string)
    {
		
        mosyajax_create_data("packages", packages_cols, packages_vals, packages_callback_function_string);
     }
     
    //End insert  packages Data ===============

    
    //Start update  packages Data ===============

    function update_packages(packages_update_str, packages_where_str, packages_callback_function_string){
    
		mosyajax_update("packages", packages_update_str, packages_where_str, packages_callback_function_string)
    
    }
    //end  update  packages Data ===============

	//Start drop  packages Data ===============
    function packages_drop(packages_where_str, packages_callback_function_string)
    {
        mosyajax_drop("packages", packages_where_str, packages_callback_function_string)

    }
	//End drop  packages Data ===============
    
    function initialize_packages(qstr, packages_callback_function_string)
    {
      var packages_token_query =qstr;
      if(qstr=="")
      {
       var packages_token_query_param="";
       var packages_js_uptoken=mosy_get_param("packages_uptoken");
       
       if(packages_js_uptoken!==undefined)
       {
        packages_token_query_param = atob(packages_js_uptoken);
       }
        packages_token_query = " where primkey='"+(packages_token_query_param)+"'";
      }
      
      var packages_push_ui_data_to =packages_callback_function_string;
      if(packages_callback_function_string=="")
      {
      packages_push_ui_data_to = "add_packages_ui_data";
      }
                
      console.log(packages_token_query+" -- "+packages_js_uptoken);

	  //alert(packages_push_ui_data_to);

     get_packages("*", packages_token_query, "primkey", "blackhole", packages_push_ui_data_to, "");
    }
    
    function add_packages_ui_data(packages_server_resp) 
    {
    var json_decoded_str=JSON.parse(packages_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load packages data on the fly ==============
    
	var gft_packages_str="(package_id LIKE '%{{qpackages}}%' OR  package_name LIKE '%{{qpackages}}%' OR  price LIKE '%{{qpackages}}%' OR  description LIKE '%{{qpackages}}%' OR  admin_id LIKE '%{{qpackages}}%')";
    
    function  gft_packages(qpackages_str)
    {
        	var clean_packages_filter_str=gft_packages_str.replace(/{{qpackages}}/g, magic_clean_str(qpackages_str));
            
            return  clean_packages_filter_str;

    }
    
    function load_packages(packages_qstr, packages_where_str, packages_ret_cols, packages_user_function, packages_result_function, packages_data_tray)
    {
    
    var fpackages_result_function="push_result";
      
    if(packages_result_function!="")
    {
          var fpackages_result_function=packages_result_function;

    }
    	var clean_packages_filter_str=gft_packages_str.replace(/{{qpackages}}/g, magic_clean_str(packages_qstr));
        
        var fpackages_where_str=" where "+clean_packages_filter_str;

    if(packages_where_str!="")
    {
          var fpackages_where_str=" "+packages_where_str;

    }
       
      get_packages("*", fpackages_where_str, packages_ret_cols, packages_user_function, fpackages_result_function, packages_data_tray);
      
    }
    ///=============== load packages data on the fly ==============

   

    //Start get  sqlpro_themes Data ===============
    
      function get_sqlpro_themes(sqlpro_themes_colstr, sqlpro_themes_filter_col, sqlpro_themes_cols, sqlpro_themes_node_function_name, sqlpro_themes_callback_function_string, sqlpro_themes_ui_tag)
      {
        mosyflex_sel("sqlpro_themes", sqlpro_themes_colstr, sqlpro_themes_filter_col , sqlpro_themes_cols, sqlpro_themes_node_function_name, sqlpro_themes_callback_function_string, sqlpro_themes_ui_tag);
        
      }
    //End get  sqlpro_themes Data ===============

    //Start insert  sqlpro_themes Data ===============

	function add_sqlpro_themes(sqlpro_themes_cols, sqlpro_themes_vals, sqlpro_themes_callback_function_string)
    {
		
        mosyajax_create_data("sqlpro_themes", sqlpro_themes_cols, sqlpro_themes_vals, sqlpro_themes_callback_function_string);
     }
     
    //End insert  sqlpro_themes Data ===============

    
    //Start update  sqlpro_themes Data ===============

    function update_sqlpro_themes(sqlpro_themes_update_str, sqlpro_themes_where_str, sqlpro_themes_callback_function_string){
    
		mosyajax_update("sqlpro_themes", sqlpro_themes_update_str, sqlpro_themes_where_str, sqlpro_themes_callback_function_string)
    
    }
    //end  update  sqlpro_themes Data ===============

	//Start drop  sqlpro_themes Data ===============
    function sqlpro_themes_drop(sqlpro_themes_where_str, sqlpro_themes_callback_function_string)
    {
        mosyajax_drop("sqlpro_themes", sqlpro_themes_where_str, sqlpro_themes_callback_function_string)

    }
	//End drop  sqlpro_themes Data ===============
    
    function initialize_sqlpro_themes(qstr, sqlpro_themes_callback_function_string)
    {
      var sqlpro_themes_token_query =qstr;
      if(qstr=="")
      {
       var sqlpro_themes_token_query_param="";
       var sqlpro_themes_js_uptoken=mosy_get_param("sqlpro_themes_uptoken");
       
       if(sqlpro_themes_js_uptoken!==undefined)
       {
        sqlpro_themes_token_query_param = atob(sqlpro_themes_js_uptoken);
       }
        sqlpro_themes_token_query = " where webtemp_key='"+(sqlpro_themes_token_query_param)+"'";
      }
      
      var sqlpro_themes_push_ui_data_to =sqlpro_themes_callback_function_string;
      if(sqlpro_themes_callback_function_string=="")
      {
      sqlpro_themes_push_ui_data_to = "add_sqlpro_themes_ui_data";
      }
                
      console.log(sqlpro_themes_token_query+" -- "+sqlpro_themes_js_uptoken);

	  //alert(sqlpro_themes_push_ui_data_to);

     get_sqlpro_themes("*", sqlpro_themes_token_query, "webtemp_key", "blackhole", sqlpro_themes_push_ui_data_to, "");
    }
    
    function add_sqlpro_themes_ui_data(sqlpro_themes_server_resp) 
    {
    var json_decoded_str=JSON.parse(sqlpro_themes_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load sqlpro_themes data on the fly ==============
    
	var gft_sqlpro_themes_str="(webtemp_name LIKE '%{{qsqlpro_themes}}%' OR  webtemp_id LIKE '%{{qsqlpro_themes}}%' OR  webtemp_skinclr LIKE '%{{qsqlpro_themes}}%' OR  webtemp_btnclr LIKE '%{{qsqlpro_themes}}%' OR  webtemp_gentxtclr LIKE '%{{qsqlpro_themes}}%' OR  webtemp_btntxtclr LIKE '%{{qsqlpro_themes}}%' OR  webtemp_url LIKE '%{{qsqlpro_themes}}%' OR  webtemp_bgimg LIKE '%{{qsqlpro_themes}}%' OR  site_id LIKE '%{{qsqlpro_themes}}%' OR  webtemp_contbg LIKE '%{{qsqlpro_themes}}%' OR  webtemp_conttxtclr LIKE '%{{qsqlpro_themes}}%' OR  webtemp_type LIKE '%{{qsqlpro_themes}}%' OR  owner LIKE '%{{qsqlpro_themes}}%')";
    
    function  gft_sqlpro_themes(qsqlpro_themes_str)
    {
        	var clean_sqlpro_themes_filter_str=gft_sqlpro_themes_str.replace(/{{qsqlpro_themes}}/g, magic_clean_str(qsqlpro_themes_str));
            
            return  clean_sqlpro_themes_filter_str;

    }
    
    function load_sqlpro_themes(sqlpro_themes_qstr, sqlpro_themes_where_str, sqlpro_themes_ret_cols, sqlpro_themes_user_function, sqlpro_themes_result_function, sqlpro_themes_data_tray)
    {
    
    var fsqlpro_themes_result_function="push_result";
      
    if(sqlpro_themes_result_function!="")
    {
          var fsqlpro_themes_result_function=sqlpro_themes_result_function;

    }
    	var clean_sqlpro_themes_filter_str=gft_sqlpro_themes_str.replace(/{{qsqlpro_themes}}/g, magic_clean_str(sqlpro_themes_qstr));
        
        var fsqlpro_themes_where_str=" where "+clean_sqlpro_themes_filter_str;

    if(sqlpro_themes_where_str!="")
    {
          var fsqlpro_themes_where_str=" "+sqlpro_themes_where_str;

    }
       
      get_sqlpro_themes("*", fsqlpro_themes_where_str, sqlpro_themes_ret_cols, sqlpro_themes_user_function, fsqlpro_themes_result_function, sqlpro_themes_data_tray);
      
    }
    ///=============== load sqlpro_themes data on the fly ==============

   

    //Start get  stock_history Data ===============
    
      function get_stock_history(stock_history_colstr, stock_history_filter_col, stock_history_cols, stock_history_node_function_name, stock_history_callback_function_string, stock_history_ui_tag)
      {
        mosyflex_sel("stock_history", stock_history_colstr, stock_history_filter_col , stock_history_cols, stock_history_node_function_name, stock_history_callback_function_string, stock_history_ui_tag);
        
      }
    //End get  stock_history Data ===============

    //Start insert  stock_history Data ===============

	function add_stock_history(stock_history_cols, stock_history_vals, stock_history_callback_function_string)
    {
		
        mosyajax_create_data("stock_history", stock_history_cols, stock_history_vals, stock_history_callback_function_string);
     }
     
    //End insert  stock_history Data ===============

    
    //Start update  stock_history Data ===============

    function update_stock_history(stock_history_update_str, stock_history_where_str, stock_history_callback_function_string){
    
		mosyajax_update("stock_history", stock_history_update_str, stock_history_where_str, stock_history_callback_function_string)
    
    }
    //end  update  stock_history Data ===============

	//Start drop  stock_history Data ===============
    function stock_history_drop(stock_history_where_str, stock_history_callback_function_string)
    {
        mosyajax_drop("stock_history", stock_history_where_str, stock_history_callback_function_string)

    }
	//End drop  stock_history Data ===============
    
    function initialize_stock_history(qstr, stock_history_callback_function_string)
    {
      var stock_history_token_query =qstr;
      if(qstr=="")
      {
       var stock_history_token_query_param="";
       var stock_history_js_uptoken=mosy_get_param("stock_history_uptoken");
       
       if(stock_history_js_uptoken!==undefined)
       {
        stock_history_token_query_param = atob(stock_history_js_uptoken);
       }
        stock_history_token_query = " where primkey='"+(stock_history_token_query_param)+"'";
      }
      
      var stock_history_push_ui_data_to =stock_history_callback_function_string;
      if(stock_history_callback_function_string=="")
      {
      stock_history_push_ui_data_to = "add_stock_history_ui_data";
      }
                
      console.log(stock_history_token_query+" -- "+stock_history_js_uptoken);

	  //alert(stock_history_push_ui_data_to);

     get_stock_history("*", stock_history_token_query, "primkey", "blackhole", stock_history_push_ui_data_to, "");
    }
    
    function add_stock_history_ui_data(stock_history_server_resp) 
    {
    var json_decoded_str=JSON.parse(stock_history_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load stock_history data on the fly ==============
    
	var gft_stock_history_str="(stocked LIKE '%{{qstock_history}}%' OR  amount LIKE '%{{qstock_history}}%' OR  stock_date LIKE '%{{qstock_history}}%' OR  supplier LIKE '%{{qstock_history}}%' OR  comment LIKE '%{{qstock_history}}%' OR  item_id LIKE '%{{qstock_history}}%')";
    
    function  gft_stock_history(qstock_history_str)
    {
        	var clean_stock_history_filter_str=gft_stock_history_str.replace(/{{qstock_history}}/g, magic_clean_str(qstock_history_str));
            
            return  clean_stock_history_filter_str;

    }
    
    function load_stock_history(stock_history_qstr, stock_history_where_str, stock_history_ret_cols, stock_history_user_function, stock_history_result_function, stock_history_data_tray)
    {
    
    var fstock_history_result_function="push_result";
      
    if(stock_history_result_function!="")
    {
          var fstock_history_result_function=stock_history_result_function;

    }
    	var clean_stock_history_filter_str=gft_stock_history_str.replace(/{{qstock_history}}/g, magic_clean_str(stock_history_qstr));
        
        var fstock_history_where_str=" where "+clean_stock_history_filter_str;

    if(stock_history_where_str!="")
    {
          var fstock_history_where_str=" "+stock_history_where_str;

    }
       
      get_stock_history("*", fstock_history_where_str, stock_history_ret_cols, stock_history_user_function, fstock_history_result_function, stock_history_data_tray);
      
    }
    ///=============== load stock_history data on the fly ==============

   

    //Start get  suppliers Data ===============
    
      function get_suppliers(suppliers_colstr, suppliers_filter_col, suppliers_cols, suppliers_node_function_name, suppliers_callback_function_string, suppliers_ui_tag)
      {
        mosyflex_sel("suppliers", suppliers_colstr, suppliers_filter_col , suppliers_cols, suppliers_node_function_name, suppliers_callback_function_string, suppliers_ui_tag);
        
      }
    //End get  suppliers Data ===============

    //Start insert  suppliers Data ===============

	function add_suppliers(suppliers_cols, suppliers_vals, suppliers_callback_function_string)
    {
		
        mosyajax_create_data("suppliers", suppliers_cols, suppliers_vals, suppliers_callback_function_string);
     }
     
    //End insert  suppliers Data ===============

    
    //Start update  suppliers Data ===============

    function update_suppliers(suppliers_update_str, suppliers_where_str, suppliers_callback_function_string){
    
		mosyajax_update("suppliers", suppliers_update_str, suppliers_where_str, suppliers_callback_function_string)
    
    }
    //end  update  suppliers Data ===============

	//Start drop  suppliers Data ===============
    function suppliers_drop(suppliers_where_str, suppliers_callback_function_string)
    {
        mosyajax_drop("suppliers", suppliers_where_str, suppliers_callback_function_string)

    }
	//End drop  suppliers Data ===============
    
    function initialize_suppliers(qstr, suppliers_callback_function_string)
    {
      var suppliers_token_query =qstr;
      if(qstr=="")
      {
       var suppliers_token_query_param="";
       var suppliers_js_uptoken=mosy_get_param("suppliers_uptoken");
       
       if(suppliers_js_uptoken!==undefined)
       {
        suppliers_token_query_param = atob(suppliers_js_uptoken);
       }
        suppliers_token_query = " where primkey='"+(suppliers_token_query_param)+"'";
      }
      
      var suppliers_push_ui_data_to =suppliers_callback_function_string;
      if(suppliers_callback_function_string=="")
      {
      suppliers_push_ui_data_to = "add_suppliers_ui_data";
      }
                
      console.log(suppliers_token_query+" -- "+suppliers_js_uptoken);

	  //alert(suppliers_push_ui_data_to);

     get_suppliers("*", suppliers_token_query, "primkey", "blackhole", suppliers_push_ui_data_to, "");
    }
    
    function add_suppliers_ui_data(suppliers_server_resp) 
    {
    var json_decoded_str=JSON.parse(suppliers_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load suppliers data on the fly ==============
    
	var gft_suppliers_str="(supp_id LIKE '%{{qsuppliers}}%' OR  contact_person LIKE '%{{qsuppliers}}%' OR  supplier_tel LIKE '%{{qsuppliers}}%' OR  supplier_ocation LIKE '%{{qsuppliers}}%' OR  business_name LIKE '%{{qsuppliers}}%' OR  speciality LIKE '%{{qsuppliers}}%' OR  comment LIKE '%{{qsuppliers}}%')";
    
    function  gft_suppliers(qsuppliers_str)
    {
        	var clean_suppliers_filter_str=gft_suppliers_str.replace(/{{qsuppliers}}/g, magic_clean_str(qsuppliers_str));
            
            return  clean_suppliers_filter_str;

    }
    
    function load_suppliers(suppliers_qstr, suppliers_where_str, suppliers_ret_cols, suppliers_user_function, suppliers_result_function, suppliers_data_tray)
    {
    
    var fsuppliers_result_function="push_result";
      
    if(suppliers_result_function!="")
    {
          var fsuppliers_result_function=suppliers_result_function;

    }
    	var clean_suppliers_filter_str=gft_suppliers_str.replace(/{{qsuppliers}}/g, magic_clean_str(suppliers_qstr));
        
        var fsuppliers_where_str=" where "+clean_suppliers_filter_str;

    if(suppliers_where_str!="")
    {
          var fsuppliers_where_str=" "+suppliers_where_str;

    }
       
      get_suppliers("*", fsuppliers_where_str, suppliers_ret_cols, suppliers_user_function, fsuppliers_result_function, suppliers_data_tray);
      
    }
    ///=============== load suppliers data on the fly ==============

   

    //Start get  team Data ===============
    
      function get_team(team_colstr, team_filter_col, team_cols, team_node_function_name, team_callback_function_string, team_ui_tag)
      {
        mosyflex_sel("team", team_colstr, team_filter_col , team_cols, team_node_function_name, team_callback_function_string, team_ui_tag);
        
      }
    //End get  team Data ===============

    //Start insert  team Data ===============

	function add_team(team_cols, team_vals, team_callback_function_string)
    {
		
        mosyajax_create_data("team", team_cols, team_vals, team_callback_function_string);
     }
     
    //End insert  team Data ===============

    
    //Start update  team Data ===============

    function update_team(team_update_str, team_where_str, team_callback_function_string){
    
		mosyajax_update("team", team_update_str, team_where_str, team_callback_function_string)
    
    }
    //end  update  team Data ===============

	//Start drop  team Data ===============
    function team_drop(team_where_str, team_callback_function_string)
    {
        mosyajax_drop("team", team_where_str, team_callback_function_string)

    }
	//End drop  team Data ===============
    
    function initialize_team(qstr, team_callback_function_string)
    {
      var team_token_query =qstr;
      if(qstr=="")
      {
       var team_token_query_param="";
       var team_js_uptoken=mosy_get_param("team_uptoken");
       
       if(team_js_uptoken!==undefined)
       {
        team_token_query_param = atob(team_js_uptoken);
       }
        team_token_query = " where primkey='"+(team_token_query_param)+"'";
      }
      
      var team_push_ui_data_to =team_callback_function_string;
      if(team_callback_function_string=="")
      {
      team_push_ui_data_to = "add_team_ui_data";
      }
                
      console.log(team_token_query+" -- "+team_js_uptoken);

	  //alert(team_push_ui_data_to);

     get_team("*", team_token_query, "primkey", "blackhole", team_push_ui_data_to, "");
    }
    
    function add_team_ui_data(team_server_resp) 
    {
    var json_decoded_str=JSON.parse(team_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load team data on the fly ==============
    
	var gft_team_str="(user_id LIKE '%{{qteam}}%' OR  names LIKE '%{{qteam}}%' OR  username LIKE '%{{qteam}}%' OR  password LIKE '%{{qteam}}%' OR  role LIKE '%{{qteam}}%' OR  last_seen LIKE '%{{qteam}}%' OR  photo LIKE '%{{qteam}}%' OR  telephone LIKE '%{{qteam}}%' OR  admin_id LIKE '%{{qteam}}%')";
    
    function  gft_team(qteam_str)
    {
        	var clean_team_filter_str=gft_team_str.replace(/{{qteam}}/g, magic_clean_str(qteam_str));
            
            return  clean_team_filter_str;

    }
    
    function load_team(team_qstr, team_where_str, team_ret_cols, team_user_function, team_result_function, team_data_tray)
    {
    
    var fteam_result_function="push_result";
      
    if(team_result_function!="")
    {
          var fteam_result_function=team_result_function;

    }
    	var clean_team_filter_str=gft_team_str.replace(/{{qteam}}/g, magic_clean_str(team_qstr));
        
        var fteam_where_str=" where "+clean_team_filter_str;

    if(team_where_str!="")
    {
          var fteam_where_str=" "+team_where_str;

    }
       
      get_team("*", fteam_where_str, team_ret_cols, team_user_function, fteam_result_function, team_data_tray);
      
    }
    ///=============== load team data on the fly ==============

   

    //Start get  transactions Data ===============
    
      function get_transactions(transactions_colstr, transactions_filter_col, transactions_cols, transactions_node_function_name, transactions_callback_function_string, transactions_ui_tag)
      {
        mosyflex_sel("transactions", transactions_colstr, transactions_filter_col , transactions_cols, transactions_node_function_name, transactions_callback_function_string, transactions_ui_tag);
        
      }
    //End get  transactions Data ===============

    //Start insert  transactions Data ===============

	function add_transactions(transactions_cols, transactions_vals, transactions_callback_function_string)
    {
		
        mosyajax_create_data("transactions", transactions_cols, transactions_vals, transactions_callback_function_string);
     }
     
    //End insert  transactions Data ===============

    
    //Start update  transactions Data ===============

    function update_transactions(transactions_update_str, transactions_where_str, transactions_callback_function_string){
    
		mosyajax_update("transactions", transactions_update_str, transactions_where_str, transactions_callback_function_string)
    
    }
    //end  update  transactions Data ===============

	//Start drop  transactions Data ===============
    function transactions_drop(transactions_where_str, transactions_callback_function_string)
    {
        mosyajax_drop("transactions", transactions_where_str, transactions_callback_function_string)

    }
	//End drop  transactions Data ===============
    
    function initialize_transactions(qstr, transactions_callback_function_string)
    {
      var transactions_token_query =qstr;
      if(qstr=="")
      {
       var transactions_token_query_param="";
       var transactions_js_uptoken=mosy_get_param("transactions_uptoken");
       
       if(transactions_js_uptoken!==undefined)
       {
        transactions_token_query_param = atob(transactions_js_uptoken);
       }
        transactions_token_query = " where primkey='"+(transactions_token_query_param)+"'";
      }
      
      var transactions_push_ui_data_to =transactions_callback_function_string;
      if(transactions_callback_function_string=="")
      {
      transactions_push_ui_data_to = "add_transactions_ui_data";
      }
                
      console.log(transactions_token_query+" -- "+transactions_js_uptoken);

	  //alert(transactions_push_ui_data_to);

     get_transactions("*", transactions_token_query, "primkey", "blackhole", transactions_push_ui_data_to, "");
    }
    
    function add_transactions_ui_data(transactions_server_resp) 
    {
    var json_decoded_str=JSON.parse(transactions_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load transactions data on the fly ==============
    
	var gft_transactions_str="(transaction_id LIKE '%{{qtransactions}}%' OR  transaction_ref LIKE '%{{qtransactions}}%' OR  package_name LIKE '%{{qtransactions}}%' OR  package_price LIKE '%{{qtransactions}}%' OR  amount_paid LIKE '%{{qtransactions}}%' OR  balance LIKE '%{{qtransactions}}%' OR  transaction_type LIKE '%{{qtransactions}}%' OR  transaction_date LIKE '%{{qtransactions}}%' OR  month_year LIKE '%{{qtransactions}}%' OR  client_id LIKE '%{{qtransactions}}%' OR  received_by LIKE '%{{qtransactions}}%' OR  confirmed_by LIKE '%{{qtransactions}}%' OR  remark LIKE '%{{qtransactions}}%' OR  status LIKE '%{{qtransactions}}%' OR  admin_id LIKE '%{{qtransactions}}%' OR  old_balances LIKE '%{{qtransactions}}%' OR  total_due LIKE '%{{qtransactions}}%' OR  discount LIKE '%{{qtransactions}}%' OR  payment_mode LIKE '%{{qtransactions}}%' OR  installation_fee LIKE '%{{qtransactions}}%' OR  trxdate LIKE '%{{qtransactions}}%' OR  package_amount_paid LIKE '%{{qtransactions}}%' OR  othercharges_paid LIKE '%{{qtransactions}}%' OR  date_paid LIKE '%{{qtransactions}}%')";
    
    function  gft_transactions(qtransactions_str)
    {
        	var clean_transactions_filter_str=gft_transactions_str.replace(/{{qtransactions}}/g, magic_clean_str(qtransactions_str));
            
            return  clean_transactions_filter_str;

    }
    
    function load_transactions(transactions_qstr, transactions_where_str, transactions_ret_cols, transactions_user_function, transactions_result_function, transactions_data_tray)
    {
    
    var ftransactions_result_function="push_result";
      
    if(transactions_result_function!="")
    {
          var ftransactions_result_function=transactions_result_function;

    }
    	var clean_transactions_filter_str=gft_transactions_str.replace(/{{qtransactions}}/g, magic_clean_str(transactions_qstr));
        
        var ftransactions_where_str=" where "+clean_transactions_filter_str;

    if(transactions_where_str!="")
    {
          var ftransactions_where_str=" "+transactions_where_str;

    }
       
      get_transactions("*", ftransactions_where_str, transactions_ret_cols, transactions_user_function, ftransactions_result_function, transactions_data_tray);
      
    }
    ///=============== load transactions data on the fly ==============

  //===============End Mosy queries-============


var ajax_url ="./ajaxreqhandler.php";
var mosyajax_sql_url=ajax_url;
   //Ajax Manager
function mosyflex_sel(tbl, colstr, filter_col , cols, node_function_name, callback_function_string, ui_tag)
{
    var clean_ui1=ui_tag.replace(/</g, "{{<}}");
    var clean_ui2=clean_ui1.replace(/>/g, "{{>}}");
    var clean_ui3=clean_ui2.replace(/onclick/g, "{{on click}}");
    var clean_ui4=clean_ui3.replace(/onkeyup/g, "{{on keyup}}");
    var clean_ui=clean_ui4.replace(/onchange/g, "{{on change}}");
    
    var json_params_str={"mosyajax_sql_data":filter_col, "colstr":colstr, "cols":cols, "node_function_name":node_function_name, "tbl":tbl, "ui_tag":clean_ui};
   
  	//alert(clean_ui);
  
	mosy_ajax_post(ajax_url, json_params_str, callback_function_string, "");
}

function push_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display='<div class="col-md-12 p-0 text-right"><span class="badge cpointer" style="font-size:10px;"><i class="fa fa-times-circle"></i> Close</span></div>'+server_resp;
  
  if(server_resp.toString().trim()=='')
  {
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 "> <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
  }
  
  
  if (document.getElementById(additional_callbacks) !==null) {
        
  document.getElementById(additional_callbacks).style.display="block";
  document.getElementById(additional_callbacks).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}

function push_val(arrkeys, arrvalues)
{
    var r = {},i;
    
    for (let i = 0; i < arrkeys.length; i++) {
        r[arrkeys[i]] = arrvalues[i];
      document.getElementById(arrvalues[i]).value=[arrkeys[i]];
    }

}

    function qddata(server_resp,callbacks)
    {
    //alert(server_resp);
    var retjson = JSON.parse(server_resp)[0];
    
        ///alert(retjson.name);


    return retjson;
    
    
    }
function mosy_ajax_post(post_url, json_params, callback_function_string, additional_callbacks)
{


	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    if (document.getElementById(fadditional_callbacks) !==null) {
        document.getElementById(fadditional_callbacks).style.display="block";
    	document.getElementById(fadditional_callbacks).innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';
        
    }
  	var formData = ((json_params)); //Array 
  
      $.ajax({ 
      url: post_url,
      type: "POST",
      data:formData,

      success: function (data) 
      {
        //alert(data);
       if (document.getElementById("ajax_spinner") !==null) 
       {
       
         var result_response_='<i class="fa fa-info-circle"></i> Request Processed Succesfully.';
		
        	if(data=='')
            {
            
        		var result_response_='<i class="fa fa-info-circle"></i> No data .';
            
            }
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML=result_response_;

       } 
        window[fcall_back_function](data, fadditional_callbacks);

      }

  })
  
}  


   //Ajax Manager

function mosyajax_create_data(tbl, tbl_cols, tbl_vals, callback_function_string)
{
  ///alert(tbl_cols+" - "+tbl_vals);
  
    var json_params_str={"mosyajax_create":"ok", "tbl_cols":tbl_cols, "tbl_vals":tbl_vals, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

   //Ajax Exe
function mosyajax_update(tbl, update_str, where_str, callback_function_string)
{
  //alert(update_str);
  
    var json_params_str={"mosyajax_update":"ok", "update_str":update_str, "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

function mosyajax_drop(tbl, where_str, callback_function_string)
{
  //alert(where_str);
  
    var json_params_str={"mosyajax_drop":"ok", "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}


function mosyajax_get(getstr, callback_function_string)
{
    if (document.getElementById("ajax_spinner") !==null) 
    {
        
      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

  	}

    $.ajax({
      url: ajax_url+"?"+getstr,
      type: 'GET',
      success: function(res) {
       if (document.getElementById("ajax_spinner") !==null) {

          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

       }              
            //alert(res);

             window[callback_function_string](res);
          }
      });
}


function mosy_form_data(form_id,  save_action, callback_function_string, additional_callbacks)
{
	var formData = new FormData(document.getElementById(form_id));
  
    if (document.getElementById("ajax_spinner") !==null) {
        
    	document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';
        
    }
	formData.append(save_action, "ok");
	formData.append('mosyrequest_type', "ajax");
        $.ajax({
            type: "POST",
            url: ajax_url,
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
                  if (document.getElementById("ajax_spinner") !==null) {
        
                      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

                  }
              ///alert(data);
        		window[callback_function_string](data, additional_callbacks);
            },
	    complete: function(){
			//alert("Data uploaded successfully.");
	    },
	    error: function (jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
	    } 
        });
      // Display the key/value pairs
      for (var pair of formData.entries()) {
          console.log(pair[0]+ ", " + pair[1]); 
      }
}

function blackhole(data)
{

}

function show_password(input_name) 
{
  var x = document.getElementById(input_name);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}


function mosy_refresh(new_location)
{

var new_location_str=window.location.href;

  window.location=new_location_str.replace("table_alert", "tbl_alert_old");

}


function pop_filter_tray (data_src, card_title, where_str_req,cols,returnfun)
{
  magic_screen(pop_data_filter_card, "alert_box");
        
  var where_str =" and "+(where_str_req);
  var where_str_inp =" and "+magic_clean_str(where_str_req);
  
  if(where_str_req=="")
  {
    var where_str="";
    var where_str_inp ="";
  }
  
  var load_data_set ="load_"+data_src;
  var gft_data_str="gft_"+data_src;
  ///alert(where_str);
  window[load_data_set]("", ajaxw+" "+window[gft_data_str]("")+where_str, cols, returnfun, "push_result:result","card");
  
  //alert(cols);
  var textbox ='<input type="text" class="form-control" onkeyup="'+load_data_set+'(this.value, \''+ajaxw+' \'+'+gft_data_str+'(this.value)+\''+where_str_inp+'\', \''+magic_clean_str(cols)+'\', \''+returnfun+'\', \'push_result:result\',\'card\')" placeholder="Type your search here"/>';
        
  document.getElementById('card_title').innerHTML=card_title;
  document.getElementById('dope_text').innerHTML=textbox;

        
}

function tray_uptoken(datakey,callbacks)
{
  
  window.location=callbacks[0]+'?'+callbacks[1]+'_uptoken='+btoa(datakey[0]);
}

var pop_data_filter_card=`
    <h5><i class="fa fa-search mr-2"></i><span id="card_title"></span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  	<div id="dope_text" class="col-md-12"></div>
	<div id="result" class="col-md-12" style="max-height:300px; overflow-y:auto;" onclick="this.style.display='none'"></div>
    
  	<div id="r" class="col-md-12 row justify-content-center m-0 p-0 mt-3">
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5 mr-lg-3" id="pop_tray_location"> 
        	View All <i class="fa fa-arrow-right"></i> 
        </a>
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5" id="new_pop_tray_location"> 
        	<i class="fa fa-plus" id="newclass"></i> 
        	<span id="new_record_label"> Add new </span> 
        </a>
    </div>
  </div>`;
  
function push_link(new_link,anchor_el)
{

	//alert(new_link);
	document.getElementById(anchor_el).href=new_link;

}


function push_html(elemid, new_val)
{
  document.getElementById(elemid).innerHTML=new_val;
}

function push_newval(elemid, new_val)
{
  document.getElementById(elemid).value=new_val;
}

function push_src(elemid, new_val)
{
  document.getElementById(elemid).src=new_val;
}

function mosytoggle_class(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosy_get_param(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}


function mosy_push_data(elemid,data)
{
	var elem_state ="false";
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='div')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  
}

function check_elem(elemid)
{
    if (document.getElementById(elemid) ===null) 
    {
    alert("element_"+elemid+" Not available");
    }
}
function mosy_push_ddata(_server_resp, elemid_str)
{
	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = elemid_arr[0];
        
          data_str = elemid_arr[1];
          
          console.log(elemid+" state "+ data_str+" serep "+_server_resp);

         data = json_decoded_str[data_str];
        
    }
    
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='div')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}


///////////////  slide show 
function mosy_slide_wgt(image_arr_n_captions, img_style, img_class, extra_attr, slide_indicators_yes_no)
{
  
const rem_array = image_arr_n_captions.slice(0, 0).concat(image_arr_n_captions.slice(0+1, image_arr_n_captions.length));
  
var curr_slide_id =magic_random_str(10);
    
var img_string =  image_arr_n_captions[0];
var caption_str = ""
var caption_str_div="";
var datakey = "";
  
if(image_arr_n_captions[0].includes(":"))
{
 img_string =  image_arr_n_captions[0].substring(0, image_arr_n_captions[0].indexOf(':')); 
 datakey_1 = image_arr_n_captions[0].substring(image_arr_n_captions[0].indexOf(':')+1); 
 datakey = datakey_1.substring(0, datakey_1.indexOf(':'));
 datakey_2 = datakey_1.substring(datakey_1.indexOf(':')+1);
 caption_str = datakey_2.substring(datakey_2.indexOf(':'));
 caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${caption_str} </div>`;
}
  ///alert("dkey1 -- "+datakey_2);
 var slide_node="";
 var slidecounter="";
 var i=0;
  
 if(slide_indicators_yes_no=='yes')
 {
   slidecounter=`<li data-target="#slide_s${curr_slide_id}" data-slide-to="0" class="active"></li>`;
 }
 for(img_arr of rem_array)
 {
   i++;
   
	if(slide_indicators_yes_no=='yes'){
 slidecounter+=`
        <li data-target="#slide_s${curr_slide_id}" data-slide-to="${i}" class="active"></li>
   `;  
    }
   
   var loop_img_string =  img_arr;
   var loop_caption_str = "";
   var loop_caption_str_div="";
   var loop_datakey="";
   
   if(img_arr.includes(":")){
 	loop_img_string =  img_arr.substring(0, img_arr.indexOf(':')); 
 	loop_datakey_1 = img_arr.substring(img_arr.indexOf(':')+1); 
 	loop_datakey = loop_datakey_1.substring(0, loop_datakey_1.indexOf(':'));
 	loop_datakey_2 = loop_datakey_1.substring(loop_datakey_1.indexOf(':')+1);
 	loop_caption_str = loop_datakey_2.substring(loop_datakey_2.indexOf(':'));
 	loop_caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${loop_caption_str} </div>`;
   }
   
   slide_node+=`   
            <!-- carousel item -->
            <div class="carousel-item">
             <div class="row pt-3 justify-content-center">
     			${loop_caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${loop_img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${loop_datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->`;
   
 }
  
var slide_tray=`
      <!--------------- Start carousel ---------->
      <div id="slide_s${curr_slide_id}" class="carousel slide w-100" data-ride="carousel" data-interval="2000">
        <ol class="carousel-indicators mt-2">
  		${slidecounter}
        </ol>
        <!-- carousel inner -->
          <div class="carousel-inner">
            <!-- carousel item -->
            <div class="carousel-item active">
             <div class="row pt-3 justify-content-center">
          	   ${caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->
		   ${slide_node}
            <!-- carousel inner -->
            <a class="carousel-control-prev" href="#slide_s${curr_slide_id}" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a class="carousel-control-next" href="#slide_s${curr_slide_id}" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a> 
          </div>
             
      </div>
      <!--------------- End carousel ---------->
        `;
  
return [slide_tray, curr_slide_id];  
}
///////////////  slide show 

//////////////  image alert 
function mosy_img_pop(img_src,img_style, img_class,  extra_attr, slide_show_yes_no)
{
  var img_tray=
    `
    <img src="${img_src}" style="${img_style}" class="${img_class}"/>
    
    `;
  
  if(slide_show_yes_no=='yes')
  {
    
    var pop_tray_carousel = mosy_slide_wgt(img_src, img_style, img_class, extra_attr)[0];
    
    magic_screen(pop_tray_carousel, 'alert_box');
    
  }else{
  	magic_screen(img_tray, 'alert_box');
  }
  
}  

//////////////  image alert \

function mosy_snack_wgt(content, curr_position, push_to, snack_pos, snackid, color, bg, onclick_fun)
{
              
var snack_cont=`
<style>
/* The snackbar - position it at the bottom and in the middle of the screen */
#${snackid} {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background:${bg}; /* Black background color */
  color: ${color}; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 9999; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  ${curr_position}: ${snack_pos}; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#${snackid}.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}

@keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}
</style>
  
  <div id="${snackid}" onclick="${onclick_fun};push_html('${push_to}', '')">${content}</div>

  `;


push_html(push_to, snack_cont);


} 

function new_location(new_location_str)
{
window.location=new_location_str;
}


function glass_modal()
{
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("background-color", "transparent", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border-top", "0px solid", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border", "0px solid", "important");;
}

function mosy_card(card_title, card_content, attach_To)
{
    var link_pop=`
    <div class="row justify-content-center m-0 p-0 col-md-12">
                      <!-- Start  Title ribbon-->
                      <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                        <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                        <div class="col-md-8 text-center"><b> ${card_title}</b></div>
                        <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                      </h5>
                      <!-- End Title ribbon--> 

                      <div class="row justify-content-center m-0 p-0 col-md-12 mt-3 mb-3">
                        ${card_content}
                      </div>
      </div>
    </div>

    `;

    if(attach_To=='' || attach_To==undefined)
    {
    magic_screen(link_pop, 'alert_box');
    }else{
      push_html(attach_To, link_pop);
    }

    return link_pop;
 
}
//<--ncgh-->
