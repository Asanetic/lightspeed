function pop_analy_month_year(goto)
{

  var input_q ='<select class="form-control" id="txt_paid_month_year">'+
          '</select>';
  var gotobtn ='<div class="col-md-12 text-center" style="width:100%;"><div class="btn btn-primary" onclick="got_to_annual(\''+goto+'\')">Proceed</div></div>';
  var card_tile = '<h4>Annual Client Report<hr></h4>'+input_q+'<hr>'+gotobtn+'<hr><div style="width:100%; max-height:300px; overflow:auto;" id="result_card"></div>';

  magic_screen(card_tile , 'alert_box');
  
      var start = 2017;
      var end = new Date().getFullYear();
      var options = "";
      for(var year = start ; year <=end; year++){
        options += "<option>"+ year +"</option>";
      }
      document.getElementById("txt_paid_month_year").innerHTML ='<option>2017</option>'+options;
}
//=========== Start compute _month arrears Ajax 

function got_to_annual(goto)
{
  var filter_year = document.getElementById("txt_paid_month_year").value;
  

  window.location=goto+'?trx_year='+btoa(filter_year);

}
function compute_monthy_payment(client_id, month_year)
{
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'compute_monthy_payment': 'ok',
         'month_year': month_year,
         'client_id': client_id
      },

      success: function (data) {

		alert(data)

      }

  });

}


//=========== End compute _month arrears Ajax 

//=========== Start compute _month arrears Ajax 

function get_month_balances(client_id, month_year)
{
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'get_month_balances': 'ok',
         'month_year': month_year,
         'client_id': client_id
      },

      success: function (data) {

		alert(data)

      }

  });

}


//=========== End compute _month arrears Ajax 


  
  //=========== Start compute _month arrears Ajax 

function get_month_arrears(client_id, month_year)
{
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'get_month_arrears': 'ok',
         'month_year': month_year,
         'client_id': client_id
      },

      success: function (data) {
      
        if(document.getElementById('txt_trx_token').value==''){
           
          document.getElementById('txt_old_balances').value=data;

      	}
  
		if(data==0)
        {
          
		magic_disable_input('edittrx', '#ccc')

        }else{
          magic_enable_input('edittrx', '#FFF');

        }

    
      }

  });

}


//=========== End compute _month arrears Ajax 
function pop_suppliers()
{

  var input_q ='<input type="text" class="form-control" id="txt_suppliers_qstr" onkeyup="qsuppliers_list(this.value)"/>';
  var gotobtn ='';
  var card_tile = '<h4>Search Suppliers<hr></h4>'+input_q+'<hr>'+gotobtn+'<hr><div style="width:100%; max-height:300px; overflow:auto;" id="result_card"></div>';

  magic_screen(card_tile , 'alert_box');
  
  document.getElementById('txt_suppliers_qstr').focus();
  
  qsuppliers_list(' ')
  
}


function pop_arr_month(goto)
{

  var input_q ='<input type="month" class="form-control" id="txt_arr_month_year"/>';
  var gotobtn ='<div class="col-md-12 text-center" style="width:100%;"><div class="btn btn-primary" onclick="show_monthly_arrears(\''+goto+'\')">Proceed</div></div>';
  var card_tile = '<h4> Monthly Arrears<hr></h4>'+input_q+'<hr>'+gotobtn+'<hr><div style="width:100%; max-height:300px; overflow:auto;" id="result_card"></div>';

  magic_screen(card_tile , 'alert_box');
  
  
}

function pop_analy_month(goto)
{

  var input_q ='<input type="month" class="form-control" id="txt_arr_month_year"/>';
  var gotobtn ='<div class="col-md-12 text-center" style="width:100%;"><div class="btn btn-primary" onclick="show_monthly_arrears(\''+goto+'\')">Proceed</div></div>';
  var card_tile = '<h4> Payment Analysis Reports<hr></h4>'+input_q+'<hr>'+gotobtn+'<hr><div style="width:100%; max-height:300px; overflow:auto;" id="result_card"></div>';

  magic_screen(card_tile , 'alert_box');
  
  
}
  
function show_monthly_arrears(goto)
{
var month_year =document.getElementById('txt_arr_month_year').value;
  
  window.location=goto+'?monthly_arrears='+btoa(month_year);

}

//=========== Start suppliers query Ajax 
function qsuppliers_list(qstr)
{
  document.getElementById('result_card').innerHTML='Fetching...';
  
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'qsuppliers_list': 'ok',
         'qstr': qstr
      },

      success: function (data) {

		document.getElementById('result_card').innerHTML=data;

      }

  });

}

function select_supplier(supplier_id, supplier_name)
{

document.getElementById('txt_supplier_id').value=supplier_id;
document.getElementById('txt_supplier_name').value=supplier_name;
document.getElementById('alert_box').innerHTML='';
  
}

//=========== End suppliers query Ajax 

function pop_payment_months(goto)
{

  var input_q ='<input type="month" class="form-control" id="txt_filter_month"/>';
  var gotobtn ='<div class="col-md-12 text-center" style="width:100%;"><div class="btn btn-primary" onclick="get_monthly_report(\''+goto+'\')">Proceed</div></div>';
  var month_card = '<h5>Monthly Payments Reports<hr></h5>'+input_q+'<hr>'+gotobtn+'<hr><div style="width:100%; max-height:300px; overflow:auto;" id="result_card"></div>';

  magic_screen(month_card, 'alert_box');
  
  
}

function get_monthly_report(goto)
{

  var gmonth =magic_validate_required('Select Month', 'txt_filter_month');
  if(gmonth=='True')
  {
  window.location=''+goto+'?qmonthly_report='+btoa(document.getElementById('txt_filter_month').value);
  }
  
}


function pop_packages()
{

  var input_q =magic_input('qpktxt', 'Search Packages', 'onkeyup="qpackages(this.value)"', '');
  var package_card = '<h4>Package List<hr></h4>'+input_q+'<hr><div id="result_card"></div>';
  
  magic_screen(package_card, 'alert_box');
  
	qpackages(' ');
  
 	document.getElementById('qpktxt').focus();
}

function pop_manage_active_months(client_id)
{

  var input_q ='<input type="month" class="form-control" id="txt_inactive_month" onchange="qactive_client_months(\''+client_id+'\', this.value)"/>';
  var gotobtn ='<div class="col-md-12 text-center" style="width:100%;"><div class="btn btn-primary" onclick="add_inactive_month(\''+client_id+'\')">Add As Inactive Month</div></div>';
  var month_card = '<h4>Client Inactive Months List<hr></h4>'+input_q+'<hr>'+gotobtn+'<hr><div style="width:100%; max-height:300px; overflow:auto;" id="result_card"></div>';

  magic_screen(month_card, 'alert_box');
  
 	document.getElementById('txt_inactive_month').focus();
  
  qactive_client_months(client_id, "");
}

//=========== Start Ajax 

  
  //=========== Start Ajax 


function remove_month_year(delkey , client_id)
{
  var r = confirm("Remove Month?!");
if (r == true) {
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'remove_month_year': 'ok',
         'delkey': delkey
      },

      success: function (data) {

		//alert(data)
  qactive_client_months(client_id, "");

      }

  });

}


}


//=========== End Ajax 


function qactive_client_months(client_id, qstr)
{
 
document.getElementById('result_card').innerHTML='Fetching...';

  
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'qactive_client_months': 'ok',
         'client_id': client_id,
         'qstr': qstr
      },

      success: function (data) {

    	document.getElementById('result_card').innerHTML=data;

      }

  });

}


//=========== End Ajax 
//=========== Start Ajax 


function add_inactive_month(client_id)
{
  var inactive_month = document.getElementById('txt_inactive_month').value;
var validate_date =magic_validate_required("Please select date", 'txt_inactive_month');
  if(validate_date=='True'){
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'add_inactive_month': 'ok',
         'txt_client_id': client_id,
         'txt_month_year': inactive_month
      },

      success: function (data) {
	  
        alert(data);
        
	  qactive_client_months(client_id, "");

      }

  });
  }else{
   alert('Month required') 
  }

}


//=========== End Ajax 

//=====================add_inactive_month
  
  
  

function pop_client_search(context)
{

  var input_q =magic_input('qclient_data_txt', 'Search Clients', 'onkeyup="qclient_list(this.value, \''+context+'\')"', '');
  var client_card = '<h4>Search Active Clients<hr></h4>'+input_q+'<hr><div id="result_card" style="max-height:350px; overflow-y:auto;"></div>';
  
  magic_screen(client_card, 'alert_box');
  
	qclient_list(' ', context);
  
 	document.getElementById('qclient_data_txt').focus();
}


//=========== Start Client List Ajax 


function qclient_list(qstr, context)
{
  	document.getElementById('result_card').innerHTML='Fetching...';

$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'qclient_list': 'ok',
         'qstr': qstr,
         'context': context
      },

      success: function (data) {
      
       //alert(data);

	document.getElementById('result_card').innerHTML=data;
      }

  });

}


//=========== End Client list  Ajax 


//=========== Start Package Ajax 


function qpackages(qstr)
{
  	document.getElementById('result_card').innerHTML='Fetching';

$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'qpackages': 'ok',
         'qstr': qstr
      },

      success: function (data) {

	document.getElementById('result_card').innerHTML=data;
      }

  });

}


//=========== End package  Ajax 




function pop_package_id(pid, pname, pprice)
{

  	document.getElementById('txt_package_name').value=pname;
  	document.getElementById('txt_package_id').value=pid;
  	document.getElementById('txt_package_price').value=pprice;
   	document.getElementById('msg_alert_myModal').style.display='none';

}

//========================================= Inventory =====================

function pop_inventory()
{

  var input_q =magic_input('qclient_data_txt', 'Search Inventory', 'onkeyup="qinventory_list(this.value)"', '');
  var inventory_card = '<h5>Search Items<hr></h5>'+input_q+'<hr><div id="result_card" style="max-height:350px; overflow-y:auto;"></div>';
  
  magic_screen(inventory_card, 'alert_box');
  
	qinventory_list(' ');
  
 	document.getElementById('qclient_data_txt').focus();
}


//=========== Start Client List Ajax 


function qinventory_list(qstr)
{
  	document.getElementById('result_card').innerHTML='Fetching...';

$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'qinventory_list': 'ok',
         'qstr': qstr
      },

      success: function (data) {
      
       //alert(data);

	document.getElementById('result_card').innerHTML=data;
      }

  });

}


//=========== End Client list  Ajax 

function add_from_inventory(item_id, item_name, item_price)
{

  	document.getElementById('txt_item_name').value=item_name;
  	document.getElementById('txt_item_id').value=item_id;
  	document.getElementById('txt_item_price').value=item_price;
  	document.getElementById('txt_qty').value=1;
  	document.getElementById('txt_inst_tots').value=parseInt(document.getElementById('txt_qty').value)*item_price;
   	document.getElementById('msg_alert_myModal').style.display='none';
  
}


//========================================= Inventory =====================


function calc_charge_tots()
{
  
  document.getElementById('txt_inst_tots').value=parseInt(document.getElementById('txt_qty').value)*parseInt(document.getElementById('txt_item_price').value);
 calc_tot_bal_rem();

}


//=========== Start Ajax 


function add_charge_tbl_item()
{
  

var txt_charge_id =document.getElementById('txt_item_id').value;
var txt_item_name =document.getElementById('txt_item_name').value;
var txt_item_id =document.getElementById('txt_item_id').value;
  

 if(txt_charge_id==''){

var txt_charge_id =document.getElementById('txt_item_name').value;

}
var txt_client_id=document.getElementById('txt_client_id').value
var txt_package_id=document.getElementById('txt_package_id').value
var txt_trx_id=document.getElementById('txt_trx_id').value
var txt_amount=document.getElementById('txt_item_price').value
var txt_balance=document.getElementById('txt_balance').value
var txt_qty=document.getElementById('txt_qty').value;
  
var rqname = magic_validate_required('required', 'txt_item_name')
var rqamt = magic_validate_required('required', 'txt_item_price')
var rqqty = magic_validate_required('required', 'txt_qty')

 if((rqqty=='False') || rqamt=='False' || rqname=='False'){
  alert('Please fill the required fileds')
}else{
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'add_charge_tbl_item': 'ok',
        'txt_charge_id':txt_charge_id,
        'txt_client_id':txt_client_id,
        'txt_package_id':txt_package_id,
        'txt_trx_id':txt_trx_id,
        'txt_amount':txt_amount,
        'txt_balance':txt_balance,
        'txt_qty':txt_qty
      },

      success: function (data) {

		//alert(data)
		loop_charge_items();
      }

  });
}
}


//=========== End Ajax 

//=========== Start Ajax 


function loop_charge_items()
{
  var trx_id=document.getElementById('txt_trx_id').value
	document.getElementById('item_charge_bdy').innerHTML='Refreshing Records ...';

$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'loop_charge_items': 'ok',
         'trx_id': trx_id
      },

      success: function (data) {

	document.getElementById('item_charge_bdy').innerHTML=data;
        
    document.getElementById('txt_amount_payable').value = parseInt(document.getElementById('tot_items_charge').innerHTML)+(parseInt(document.getElementById('txt_old_balances').value));
      calc_tot_bal_rem();
     
      }

  });

}


//=========== End Ajax 

//=========== Start Ajax 


function delete_charge(delkey)
{

$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'delete_charge': 'ok',
         'delkey': delkey
      },

      success: function (data) {

		loop_charge_items();
        
      }

  });

}


//=========== End Ajax 
function checknan(input_id)
{
  
  var numberTest =document.getElementById(input_id).value;
    if (Number.isNaN(numberTest) || numberTest == "" || numberTest === null) {
    var myElement = document.getElementById(input_id);
	if(myElement === document.activeElement){
    //myElement Has Focus
	}else{
      
      document.getElementById(input_id).value=0; 
    }
  }
}


function calc_tot_bal_rem()
{
checknan('txt_package_price');
checknan('txt_old_balances');
checknan('txt_amount_payable');
checknan('txt_discount');
checknan('txt_total_due');
checknan('txt_package_amount_paid');
checknan('txt_othercharges_paid');
checknan('txt_amount_paid');
checknan('txt_balance');
  
  
document.getElementById('txt_total_due').value=parseInt(document.getElementById('txt_amount_payable').value)-parseInt(document.getElementById('txt_discount').value);
document.getElementById('txt_amount_paid').value=((parseInt(document.getElementById('txt_othercharges_paid').value)+parseInt(document.getElementById('txt_package_amount_paid').value)));
document.getElementById('txt_balance').value=((parseInt(document.getElementById('txt_total_due').value)-parseInt(document.getElementById('txt_amount_paid').value)));


}


function check_mpesa()
{

  if(document.getElementById('txt_payment_mode').value=='Mpesa' || document.getElementById('txt_payment_mode').value=='Cheque'){
   document.getElementById('txt_transaction_ref').required  =true;
  }else{
       document.getElementById('txt_transaction_ref').required  =false;

  }

}

function pop_due_date(gotourl)
{
var loop_due_date ='<select id="due_date_drop_down" class="form-control" <option value="10">Select Date</option></select>';
var loop_due_date2 ='<select id="due_date_drop_down2" class="form-control"><option value="10">Select Date</option></select>';
var gotobtn ='<div class="col-md-12 text-center" style="width:100%;"><hr><div class="btn btn-primary" onclick="load_due_date(\''+gotourl+'\')">Go </div></div>';
  
 var loop_dt='';
  for(i=1; i<32; i++)
  {
    loop_dt+='<option>'+i+'</option>';
  }
  
   var loop_dt2='';
  for(j=1; j<32; j++)
  {
    loop_dt2+='<option>'+j+'</option>';
  }
  
  
	magic_screen('<h5>Filter By Due Date Between </h5> <hr>start Date'+loop_due_date+"<hr> End Date"+loop_due_date2+""+gotobtn, 'alert_box');
  
    document.getElementById('due_date_drop_down').innerHTML=document.getElementById('due_date_drop_down').innerHTML+loop_dt;
    document.getElementById('due_date_drop_down2').innerHTML=document.getElementById('due_date_drop_down2').innerHTML+loop_dt2;


}


function load_due_date(gotourl) 
{
var qstart_due_date=document.getElementById('due_date_drop_down').value;
var qend_due_date=document.getElementById('due_date_drop_down2').value;

window.location='./'+gotourl+'?qstart_due_date='+btoa(qstart_due_date)+"&qend_due_date="+btoa(qend_due_date);
}
  
  
function pop_pay_state(statekey, statevalue)
  {
  
  var yes_no_btn='<a href="#" class="btn btn-primary" onclick="change_trx_state(\''+statekey+'\', \'Pending\')">Pending</a>';
   yes_no_btn+='<a href="#" class="btn btn-primary ml-lg-4" onclick="change_trx_state(\''+statekey+'\', \'Cleared\')">Cleared</a>';
    
    magic_screen('<h6><i class="fa fa-check-circle"></i> Mark Payment as</h6><hr><div class="w-100 text-center">'+yes_no_btn+'</div>', 'alert_box');

  }

//=========== Start Ajax 


function change_trx_state(statekey, statevalue)
{
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'change_trx_state': 'ok',
         'statekey': statekey,
         'statevalue': statevalue
      },

      success: function (data) {

		alert(data)

      }

  });

}


//=========== End Ajax 

function pop_report_date(goto, curr_doctype, context)
  {
    var from_date_tile='<h6><i class="fa fa-calendar"></i> Select Start Date</h6><input type="date" class="form-control" id="start_date_input"/>';

    var to_date_tile='<h6 class="mt-3"><i class="fa fa-calendar"></i> Select End Date</h6><input type="date" class="form-control" id="end_date_input"/><hr>';
    var submit_filter='<div style="text-align:center;"><div class="btn btn-primary" onclick="create_coa_report(\''+goto+'\', \''+context+'\')"> <i class="fa fa-arrow-right"></i>  Proceed</div></div><hr>';

    magic_screen('<h5>Generate '+curr_doctype+' report<hr></h5> '+from_date_tile+to_date_tile+submit_filter, 'alert_box');

  }

  function create_coa_report(goto, context)
  {
    var start_date_input = document.getElementById('start_date_input').value;
    var end_date_input = document.getElementById('end_date_input').value;

    var proceed_to_report ='yes';

    if(start_date_input=="")
    {
      alert('Select Start Date');

      var proceed_to_report ='no';

    }else if(end_date_input==''){

      alert('Select End Date');

      var proceed_to_report ='no';

    }



    if(proceed_to_report=='yes')
    {
      if(goto=='transactions'){
            window.location=(goto+'?start_date_input='+btoa(start_date_input)+'&end_date_input='+btoa(end_date_input));
      }else if(context=='install_date'){

      window.location=(goto+'?qstart_inst_date='+btoa(start_date_input)+'&qend_inst_date='+btoa(end_date_input));

      }else if(context=='trxfilter'){

      window.location=(goto+'?start_tx_date='+btoa(start_date_input)+'&end_tx_id='+btoa(end_date_input));

      }else{
            window.open(goto+'?start_date_input='+btoa(start_date_input)+'&end_date_input='+btoa(end_date_input));
      }
    }
}

//=========== Start Ajax 

//ml/infomessenger/addcontacts.php
function export_contacts(cont_key)
{
$.ajax({ 
      url: './data_control/ajax.php',
      type: "POST",
      data: {
      	'export_contacts': 'ok',
         'cont_key': cont_key
      },

      success: function (data) {

		alert(data)

      }

  });

}


//=========== End Ajax 
