
  
  
////========================= start active_client_months inputs widget 

function active_client_months_input_wgt(input_array, button, title)
{
 var input_policy={"txt_client_id":"Member Names:text:col-md-4","txt_reamark":"Reamark:text:col-md-4","txt_status":"Status:text:col-md-4",};
 if(title=="")
 {
 title ="Active Client Months";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start address_book inputs widget 

function address_book_input_wgt(input_array, button, title)
{
 var input_policy={"txt_address":"Address:text:col-md-4","txt_type":"Type:type_dynamic_drop_down:col-md-4","txt_comment":"Comment:text:col-md-4",};
 if(title=="")
 {
 title ="Address Book";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
          				
                  if(input_type=="type_dynamic_drop_down")
                  {
                  label_tag ="";
                  input_tag =`
         			 <label ><span>Type</span> 
              			<span  id="_toggle_on_type"   onclick="document.getElementById(\'txt_type\').type=\'text\';document.getElementById(\'txt_type\').value=\'\';document.getElementById(\'sel_type\').style.display=\'none\';this.style.display=\'none\';document.getElementById(\'_toggle_off_type\').style.display=\'inline-block\';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              			<span style="display:none" id="_toggle_off_type"   onclick="document.getElementById(\'txt_type\').type=\'hidden\';document.getElementById(\'sel_type\').style.display=\'block\';this.style.display=\'none\';document.getElementById(\'_toggle_on_type\').style.display=\'inline-block\';if(document.getElementById(\'txt_type\').value==\'\') document.getElementById(\'txt_type\').value=document.getElementById(\'sel_type\').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_type" id="txt_type" class="form-control" placeholder="Type new Type" /> 
              <select name="sel_type" id="sel_type" class="form-control" onchange="document.getElementById('txt_type').value=this.value;"></select>
              `
              
              };
          
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  
           function load_address_book_type_dyn_items(qstr)
           {
           get_address_book("*", ""+qstr+" group by type", 'primkey,type:type','', 'push_result:sel_type', 'option');
           }
          
          

  
  
  
////========================= start admin inputs widget 

function admin_input_wgt(input_array, button, title)
{
 var input_policy={"txt_names":"Names:text:col-md-4","txt_username":"Username:text:col-md-4","txt_password":"Password:password:col-md-4","txt_role":"Role:text:col-md-4","txt_last_seen":"Last Seen:datetime-local:col-md-4","txt_telephone":"Telephone:text:col-md-4",};
 if(title=="")
 {
 title ="Admin";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start client_base inputs widget 

function client_base_input_wgt(input_array, button, title)
{
 var input_policy={"txt_client_name":"Client Name:text:col-md-4","txt_gender":"Gender:gender_static_drop_down:col-md-4","txt_client_tel":"Client Tel:text:col-md-4","txt_client_email":"Client Email:text:col-md-4","txt_city":"City:text:col-md-4","txt_location":"Location:location_dynamic_drop_down:col-md-4","txt_building_no":"Building No:text:col-md-4","txt_floor_no":"Floor No:text:col-md-4","txt_room_no":"Room No:text:col-md-4","txt_package":"Package:text:col-md-4","txt_package_price":"Package Price:text:col-md-4","txt_installation_date":"Installation Date:text:col-md-4","txt_signed_by":"Signed By:text:col-md-4","txt_comment":"Comment:text:col-md-4","txt_ip_address":"Ip Address:text:col-md-4","txt_account_status":"Account Status:text:col-md-4","txt_instdate":"Instdate:text:col-md-4","txt_vcf_exported":"Vcf Exported:text:col-md-4",};
 if(title=="")
 {
 title ="Client Base";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
           

                
				if(input_type=="gender_static_drop_down")
                  {
                input_tag=`
                   <select name="txt_gender" id="txt_gender" class="form-control">
                   </select>`;
                   }
           
    
          				
                  if(input_type=="location_dynamic_drop_down")
                  {
                  label_tag ="";
                  input_tag =`
         			 <label ><span>Location</span> 
              			<span  id="_toggle_on_location"   onclick="document.getElementById(\'txt_location\').type=\'text\';document.getElementById(\'txt_location\').value=\'\';document.getElementById(\'sel_location\').style.display=\'none\';this.style.display=\'none\';document.getElementById(\'_toggle_off_location\').style.display=\'inline-block\';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              			<span style="display:none" id="_toggle_off_location"   onclick="document.getElementById(\'txt_location\').type=\'hidden\';document.getElementById(\'sel_location\').style.display=\'block\';this.style.display=\'none\';document.getElementById(\'_toggle_on_location\').style.display=\'inline-block\';if(document.getElementById(\'txt_location\').value==\'\') document.getElementById(\'txt_location\').value=document.getElementById(\'sel_location\').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_location" id="txt_location" class="form-control" placeholder="Type new Location" /> 
              <select name="sel_location" id="sel_location" class="form-control" onchange="document.getElementById('txt_location').value=this.value;"></select>
              `
              
              };
          
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  
              function load_client_base_gender_items ()
              {
                var default_gender_static_drop_down_val = `                      
                <option >Gender</option>`;
                
                var static_gender_drop_down_items=`<option>Male</option>
<option>Female</option>
`;
           push_html("txt_gender", default_gender_static_drop_down_val+static_gender_drop_down_items);
           }
           function load_client_base_location_dyn_items(qstr)
           {
           get_client_base("*", ""+qstr+" group by location", 'primkey,location:location','', 'push_result:sel_location', 'option');
           }
          
          

  
  
  
////========================= start client_charges inputs widget 

function client_charges_input_wgt(input_array, button, title)
{
 var input_policy={"txt_client_id":"Member Names:text:col-md-4","txt_package_id":"Package Id:text:col-md-4","txt_trx_id":"Trx Id:text:col-md-4","txt_amount":"Amount:text:col-md-4","txt_balance":"Balance:text:col-md-4","txt_remark":"Remark:textarea:col-md-12","txt_qty":"Qty:text:col-md-4",};
 if(title=="")
 {
 title ="Client Charges";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start dtclean inputs widget 

function dtclean_input_wgt(input_array, button, title)
{
 var input_policy={"txt_client_name":"Client Name:text:col-md-4","txt_room_no":"Room No:text:col-md-4","txt_package":"Package:text:col-md-4","txt_package_amt":"Package Amt:text:col-md-4","txt_insta_date":"Insta Date:text:col-md-4",};
 if(title=="")
 {
 title ="Dtclean";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start expenses inputs widget 

function expenses_input_wgt(input_array, button, title)
{
 var input_policy={"txt_transaction_ref":"Transaction Ref:text:col-md-4","txt_amount_paid":"Amount Paid:text:col-md-4","txt_transaction_type":"Transaction Type:text:col-md-4","txt_transaction_date":"Transaction Date:date:col-md-4","txt_client_id":"Member Names:text:col-md-4","txt_received_by":"Received By:text:col-md-4","txt_confirmed_by":"Confirmed By:text:col-md-4","txt_remark":"Remark:textarea:col-md-12","txt_payment_mode":"Payment Mode:text:col-md-4",};
 if(title=="")
 {
 title ="Expenses";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start files_and_photos inputs widget 

function files_and_photos_input_wgt(input_array, button, title)
{
 var input_policy={"txt_file_path":"File Path:text:col-md-4",};
 if(title=="")
 {
 title ="Files And Photos";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start inventory inputs widget 

function inventory_input_wgt(input_array, button, title)
{
 var input_policy={"txt_item_name":"Item Name:text:col-md-4","txt_buying_price":"Buying Price:text:col-md-4","txt_description":"Description:text:col-md-4","txt_selling_price":"Selling Price:text:col-md-4",};
 if(title=="")
 {
 title ="Inventory";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start message_board inputs widget 

function message_board_input_wgt(input_array, button, title)
{
 var input_policy={"txt_from":"From:text:col-md-4","txt_to":"To:text:col-md-4","txt_msg_date":"Msg Date:text:col-md-4","txt_admin":"Admin:text:col-md-4","txt_read":"Read:text:col-md-4","txt_message":"Message:text:col-md-4","txt_msg_type":"Msg Type:text:col-md-4","txt_subject":"Subject:text:col-md-4",};
 if(title=="")
 {
 title ="Message Board";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start notes inputs widget 

function notes_input_wgt(input_array, button, title)
{
 var input_policy={"txt_title":"Title:text:col-md-4","txt_note":"Note:text:col-md-4","txt_note_date":"Note Date:text:col-md-4","txt_note_tag":"Note Tag:text:col-md-4","txt_user_id":"User Id:text:col-md-4","txt_client_id":"Member Names:text:col-md-4",};
 if(title=="")
 {
 title ="Notes";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start packages inputs widget 

function packages_input_wgt(input_array, button, title)
{
 var input_policy={"txt_package_name":"Package Name:text:col-md-4","txt_price":"Price:text:col-md-4","txt_description":"Description:text:col-md-4",};
 if(title=="")
 {
 title ="Packages";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start sqlpro_themes inputs widget 

function sqlpro_themes_input_wgt(input_array, button, title)
{
 var input_policy={"txt_webtemp_id":"Webtemp Id:text:col-md-4","txt_webtemp_skinclr":"Webtemp Skinclr:text:col-md-4","txt_webtemp_btnclr":"Webtemp Btnclr:text:col-md-4","txt_webtemp_gentxtclr":"Webtemp Gentxtclr:text:col-md-4","txt_webtemp_btntxtclr":"Webtemp Btntxtclr:text:col-md-4","txt_webtemp_url":"Webtemp Url:text:col-md-4","txt_webtemp_bgimg":"Webtemp Bgimg:text:col-md-4","txt_site_id":"Site Id:text:col-md-4","txt_webtemp_contbg":"Webtemp Contbg:text:col-md-4","txt_webtemp_conttxtclr":"Webtemp Conttxtclr:text:col-md-4","txt_webtemp_type":"Webtemp Type:text:col-md-4","txt_owner":"Owner:text:col-md-4",};
 if(title=="")
 {
 title ="Sqlpro Themes";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start stock_history inputs widget 

function stock_history_input_wgt(input_array, button, title)
{
 var input_policy={"txt_amount":"Amount:text:col-md-4","txt_stock_date":"Stock Date:text:col-md-4","txt_supplier":"Supplier:text:col-md-4","txt_comment":"Comment:text:col-md-4","txt_item_id":"Item Id:text:col-md-4",};
 if(title=="")
 {
 title ="Stock History";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start suppliers inputs widget 

function suppliers_input_wgt(input_array, button, title)
{
 var input_policy={"txt_contact_person":"Contact Person:text:col-md-4","txt_supplier_tel":"Supplier Tel:text:col-md-4","txt_supplier_ocation":"Supplier Ocation:text:col-md-4","txt_business_name":"Business Name:text:col-md-4","txt_speciality":"Speciality:text:col-md-4","txt_comment":"Comment:text:col-md-4",};
 if(title=="")
 {
 title ="Suppliers";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start team inputs widget 

function team_input_wgt(input_array, button, title)
{
 var input_policy={"txt_names":"Names:text:col-md-4","txt_username":"Username:text:col-md-4","txt_password":"Password:password:col-md-4","txt_role":"Role:text:col-md-4","txt_last_seen":"Last Seen:datetime-local:col-md-4","txt_telephone":"Telephone:text:col-md-4",};
 if(title=="")
 {
 title ="Team";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  
  
  
////========================= start transactions inputs widget 

function transactions_input_wgt(input_array, button, title)
{
 var input_policy={"txt_transaction_ref":"Transaction Ref:text:col-md-4","txt_package_name":"Package Name:text:col-md-4","txt_package_price":"Package Price:text:col-md-4","txt_amount_paid":"Amount Paid:text:col-md-4","txt_balance":"Balance:text:col-md-4","txt_transaction_type":"Transaction Type:text:col-md-4","txt_transaction_date":"Transaction Date:date:col-md-4","txt_client_id":"Member Names:text:col-md-4","txt_received_by":"Received By:text:col-md-4","txt_confirmed_by":"Confirmed By:text:col-md-4","txt_remark":"Remark:textarea:col-md-12","txt_status":"Status:text:col-md-4","txt_old_balances":"Old Balances:text:col-md-4","txt_total_due":"Total Due:text:col-md-4","txt_discount":"Discount:text:col-md-4","txt_payment_mode":"Payment Mode:text:col-md-4","txt_installation_fee":"Installation Fee:text:col-md-4","txt_trxdate":"Trxdate:text:col-md-4","txt_package_amount_paid":"Package Amount Paid:text:col-md-4","txt_othercharges_paid":"Othercharges Paid:text:col-md-4","txt_date_paid":"Date Paid:text:col-md-4",};
 if(title=="")
 {
 title ="Payments";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  

  