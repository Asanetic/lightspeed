<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/team.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Team</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Team<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  <!--Start Sql input-->  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./team.php', '<i class="fa fa-arrow-left"></i> Back to list', "");?>

    	<?php echo magic_button_link('./editteam.php?newrecord', '<i class="fa fa-plus"></i> Add new', "");?> 

		<?php if(isset($_GET['team_uptoken'])) echo magic_button_link('./editteam.php?team_uptoken='.($_GET["team_uptoken"]).'&deleteteam','<i class="fa fa-trash"></i> Delete', 'style="background-color:red;"');?>
	</div>     
	<div class="row p-md-3 justify-content-center bg-white col-md-11">
	

<div class="col-md-5">

 <div class="form-group">
  <label >Names</label>
  <input class="form-control" id="txt_names" name="txt_names" value="<?php echo $team_node["names"];?>" placeholder="Names" type="text">
 </div>
 <div class="form-group">
  <label >Username</label>
  <input class="form-control" id="txt_username" name="txt_username" value="<?php echo $team_node["username"];?>" placeholder="Username" type="text">
 </div>
  <div class="form-group">
  <label >Telephone</label>
  <input class="form-control" id="txt_telephone" name="txt_telephone" value="<?php echo $team_node["telephone"];?>" placeholder="Telephone" type="text">
 </div>
 <div class="form-group">
  <label >Password</label>
  <input class="form-control" id="txt_password" name="txt_password" value="<?php echo $team_node["password"];?>" placeholder="Password" type="password">
 </div>
 <div class="form-group">
  <label >Role</label>
     <select class="form-control" id="txt_role" name="txt_role">
       <option value=""><?php echo $team_node["role"];?></option>
          <option>Admin</option>
          <option>Technician</option>
    </select>
  </div>
 <div class="form-group">
  <label >Last Seen</label>
  <input readonly class="form-control" id="txt_last_seen" name="txt_last_seen" value="<?php echo $team_node["last_seen"];?>" placeholder="Last Seen" type="text">
 </div>



</div>
                   
		<div align="center" style="width: 98%">
			<?php if(!isset($_GET['team_uptoken'])) echo magic_button("team_insert_btn","Proceed","");?>
			<?php if(isset($_GET['team_uptoken'])) echo magic_button("team_update_btn","Save Changes","");?>
		</div>
		</div>

<!--End Sql input-->
<!--<{ncgh}/>-->

          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
