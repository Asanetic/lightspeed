<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/stock_history.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$item_id=$stock_history_node['item_id'];
$supplier_id=$stock_history_node['supplier'];

if(isset($_GET["qitemid"])){
  
  $item_id=base64_decode($_GET['qitemid']);
}


$item_name = qinventory_data($item_id)['item_name'];
$supplier_name=qsupplier_data($supplier_id)['business_name'];
$input_stock_date=date('Y-m-d', strtotime($stock_history_node['stock_date']));

if($stock_history_node['stock_date']=='')
{
$input_stock_date=date("Y-m-d");
;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Stock History</title>
    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Stock History<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  <!--Start Sql input-->  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./stock_history.php', '<i class="fa fa-arrow-left"></i> Back to list', "");?>

    	<?php echo magic_button_link('./editstock_history.php?newrecord', '<i class="fa fa-plus"></i> Add new', "");?> 
    	<?php echo magic_button_link('./inventory.php?qinventory='.base64_encode($stock_history_node["item_id"]).'','<i class="fa fa-eye"></i> View item', '');?> 
		<?php if(isset($_GET['stock_history_uptoken'])) echo magic_button_link('./editstock_history.php?stock_history_uptoken='.($_GET["stock_history_uptoken"]).'&deletestock_history','<i class="fa fa-trash"></i> Delete', 'style="background-color:red;"');?>
	</div>     
	<div class="row p-md-3 justify-content-center bg-white col-md-11">
<div class="col-md-7">
 <div class="form-group">
  <label >Item</label>
  <input class="form-control"  value="<?php echo $item_name;?>" placeholder="Item" type="text">
  <input class="form-control" id="txt_item_id" name="txt_item_id" value="<?php echo $item_id;?>" placeholder="Item Id" type="hidden">
 </div>
 <div class="form-group">
  <label >Quantity brought in</label>
  <input class="form-control" required id="txt_stocked" name="txt_stocked" value="<?php echo $stock_history_node["stocked"];?>" placeholder="Stocked" type="text">
 </div>
 <div class="form-group">
  <label >Buying price</label>
  <input class="form-control" required id="txt_amount" name="txt_amount" value="<?php echo $stock_history_node["amount"];?>" placeholder="Amount" type="text">
 </div>
 <div class="form-group">
  <label >Stock Date</label>
  <input class="form-control" required id="txt_stock_date" name="txt_stock_date" value="<?php echo $input_stock_date;?>" placeholder="Stock Date" type="date">
 </div>
 <div class="form-group">
  <label >Supplier</label>
  <input class="form-control" onclick="pop_suppliers()" id="txt_supplier_name"  value="<?php echo $supplier_name;?>" placeholder="Supplier" type="text">
  <input class="form-control" onclick="pop_suppliers()" id="txt_supplier_id" name="txt_supplier" value="<?php echo $supplier_id;?>" placeholder="Supplier" type="hidden">

 </div>


	</div>

<div class="col-md-7">
 <div class="form-group">
  <label >Comment</label>
  <input class="form-control" id="txt_comment" name="txt_comment" value="<?php echo $stock_history_node["comment"];?>" placeholder="Comment" type="text">
 </div>

</div>
                   
		<div align="center" style="width: 98%">
			<?php if(!isset($_GET['stock_history_uptoken'])) echo magic_button("stock_history_insert_btn","Proceed","");?>
			<?php if(isset($_GET['stock_history_uptoken'])) echo magic_button("stock_history_update_btn","Save Changes","");?>
		</div>
		</div>

<!--End Sql input-->
<!--<{ncgh}/>-->

          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
