<?php
ob_start();

include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/transactions.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$current_client_id=$transactions_node['client_id'];

if(isset($_GET["client_id"])){

	$current_client_id=base64_decode($_GET['client_id']);

}

$trx_client_node=qclient_data($current_client_id);
$client_name=$trx_client_node['client_name'];
$client_package=$trx_client_node['package'];

$client_package_name=qpackage_data($trx_client_node['package'])['package_name'];
$client_package_price=qpackage_data($trx_client_node['package'])['price'];

if($transactions_node['package_price']!='')
{

$client_package_price=$transactions_node['package_price'];

}

if($transactions_node['package_name']!='')
{

$client_package=($transactions_node['package_name']);
$client_package_name=qpackage_data($transactions_node['package_name'])['package_name'];

}

$formatted_date=date("Y-m-d\TH:i:s", strtotime($transactions_node['transaction_date']));
if($transactions_node['transaction_date']==''){

$formatted_date=date("Y-m-d\TH:i:s");

}

$formatted_date_paid=date("Y-m-d", strtotime($transactions_node['date_paid']));
if($transactions_node['date_paid']==''){

$formatted_date_paid=date("Y-m-d");

}

$formatted_month_year=date("Y-m", strtotime($transactions_node['month_year']));

$formated_fy= date("M-Y", strtotime($transactions_node['month_year']));

if($transactions_node['month_year']=='' && !isset($_GET['trx_month_year'])){

$formatted_month_year=date("Y-m");

$formated_fy= date("M-Y");
  
}

if(isset($_GET['trx_month_year'])){

$formatted_month_year=date("Y-m", strtotime(base64_decode($_GET['trx_month_year'])));

$formated_fy= date("M-Y",  strtotime(base64_decode($_GET['trx_month_year'])));
  
}

$session_trx_id=$transactions_node['transaction_id'];

if($transactions_node['transaction_id']==''){
 if(isset($_SESSION["session_trx_id_active"])){
	$session_trx_id=$_SESSION["session_trx_id"];
}else{
  
  $_SESSION["session_trx_id_active"]=TRUE;
  $_SESSION["session_trx_id"]=magic_random_str(7);
   
  $session_trx_id=$_SESSION["session_trx_id"];

   
 }
}

          $act_start_date=$trx_client_node['installation_date'];
          $act_end_date=date("Y-m-d");
          
          if(isset($_GET['end_date_input']))
          {
          $act_start_date=base64_decode($_GET['start_date_input']);
          $act_end_date=base64_decode($_GET['end_date_input']);
          }
          
          
          $tot_pkg_paid=cal_client_payments($act_start_date, $act_end_date,  $trx_client_node["client_id"]);
		  $tot_inst_charges=cal_client_inst_arrears($act_start_date, $act_end_date, $trx_client_node["client_id"])[0];
		  $tot_inst_charges_paid=cal_client_inst_arrears($act_start_date, $act_end_date, $trx_client_node["client_id"])[1];
		  $cpackge_price=qpackage_data($trx_client_node["package"])['price'];
          

          $active_months= calc_active_months($act_start_date, $act_end_date, $trx_client_node["client_id"])[0];
	      $tot_pkg_due=$active_months*$cpackge_price;
          $tot_pack_bal=$tot_pkg_due-$tot_pkg_paid;
          $inst_charge_bal=$tot_inst_charges-$tot_inst_charges_paid;
                     

			$netarrears=$transactions_node["old_balances"];

			if($transactions_node["old_balances"]==''){
		  		$netarrears=get_month_arrears($current_client_id, $formated_fy);
              }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Transactions</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data" id="edittrx">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
  		<?php if(!isset($_GET['transactions_uptoken'])){?>
        <h4 class="col-md-12" style="text-align: center;">Add Payment For <?php echo $client_name." : Month  - ".$formated_fy;?><br><br></h4>
          <?php }else{?>
        <h4 class="col-md-12" style="text-align: center;">Transaction Profile For <?php echo $client_name." : Month  - ".$formated_fy;?><br><br></h4>
          <?php }?>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
		
<!--Start Sql input-->  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./transactions.php', '<i class="fa fa-arrow-left"></i> Back to list', "");?>

    	<?php if(isset($_GET['transactions_uptoken'])) echo magic_button_link('./edittransactions?client_id='.base64_encode($transactions_node['client_id']).'', '<i class="fa fa-credit-card"></i> Add Payment', "");?> 
    	<?php  echo magic_button_link('./transactions?qclient_id='.base64_encode($current_client_id).'', '<i class="fa fa-history"></i> Payment History', "");?> 
	    <?php  echo magic_button_link('#','<i class="fa fa-times"></i> Inactive Months', 'onclick="pop_manage_active_months(\''.$current_client_id.'\')"');?>
      
	    <?php echo magic_button_link('./client_base?qclient_id='.base64_encode($current_client_id).'','<i class="fa fa-list"></i> View on client list', '');?>

		<?php if(isset($_GET['transactions_uptoken'])) echo magic_button_link('./edittransactions.php?transactions_uptoken='.($_GET["transactions_uptoken"]).'&deletetransactions','<i class="fa fa-trash"></i> Delete', 'style="background-color:red;"');?>
	</div>     
	<div class="row p-md-3 justify-content-center bg-white col-md-11">
          <h5 class="col-md-12" style="display:none;" id="edittrx_msg">The client has no arrears. Entry disabled<hr></h4>
	<!-- Start -->
  	<div class="row justify-content-center col-md-12">
      <div class="col-md-4">
       <div class="form-group">
        <label >Client</label>
        <input class="form-control" id="txt_client_name" name="txt_client_name" value="<?php echo $client_name;?>" placeholder="Client" type="text">
        <input class="form-control" id="txt_client_id" name="txt_client_id" value="<?php echo $current_client_id;?>" placeholder="Client Id" type="hidden">
        <input class="form-control" id="txt_trx_token" name="txt_trx_token" value="<?php echo $transactions_uptoken;?>"type="hidden">
       </div>
      </div>
      <div class="col-md-4">
       <div class="form-group">
        <label >Package Name</label>
        <input class="form-control"  value="<?php echo $client_package_name;?>" placeholder="Package Name" type="text">
        <input class="form-control" id="txt_package_id" name="txt_package_name" value="<?php echo $client_package;?>" placeholder="Package Name" type="hidden">
        </div>
	  </div>
      <div class="col-md-4">
       <div class="form-group">
        <label >Package Price</label>
        <input class="form-control" id="txt_package_price" name="txt_package_price" value="<?php echo $client_package_price;?>" placeholder="Package Price" type="text">
       </div>
	  </div>
     </div>
  <!-- End -->
  	<!-- Start -->
  	<div class="row justify-content-center col-md-12">
      <div class="col-md-4">
       <div class="form-group">
        <label >Arrears</label>
        <input class="form-control" onkeyup="calc_tot_bal_rem()" onchange="calc_tot_bal_rem()" id="txt_old_balances" name="txt_old_balances" value="<?php echo $netarrears;?>" placeholder="Package Price" type="text" readonly>
       </div>
	  </div>
      <div class="col-md-4">
       <div class="form-group">
        <label >Pay for Date</label>
        <input class="form-control" id="txt_transaction_date" name="txt_transaction_date" value="<?php echo $formatted_date;?>" placeholder="Transaction Date" type="datetime-local">
       </div>
      </div>
      <div class="col-md-4">
       <div class="form-group">
        <label >Month Year</label>
        <input class="form-control" id="txt_month_year" name="txt_month_year" onchange="change_trx_month_year(document.getElementById('txt_client_id').value, this.value)" value="<?php echo $formatted_month_year;?>" placeholder="Month year" type="month">
        </div>
	  </div>

     </div>
  <!-- End -->
    <!-- Start Intallation char  ges Table-->
    <div class="row justify-content-center m-0 col-md-12 bg-light p-2 pb-4">
      <h6 class="col-md-12 p-2 ml-lg-4"><u>Additional Charges</u></h6>
	<div class="row justify-content-center col-md-12">
      <div class="col-md-3">
       <div class="form-group">
        <label >Item <span  onclick="pop_inventory()" class="badge badge-primary p-1 cpointer">Select items</span></label>
        <input class="form-control" onkeyup="document.getElementById('txt_item_id').value=''" id="txt_item_name" name="txt_item_name" value="" placeholder="Item Name" type="text">
        <input class="form-control"  id="txt_item_id" name="txt_charge_id" value="" placeholder="Item" type="hidden">
        <input class="form-control"  id="txt_trx_id" name="txt_transaction_id" value="<?php echo $session_trx_id;?>" placeholder="Item" type="hidden">
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Amount</label>
        <input class="form-control" onchange="calc_charge_tots()"  onkeyup="calc_charge_tots()"  id="txt_item_price" name="txt_item_price" placeholder="Item Amount" type="text">
       </div>
      </div>
      <div class="col-md-2">
       <div class="form-group">
        <label >Qty</label>
        <input class="form-control" id="txt_qty" onchange="calc_charge_tots()"  onkeyup="calc_charge_tots()"  name="txt_qty"  placeholder="Quantity" value="1" type="text">
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Total</label>
        <input class="form-control" id="txt_inst_tots" name="txt_inst_tots" readonly  placeholder="Totals" type="text">
       </div>
      </div>
      <div class="col-md-1">
       <div class="form-group">
        <label >_</label>
        <div  class="btn btn-primary cpointer w-100" id="txt_add_charge_btn" name="txt_add_charge_btn" onclick="add_charge_tbl_item()">Add</div>
       </div>
      </div>
	</div>
     <div class="row justify-content-left col-md-12  m-0">
		<div class="btn btn-primary cpointer" onclick="loop_charge_items()"><i class="fa fa-sync"></i>Refresh</div>
	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; padding-bottom: 40px;">
          
	<table class="table table-hover text-left" id="client_charges_data_table">
	    <thead class="text-uppercase">
		   <tr>
		    <th scope="col">#</th>
          	<th scope="col">Item</th>
            <th scope="col">Amount</th>
            <th scope="col">Qty</th>
            <th scope="col">Total</th>
		   </tr>
	    </thead>
	    <tbody id="item_charge_bdy">

	    </tbody>
	    </table>
	 <hr>
	</div>
    </div>
    <!-- End  Intallation charges Table-->
   	<!-- Start input row-->
  	<div class="row justify-content-center col-md-12 border-top border-dark pt-3">
      <div class="col-md-3">
       <div class="form-group">
        <label >Amount Payable</label>
        <input readonly class="form-control"  onkeyup="calc_tot_bal_rem()" onchange="calc_tot_bal_rem()" id="txt_amount_payable" name="txt_amount_payable" placeholder="Amount Payable" type="text" required>
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Discount</label>
        <input class="form-control"  onkeyup="calc_tot_bal_rem()" onchange="calc_tot_bal_rem()"id="txt_discount" name="txt_discount" value="<?php echo $transactions_node["discount"];?>" placeholder="Discount" type="text">
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Total Due</label>
        <input class="form-control"  onkeyup="calc_tot_bal_rem()" onchange="calc_tot_bal_rem()" id="txt_total_due" name="txt_total_due" value="<?php echo $transactions_node["total_due"];?>" placeholder="Amount Paid" type="text" required readonly>
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Package Amount paid</label>
        <input class="form-control"  onkeyup="calc_tot_bal_rem()" onchange="calc_tot_bal_rem()" id="txt_package_amount_paid" name="txt_package_amount_paid" value="<?php echo $transactions_node["package_amount_paid"];?>" placeholder="Amount Paid" type="text">
       </div>
      </div>
    </div>
   <!-- End input row-->
      	<!-- Start input row-->
  	<div class="row justify-content-center col-md-12  pt-3">
      <div class="col-md-3">
       <div class="form-group">
        <label >Additional charges paid</label>
        <input class="form-control"  onkeyup="calc_tot_bal_rem()" onchange="calc_tot_bal_rem()" id="txt_othercharges_paid" name="txt_othercharges_paid" value="<?php echo $transactions_node["othercharges_paid"];?>"  placeholder="Other Charges Paid" type="text" required>
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Total Paid</label>
        <input class="form-control"  onkeyup="calc_tot_bal_rem()" onchange="calc_tot_bal_rem()" id="txt_amount_paid" name="txt_amount_paid" value="<?php echo $transactions_node["amount_paid"];?>" placeholder="Total Amount Paid" type="text" readonly>
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Balance</label>
        <input class="form-control" readonly id="txt_balance" name="txt_balance" value="<?php echo $transactions_node["balance"];?>" placeholder="Balance" type="text">
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Payment Mode</label>
       	<select class="form-control"  id="txt_payment_mode" name="txt_payment_mode"  onchange="check_mpesa();">
           <option><?php echo $transactions_node['payment_mode']?></option>
          <option>Mpesa</option>
          <option>Cash</option>
          <option>Cheque</option>
        </select>
          </div>
      </div>
    </div>
   <!-- End input row-->
         	<!-- Start input row-->
  	<div class="row justify-content-center col-md-12  pt-3">

      <div class="col-md-3">
       <div class="form-group">
        <label >Ref No</label>
        <input class="form-control" id="txt_transaction_ref" name="txt_transaction_ref" value="<?php echo $transactions_node["transaction_ref"];?>" placeholder="Ref no" type="text">
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Received By</label>
    <select class="form-control"  id="txt_received_by" name="txt_received_by">
   <option value="<?php echo $transactions_node['received_by']?>"><?php echo qteam_data($transactions_node['received_by'])['username']?></option>
   <?php $drop_down_list_q = magic_sql_group('team', "", '10000', 'primkey', 'DESC', 'user_id');
while($drop_down_list_r=mysqli_fetch_array($drop_down_list_q[0])){
?>
   <option value="<?php echo $drop_down_list_r['user_id']?>"><?php echo $drop_down_list_r['username']?></option>
<?php }?>
</select>          
       </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Status</label>
		<select  class="form-control" id="txt_status" name="txt_status">
   			<option><?php echo $transactions_node["status"];?></option>
   			<option>Cleared</option>
   			<option>Pending</option>
		</select>
        </div>
      </div>
      <div class="col-md-3">
       <div class="form-group">
        <label >Confirmed by</label>
      <select class="form-control"  id="txt_confirmed_by" name="txt_confirmed_by" >
         <option value="<?php echo $transactions_node['confirmed_by']?>"><?php echo qadmin_data($transactions_node['confirmed_by'])['username']?></option>
         <?php $admindrop_down_list_q = magic_sql_group('admin', "", '10000', 'primkey', 'DESC', 'admin_id');
      while($admindrop_down_list_r=mysqli_fetch_array($admindrop_down_list_q[0])){
      ?>
         <option value="<?php echo $admindrop_down_list_r['admin_id']?>"><?php echo $admindrop_down_list_r['username']?></option>
      <?php }?>
	</select>
       </div>
      </div>
      <div class="col-md-6">
       <div class="form-group">
        <label>Comment</label>
        <input class="form-control" id="txt_remark" name="txt_remark" value="<?php echo $transactions_node["remark"];?>" placeholder="Ref no" type="text">
       </div>
      </div>
      <div class="col-md-6">
       <div class="form-group">
        <label>Date Paid</label>
        <input class="form-control" id="txt_date_paid" name="txt_date_paid" value="<?php echo $formatted_date_paid;?>" placeholder="Date Paid" type="date">
       </div>
      </div>
      </div>
                   
		<div align="center" style="width: 98%">
			<?php if(!isset($_GET['transactions_uptoken'])) echo magic_button("transactions_insert_btn","Proceed","");?>
			<?php if(isset($_GET['transactions_uptoken'])) echo magic_button("transactions_update_btn","Save Changes","");?>
		</div>
		</div>

<!--End Sql input-->
<!--<{ncgh}/>-->

       	<!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
 <script type="text/javascript">
 
    window.onload=loop_charge_items();
    loop_charge_items();
    get_month_arrears(document.getElementById('txt_client_id').value, document.getElementById('txt_month_year').value);
    magic_disable_input('edittrx', '#ccc');


function magic_disable_input(curr_form_name, newbgcolor)
{

  if(document.getElementById('txt_old_balances').value==0){
document.getElementById('edittrx_msg').style.display='block';

document.getElementById('txt_add_charge_btn').style.display='none';

    var f = document.forms[curr_form_name];
    for(var i=0,fLen=f.length;i<fLen;i++){

     if(f.elements[i].id!='txt_month_year')
     {
              
      f.elements[i].readOnly = true;//As @oldergod noted, the "O" must be upper case
      f.elements[i].disabled = true;//As @oldergod noted, the "O" must be upper case
      f.elements[i].style.backgroundColor=newbgcolor;
       
     }

    }
    
  }
}

function magic_enable_input(curr_form_name, newbgcolor)
{
 
	document.getElementById('edittrx_msg').style.display='none';
	
    document.getElementById('txt_add_charge_btn').style.display='inline-block';

    var f = document.forms[curr_form_name];
  
    for(var i=0,fLen=f.length;i<fLen;i++)
    {        
        f.elements[i].readOnly = false;//As @oldergod noted, the "O" must be upper case
        f.elements[i].disabled = false;//As @oldergod noted, the "O" must be upper case
        f.elements[i].style.backgroundColor=newbgcolor;
      	f.elements[i].style.color='#000';
        
    }
 	document.getElementById('txt_old_balances').readOnly=true;;
 	document.getElementById('txt_total_due').readOnly=true;;
 	document.getElementById('txt_amount_payable').readOnly=true;;
 	document.getElementById('txt_amount_paid').readOnly=true;;
 	document.getElementById('txt_balance').readOnly=true;;

   	document.getElementById('txt_old_balances').style.backgroundColor='#ccc';;
 	document.getElementById('txt_total_due').style.backgroundColor='#ccc';;
 	document.getElementById('txt_amount_payable').style.backgroundColor='#ccc';;
 	document.getElementById('txt_amount_paid').style.backgroundColor='#ccc';;
 	document.getElementById('txt_balance').style.backgroundColor='#ccc';;
 
    
}

function change_trx_month_year(qclient_id, month_year)
{
  window.location='./edittransactions?client_id='+btoa(qclient_id)+'&trx_month_year='+btoa(month_year)+'';
}
</script>
    </form>
</body>
</html>

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  