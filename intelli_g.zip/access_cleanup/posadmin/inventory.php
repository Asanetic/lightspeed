<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./data_control/inventory.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>INVENTORY</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">INVENTORY LIST<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  
    <div align="left" class="col-md-6">
       <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./editinventory.php?newrecord', '<i class="fa fa-plus"></i> Add new', 'style="display:inline-block;"');?> 
    	<?php echo magic_button_link('./inventory.php', '<i class="fa fa-refresh"></i> Refresh', 'style="display:inline-block;"');?> 
    	<?php echo magic_button_link('./stock_history.php', '<i class="fa fa-history"></i> Stock in History', 'style="display:inline-block;"');?> 
    	<?php echo magic_button_link('./suppliers.php', '<i class="fa fa-truck"></i> suppliers', 'style="display:inline-block;"');?> 

		<hr><input type="text" placeholderder="Search inventory" name="txt_inventory" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button('qinventory_btn', 'Search', 'style="display:inline-block;"');?> 

	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">
	<table class="table table-hover text-left" id="inventory_data_table">
	    <thead class="text-uppercase">
		   <tr>
		    <th scope="col">#</th>
              <th scope="col">Item_/_Service</th>
              <th scope="col">B._Price</th>
              <th scope="col">S._Price</th>
              <th scope="col">StockIn</th>
              <th scope="col">Stockin_Value</th>
              <th scope="col">Stock_Out</th>
              <th scope="col">Sold_Amt</th>
              <th scope="col">Profit</th>
              <th scope="col">Remaining</th>
              <th scope="col">Balance Value</th>
              <th scope="col">Description</th>
		   </tr>
	    </thead>
	    <tbody>
		<?php 
		$pagination_record_count=$inventory_pgcount;
        $i=0;
		while($listinventory_result=mysqli_fetch_array($inventory_list_query)){
	        $i++;

	        $edit_drop_link=magic_link('./editinventory.php?inventory_uptoken='.base64_encode($listinventory_result["primkey"]).'','<i class="fa fa-arrow-right"></i> View More', '');
	        $edit_drop_link.=magic_link('./stock_history.php?qitemid='.base64_encode($listinventory_result["item_id"]).'','<i class="fa fa-truck"></i> View Stock History', '');
	        $edit_drop_link.=magic_link('./editstock_history.php?qitemid='.base64_encode($listinventory_result["item_id"]).'','<i class="fa fa-plus"></i> Add Stock', '');

	        $delete_drop_link=magic_link('./editinventory.php?inventory_uptoken='.base64_encode($listinventory_result["primkey"]).'&deleteinventory','<i class="fa fa-trash"></i> Delete', '');

	        $dropdown_items =$edit_drop_link.$delete_drop_link;
	        
	        $sold_amt=qstock_out($listinventory_result["item_id"]);
	        
	        $item_profit=($listinventory_result["selling_price"]-$listinventory_result["buying_price"])*($sold_amt);
        ?>
	    <tr>
	    	<td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
            <td scope="col"><?php echo $listinventory_result["item_name"];?></td>
            <td scope="col"><?php echo $listinventory_result["buying_price"];?></td>
            <td scope="col"><?php echo $listinventory_result["selling_price"];?></td>
            <td scope="col"><?php echo qrestocked($listinventory_result["item_id"]);?></td>
            <td scope="col"><?php echo qstockin_value($listinventory_result["item_id"]);?></td>
            <td scope="col"><?php echo qstock_out($listinventory_result["item_id"]);?></td>
            <td scope="col"><?php echo qstockout_value($listinventory_result["item_id"]);?></td>
            <td scope="col"><?php echo $item_profit;?></td>
            <td scope="col"><?php echo items_remaining($listinventory_result["item_id"])[0];?></td>
            <td scope="col"><?php echo items_remaining($listinventory_result["item_id"])[1];?></td>
            <td scope="col"><?php echo $listinventory_result["description"];?></td>
	    </tr>
	    <?php }?>
	    </tbody>
	    </table>
	 <hr>
	 <?php include("./pagination.php");?>
	</div>
          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
          
          
          
          
          
          
          
          
          
          
