<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./data_control/client_charges_main.php');
include('./adminsessionmonitor.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Client Charges</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Stock Out<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  
    <div align="left" class="col-md-6">
       <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./client_charges.php', '<i class="fa fa-refresh"></i> Refresh', 'style="display:inline-block;"');?> 

		<hr><input type="text" placeholder="Search client charges" name="txt_client_charges" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button('qclient_charges_btn', 'Search', 'style="display:inline-block;"');?> 

	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">
	<table class="table table-hover text-left" id="client_charges_data_table">
	    <thead class="text-uppercase">
		   <tr>
		    <th scope="col">#</th>
            <th scope="col">Sold On</th>
			<th scope="col">Item</th>
             <th scope="col">Client</th>
             <th scope="col">Selling Price </th>
             <th scope="col">Qty</th>
             <th scope="col">Total</th>

		   </tr>
	    </thead>
	    <tbody>
		<?php 
		$pagination_record_count=$client_charges_pgcount;
        $i=0;
		while($listclient_charges_result=mysqli_fetch_array($client_charges_list_query)){
	        $i++;

	        $edit_drop_link=magic_link('./edittransactions.php?transactions_uptoken='.base64_encode(qtrx_data($listclient_charges_result["trx_id"])['primkey']).'','<i class="fa fa-arrow-right"></i> View Transaction', '');

	        $delete_drop_link=magic_link('./editclient_charges.php?client_charges_uptoken='.base64_encode($listclient_charges_result["primkey"]).'&deleteclient_charges','<i class="fa fa-trash"></i> Delete', '');

	        $dropdown_items =$edit_drop_link;
        ?>
	    <tr>
	    	<td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
			 <td scope="col"><?php echo date("d/m/Y", strtotime(qtrx_data($listclient_charges_result["trx_id"])['transaction_date']));?></td>
			 <td scope="col"><?php echo qinventory_data($listclient_charges_result["charge_id"])['item_name'];?></td>
 <td scope="col"><?php echo qclient_data($listclient_charges_result["client_id"])['client_name'];?></td>
 <td scope="col"><?php echo $listclient_charges_result["amount"];?></td>
 <td scope="col"><?php echo $listclient_charges_result["qty"];?></td>
 <td scope="col"><?php echo $listclient_charges_result["amount"]*$listclient_charges_result["qty"];?></td>

	    </tr>
	    <?php }?>
	    </tbody>
	    </table>
	 <hr>
	 <?php include("./pagination.php");?>
	</div>
          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
