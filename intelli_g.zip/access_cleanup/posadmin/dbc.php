<?php
ob_start();

include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');

$trx_q=magic_sql_select('transactions',  "", "20000", "primkey", "desc");

while($trx_r=mysqli_fetch_array($trx_q[0])){
  
  $upkey= $trx_r['primkey'];
  $amount_paid= $trx_r['amount_paid'];
  
  magic_sql_update('transactions', '{"total_due":"'.$amount_paid.'"}', "primkey='$upkey'");

}


?>