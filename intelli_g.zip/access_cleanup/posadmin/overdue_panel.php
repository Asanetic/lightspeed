<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');
include('./adminsessionmonitor.php');

$default_home_crumb="";
if(isset($home_crumb))
{
$default_home_crumb=$home_crumb;
}

$start_date=date("Y-m-d", strtotime("-120 days", strtotime(date("Y-m-d"))));
$end_date=date("Y-m-d", strtotime(date("Y-m-d")));

if(isset($_GET['start_date']))
{
	
 $start_date=base64_decode($_GET['start_date']);
 $end_date=base64_decode($_GET['end_date']);

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Overdue clients filter</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
<script type="text/javascript">
var pop_sales_date=`
  <div class="row justify-content-center m-0 p-0 col-md-12">
	<div class="form-group col-md-6 text-left">
		<label >Start Date</label>
		<input class="form-control" id="txt_start_date" name="" value="<?php echo date_time_input("", "date") ?>" placeholder="Your Name" type="date">
	</div>
  	<div class="form-group col-md-6 text-left">
		<label >End Date</label>
		<input class="form-control" id="txt_end_date"  name="" value="<?php echo date_time_input("", "date") ?>" placeholder="Your Name" type="date">
	</div>
  <div class="col-md-7 cpointer btn_neoo2 btn-primary text-center" onclick=" new_location('overdue_panel?start_date=\'+btoa(document.getElementById(\'txt_start_date\').value)+\'&end_date=\'+btoa(document.getElementById(\'txt_end_date\').value)+\'\')"><i class="fa fa-arrow-right"></i> Proceed </div>
  </div>
  `;

var pop_send_sms =`
  
  <div class="form-group col-md-12 text-left  p-0">
	<label >Subject <span class="p-2 border cpointer ml-3" onclick="save_message()"><i class="fa fa-save"></i> Save as draft</span></label>
	<input type="text" name="txt_subject" id="txt_subject" class="form-control" placeholder="Subject"  />
  </div>
  <div class="form-group col-md-12 text-left  p-0">
	<label >Your Message <span class="text-danger" id="error_message"></span></label>
    <input type="hidden" name="txt_msg_date" id="txt_msg_date" class="form-control" placeholder="Msg date"  value="<?php echo date_time_input("", "full");?>" />
	<textarea required class="form-control" name="txt_message" id="txt_message" class="form-control" placeholder="Type Message" style="min-height:200px;"></textarea>
  </div>
<div class="row justify-content-center m-0 p-0 col-md-12">
 <div type="submit" onclick="save_n_send_message()" class="btn btn-primary" > 
   <i class="fa fa-send"></i> Send Message 
 </div>  
</div>
  
  
`;
</script>
</head>

<body>
    <form method="post" enctype="multipart/form-data" id="overdue_list">
	<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">
      <div class="row mt-5 pt-5 justify-content-center pl-1 pr-1">
        
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
                  <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0">
                    <div class="col-md-3 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                    <div class="col-md-5 text-center"> Overdue panel </div>
                    <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>                    
                  </h5>
                  <div class="col-md-12 border p-2 pl-3"><b>Period <?php echo dmy($start_date, "date")." and ".dmy($end_date, "date")  ?></b></div>
                  <!-- End Title ribbon-->
				  <div class="row justify-content-left m-0 p-0 col-md-12  border  mb-3">
        			<div class="col-md-8  ">                    
                    <div class="row justify-content-left m-0 p-0 pt-2 col-md-12">
                    <div onclick="mosy_card('Send SMS to this list', pop_send_sms, '')" class="col-md-3 pr-0 pl-0 btn_neo mb-3 slanted_tray rounded btn btn-primary cpointer"> <i class="fa fa-send"></i> Send SMS to expired </div> 
                    <div onclick="mosy_card('Filter Dates between', pop_sales_date, '')" class="col-md-3 pr-0 pl-0 btn_neo mb-3 ml-lg-3 slanted_tray rounded btn btn-primary cpointer"> <i class="fa fa-calendar"></i> Filter expiry date </div> 
                    <a href="message_board_list" class="col-md-3 pr-0 pl-0 btn_neo mb-3 ml-lg-3 slanted_tray rounded btn btn-primary cpointer"> <i class="fa fa-comments"></i> View sent messages </a> 
                      
                    </div>
                      
                    </div>
        		  </div>        
                  <!-- Start Table -->
                  <div class="table-responsive data-tables" style="padding-bottom: 150px;">
                    <div class="row justify-content-left m-0 p-0 col-md-12 ">                                                        
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent" placeholder="Search client list" name="txt_client_base" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 ml-2" name="qclient_base_btn"><i class="fa fa-search"></i> Go</button>
                     <a href="overdue_panel" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 "><i class="fa fa-refresh mt-1"></i> Refresh </a>       
                     <div class="badge badge-primary p-2 btn_neo cpointer " title="Recompute overdues" onclick="mosy_card('Processing request...', '', '');mosy_form_data('overdue_list', 'sync_expiry_dates', 'mosy_refresh')"><i class="fa fa-bolt mt-1"></i> Refresh overdue data</div>
                     <a href="<?php echo pdf_url('overdue_panel', 'overdue_acc_pdf') ?>" target="_blank" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 ml-3"><i class="fa fa-print mt-1"></i> Print  </a>       
                    </div>
                    <style>
                      .table thead th {
                      white-space: nowrap;
                      }
                    </style>
                  <table class="table table-hover text-left">
                    <thead class="text-uppercase">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Building</th>
                        <th scope="col">Room </th>
                        <th scope="col">Contacts </th>
                        <th scope="col">Package </th>
                        <th scope="col">Package Amt </th>
                        <th scope="col">Last payment </th>
                        <th scope="col">Expiry date</th>
                       </tr>
                    </thead>
                      <tbody>
                        <?php $i=0; $senlist_arr=array();?>
                        <?php $get_client_q=get_client_base("*", " where $gft_client_base_and account_status='active' and DATE_FORMAT(expiry_date, '%Y-%m-%d')>='$start_date' and DATE_FORMAT(expiry_date, '%Y-%m-%d')<='$end_date' order by expiry_date DESC ", "l"); ?>
                        <?php while($get_client_r=mysqli_fetch_array($get_client_q)){ 

      					$client_id=$get_client_r['client_id'];

						$last_trx_date=get_transactions("*", " where client_id='$client_id' order by transaction_date desc", "r");
						$next_expiry=date("Y-m-d", strtotime("+30 days", strtotime($last_trx_date['transaction_date'])));

						$curr_date=date("Y-m-d");
						$exp_date=date("Y-m-d", strtotime($get_client_r['expiry_date']));

						///echo " curr date ".$curr_date." exp date ". $exp_date."<br>";
						if($curr_date>$exp_date){
                        
                        $tel_str='<span class="text-danger" title="'.$get_client_r['client_tel'].'"> Invalid '.magic_strip_if($get_client_r['client_tel'], 15, 15).'</span>';                          
                        if( is_numeric($get_client_r['client_tel']) )
                        {
							$senlist_arr[]=$get_client_r['client_tel'];
                        	$tel_str=$get_client_r['client_tel'];
                        }
											
						$i++;

                          
						?>
                       <tr>
                        <td scope="col"><?php echo $i; ?></td>
                        <td scope="col"><?php echo $get_client_r['building_no']; ?></td>
                        <td scope="col"><?php echo $get_client_r['room_no']; ?></td>
                        <td scope="col"><?php echo $tel_str; ?></td>
                        <td scope="col"><?php echo qpackages_data($get_client_r['package'])['package_name']; ?></td>
                        <td scope="col"><?php echo tonum(qpackages_data($get_client_r['package'])['price']); ?></td>
                        <td scope="col"><?php echo (date("d/m/Y", strtotime($last_trx_date['transaction_date']))) ?></td>
                        <td scope="col"><?php echo date("d/m/Y", strtotime($get_client_r['expiry_date'])); ?></td>                        
                       </tr>
                        <?php } }?>
                      </tbody>
                  </table>

                  </div>
                  <div class="row justify-content-center m-0 p-0 col-md-12 sticky_scroll" >
                  <input type="text" id="txt_to" name="txt_to" class="form-control" value="<?php echo implode(",", $senlist_arr); ?>" placeholder=""/>  
                  </div>                  <!-- End Table -->

          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
<script type="text/javascript">
function popres(serverresp)
{
    
  ///alert(serverresp);
  
}

function confirm_send_message()
{

  
  mosy_form_data('overdue_list', 'send_sms_ajax', 'mosy_refresh');

  mosy_card('Sending Message...', 'If It takes long, please refresh page :)', '');


}
  
function save_n_send_message()
{
  if(document.getElementById('txt_message').value=='')
  {
    push_html('error_message', 'Message Cannot be blank');
  }else{
        
    push_html('error_message', '');
    
    mosy_form_data('overdue_list', 'message_board_insert_btn', 'blackhole');

    magic_yes_no_alert('Send SMS?', 'dialog_box', 'confirm_send_message()', 'mosy_refresh()');


  }
}

function save_message()
{
  if(document.getElementById('txt_message').value=='')
  {
  
    push_html('error_message', 'Message Cannot be blank');
    
  }else{
        
    push_html('error_message', '');
    mosy_form_data('overdue_list', 'message_board_insert_btn', 'mosy_refresh');
    mosy_card('Saving Message...', 'If It takes long, please refresh page :)', '');

  }
}

</script>
  
</form>
</body>
</html>