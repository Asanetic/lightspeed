<?php

ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./data_control/vcf_client_base.php');
include('./adminsessionmonitor.php');;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Client Base</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
	<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">
      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Client Base<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          <!--Start Sql input-->  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./client_base', '<i class="fa fa-arrow-left"></i> Back to list', "");?>

    	<?php echo magic_button_link('./editclient_base?newrecord', '<i class="fa fa-plus"></i> Add new', "");?> 

		<?php if(isset($_GET['client_base_uptoken'])) echo magic_button_link('./editclient_base?after_delete='.base64_encode(magic_current_url()).'&client_base_uptoken='.($_GET["client_base_uptoken"]).'&deleteclient_base','<i class="fa fa-trash"></i> Delete', 'style="background-color:red;"');?>
	</div>     
	<div class="row p-md-3 justify-content-center bg-white col-md-11">
	

<div class="col-md-4">
 <div class="form-group">
  <label >Client Id</label>
  <input class="form-control" id="txt_client_id" name="txt_client_id" value="<?php echo $client_base_node["client_id"];?>" placeholder="Client Id" type="text">
 </div>
 <div class="form-group">
  <label >Client Name</label>
  <input class="form-control" id="txt_client_name" name="txt_client_name" value="<?php echo $client_base_node["client_name"];?>" placeholder="Client Name" type="text">
 </div>
 <div class="form-group">
  <label >Gender</label>
  <input class="form-control" id="txt_gender" name="txt_gender" value="<?php echo $client_base_node["gender"];?>" placeholder="Gender" type="text">
 </div>
 <div class="form-group">
  <label >Client Tel</label>
  <input class="form-control" id="txt_client_tel" name="txt_client_tel" value="<?php echo $client_base_node["client_tel"];?>" placeholder="Client Tel" type="text">
 </div>
 <div class="form-group">
  <label >Client Email</label>
  <input class="form-control" id="txt_client_email" name="txt_client_email" value="<?php echo $client_base_node["client_email"];?>" placeholder="Client Email" type="text">
 </div>
 <div class="form-group">
  <label >City</label>
  <input class="form-control" id="txt_city" name="txt_city" value="<?php echo $client_base_node["city"];?>" placeholder="City" type="text">
 </div>


	</div>

<div class="col-md-4">
 <div class="form-group">
  <label >Location</label>
  <input class="form-control" id="txt_location" name="txt_location" value="<?php echo $client_base_node["location"];?>" placeholder="Location" type="text">
 </div>
 <div class="form-group">
  <label >Building No</label>
  <input class="form-control" id="txt_building_no" name="txt_building_no" value="<?php echo $client_base_node["building_no"];?>" placeholder="Building No" type="text">
 </div>
 <div class="form-group">
  <label >Floor No</label>
  <input class="form-control" id="txt_floor_no" name="txt_floor_no" value="<?php echo $client_base_node["floor_no"];?>" placeholder="Floor No" type="text">
 </div>
 <div class="form-group">
  <label >Room No</label>
  <input class="form-control" id="txt_room_no" name="txt_room_no" value="<?php echo $client_base_node["room_no"];?>" placeholder="Room No" type="text">
 </div>
 <div class="form-group">
  <label >Package</label>
  <input class="form-control" id="txt_package" name="txt_package" value="<?php echo $client_base_node["package"];?>" placeholder="Package" type="text">
 </div>


	</div>

<div class="col-md-4">
 <div class="form-group">
  <label >Package Price</label>
  <input class="form-control" id="txt_package_price" name="txt_package_price" value="<?php echo $client_base_node["package_price"];?>" placeholder="Package Price" type="text">
 </div>
 <div class="form-group">
  <label >Photo</label>
  <input class="form-control" id="txt_photo" name="txt_photo" value="<?php echo $client_base_node["photo"];?>" placeholder="Photo" type="text">
 </div>
 <div class="form-group">
  <label >Installation Date</label>
  <input class="form-control" id="txt_installation_date" name="txt_installation_date" value="<?php echo $client_base_node["installation_date"];?>" placeholder="Installation Date" type="text">
 </div>
 <div class="form-group">
  <label >Signed By</label>
  <input class="form-control" id="txt_signed_by" name="txt_signed_by" value="<?php echo $client_base_node["signed_by"];?>" placeholder="Signed By" type="text">
 </div>
 <div class="form-group">
  <label >Comment</label>
  <input class="form-control" id="txt_comment" name="txt_comment" value="<?php echo $client_base_node["comment"];?>" placeholder="Comment" type="text">
 </div>


	</div>

<div class="col-md-4">
 <div class="form-group">
  <label >Ip Address</label>
  <input class="form-control" id="txt_ip_address" name="txt_ip_address" value="<?php echo $client_base_node["ip_address"];?>" placeholder="Ip Address" type="text">
 </div>
 <div class="form-group">
  <label >Account Status</label>
  <input class="form-control" id="txt_account_status" name="txt_account_status" value="<?php echo $client_base_node["account_status"];?>" placeholder="Account Status" type="text">
 </div>
 <div class="form-group">
  <label >Admin Id</label>
  <input class="form-control" id="txt_admin_id" name="txt_admin_id" value="<?php echo $client_base_node["admin_id"];?>" placeholder="Admin Id" type="text">
 </div>
 <div class="form-group">
  <label >Instdate</label>
  <input class="form-control" id="txt_instdate" name="txt_instdate" value="<?php echo $client_base_node["instdate"];?>" placeholder="Instdate" type="text">
 </div>

</div>
                   
		<div align="center" style="width: 98%">
			<?php if(!isset($_GET['client_base_uptoken'])) echo magic_button("client_base_insert_btn","Proceed","");?>
			<?php if(isset($_GET['client_base_uptoken'])) echo magic_button("client_base_update_btn","Save Changes","");?>
		</div>
		</div>

<!--End Sql input-->
<!--<{ncgh}/>-->

      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>