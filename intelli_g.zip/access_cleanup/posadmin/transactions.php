<?php
ob_start();

include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/transactions.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$start_tx_date_title="";

if(isset($_GET["start_tx_date"])){
$start_tx_date_title="List For Dates Between ".base64_decode($_GET['start_tx_date'])." and ".base64_decode($_GET['end_tx_id']);

}

if(isset($_GET["qclient_id"])){
$start_tx_date_title=" History  For ".qclient_data(base64_decode($_GET['qclient_id']))['client_name'];

}

if(isset($_GET['qmonthly_report']))
{
  $start_tx_date_title=" Report  For ".date("M-Y", strtotime(base64_decode($_GET['qmonthly_report'])));

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Transactions</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Client Payments <?php echo $start_tx_date_title; ?><br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  
    <div align="left" class="col-md-11">
       <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('#', '<i class="fa fa-plus"></i> Record transaction', 'style="display:inline-block;" onclick="pop_client_search()"');?> 
    	<?php echo magic_button_link('./transactions?qstatus=Pending', '<i class="fa fa-bell"></i> Pending Transactions', 'style="display:inline-block;"');?> 
    	<?php echo magic_button_link('./transactions?qstatus=Cleared', '<i class="fa fa-check"></i> Cleared Transactions', 'style="display:inline-block;"');?> 
    	<?php echo magic_button_link('./transactions.php', '<i class="fa fa-refresh"></i> Refresh', 'style="display:inline-block;"');?> 
        <a href="#" onclick="pop_client_search('trx_client')" class="btn btn-primary mb-3"><i class="fa fa-users"></i> Payment By client</a>
        <a href="#" onclick="pop_payment_months('./transactions.php')" class="btn btn-primary mb-3"><i class="fa fa-money"></i> Monthly payments</a>

              <a href="#" onclick="pop_report_date('./transactions', 'Transaction Date', 'trxfilter')"  class="btn btn-primary mb-3"><i class="fa fa-calendar"></i> Filter by date</a>
		<hr><input type="text" placeholder="Search transactions" name="txt_transactions" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button('qtransactions_btn', 'Search', 'style="display:inline-block;"');?> 

	</div>
	<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">
	<table class="table table-hover text-left" id="transactions_data_table">
	    <thead class="text-uppercase">
		   <tr>
		    <th scope="col">#</th>
             <th scope="col">Client</th>
             <th scope="col">Package</th>
             <th scope="col">Pkg_Price</th>
              <th scope="col">Arrears</th>
             <th scope="col">Pkg_Amt_Paid</th>
             <th scope="col">Inst_Charges</th>
             <th scope="col">Charges_Paid</th>
             <th scope="col">New_Bal</th>
             <th scope="col">Month_Year</th>
             <th scope="col">Payment_Date</th>
              <th scope="col">Remark</th>
             <th scope="col">Status</th>
             <th scope="col">Payment_Mode</th>
             <th scope="col">RefNo</th>
             <th scope="col">ClientID</th>

		   </tr>
	    </thead>
	    <tbody>
		<?php 
		$pagination_record_count=$transactions_pgcount;
        $i=0;
        $tot_pkpr=0;
        $tot_pkamt_paid=0;
        $tot_client_btm_charges=0;
        $other_charges_paid_btm=0;
		$pkg_btm_bal=0;
		$new_bal_btm=0;
		while($listtransactions_result=mysqli_fetch_array($transactions_list_query)){
	        $i++;

	        $edit_drop_link=magic_link('./edittransactions.php?transactions_uptoken='.base64_encode($listtransactions_result["primkey"]).'','<i class="fa fa-arrow-right"></i> View more', '');

	        $delete_drop_link=magic_link('./edittransactions.php?transactions_uptoken='.base64_encode($listtransactions_result["primkey"]).'&deletetransactions','<i class="fa fa-trash"></i> Delete', '');

	        $dropdown_items =$delete_drop_link;
          $loop_trx_id=$listtransactions_result['transaction_id'];
          $loop_client_id=$listtransactions_result['client_id'];
          
          $sum_stalltion_charges_q=mysqli_query($mysqliconn , "SELECT SUM(qty*amount) AS TOTCHARGES FROM `$infolinkdb`.`client_charges`  WHERE client_id='$loop_client_id' AND trx_id='$loop_trx_id'");
          $sum_stalltion_charges_r=mysqli_fetch_array($sum_stalltion_charges_q);
		$loop_pkg_price=$listtransactions_result["package_price"];
        if($listtransactions_result["package_price"]==''){
        $loop_pkg_price=0;
        }
        $tot_pkpr=$tot_pkpr+$loop_pkg_price;
        $tot_pkamt_paid=$tot_pkamt_paid+$listtransactions_result["package_amount_paid"];
        $tot_client_btm_charges=$tot_client_btm_charges+$sum_stalltion_charges_r['TOTCHARGES'];
        $other_charges_paid_btm=$other_charges_paid_btm+$listtransactions_result["othercharges_paid"];
		$pkg_btm_bal=$pkg_btm_bal+$listtransactions_result["old_balances"];
		$new_bal_btm=(($listtransactions_result["old_balances"]+$sum_stalltion_charges_r['TOTCHARGES'])-($listtransactions_result["package_amount_paid"]+ $listtransactions_result["othercharges_paid"]));
$curr_client=qclient_data($listtransactions_result["client_id"])['client_name'];
          
          if($curr_client==''){
            $curr_client='Client Record Available';
          }
        ?>
	    <tr>
	    	<td scope="col"><?php echo $i;?></td>
  <td scope="col"><a href="<?php echo './edittransactions.php?transactions_uptoken='.base64_encode($listtransactions_result["primkey"]).''?>" class="nav-link"><?php echo  $curr_client;?>_</a></td>
 <td scope="col"><?php echo qpackage_data($listtransactions_result["package_name"])['package_name'];?></td>
 <td scope="col"><?php echo $listtransactions_result["package_price"];?></td>
 <td scope="col"><?php echo $listtransactions_result["old_balances"];?></td>
 <td scope="col"><?php echo $listtransactions_result["package_amount_paid"];?></td>
 <td scope="col"><?php echo $sum_stalltion_charges_r['TOTCHARGES'];?></td>
 <td scope="col"><?php echo $listtransactions_result["othercharges_paid"];?></td>
 <td scope="col"><?php echo $listtransactions_result["balance"];?></td>
 <td scope="col"><?php echo date("M-Y", strtotime($listtransactions_result["month_year"]));?></td>
 <td scope="col"><?php echo date("d/m/Y", strtotime($listtransactions_result["transaction_date"]))?></td>
   <td scope="col"><?php echo $listtransactions_result["remark"];?></td>

 <td scope="col" class="cpointer" onclick="pop_pay_state('<?php echo $listtransactions_result['primkey'];?>', '<?php echo $listtransactions_result['status'];?>')"><?php echo $listtransactions_result["status"];?></td>
 <td scope="col"><?php echo $listtransactions_result["payment_mode"];?></td>
  <td scope="col"><?php echo $listtransactions_result["transaction_ref"];?></td>
  <td scope="col"><?php echo $listtransactions_result["client_id"];?></td>




	    </tr>
	    <?php }?>
		   <tr>
		    <th scope="col"></th>
 <th scope="col"></th>
 <th scope="col">Totals</th>
 <th scope="col"><?php //echo $tot_pkpr;?></th>
  <th scope="col"><?php //echo $pkg_btm_bal?></th>
 <th scope="col"><?php echo $tot_pkamt_paid?></th>
 <th scope="col"><?php echo $tot_client_btm_charges?></th>
 <th scope="col"><?php echo $other_charges_paid_btm?></th>
 <th scope="col"><?php //echo $new_bal_btm;?></th>
 <th scope="col"></th>
 <th scope="col"></th>
 <th scope="col"></th>
 <th scope="col"></th>
 <th scope="col"></th>

		   </tr>
	    </tbody>
	    </table>
	 <hr>
  
	 <?php include("./pagination.php");?>
	</div>
          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>

  
  
  
  
  
  
  
  
  