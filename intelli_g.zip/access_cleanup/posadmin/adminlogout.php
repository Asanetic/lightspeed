<?php
  
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');

unset($_SESSION['infocms_admin_session']);
unset($_SESSION['infocms_admin_session_username']);
unset($_SESSION['infocms_admin_session_names']);

header('location:./adminlogin.php');


?>