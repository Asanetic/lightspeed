<?php
ob_start();
include("./data_control/conn.php"); 
include("./data_control/phpmagicbits.php"); 
include("./data_control/gwdna.php"); 
include("./data_control/datahandler.php"); 
include("./data_control/requesthandler.php"); 
include("./data_control/customfunctions.php"); 

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$start_date=date("Y-m-d", strtotime("-120 days", strtotime(date("Y-m-d"))));
$end_date=date("Y-m-d", strtotime(date("Y-m-d")));

if(isset($_GET['start_date']))
{
	
 $start_date=base64_decode($_GET['start_date']);
 $end_date=base64_decode($_GET['end_date']);

}

$headerdata_attr=
array(
 "name"=>"Jeoh doe",
'bank_name'=>'John doe',
'account_no'=>'John doe',
'swort_code'=>'John doe',
'pin_no'=>'John doe',
'mobile'=>'John doe',
'supplier_no'=>'John doe'
);
  
$buttonclr="#00008B";

$splithex = str_split(str_replace("#","",$buttonclr), 2);
$r = hexdec($splithex[0]);
$g = hexdec($splithex[1]);
$b = hexdec($splithex[2]);

$style5 = array('width' => 0.25, 'color' => array($r,$g,$b));


$logohead2="./img/logo.png";

$image = imagecreatefrompng($logohead2);


$logohead3= $logohead2;

// Include the main TCPDF library (search for installation path).
require_once("./tcpdf/tcpdf.php");

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->setHeaderData('',0,'','',array(0,0,0), array(255,255,255) );  

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
 $pdf->setImageScale(1.53);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}
// ---------------------------------------------------------
// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', 'B', 12);

// add a page
$pdf->AddPage();

//===================== params =====================================
$bus_name="frm";
$bus_email="";
$bus_tel="";
$sub_headers="";

//===================== params =====================================

$pdf->Line(0, 0, 0, 0, $style5);

//===================== headers =====================================
$pdf->Ln(1);
$pdf->writeHTML('<div align="left"><hr/></div>', true, false, false, false, 'C');

$pdf->Ln(10);

$pdf->StartTransform();

$pdf->Image($logohead3, 14, 8, 25, 25, '','', '', false, 0, '', false, false, 0, false, false, false);
//$pdf->Image($logohead3, left, top, w, h, '','', '', false, 0, '', false, false, 0, false, false, false);

$pdf->StopTransform();


$pdf->SetFont('helvetica', '', 10);

$pdf->SetXY(20, 8);

//$pdf->Cell(0, 9, 'Infolink communications', 0, false, 'R', 0, '', 0, false, 'T', 'M' );


$pdf->SetFont('helvetica', 'b', 11);

//$pdf->Cell(0, 65, $headerdata_attr['supplier_no'], 0, false, 'R', 0, '', 0, false, '', '' );

$pdf->SetXY(40, 29);

$pdf->StopTransform();
//===================== headers =====================================
$pdf->Ln(10);
// ---------------------------------------------------------
//========= Start print table=============================
$pdf->Ln(10);

$pdf->SetFont('helvetica', '', 10);


$headtable='
		<table class="table table-hover text-left" id="invoice_items_data_table" border="0" width="100%">
			<tr style="color:#000; background-color:#FFF; text-align:left;">
				<td colspan="2"><span style="font-weight:bold"> Payee :</span> '. $headerdata_attr["name"].'<br></td>
				<td><b> Date : </b>  '.date("jS, M, Y").'<br></td>
			</tr>
			<tr style="color:#000; background-color:#FFF; text-align:left;">
				<td colspan="2"><b> Bank Name : </b> '.$headerdata_attr["bank_name"].'<br></td>
				<td><b> Account no :  </b>  '.$headerdata_attr["account_no"].'<br></td>
			</tr>
			<tr style="color:#000; background-color:#FFF; text-align:left;">
				<td colspan="2"><b> Swort Code : </b> '.$headerdata_attr["swort_code"].'<br></td>
				<td><b> Pin :  </b> '.$headerdata_attr["pin_no"].'<br></td>
			</tr>
			<tr style="color:#000; background-color:#FFF; text-align:left;">
				<td><b> Supplier Tel : </b>  '.$headerdata_attr["mobile"].'<br></td>
				<td><b> </b></td>
				<td><b> Vendor No :  </b> '.$headerdata_attr["supplier_no"].'<br></td>
			</tr>
	    </table>
	   	<br>';
//$pdf->writeHTML($headtable, true, false, false, false, 'C');
//Put your tballe here
$pdf->SetFont('helvetica', '', 10);

$tbl='<div align="left"> <b> <span style="font-size:18px;">Ovedue client list for period between '.date("d/m/Y", strtotime($start_date)).' and '.date("d/m/Y", strtotime($end_date)).'</span> <hr style="border:1px solid darkblue;"/></div>';

		$tbl.='<table class="table table-hover text-left" id="invoice_items_data_table" border="1" cellpadding="6">
	    <thead class="text-uppercase">
		   <tr style="color:#FFF; background-color:darkblue;">
                        <th scope="col" style="width:5%;">#</th>
                        <th scope="col" style="width:15%;">Building</th>
                        <th scope="col" style="width:15%;">Room </th>
                        <th scope="col" style="width:15%;">Contacts </th>
                        <th scope="col" style="width:15%;">Package </th>
                        <th scope="col" style="width:10%;">Package Amt </th>
                        <th scope="col" style="width:15%;">Last payment </th>
                        <th scope="col" style="width:15%;">Expiry date</th>
                       </tr>
                    </thead>
                      <tbody>';
                         $i=0; $senlist_arr=array();
                         $get_client_q=get_client_base("*", " where $gft_client_base_and account_status='active' and DATE_FORMAT(expiry_date, '%Y-%m-%d')>='$start_date' and DATE_FORMAT(expiry_date, '%Y-%m-%d')<='$end_date' order by expiry_date DESC ", "l");
                         while($get_client_r=mysqli_fetch_array($get_client_q)){ 

      					$client_id=$get_client_r['client_id'];

						$last_trx_date=get_transactions("*", " where client_id='$client_id' order by transaction_date desc", "r");
						$next_expiry=date("Y-m-d", strtotime("+30 days", strtotime($last_trx_date['transaction_date'])));
                        						$curr_date=date("Y-m-d");
						$exp_date=date("Y-m-d", strtotime($get_client_r['expiry_date']));

						///echo " curr date ".$curr_date." exp date ". $exp_date."<br>";
						if($end_date>$exp_date){
                        $tel_str='<span class="text-danger" title="'.$get_client_r['client_tel'].'"> Invalid '.magic_strip_if($get_client_r['client_tel'], 15, 15).'</span>';                          
                        if( is_numeric($get_client_r['client_tel']) )
                        {
							$senlist_arr[]=$get_client_r['client_tel'];
                        	$tel_str=$get_client_r['client_tel'];
                        }
						$i++;

                        ///update_client_base(['expiry_date'=>$next_expiry], "client_id='$client_id'");
						$tbl.='
                       <tr>
                        <td scope="col" style="width:5%;"> '. $i.'</td>
                        <td scope="col" style="width:15%;"> '. $get_client_r['building_no'].'</td>
                        <td scope="col" style="width:15%;"> '. $get_client_r['room_no'].'</td>
                        <td scope="col" style="width:15%;"> '. $tel_str.'</td>
                        <td scope="col" style="width:15%;"> '. qpackages_data($get_client_r['package'])['package_name'].'</td>
                        <td scope="col" style="width:10%;"> '. tonum(qpackages_data($get_client_r['package'])['price']).'</td>
                        <td scope="col" style="width:15%;"> '. (date("d/m/Y", strtotime($last_trx_date['transaction_date']))) .'</td>
                        <td scope="col" style="width:15%;"> '. date("d/m/Y", strtotime($get_client_r['expiry_date'])).'</td>                        
                       </tr>';
                         } 
                         }

                   $tbl.='
                   </tbody>
                  </table>';
//========= End print table=============================


$pdf->writeHTML($tbl, true, false, false, false, 'L');
              
//Close and output PDF document
$pdf->Output('frm.pdf', 'I');

//============================================================ 
// END OF FILE
//============================================================ 

?>