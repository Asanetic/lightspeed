<?php
ob_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/transactions.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$due_date_title="Client Report";

if(isset($_GET["qdue_date"])){
$due_date_title=" due  ".base64_decode($_GET["qdue_date"]);

}

if(isset($_GET["start_date_input"])){
$due_date_title="Client_With_arrears_for_date_between_".base64_decode($_GET["start_date_input"])."_and_".base64_decode($_GET["end_date_input"]);

}

if(isset($_GET['qmonthly_report'])){

$qmonthly_report1=mysqli_real_escape_string($mysqliconn, base64_decode($_GET['qmonthly_report']));

$due_date_title='Monthly Payments Report for '.date('F, Y', strtotime($qmonthly_report1));
}
   

if(isset($_GET["start_tx_date"])){
$due_date_title="Client_Payments_for_date_between_".date("d/m/Y", strtotime(base64_decode($_GET["start_tx_date"])))."_and_".date("d/m/Y", strtotime(base64_decode($_GET["end_tx_id"])));

}


if(isset($_GET["qclient_id"])){
  
$due_date_title="Client_Payment_history_for_".qclient_data(base64_decode($_GET['qclient_id']))['client_name'];
    

}
$filetitile=$due_date_title;

$filename1=str_replace(" ", "_", $filetitile);
$filename=str_replace("/", "_", $filename1);

$buttonclr="#00008b";

$logohead2="./img/logo.png";

$image = imagecreatefrompng($logohead2);
$bg = imagecreatetruecolor(imagesx($image), imagesy($image));
imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
imagealphablending($bg, TRUE);
imagecopy($bg, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
imagedestroy($image);
$quality = 50; 
imagejpeg($bg, $logohead2.".jpg", $quality);
imagedestroy($bg);

$logohead3= $logohead2.".jpg";
$splithex = str_split(str_replace("#","",$buttonclr), 2);
$r = hexdec($splithex[0]);
$g = hexdec($splithex[1]);
$b = hexdec($splithex[2]);
$lineclr=$r . ", " . $g . ", " . $b;


$arrayclr = explode(',', $lineclr);



// Include the main TCPDF library (search for installation path).
require_once("./tcpdf/tcpdf.php");

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
 $pdf->setImageScale(1.53);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}
// ---------------------------------------------------------
// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', 'B', 12);

// add a page
$pdf->AddPage("L", "A4");
$style5 = array('width' => 0.25, 'color' => array($r,$g,$b));
$style4 = array('width' => 0.25, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array($r,$g,$b));

//print_r($splithex);
// Line
// Circle and ellipse
$pdf->SetLineStyle($style4);


// set alpha to semi-transparency
$pdf->SetAlpha(0.1);
//===================== params =====================================


$bus_name="Infolink POS";
$bus_email="";
$bus_tel="";
$sub_headers="Client Payment Report";
//===================== params =====================================

//Start Graphic Transformation
// set bacground image
$pdf->SetAlpha(1);

$pdf->StartTransform();
$pdf->StarPolygon(150, 26, 9, 25, 3, 0, 1, 'CNZ');
$pdf->Image($logohead3, 140, 16, 20, 20, '','', '', false, 0, '', false, false, 0, false, false, false);

$pdf->StopTransform();

$pdf->Ln(10);
$pdf->Write(0, $bus_name, '', 0, 'C', 1, 0, false, false, 0);
$pdf->SetFont('helvetica', '', 10);
$pdf->Ln(3);
$pdf->Write(0, $sub_headers, '', 0, 'C', 1, 0, false, false, 0);
$pdf->Ln(10);


$pdf->SetFont('helvetica', 'b', 10);

$pdf->writeHTML('<div align="left">  '.$filetitile.'<hr/></div>', true, false, false, false, 'C');

$pdf->SetFont('helvetica', '', 8);
$tbl='<table width="100%" border="1" cellpadding="2" cellspacing="0">';

$tbl.='
	    <thead class="text-uppercase">
		   <tr style="background-color:#3CA6EA; color:#FFF;">
		    <th   style="width:5%;">#</th>
 <th   style="width:10%;"  >Client</th>
 <th   style="width:10%;"  >Package</th>
 <th  >Pkg_Price</th>
  <th  >Arrears</th>
 <th  >Pkg_Paid</th>
 <th  >Inst_Chrg</th>
 <th  >Chrg_Paid</th>
 <th  >Bal</th>
 <th  >Mth_Yr</th>
 <th  >Date</th>
 <th  >Mode</th>
 <th  >RefNo</th>

		   </tr>
	    </thead>
	    <tbody>';

        $i=0;
        $tot_pkpr=0;
        $tot_pkamt_paid=0;
        $tot_client_btm_charges=0;
        $other_charges_paid_btm=0;
		$pkg_btm_bal=0;
		$new_bal_btm=0;
		while($listtransactions_result=mysqli_fetch_array($transactions_list_query)){
	        $i++;


          $loop_trx_id=$listtransactions_result['transaction_id'];
          $loop_client_id=$listtransactions_result['client_id'];
          
          $sum_stalltion_charges_q=mysqli_query($mysqliconn , "SELECT SUM(qty*amount) AS TOTCHARGES FROM `$infolinkdb`.`client_charges`  WHERE client_id='$loop_client_id' AND trx_id='$loop_trx_id'");
          $sum_stalltion_charges_r=mysqli_fetch_array($sum_stalltion_charges_q);
		$loop_pkg_price=$listtransactions_result["package_price"];
        if($listtransactions_result["package_price"]==''){
        $loop_pkg_price=0;
        }
        $tot_pkpr=$tot_pkpr+$loop_pkg_price;
        $tot_pkamt_paid=$tot_pkamt_paid+$listtransactions_result["package_amount_paid"];
        $tot_client_btm_charges=$tot_client_btm_charges+$sum_stalltion_charges_r['TOTCHARGES'];
        $other_charges_paid_btm=$other_charges_paid_btm+$listtransactions_result["othercharges_paid"];
		$pkg_btm_bal=$pkg_btm_bal+$listtransactions_result["old_balances"];
		$new_bal_btm=(($listtransactions_result["old_balances"]+$sum_stalltion_charges_r['TOTCHARGES'])-($listtransactions_result["package_amount_paid"]+ $listtransactions_result["othercharges_paid"]));

        
	    $tbl.='<tr>
	    	<td   style="width:5%;">'. $i.'</td>
  <td   style="width:10%;" >'. qclient_data($listtransactions_result["client_id"])['client_name'].'</td>
 <td    style="width:10%;">'. qpackage_data($listtransactions_result["package_name"])['package_name'].'</td>
 <td  >'. $listtransactions_result["package_price"].'</td>
 <td  >'. $listtransactions_result["old_balances"].'</td>
 <td  >'. $listtransactions_result["package_amount_paid"].'</td>
 <td  >'. $sum_stalltion_charges_r['TOTCHARGES'].'</td>
 <td  >'. $listtransactions_result["othercharges_paid"].'</td>
 <td  >'. $listtransactions_result["balance"].'</td>
 <td  >'. date("M-Y", strtotime($listtransactions_result["month_year"])).'</td>
 <td  >'. date("d/m/Y", strtotime($listtransactions_result["transaction_date"])).'</td>
 <td  >'. $listtransactions_result["payment_mode"].'</td>
  <td  >'. $listtransactions_result["transaction_ref"].'</td>


	    </tr>';
	    }
		   $tbl.='<tr style="font-size:14px; font-weight:bold;">
		    <th   style="width:5%;"></th>
 <th  style="width:10%;"   ></th>
 <th  style="width:10%;"   >Totals</th>
 <th  ></th>
  <th  ></th>
 <th  >'. $tot_pkamt_paid.'</th>
 <th  >'. $tot_client_btm_charges.'</th>
 <th  >'. $other_charges_paid_btm.'</th>
 <th  ></th>
 <th  ></th>
 <th  ></th>
 <th  ></th>
 <th  ></th>

		   </tr>';

$tbl.='	</tbody>
	    </table>';

$pdf->writeHTML($tbl, true, false, false, false, 'C');


// ---------------------------------------------------------
//Close and output PDF document
$pdf->Output($filename.'.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+

?>