<?php

ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./data_control/client_base.php');
include('./adminsessionmonitor.php');;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Client Profile</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Client Profile<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
 

<!--Start Sql input-->  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./client_base.php', '<i class="fa fa-arrow-left"></i> Back to list', "");?>

    	<?php echo magic_button_link('./editclient_base.php?newrecord', '<i class="fa fa-plus"></i> Register New Client', "");?> 
    	<?php if(isset($_GET['client_base_uptoken'])) echo magic_button_link('./transactions?qclient_id='.base64_encode($client_base_node['client_id']).'', '<i class="fa fa-history"></i> Payment History', "");?> 
    	<?php if(isset($_GET['client_base_uptoken'])) echo magic_button_link('./edittransactions?client_id='.base64_encode($client_base_node['client_id']).'', '<i class="fa fa-credit-card"></i> Add Payment', "");?> 
	    <?php if(isset($_GET['client_base_uptoken'])) echo magic_button_link('#','<i class="fa fa-times"></i> Inactive Months', 'onclick="pop_manage_active_months(\''.$client_base_node['client_id'].'\')"');?>

		<?php if(isset($_GET['client_base_uptoken'])) echo magic_button_link('./editclient_base.php?client_base_uptoken='.($_GET["client_base_uptoken"]).'&deleteclient_base','<i class="fa fa-trash"></i> Delete', 'style="background-color:red;"');?>
		<?php if(isset($_GET['client_base_uptoken'])) echo magic_button_link('./editclient_base.php?client_base_uptoken='.($_GET["client_base_uptoken"]).'&cloneclient_base','<i class="fa fa-copy"></i> Clone Client Record', 'style="background-color:purple;"');?>

	</div>     
	<div class="row p-md-3 justify-content-center bg-white col-md-11">
	

<div class="col-md-4">
   <div class="form-group">
    <label >Client Name</label>
    <input required class="form-control" id="txt_client_name" name="txt_client_name" value="<?php echo $client_base_node["client_name"];?>" placeholder="Client Name" type="text">
   </div>
   <div class="form-group">
    <label >Client Tel</label>
    <input required class="form-control" id="txt_client_tel" name="txt_client_tel" value="<?php echo $client_base_node["client_tel"];?>" placeholder="Client Tel" type="text">
   </div>
    <div class="form-group">
    <label >Client Email</label>
    <input class="form-control" id="txt_client_email" name="txt_client_email" value="<?php echo $client_base_node["client_email"];?>" placeholder="Client Email" type="text">
   </div>

  <div class="form-group">
    <label >Gender</label>
   <select  class="form-control" id="txt_gender" name="txt_gender" >
   	<option><?php echo $client_base_node["gender"];?></option>
    <option>Male</option>      
    <option>Female</option>      
	</select>
    </div>
  <div class="form-group">
  <label >City</label>
  <input class="form-control" id="txt_city" name="txt_city" value="<?php echo $client_base_node["city"];?>" placeholder="City" type="text">
 </div>
</div>
<div class="col-md-4">
  <div class="form-group">
    <label >Room No</label>
    <input required class="form-control" id="txt_room_no" name="txt_room_no" value="<?php echo $client_base_node["room_no"];?>" placeholder="Room No" type="text">
   </div>
 <div class="form-group">
  <label >Building No</label>
  <input required  class="form-control" id="txt_building_no" name="txt_building_no" value="<?php echo $client_base_node["building_no"];?>" placeholder="Building No" type="text">
 <select name="" class="form-control" onchange="document.getElementById('txt_building_no').value=this.value;">
   <option  value="">Select Building</option>
   <?php $building_list_q = magic_sql_group('client_base', "account_status!='Inactive'", '1000', 'primkey', 'DESC', 'building_no');
while($building_list_r=mysqli_fetch_array($building_list_q[0])){
?>
   <option><?php echo $building_list_r['building_no']?></option>
<?php }?>
</select>
  </div>
 <div class="form-group">
  <label >Floor No</label>
  <input class="form-control" id="txt_floor_no" name="txt_floor_no" value="<?php echo $client_base_node["floor_no"];?>" placeholder="Floor No" type="text">
  <select name="" class="form-control" onchange="document.getElementById('txt_floor_no').value=this.value;">
   <option  value="">Select Floor</option>
   <?php $floor_list_q = magic_sql_group('client_base',  "account_status!='Inactive'", '1000', 'primkey', 'DESC', 'floor_no');
while($floor_list_r=mysqli_fetch_array($floor_list_q[0])){
?>
   <option><?php echo $floor_list_r['floor_no']?></option>
<?php }?>
</select>
  </div>

  <div class="form-group">
  <label >Location</label>
  <input class="form-control" id="txt_location" name="txt_location" value="<?php echo $client_base_node["location"];?>" placeholder="Location" type="text">
  <select name="" class="form-control" onchange="document.getElementById('txt_location').value=this.value;">
   <option  value="">Select Location</option>
   <?php $location_list_q = magic_sql_group('client_base', "", '1000', 'primkey', 'DESC', 'location');
while($location_list_r=mysqli_fetch_array($location_list_q[0])){
?>
   <option><?php echo $location_list_r['location']?></option>
<?php }?>
</select>
  </div>
  <div class="form-group">
  <label >Comment</label>
  <input class="form-control" id="txt_comment" name="txt_comment" value="<?php echo $client_base_node["comment"];?>" placeholder="Comment" type="text">
  </div>
</div>

<div class="col-md-4">
 <div class="form-group">
  <label >Package</label>
  <input required onclick="pop_packages()" onkeyup="pop_packages()" class="form-control" id="txt_package_name" autocomplete="off"  value="<?php echo qpackage_data($client_base_node["package"])['package_name'];?>" placeholder="Package" type="text">
  <input  onclick="pop_packages()" class="form-control" id="txt_package_id" name="txt_package" value="<?php echo $client_base_node["package"];?>" placeholder="Package" type="hidden">
 </div>
 <div class="form-group">
  <label >Package Price</label>
  <input readonly class="form-control" onclick="pop_packages()"  id="txt_package_price" name="txt_package_price" value="<?php echo $client_base_node["package_price"];?>" placeholder="Package Price" type="text">
 </div>
 <div class="form-group">
  <label >Installation Date</label>
  <input  required class="form-control" id="txt_installation_date" name="txt_installation_date" value="<?php if($client_base_node['installation_date']==''){ echo date("Y-m-d");}else{ echo $client_base_node["installation_date"];}?>" placeholder="Installation Date" type="date">
 </div>
 <div class="form-group">
  <label >Signed By</label>
    <select class="form-control"  id="txt_signed_by" name="txt_signed_by">
   <option value="<?php echo $client_base_node['signed_by']?>"><?php echo qteam_data($client_base_node['signed_by'])['username']?></option>
   <?php $drop_down_list_q = magic_sql_group('team', "", '10000', 'primkey', 'DESC', 'user_id');
while($drop_down_list_r=mysqli_fetch_array($drop_down_list_q[0])){
?>
   <option value="<?php echo $drop_down_list_r['user_id']?>"><?php echo $drop_down_list_r['username']?></option>
<?php }?>
</select>
  </div>
   <div class="form-group">
  <label >Account Status</label>
 <select class="form-control" id="txt_account_status" name="txt_account_status">
   <option><?php echo $client_base_node["account_status"];?></option>
   <option>Active</option>
   <option>Inactive</option>
</select>
  </div>
  
</div>

                   
<div align="center" style="width: 98%">
<?php if(!isset($_GET['client_base_uptoken'])) echo magic_button("client_base_insert_btn","Proceed","");?>
<?php if(isset($_GET['client_base_uptoken'])) echo magic_button("client_base_update_btn","Save Changes","");?>
</div>
</div>

<!--End Sql input-->
</div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
