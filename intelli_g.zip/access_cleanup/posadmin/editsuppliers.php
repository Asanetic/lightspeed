<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/suppliers.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Suppliers</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Suppliers<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  <!--Start Sql input-->  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./suppliers.php', '<i class="fa fa-arrow-left"></i> Back to list', "");?>

    	<?php echo magic_button_link('./editsuppliers.php?newrecord', '<i class="fa fa-plus"></i> Add new', "");?> 

		<?php if(isset($_GET['suppliers_uptoken'])) echo magic_button_link('./editsuppliers.php?suppliers_uptoken='.($_GET["suppliers_uptoken"]).'&deletesuppliers','<i class="fa fa-trash"></i> Delete', 'style="background-color:red;"');?>
	</div>     
	<div class="row p-md-3 justify-content-center bg-white col-md-11">
	

<div class="col-md-7">
  <div class="form-group">
  <label >Business Name</label>
  <input class="form-control" id="txt_business_name" name="txt_business_name" value="<?php echo $suppliers_node["business_name"];?>" placeholder="Business Name" type="text">
 </div>
 <div class="form-group">
  <label >Contact Person</label>
  <input class="form-control" id="txt_contact_person" name="txt_contact_person" value="<?php echo $suppliers_node["contact_person"];?>" placeholder="Contact Person" type="text">
 </div>
 <div class="form-group">
  <label >Supplier Tel</label>
  <input class="form-control" id="txt_supplier_tel" name="txt_supplier_tel" value="<?php echo $suppliers_node["supplier_tel"];?>" placeholder="Supplier Tel" type="text">
 </div>
 <div class="form-group">
  <label >Supplier Location</label>
  <input class="form-control" id="txt_supplier_ocation" name="txt_supplier_ocation" value="<?php echo $suppliers_node["supplier_ocation"];?>" placeholder="Supplier Location" type="text">
 </div>



	</div>

<div class="col-md-7">
 <div class="form-group">
  <label >Speciality</label>
  <input class="form-control" id="txt_speciality" name="txt_speciality" value="<?php echo $suppliers_node["speciality"];?>" placeholder="Speciality" type="text">
 </div>
 <div class="form-group">
  <label >Comment</label>
  <input class="form-control" id="txt_comment" name="txt_comment" value="<?php echo $suppliers_node["comment"];?>" placeholder="Comment" type="text">
 </div>

</div>
                   
		<div align="center" style="width: 98%">
			<?php if(!isset($_GET['suppliers_uptoken'])) echo magic_button("suppliers_insert_btn","Proceed","");?>
			<?php if(isset($_GET['suppliers_uptoken'])) echo magic_button("suppliers_update_btn","Save Changes","");?>
		</div>
		</div>

<!--End Sql input-->
<!--<{ncgh}/>-->

          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
