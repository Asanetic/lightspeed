<?php
ob_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/client_base.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

$due_date_title="Client Arrears List";

if(isset($_GET["qdue_date"])){
$due_date_title=" due  ".base64_decode($_GET["qdue_date"]);

}

if(isset($_GET["start_date_input"])){
$due_date_title=" Clients with arrears for date between  ".date("d/m/Y", strtotime(base64_decode($_GET["start_date_input"])))." and ".date("d/m/Y", strtotime(base64_decode($_GET["end_date_input"])));

}

if(isset($_GET["qstart_due_date"])){
$due_date_title=" Clients with due Dates for date between  ".date("d/m/Y", strtotime(base64_decode($_GET["qstart_due_date"])))." and ".date("d/m/Y", strtotime(base64_decode($_GET["qend_due_date"])));

}
$filetitile=$due_date_title;


$buttonclr="#00008b";

$logohead2="./img/logo.png";

$image = imagecreatefrompng($logohead2);
$bg = imagecreatetruecolor(imagesx($image), imagesy($image));
imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
imagealphablending($bg, TRUE);
imagecopy($bg, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
imagedestroy($image);
$quality = 50; 
imagejpeg($bg, $logohead2.".jpg", $quality);
imagedestroy($bg);

$logohead3= $logohead2.".jpg";
$splithex = str_split(str_replace("#","",$buttonclr), 2);
$r = hexdec($splithex[0]);
$g = hexdec($splithex[1]);
$b = hexdec($splithex[2]);
$lineclr=$r . ", " . $g . ", " . $b;


$arrayclr = explode(',', $lineclr);



// Include the main TCPDF library (search for installation path).
require_once("./tcpdf/tcpdf.php");

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
 $pdf->setImageScale(1.53);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}
// ---------------------------------------------------------
// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', 'B', 12);

// add a page
$pdf->AddPage("L", "A4");
$style5 = array('width' => 0.25, 'color' => array($r,$g,$b));
$style4 = array('width' => 0.25, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array($r,$g,$b));

//print_r($splithex);
// Line
// Circle and ellipse
$pdf->SetLineStyle($style4);


// set alpha to semi-transparency
$pdf->SetAlpha(0.1);
//===================== params =====================================


$bus_name="Infolink POS";
$bus_email="";
$bus_tel="";
$sub_headers="Client Arrears List ";
//===================== params =====================================

//Start Graphic Transformation
// set bacground image
$pdf->SetAlpha(1);

$pdf->StartTransform();
$pdf->StarPolygon(150, 26, 9, 25, 3, 0, 1, 'CNZ');
$pdf->Image($logohead3, 140, 16, 20, 20, '','', '', false, 0, '', false, false, 0, false, false, false);

$pdf->StopTransform();

$pdf->Ln(10);
$pdf->Write(0, $bus_name, '', 0, 'C', 1, 0, false, false, 0);
$pdf->SetFont('helvetica', '', 10);
$pdf->Ln(3);
$pdf->Write(0, $sub_headers, '', 0, 'C', 1, 0, false, false, 0);
$pdf->Ln(10);


$pdf->SetFont('helvetica', 'b', 10);

$pdf->writeHTML('<div align="left">  '.$due_date_title.'<hr/></div>', true, false, false, false, 'C');

$pdf->SetFont('helvetica', '', 8);
$tbl='<table width="100%" border="1" cellpadding="2" cellspacing="0">';

$tbl.='
	    <thead class="text-uppercase">
		   <tr style="background-color:#3CA6EA; color:#FFF;">
		    <th   style="width:5%;">#</th>
  <th  >Building</th>
 <th  >Names</th>
 <th  >Room</th>
 <th  style="width:10%;">Package</th>
 <th  >Pkg price</th>
 <th  >Start Date</th>
 <th  >Active Months</th>
 <th  >Inactive Months</th>
 <th  >Total Due</th>
 <th  >Total Paid</th>
 <th  >Pkg Bal</th>
 <th  >Other charges</th>
 <th  >Charges paid</th>
 <th  >Charges Balance</th>
 <th  >Net Arrears</th>
 <th  >Account Status</th>

		   </tr>
	    </thead>
	    <tbody>';

        $pagination_record_count=$client_base_pgcount;
        $i=0;
		while($listclient_base_result=mysqli_fetch_array($client_base_list_query)){
          
          $act_start_date=$listclient_base_result['installation_date'];
          $act_end_date=date("Y-m-d");
          
          if(isset($_GET['end_date_input']))
          {
          $act_start_date=base64_decode($_GET['start_date_input']);
          $act_end_date=base64_decode($_GET['end_date_input']);
          }
          
          
          $tot_pkg_paid=cal_client_payments($act_start_date, $act_end_date,  $listclient_base_result["client_id"]);
		  $tot_inst_charges=cal_client_inst_arrears($act_start_date, $act_end_date, $listclient_base_result["client_id"])[0];
		  $tot_inst_charges_paid=cal_client_inst_arrears($act_start_date, $act_end_date, $listclient_base_result["client_id"])[1];
		  $cpackge_price=qpackage_data($listclient_base_result["package"])['price'];
          

          $active_months= calc_active_months($act_start_date, $act_end_date, $listclient_base_result["client_id"])[0];
          $inactive_months= calc_active_months($act_start_date, $act_end_date, $listclient_base_result["client_id"])[1];
	      $tot_pkg_due=$active_months*$cpackge_price;
          $tot_pack_bal=$tot_pkg_due-$tot_pkg_paid;
          $inst_charge_bal=$tot_inst_charges-$tot_inst_charges_paid;
          
          if($inst_charge_bal=='')
          {
           $inst_charge_bal=0; 
          }
          
           if($tot_pack_bal=='')
          {
           $tot_pack_bal=0; 
          }

          $net_arrears=$inst_charge_bal+$tot_pack_bal;

          if($net_arrears>0){
	        $i++;

	    $tbl.='
        	    <tr>
	    	<td   style="width:5%;">'.$i.'</td>
 <td  >'.$listclient_base_result["building_no"].'</td>
 <td  >'.$listclient_base_result["client_name"].'</td>
 <td  >'.$listclient_base_result["room_no"].'</td>
 <td  style="width:10%;">'. qpackage_data($listclient_base_result["package"])['package_name'].'</td>
  <td  >'. $cpackge_price.'</td>
 <td  >'.date("d/m/Y", strtotime($act_start_date)).'</td>
 <td  >'.$active_months.'</td>
 <td  >'.$inactive_months.'</td>
 <td  >'.$tot_pkg_due.'</td>
 <td  >'.$tot_pkg_paid.'</td>
 <td  >'.$tot_pack_bal.'</td>
 <td  >'.$tot_inst_charges.'</td>
 <td  >'.$tot_inst_charges_paid.'</td>
 <td  >'.$inst_charge_bal.'</td>
 <td  >'.($inst_charge_bal+$tot_pack_bal).'</td>
 <td  >'.$listclient_base_result["account_status"].'
 </td>

	    </tr>';
	    }
        }
$tbl.='	</tbody>
	    </table>';

$pdf->writeHTML($tbl, true, false, false, false, 'C');


// ---------------------------------------------------------
//Close and output PDF document
$pdf->Output('infolinkpos_client_base_list.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+

?>