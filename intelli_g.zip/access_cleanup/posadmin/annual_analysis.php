<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/client_base.php');
include('./data_control/datafeed.php');
include('./adminsessionmonitor.php');

function compute_annual_monthy_payment($client_id, $month_year)
{
  
  global $compute_annual_monthy_payment;
  global $single_conn;
  global $single_db;
  
  $formated_ym= date("Y-m", strtotime($month_year));
  $formated_fy= date("M-Y", strtotime($month_year));
  
  $compute_annual_monthy_payment=  magic_sql_sum('transactions', 'package_amount_paid', "client_id='$client_id' AND month_year='$formated_fy'");
  
  $check_if_month_active = magic_sql_count('active_client_months', "*", "client_id='$client_id' AND month_year='$formated_ym'");
  
  return array($compute_annual_monthy_payment, $tot_charges_paid);
}

$trx_year=date("Y");

if(isset($_GET['trx_year'])){

$trx_year=base64_decode($_GET['trx_year']);

}

//echo $trx_year;

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


$logoimg='./img/logo.png';

$buttonclr="#00008b";
$buttontxtclr ="#FFF";

$logohead2="./img/logo.png";

$image = imagecreatefrompng($logohead2);
$bg = imagecreatetruecolor(imagesx($image), imagesy($image));
imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
imagealphablending($bg, TRUE);
imagecopy($bg, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
imagedestroy($image);
$quality = 50; 
imagejpeg($bg, $logohead2.".jpg", $quality);
imagedestroy($bg);

$logohead3= $logohead2.".jpg";
$splithex = str_split(str_replace("#","",$buttonclr), 2);
$r = hexdec($splithex[0]);
$g = hexdec($splithex[1]);
$b = hexdec($splithex[2]);
$lineclr=$r . ", " . $g . ", " . $b;


$arrayclr = explode(',', $lineclr);



// Include the main TCPDF library (search for installation path).
require_once("./tcpdf/tcpdf.php");

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
 $pdf->setImageScale(1.53);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}
// ---------------------------------------------------------
// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', 'B', 12);

// add a page
$pdf->AddPage("L", "A4");
$style5 = array('width' => 0.25, 'color' => array($r,$g,$b));
$style4 = array('width' => 0.25, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array($r,$g,$b));

//print_r($splithex);
// Line
// Circle and ellipse
$pdf->SetLineStyle($style4);


// set alpha to semi-transparency
$pdf->SetAlpha(0.1);
//===================== params =====================================


$bus_name="Infolink POS";
$bus_email="";
$bus_tel="";
$sub_headers="Client List";
//===================== params =====================================

//Start Graphic Transformation
// set bacground image
$pdf->SetAlpha(1);

$pdf->StartTransform();
$pdf->StarPolygon(150, 26, 9, 25, 3, 0, 1, 'CNZ');
$pdf->Image($logohead3, 140, 16, 20, 20, '','', '', false, 0, '', false, false, 0, false, false, false);

$pdf->StopTransform();

$pdf->Ln(10);
$pdf->Write(0, $bus_name, '', 0, 'C', 1, 0, false, false, 0);
$pdf->SetFont('helvetica', '', 10);
$pdf->Ln(3);
$pdf->Write(0, $sub_headers, '', 0, 'C', 1, 0, false, false, 0);
$pdf->Ln(10);


$pdf->SetFont('helvetica', 'b', 10);

$pdf->writeHTML('<div align="left"> Client List Annual Report for year '.$trx_year.'<hr/></div>', true, false, false, false, 'C');

$pdf->SetFont('helvetica', '', 8);
$tbl='<table width="100%" border="1" cellpadding="2" cellspacing="0">';

$tbl.='
<tr style="color:'.$buttontxtclr.';" bgcolor="'.$buttonclr.'">
<th  >#</th>
<th  >Client name</th>
<th  >Mobile</th>
<th  >Jan</th>
<th  >Feb</th>
<th  >Mar</th>
<th  >Apr</th>
<th  >May</th>
<th  >Jun</th>
<th  >Jul</th>
<th  >Aug</th>
<th  >Sept</th>
<th  >Oct</th>
<th  >Nov</th>
<th  >Dec</th>
</tr>';

$jan_tot_base=0;
$feb_tot_base=0;
$mar_tot_base=0;
$apr_tot_base=0;
$may_tot_base=0;
$jun_tot_base=0;
$jul_tot_base=0;
$aug_tot_base=0;
$sep_tot_base=0;
$oct_tot_base=0;
$nov_tot_base=0;
$dec_tot_base=0;

$i=0;
$all_clients_q=mysqli_query($mysqliconn , "SELECT * FROM `$single_db`.`client_base`");
while($sellike_client_base_res=mysqli_fetch_array($all_clients_q)){
    $i++;
$package_name=qpackage_data($sellike_client_base_res['package']);

$curr_client_id=$sellike_client_base_res['client_id'];

$jan_tot=compute_annual_monthy_payment( $curr_client_id, 'Jan-'.$trx_year.'')[0];
$feb_tot=compute_annual_monthy_payment( $curr_client_id, 'Feb-'.$trx_year.'')[0];
$mar_tot=compute_annual_monthy_payment( $curr_client_id, 'Mar-'.$trx_year.'')[0];
$apr_tot=compute_annual_monthy_payment( $curr_client_id, 'Apr-'.$trx_year.'')[0];
$may_tot=compute_annual_monthy_payment( $curr_client_id, 'May-'.$trx_year.'')[0];
$jun_tot=compute_annual_monthy_payment( $curr_client_id, 'Jun-'.$trx_year.'')[0];
$jul_tot=compute_annual_monthy_payment( $curr_client_id, 'Jul-'.$trx_year.'')[0];
$aug_tot=compute_annual_monthy_payment( $curr_client_id, 'Aug-'.$trx_year.'')[0];
$sep_tot=compute_annual_monthy_payment( $curr_client_id, 'Sep-'.$trx_year.'')[0];
$oct_tot=compute_annual_monthy_payment( $curr_client_id, 'Oct-'.$trx_year.'')[0];
$nov_tot=compute_annual_monthy_payment( $curr_client_id, 'Nov-'.$trx_year.'')[0];
$dec_tot=compute_annual_monthy_payment( $curr_client_id, 'Dec-'.$trx_year.'')[0];

 // echo "Jan totos ".$jan_tot;

$jan_tot_base=$jan_tot_base+$jan_tot;
$feb_tot_base=$feb_tot_base+$feb_tot;
$mar_tot_base=$mar_tot_base+$mar_tot;
$apr_tot_base=$apr_tot_base+$apr_tot;
$may_tot_base=$may_tot_base+$may_tot;
$jun_tot_base=$jun_tot_base+$jun_tot;
$jul_tot_base=$jul_tot_base+$jul_tot;
$aug_tot_base=$aug_tot_base+$aug_tot;
$sep_tot_base=$sep_tot_base+$aug_tot;
$oct_tot_base=$oct_tot_base+$oct_tot;
$nov_tot_base=$nov_tot_base+$nov_tot;
$dec_tot_base=$dec_tot_base+$dec_tot;


$tbl.='<tr>

<td  >'.$i.'</td>
<td  >'.$sellike_client_base_res["client_name"].'</td>
<td  >'.$sellike_client_base_res["client_tel"].'</td>
<td  >'.$jan_tot.'</td>
<td  >'.$feb_tot.'</td>
<td  >'.$mar_tot.'</td>
<td  >'.$apr_tot.'</td>
<td  >'.$may_tot.'</td>
<td  >'.$jun_tot.'</td>
<td  >'.$jul_tot.'</td>
<td  >'.$aug_tot.'</td>
<td  >'.$sep_tot.'</td>
<td  >'.$oct_tot.'</td>
<td  >'.$nov_tot.'</td>
<td  >'.$dec_tot.'</td>

</tr>';
}

$tbl.='
<tr style="color:'.$buttontxtclr.';" bgcolor="'.$buttonclr.'"  nobr="true">

<td></td>
<td>'.$sellike_client_base_res["client_name"].'</td>
<td>'.$sellike_client_base_res["client_tel"].'</td>
<td>'.$jan_tot_base.'</td>
<td>'.$feb_tot_base.'</td>
<td>'.$mar_tot_base.'</td>
<td>'.$apr_tot_base.'</td>
<td>'.$may_tot_base.'</td>
<td>'.$jun_tot_base.'</td>
<td>'.$jul_tot_base.'</td>
<td>'.$aug_tot_base.'</td>
<td>'.$sep_tot_base.'</td>
<td>'.$oct_tot_base.'</td>
<td>'.$nov_tot_base.'</td>
<td>'.$dec_tot_base.'</td>

</tr>';

$tbl.='</table>';
$pdf->writeHTML($tbl, true, false, false, false, '');



// ---------------------------------------------------------
//Close and output PDF document
$pdf->Output('infolinkpos_client_base_list.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+

?>