





if(isset($_GET["qtransactions"])){


$qtransactions=mysqli_real_escape_string($mysqliconn, base64_decode($_GET["qtransactions"]));


//===== limit record value

$transactions_sqlstring="SELECT COUNT(*) FROM transactions LEFT JOIN  client_base ON client_base.client_id=client.transactions  WHERE (client_base.primkey LIKE '%".$qtransactions."%' OR  client_base.client_id LIKE '%".$qtransactions."%' OR  client_base.client_name LIKE '%".$qtransactions."%' OR  client_base.gender LIKE '%".$qtransactions."%' OR  client_base.client_tel LIKE '%".$qtransactions."%' OR  client_base.client_email LIKE '%".$qtransactions."%' OR  client_base.city LIKE '%".$qtransactions."%' OR  client_base.location LIKE '%".$qtransactions."%' OR  client_base.building_no LIKE '%".$qtransactions."%' OR  client_base.floor_no LIKE '%".$qtransactions."%' OR  client_base.room_no LIKE '%".$qtransactions."%' OR  client_base.package LIKE '%".$qtransactions."%' OR  client_base.package_price LIKE '%".$qtransactions."%' OR  client_base.photo LIKE '%".$qtransactions."%' OR  client_base.installation_date LIKE '%".$qtransactions."%' OR  client_base.signed_by LIKE '%".$qtransactions."%' OR  client_base.comment LIKE '%".$qtransactions."%' OR  client_base.ip_address LIKE '%".$qtransactions."%' OR  client_base.account_status LIKE '%".$qtransactions."%' OR  client_base.admin_id LIKE '%".$qtransactions."%' OR  client_base.instdate LIKE '%".$qtransactions."%'  OR transactions.primkey LIKE '%".$qtransactions."%' OR  transactions.transaction_id LIKE '%".$qtransactions."%' OR  transactions.transaction_ref LIKE '%".$qtransactions."%' OR  transactions.package_name LIKE '%".$qtransactions."%' OR  transactions.package_price LIKE '%".$qtransactions."%' OR  transactions.amount_paid LIKE '%".$qtransactions."%' OR  transactions.balance LIKE '%".$qtransactions."%' OR  transactions.transaction_type LIKE '%".$qtransactions."%' OR  transactions.transaction_date LIKE '%".$qtransactions."%' OR  transactions.month_year LIKE '%".$qtransactions."%' OR  transactions.client_id LIKE '%".$qtransactions."%' OR  transactions.received_by LIKE '%".$qtransactions."%' OR  transactions.confirmed_by LIKE '%".$qtransactions."%' OR  transactions.remark LIKE '%".$qtransactions."%' OR  transactions.status LIKE '%".$qtransactions."%' OR  transactions.admin_id LIKE '%".$qtransactions."%' OR  transactions.old_balances LIKE '%".$qtransactions."%' OR  transactions.total_due LIKE '%".$qtransactions."%' OR  transactions.discount LIKE '%".$qtransactions."%' OR  transactions.payment_mode LIKE '%".$qtransactions."%' OR  transactions.installation_fee LIKE '%".$qtransactions."%' OR  transactions.trxdate LIKE '%".$qtransactions."%' OR  transactions.package_amount_paid LIKE '%".$qtransactions."%' OR  transactions.othercharges_paid LIKE '%".$qtransactions."%')";

//===== Pagination function

$transactions_pagination= list_record_per_page($mysqliconn, $transactions_sqlstring, $datalimit);


//===== get return values


$transactions_firstproduct=$transactions_pagination["0"];

$transactions_pgcount=$transactions_pagination["1"];

//=== start transactions select  LEFT JOIN Query for transactions as main table and child client_base list  

$transactions_list_query=mysqli_query($mysqliconn, "SELECT  client_base.primkey ,  client_base.client_id ,  client_base.client_name ,  client_base.gender ,  client_base.client_tel ,  client_base.client_email ,  client_base.city ,  client_base.location ,  client_base.building_no ,  client_base.floor_no ,  client_base.room_no ,  client_base.package ,  client_base.package_price ,  client_base.photo ,  client_base.installation_date ,  client_base.signed_by ,  client_base.comment ,  client_base.ip_address ,  client_base.account_status ,  client_base.admin_id ,  client_base.instdate , transactions.primkey ,  transactions.transaction_id ,  transactions.transaction_ref ,  transactions.package_name ,  transactions.package_price ,  transactions.amount_paid ,  transactions.balance ,  transactions.transaction_type ,  transactions.transaction_date ,  transactions.month_year ,  transactions.client_id ,  transactions.received_by ,  transactions.confirmed_by ,  transactions.remark ,  transactions.status ,  transactions.admin_id ,  transactions.old_balances ,  transactions.total_due ,  transactions.discount ,  transactions.payment_mode ,  transactions.installation_fee ,  transactions.trxdate ,  transactions.package_amount_paid ,  transactions.othercharges_paid FROM  transactions LEFT JOIN  client_base ON client_base.client_id=client.transactions   WHERE (client_base.primkey LIKE '%".$qtransactions."%' OR  client_base.client_id LIKE '%".$qtransactions."%' OR  client_base.client_name LIKE '%".$qtransactions."%' OR  client_base.gender LIKE '%".$qtransactions."%' OR  client_base.client_tel LIKE '%".$qtransactions."%' OR  client_base.client_email LIKE '%".$qtransactions."%' OR  client_base.city LIKE '%".$qtransactions."%' OR  client_base.location LIKE '%".$qtransactions."%' OR  client_base.building_no LIKE '%".$qtransactions."%' OR  client_base.floor_no LIKE '%".$qtransactions."%' OR  client_base.room_no LIKE '%".$qtransactions."%' OR  client_base.package LIKE '%".$qtransactions."%' OR  client_base.package_price LIKE '%".$qtransactions."%' OR  client_base.photo LIKE '%".$qtransactions."%' OR  client_base.installation_date LIKE '%".$qtransactions."%' OR  client_base.signed_by LIKE '%".$qtransactions."%' OR  client_base.comment LIKE '%".$qtransactions."%' OR  client_base.ip_address LIKE '%".$qtransactions."%' OR  client_base.account_status LIKE '%".$qtransactions."%' OR  client_base.admin_id LIKE '%".$qtransactions."%' OR  client_base.instdate LIKE '%".$qtransactions."%'  OR transactions.primkey LIKE '%".$qtransactions."%' OR  transactions.transaction_id LIKE '%".$qtransactions."%' OR  transactions.transaction_ref LIKE '%".$qtransactions."%' OR  transactions.package_name LIKE '%".$qtransactions."%' OR  transactions.package_price LIKE '%".$qtransactions."%' OR  transactions.amount_paid LIKE '%".$qtransactions."%' OR  transactions.balance LIKE '%".$qtransactions."%' OR  transactions.transaction_type LIKE '%".$qtransactions."%' OR  transactions.transaction_date LIKE '%".$qtransactions."%' OR  transactions.month_year LIKE '%".$qtransactions."%' OR  transactions.client_id LIKE '%".$qtransactions."%' OR  transactions.received_by LIKE '%".$qtransactions."%' OR  transactions.confirmed_by LIKE '%".$qtransactions."%' OR  transactions.remark LIKE '%".$qtransactions."%' OR  transactions.status LIKE '%".$qtransactions."%' OR  transactions.admin_id LIKE '%".$qtransactions."%' OR  transactions.old_balances LIKE '%".$qtransactions."%' OR  transactions.total_due LIKE '%".$qtransactions."%' OR  transactions.discount LIKE '%".$qtransactions."%' OR  transactions.payment_mode LIKE '%".$qtransactions."%' OR  transactions.installation_fee LIKE '%".$qtransactions."%' OR  transactions.trxdate LIKE '%".$qtransactions."%' OR  transactions.package_amount_paid LIKE '%".$qtransactions."%' OR  transactions.othercharges_paid LIKE '%".$qtransactions."%') ORDER BY transactions.primkey DESC LIMIT $transactions_firstproduct, $datalimit" );


//=== End transactions select  LEFT JOIN Query for transactions as main table and child client_base list


}

//--<{ncgh}/>