<?php

ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./data_control/expenses.php');
include('./adminsessionmonitor.php');



$formatted_date=date("Y-m-d\TH:i:s", strtotime($expenses_node['transaction_date']));

if($expenses_node['transaction_date']=='')
{

  $formatted_date=date("Y-m-d\TH:i:s");
  
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Expenses</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h4 class="col-md-12" style="text-align: center;">Expenses<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          <!--Start Sql input-->  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET['table_alert'])) echo magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF'); ?>
    	</div>
    	<?php echo magic_button_link('./expenses.php', '<i class="fa fa-arrow-left"></i> Back to list', "");?>

    	<?php echo magic_button_link('./editexpenses.php?newrecord', '<i class="fa fa-plus"></i> Add new', "");?> 

		<?php if(isset($_GET['expenses_uptoken'])) echo magic_button_link('./editexpenses.php?expenses_uptoken='.($_GET["expenses_uptoken"]).'&deleteexpenses','<i class="fa fa-trash"></i> Delete', 'style="background-color:red;"');?>
	</div>     
	<div class="row p-md-3 justify-content-center bg-white col-md-11">
	

<div class="col-md-4">
 <div class="form-group">
  <label >Transaction Ref</label>
  <input class="form-control" id="txt_transaction_ref" name="txt_transaction_ref" value="<?php echo $expenses_node["transaction_ref"];?>" placeholder="Transaction Ref" type="text">
 </div>
 <div class="form-group">
  <label >Amount Paid</label>
  <input class="form-control" id="txt_amount_paid" name="txt_amount_paid" value="<?php echo $expenses_node["amount_paid"];?>" placeholder="Amount Paid" type="number">
 </div>
 <div class="form-group">
  <label >Transaction Type</label>
  <input class="form-control" id="txt_transaction_type" name="txt_transaction_type" value="<?php echo $expenses_node["transaction_type"];?>" placeholder="Transaction Type" type="text">
  <select name="" class="form-control" onchange="document.getElementById('txt_transaction_type').value=this.value;">
       <option  value="">Select Transaction Type</option>
       <?php $drop_down_list_q = magic_sql_group('expenses', "", '1000', 'primkey', 'DESC', 'transaction_type');
    while($drop_down_list_r=mysqli_fetch_array($drop_down_list_q[0])){
    ?>
       <option><?php echo $drop_down_list_r['transaction_type']?></option>
    <?php }?>
  </select>
 </div>
 <div class="form-group">
  <label >Transaction Date</label>
  <input class="form-control" id="txt_transaction_date" name="txt_transaction_date" value="<?php echo $formatted_date;?>" placeholder="Transaction Date" type="datetime-local">
 </div>



	</div>

  <div class="col-md-4">
   <div class="form-group">
    <label >Remark</label>
    <textarea class="form-control" id="txt_remark" name="txt_remark"  placeholder="Remark" style="min-height:200px;"><?php echo $expenses_node["remark"];?></textarea>
  </div>
 <div class="form-group">
  <label >Payment Mode</label>
  <input class="form-control" id="txt_payment_mode" name="txt_payment_mode" value="<?php echo $expenses_node["payment_mode"];?>" placeholder="Payment Mode" type="text">
 </div>
 </div>

                   
		<div align="center" style="width: 98%">
			<?php if(!isset($_GET['expenses_uptoken'])) echo magic_button("expenses_insert_btn","Proceed","");?>
			<?php if(isset($_GET['expenses_uptoken'])) echo magic_button("expenses_update_btn","Save Changes","");?>
		</div>
		</div>

<!--End Sql input-->
<!--<{ncgh}/>-->

      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
