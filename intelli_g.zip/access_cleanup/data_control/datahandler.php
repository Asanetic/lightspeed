<?php 
//===============Start Mosy queries-============ 

    
 	//Start Add intelli_guard Data ===============
 	function add_intelli_guard($intelli_guard_arr_)
    {
     $gw_intelli_guard_cols=array();
     
     foreach($intelli_guard_arr_ as $intelli_guard_arr_gw => $intelli_guard_arr_gw_val)
     {
     
     	$gw_intelli_guard_cols[]=$intelli_guard_arr_gw;
        
     }
     
     $gw_intelli_guard_cols_str=implode(",", $gw_intelli_guard_cols);
     
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "insert",$gw_intelli_guard_cols_str);
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("intelli_guard", $intelli_guard_arr_);
     
     	//echo $gwauthenticate_intelli_guard_;

     }else{
     
     	echo $gwauthenticate_intelli_guard_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");

     }
     
    }
    
       function initialize_intelli_guard()
        {
        
         global $intelli_guard_uptoken;
             
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "select","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {
         
         	return get_intelli_guard("*", "WHERE primkey='$intelli_guard_uptoken'", "r");
         
            echo $gwauthenticate_intelli_guard_;

         }else{

         	echo $gwauthenticate_intelli_guard_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");
         
         }
        }   
    //End Add intelli_guard Data ===============
                
    //Start Update intelli_guard Data ===============
    
 	function update_intelli_guard($intelli_guard_arr_, $where_str)
    {
         $gw_intelli_guard_cols=array();
     
     foreach($intelli_guard_arr_ as $intelli_guard_arr_gw => $intelli_guard_arr_gw_val)
     {
     
     	$gw_intelli_guard_cols[]=$intelli_guard_arr_gw;
        
     }
     
     $gw_intelli_guard_cols_str=implode(",", $gw_intelli_guard_cols);
     
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "update",$gw_intelli_guard_cols_str);
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("intelli_guard", $intelli_guard_arr_, $where_str);

       // echo $gwauthenticate_intelli_guard_;
        
        exit;

     }else{

        echo $gwauthenticate_intelli_guard_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");


      }
    
    }
 	
    
    //End Update intelli_guard Data ===============

    //Start get  intelli_guard Data ===============
    
    function get_intelli_guard($colstr, $where_str, $type)
    {
          
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "select","");
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {
    	return mosyflex_sel("intelli_guard", $colstr, $where_str, $type);

        //echo $gwauthenticate_intelli_guard_;

	  }else{
     
     	echo $gwauthenticate_intelli_guard_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");


     }    
    }
    //End get  intelli_guard Data ===============
    
    
    //======== qintelli_guard_data qsingle query function
    
    function qintelli_guard_data($qflagkey_key)
    {
          
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "qdata","");
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {    
    	return get_intelli_guard("*", "WHERE flagkey='$qflagkey_key'", "r");

		//echo $gwauthenticate_intelli_guard_;

      }else{
     
     	echo $gwauthenticate_intelli_guard_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");


     }  
    }
   
    //======== qintelli_guard_data qsingle query function
    
    
     //======== intelli_guard data to array
    
    function intelli_guard_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "data_array","");
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {  
     	$append_intelli_guard_arr=array();
    
    	$array_intelli_guard_q=get_intelli_guard($colstr, $where_str, "l");
        while($array_intelli_guard_res=mysqli_fetch_array($array_intelli_guard_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_intelli_guard_arr[]=$array_intelli_guard_res[$tbl_col];
            }
          }else{
          	          
               $append_intelli_guard_arr[]=$array_intelli_guard_res;

          }
        }
        
        return $append_intelli_guard_arr;

		//echo $gwauthenticate_intelli_guard_;

      }else{
     
     	echo $gwauthenticate_intelli_guard_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");


     }  
    }
   
    //======== qintelli_guard_data qsingle query function   
        
    //======== qintelli_guard_ddata qsingle query function    
    function qintelli_guard_ddata($flagkey_col, $qflagkey_key)
    {
     
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "qddata","");
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {    
    	return get_intelli_guard("*", "WHERE $flagkey_col='$qflagkey_key'", "r");

		//echo $gwauthenticate_intelli_guard_;

     }else{
     
     	echo $gwauthenticate_intelli_guard_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");


     }   
    }
    //======== qintelli_guard_ddata qsingle query function
    
        //======== qintelli_guard_gdata qsingle query function    
    function qintelli_guard_gdata($intelli_guard_where="")
    {
     
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "gddata","");
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {    
     	$where_str="";
        if($intelli_guard_where!=="")
        {
        $where_str=" ".$intelli_guard_where;
        }
    	return get_intelli_guard("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_intelli_guard_;

     }else{
     
     	echo $gwauthenticate_intelli_guard_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");


     }   
    }
    //======== qintelli_guard_gdata qsingle query function
    

    //======== count intelli_guard data function
    
    function count_intelli_guard($intelli_guard_wherestr)
    {
     
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "count_data","");
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {    
      $clean_intelli_guard_where_str="";
  
      if($intelli_guard_wherestr!='')
      {
        $clean_intelli_guard_where_str="Where ".$intelli_guard_wherestr;
      }

      return get_intelli_guard("count(*) as return_result", " ".$clean_intelli_guard_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_intelli_guard_;

      }else{
     
     	echo $gwauthenticate_intelli_guard_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");


     }    
    }
    //======== count intelli_guard data function

    //======== sum  intelli_guard data function
    
    function sum_intelli_guard($intelli_guard_sumcol, $intelli_guard_wherestr)
    {
     
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "sum_data","");
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {    
      $clean_intelli_guard_where_str="";
  
      if($intelli_guard_wherestr!='')
      {
        $clean_intelli_guard_where_str="Where ".$intelli_guard_wherestr;
      }

      return get_intelli_guard("sum($intelli_guard_sumcol) as return_result", " ".$clean_intelli_guard_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_intelli_guard_;


      }else{
     
     	echo $gwauthenticate_intelli_guard_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");
        


     }    
    }
    
    //======== sum  intelli_guard data function   
    
    
    //Start drop  intelli_guard Data ===============
    
    function drop_intelli_guard($where_str)
    {
     
     $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "drop_data","");
     
     $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
     
     if($gwauthenticate_intelli_guard_json["response"]=="ok")
     {    
    	return magic_sql_delete("intelli_guard", $where_str);

		//echo $gwauthenticate_intelli_guard_;

      }else{
     
     	echo $gwauthenticate_intelli_guard_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");
		

     }
    }
    //End drop  intelli_guard Data ===============    
    
    
   

    
 	//Start Add intelli_guard_inventory Data ===============
 	function add_intelli_guard_inventory($intelli_guard_inventory_arr_)
    {
     $gw_intelli_guard_inventory_cols=array();
     
     foreach($intelli_guard_inventory_arr_ as $intelli_guard_inventory_arr_gw => $intelli_guard_inventory_arr_gw_val)
     {
     
     	$gw_intelli_guard_inventory_cols[]=$intelli_guard_inventory_arr_gw;
        
     }
     
     $gw_intelli_guard_inventory_cols_str=implode(",", $gw_intelli_guard_inventory_cols);
     
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "insert",$gw_intelli_guard_inventory_cols_str);
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("intelli_guard_inventory", $intelli_guard_inventory_arr_);
     
     	//echo $gwauthenticate_intelli_guard_inventory_;

     }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");

     }
     
    }
    
       function initialize_intelli_guard_inventory()
        {
        
         global $intelli_guard_inventory_uptoken;
             
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "select","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {
         
         	return get_intelli_guard_inventory("*", "WHERE primkey='$intelli_guard_inventory_uptoken'", "r");
         
            echo $gwauthenticate_intelli_guard_inventory_;

         }else{

         	echo $gwauthenticate_intelli_guard_inventory_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");
         
         }
        }   
    //End Add intelli_guard_inventory Data ===============
                
    //Start Update intelli_guard_inventory Data ===============
    
 	function update_intelli_guard_inventory($intelli_guard_inventory_arr_, $where_str)
    {
         $gw_intelli_guard_inventory_cols=array();
     
     foreach($intelli_guard_inventory_arr_ as $intelli_guard_inventory_arr_gw => $intelli_guard_inventory_arr_gw_val)
     {
     
     	$gw_intelli_guard_inventory_cols[]=$intelli_guard_inventory_arr_gw;
        
     }
     
     $gw_intelli_guard_inventory_cols_str=implode(",", $gw_intelli_guard_inventory_cols);
     
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "update",$gw_intelli_guard_inventory_cols_str);
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("intelli_guard_inventory", $intelli_guard_inventory_arr_, $where_str);

       // echo $gwauthenticate_intelli_guard_inventory_;
        
        exit;

     }else{

        echo $gwauthenticate_intelli_guard_inventory_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");


      }
    
    }
 	
    
    //End Update intelli_guard_inventory Data ===============

    //Start get  intelli_guard_inventory Data ===============
    
    function get_intelli_guard_inventory($colstr, $where_str, $type)
    {
          
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "select","");
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {
    	return mosyflex_sel("intelli_guard_inventory", $colstr, $where_str, $type);

        //echo $gwauthenticate_intelli_guard_inventory_;

	  }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");


     }    
    }
    //End get  intelli_guard_inventory Data ===============
    
    
    //======== qintelli_guard_inventory_data qsingle query function
    
    function qintelli_guard_inventory_data($qfile_key_key)
    {
          
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "qdata","");
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {    
    	return get_intelli_guard_inventory("*", "WHERE file_key='$qfile_key_key'", "r");

		//echo $gwauthenticate_intelli_guard_inventory_;

      }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");


     }  
    }
   
    //======== qintelli_guard_inventory_data qsingle query function
    
    
     //======== intelli_guard_inventory data to array
    
    function intelli_guard_inventory_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "data_array","");
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {  
     	$append_intelli_guard_inventory_arr=array();
    
    	$array_intelli_guard_inventory_q=get_intelli_guard_inventory($colstr, $where_str, "l");
        while($array_intelli_guard_inventory_res=mysqli_fetch_array($array_intelli_guard_inventory_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_intelli_guard_inventory_arr[]=$array_intelli_guard_inventory_res[$tbl_col];
            }
          }else{
          	          
               $append_intelli_guard_inventory_arr[]=$array_intelli_guard_inventory_res;

          }
        }
        
        return $append_intelli_guard_inventory_arr;

		//echo $gwauthenticate_intelli_guard_inventory_;

      }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");


     }  
    }
   
    //======== qintelli_guard_inventory_data qsingle query function   
        
    //======== qintelli_guard_inventory_ddata qsingle query function    
    function qintelli_guard_inventory_ddata($file_key_col, $qfile_key_key)
    {
     
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "qddata","");
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {    
    	return get_intelli_guard_inventory("*", "WHERE $file_key_col='$qfile_key_key'", "r");

		//echo $gwauthenticate_intelli_guard_inventory_;

     }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");


     }   
    }
    //======== qintelli_guard_inventory_ddata qsingle query function
    
        //======== qintelli_guard_inventory_gdata qsingle query function    
    function qintelli_guard_inventory_gdata($intelli_guard_inventory_where="")
    {
     
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "gddata","");
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {    
     	$where_str="";
        if($intelli_guard_inventory_where!=="")
        {
        $where_str=" ".$intelli_guard_inventory_where;
        }
    	return get_intelli_guard_inventory("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_intelli_guard_inventory_;

     }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");


     }   
    }
    //======== qintelli_guard_inventory_gdata qsingle query function
    

    //======== count intelli_guard_inventory data function
    
    function count_intelli_guard_inventory($intelli_guard_inventory_wherestr)
    {
     
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "count_data","");
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {    
      $clean_intelli_guard_inventory_where_str="";
  
      if($intelli_guard_inventory_wherestr!='')
      {
        $clean_intelli_guard_inventory_where_str="Where ".$intelli_guard_inventory_wherestr;
      }

      return get_intelli_guard_inventory("count(*) as return_result", " ".$clean_intelli_guard_inventory_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_intelli_guard_inventory_;

      }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");


     }    
    }
    //======== count intelli_guard_inventory data function

    //======== sum  intelli_guard_inventory data function
    
    function sum_intelli_guard_inventory($intelli_guard_inventory_sumcol, $intelli_guard_inventory_wherestr)
    {
     
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "sum_data","");
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {    
      $clean_intelli_guard_inventory_where_str="";
  
      if($intelli_guard_inventory_wherestr!='')
      {
        $clean_intelli_guard_inventory_where_str="Where ".$intelli_guard_inventory_wherestr;
      }

      return get_intelli_guard_inventory("sum($intelli_guard_inventory_sumcol) as return_result", " ".$clean_intelli_guard_inventory_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_intelli_guard_inventory_;


      }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");
        


     }    
    }
    
    //======== sum  intelli_guard_inventory data function   
    
    
    //Start drop  intelli_guard_inventory Data ===============
    
    function drop_intelli_guard_inventory($where_str)
    {
     
     $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "drop_data","");
     
     $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
     
     if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
     {    
    	return magic_sql_delete("intelli_guard_inventory", $where_str);

		//echo $gwauthenticate_intelli_guard_inventory_;

      }else{
     
     	echo $gwauthenticate_intelli_guard_inventory_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");
		

     }
    }
    //End drop  intelli_guard_inventory Data ===============    
    
    
   

    
 	//Start Add mosy_sql_roll_back Data ===============
 	function add_mosy_sql_roll_back($mosy_sql_roll_back_arr_)
    {
     $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("mosy_sql_roll_back", $mosy_sql_roll_back_arr_);
     
     	//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

     }
     
    }
    
       function initialize_mosy_sql_roll_back()
        {
        
         global $mosy_sql_roll_back_uptoken;
             
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
         	return get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
         
            echo $gwauthenticate_mosy_sql_roll_back_;

         }else{

         	echo $gwauthenticate_mosy_sql_roll_back_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
        }   
    //End Add mosy_sql_roll_back Data ===============
                
    //Start Update mosy_sql_roll_back Data ===============
    
 	function update_mosy_sql_roll_back($mosy_sql_roll_back_arr_, $where_str)
    {
         $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("mosy_sql_roll_back", $mosy_sql_roll_back_arr_, $where_str);

       // echo $gwauthenticate_mosy_sql_roll_back_;
        
        exit;

     }else{

        echo $gwauthenticate_mosy_sql_roll_back_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


      }
    
    }
 	
    
    //End Update mosy_sql_roll_back Data ===============

    //Start get  mosy_sql_roll_back Data ===============
    
    function get_mosy_sql_roll_back($colstr, $where_str, $type)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
    	return mosyflex_sel("mosy_sql_roll_back", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosy_sql_roll_back_;

	  }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //End get  mosy_sql_roll_back Data ===============
    
    
    //======== qmosy_sql_roll_back_data qsingle query function
    
    function qmosy_sql_roll_back_data($qroll_bk_key_key)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qdata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE roll_bk_key='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function
    
    
     //======== mosy_sql_roll_back data to array
    
    function mosy_sql_roll_back_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "data_array","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {  
     	$append_mosy_sql_roll_back_arr=array();
    
    	$array_mosy_sql_roll_back_q=get_mosy_sql_roll_back($colstr, $where_str, "l");
        while($array_mosy_sql_roll_back_res=mysqli_fetch_array($array_mosy_sql_roll_back_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res[$tbl_col];
            }
          }else{
          	          
               $append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res;

          }
        }
        
        return $append_mosy_sql_roll_back_arr;

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function   
        
    //======== qmosy_sql_roll_back_ddata qsingle query function    
    function qmosy_sql_roll_back_ddata($roll_bk_key_col, $qroll_bk_key_key)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE $roll_bk_key_col='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }
    //======== qmosy_sql_roll_back_ddata qsingle query function
    
        //======== qmosy_sql_roll_back_gdata qsingle query function    
    function qmosy_sql_roll_back_gdata($mosy_sql_roll_back_where="")
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "gddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
     	$where_str="";
        if($mosy_sql_roll_back_where!=="")
        {
        $where_str=" ".$mosy_sql_roll_back_where;
        }
    	return get_mosy_sql_roll_back("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }
    //======== qmosy_sql_roll_back_gdata qsingle query function
    

    //======== count mosy_sql_roll_back data function
    
    function count_mosy_sql_roll_back($mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "count_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("count(*) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //======== count mosy_sql_roll_back data function

    //======== sum  mosy_sql_roll_back data function
    
    function sum_mosy_sql_roll_back($mosy_sql_roll_back_sumcol, $mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "sum_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("sum($mosy_sql_roll_back_sumcol) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;


      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
        


     }    
    }
    
    //======== sum  mosy_sql_roll_back data function   
    
    
    //Start drop  mosy_sql_roll_back Data ===============
    
    function drop_mosy_sql_roll_back($where_str)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "drop_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return magic_sql_delete("mosy_sql_roll_back", $where_str);

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
		

     }
    }
    //End drop  mosy_sql_roll_back Data ===============    
    
    
  //===============End Mosy queries-============

//============= Start Sql chart  Script =====================

function mosy_sql_rollback($tbl, $where, $type)
{
  $sql_fun="get_".$tbl;

  $curr_sql_ret_=$sql_fun("*", " where ".$where." ", "r");
  
  $json_sql_str=json_encode($curr_sql_ret_, true);
  
  //------- begin mosy_sql_roll_back_post_arr --> 
  $mosy_sql_roll_back_post_arr_=array(

  "primkey"=>"NULL",
  "roll_bk_key"=>mmres(magic_random_str(20)),
  "table_name"=>mmres($tbl),
  "where_str"=>mmres($where),
  "roll_type"=>mmres($type),
  "roll_timestamp"=>date("Y-m-d H:i:s"),
  "value_entries"=>mmres($json_sql_str)

  );
  //===-- End mosy_sql_roll_back_post_arr -->

  add_mosy_sql_roll_back($mosy_sql_roll_back_post_arr_);
  
  return $json_sql_str;
  
}


function get_mosychart_data($tbl, $colstr, $where_str, $xcol, $ycol, $groupby)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str="";
   $groupby_cols="";
   
   if($where_str!='')
   {
     $fun_where_str=" WHERE ".$where_str;
   }
   
   if($groupby!='')
   {
     $groupby_cols=" GROUP BY ".$groupby;
   }
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ".$groupby_cols." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================

//============= End Sql chart  Script =====================

function get_mosyflex_chart($tbl, $colstr, $where_str, $xcol, $ycol)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str=$where_str;
  
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================


//============= Start   mosy flex select script =====================

function mosyflex_sel($tbl, $colstr, $where_str, $loop_or_row_l_r,$show_str="")
{
   global $single_conn;
   global $single_db;
   global $flex_result;
   global $datalimit;
  
  $paginate_q="";
  $paginate_state="";
  
  $pagination_token=$tbl."_mpgtkn";
  
  $loop_or_row_l_rtype=$loop_or_row_l_r;
  
  if (strpos($loop_or_row_l_r, ':') !== false)
  {
    $loop_or_row_l_r_str=explode(":", $loop_or_row_l_r);

    $pagination_token=$loop_or_row_l_r_str[1];

    $loop_or_row_l_rtype=$loop_or_row_l_r_str[0];

    $paginate_state="paginate";
    
    $pagination_sql="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

    $process_pagination=mysqli_query($single_conn, $pagination_sql) or die(mysqli_error($single_conn));

    $paginate_q=mosy_paginate($process_pagination, $datalimit, $pagination_token);

    $new_where_str=$where_str." LIMIT ".$paginate_q[0].", $datalimit ";

    $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_str."";
    

  }else{
    
      $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

  }
  if($show_str=="yes")
  {
   echo $sql_str;
  } 
  $flex_result_q=mysqli_query($single_conn, $sql_str) or die(mysqli_error($single_conn));
  
  $flex_result=$flex_result_q;

  if($loop_or_row_l_rtype=='r')
  {
    $flex_result_r=mysqli_fetch_array($flex_result_q);
    
    $flex_result=$flex_result_r;
    
  }
  
  if($paginate_state=='paginate')
  {
  	$flex_result=array($flex_result_q, $paginate_q[1], $paginate_q[0], $sql_str, $pagination_sql);  
  }
  
  return $flex_result;
  
}


function mosy_paginate($sqlstring, $reclimit, $token_name)
{

  $requested_page = isset($_GET[$token_name]) ? intval(base64_decode($_GET[$token_name])) : 1;

  $rows_count = mysqli_num_rows($sqlstring);

  $items_per_page = $reclimit;

  $page_count = ceil($rows_count / $items_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_row = ($requested_page - 1) * $items_per_page;

  $recordperpage_data=array($first_row,$page_count);

  return $recordperpage_data;
  
}
//============= End  mosy flex select script =====================

  function tonum($number_str, $decplaces=0)
  {
	if($number_str=='')
    {
      $number_str=0;
    }
  	return number_format($number_str, $decplaces, ".", ",");
  	

  }
  
//checkblank fuction

function checkblank($value, $return_val)
{
  
  global $fun_resonse;

  if($value!='')
  {
  $fun_resonse=$value;
  }else{
    $fun_resonse=$return_val;

  }
  return $fun_resonse;

}

//get date foramrt

function ftime($time_st, $type)
{
  	global $timeresp;
    
  $timeresp=date("l, jS, M, y, @ H:i:s");

  if($time_st=="") 
  {
    $timeresp=date("l, jS, M, y, @ H:i:s");

  	if($type=="date")
    {
    $timeresp=date("l, jS, M, y");
    }
    
  }
  
  if($time_st!=""){
  
     $timeresp=date("l, jS, M, y, @ H:i:s", strtotime($time_st));

    if($type=="date")
    {
    	$timeresp=date("l, jS, M, y", strtotime($time_st));
    }
    
  }
	return $timeresp;
}

function date_time_input($time_st, $full_date_time="")
{
  	global $timeresp;
    
    $date_form="Y-m-d\TH:i:s";
    
    if($full_date_time=="date")
    {
    $date_form="Y-m-d";
    }
    
    if($full_date_time=="time")
    {
    $date_form="H:i:s";
    }
    
  if($time_st==""){
  	$timeresp=date($date_form);
  }else{
   
   $timeresp=date($date_form, strtotime($time_st));

  }
	return $timeresp;
}
function daytime()
{
  global $daytime;

  $daytime='Hello';

  $fromdate=date('A');
  $eve_aft=date("H");

  if($fromdate=='AM'){
 	 $daytime='Morning';
  }
  
  if($fromdate=='PM' && $eve_aft<17){
  	$daytime='Afternoon';
  }
  
  if($fromdate=='PM' && $eve_aft>=17){
  	$daytime='Evening';
  }

  return $daytime;
}

function mosy_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest)
{
	global $curl_post_response;

	$new_curl_method='POST';
	if($curlopt_customrequest!='')
	{
		$new_curl_method=$curlopt_customrequest;
	}

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $curlopt_url);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $new_curl_method); 
		curl_setopt($ch, CURLOPT_HTTPHEADER, ($curlopt_httpheader));
		curl_setopt($ch, CURLOPT_USERPWD, $curlopt_userpwd);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $curlopt_post_fields);

		$curl_post_response = curl_exec($ch);

	return $curl_post_response;
}

function mosy_month_year_diff($start_date, $end_date, $myd="m")
{

  $ts1 = strtotime($start_date);
  $ts2 = strtotime($end_date);

  $year1 = date("Y", $ts1);
  $year2 = date("Y", $ts2);

  $month1 = date("m", $ts1);
  $month2 = date("m", $ts2);

  $date1=date_create($start_date);
  $date2=date_create($end_date);

  $day_diff=date_diff($date1,$date2);

  $day_diff_count=$day_diff->format("%R%a");
    
  $year_diff_=$year2 - $year1;
  $month_diff_=$month2 - $month1;

  $diff = (($year_diff_) * 12) + ($month_diff_);

  $ret_diff=$year_diff_;

  if($myd=="m")
  {
    $ret_diff=$diff;
  }
  
  if($myd=="d")
  {
    $ret_diff=$day_diff_count;
  }
  
  if($myd=="y")
  {
    $ret_diff=$year_diff_;
  }

  return $ret_diff;

}

function ifnotblank($str,$replacement)
{
	
    if($str!="")
    {
     return $replacement;
     
    }else{
    return $str;
    }

}

function time_elapsed_string($datetime, $full = false) 
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        "y" => "year",
        "m" => "month",
        "w" => "week",
        "d" => "day",
        "h" => "hour",
        "i" => "minute",
        "s" => "second",
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . " " . $v . ($diff->$k > 1 ? "s" : "");
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(", ", $string) . " ago" : "just now";
}

if (file_exists("./mosy_paginate.php")){
include("./mosy_paginate.php");
}

function pdf_url($current, $pdfurl)
{
  
  $filter_param=str_replace($current."", $pdfurl."", (magic_current_url()));

  if(strpos($filter_param, '?') !== false) 
  {
    $filter_param=str_replace($current."?", $pdfurl."?", (magic_current_url()));

  }

  if(strpos($filter_param, '.php?') !== false) 
  {
    $filter_param=str_replace($current.".php?", $pdfurl."?", (magic_current_url()));

  }

  return $filter_param;
  
}


function mosy_send_mail($to_email, $from_email, $sender_name, $subject, $message, $use_api="")
{
	// create email headers
	$replyto_mail="";
	$returnpath="";
	$headers="";

	if($from_email!='')
	{
    	$replyto_mail='Reply-To: ' .$sender_name." <".$from_email.">\r\n";
    	$returnpath='Return-Path: ' .$sender_name." <".$from_email.">\r\n";
	}

	$busmail=$from_email;
	$bus_name=$sender_name;

	if($to_email=='')
	{
		$busmail='info@clearphrases.com';
	}

	if($sender_name=='')
	{
		$bus_name="";
	}

    $headers = 'From: '.$bus_name.'<'.$busmail.'>' . "\r\n" .
    $headers.=$replyto_mail;
    $headers.=$returnpath;
    $headers .= "Organization: ".$bus_name."\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers.='Content-type: text/html; charset=UTF-8'. "\r\n";
    $headers .= "X-Priority: 3\r\n";
    $headers .= "X-Mailer: PHP". phpversion() ."\r\n";
   
  if($use_api=="yes")
  {
    
    $curlopt_url="https://origin.clearphrases.com/api/email/mosy_mail.php";
    
    $email_attr="send_mosy_email&to_email=".rawurlencode($to_email)."&from_email=".rawurlencode($from_email)."&sender_name=".rawurlencode($sender_name)."&subject=".rawurlencode($subject)."&message=".rawurlencode($message)."";
    
   return magic_post_curl($curlopt_url, "", "", $email_attr, "POST");

  }else{
    
  return mail($to_email, $subject, $message, $headers);        
  }
}


function mosy_push_sms($recp, $sms_body, $smsapi_url="")
{

  
  if($smsapi_url=="")
  {
    $smsapi_url="https://origin.clearphrases.com/api/sms/adminsmsgateway.php";
  }
  
  $sms_request="pushsms&recp=".$recp."&body=".$sms_body."";

  return magic_post_curl($smsapi_url, '', '', $sms_request, 'POST');

}
function add_url_param( $key, $value, $passed_url) 
{
  $url=$passed_url;
  if($passed_url=='')
  {
    $url=magic_current_url();
  }
  
  $info = parse_url( $url );

  if(isset($info['query']))
  {
    parse_str( $info['query'], $query );
  }else{
    $query="";
  }
    return $info['scheme'] . '://' . $info['host'] . $info['path'] . '?' . http_build_query( $query ? array_merge( $query, array($key => $value ) ) : array( $key => $value ) );
}


function mosy_user_acc_($user_id, $access_key="")
{
  
  if($access_key=="")    
  {
    $access_key=magic_basename(magic_current_url());
  }
  
    
  $access_key=str_replace(".php", "", $access_key); 
  
  $page_group=qpage_manifest__ddata("page_url", $access_key);

  $pagegrp=$page_group['page_group'];

  $user_access_req=count_user_manifest_(" user_id='$user_id' and role_name='$pagegrp' ");

  $user_role_attr=quser_manifest__gdata(" where  user_id='$user_id' and role_name='$pagegrp' ");

  ///echo " status - ".$user_access_req;
  ///echo " Page ".$pagegrp." - user_count - ".$user_access_req." NAme - ".$user_role_attr['user_name']." acc key - ".$access_key."<br>";  
  if($user_access_req>0)
  {
    $acc_state="Allowed";
  }else{
    $acc_state="Denied";
  }

  return $acc_state;
}



function mosy_log_notific($note_title,$note_remark,$note_link="",$note_type="",$note_icon="img/logo.png")
{
  
  //------- begin notification_manifest__arr --> 
  $notification_manifest__arr_=array(

  "notific_key"=>magic_random_str(10),
  "notification_type"=>$note_type,
  "notification_state"=>"Unread",
  "notification_icon"=>$note_icon,
  "notification_title"=>$note_title,
  "notification_link"=>$note_link,
  "notification_read_state"=>"Unread",
  "notification_time_stamp"=>date("Y-m-d H:i:a"),
  "notif_remark"=>$note_remark

  );
  //===-- End notification_manifest__arr -->

  return add_notification_manifest_($notification_manifest__arr_);
  
}

function trim_text($string)
{
 return magic_strip_if($string, 90, 90);
}

//<--ncgh-->
?>