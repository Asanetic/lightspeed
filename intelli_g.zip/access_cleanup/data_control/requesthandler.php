<?php 
//===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section intelli_guard
  //************************************************* START  intelli_guard OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize intelli_guard edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['intelli_guard_table_alert']))
              	{	
                  if(isset($intelli_guard_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$intelli_guard_uptoken="";

		if(isset($_GET["intelli_guard_uptoken"]))
		{
		$intelli_guard_uptoken=base64_decode($_GET["intelli_guard_uptoken"]);
		}
        
        if(isset($_POST["intelli_guard_uptoken"]))
		{
		$intelli_guard_uptoken=base64_decode($_POST["intelli_guard_uptoken"]);
		}
        //
        
          $intelli_guard_alias_name="INTELLI GUARD";

          if(isset($intelli_guard_alias))
          {
             $intelli_guard_alias_name=$intelli_guard_alias;

          }
          
        //get single data record query with $intelli_guard_uptoken
        
        ///$intelli_guard_node=get_intelli_guard("*", "WHERE primkey='$intelli_guard_uptoken'", "r");
        
	
//************* START INSERT  intelli_guard QUERY 
if(isset($_POST["intelli_guard_insert_btn"])){
//------- begin intelli_guard_arr_ins --> 
$intelli_guard_arr_ins_=array(

"primkey"=>"NULL",
"flagkey"=>magic_random_str(7),
"flag_name"=>"?",
"flag_type"=>"?",
"flag_id"=>"?",
"flag_source"=>"?",
"flag_status"=>"?",
"notification_read_state"=>"?",
"flag_date"=>"?",
"flag_remark"=>"?"

);
//===-- End intelli_guard_arr_ins -->


          
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "insert","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {

              $intelli_guard_validated_ins_str=$intelli_guard_arr_ins_;

              if(isset($intelli_guard_ins_inputs))
              {
                $intelli_guard_validated_ins_str=$intelli_guard_ins_inputs;	
              }

              if(empty($intelli_guard_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$intelli_guard_alias_name." request cannot be empty. Record not added");
              }else{
                $intelli_guard_return_key=add_intelli_guard($intelli_guard_validated_ins_str);
                
                mosy_sql_rollback("intelli_guard", "primkey='$intelli_guard_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$intelli_guard_mosy_rest_req_vars=http_build_query($_POST);
                echo $intelli_guard_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $intelli_guard_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $intelli_guard_return_key; 

                      } 

                    }else{ 

                                    
                $intelli_guard_custom_redir1=add_url_param ("intelli_guard_uptoken", base64_encode($intelli_guard_return_key), "");
                $intelli_guard_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$intelli_guard_custom_redir1);
                $intelli_guard_custom_redir3=add_url_param ("intelli_guard_table_alert", "intelli_guard_added",$intelli_guard_custom_redir2);
                
                ///echo magic_message($intelli_guard_custom_redir1." -- ".$intelli_guard_custom_redir2."--".$intelli_guard_custom_redir3);
                
                $intelli_guard_custom_redir=$intelli_guard_custom_redir3;
                
               header('location:'.$intelli_guard_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_intelli_guard_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");
         
         }
      
}
//************* END  intelli_guard INSERT QUERY 	
	

//************* START intelli_guard  UPDATE QUERY 
if(isset($_POST["intelli_guard_update_btn"])){
//------- begin intelli_guard_arr_updt --> 
$intelli_guard_arr_updt_=array(
"flag_name"=>"?",
"flag_type"=>"?",
"flag_id"=>"?",
"flag_source"=>"?",
"flag_status"=>"?",
"notification_read_state"=>"?",
"flag_date"=>"?",
"flag_remark"=>"?"

);
//===-- End intelli_guard_arr_updt -->
                     
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "update","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {
         
            $intelli_guard_validated_updt_str=$intelli_guard_arr_updt_;

            if(isset($intelli_guard_updt_inputs))
            {
              $intelli_guard_validated_updt_str=$intelli_guard_updt_inputs;	
            }

            if(empty($intelli_guard_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$intelli_guard_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$intelli_guard_key_salt=initialize_intelli_guard()["flagkey"];
            
              update_intelli_guard($intelli_guard_validated_updt_str, "primkey='$intelli_guard_uptoken' and flagkey='$intelli_guard_key_salt'");
				

			 mosy_sql_rollback("intelli_guard", "primkey='$intelli_guard_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $intelli_guard_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $intelli_guard_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $intelli_guard_uptoken; 

                    } 

                  }else{ 

                $intelli_guard_custom_redir1=add_url_param ("intelli_guard_uptoken", base64_encode($intelli_guard_uptoken), "");
                $intelli_guard_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$intelli_guard_custom_redir1);
                $intelli_guard_custom_redir3=add_url_param ("intelli_guard_table_alert", "intelli_guard_updated",$intelli_guard_custom_redir2);
                
                ///echo magic_message($intelli_guard_custom_redir1." -- ".$intelli_guard_custom_redir2."--".$intelli_guard_custom_redir3);
                
                $intelli_guard_custom_redir=$intelli_guard_custom_redir3;
                
               header('location:'.$intelli_guard_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_intelli_guard_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_)."");
         
         }

      

      
}
//************* END intelli_guard  UPDATE QUERY 

    
    
      //== Start intelli_guard delete record

      if(isset($_GET["deleteintelli_guard"]))
      {
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "super_delete_request","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_intelli_guard_btn=magic_button_link("./".$current_file_url."?intelli_guard_uptoken=".$_GET["intelli_guard_uptoken"]."&conf_deleteintelli_guard&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_intelli_guard_btn=magic_button_link("./".$current_file_url."?intelli_guard_uptoken=".$_GET["intelli_guard_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_intelli_guard_btn." ".$cancel_del_intelli_guard_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_intelli_guard_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteintelli_guard"]))
      {
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "super_delete_confirm","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $intelli_guard_del_key_salt=initialize_intelli_guard()["flagkey"];
      mosy_sql_rollback("intelli_guard", "primkey='$intelli_guard_uptoken'", "DELETE");
      drop_intelli_guard("primkey='$intelli_guard_uptoken' and flagkey='$intelli_guard_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_intelli_guard_);

      }
      }

      //== End intelli_guard delete record  
    
       ///SELECT STRING FOR intelli_guard============================
              
       if(isset($_POST["qintelli_guard_btn"])){
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "qintelli_guard_btn","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {
            $current_intelli_guard_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_intelli_guard_current_url=$current_intelli_guard_url_params.'?qintelli_guard=';
            if (strpos($current_intelli_guard_url_params, '?') !== false) {

                $clean_intelli_guard_current_url=$current_intelli_guard_url_params.'&qintelli_guard=';

            }
            if (strpos($current_intelli_guard_url_params, '?qintelli_guard')) {

                $remove_intelli_guard_old_token = substr($current_intelli_guard_url_params, 0, strpos($current_intelli_guard_url_params, "?qintelli_guard"));

                $clean_intelli_guard_current_url=$remove_intelli_guard_old_token.'?qintelli_guard=';

            }
            if(strpos($current_intelli_guard_url_params, '&qintelli_guard')) {

                $remove_intelli_guard_old_token = substr($current_intelli_guard_url_params, 0, strpos($current_intelli_guard_url_params, "&qintelli_guard"));

                $clean_intelli_guard_current_url=$remove_intelli_guard_old_token.'&qintelli_guard=';

            }
        $qintelli_guard_str=base64_encode($_POST["txt_intelli_guard"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_intelli_guard_current_url.($qintelli_guard_str);
            } 

          }else{ 
             header('location:'.$clean_intelli_guard_current_url.($qintelli_guard_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_intelli_guard_);

        }
        }
        $qintelli_guard="";
		if(isset($_GET["intelli_guard_mosyfilter"]) && isset($_GET["qintelli_guard"])){
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "intelli_guard_mosyfilter_n_query","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {
         $qintelli_guard=mmres(base64_decode($_GET["qintelli_guard"]));
         
         $gft_intelli_guard_where_query="(`flagkey` LIKE '%".$qintelli_guard."%' OR  `flag_name` LIKE '%".$qintelli_guard."%' OR  `flag_type` LIKE '%".$qintelli_guard."%' OR  `flag_id` LIKE '%".$qintelli_guard."%' OR  `flag_source` LIKE '%".$qintelli_guard."%' OR  `flag_status` LIKE '%".$qintelli_guard."%' OR  `notification_read_state` LIKE '%".$qintelli_guard."%' OR  `flag_date` LIKE '%".$qintelli_guard."%' OR  `flag_remark` LIKE '%".$qintelli_guard."%')";
         
         if($_GET["intelli_guard_mosyfilter"]!=""){
         
         $mosyfilter_intelli_guard_queries_str=(base64_decode($_GET["intelli_guard_mosyfilter"]));
        
         $gft_intelli_guard_where_query="(`flagkey` LIKE '%".$qintelli_guard."%' OR  `flag_name` LIKE '%".$qintelli_guard."%' OR  `flag_type` LIKE '%".$qintelli_guard."%' OR  `flag_id` LIKE '%".$qintelli_guard."%' OR  `flag_source` LIKE '%".$qintelli_guard."%' OR  `flag_status` LIKE '%".$qintelli_guard."%' OR  `notification_read_state` LIKE '%".$qintelli_guard."%' OR  `flag_date` LIKE '%".$qintelli_guard."%' OR  `flag_remark` LIKE '%".$qintelli_guard."%') AND ".$mosyfilter_intelli_guard_queries_str."";
         
         }
         
		 $gft_intelli_guard="WHERE ".$gft_intelli_guard_where_query;
         
         $gft_intelli_guard_and=$gft_intelli_guard_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_intelli_guard_);
        }
        }elseif(isset($_GET["qintelli_guard"])){
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "get_qintelli_guard","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {
		 $qintelli_guard=mmres(base64_decode($_GET["qintelli_guard"]));
        
         $gft_intelli_guard_where_query="(`flagkey` LIKE '%".$qintelli_guard."%' OR  `flag_name` LIKE '%".$qintelli_guard."%' OR  `flag_type` LIKE '%".$qintelli_guard."%' OR  `flag_id` LIKE '%".$qintelli_guard."%' OR  `flag_source` LIKE '%".$qintelli_guard."%' OR  `flag_status` LIKE '%".$qintelli_guard."%' OR  `notification_read_state` LIKE '%".$qintelli_guard."%' OR  `flag_date` LIKE '%".$qintelli_guard."%' OR  `flag_remark` LIKE '%".$qintelli_guard."%')";
         
         $gft_intelli_guard="WHERE ".$gft_intelli_guard_where_query;
         
         $gft_intelli_guard_and=$gft_intelli_guard_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_intelli_guard_);

        }
        }elseif(isset($_GET["intelli_guard_mosyfilter"])){
         $gwauthenticate_intelli_guard_=gw_oauth("table", magic_current_url(), "intelli_guard", "intelli_guard_mosyfilter","");

         $gwauthenticate_intelli_guard_json=json_decode($gwauthenticate_intelli_guard_, true);
         	
          //echo $gwauthenticate_intelli_guard_;

         if($gwauthenticate_intelli_guard_json["response"]=="ok")
         {
         $gft_intelli_guard_where_query="";
         $gft_intelli_guard="";

         if($_GET["intelli_guard_mosyfilter"]!=""){
          $gft_intelli_guard_where_query=(base64_decode($_GET["intelli_guard_mosyfilter"]));
          $gft_intelli_guard="WHERE ".$gft_intelli_guard_where_query;
         }
         
         
         $gft_intelli_guard_and=$gft_intelli_guard_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_intelli_guard_);

        }
        }else{
         $gft_intelli_guard="";
         $gft_intelli_guard_and="";
         $gft_intelli_guard_where_query="";
        }
       
    //************************************************* END  intelli_guard OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section intelli_guard_inventory
  //************************************************* START  intelli_guard_inventory OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize intelli_guard_inventory edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['intelli_guard_inventory_table_alert']))
              	{	
                  if(isset($intelli_guard_inventory_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$intelli_guard_inventory_uptoken="";

		if(isset($_GET["intelli_guard_inventory_uptoken"]))
		{
		$intelli_guard_inventory_uptoken=base64_decode($_GET["intelli_guard_inventory_uptoken"]);
		}
        
        if(isset($_POST["intelli_guard_inventory_uptoken"]))
		{
		$intelli_guard_inventory_uptoken=base64_decode($_POST["intelli_guard_inventory_uptoken"]);
		}
        //
        
          $intelli_guard_inventory_alias_name="INTELLI GUARD INVENTORY";

          if(isset($intelli_guard_inventory_alias))
          {
             $intelli_guard_inventory_alias_name=$intelli_guard_inventory_alias;

          }
          
        //get single data record query with $intelli_guard_inventory_uptoken
        
        ///$intelli_guard_inventory_node=get_intelli_guard_inventory("*", "WHERE primkey='$intelli_guard_inventory_uptoken'", "r");
        
	
//************* START INSERT  intelli_guard_inventory QUERY 
if(isset($_POST["intelli_guard_inventory_insert_btn"])){
//------- begin intelli_guard_inventory_arr_ins --> 
$intelli_guard_inventory_arr_ins_=array(

"primkey"=>"NULL",
"file_key"=>magic_random_str(7),
"directory"=>"?",
"filename"=>"?",
"file_path"=>"?",
"file_size"=>"?",
"date_created"=>"?",
"date_added"=>"?",
"flag_remark"=>"?"

);
//===-- End intelli_guard_inventory_arr_ins -->


          
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "insert","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {

              $intelli_guard_inventory_validated_ins_str=$intelli_guard_inventory_arr_ins_;

              if(isset($intelli_guard_inventory_ins_inputs))
              {
                $intelli_guard_inventory_validated_ins_str=$intelli_guard_inventory_ins_inputs;	
              }

              if(empty($intelli_guard_inventory_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$intelli_guard_inventory_alias_name." request cannot be empty. Record not added");
              }else{
                $intelli_guard_inventory_return_key=add_intelli_guard_inventory($intelli_guard_inventory_validated_ins_str);
                
                mosy_sql_rollback("intelli_guard_inventory", "primkey='$intelli_guard_inventory_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$intelli_guard_inventory_mosy_rest_req_vars=http_build_query($_POST);
                echo $intelli_guard_inventory_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $intelli_guard_inventory_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $intelli_guard_inventory_return_key; 

                      } 

                    }else{ 

                                    
                $intelli_guard_inventory_custom_redir1=add_url_param ("intelli_guard_inventory_uptoken", base64_encode($intelli_guard_inventory_return_key), "");
                $intelli_guard_inventory_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$intelli_guard_inventory_custom_redir1);
                $intelli_guard_inventory_custom_redir3=add_url_param ("intelli_guard_inventory_table_alert", "intelli_guard_inventory_added",$intelli_guard_inventory_custom_redir2);
                
                ///echo magic_message($intelli_guard_inventory_custom_redir1." -- ".$intelli_guard_inventory_custom_redir2."--".$intelli_guard_inventory_custom_redir3);
                
                $intelli_guard_inventory_custom_redir=$intelli_guard_inventory_custom_redir3;
                
               header('location:'.$intelli_guard_inventory_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_intelli_guard_inventory_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");
         
         }
      
}
//************* END  intelli_guard_inventory INSERT QUERY 	
	

//************* START intelli_guard_inventory  UPDATE QUERY 
if(isset($_POST["intelli_guard_inventory_update_btn"])){
//------- begin intelli_guard_inventory_arr_updt --> 
$intelli_guard_inventory_arr_updt_=array(
"directory"=>"?",
"filename"=>"?",
"file_path"=>"?",
"file_size"=>"?",
"date_created"=>"?",
"date_added"=>"?",
"flag_remark"=>"?"

);
//===-- End intelli_guard_inventory_arr_updt -->
                     
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "update","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {
         
            $intelli_guard_inventory_validated_updt_str=$intelli_guard_inventory_arr_updt_;

            if(isset($intelli_guard_inventory_updt_inputs))
            {
              $intelli_guard_inventory_validated_updt_str=$intelli_guard_inventory_updt_inputs;	
            }

            if(empty($intelli_guard_inventory_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$intelli_guard_inventory_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$intelli_guard_inventory_key_salt=initialize_intelli_guard_inventory()["file_key"];
            
              update_intelli_guard_inventory($intelli_guard_inventory_validated_updt_str, "primkey='$intelli_guard_inventory_uptoken' and file_key='$intelli_guard_inventory_key_salt'");
				

			 mosy_sql_rollback("intelli_guard_inventory", "primkey='$intelli_guard_inventory_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $intelli_guard_inventory_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $intelli_guard_inventory_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $intelli_guard_inventory_uptoken; 

                    } 

                  }else{ 

                $intelli_guard_inventory_custom_redir1=add_url_param ("intelli_guard_inventory_uptoken", base64_encode($intelli_guard_inventory_uptoken), "");
                $intelli_guard_inventory_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$intelli_guard_inventory_custom_redir1);
                $intelli_guard_inventory_custom_redir3=add_url_param ("intelli_guard_inventory_table_alert", "intelli_guard_inventory_updated",$intelli_guard_inventory_custom_redir2);
                
                ///echo magic_message($intelli_guard_inventory_custom_redir1." -- ".$intelli_guard_inventory_custom_redir2."--".$intelli_guard_inventory_custom_redir3);
                
                $intelli_guard_inventory_custom_redir=$intelli_guard_inventory_custom_redir3;
                
               header('location:'.$intelli_guard_inventory_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_intelli_guard_inventory_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_intelli_guard_inventory_)."");
         
         }

      

      
}
//************* END intelli_guard_inventory  UPDATE QUERY 

    
    
      //== Start intelli_guard_inventory delete record

      if(isset($_GET["deleteintelli_guard_inventory"]))
      {
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "super_delete_request","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_intelli_guard_inventory_btn=magic_button_link("./".$current_file_url."?intelli_guard_inventory_uptoken=".$_GET["intelli_guard_inventory_uptoken"]."&conf_deleteintelli_guard_inventory&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_intelli_guard_inventory_btn=magic_button_link("./".$current_file_url."?intelli_guard_inventory_uptoken=".$_GET["intelli_guard_inventory_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_intelli_guard_inventory_btn." ".$cancel_del_intelli_guard_inventory_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_intelli_guard_inventory_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteintelli_guard_inventory"]))
      {
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "super_delete_confirm","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $intelli_guard_inventory_del_key_salt=initialize_intelli_guard_inventory()["file_key"];
      mosy_sql_rollback("intelli_guard_inventory", "primkey='$intelli_guard_inventory_uptoken'", "DELETE");
      drop_intelli_guard_inventory("primkey='$intelli_guard_inventory_uptoken' and file_key='$intelli_guard_inventory_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_intelli_guard_inventory_);

      }
      }

      //== End intelli_guard_inventory delete record  
    
       ///SELECT STRING FOR intelli_guard_inventory============================
              
       if(isset($_POST["qintelli_guard_inventory_btn"])){
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "qintelli_guard_inventory_btn","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {
            $current_intelli_guard_inventory_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_intelli_guard_inventory_current_url=$current_intelli_guard_inventory_url_params.'?qintelli_guard_inventory=';
            if (strpos($current_intelli_guard_inventory_url_params, '?') !== false) {

                $clean_intelli_guard_inventory_current_url=$current_intelli_guard_inventory_url_params.'&qintelli_guard_inventory=';

            }
            if (strpos($current_intelli_guard_inventory_url_params, '?qintelli_guard_inventory')) {

                $remove_intelli_guard_inventory_old_token = substr($current_intelli_guard_inventory_url_params, 0, strpos($current_intelli_guard_inventory_url_params, "?qintelli_guard_inventory"));

                $clean_intelli_guard_inventory_current_url=$remove_intelli_guard_inventory_old_token.'?qintelli_guard_inventory=';

            }
            if(strpos($current_intelli_guard_inventory_url_params, '&qintelli_guard_inventory')) {

                $remove_intelli_guard_inventory_old_token = substr($current_intelli_guard_inventory_url_params, 0, strpos($current_intelli_guard_inventory_url_params, "&qintelli_guard_inventory"));

                $clean_intelli_guard_inventory_current_url=$remove_intelli_guard_inventory_old_token.'&qintelli_guard_inventory=';

            }
        $qintelli_guard_inventory_str=base64_encode($_POST["txt_intelli_guard_inventory"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_intelli_guard_inventory_current_url.($qintelli_guard_inventory_str);
            } 

          }else{ 
             header('location:'.$clean_intelli_guard_inventory_current_url.($qintelli_guard_inventory_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_intelli_guard_inventory_);

        }
        }
        $qintelli_guard_inventory="";
		if(isset($_GET["intelli_guard_inventory_mosyfilter"]) && isset($_GET["qintelli_guard_inventory"])){
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "intelli_guard_inventory_mosyfilter_n_query","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {
         $qintelli_guard_inventory=mmres(base64_decode($_GET["qintelli_guard_inventory"]));
         
         $gft_intelli_guard_inventory_where_query="(`file_key` LIKE '%".$qintelli_guard_inventory."%' OR  `directory` LIKE '%".$qintelli_guard_inventory."%' OR  `filename` LIKE '%".$qintelli_guard_inventory."%' OR  `file_path` LIKE '%".$qintelli_guard_inventory."%' OR  `file_size` LIKE '%".$qintelli_guard_inventory."%' OR  `date_created` LIKE '%".$qintelli_guard_inventory."%' OR  `date_added` LIKE '%".$qintelli_guard_inventory."%' OR  `flag_remark` LIKE '%".$qintelli_guard_inventory."%')";
         
         if($_GET["intelli_guard_inventory_mosyfilter"]!=""){
         
         $mosyfilter_intelli_guard_inventory_queries_str=(base64_decode($_GET["intelli_guard_inventory_mosyfilter"]));
        
         $gft_intelli_guard_inventory_where_query="(`file_key` LIKE '%".$qintelli_guard_inventory."%' OR  `directory` LIKE '%".$qintelli_guard_inventory."%' OR  `filename` LIKE '%".$qintelli_guard_inventory."%' OR  `file_path` LIKE '%".$qintelli_guard_inventory."%' OR  `file_size` LIKE '%".$qintelli_guard_inventory."%' OR  `date_created` LIKE '%".$qintelli_guard_inventory."%' OR  `date_added` LIKE '%".$qintelli_guard_inventory."%' OR  `flag_remark` LIKE '%".$qintelli_guard_inventory."%') AND ".$mosyfilter_intelli_guard_inventory_queries_str."";
         
         }
         
		 $gft_intelli_guard_inventory="WHERE ".$gft_intelli_guard_inventory_where_query;
         
         $gft_intelli_guard_inventory_and=$gft_intelli_guard_inventory_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_intelli_guard_inventory_);
        }
        }elseif(isset($_GET["qintelli_guard_inventory"])){
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "get_qintelli_guard_inventory","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {
		 $qintelli_guard_inventory=mmres(base64_decode($_GET["qintelli_guard_inventory"]));
        
         $gft_intelli_guard_inventory_where_query="(`file_key` LIKE '%".$qintelli_guard_inventory."%' OR  `directory` LIKE '%".$qintelli_guard_inventory."%' OR  `filename` LIKE '%".$qintelli_guard_inventory."%' OR  `file_path` LIKE '%".$qintelli_guard_inventory."%' OR  `file_size` LIKE '%".$qintelli_guard_inventory."%' OR  `date_created` LIKE '%".$qintelli_guard_inventory."%' OR  `date_added` LIKE '%".$qintelli_guard_inventory."%' OR  `flag_remark` LIKE '%".$qintelli_guard_inventory."%')";
         
         $gft_intelli_guard_inventory="WHERE ".$gft_intelli_guard_inventory_where_query;
         
         $gft_intelli_guard_inventory_and=$gft_intelli_guard_inventory_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_intelli_guard_inventory_);

        }
        }elseif(isset($_GET["intelli_guard_inventory_mosyfilter"])){
         $gwauthenticate_intelli_guard_inventory_=gw_oauth("table", magic_current_url(), "intelli_guard_inventory", "intelli_guard_inventory_mosyfilter","");

         $gwauthenticate_intelli_guard_inventory_json=json_decode($gwauthenticate_intelli_guard_inventory_, true);
         	
          //echo $gwauthenticate_intelli_guard_inventory_;

         if($gwauthenticate_intelli_guard_inventory_json["response"]=="ok")
         {
         $gft_intelli_guard_inventory_where_query="";
         $gft_intelli_guard_inventory="";

         if($_GET["intelli_guard_inventory_mosyfilter"]!=""){
          $gft_intelli_guard_inventory_where_query=(base64_decode($_GET["intelli_guard_inventory_mosyfilter"]));
          $gft_intelli_guard_inventory="WHERE ".$gft_intelli_guard_inventory_where_query;
         }
         
         
         $gft_intelli_guard_inventory_and=$gft_intelli_guard_inventory_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_intelli_guard_inventory_);

        }
        }else{
         $gft_intelli_guard_inventory="";
         $gft_intelli_guard_inventory_and="";
         $gft_intelli_guard_inventory_where_query="";
        }
       
    //************************************************* END  intelli_guard_inventory OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  

//<--ncgh-->

?>