<?php
if (session_status() == PHP_SESSION_NONE) 
{
  session_start();
}

date_default_timezone_set("Africa/Nairobi");

  //local conn
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password

$db="intelliguard";
$intelliguard="intelliguard";


/*
  //online conn

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password

$db="intelliguard";
$intelliguard="intelliguard";

*/

$mysqliconn=mysqli_connect("$host", "$username", "$password") or die("cannot connect"); 

mysqli_select_db($mysqliconn, $db);

$single_db=$db;
$single_conn=$mysqliconn;

$datalimit=15;

if(isset($_SESSION["filelim"]))
{
 $datalimit=$_SESSION["filelim"];
}
////=========== record per page function 
?>