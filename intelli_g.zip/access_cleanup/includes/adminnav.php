<?php 
$mosy_nav___username="Jeremy Alex";
$mosy_nav___user_avatar="img/useravatar.png";
$mosy_nav___user_notifi_count=count_notification_manifest_("");
$mosy_nav___user_role="User";
?>
<div class="header nav_bar_set">
  <div class="header-left">
    <a href="index.php" class="logo">
    	<img src="<?php echo $mep_app_logo ?>" alt="Logo">
    </a>
    <a href="index.php" class="logo logo-small">
    	<img src="<?php echo $mep_app_logo ?>" alt="Logo" width="30" height="30">
    </a>
  </div>

  <a href="javascript:void(0);" id="toggle_btn">
  	<i class="fe fe-text-align-left"></i>
  </a>
  <div class="top-nav-search d-none">
    <input type="text" readonly class="form-control cpointer mt-3 mosy_msdn" data-mosy_msdn="search_modal()" placeholder="Search records">
    <button class="btn" type="submit"><i class="fa fa-search"></i></button>
  </div>

  <a class="mobile_btn" id="mobile_btn">
  	<i class="fa fa-bars"></i>
  </a>
  <ul class="nav user-menu">

    <li class="nav-item dropdown noti-dropdown">
    <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
    <i class="fa fa-bell text-success "></i> <span class="badge badge-pill text-white"><?php echo $mosy_nav___user_notifi_count ?></span>
    </a>
    <div class="dropdown-menu notifications">
      <div class="topnav-dropdown-header">
        <span class="notification-title">Notifications</span>
        <a href="javascript:void(0)" class="clear-noti"></a>
      </div>
      <div class="noti-content">
      <ul class="notification-list">
      <?php $nav_notifics_q=get_notification_manifest_("*", " order by primkey desc limit 3  ", "l");?>
      <?php while($notific_nav_res=mysqli_fetch_array($nav_notifics_q)){?>               
        <li class="notification-message">
          <a href="<?php echo $notific_nav_res['notification_link'] ?>">
          <div class="media d-flex">
            <span class="avatar avatar-sm flex-shrink-0">
                <img class="avatar-img rounded-circle" alt="User Image" src="<?php echo $notific_nav_res['notification_icon'] ?>">
            </span>
            <div class="media-body flex-grow-1">
              <p class="noti-details text-dark"><?php echo magic_strip_if($notific_nav_res['notif_remark'], 100, 100);?></p>
              <p class="noti-time"><span class="notification-time"><?php echo time_elapsed_string($notific_nav_res['notification_time_stamp']);?></span></p>
            </div>
          </div>
          </a>
        </li>
        <?php } ?>
      </ul>
      </div>
      <div class="topnav-dropdown-footer">
      	<a href="mosy_notific">View all Notifications</a>
      </div>
    </div>
    </li>


    <li class="nav-item dropdown has-arrow">
      <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
        <span class="text-primary mr-2"><?php echo daytime()." ".explode(" ", $mosy_nav___username)[0] ?></span>
      	<span class="user-img"><img class="rounded-circle" src="<?php echo $mosy_nav___user_avatar?>" onerror="this.src='img/useravatar.png'" width="31"></span>
      </a>
      <div class="dropdown-menu">
        <div class="user-header">
          <div class="avatar avatar-sm">
          	<img src="<?php echo $mosy_nav___user_avatar ?>" onerror="this.src='img/useravatar.png'" alt="User Image" class="avatar-img rounded-circle">
          </div>
          <div class="user-text">
          	<h6><?php echo $mosy_nav___username ?></h6>
          	<p class="text-muted mb-0"><?php echo $mosy_nav___user_role?></p>
        </div>
        </div>
        <a class="dropdown-item d-none" href="adminaccount">My Profile</a>
        <a class="dropdown-item d-none" href="adminaccount">Account Settings</a>
        <a class="dropdown-item" href="olm_sessionlogout.php">Logout</a>
      </div>
    </li>

  </ul>

</div>

<div class="sidebar" id="sidebar">
  <div class="sidebar-inner slimscroll">
    <div id="sidebar-menu" class="sidebar-menu">
      <ul>
        <li class="menu-title">  </li>
        <li><a href="index"><i class="fe fe-home"></i> <span>Dashboard</span></a></li>                       
        <li class="submenu">
          <a href="#"><i class="fe fe-users"></i> <span> Members</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">
            <li><a href="members">View Members</a></li>
            <li><a href="member_prof">Add Members</a></li>
            <li><a href="members">Manage Members</a></li>
          </ul>
        </li> 
        <li class="submenu">
          <a href="#"><i class="fa fa-database"></i> <span> Loans </span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">
            <li><a href="loanprof">Add Loan</a></li>
            <li><a href="loanlist">View Loans</a></li>
            <li><a href="loanlist">Manage Loans</a></li>
          </ul>
        </li>  
        <li class="submenu">
          <a href="#"><i class="fa fa-money"></i> <span> Loan Payments </span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">
            <li><a href="loan_repayments">View Repayments</a></li>
            <li><a href="paymentprof">Add loan payment</a></li>
            <li><a href="loan_repayments">Manage Repayments</a></li>
          </ul>
        </li>    
        <li class="submenu">
          <a href="#"><i class="fa fa-gear"></i> <span> Loan settings </span> <span class="menu-arrow"></span></a>
          <ul style="display: none;"> 
            <li><a href="guarantors">Guarantors</a></li>
            <li><a href="collaterals">Collaterals</a></li>
            <li><a href="guarantors">Add Guarantors</a></li>
            <li><a href="collaterals">Add Collaterals</a></li>
          </ul>
        </li>   
        <li class="submenu">
          <a href="#"><i class="fa fa-line-chart"></i> <span> Reports </span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">
            <li><a href="paidloans">Cleared Loans</a></li>
            <li><a href="unpaidloans">Uncleared Loans</a></li>
            <li><a href="overdueloans">Overdue Loans</a></li>
            <li><a href="loan_repayments">Loan Repayments</a></li>
          </ul>
        </li> 
        <li class="submenu">
          <a href="#"><i class="fa fa-shield"></i> <span> User Account </span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">
            <li><a href="adminlist">View Accounts</a></li>
            <li><a href="adminlist">Add Accounts</a></li>
            <li><a href="adminlist">Manage Accounts</a></li>
            <li><a href="user_access_editor">Manage User Roles</a></li>
          </ul>
        </li>         
        <li onclick="mosy_card('Quick calc', calc_ui)"><a><i class="fe fe-bolt"></i>  <span>Calc</span></a></li>        
        <li ><a href="invoice_settings"><i class="fa fa-copy"></i>  <span>Invoice settings </span></a></li>        
      </ul>
    </div>
  </div>
</div>