<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');
include('./data_control/customfunctions.php');
 

if(count_intelli_guard(" flag_name='gatekeeper' and flag_status='Running' ")>0)
{
  scan_folder('..', 'yes', 'no', "yes");
}

?>