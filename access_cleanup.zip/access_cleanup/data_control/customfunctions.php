<?php
$this_month=date("Y-m");
$today=date("Y-m-d");

if(isset($_GET['open_file']))
{
  echo file_get_contents($_GET['open_file']);
}

if(isset($_GET['toggle_gatekeeper']))
{
  $is_activated=count_intelli_guard(" flag_name='gatekeeper'");

  
  if($is_activated==0)
  {
    //------- begin intelli_guard_arr --> 
    $intelli_guard_arr_=array(

    "flagkey"=>"gatekeeper",
    "flag_name"=>"gatekeeper",
    "flag_status"=>"Running"

    );
    //===-- End intelli_guard_arr -->

    add_intelli_guard($intelli_guard_arr_);
    
  }
  
  $is_running=count_intelli_guard(" flag_name='gatekeeper' and flag_status='Running' ");
  $is_inactive=count_intelli_guard(" flag_name='gatekeeper' and flag_status='Running' ");
  
  if($is_running>0)
  {
	update_intelli_guard(['flag_status'=>"Stopped"], " flag_name='gatekeeper' ");
  }else{

    update_intelli_guard(['flag_status'=>"Running"], " flag_name='gatekeeper' ");

  }
  
  
} 


function intelli_cleaup_($directory_to_list, $file_to_flag_str, $dont_delete_files_str, $remove="no")
 {
   
   //echo " in funstion  ".$file_to_flag_str." - ".$dont_delete_files_str;
   
   $file_to_flag=explode(",", $file_to_flag_str);
   
   $dont_delete_files=explode(",", $dont_delete_files_str);
  
   	if ($handle = opendir($directory_to_list)) {
	
		while (false !== ($entry = readdir($handle))) {
	
			if ($entry != "." && $entry != "..") 
            {
              
				$a = $entry;
		
				if (strpos($a, '.') !== false) {
	
                $check_access="";

                                   	
				if(in_array($entry, $file_to_flag))
                {
                  
                  if(in_array($directory_to_list."/".$entry, $dont_delete_files))
                  {                    
                    
                  }else{
                    
                    Quarantine($directory_to_list."/".$entry);
                    
                  }
                  
                }
				// ==================== cnovert html files ==================== 
                  
                  
				}else{
                                  
                ///file_put_contents($directory_to_list."/".$entry."/thugnificent.txt", "lando");
				intelli_cleaup_($directory_to_list."/".$entry, $file_to_flag_str, $dont_delete_files_str, $remove);
				}
			
			}
		}
	}
 }



if(isset($_GET['run_batch_quarantine']))
{

  ///echo "run_batch_quarantine  == ".$_GET['run_batch_quarantine']." ==> ".$_GET['skip_qarr'];
  
 echo (intelli_cleaup_($_GET['root_folder'], $_GET['run_batch_quarantine'], $_GET['skip_qarr'], "yes"));  
    
}


function zip_folder($folder_path, $zip_file_name, $zip_to="")
{
  // Get real path for our folder
  $rootPath = realpath($folder_path);

  // Initialize archive object
  $zip = new ZipArchive();
  
  if($zip_to=="")
  {
    $zip_to=$folder_path;
  }
  
  $zip->open($zip_to."/".$zip_file_name.".zip", ZipArchive::CREATE | ZipArchive::OVERWRITE);

  // Create recursive directory iterator
  /** @var SplFileInfo[] $files */
  $files = new RecursiveIteratorIterator(
      new RecursiveDirectoryIterator($rootPath),
      RecursiveIteratorIterator::LEAVES_ONLY
  );

  foreach ($files as $name => $file)
  {
      // Skip directories (they would be added automatically)
      if (!$file->isDir())
      {
          // Get real and relative path for current file
          $filePath = $file->getRealPath();
          $relativePath = substr($filePath, strlen($rootPath) + 1);

          // Add current file to archive
          $zip->addFile($filePath, $relativePath);
      }
  }

  // Zip archive will be created only after closing object
  $zip->close();
  
  echo "Folder ".$zip_file_name." Zipped Successfully ";
}


if(isset($_GET['create_backup']))
{
  zip_folder($_GET['create_backup'], $_GET['file_name'], "intelli_restore");
}

function scan_folder($directory_to_list, $deep_search="", $add_to_inventory="",$exe_quarantine="")
{
    $scan_ui="";

    //$handle= opendir($directory_to_list);
    $handle= @opendir($directory_to_list);

  	if ($handle) 
    {
	
		while (false !== ($entry = readdir($handle))) {
	
           
			if ($entry != "." && $entry != "..") {
				$a = $entry;
		
 
				if (strpos($a, '.') == false) {                  
                 if($deep_search=="yes")
                  {
				
                   if (strpos($directory_to_list."/".$entry, '.') == false) {                  

                    ///$scan_ui.="Folder".$directory_to_list."/".$entry.'<br>';
                     
                    $scan_ui.=scan_folder($directory_to_list."/".$entry, $deep_search, $add_to_inventory, $exe_quarantine);
                    
                   }
                  }else{
                   
                  $folder_creation_time=date("F d Y H:i:s.", filemtime($directory_to_list."/".$entry));

                  $scan_ui.='
                  <div onclick="mosytoggle_remclass(\'back_dir_btn\',\'hidden\');push_html(\'active_dir\', \''.$directory_to_list."/".$entry.'\');req_scan_dir()" class="row border-bottom border_set result_node cpointer justify-content-center m-0 p-0 col-md-12" id="">
                   <div class="col-md-1 " id=""><i class="fa fa-folder text-warning"></i> </div>
                   <div class="col-md-5 text-left" id=""><div class="trim_text"><b>'.$entry.'</b></div> </div>
                   <div class="col-md-6 " id=""><b class="badge">'.$folder_creation_time.'</b> </div>
                  </div>';
                  }
               }
            }
        }
    }
  
   //$handle_2 =  opendir($directory_to_list);
   //$handle_2 =  opendir($directory_to_list);
   $handle_2 =  @opendir($directory_to_list);
  
   if ($handle_2) 
    {
	
		while (false !== ($entry = readdir($handle_2))) {
	
			if ($entry != "." && $entry != "..") {
				$a = $entry;
		
				if (strpos($a, '.') !== false) {

                $file_path__=$directory_to_list."/".$entry;
                $file_creation_time=date("F d Y H:i:s.", filemtime($directory_to_list."/".$entry));
                                   
                  //------- begin intelli_guard_inventory_arr --> 
                  $intelli_guard_inventory_arr_=array(
                  "file_key"=>date("dmyhisa"),
                  "directory"=>$directory_to_list,
                  "filename"=>$entry,
                  "file_path"=>$file_path__,
                  "file_size"=>filesize($file_path__),
                  "date_created"=>$file_creation_time,
                  "date_added"=>date("Y-m-d H:i:s"),
                  "flag_remark"=>""

                  );
                  //===-- End intelli_guard_inventory_arr -->

                $count_dup_files=count_intelli_guard_inventory("file_path='$file_path__'");
                  
                if($add_to_inventory=="yes")
                { 
                   if($count_dup_files==0)
                   {
                     add_intelli_guard_inventory($intelli_guard_inventory_arr_);
                   }
                } 
                $flagged_clr="";
                $flagged_name="";
                $flagged_icon='<i class="fa fa-check-circle text-success "></i>';
                  
                if($count_dup_files==0)
                {
                  $flagged_clr="";
                  $flagged_name="Suspicious File";
                  $flagged_icon='<i class="fa fa-times-circle text-danger "></i>';
                  
                    if($exe_quarantine=="yes")
                    {
                                        
                      Quarantine($directory_to_list."/".$entry);

                    }
                  
                }
                  
                $scan_ui.='
                <div onclick="stage_file(\''.$entry.'\', \''.$directory_to_list.'\',\''.$file_creation_time.'\', \''.$flagged_name.'\')" class="row border-bottom border_set cpointer justify-content-center m-0 p-0 col-md-12 result_node " id="">
                 <div class="col-md-1 " id=""><i class="fa fa-file-text text-info "></i> </div>
                 <div class="col-md-5 text-left" title="'.$entry.'" id=""><div class="trim_text"><b>'.$entry.'</b></div> </div>
                 <div class="col-md-6 " id=""><b class="badge">'.$file_creation_time.'</b> </div>
                 <div class="col-md-12 '.$flagged_clr.'" id=""><span class="badge"> '.$flagged_icon.' Location : <em> '.$directory_to_list.'<span class="text-danger">'.$flagged_name.'</span></em><span></div>
                </div>';
                }
            }
        }
    }
  
  return $scan_ui;
}



if(isset($_GET['scan_folder']))
{
  echo scan_folder($_GET['scan_folder'], $_GET['deep_search'], $_GET['add_to_inventory'], $_GET['exe_quarantine']);
}

function Quarantine($filename, $echo_res='')
{
  $new_file_name='./intelli_quarantine/'.magic_basename($filename)."_".date("d_m_y_h_i_s_a")."_".magic_random_str(10).'.intelli';
  
     if (!file_exists('./intelli_quarantine')) @mkdir('./intelli_quarantine');
	
  	$exec_move = rename($filename, $new_file_name);
  if($echo_res==''){
    
  if($exec_move)
  {
    
  echo "<hr>File ".$filename." -  Moved to ".$new_file_name."<hr>";
    
	}else{
  
  echo "<hr>Opps! Error While Deleting File <hr>";
	
  }
  }

}


if(isset($_GET['quarantine_file']))
{
 echo Quarantine($_GET['quarantine_file']);
}

if(isset($_GET['empty_quarantine']))
{
   $directory_to_list="./intelli_quarantine";
   $handle_2 =  opendir($directory_to_list);
  
   if ($handle_2) 
    {
	
		while (false !== ($entry = readdir($handle_2))) {
	
			if ($entry != "." && $entry != "..") {
				$a = $entry;
		
				if (strpos($a, '.') !== false) {

                $file_path__=$directory_to_list."/".$entry;
                unlink($file_path__);
                  
                }
            }
        }
   }

}


if(isset($_GET['install_gatekeeper']))
{
  
        // Set the command to be executed by the cron job
    $command = 'wget -q -O /dev/null https://clearphrases.com/tgai/gg_note.php >/dev/null 2>&1';

    // Set the interval at which the command should be executed
    $interval = '*/5 * * * *'; // This will execute the command every 5 minutes

    // Get the current cron job list
    $cronjobs = shell_exec('crontab -l');
    $existingCronJobs = shell_exec('crontab -l');

    //echo "Old cronjob - ".$cronjobs."<br>";
    //echo "New cronjob - ".$command."<br>";

    // Append the new cron job to the list
    $cronjobs .= $interval . ' ' . $command . "\n";

  
    // Check if the command already exists in the list of cron jobs
    if (strpos($existingCronJobs, $command) !== false) {
        // The cron job already exists
        echo 'The cron job already exists';
    }else{
        // Update the crontab with the new list
        shell_exec('echo "'.trim($cronjobs).'" | crontab -');
    }
  
}
?>