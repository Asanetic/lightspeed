<?php
  include('./data_control/conn.php');

  unset($_SESSION["session_itg_logged"]);
  unset($_SESSION['session_itg_logged_email']);
  unset($_SESSION['session_itg_logged_name']);
  unset($_SESSION['session_itg_logged_user_id']);

      header('location:./itg_login.php');

  ?>