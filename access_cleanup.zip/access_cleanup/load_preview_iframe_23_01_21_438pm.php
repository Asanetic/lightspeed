<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');  
 
include('./data_control/customfunctions.php');

include('./itg_sessionmonitor.php');

$mosy_page_title="Intelliguard Desk";
if(isset($_GET['mosy_page_title']))
{
  $mosy_page_title=base64_decode($_GET['mosy_page_title']);
}
$def_dashboard="index";
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title> <?php echo $mosy_page_title ?></title>
<?php include('./includes/admin_css_scripts.php');?>
</head>
<body class="mini-sidebar">
    
<form method="post" enctype="multipart/form-data" id="mosy_form">
  <div class="main-wrapper">
    <div class="">
      <div class="row justify-content-center m-0 p-0 col-md-12 pt-2" id="">
      <img src="<?php echo $mep_app_logo ?>" class="" style="height:50px; width:auto;" id=""/>  
  	   <div class="h4 text-center text-info" ><?php echo $mep_app_name ?></div>
        <div class="col-md-12 text-right " id="">
          <span onclick="" class=" cpointer  text-white p-1 rounded_medium <?php echo "" ?>"> <i class="fa fa-shield"></i> Intelliguard Gatekeeper is <?php echo "" ?> </span>
          <a href="itg_sessionlogout.php"><span class="badge"> <i class="fa fa-user mr-2"></i> <?php echo daytime()." ".$_SESSION['session_itg_logged_name'] ?> - Logout <i class="fa fa-arrow-right"></i></span> </a></div>
    </div> 
      <div class="content container-fluid">
        <div class="row">
          <div class="col-sm-12">
			<div class="col-md-12 p-3 "></div>

			<!-- Start body content -->
             <div class="row justify-content-center m-0 p-0 col-md-12 skin_plasma">
              <div class="col-md-4 border-left p-0 rounded_medium">                             	
                <div class="col-md-12 border-bottom h4 bg-info p-2 text-white ">Files and Folders</div>
                <div class="row justify-content-center m-0 p-0 col-md-12" id="">
                <div class="col-md-12 pr-0 " id="">                                     
                    <!-- start power button  -->
    				<span id="back_dir_btn" class="badge border hidden cpointer rounded_medium p-2 mosy_msdn " data-mosy_msdn="up_directory()" > 
                      <i class="fa fa-arrow-up"></i> Back
                    </span>          	                          					
                    <!-- End power button  -->
                    <!-- start power button  -->
    				<span  class="badge border cpointer rounded_medium p-2 mosy_msdn " data-mosy_msdn="mosytoggle_addclass('back_dir_btn','hidden');push_html('active_dir','..');req_scan_dir();" > 
                      <i class="fa fa-home"></i> Home
                    </span>          	                          					
                    <!-- End power button  -->  
                    <!-- start power button  -->
    				<span  class="badge border cpointer rounded_medium p-2 mosy_msdn " data-mosy_msdn="mosytoggle_addclass('back_dir_btn','hidden');push_html('active_dir','..');req_scan_dir('yes');" > 
                      <i class="fa fa-search"></i> Deep Search
                    </span>          	                          					
                    <!-- End power button  -->                    
                    <!-- start power button  -->
    				<span  class="badge border cpointer rounded_medium p-2 mosy_msdn " data-mosy_msdn="magic_yes_no_alert('Are you sure you want to while list the files as safe?', 'alert_box', 'white_list_dir()', 'blackhole()')" > 
                      <i class="fa fa-check-circle"></i> Whitelist files
                    </span>          	                          					
                    <!-- End power button  -->                    
                <div class="col-md-12 p-0  " id=""><b>Listing <span id="active_dir">..</span></b></div>
                <input type="text" onkeyup="search_log(this.value, 'result_node')" id="" name="" class="form-control" value=""   placeholder="Search Files & folders "/>
                  <div class="col-md-12 p-2" id="search_msg"></div>
                </div>
                </div>
                <div class="max_height_80vh m-0 p-2 col-md-12" id="folder_scan_isle"></div>
              </div>
              <div class="col-md-4 border-left p-0 rounded_medium">                              
                <div class="col-md-12 border-bottom h4 bg-info p-2 text-white ">Security</div>
                            <!-- start power editor Widget  -->
			<div class="row justify-content-center m-0 p-0 col-md-12 rounded_big p-1">
				<div class="row justify-content-center m-0 p-0 col-md-12">
                  <div class="col-md-12 pt-2 text-right " id="">
                    <!-- start power button  -->
    				<span  class="badge border cpointer rounded_medium p-2 mosy_msdn " data-mosy_msdn="search_log('Suspicious File', 'result_node')" > 
                      <i class="fa fa-flag text-danger "></i> Flagged files
                    </span>          	                          					
                    <!-- End power button  -->                    
                                        
                    <!-- start power button  -->
    				<span id="" name="" class="badge border cpointer rounded_medium ml-3 p-2 mosy_msdn text-right" data-mosy_msdn="mosy_card('Quarantine multi files',get_html('qbatch_tray'))" > 
                      <i class="fa fa-trash"></i> Batch Quarantine
                    </span>          	                          					
                    <!-- End power button  -->
                    <template id="qbatch_tray">
                      <div class="row justify-content-left m-0 p-0 col-md-12" id="">
                     <div class="form-group text-left col-md-12">
                        <label >File name to Quarantine </label>
                        <input class="form-control" id="quarantine_arr" name="quarantine_arr" value="" placeholder="Backup file name" type="text">
                      </div>
                     <div class="form-group text-left col-md-12">
                        <label >Skip Files with paths </label>
                        <input class="form-control" id="skip_qarr" name="skip_qarr" value="" placeholder="Backup file name" type="text">
                      </div>   
                      </div>
                       <div class="col-md-12 text-right">
                         <div class="cpointer btn btn-primary mb-3" onclick="run_batch_quarantine()"><i class="fa fa-arrow-right "></i> Proceed </div>
                    </div>
                    </template>
                    
                    <!-- start power button  -->
    				<span id="" name="" class="badge border cpointer rounded_medium ml-3 p-2 mosy_msdn text-right" data-mosy_msdn="mosy_card('Create back up ',get_html('update_tray'))" > 
                      <i class="fa fa-upload"></i> Create Backup
                    </span>          	                          					
                    <!-- End power button  -->
                    <template id="update_tray">
                     <div class="form-group text-left col-md-12">
                        <label >  Backup file name </label>
                        <input class="form-control" id="back_up_file_name" name="back_up_file_name" value="" placeholder="Backup file name" type="text">               				
                       <div class="col-md-12 text-right">
                         <div class="cpointer btn btn-primary mb-3" onclick="create_backup()"><i class="fa fa-arrow-right "></i> Proceed </div>
                        </div>
                    </div>
                    </template>
                  </div>
              	</div>              
  			</div>              
            <!-- end power editor Widget  -->
                <div class="row justify-content-center m-0 p-2 col-md-12 bg-white rounded_medium border border_set" id="security_tab">                                      
                  <div class="col-md-12 pt-3 p-0" id=""></div>

                	<div class="col-md-12  " id=""><b>File:</b><span  id="file_name" class="pl-2"></span></div>
                	<div class="col-md-12  " id=""><b>Location:</b><span  id="file_dir" class="pl-2"></span></div>
                	<div class="col-md-12  " id=""><b>Date Created :</b><span  id="created_time" class="pl-2"></span></div>
                	<div class="col-md-12  " id=""><b> Flagged :</b><span  id="flag_status" class="pl-2"></span></div>
                                          
                  <div class="mt-2 text-center  border-top  col-md-12">
                          <span class="mr-3 badge cpointer" onclick="magic_yes_no_alert(' Quarantine this file?'+get_html('file_name'), 'alert_box', 'quarantine_exe_file()', 'mosy_reload()')"><i class="fa fa-shield"></i> Quarantine file</span>                            
                          <span class="mr-3 badge cpointer" onclick="search_log(get_html('file_name'), 'result_node')"> <i class="fa fa-search"></i> More like this </span> 
                          <span class="mr-3 badge cpointer" onclick="magic_yes_no_alert('Are you sure you want to quarantine all flagged Files?', 'alert_box', 'quarantine_all()', 'mosy_reload()')"><i class="fa fa-list"></i> Quarantine Flagged </span> 
  						</div> 
                  <div class="row justify-content-center m-0 p-0 col-md-12" id="">
                    <textarea class="bg-light" readonly id="file_prev" style="min-height:70vh;"></textarea>
                  </div>
                </div>
              </div>
              <div class="col-md-4 border-left p-0 rounded_medium">
                 <div class=" col-md-12 border-bottom h4 bg-info p-2 text-white ">Quarantine</div>
                <div class="col-md-12 p-2  " id=""><b>Listing <span id="qactive_dir">./intelli_quarantine</span> <span onclick="magic_yes_no_alert('Permanently delete all quarantined files? This cannot be undone !!', 'alert_box', 'empty_quarantine()', 'mosy_reload()')" class="pl-3 cpointer badge border-bottom text-danger"> Empty Quarantined Files  </span></b></div>
                <input type="text" onkeyup="search_log(this.value, 'result_node')" id="" name="" class="form-control" value=""   placeholder="Search Files & folders "/>
                  <div class="col-md-12 p-2" id="search_msg"></div>
                <div class="max_height_80vh m-0 p-2 col-md-12" id="q_scan_isle"></div>
           
              </div>
            </div>
			<!-- End body content -->     
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include('./includes/admin_footer.php');?>  
<script type="text/javascript">
function run_batch_quarantine()
{
    if(mosy_validate_required(['quarantine_arr','skip_qarr'])==1)
    {
      magic_message('Back in progress...', 'dialog_box');
      //mosyajax_get('run_batch_quarantine='+get_newval('quarantine_arr')+'&skip_qarr='+get_newval('skip_qarr')+'&root_folder='+get_html('active_dir'), 'push_shtml:Batch succesfully complete');
            mosyajax_get('run_batch_quarantine='+get_newval('quarantine_arr')+'&skip_qarr='+get_newval('skip_qarr')+'&root_folder='+get_html('active_dir'), 'mosy_response');

    }
  
}
  
function create_backup()
{
  if(mosy_validate_required(['back_up_file_name'])==1)
    {
      magic_message('Back in progress...', 'dialog_box');
      mosyajax_get('create_backup='+get_html('active_dir')+'&file_name='+get_newval('back_up_file_name'), 'backup_complete');
    }
}
  
function backup_complete()
{
  magic_message('Back up complete', 'dialog_box');
}
  
function quarantine_exe_file()
{
  quarantine_file(get_html('file_dir')+'/'+get_html('file_name'))
}
  
  
function quarantine_file(filepath)
{
  mosyajax_get('quarantine_file='+filepath, 'quarantine_loop')
}
  
function empty_quarantine()
{
    mosyajax_get('empty_quarantine', 'mosy_reload')
}
function quarantine_all()
{

  mosytoggle_addclass('back_dir_btn','hidden');
  push_html('active_dir','..');
  req_scan_dir('yes','no','active_dir','folder_scan_isle','yes');

}
  
  
function quarantine_loop()
{
  req_scan_dir('','','qactive_dir', 'q_scan_isle');
}
  
function req_scan_dir(deep_search="",add_to_inventory="",active_dir="active_dir", list_node="folder_scan_isle", exe_quarantine="")
{

  mosyajax_get('scan_folder='+get_html(active_dir)+'&deep_search='+deep_search+"&add_to_inventory="+add_to_inventory+'&exe_quarantine='+exe_quarantine, 'list_folder:'+list_node)
  
}

req_scan_dir();
req_scan_dir('','','qactive_dir', 'q_scan_isle');

function list_folder(server_resp, result_node="folder_scan_isle")
{
  push_html(result_node, server_resp+"<hr>"+get_html(result_node))
}
  
function white_list_dir()
{
  mosytoggle_addclass('back_dir_btn','hidden');
  push_html('active_dir','..');
  req_scan_dir('yes','yes');
}
function up_directory()
{
  var curr_path_1 = get_html('active_dir');
  var curr_path_2=curr_path_1.replace(/^\/+|\/+$/g, '');;
  var curr_path=curr_path_2.replace(/^\/+|\/+$/g, '');;
  
  var split_active_dir = curr_path.split('');

  var last_char = split_active_dir.splice(-1);  
  
  if(last_char=="/")
  {
     alert(curr_path);
      curr_path = (curr_path.substring(0, curr_path.length-1));
  }
  
  var dir_up = curr_path.split("/");
  
  var back_str = dir_up.splice(-1);
  
  var new_str=get_html('active_dir').replace(back_str, "");
    
  //alert(new_str);
  
  push_html('active_dir', new_str);
  
  req_scan_dir();

}
  
function stage_file(file,directory, created, flag_status)
{
  push_html('file_name', file)
  push_html('file_dir', directory)
  push_html('created_time', created)
  push_html('flag_status', flag_status)
  
  if(flag_status!='')
  {
  
    mosytoggle_addclass('security_tab', 'bg-danger')
    mosytoggle_addclass('security_tab', 'text-white')
  }else{
    mosytoggle_remclass('security_tab', 'bg-danger')
    mosytoggle_remclass('security_tab', 'text-white')
  }
  
  
  mosyajax_get('open_file='+directory+"/"+file, 'view_file')
  
}
  
function view_file(server_resp)
{
  push_newval('file_prev', server_resp);
}
function search_log(input, qclass) 
{
  //alert(input);
  push_html('search_msg', " Searching `"+input+"`")
  var filter = input.toLowerCase();
  var nodes = document.getElementsByClassName(qclass);  

  var count_nodes=0;

  for (i = 0; i < nodes.length; i++) {
    if (nodes[i].innerText.toLowerCase().includes(filter)) {  

      nodes[i].style.display = "flex";  
      count_nodes=1;
            
    } else {
      nodes[i].style.display = "none";
    }
  }
  
}
</script>
</form>
</body> 
</html><style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style>
<script>
window.onscroll = function() {termial_xsendcurspos()};

function termial_xsendcurspos() {
if(document.documentElement.scrollTop>0){
  window.parent.document.getElementById("prevscroll_px").value=document.documentElement.scrollTop; 
}
}
</script>