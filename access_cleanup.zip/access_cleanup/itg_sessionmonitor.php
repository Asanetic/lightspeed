<?php
  $session_itg_logged_user_id="";
 
  if(isset($_SESSION['session_itg_logged_user_id']))
  {
  	$session_itg_logged_user_id=$_SESSION['session_itg_logged_user_id'];
  }
  
  if(!isset($_SESSION["session_itg_logged"]))
  {

      $ref_url_go_to='?ref_url_go_to='.base64_encode(magic_current_url());

      header('location:./itg_login.php'.$ref_url_go_to.'');

      exit;

  }
  ?>