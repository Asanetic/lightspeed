<?php 
  
function download_zip_file()
{
  
  $app_name="avastanti";

  $project_folder="../../".$app_name;

  $zip_name="terminal.zip";

  $app_name_str="Asanetic Academy";

  echo '<a href="'.$project_folder.'/terminal/home" target="_blank">View Folder</a>';

  if (!file_exists($project_folder)) @mkdir($project_folder);

  //ui_write_to_file(''.$project_folder.'/'.$zip_name, file_get_contents('https://github.com/Asanetic/lightspeed/blob/main/simpleui.zip?raw=true'));
  ui_write_to_file(''.$project_folder.'/'.$zip_name, file_get_contents('https://github.com/Asanetic/lightspeed/blob/main/terminal.zip?raw=true'));


  $zip = new ZipArchive;
  $res = $zip->open(''.$project_folder.'/'.$zip_name);

  if ($res === TRUE) 
  {
   $zip->extractTo(''.$project_folder.'/');
   $zip->close();
  }

}
//=============Create app frame work 


function create_db($mysqliconn, $db_to_create)
{
  
    // Make my_db the current database
    $db_selected = mysqli_select_db($mysqliconn, $db_to_create);

    if (!$db_selected) {
      // If we couldn't, then it either doesn't exist, or we can't see it.

      if (mysqli_query($mysqliconn, "CREATE DATABASE $db_to_create")) {
          echo "Database $db_to_create created successfully\n";
      }else{
        echo "Oops! Db not created ".mysqli_error($mysqliconn);
      }
    }


}

function import_snippet_db()
{
  global $host;
  global $password;
  global $snippets_db;
  global $username;
  global $single_conn;
  
   create_db($single_conn, $snippets_db);
  
  $db_file='https://clearphrases.com/terminalx/snippets_db.sql';
  
  $download_db=file_put_contents('import_snippets_db.sql', file_get_contents($db_file));
  
  magic_sql_import_db('import_snippets_db.sql', $host, $username, $password, $snippets_db);
  
}
  
function magic_sql_import_db($filename, $host, $username, $password, $mysql_database)
{

  // Connect to MySQL server
  $mysliconn_imp=mysqli_connect($host, $username, $password) or die('Error connecting to MySQL server: ' . mysqli_error($mysliconn_imp));
  // Select database
  mysqli_select_db($mysliconn_imp, $mysql_database) or die('Error selecting MySQL database: ' . mysqli_error($mysliconn_imp));

  // Temporary variable, used to store current query
  $templine = '';
  // Read in entire file
  $lines = file($filename);
  // Loop through each line
  foreach ($lines as $line)
  {
    // Skip it if it's a comment
    if (substr($line, 0, 2) == '--' || $line == '')
        continue;

    // Add this line to the current segment
    $templine .= $line;
    // If it has a semicolon at the end, it's the end of the query
    if (substr(trim($line), -1, 1) == ';')
    {
        // Perform the query
        mysqli_query($mysliconn_imp, $templine) or print('<span style="color:red;">Error performing query \'<strong>' . $templine . '\': ' . mysqli_error($mysliconn_imp) . '<br /><br /></span>');
        // Reset temp variable to empty
        $templine = '';
    }
  }
   echo "Tables imported successfully";
}


/////create_app_frmrk($app_name_str);



function ui_write_to_file($file_path, $new_content_to_write, $skip_echo="")
{

	global $final_file_content;
  
  if (!file_exists($file_path))
  {
  	$file_to_write = fopen($file_path, 'w') or die("can't open file");
	fwrite($file_to_write, $new_content_to_write);
	fclose($file_to_write);

	$final_file_content=file_get_contents($file_path);
	if($skip_echo=="")
    {
		echo '<h2><u>File Succesfully created on <a href="'.$file_path.'" target="_blank">'.$file_path.'</a></u></h2>';
    }
  }else{
    	if($skip_echo=="")
        {
  		  echo "<h2>Sorry, File Overwrite is not allowed, a similar file '".$file_path."'  already exists. Delete this file before creating a new one. </h2> ";
        }
  }

	return $final_file_content;

}


?>