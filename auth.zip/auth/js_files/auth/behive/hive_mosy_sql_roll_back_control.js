//============================================================ ++++ start mosy_sql_roll_back datahandler js =============================
   
    

    //Start get  mosy_sql_roll_back Data ===============
    
      function get_mosy_sql_roll_back(mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col, mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination, route_url_name="auth")
      {        
        var req_url=route_url_name;

        mosyflex_sel("mosy_sql_roll_back", mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col , mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination,req_url);
        
      }
    //End get  mosy_sql_roll_back Data ===============

    //Start insert  mosy_sql_roll_back Data ===============

	function add_mosy_sql_roll_back(mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string)
    {
		
        mosyajax_create_data("mosy_sql_roll_back", mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string);
     }
     
    //End insert  mosy_sql_roll_back Data ===============

    
    //Start update  mosy_sql_roll_back Data ===============

    function update_mosy_sql_roll_back(mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string){
    
		mosyajax_update("mosy_sql_roll_back", mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    
    }
    //end  update  mosy_sql_roll_back Data ===============

	//Start drop  mosy_sql_roll_back Data ===============
    function mosy_sql_roll_back_drop(mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    {
        mosyajax_drop("mosy_sql_roll_back", mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)

    }
	//End drop  mosy_sql_roll_back Data ===============
    
    function initialize_mosy_sql_roll_back(qstr="", mosy_sql_roll_back_callback_function_string="",route_url_name="auth")
    {
    
    ///alert(qstr);
      var mosy_sql_roll_back_token_query =qstr;
      if(qstr=="")
      {
       var mosy_sql_roll_back_token_query_param="";
       var mosy_sql_roll_back_js_uptoken=mosy_get_param("mosy_sql_roll_back_uptoken");
       //alert(mosy_sql_roll_back_js_uptoken);
       if(mosy_sql_roll_back_js_uptoken!==undefined)
       {
       
        mosy_sql_roll_back_token_query_param = atob(mosy_sql_roll_back_js_uptoken);
       }
        mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_token_query_param)+"'";
        
           if (document.getElementById("mosy_sql_roll_back_uptoken") !==null) {
           	if(document.getElementById("mosy_sql_roll_back_uptoken").value!="")
            {
            
            var mosy_sql_roll_back_atob_tbl_key =atob(document.getElementById("mosy_sql_roll_back_uptoken").value);
            
                   
            mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_atob_tbl_key)+"'";

            }
           }
      }
      
      var mosy_sql_roll_back_push_ui_data_to =mosy_sql_roll_back_callback_function_string;
      if(mosy_sql_roll_back_callback_function_string=="")
      {
      mosy_sql_roll_back_push_ui_data_to = "add_mosy_sql_roll_back_ui_data";
      }
                
      console.log(mosy_sql_roll_back_token_query+" -- "+mosy_sql_roll_back_js_uptoken);

	  //alert(mosy_sql_roll_back_push_ui_data_to);

	 var req_url=route_url_name;

     get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_mosy_sql_roll_back_ui_data(mosy_sql_roll_back_server_resp) 
    {
    
    ///alert(mosy_sql_roll_back_server_resp);
    
    var json_decoded_str=JSON.parse(mosy_sql_roll_back_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load mosy_sql_roll_back data on the fly ==============
    
	var gft_mosy_sql_roll_back_str="(primkey LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
    
    function  gft_mosy_sql_roll_back(qmosy_sql_roll_back_str)
    {
        	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(qmosy_sql_roll_back_str));
            
            return  clean_mosy_sql_roll_back_filter_str;

    }
    
    function load_mosy_sql_roll_back(mosy_sql_roll_back_qstr, mosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, mosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray, route_url_name="auth")
    {
    
    var fmosy_sql_roll_back_result_function="push_result";
      
    if(mosy_sql_roll_back_result_function!="")
    {
          var fmosy_sql_roll_back_result_function=mosy_sql_roll_back_result_function;

    }
    	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(mosy_sql_roll_back_qstr));
        
        var fmosy_sql_roll_back_where_str=" where "+clean_mosy_sql_roll_back_filter_str;

    if(mosy_sql_roll_back_where_str!="")
    {
          var fmosy_sql_roll_back_where_str=" "+mosy_sql_roll_back_where_str;

    }

	  var req_url=route_url_name;

      get_mosy_sql_roll_back("*", fmosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, fmosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray,"",req_url);

  }
    ///=============== load mosy_sql_roll_back data on the fly ==============


 ///=quick load 
 
function qkload_mosy_sql_roll_back(qstr, push_fun="", ui_card="", and_query="", additional_cols="", mosy_sql_roll_back_pagination="",route_url_name="auth")
{


      mosy_sql_roll_back_list_nodes_str=ui_card;
  
   
   var mosy_sql_roll_back_qret_fun="push_grid_result:mosy_sql_roll_back_tbl_list";
   
   if(push_fun!="")
   {
    mosy_sql_roll_back_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_mosy_sql_roll_back("*", ajaxw+" ("+gft_mosy_sql_roll_back(qstr)+") "+combined_query+"  order by primkey desc ", mosy_sql_roll_back_list_cols+additional_cols_str, "",mosy_sql_roll_back_qret_fun, "c=>"+mosy_sql_roll_back_list_nodes_str, mosy_sql_roll_back_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_mosy_sql_roll_back(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_mosy_sql_roll_back("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_mosy_sql_roll_back(mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col, mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination, route_url_name="auth") 

}


//qddata
function qmosy_sql_roll_back_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_mosy_sql_roll_back("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_mosy_sql_roll_back(mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col, mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination, route_url_name="auth")    

}



//sum 

function sum_mosy_sql_roll_back(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_mosy_sql_roll_back("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_mosy_sql_roll_back_(mosy_sql_roll_back_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'mosy_sql_roll_back_rem_(\''+mosy_sql_roll_back_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_mosy_sql_roll_back_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="auth")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   mosy_sql_roll_back_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_mosy_sql_roll_back_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="auth")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   mosy_sql_roll_back_updt_(formid,"",response_fun,req_url)
 }
}

function mosy_sql_roll_back_ins_(formid, required_inp=null, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function mosy_sql_roll_back_updt_(formid, required_inp, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function mosy_sql_roll_back_rem_(req_token, callback_function_string="",route_url_name="auth")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletemosy_sql_roll_back&mosy_sql_roll_back_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_mosy_sql_roll_back_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('mosy_sql_roll_back')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End mosy_sql_roll_back datahandler js =============================
   
   ///mosy_sql_roll_back data_nodes 
  var mosy_sql_roll_back_data_nodes ='{{row_count}}|{{primkey}}|{{roll_bk_key}}|{{table_name}}|{{roll_type}}|{{where_str}}|{{roll_timestamp}}|{{value_entries}}';



   var mosy_sql_roll_back_list_cols ="primkey:primkey,roll_bk_key:roll_bk_key,table_name:table_name,roll_type:roll_type,where_str:where_str,roll_timestamp:roll_timestamp,value_entries:value_entries";

;
        
   ///start mosy_sql_roll_back search columns 
   
   var data_nodes_gft_mosy_sql_roll_back_str="(primkey LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
    
    function  data_nodes_gft_mosy_sql_roll_back(qmosy_sql_roll_back_str)
    {
        	var data_nodes_clean_mosy_sql_roll_back_filter_str=data_nodes_gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(qmosy_sql_roll_back_str));
            
            return  data_nodes_clean_mosy_sql_roll_back_filter_str;

    }
       ///end mosy_sql_roll_back search columns 

  function mosy_mosy_sql_roll_back_ui_node (mosy_sql_roll_back_json_data, mosy_sql_roll_back_load_to, mosy_sql_roll_back_cols_, mosy_sql_roll_back_template_ui)
  {
     ////alert(mosy_sql_roll_back_template_ui);
     var mosy_sql_roll_back_cols_fun_cols_str ="";
     
     if(typeof mosy_sql_roll_back_cols_fun_cols !== "undefined")
      {
        mosy_sql_roll_back_cols_fun_cols_str=mosy_sql_roll_back_cols_fun_cols;
        
        ///alert(mosy_sql_roll_back_cols_fun_cols)
      } 
      
     var mosy_sql_roll_back_ui__ = mosy_list_render_(mosy_sql_roll_back_json_data, mosy_sql_roll_back_cols_fun_cols_str+mosy_sql_roll_back_cols_, mosy_sql_roll_back_template_ui) 

     ////push_html(mosy_sql_roll_back_load_to, mosy_sql_roll_back_ui__)  

     push_grid_result(mosy_sql_roll_back_ui__, mosy_sql_roll_back_load_to)
  }
  
 
 ///////
 
 var mosy_sql_roll_back_auto_function= '{"cbfun":"process_mosy_sql_roll_back_json_data","_data_isle":"mosy_sql_roll_back_data_isle","_pagination_isle":"mosy_sql_roll_back_pagination_isle","_data_template":"hive_mosy_sql_roll_back_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_mosy_sql_roll_back","req_url":"auth"}';

 
 
 ///============ auto renders 
 
 
function mosy_mosy_sql_roll_back_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", mosy_sql_roll_back_pagination_prefix_="__pgnt_mosy_sql_roll_back", colstr="*", req_url="auth")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("mosy_sql_roll_back", btoa(qstr))
  }else{
    mosy_delete_get_pram("mosy_sql_roll_back")
  }
  
  if(mosy_get_param("mosy_sql_roll_back")!==undefined)
  {
    qstr=atob(mosy_get_param("mosy_sql_roll_back"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:mosy_sql_roll_back_page_no:"+mosy_limit;
  }
  
  ///hive_mosy_sql_roll_back_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_mosy_sql_roll_back_json_data","_data_isle":"mosy_sql_roll_back_data_isle","_pagination_isle":"mosy_sql_roll_back_pagination_isle","_data_template":"hive_mosy_sql_roll_back_data_template","_payload_str":"req","_pagination_prefix":"'+mosy_sql_roll_back_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_mosy_sql_roll_back_(response_fun," where "+gft_mosy_sql_roll_back(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, mosy_sql_roll_back_pagination_prefix_,req_url)
  
}


  
  function autoprocess_mosy_sql_roll_back_json_data(mosy_sql_roll_back_server_resp)
  {  
    mosy_mosy_sql_roll_back_ui_node(mosy_sql_roll_back_server_resp, "mosy_sql_roll_back_data_isle", mosy_sql_roll_back_data_nodes, get_html(hive_mosy_sql_roll_back_data_template),"", "l:mosy_sql_roll_back_page_no:15")
    mosy_paginate_api(mosy_sql_roll_back_server_resp, "mosy_sql_roll_back_page_no", "mosy_sql_roll_back_pagination_isle", "15")
  }
  
  function process_mosy_sql_roll_back_json_data(mosy_sql_roll_back_server_resp, mosy_sql_roll_back_callback="")
  {  
      var mosy_sql_roll_back_data_isle="mosy_sql_roll_back_data_isle";
      var mosy_sql_roll_back_data_node_template="hive_mosy_sql_roll_back_data_template";
      var mosy_sql_roll_back_pagination_isle="mosy_sql_roll_back_pagination_isle";
      var mosy_sql_roll_back_payload_str="";
      var mosy_sql_roll_back__pagination_prefix_str="__pgnt_mosy_sql_roll_back";
      
       ///alert(mosy_sql_roll_back_callback)
       ///alert(mosy_sql_roll_back_server_resp)
       ///console.log(mosy_sql_roll_back_server_resp)
              
      try {
        
           const mosy_sql_roll_back_jsonObject = JSON.parse(mosy_sql_roll_back_callback);
        
           mosy_sql_roll_back_data_isle=mosy_sql_roll_back_jsonObject._data_isle;
           mosy_sql_roll_back_data_node_template=mosy_sql_roll_back_jsonObject._data_template;
           mosy_sql_roll_back_pagination_isle=mosy_sql_roll_back_jsonObject._pagination_isle;
           mosy_sql_roll_back_payload_str=mosy_sql_roll_back_jsonObject._payload_str;
           mosy_sql_roll_back__pagination_prefix_str=mosy_sql_roll_back_jsonObject._pagination_prefix;
           mosy_sql_roll_back__req_url=mosy_sql_roll_back_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+mosy_sql_roll_back_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+mosy_sql_roll_back_callback);
        
         if(mosy_sql_roll_back_callback.indexOf(",") >= 0)
         {
              mosy_sql_roll_back_data_handler_ui =mosy_sql_roll_back_callback.split(",");                                 

              if(mosy_sql_roll_back_data_handler_ui[0]!=undefined){ mosy_sql_roll_back_data_isle=mosy_sql_roll_back_data_handler_ui[0];}

              if(mosy_sql_roll_back_data_handler_ui[1]!=undefined){mosy_sql_roll_back_data_node_template =mosy_sql_roll_back_data_handler_ui[1];}

              if(mosy_sql_roll_back_data_handler_ui[2]!=undefined){ mosy_sql_roll_back_pagination_isle=mosy_sql_roll_back_data_handler_ui[2]};

              if(mosy_sql_roll_back_data_handler_ui[3]!=undefined){ mosy_sql_roll_back_payload_str=btoa(mosy_sql_roll_back_data_handler_ui[3])};
              
              if(mosy_sql_roll_back_data_handler_ui[4]!=undefined){ mosy_sql_roll_back__pagination_prefix_str=btoa(mosy_sql_roll_back_data_handler_ui[4])};

			  if(mosy_sql_roll_back_data_handler_ui[5]!=undefined){ mosy_sql_roll_back__req_url=mosy_sql_roll_back_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+mosy_sql_roll_back_data_isle)
       
            mosy_mosy_sql_roll_back_ui_node(mosy_sql_roll_back_server_resp, mosy_sql_roll_back_data_isle, mosy_sql_roll_back_data_nodes, get_html(mosy_sql_roll_back_data_node_template),"", "l:mosy_sql_roll_back_page_no:"+mosy_limit)                       
            
             if(mosy_sql_roll_back_payload_str==="req")
             {
                
                mosy_paginate_api(mosy_sql_roll_back_server_resp, "mosy_sql_roll_back_page_no", mosy_sql_roll_back_pagination_isle, "process_mosy_sql_roll_back_json_data", mosy_sql_roll_back__pagination_prefix_str,mosy_sql_roll_back__req_url)

             }
           
  }
    

function mosyrender_mosy_sql_roll_back_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_mosy_sql_roll_back", req_url="auth")
{
   
  if(pagination==="")
  {
    pagination="l:mosy_sql_roll_back_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _mosy_sql_roll_back_payload="mosyget_&tbl=mosy_sql_roll_back&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_mosy_sql_roll_back_payload+curl_url)
  
  var _mosy_sql_roll_back_pagination_json = '{"_payload":"'+_mosy_sql_roll_back_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _mosy_sql_roll_back_payload_input = document.createElement("input");
                _mosy_sql_roll_back_payload_input.setAttribute('type', 'hidden');
                _mosy_sql_roll_back_payload_input.setAttribute('name',_txt_payload);
                _mosy_sql_roll_back_payload_input.setAttribute('id', _txt_payload);

                // Add the _mosy_sql_roll_back_payload_input element to the DOM
                document.body.appendChild(_mosy_sql_roll_back_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _mosy_sql_roll_back_pagination_json)
  mosyajax_get(_mosy_sql_roll_back_payload, response_fun, req_url);
  
  return _mosy_sql_roll_back_payload;
  
}


function mginitialize_mosy_sql_roll_back(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _mosy_sql_roll_back_payload="mosyget_&tbl=mosy_sql_roll_back&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_mosy_sql_roll_back_payload, response_fun, req_url);


}

 

