//============================================================ ++++ start page_manifest_ datahandler js =============================
   
    

    //Start get  page_manifest_ Data ===============
    
      function get_page_manifest_(page_manifest__colstr, page_manifest__filter_col, page_manifest__cols, page_manifest__node_function_name, page_manifest__callback_function_string, page_manifest__ui_tag, page_manifest__pagination, route_url_name="auth")
      {        
        var req_url=route_url_name;

        mosyflex_sel("page_manifest_", page_manifest__colstr, page_manifest__filter_col , page_manifest__cols, page_manifest__node_function_name, page_manifest__callback_function_string, page_manifest__ui_tag, page_manifest__pagination,req_url);
        
      }
    //End get  page_manifest_ Data ===============

    //Start insert  page_manifest_ Data ===============

	function add_page_manifest_(page_manifest__cols, page_manifest__vals, page_manifest__callback_function_string)
    {
		
        mosyajax_create_data("page_manifest_", page_manifest__cols, page_manifest__vals, page_manifest__callback_function_string);
     }
     
    //End insert  page_manifest_ Data ===============

    
    //Start update  page_manifest_ Data ===============

    function update_page_manifest_(page_manifest__update_str, page_manifest__where_str, page_manifest__callback_function_string){
    
		mosyajax_update("page_manifest_", page_manifest__update_str, page_manifest__where_str, page_manifest__callback_function_string)
    
    }
    //end  update  page_manifest_ Data ===============

	//Start drop  page_manifest_ Data ===============
    function page_manifest__drop(page_manifest__where_str, page_manifest__callback_function_string)
    {
        mosyajax_drop("page_manifest_", page_manifest__where_str, page_manifest__callback_function_string)

    }
	//End drop  page_manifest_ Data ===============
    
    function initialize_page_manifest_(qstr="", page_manifest__callback_function_string="",route_url_name="auth")
    {
    
    ///alert(qstr);
      var page_manifest__token_query =qstr;
      if(qstr=="")
      {
       var page_manifest__token_query_param="";
       var page_manifest__js_uptoken=mosy_get_param("page_manifest__uptoken");
       //alert(page_manifest__js_uptoken);
       if(page_manifest__js_uptoken!==undefined)
       {
       
        page_manifest__token_query_param = atob(page_manifest__js_uptoken);
       }
        page_manifest__token_query = " where primkey='"+(page_manifest__token_query_param)+"'";
        
           if (document.getElementById("page_manifest__uptoken") !==null) {
           	if(document.getElementById("page_manifest__uptoken").value!="")
            {
            
            var page_manifest__atob_tbl_key =atob(document.getElementById("page_manifest__uptoken").value);
            
                   
            page_manifest__token_query = " where primkey='"+(page_manifest__atob_tbl_key)+"'";

            }
           }
      }
      
      var page_manifest__push_ui_data_to =page_manifest__callback_function_string;
      if(page_manifest__callback_function_string=="")
      {
      page_manifest__push_ui_data_to = "add_page_manifest__ui_data";
      }
                
      console.log(page_manifest__token_query+" -- "+page_manifest__js_uptoken);

	  //alert(page_manifest__push_ui_data_to);

	 var req_url=route_url_name;

     get_page_manifest_("*", page_manifest__token_query, "primkey", "blackhole", page_manifest__push_ui_data_to, "", "", req_url);
     

    }
    
    function add_page_manifest__ui_data(page_manifest__server_resp) 
    {
    
    ///alert(page_manifest__server_resp);
    
    var json_decoded_str=JSON.parse(page_manifest__server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load page_manifest_ data on the fly ==============
    
	var gft_page_manifest__str="(primkey LIKE '%{{qpage_manifest_}}%' OR  manikey LIKE '%{{qpage_manifest_}}%' OR  page_group LIKE '%{{qpage_manifest_}}%' OR  site_id LIKE '%{{qpage_manifest_}}%' OR  page_url LIKE '%{{qpage_manifest_}}%' OR  hive_site_id LIKE '%{{qpage_manifest_}}%' OR  hive_site_name LIKE '%{{qpage_manifest_}}%' OR  project_id LIKE '%{{qpage_manifest_}}%' OR  project_name LIKE '%{{qpage_manifest_}}%')";
    
    function  gft_page_manifest_(qpage_manifest__str)
    {
        	var clean_page_manifest__filter_str=gft_page_manifest__str.replace(/{{qpage_manifest_}}/g, magic_clean_str(qpage_manifest__str));
            
            return  clean_page_manifest__filter_str;

    }
    
    function load_page_manifest_(page_manifest__qstr, page_manifest__where_str, page_manifest__ret_cols, page_manifest__user_function, page_manifest__result_function, page_manifest__data_tray, route_url_name="auth")
    {
    
    var fpage_manifest__result_function="push_result";
      
    if(page_manifest__result_function!="")
    {
          var fpage_manifest__result_function=page_manifest__result_function;

    }
    	var clean_page_manifest__filter_str=gft_page_manifest__str.replace(/{{qpage_manifest_}}/g, magic_clean_str(page_manifest__qstr));
        
        var fpage_manifest__where_str=" where "+clean_page_manifest__filter_str;

    if(page_manifest__where_str!="")
    {
          var fpage_manifest__where_str=" "+page_manifest__where_str;

    }

	  var req_url=route_url_name;

      get_page_manifest_("*", fpage_manifest__where_str, page_manifest__ret_cols, page_manifest__user_function, fpage_manifest__result_function, page_manifest__data_tray,"",req_url);

  }
    ///=============== load page_manifest_ data on the fly ==============


 ///=quick load 
 
function qkload_page_manifest_(qstr, push_fun="", ui_card="", and_query="", additional_cols="", page_manifest__pagination="",route_url_name="auth")
{


      page_manifest__list_nodes_str=ui_card;
  
   
   var page_manifest__qret_fun="push_grid_result:page_manifest__tbl_list";
   
   if(push_fun!="")
   {
    page_manifest__qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_page_manifest_("*", ajaxw+" ("+gft_page_manifest_(qstr)+") "+combined_query+"  order by primkey desc ", page_manifest__list_cols+additional_cols_str, "",page_manifest__qret_fun, "c=>"+page_manifest__list_nodes_str, page_manifest__pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_page_manifest_(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_page_manifest_("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_page_manifest_(page_manifest__colstr, page_manifest__filter_col, page_manifest__cols, page_manifest__node_function_name, page_manifest__callback_function_string, page_manifest__ui_tag, page_manifest__pagination, route_url_name="auth") 

}


//qddata
function qpage_manifest__ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_page_manifest_("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_page_manifest_(page_manifest__colstr, page_manifest__filter_col, page_manifest__cols, page_manifest__node_function_name, page_manifest__callback_function_string, page_manifest__ui_tag, page_manifest__pagination, route_url_name="auth")    

}



//sum 

function sum_page_manifest_(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_page_manifest_("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_page_manifest__(page_manifest__data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'page_manifest__rem_(\''+page_manifest__data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_page_manifest__ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="auth")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   page_manifest__ins_(formid,"",response_fun,req_url)
 }
}

function mosy_page_manifest__updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="auth")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   page_manifest__updt_(formid,"",response_fun,req_url)
 }
}

function page_manifest__ins_(formid, required_inp=null, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "page_manifest__insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function page_manifest__updt_(formid, required_inp, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "page_manifest__update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function page_manifest__rem_(req_token, callback_function_string="",route_url_name="auth")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletepage_manifest_&page_manifest__uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_page_manifest__updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('page_manifest_')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End page_manifest_ datahandler js =============================
   
   ///page_manifest_ data_nodes 
  var page_manifest__data_nodes ='{{row_count}}|{{primkey}}|{{manikey}}|{{page_group}}|{{site_id}}|{{page_url}}|{{hive_site_id}}|{{hive_site_name}}|{{project_id}}|{{project_name}}';



   var page_manifest__list_cols ="primkey:primkey,manikey:manikey,page_group:page_group,site_id:site_id,page_url:page_url,hive_site_id:hive_site_id,hive_site_name:hive_site_name,project_id:project_id,project_name:project_name";

;
        
   ///start page_manifest_ search columns 
   
   var data_nodes_gft_page_manifest__str="(primkey LIKE '%{{qpage_manifest_}}%' OR  manikey LIKE '%{{qpage_manifest_}}%' OR  page_group LIKE '%{{qpage_manifest_}}%' OR  site_id LIKE '%{{qpage_manifest_}}%' OR  page_url LIKE '%{{qpage_manifest_}}%' OR  hive_site_id LIKE '%{{qpage_manifest_}}%' OR  hive_site_name LIKE '%{{qpage_manifest_}}%' OR  project_id LIKE '%{{qpage_manifest_}}%' OR  project_name LIKE '%{{qpage_manifest_}}%')";
    
    function  data_nodes_gft_page_manifest_(qpage_manifest__str)
    {
        	var data_nodes_clean_page_manifest__filter_str=data_nodes_gft_page_manifest__str.replace(/{{qpage_manifest_}}/g, magic_clean_str(qpage_manifest__str));
            
            return  data_nodes_clean_page_manifest__filter_str;

    }
       ///end page_manifest_ search columns 

  function mosy_page_manifest__ui_node (page_manifest__json_data, page_manifest__load_to, page_manifest__cols_, page_manifest__template_ui)
  {
     ////alert(page_manifest__template_ui);
     var page_manifest__cols_fun_cols_str ="";
     
     if(typeof page_manifest__cols_fun_cols !== "undefined")
      {
        page_manifest__cols_fun_cols_str=page_manifest__cols_fun_cols;
        
        ///alert(page_manifest__cols_fun_cols)
      } 
      
     var page_manifest__ui__ = mosy_list_render_(page_manifest__json_data, page_manifest__cols_fun_cols_str+page_manifest__cols_, page_manifest__template_ui) 

     ////push_html(page_manifest__load_to, page_manifest__ui__)  

     push_grid_result(page_manifest__ui__, page_manifest__load_to)
  }
  
 
 ///////
 
 var page_manifest__auto_function= '{"cbfun":"process_page_manifest__json_data","_data_isle":"page_manifest__data_isle","_pagination_isle":"page_manifest__pagination_isle","_data_template":"hive_page_manifest__data_template","_payload_str":"req","_pagination_prefix":"__pgnt_page_manifest_","req_url":"auth"}';

 
 
 ///============ auto renders 
 
 
function mosy_page_manifest__json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", page_manifest__pagination_prefix_="__pgnt_page_manifest_", colstr="*", req_url="auth")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("page_manifest_", btoa(qstr))
  }else{
    mosy_delete_get_pram("page_manifest_")
  }
  
  if(mosy_get_param("page_manifest_")!==undefined)
  {
    qstr=atob(mosy_get_param("page_manifest_"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:page_manifest__page_no:"+mosy_limit;
  }
  
  ///hive_page_manifest__data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_page_manifest__json_data","_data_isle":"page_manifest__data_isle","_pagination_isle":"page_manifest__pagination_isle","_data_template":"hive_page_manifest__data_template","_payload_str":"req","_pagination_prefix":"'+page_manifest__pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_page_manifest__(response_fun," where "+gft_page_manifest_(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, page_manifest__pagination_prefix_,req_url)
  
}


  
  function autoprocess_page_manifest__json_data(page_manifest__server_resp)
  {  
    mosy_page_manifest__ui_node(page_manifest__server_resp, "page_manifest__data_isle", page_manifest__data_nodes, get_html(hive_page_manifest__data_template),"", "l:page_manifest__page_no:15")
    mosy_paginate_api(page_manifest__server_resp, "page_manifest__page_no", "page_manifest__pagination_isle", "15")
  }
  
  function process_page_manifest__json_data(page_manifest__server_resp, page_manifest__callback="")
  {  
      var page_manifest__data_isle="page_manifest__data_isle";
      var page_manifest__data_node_template="hive_page_manifest__data_template";
      var page_manifest__pagination_isle="page_manifest__pagination_isle";
      var page_manifest__payload_str="";
      var page_manifest___pagination_prefix_str="__pgnt_page_manifest_";
      
       ///alert(page_manifest__callback)
       ///alert(page_manifest__server_resp)
       ///console.log(page_manifest__server_resp)
              
      try {
        
           const page_manifest__jsonObject = JSON.parse(page_manifest__callback);
        
           page_manifest__data_isle=page_manifest__jsonObject._data_isle;
           page_manifest__data_node_template=page_manifest__jsonObject._data_template;
           page_manifest__pagination_isle=page_manifest__jsonObject._pagination_isle;
           page_manifest__payload_str=page_manifest__jsonObject._payload_str;
           page_manifest___pagination_prefix_str=page_manifest__jsonObject._pagination_prefix;
           page_manifest___req_url=page_manifest__jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+page_manifest__callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+page_manifest__callback);
        
         if(page_manifest__callback.indexOf(",") >= 0)
         {
              page_manifest__data_handler_ui =page_manifest__callback.split(",");                                 

              if(page_manifest__data_handler_ui[0]!=undefined){ page_manifest__data_isle=page_manifest__data_handler_ui[0];}

              if(page_manifest__data_handler_ui[1]!=undefined){page_manifest__data_node_template =page_manifest__data_handler_ui[1];}

              if(page_manifest__data_handler_ui[2]!=undefined){ page_manifest__pagination_isle=page_manifest__data_handler_ui[2]};

              if(page_manifest__data_handler_ui[3]!=undefined){ page_manifest__payload_str=btoa(page_manifest__data_handler_ui[3])};
              
              if(page_manifest__data_handler_ui[4]!=undefined){ page_manifest___pagination_prefix_str=btoa(page_manifest__data_handler_ui[4])};

			  if(page_manifest__data_handler_ui[5]!=undefined){ page_manifest___req_url=page_manifest__data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+page_manifest__data_isle)
       
            mosy_page_manifest__ui_node(page_manifest__server_resp, page_manifest__data_isle, page_manifest__data_nodes, get_html(page_manifest__data_node_template),"", "l:page_manifest__page_no:"+mosy_limit)                       
            
             if(page_manifest__payload_str==="req")
             {
                
                mosy_paginate_api(page_manifest__server_resp, "page_manifest__page_no", page_manifest__pagination_isle, "process_page_manifest__json_data", page_manifest___pagination_prefix_str,page_manifest___req_url)

             }
           
  }
    

function mosyrender_page_manifest__(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_page_manifest_", req_url="auth")
{
   
  if(pagination==="")
  {
    pagination="l:page_manifest__page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _page_manifest__payload="mosyget_&tbl=page_manifest_&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_page_manifest__payload+curl_url)
  
  var _page_manifest__pagination_json = '{"_payload":"'+_page_manifest__payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _page_manifest__payload_input = document.createElement("input");
                _page_manifest__payload_input.setAttribute('type', 'hidden');
                _page_manifest__payload_input.setAttribute('name',_txt_payload);
                _page_manifest__payload_input.setAttribute('id', _txt_payload);

                // Add the _page_manifest__payload_input element to the DOM
                document.body.appendChild(_page_manifest__payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _page_manifest__pagination_json)
  mosyajax_get(_page_manifest__payload, response_fun, req_url);
  
  return _page_manifest__payload;
  
}


function mginitialize_page_manifest_(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _page_manifest__payload="mosyget_&tbl=page_manifest_&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_page_manifest__payload, response_fun, req_url);


}

 

