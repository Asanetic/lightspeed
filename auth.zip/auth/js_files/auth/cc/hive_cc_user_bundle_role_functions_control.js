
   const hive_user_bundle_role_functions_ins_btn = document.querySelectorAll(".hive_user_bundle_role_functions_ins_btn");
        hive_user_bundle_role_functions_ins_btn.forEach(user_bundle_role_functions_ins_btn => {
          user_bundle_role_functions_ins_btn.addEventListener("click", event => {
          
          mosy_user_bundle_role_functions_ins_fun()
          
          });
        });
        
        
   const hive_user_bundle_role_functions_updt_btn = document.querySelectorAll(".hive_user_bundle_role_functions_updt_btn");
        hive_user_bundle_role_functions_updt_btn.forEach(user_bundle_role_functions_updt_btn => {
          user_bundle_role_functions_updt_btn.addEventListener("click", event => {
          
          mosy_user_bundle_role_functions_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var user_bundle_role_functions_data_template=get_html("user_bundle_role_functions_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_user_bundle_role_functions_ui_data(qstr="",callback="", andquery="", _user_bundle_role_functions_auto_function="")
      {      
        
        
         /// ==============user_bundle_role_functions custom js auto response function  ================
    var custom_user_bundle_role_functions_auto_function= '{"cbfun":"process_user_bundle_role_functions_json_data","_data_isle":"user_bundle_role_functions_data_isle:9","_pagination_isle":"user_bundle_role_functions_pagination_isle","_data_template":"hive_user_bundle_role_functions_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_user_bundle_role_functions"}';
    
/// ==============user_bundle_role_functions custom js auto response function  ================
   
    
      if(_user_bundle_role_functions_auto_function!="")
      {
      	custom_user_bundle_role_functions_auto_function = _user_bundle_role_functions_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_user_bundle_role_functions_json_data_list(qstr, custom_user_bundle_role_functions_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      