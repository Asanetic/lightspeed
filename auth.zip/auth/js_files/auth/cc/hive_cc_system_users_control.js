
   const hive_system_users_ins_btn = document.querySelectorAll(".hive_system_users_ins_btn");
        hive_system_users_ins_btn.forEach(system_users_ins_btn => {
          system_users_ins_btn.addEventListener("click", event => {
          
          mosy_system_users_ins_fun()
          
          });
        });
        
        
   const hive_system_users_updt_btn = document.querySelectorAll(".hive_system_users_updt_btn");
        hive_system_users_updt_btn.forEach(system_users_updt_btn => {
          system_users_updt_btn.addEventListener("click", event => {
          
          mosy_system_users_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var system_users_data_template=get_html("system_users_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_system_users_ui_data(qstr="",callback="", andquery="", _system_users_auto_function="")
      {      
        
        
         /// ==============system_users custom js auto response function  ================
    var custom_system_users_auto_function= '{"cbfun":"process_system_users_json_data","_data_isle":"system_users_data_isle:20","_pagination_isle":"system_users_pagination_isle","_data_template":"hive_system_users_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_system_users"}';
    
/// ==============system_users custom js auto response function  ================
   
    
      if(_system_users_auto_function!="")
      {
      	custom_system_users_auto_function = _system_users_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_system_users_json_data_list(qstr, custom_system_users_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      