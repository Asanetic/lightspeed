                        
                      var hive_system_users_data_template = 
                      `<!--- system_users data nodes -->
                        <div id="system_users_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('system_users_uptoken',btoa('{{login_password}}'));mginitialize_system_users('{{login_password}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          							<td><img src="{{user_pic}}" onerror="this.src=''"  style="width:50px; height:50px; border-radius:50%;"></td>

                          							<td>{{user_id}}</td>
							<td>{{name}}</td>
							<td>{{email}}</td>
							<td>{{tel}}</td>
							<td>{{ref_id}}</td>
							<td>{{regdate}}</td>
							<td>{{user_no}}</td>
							<td>{{user_gender}}</td>
							<td>{{last_seen}}</td>
							<td>{{about}}</td>
							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
							<td>{{auth_token}}</td>
							<td>{{token_status}}</td>
							<td>{{token_expiring_in}}</td>
							<td>{{project_id}}</td>
							<td>{{project_name}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_system_users_head_template = 
                      `<!--- system_users data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                          							<th>USER PIC</th>
    
                          							<th>USER ID</th>
							<th>NAME</th>
							<th>EMAIL</th>
							<th>TEL</th>
							<th>REF ID</th>
							<th>REGDATE</th>
							<th>USER NO</th>
							<th>USER GENDER</th>
							<th>LAST SEEN</th>
							<th>ABOUT</th>
							<th>HIVE SITE ID</th>
							<th>HIVE SITE NAME</th>
							<th>AUTH TOKEN</th>
							<th>TOKEN STATUS</th>
							<th>TOKEN EXPIRING IN</th>
							<th>PROJECT ID</th>
							<th>PROJECT NAME</th>
    
                        </tr>`                                              
                        
              var hive_cv_system_users_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search system users " name="qtxt_system_users" id="qtxt_system_users" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_system_users_ui_data(get_newval('qtxt_system_users'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qsystem_users_btn" id="qsystem_users_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_system_users_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
