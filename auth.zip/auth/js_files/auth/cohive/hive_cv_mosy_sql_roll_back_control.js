                        
                      var hive_mosy_sql_roll_back_data_template = 
                      `<!--- mosy_sql_roll_back data nodes -->
                        <div id="mosy_sql_roll_back_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('mosy_sql_roll_back_uptoken',btoa('{{primkey}}'));mginitialize_mosy_sql_roll_back('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{table_name}}</td>
							<td>{{roll_type}}</td>
							<td>{{where_str}}</td>
							<td>{{roll_timestamp}}</td>
							<td>{{value_entries}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_mosy_sql_roll_back_head_template = 
                      `<!--- mosy_sql_roll_back data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>TABLE NAME</th>
							<th>ROLL TYPE</th>
							<th>WHERE STR</th>
							<th>ROLL TIMESTAMP</th>
							<th>VALUE ENTRIES</th>
    
                        </tr>`                                              
                        
              var hive_cv_mosy_sql_roll_back_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search mosy sql roll back " name="qtxt_mosy_sql_roll_back" id="qtxt_mosy_sql_roll_back" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_mosy_sql_roll_back_ui_data(get_newval('qtxt_mosy_sql_roll_back'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qmosy_sql_roll_back_btn" id="qmosy_sql_roll_back_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_mosy_sql_roll_back_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
