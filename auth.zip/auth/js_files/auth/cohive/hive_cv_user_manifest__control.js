                        
                      var hive_user_manifest__data_template = 
                      `<!--- user_manifest_ data nodes -->
                        <div id="user_manifest__tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('user_manifest__uptoken',btoa('{{primkey}}'));mginitialize_user_manifest_('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{user_id}}</td>
							<td>{{user_name}}</td>
							<td>{{role_id}}</td>
							<td>{{site_id}}</td>
							<td>{{role_name}}</td>
							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
							<td>{{project_id}}</td>
							<td>{{project_name}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_user_manifest__head_template = 
                      `<!--- user_manifest_ data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>USER ID</th>
							<th>USER NAME</th>
							<th>ROLE ID</th>
							<th>SITE ID</th>
							<th>ROLE NAME</th>
							<th>HIVE SITE ID</th>
							<th>HIVE SITE NAME</th>
							<th>PROJECT ID</th>
							<th>PROJECT NAME</th>
    
                        </tr>`                                              
                        
              var hive_cv_user_manifest__search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search user manifest  " name="qtxt_user_manifest_" id="qtxt_user_manifest_" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_user_manifest__ui_data(get_newval('qtxt_user_manifest_'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="quser_manifest__btn" id="quser_manifest__btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_user_manifest__ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
