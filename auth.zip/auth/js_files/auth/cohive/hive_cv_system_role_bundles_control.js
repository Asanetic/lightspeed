                        
                      var hive_system_role_bundles_data_template = 
                      `<!--- system_role_bundles data nodes -->
                        <div id="system_role_bundles_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('system_role_bundles_uptoken',btoa('{{primkey}}'));mginitialize_system_role_bundles('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{bundle_id}}</td>
							<td>{{bundle_name}}</td>
							<td>{{remark}}</td>
							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_system_role_bundles_head_template = 
                      `<!--- system_role_bundles data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>BUNDLE ID</th>
							<th>BUNDLE NAME</th>
							<th>REMARK</th>
							<th>HIVE SITE ID</th>
							<th>HIVE SITE NAME</th>
    
                        </tr>`                                              
                        
              var hive_cv_system_role_bundles_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search system role bundles " name="qtxt_system_role_bundles" id="qtxt_system_role_bundles" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_system_role_bundles_ui_data(get_newval('qtxt_system_role_bundles'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qsystem_role_bundles_btn" id="qsystem_role_bundles_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_system_role_bundles_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
