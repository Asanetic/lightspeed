<?php
ob_start();
include('../root_configs/s_env_root.php');
include($s_env_root.'/superauth_env.php');
include($common_root.'/be/data_control/conn.php');
include($common_root.'/data_control/phpmagicbits.php');
include($common_root.'/data_control/gwdna.php');
include($common_root.'/data_control/hive_routes.php');
include($common_root.'/data_control/hive_gw.php');

$mosy_page_title="Access Denied";
if(isset($_GET['mosy_page_title']))
{
  $mosy_page_title=base64_decode($_GET['mosy_page_title']);
}

include('./saconfig.php');
include('./sauth_sessionmonitor.php');
 
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title> <?php echo $mosy_page_title ?></title>
<?php include($common_root.'/includes/admin_css_scripts.php');?>
</head>
<body class="mini-sidebar">
    
<form method="post" enctype="multipart/form-data" id="mosy_form">
  <div class="main-wrapper">
  <?php include($common_root.'/includes/mainnav.php'); ?>
    <div class="page-wrapper">
      <div class="content container-fluid">
        <div class="page-header p-0 m-0 ">
          <div class="row m-0 p-0  col-md-12  ">
            <div class="col-md-12 p-0 m-0">
              <h3 class="page-title"> <?php echo $mosy_page_title ?> </h3>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12">
			<div class="col-md-12 p-3 "></div>
			<!-- Start body content -->
  			<?php  include('./features/auth/denied_ui.php'); ?>
            <!-- End body content -->     
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include($common_root.'/includes/admin_footer.php');?>  
<script type="text/javascript">

</script>
</form>
</body> 
</html>