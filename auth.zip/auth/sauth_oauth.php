<?php        
  
  ///===The script below is designed to be used by users with accounts in the system_users table only
  
  ////user login script 
  function system_users_mosy_login($login_password,$user_name,$endpoint="")
  {
    
        global $oauth_table;
        global $session_user_mail;
        global $session_user_tel;
        global $session_prefix;
        global $password_col;
        global $user_id_col;
        global $username;

    
        $additional_login_arr ="login_btn&username=".base64_encode($user_name)."&password=".base64_encode($login_password)."&passwordcol=".base64_encode($password_col)."&usernamecol=".base64_encode($session_user_mail)."";
        $login_res_=mgqhivesql_gdata($oauth_table, "", $endpoint,"",$additional_login_arr);
        
        ///print_r($login_res_);
        if(!empty($login_res_[$session_user_mail]) && !empty($login_res_[$password_col]))
        {

          $_SESSION['session_'.$session_prefix.'_logged']=TRUE;
          $_SESSION['session_'.$session_prefix.'_logged_email']=$login_res_[$session_user_mail];
          $_SESSION['session_'.$session_prefix.'_logged_tel']=$login_res_[$session_user_tel];
          $_SESSION['session_'.$session_prefix.'_logged_name']=$login_res_[$username];
          $_SESSION['session_'.$session_prefix.'_logged_user_id']=$login_res_[$user_id_col];
          $_SESSION['session_'.$session_prefix.'_logged_hive_site_id']=$login_res_['hive_site_id'];
          $_SESSION['session_'.$session_prefix.'_logged_ref_id']=$login_res_['ref_id'];
          $_SESSION['session_'.$session_prefix.'_logged_hive_site_name']=$login_res_['hive_site_name'];
          $_SESSION['session_'.$session_prefix.'_logged_auth_token']=$login_res_['auth_token'];
          
          $auth_token_=magic_random_str(170);
        
          $plus_one_day=date("Y-m-d H:i:s", strtotime("+1 days", strtotime(date("Y-m-d H:i:s"))));
          
          //------- begin system_users_arr --> 
          $token_udate_arr=array(
          "txt_auth_token"=>$auth_token_,
          "txt_token_status"=>"Active",
          "txt_token_expiring_in"=>$plus_one_day,
 		  $oauth_table."_uptoken"=>base64_encode($login_res_['primkey']), 
          $oauth_table."_update_btn"=>"ok"           
          );
          //===-- End system_users_arr -->

          mosypost_($token_udate_arr, "", $endpoint);

          $_SESSION['session_'.$session_prefix.'_logged_auth_token']=$auth_token_;
          
          if(isset($_GET['ref_url_go_to'])){

              $ref_url_go_to=base64_decode($_GET['ref_url_go_to']);

              header("location:".$ref_url_go_to."");


          }else{

             header("location:./sasplash");

          }

          }else{

              echo magic_message("Wrong password or user name please try again");
          }

    }



    if(isset($_POST["btn_login"]))
    {
     system_users_mosy_login($_POST["txt_password"],$_POST["txt_username"], 'authapi');
    }
    //=== End Log in to rm_users Login Script query
  
  
//=========request password

function system_users_request_pass_($membusername, $superauth_route="")
{

        global $oauth_table;
        global $session_user_mail;
        global $session_prefix;
        global $password_col;
        global $username;
        global $primkey;
  
    $additional_reset_arr="resetpassword&emailcol=".base64_encode($session_user_mail)."&email=".base64_encode($membusername)."";
  
    $login_res_=mgqhivesql_gdata($oauth_table, "",$superauth_route,"",$additional_reset_arr);
 
    if(isset($login_res_[$session_user_mail]))
    {

      $sender_name="ClearPhrases Reset Pssword"; 
      $tel="0710766390"; 

      $from_email="clearphrases@gmail.com";

      $to_email=$membusername;
      $client_names=$login_res_[$username];


      $path1="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
      //echo $path1;

      $msgtosend='Hello You requested a password request. Follow this link to create a new password.<br /><br />
      <a href="'.$path1.'?reset_token='.base64_encode($login_res_[$primkey]).'">Reset Password</a><br /><br />';

      $message=$msgtosend;
      $subject="Password reset Request";
      $actlink="http://www.clearphrases.com";

	  mosy_send_mail($to_email, $from_email, $sender_name, $subject, $message, "yes");
      
      //echo $msgtosend;

      echo magic_message("We have sent you a reset password email to ".$login_res_[$session_user_mail].".<hr> Follow that link to reset your password");

    }else{
    echo magic_message("Sorry that email does not exist. Please Try Again");
    }
}
//===================reset password request  
  
  
if(isset($_POST["request_password_reset_btn"]))
{
   system_users_request_pass_($_POST["txt_email"],'authapi');
}

function system_users_change_password($primkey, $pass1, $pass2, $endpoint="")
{
  global $oauth_table;
  global $password_col;
  
  if($pass1=="" || $pass2=="")
  {

    echo magic_message("Password cannot be blank!!");
  
  }else{
  
  if($pass1!=$pass2)
  {

    echo magic_message("Password Do Not match!!");
  
    }else{

      ///mysqli_query($mysqliconn,"UPDATE `$superauth`.`` SET login_password='$resetpass1' WHERE ='$foundresetmail' AND primkey='$memberkey'");

      echo magic_message("Password reset succesfully. Login afresh to continue.");

      $pass_reset_arr=["txt_".$password_col=>$pass1, $oauth_table."_uptoken"=>base64_encode($primkey), $oauth_table."_update_btn"=>"ok"];

      return mosypost_($pass_reset_arr, "", $endpoint);
    }
  }
  
}
//===========reset pass=============   


if(isset($_POST["confirm_password_reset_btn"]))
{

  $txt_password_one=mmres($_POST["txt_password_one"]);
  $txt_password_two=mmres($_POST["txt_password_two"]);
  $reset_token=base64_decode($_GET["reset_token"]);

  system_users_change_password($reset_token,$txt_password_one,$txt_password_two,'authapi');

  echo '<meta http-equiv="refresh" content="4;url='.$login_file.'">';

}

function system_users_create_acc($user_acc_regr, $additional_arr, $endpoint="")
{
 
    return mosypost_($user_acc_regr, $additional_arr, $endpoint);
 
}


//user create account 
if(isset($_POST["create_user_acc"]))
{
  $req_email=mmres($_POST["txt_".$session_user_mail]);
  
  $count_dup_username=mgcount_hivesql($oauth_table, "",'authapi',"","emailduplicate&emailcol=".base64_encode($session_user_mail)."&email=".base64_encode($req_email)."");
  
  ////echo "dupmail".$count_dup_username;
  
  if($count_dup_username==0)
  {
     $system_users_create_acc_request= system_users_create_acc($_POST, $oauth_table."_insert_btn",'authapi');
      
     if($system_users_create_acc_request)
     {
      echo magic_screen('Account Created Succesfully.<hr> <a href="'.$login_file.'" class="btn btn-primary">Click Here To Login</a>');
     }else{
     echo magic_screen("An error Occured when creating your account. Kindy try again");
     
     }
                                            
  }else{
   
   echo magic_message("Duplicate email found. Kindy try another one.");
   
  }
}

?>
