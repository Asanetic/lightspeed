<?php
ob_start();
include('../root_configs/s_env_root.php');
include($s_env_root.'/superauth_env.php');
include($common_root.'/be/data_control/conn.php');
include($common_root.'/data_control/phpmagicbits.php');
include($common_root.'/data_control/gwdna.php');
include($common_root.'/data_control/hive_routes.php');
include($common_root.'/data_control/hive_gw.php');

///=============== user_bundle_role_functions hive control ====================
include('./hive_control/superauth/user_bundle_role_functions/hive_user_bundle_role_functions_dh.php');
include('./hive_control/superauth/user_bundle_role_functions/hive_user_bundle_role_functions_api_rh.php');
include('./hive_control/superauth/user_bundle_role_functions/hive_user_bundle_role_functions_rh.php');
    

include($common_root.'/auth/saconfig.php');
include($common_root.'/auth/sauth_sessionmonitor.php');






$mosy_page_title="Role functions";
if(isset($_GET['mosy_page_title']))
{
  $mosy_page_title=base64_decode($_GET['mosy_page_title']);
}
 
$def_dashboard="";
  
if(isset($def_dashboard_))
{
  $def_dashboard=$def_dashboard_;
}

if(!isset($side_bar_type)){
  
 $side_bar_type="mini-sidebar"; //mini-sidebar || ""
}

?>
  
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title> <?php echo $mosy_page_title ?></title>
<?php include($common_root.'/includes/admin_css_scripts.php');?>
</head>
<body class="<?php echo $side_bar_type; ?>">
    
<form method="post" enctype="multipart/form-data" id="mosy_form">
  <div class="main-wrapper">
  <?php include($common_root.'includes/mainnav.php'); ?>  
    <div class="page-wrapper">
      <div class="content container-fluid skin_plasma p-0 m-0">
        <div class="row m-0 p-0 ">
          <div class="col-sm-12 p-0 m-0">
			<!-- Start body content -->
              <?php include('features/superauth/user_bundle_role_functions/custom_user_bundle_role_functions_role_functions_list_wgt.php');?>
			<!-- End body content -->     
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include($common_root.'/includes/admin_footer.php');?>  
<script type="text/javascript">
//{{js_script_loop}}
</script>
<!--mosy_page_script-->
</form>
</body> 
</html>