<?php
include($common_root.'/auth/hive_control/auth/page_manifest_/hive_page_manifest__dh.php');
include($common_root.'/auth/hive_control/auth/user_manifest_/hive_user_manifest__dh.php');
include($common_root.'/auth/hive_control/auth/user_bundle_role_functions/hive_user_bundle_role_functions_dh.php');

function sa_uac($user_id, $access_key="", $access_type="user", $endpoint="auth")
{
  
  if($access_key=="")    
  {
    $access_key=magic_basename(magic_current_url());
  }
  
    
  $access_key=str_replace(".php", "", $access_key); 
  
  $page_group=mgqpage_manifest__ddata("page_url", $access_key,$endpoint);

  $pagegrp=getarr_val_($page_group, 'page_group');
  
  if($access_type=="overall")
  {
    $user_access_req=mgcount_user_bundle_role_functions("bundle_id='$user_id' and role_id='$pagegrp'", $endpoint);
  }else{
      $user_access_req=mgcount_user_manifest_(" user_id='$user_id' and role_name='$pagegrp' ",$endpoint);
  }

  //$user_role_attr=mgquser_manifest__gdata(" where  user_id='$user_id' and role_name='$pagegrp' ",$endpoint);
  //echo " status - ".$user_access_req;
  //echo " Page ".$pagegrp." - user_count - ".$user_access_req." NAme - ".getarr_val_($user_role_attr, 'user_name')." acc key - ".$access_key."<br>";  
  if($user_access_req>0)
  {
    $acc_state="Allowed";
  }else{
    $acc_state="Denied";
  }

  return $acc_state;
}



$sa_access_user_role_ = $_SESSION['session_'.$session_prefix.'_logged_ref_id'];
$sa_access_current_url = magic_basename(magic_current_url());

$ovveride_accesss_array_ = ["userdenied", "userdenied.php", "superadmin_acc_control"];

// Correct in_array() usage
if (!in_array($sa_access_current_url, $ovveride_accesss_array_)) {
    $role_access = sa_uac($sa_access_user_role_, "", "overall");

  $msg__status= " $sa_access_current_url - role $sa_access_user_role_ status $role_access";
  
 // echo magic_message($msg__status);
  
    if ($role_access == "Denied") {
     
     // header("location:" . $common_root . "auth/userdenied");
       // exit; // Always exit after redirection
    }
}



  
?>