<?php //===============Start Mosy queries-============ 

        function mpupdate_user_manifest_($custom_input_array="", $appname="auth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "insert","");

           $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);

            //echo $gwauthenticate_user_manifest__;

           if($gwauthenticate_user_manifest__json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $user_manifest__post_arr=$new_input_array;

                  

                  $user_manifest__return_key=mosypost_arr_($user_manifest__post_arr, ["user_manifest__update_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$user_manifest__return_key;

                  return $user_manifest__return_key;

           }
         
         }
         
        
        function mpadd_user_manifest_($custom_input_array="", $appname="auth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "insert","");

           $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);

            //echo $gwauthenticate_user_manifest__;

           if($gwauthenticate_user_manifest__json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $user_manifest__post_arr=$new_input_array;

                  

                  $user_manifest__return_key=mosypost_arr_($user_manifest__post_arr, ["user_manifest__insert_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$user_manifest__return_key;

                  return $user_manifest__return_key;

           }
         
         }
         
         
         
 	//Start Add user_manifest_ Data ===============
 	function add_user_manifest_($user_manifest__arr_)
    {
     $gw_user_manifest__cols=array();
     
     foreach($user_manifest__arr_ as $user_manifest__arr_gw => $user_manifest__arr_gw_val)
     {
     
     	$gw_user_manifest__cols[]=$user_manifest__arr_gw;
        
     }
     
     $gw_user_manifest__cols_str=implode(",", $gw_user_manifest__cols);
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "insert",$gw_user_manifest__cols_str);
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("user_manifest_", $user_manifest__arr_);
     
     	//echo $gwauthenticate_user_manifest__;

     }else{
     
     	echo $gwauthenticate_user_manifest__;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");

     }
     
    }
    
       function initialize_user_manifest_()
        {
        
         global $user_manifest__uptoken;
             
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "select","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
         
         	return get_user_manifest_("*", "WHERE primkey='$user_manifest__uptoken'", "r");
         
            echo $gwauthenticate_user_manifest__;

         }else{

         	echo $gwauthenticate_user_manifest__;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");
         
         }
        } 
        
       function mginitialize_user_manifest_($endpoint="auth",$function_json="")
        {
        
         global $user_manifest__uptoken;
             
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "select","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("user_manifest_", "*", "WHERE primkey='$user_manifest__uptoken'", "l",$function_json, $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_user_manifest__;

         }else{

         	echo $gwauthenticate_user_manifest__;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");
         
         }
        }         
    //End Add user_manifest_ Data ===============
                
    //Start Update user_manifest_ Data ===============
    
 	function update_user_manifest_($user_manifest__arr_, $where_str)
    {
         $gw_user_manifest__cols=array();
     
     foreach($user_manifest__arr_ as $user_manifest__arr_gw => $user_manifest__arr_gw_val)
     {
     
     	$gw_user_manifest__cols[]=$user_manifest__arr_gw;
        
     }
     
     $gw_user_manifest__cols_str=implode(",", $gw_user_manifest__cols);
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "update",$gw_user_manifest__cols_str);
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("user_manifest_", $user_manifest__arr_, $where_str);

       // echo $gwauthenticate_user_manifest__;
        
        exit;

     }else{

        echo $gwauthenticate_user_manifest__;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


      }
    
    }
 	
    
    //End Update user_manifest_ Data ===============


    //Start get  user_manifest_ Data ===============
    
    function get_user_manifest_($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "select","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {
    	return mosyflex_sel("user_manifest_", $colstr, $where_str, $type);

        //echo $gwauthenticate_user_manifest__;

	  }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }    
    }
    //End get  user_manifest_ Data ===============
    
  //Start get  user_manifest_ Data ===============
    
    function mgget_user_manifest_($colstr="*", $where_str="", $type="l", $endpoint="auth",$function_json="")
    {
          
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "select","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {
     
        return mosyget_("user_manifest_", $colstr, $where_str, $type,$function_json, $endpoint);
        
        
    	//return mosyflex_sel("user_manifest_", $colstr, $where_str, $type);

        //echo $gwauthenticate_user_manifest__;

	  }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }    
    }
    //End get  user_manifest_ Data ===============
            

    //======== quser_manifest__data qsingle query function
    
    function quser_manifest__data($qadmin_mkey_key)
    {
          
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "qdata","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
    	return get_user_manifest_("*", "WHERE admin_mkey='$qadmin_mkey_key'", "r");

		//echo $gwauthenticate_user_manifest__;

      }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }  
    }
    
    function mgquser_manifest__data($qadmin_mkey_key, $endpoint="auth",$function_json="")
    {
          
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "qdata","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("user_manifest_", "*", "WHERE admin_mkey='$qadmin_mkey_key'", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_user_manifest__;

      }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }  
    }
   
    //======== quser_manifest__data qsingle query function
    
    
     //======== user_manifest_ data to array
    
    function user_manifest__data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "data_array","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {  
     	$append_user_manifest__arr=array();
    
    	$array_user_manifest__q=get_user_manifest_($colstr, $where_str, "l");
        while($array_user_manifest__res=mysqli_fetch_array($array_user_manifest__q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_user_manifest__arr[]=$array_user_manifest__res[$tbl_col];
            }
          }else{
          	          
               $append_user_manifest__arr[]=$array_user_manifest__res;

          }
        }
        
        return $append_user_manifest__arr;

		//echo $gwauthenticate_user_manifest__;

      }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }  
    }
   
    //======== quser_manifest__data qsingle query function   
        
    //======== quser_manifest__ddata qsingle query function    
    function quser_manifest__ddata($admin_mkey_col, $qadmin_mkey_key)
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "qddata","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
    	return get_user_manifest_("*", "WHERE $admin_mkey_col='$qadmin_mkey_key'", "r");



		//echo $gwauthenticate_user_manifest__;

     }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }   
    }
    
    function mgquser_manifest__ddata($admin_mkey_col, $qadmin_mkey_key, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "qddata","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("user_manifest_", "*", "WHERE $admin_mkey_col='$qadmin_mkey_key'", "l",$function_json, $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_user_manifest__;

     }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }   
    }    
    //======== quser_manifest__ddata qsingle query function
    
        //======== quser_manifest__gdata qsingle query function    
    function quser_manifest__gdata($user_manifest__where="")
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "gddata","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
     	$where_str="";
        if($user_manifest__where!=="")
        {
        $where_str=" ".$user_manifest__where;
        }
    	return get_user_manifest_("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_user_manifest__;

     }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }   
    }
    
    function mgquser_manifest__gdata($user_manifest__where="", $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "gddata","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
     	$where_str="";
        if($user_manifest__where!=="")
        {
        $where_str=" ".$user_manifest__where;
        }
        
        $return_data_set = mosyget_("user_manifest_", "*", " ".$where_str." ", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_user_manifest__;

     }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }   
    }
    //======== quser_manifest__gdata qsingle query function
    

    //======== count user_manifest_ data function
    
    function count_user_manifest_($user_manifest__wherestr)
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "count_data","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
      $clean_user_manifest__where_str="";
  
      if($user_manifest__wherestr!='')
      {
        $clean_user_manifest__where_str="Where ".$user_manifest__wherestr;
      }

      return get_user_manifest_("count(*) as return_result", " ".$clean_user_manifest__where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_user_manifest__;

      }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }    
    }
    
    function mgcount_user_manifest_($user_manifest__wherestr, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "count_data","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
      $clean_user_manifest__where_str="";
  
      if($user_manifest__wherestr!='')
      {
        $clean_user_manifest__where_str="Where ".$user_manifest__wherestr;
      }

         $return_data_set= mosyget_("user_manifest_", "count(*) as return_result", " ".$clean_user_manifest__where_str."", "l", $function_json, $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_user_manifest__;

      }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");


     }    
    }    
    //======== count user_manifest_ data function
    
    

    //======== sum  user_manifest_ data function
    
    function sum_user_manifest_($user_manifest__sumcol, $user_manifest__wherestr)
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "sum_data","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
      $clean_user_manifest__where_str="";
  
      if($user_manifest__wherestr!='')
      {
        $clean_user_manifest__where_str="Where ".$user_manifest__wherestr;
      }

      $_sum_return = get_user_manifest_("sum($user_manifest__sumcol) as return_result", " ".$clean_user_manifest__where_str."", "r")["return_result"];
      
      if($_sum_return=="")
      {
      
       $_sum_return="0";
            
      }
      
      return $_sum_return;
      
      //echo $gwauthenticate_user_manifest__;


      }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");
        


     }    
    }
    
    function mgsum_user_manifest_($user_manifest__sumcol, $user_manifest__wherestr, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "sum_data","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
      $clean_user_manifest__where_str="";
  
      if($user_manifest__wherestr!='')
      {
        $clean_user_manifest__where_str="Where ".$user_manifest__wherestr;
      }
      
        $return_data_set = mosyget_("user_manifest_", "sum($user_manifest__sumcol) as return_result", " ".$clean_user_manifest__where_str."", "l",$function_json, $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

        
		return $result_node;

      //echo $gwauthenticate_user_manifest__;


      }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");
        


     }    
    }    
    
    //======== sum  user_manifest_ data function   
    
    
    //Start drop  user_manifest_ Data ===============
    
    function drop_user_manifest_($where_str)
    {
     
     $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "drop_data","");
     
     $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
     
     if($gwauthenticate_user_manifest__json["response"]=="ok")
     {    
    	return magic_sql_delete("user_manifest_", $where_str);

		//echo $gwauthenticate_user_manifest__;

      }else{
     
     	echo $gwauthenticate_user_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");
		

     }
    }
    //End drop  user_manifest_ Data ===============    
    
    
?>