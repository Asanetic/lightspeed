<?php //===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section user_manifest_
  //************************************************* START  user_manifest_ OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize user_manifest_ edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['user_manifest__table_alert']))
              	{	
                  if(isset($user_manifest__custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$user_manifest__uptoken="";

		if(isset($_GET["user_manifest__uptoken"]))
		{
		$user_manifest__uptoken=base64_decode($_GET["user_manifest__uptoken"]);
		}
        
        if(isset($_POST["user_manifest__uptoken"]))
		{
		$user_manifest__uptoken=base64_decode($_POST["user_manifest__uptoken"]);
		}
        //
        
          $user_manifest__alias_name="USER MANIFEST ";

          if(isset($user_manifest__alias))
          {
             $user_manifest__alias_name=$user_manifest__alias;

          }
          
        //get single data record query with $user_manifest__uptoken
        
        ///$user_manifest__node=get_user_manifest_("*", "WHERE primkey='$user_manifest__uptoken'", "r");
        
	
//************* START INSERT  user_manifest_ QUERY 
if(isset($_POST["user_manifest__insert_btn"])){
//------- begin user_manifest__arr_ins --> 
$user_manifest__arr_ins_=array(

"primkey"=>"NULL",
"admin_mkey"=>magic_random_str(7),
"user_id"=>"?",
"user_name"=>"?",
"role_id"=>"?",
"site_id"=>"?",
"role_name"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?",
"project_id"=>"?",
"project_name"=>"?"

);
//===-- End user_manifest__arr_ins -->


          
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "insert","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {

              $user_manifest__validated_ins_str=$user_manifest__arr_ins_;

              if(isset($user_manifest__ins_inputs))
              {
                $user_manifest__validated_ins_str=$user_manifest__ins_inputs;	
              }

              if(empty($user_manifest__validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$user_manifest__alias_name." request cannot be empty. Record not added");
              }else{


                $user_manifest__return_key=add_user_manifest_($user_manifest__validated_ins_str);
                
                mosy_sql_rollback("user_manifest_", "primkey='$user_manifest__return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$user_manifest__mosy_rest_req_vars=http_build_query($_POST);
                echo $user_manifest__mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $user_manifest__mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $user_manifest__return_key; 

                      } 

                    }else{ 

                                    
                $user_manifest__custom_redir1=add_url_param ("user_manifest__uptoken", base64_encode($user_manifest__return_key), "");
                $user_manifest__custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$user_manifest__custom_redir1);
                $user_manifest__custom_redir3=add_url_param ("user_manifest__table_alert", "user_manifest__added",$user_manifest__custom_redir2);
                
                ///echo magic_message($user_manifest__custom_redir1." -- ".$user_manifest__custom_redir2."--".$user_manifest__custom_redir3);
                
                $user_manifest__custom_redir=$user_manifest__custom_redir3;
                
               header('location:'.$user_manifest__custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_user_manifest__);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");
         
         }
      
}
//************* END  user_manifest_ INSERT QUERY 	
	

//************* START user_manifest_  UPDATE QUERY 
if(isset($_POST["user_manifest__update_btn"])){
//------- begin user_manifest__arr_updt --> 
$user_manifest__arr_updt_=array(



"user_id"=>"?",
"user_name"=>"?",
"role_id"=>"?",
"site_id"=>"?",
"role_name"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?",
"project_id"=>"?",
"project_name"=>"?"

);
//===-- End user_manifest__arr_updt -->



                     
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "update","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
         
            $user_manifest__validated_updt_str=$user_manifest__arr_updt_;

            if(isset($user_manifest__updt_inputs))
            {
              $user_manifest__validated_updt_str=$user_manifest__updt_inputs;	
            }

            if(empty($user_manifest__validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$user_manifest__alias_name."  input cannot be empty. Record not Updated");

            }else{
			$user_manifest__key_salt=initialize_user_manifest_()["admin_mkey"];
            
              update_user_manifest_($user_manifest__validated_updt_str, "primkey='$user_manifest__uptoken' and admin_mkey='$user_manifest__key_salt'");
				

			 mosy_sql_rollback("user_manifest_", "primkey='$user_manifest__uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $user_manifest__mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $user_manifest__mosy_rest_req_vars, "POST");
                
                }
             
              



                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $user_manifest__uptoken; 

                    } 

                  }else{ 

                $user_manifest__custom_redir1=add_url_param ("user_manifest__uptoken", base64_encode($user_manifest__uptoken), "");
                $user_manifest__custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$user_manifest__custom_redir1);
                $user_manifest__custom_redir3=add_url_param ("user_manifest__table_alert", "user_manifest__updated",$user_manifest__custom_redir2);
                
                ///echo magic_message($user_manifest__custom_redir1." -- ".$user_manifest__custom_redir2."--".$user_manifest__custom_redir3);
                
                $user_manifest__custom_redir=$user_manifest__custom_redir3;
                
               header('location:'.$user_manifest__custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_user_manifest__);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");
         
         }

      

      
}
//************* END user_manifest_  UPDATE QUERY 

    
    
      //== Start user_manifest_ delete record

      if(isset($_GET["deleteuser_manifest_"]))
      {
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "super_delete_request","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }


      $conf_del_user_manifest__btn=magic_button_link("./".$current_file_url."?user_manifest__uptoken=".$_GET["user_manifest__uptoken"]."&conf_deleteuser_manifest_&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_user_manifest__btn=magic_button_link("./".$current_file_url."?user_manifest__uptoken=".$_GET["user_manifest__uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_user_manifest__btn." ".$cancel_del_user_manifest__btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_user_manifest__);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteuser_manifest_"]))
      {
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "super_delete_confirm","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      //$user_manifest__del_key_salt=initialize_user_manifest_()["admin_mkey"];
      //mosy_sql_rollback("user_manifest_", "primkey='$user_manifest__uptoken'", "DELETE");
      //drop_user_manifest_("primkey='$user_manifest__uptoken' and admin_mkey='$user_manifest__del_key_salt'");
      $user_manifest_curlopt_url=$hive_routes["auth"];;
      $user_manifest_curlopt_httpheader="";
      $user_manifest_curlopt_userpwd="";
      $user_manifest_curlopt_post_fields="?conf_deleteuser_manifest_&user_manifest__uptoken=".base64_encode($user_manifest__uptoken);
      $user_manifest_curlopt_customrequest="GET";

      magic_post_curl($user_manifest_curlopt_url.$user_manifest_curlopt_post_fields, $user_manifest_curlopt_httpheader, $user_manifest_curlopt_userpwd, "", $user_manifest_curlopt_customrequest);

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_user_manifest__);

      }
      }

      //== End user_manifest_ delete record  
    
       ///SELECT STRING FOR user_manifest_============================
              
       if(isset($_POST["quser_manifest__btn"])){
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "quser_manifest__btn","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
            $current_user_manifest__url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_user_manifest__current_url=$current_user_manifest__url_params.'?quser_manifest_=';


            if (strpos($current_user_manifest__url_params, '?') !== false) {

                $clean_user_manifest__current_url=$current_user_manifest__url_params.'&quser_manifest_=';

            }
            if (strpos($current_user_manifest__url_params, '?quser_manifest_')) {

                $remove_user_manifest__old_token = substr($current_user_manifest__url_params, 0, strpos($current_user_manifest__url_params, "?quser_manifest_"));

                $clean_user_manifest__current_url=$remove_user_manifest__old_token.'?quser_manifest_=';

            }
            if(strpos($current_user_manifest__url_params, '&quser_manifest_')) {

                $remove_user_manifest__old_token = substr($current_user_manifest__url_params, 0, strpos($current_user_manifest__url_params, "&quser_manifest_"));

                $clean_user_manifest__current_url=$remove_user_manifest__old_token.'&quser_manifest_=';

            }
        $quser_manifest__str=base64_encode($_POST["txt_user_manifest_"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_user_manifest__current_url.($quser_manifest__str);
            } 

          }else{ 


             header('location:'.$clean_user_manifest__current_url.($quser_manifest__str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_user_manifest__);

        }
        }
        $quser_manifest_="";
               //handle data sensisitve filters
        $user_manifest__mdsf_="";
        $user_manifest__mdsf_qstr_without_where_="";
        $user_manifest__mdsf_qstr_with_where_="";

        if(isset($mosy_dsft_))
        {
          $user_manifest__mdsf_=$mosy_dsft_["global_filter"];
          
          if(isset($mosy_dsft_["user_manifest_"]))
          {
            $user_manifest__mdsf_=$mosy_dsft_["user_manifest_"];
          }
          
          if($user_manifest__mdsf_!="")
          {
            $user_manifest__mdsf_qstr_without_where_=" AND $user_manifest__mdsf_";
            $user_manifest__mdsf_qstr_with_where_=" WHERE $user_manifest__mdsf_";
            
          }
          
        }

        ///echo " dsgft__ $user_manifest__mdsf_ with  $user_manifest__mdsf_qstr_with_where_ wihout $user_manifest__mdsf_qstr_without_where_ ";
        
		if(isset($_GET["user_manifest__mosyfilter"]) && isset($_GET["quser_manifest_"])){
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "user_manifest__mosyfilter_n_query","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
         $quser_manifest_=mmres(base64_decode($_GET["quser_manifest_"]));
         
         $gft_user_manifest__where_query="(`admin_mkey` LIKE '%".$quser_manifest_."%' OR  `user_id` LIKE '%".$quser_manifest_."%' OR  `user_name` LIKE '%".$quser_manifest_."%' OR  `role_id` LIKE '%".$quser_manifest_."%' OR  `site_id` LIKE '%".$quser_manifest_."%' OR  `role_name` LIKE '%".$quser_manifest_."%' OR  `hive_site_id` LIKE '%".$quser_manifest_."%' OR  `hive_site_name` LIKE '%".$quser_manifest_."%' OR  `project_id` LIKE '%".$quser_manifest_."%' OR  `project_name` LIKE '%".$quser_manifest_."%') ".$user_manifest__mdsf_qstr_without_where_."";
         
         if($_GET["user_manifest__mosyfilter"]!=""){
         
         $mosyfilter_user_manifest__queries_str=(base64_decode($_GET["user_manifest__mosyfilter"]));
        
         $gft_user_manifest__where_query="(`admin_mkey` LIKE '%".$quser_manifest_."%' OR  `user_id` LIKE '%".$quser_manifest_."%' OR  `user_name` LIKE '%".$quser_manifest_."%' OR  `role_id` LIKE '%".$quser_manifest_."%' OR  `site_id` LIKE '%".$quser_manifest_."%' OR  `role_name` LIKE '%".$quser_manifest_."%' OR  `hive_site_id` LIKE '%".$quser_manifest_."%' OR  `hive_site_name` LIKE '%".$quser_manifest_."%' OR  `project_id` LIKE '%".$quser_manifest_."%' OR  `project_name` LIKE '%".$quser_manifest_."%') AND ".$mosyfilter_user_manifest__queries_str." ".$user_manifest__mdsf_qstr_without_where_."";
         
         }
         
		 $gft_user_manifest_="WHERE ".$gft_user_manifest__where_query;
         
         $gft_user_manifest__and=$gft_user_manifest__where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_user_manifest__);
        }
        }elseif(isset($_GET["quser_manifest_"])){
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "get_quser_manifest_","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
		 $quser_manifest_=mmres(base64_decode($_GET["quser_manifest_"]));
        
         $gft_user_manifest__where_query="(`admin_mkey` LIKE '%".$quser_manifest_."%' OR  `user_id` LIKE '%".$quser_manifest_."%' OR  `user_name` LIKE '%".$quser_manifest_."%' OR  `role_id` LIKE '%".$quser_manifest_."%' OR  `site_id` LIKE '%".$quser_manifest_."%' OR  `role_name` LIKE '%".$quser_manifest_."%' OR  `hive_site_id` LIKE '%".$quser_manifest_."%' OR  `hive_site_name` LIKE '%".$quser_manifest_."%' OR  `project_id` LIKE '%".$quser_manifest_."%' OR  `project_name` LIKE '%".$quser_manifest_."%') ".$user_manifest__mdsf_qstr_without_where_."";
         
         $gft_user_manifest_="WHERE ".$gft_user_manifest__where_query;
         
         $gft_user_manifest__and=$gft_user_manifest__where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_user_manifest__);

        }
        }elseif(isset($_GET["user_manifest__mosyfilter"])){
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "user_manifest__mosyfilter","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
         $gft_user_manifest__where_query="";
         $gft_user_manifest_="$user_manifest__mdsf_qstr_with_where_";

         if($_GET["user_manifest__mosyfilter"]!=""){
          $gft_user_manifest__where_query=(base64_decode($_GET["user_manifest__mosyfilter"]));
          $gft_user_manifest_="WHERE ".$gft_user_manifest__where_query." ".$user_manifest__mdsf_qstr_without_where_." ";
         }
         
         
         $gft_user_manifest__and=$gft_user_manifest__where_query." ".$user_manifest__mdsf_qstr_without_where_." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_user_manifest__);

        }
        }else{
         $gft_user_manifest_="$user_manifest__mdsf_qstr_with_where_";
         $gft_user_manifest__and="$user_manifest__mdsf_qstr_without_where_";
         $gft_user_manifest__where_query="";
        }
       
    //************************************************* END  user_manifest_ OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  ?>