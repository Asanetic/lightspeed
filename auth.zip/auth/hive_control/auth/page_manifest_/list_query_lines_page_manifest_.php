<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $auth_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$auth_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $auth_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$auth_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
  //add mosy list query
  $page_manifest__data_functions_arr=[];
  $page_manifest__data_functions=json_encode($page_manifest__data_functions_arr, true);
  
  $page_manifest__list_query=mosyget_("page_manifest_", "*", " $gft_page_manifest_ order by primkey Desc", "l:qpage_manifest__token:".$datalimit."", $page_manifest__data_functions, "auth");
?>