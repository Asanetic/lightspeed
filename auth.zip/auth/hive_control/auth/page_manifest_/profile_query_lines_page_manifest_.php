<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $auth_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$auth_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $auth_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$auth_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
 ///add mosy profile query 
  
  
  //add mosy profile query line
  $page_manifest__data_functions_arr=[];
  $page_manifest__data_functions=json_encode($page_manifest__data_functions_arr, true);
  
  
  $page_manifest__profile_node_query=mosyget_("page_manifest_", "*", " WHERE primkey='$page_manifest__uptoken' ", "l", $page_manifest__data_functions, "auth");
  $page_manifest__profile_result_node=[];   
  
  if(isset($page_manifest__profile_node_query["data"][0]))
  {  
    $page_manifest__profile_result_node=$page_manifest__profile_node_query["data"][0];
  }
 $page_manifest__node=$page_manifest__profile_result_node; 
?>
