<?php //===============Start Mosy queries-============ 

        function mpupdate_page_manifest_($custom_input_array="", $appname="auth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "insert","");

           $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);

            //echo $gwauthenticate_page_manifest__;

           if($gwauthenticate_page_manifest__json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $page_manifest__post_arr=$new_input_array;

                  

                  $page_manifest__return_key=mosypost_arr_($page_manifest__post_arr, ["page_manifest__update_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$page_manifest__return_key;

                  return $page_manifest__return_key;

           }
         
         }
         
        
        function mpadd_page_manifest_($custom_input_array="", $appname="auth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "insert","");

           $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);

            //echo $gwauthenticate_page_manifest__;

           if($gwauthenticate_page_manifest__json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $page_manifest__post_arr=$new_input_array;

                  

                  $page_manifest__return_key=mosypost_arr_($page_manifest__post_arr, ["page_manifest__insert_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$page_manifest__return_key;

                  return $page_manifest__return_key;

           }
         
         }
         
         
         
 	//Start Add page_manifest_ Data ===============
 	function add_page_manifest_($page_manifest__arr_)
    {
     $gw_page_manifest__cols=array();
     
     foreach($page_manifest__arr_ as $page_manifest__arr_gw => $page_manifest__arr_gw_val)
     {
     
     	$gw_page_manifest__cols[]=$page_manifest__arr_gw;
        
     }
     
     $gw_page_manifest__cols_str=implode(",", $gw_page_manifest__cols);
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "insert",$gw_page_manifest__cols_str);
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("page_manifest_", $page_manifest__arr_);
     
     	//echo $gwauthenticate_page_manifest__;

     }else{
     
     	echo $gwauthenticate_page_manifest__;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");

     }
     
    }
    
       function initialize_page_manifest_()
        {
        
         global $page_manifest__uptoken;
             
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "select","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
         
         	return get_page_manifest_("*", "WHERE primkey='$page_manifest__uptoken'", "r");
         
            echo $gwauthenticate_page_manifest__;

         }else{

         	echo $gwauthenticate_page_manifest__;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");
         
         }
        } 
        
       function mginitialize_page_manifest_($endpoint="auth",$function_json="")
        {
        
         global $page_manifest__uptoken;
             
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "select","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("page_manifest_", "*", "WHERE primkey='$page_manifest__uptoken'", "l",$function_json, $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_page_manifest__;

         }else{

         	echo $gwauthenticate_page_manifest__;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");
         
         }
        }         
    //End Add page_manifest_ Data ===============
                
    //Start Update page_manifest_ Data ===============
    
 	function update_page_manifest_($page_manifest__arr_, $where_str)
    {
         $gw_page_manifest__cols=array();
     
     foreach($page_manifest__arr_ as $page_manifest__arr_gw => $page_manifest__arr_gw_val)
     {
     
     	$gw_page_manifest__cols[]=$page_manifest__arr_gw;
        
     }
     
     $gw_page_manifest__cols_str=implode(",", $gw_page_manifest__cols);
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "update",$gw_page_manifest__cols_str);
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("page_manifest_", $page_manifest__arr_, $where_str);

       // echo $gwauthenticate_page_manifest__;
        
        exit;

     }else{

        echo $gwauthenticate_page_manifest__;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


      }
    
    }
 	
    
    //End Update page_manifest_ Data ===============


    //Start get  page_manifest_ Data ===============
    
    function get_page_manifest_($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "select","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {
    	return mosyflex_sel("page_manifest_", $colstr, $where_str, $type);

        //echo $gwauthenticate_page_manifest__;

	  }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }    
    }
    //End get  page_manifest_ Data ===============
    
  //Start get  page_manifest_ Data ===============
    
    function mgget_page_manifest_($colstr="*", $where_str="", $type="l", $endpoint="auth",$function_json="")
    {
          
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "select","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {
     
        return mosyget_("page_manifest_", $colstr, $where_str, $type,$function_json, $endpoint);
        
        
    	//return mosyflex_sel("page_manifest_", $colstr, $where_str, $type);

        //echo $gwauthenticate_page_manifest__;

	  }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }    
    }
    //End get  page_manifest_ Data ===============
            

    //======== qpage_manifest__data qsingle query function
    
    function qpage_manifest__data($qmanikey_key)
    {
          
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "qdata","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
    	return get_page_manifest_("*", "WHERE manikey='$qmanikey_key'", "r");

		//echo $gwauthenticate_page_manifest__;

      }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }  
    }
    
    function mgqpage_manifest__data($qmanikey_key, $endpoint="auth",$function_json="")
    {
          
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "qdata","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("page_manifest_", "*", "WHERE manikey='$qmanikey_key'", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_page_manifest__;

      }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }  
    }
   
    //======== qpage_manifest__data qsingle query function
    
    
     //======== page_manifest_ data to array
    
    function page_manifest__data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "data_array","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {  
     	$append_page_manifest__arr=array();
    
    	$array_page_manifest__q=get_page_manifest_($colstr, $where_str, "l");
        while($array_page_manifest__res=mysqli_fetch_array($array_page_manifest__q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_page_manifest__arr[]=$array_page_manifest__res[$tbl_col];
            }
          }else{
          	          
               $append_page_manifest__arr[]=$array_page_manifest__res;

          }
        }
        
        return $append_page_manifest__arr;

		//echo $gwauthenticate_page_manifest__;

      }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }  
    }
   
    //======== qpage_manifest__data qsingle query function   
        
    //======== qpage_manifest__ddata qsingle query function    
    function qpage_manifest__ddata($manikey_col, $qmanikey_key)
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "qddata","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
    	return get_page_manifest_("*", "WHERE $manikey_col='$qmanikey_key'", "r");



		//echo $gwauthenticate_page_manifest__;

     }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }   
    }
    
    function mgqpage_manifest__ddata($manikey_col, $qmanikey_key, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "qddata","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("page_manifest_", "*", "WHERE $manikey_col='$qmanikey_key'", "l",$function_json, $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_page_manifest__;

     }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }   
    }    
    //======== qpage_manifest__ddata qsingle query function
    
        //======== qpage_manifest__gdata qsingle query function    
    function qpage_manifest__gdata($page_manifest__where="")
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "gddata","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
     	$where_str="";
        if($page_manifest__where!=="")
        {
        $where_str=" ".$page_manifest__where;
        }
    	return get_page_manifest_("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_page_manifest__;

     }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }   
    }
    
    function mgqpage_manifest__gdata($page_manifest__where="", $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "gddata","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
     	$where_str="";
        if($page_manifest__where!=="")
        {
        $where_str=" ".$page_manifest__where;
        }
        
        $return_data_set = mosyget_("page_manifest_", "*", " ".$where_str." ", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_page_manifest__;

     }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }   
    }
    //======== qpage_manifest__gdata qsingle query function
    

    //======== count page_manifest_ data function
    
    function count_page_manifest_($page_manifest__wherestr)
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "count_data","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
      $clean_page_manifest__where_str="";
  
      if($page_manifest__wherestr!='')
      {
        $clean_page_manifest__where_str="Where ".$page_manifest__wherestr;
      }

      return get_page_manifest_("count(*) as return_result", " ".$clean_page_manifest__where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_page_manifest__;

      }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }    
    }
    
    function mgcount_page_manifest_($page_manifest__wherestr, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "count_data","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
      $clean_page_manifest__where_str="";
  
      if($page_manifest__wherestr!='')
      {
        $clean_page_manifest__where_str="Where ".$page_manifest__wherestr;
      }

         $return_data_set= mosyget_("page_manifest_", "count(*) as return_result", " ".$clean_page_manifest__where_str."", "l", $function_json, $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_page_manifest__;

      }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");


     }    
    }    
    //======== count page_manifest_ data function
    
    

    //======== sum  page_manifest_ data function
    
    function sum_page_manifest_($page_manifest__sumcol, $page_manifest__wherestr)
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "sum_data","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
      $clean_page_manifest__where_str="";
  
      if($page_manifest__wherestr!='')
      {
        $clean_page_manifest__where_str="Where ".$page_manifest__wherestr;
      }

      $_sum_return = get_page_manifest_("sum($page_manifest__sumcol) as return_result", " ".$clean_page_manifest__where_str."", "r")["return_result"];
      
      if($_sum_return=="")
      {
      
       $_sum_return="0";
            
      }
      
      return $_sum_return;
      
      //echo $gwauthenticate_page_manifest__;


      }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");
        


     }    
    }
    
    function mgsum_page_manifest_($page_manifest__sumcol, $page_manifest__wherestr, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "sum_data","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
      $clean_page_manifest__where_str="";
  
      if($page_manifest__wherestr!='')
      {
        $clean_page_manifest__where_str="Where ".$page_manifest__wherestr;
      }
      
        $return_data_set = mosyget_("page_manifest_", "sum($page_manifest__sumcol) as return_result", " ".$clean_page_manifest__where_str."", "l",$function_json, $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

        
		return $result_node;

      //echo $gwauthenticate_page_manifest__;


      }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");
        


     }    
    }    
    
    //======== sum  page_manifest_ data function   
    
    
    //Start drop  page_manifest_ Data ===============
    
    function drop_page_manifest_($where_str)
    {
     
     $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "drop_data","");
     
     $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
     
     if($gwauthenticate_page_manifest__json["response"]=="ok")
     {    
    	return magic_sql_delete("page_manifest_", $where_str);

		//echo $gwauthenticate_page_manifest__;

      }else{
     
     	echo $gwauthenticate_page_manifest__;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");
		

     }
    }
    //End drop  page_manifest_ Data ===============    
    
    
?>