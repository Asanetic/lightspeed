<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $auth_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$auth_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $auth_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$auth_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
 ///add mosy profile query 
  
  
  //add mosy profile query line
  $client_list_data_functions_arr=["_affiliates_name_reffered_by"=>'checkblank(getarr_val_(qaffiliates_ddata("record_id", $data_res["reffered_by"]), "name"), $data_res["reffered_by"])',
"_services_service_name_active_service"=>'checkblank(getarr_val_(qservices_ddata("record_id", $data_res["active_service"]), "service_name"), $data_res["active_service"])',
];
  $client_list_data_functions=json_encode($client_list_data_functions_arr, true);
  
  
  $client_list_profile_node_query=mosyget_("client_list", "*", " WHERE primkey='$client_list_uptoken' ", "l", $client_list_data_functions, "auth");
  $client_list_profile_result_node=[];   
  
  if(isset($client_list_profile_node_query["data"][0]))
  {  
    $client_list_profile_result_node=$client_list_profile_node_query["data"][0];
  }
 $client_list_node=$client_list_profile_result_node; 
?>
