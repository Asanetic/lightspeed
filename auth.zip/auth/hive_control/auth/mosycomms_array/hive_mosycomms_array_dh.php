<?php //===============Start Mosy queries-============ 

        function mpupdate_mosycomms_array($custom_input_array="", $appname="auth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "insert","");

           $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);

            //echo $gwauthenticate_mosycomms_array_;

           if($gwauthenticate_mosycomms_array_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $mosycomms_array_post_arr=$new_input_array;

                  

                  $mosycomms_array_return_key=mosypost_arr_($mosycomms_array_post_arr, ["mosycomms_array_update_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$mosycomms_array_return_key;

                  return $mosycomms_array_return_key;

           }
         
         }
         
        
        function mpadd_mosycomms_array($custom_input_array="", $appname="auth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "insert","");

           $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);

            //echo $gwauthenticate_mosycomms_array_;

           if($gwauthenticate_mosycomms_array_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $mosycomms_array_post_arr=$new_input_array;

                  

                  $mosycomms_array_return_key=mosypost_arr_($mosycomms_array_post_arr, ["mosycomms_array_insert_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$mosycomms_array_return_key;

                  return $mosycomms_array_return_key;

           }
         
         }
         
         
         
 	//Start Add mosycomms_array Data ===============
 	function add_mosycomms_array($mosycomms_array_arr_)
    {
     $gw_mosycomms_array_cols=array();
     
     foreach($mosycomms_array_arr_ as $mosycomms_array_arr_gw => $mosycomms_array_arr_gw_val)
     {
     
     	$gw_mosycomms_array_cols[]=$mosycomms_array_arr_gw;
        
     }
     
     $gw_mosycomms_array_cols_str=implode(",", $gw_mosycomms_array_cols);
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "insert",$gw_mosycomms_array_cols_str);
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("mosycomms_array", $mosycomms_array_arr_);
     
     	//echo $gwauthenticate_mosycomms_array_;

     }else{
     
     	echo $gwauthenticate_mosycomms_array_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");

     }
     
    }
    
       function initialize_mosycomms_array()
        {
        
         global $mosycomms_array_uptoken;
             
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "select","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
         
         	return get_mosycomms_array("*", "WHERE primkey='$mosycomms_array_uptoken'", "r");
         
            echo $gwauthenticate_mosycomms_array_;

         }else{

         	echo $gwauthenticate_mosycomms_array_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");
         
         }
        } 
        
       function mginitialize_mosycomms_array($endpoint="auth",$function_json="")
        {
        
         global $mosycomms_array_uptoken;
             
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "select","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("mosycomms_array", "*", "WHERE primkey='$mosycomms_array_uptoken'", "l",$function_json, $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_mosycomms_array_;

         }else{

         	echo $gwauthenticate_mosycomms_array_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");
         
         }
        }         
    //End Add mosycomms_array Data ===============
                
    //Start Update mosycomms_array Data ===============
    
 	function update_mosycomms_array($mosycomms_array_arr_, $where_str)
    {
         $gw_mosycomms_array_cols=array();
     
     foreach($mosycomms_array_arr_ as $mosycomms_array_arr_gw => $mosycomms_array_arr_gw_val)
     {
     
     	$gw_mosycomms_array_cols[]=$mosycomms_array_arr_gw;
        
     }
     
     $gw_mosycomms_array_cols_str=implode(",", $gw_mosycomms_array_cols);
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "update",$gw_mosycomms_array_cols_str);
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("mosycomms_array", $mosycomms_array_arr_, $where_str);

       // echo $gwauthenticate_mosycomms_array_;
        
        exit;

     }else{

        echo $gwauthenticate_mosycomms_array_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


      }
    
    }
 	
    
    //End Update mosycomms_array Data ===============


    //Start get  mosycomms_array Data ===============
    
    function get_mosycomms_array($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "select","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {
    	return mosyflex_sel("mosycomms_array", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosycomms_array_;

	  }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }    
    }
    //End get  mosycomms_array Data ===============
    
  //Start get  mosycomms_array Data ===============
    
    function mgget_mosycomms_array($colstr="*", $where_str="", $type="l", $endpoint="auth",$function_json="")
    {
          
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "select","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {
     
        return mosyget_("mosycomms_array", $colstr, $where_str, $type,$function_json, $endpoint);
        
        
    	//return mosyflex_sel("mosycomms_array", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosycomms_array_;

	  }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }    
    }
    //End get  mosycomms_array Data ===============
            

    //======== qmosycomms_array_data qsingle query function
    
    function qmosycomms_array_data($qmessageid_key)
    {
          
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "qdata","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
    	return get_mosycomms_array("*", "WHERE messageid='$qmessageid_key'", "r");

		//echo $gwauthenticate_mosycomms_array_;

      }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }  
    }
    
    function mgqmosycomms_array_data($qmessageid_key, $endpoint="auth",$function_json="")
    {
          
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "qdata","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("mosycomms_array", "*", "WHERE messageid='$qmessageid_key'", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosycomms_array_;

      }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }  
    }
   
    //======== qmosycomms_array_data qsingle query function
    
    
     //======== mosycomms_array data to array
    
    function mosycomms_array_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "data_array","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {  
     	$append_mosycomms_array_arr=array();
    
    	$array_mosycomms_array_q=get_mosycomms_array($colstr, $where_str, "l");
        while($array_mosycomms_array_res=mysqli_fetch_array($array_mosycomms_array_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_mosycomms_array_arr[]=$array_mosycomms_array_res[$tbl_col];
            }
          }else{
          	          
               $append_mosycomms_array_arr[]=$array_mosycomms_array_res;

          }
        }
        
        return $append_mosycomms_array_arr;

		//echo $gwauthenticate_mosycomms_array_;

      }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }  
    }
   
    //======== qmosycomms_array_data qsingle query function   
        
    //======== qmosycomms_array_ddata qsingle query function    
    function qmosycomms_array_ddata($messageid_col, $qmessageid_key)
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "qddata","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
    	return get_mosycomms_array("*", "WHERE $messageid_col='$qmessageid_key'", "r");



		//echo $gwauthenticate_mosycomms_array_;

     }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }   
    }
    
    function mgqmosycomms_array_ddata($messageid_col, $qmessageid_key, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "qddata","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("mosycomms_array", "*", "WHERE $messageid_col='$qmessageid_key'", "l",$function_json, $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosycomms_array_;

     }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }   
    }    
    //======== qmosycomms_array_ddata qsingle query function
    
        //======== qmosycomms_array_gdata qsingle query function    
    function qmosycomms_array_gdata($mosycomms_array_where="")
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "gddata","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
     	$where_str="";
        if($mosycomms_array_where!=="")
        {
        $where_str=" ".$mosycomms_array_where;
        }
    	return get_mosycomms_array("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_mosycomms_array_;

     }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }   
    }
    
    function mgqmosycomms_array_gdata($mosycomms_array_where="", $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "gddata","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
     	$where_str="";
        if($mosycomms_array_where!=="")
        {
        $where_str=" ".$mosycomms_array_where;
        }
        
        $return_data_set = mosyget_("mosycomms_array", "*", " ".$where_str." ", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosycomms_array_;

     }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }   
    }
    //======== qmosycomms_array_gdata qsingle query function
    

    //======== count mosycomms_array data function
    
    function count_mosycomms_array($mosycomms_array_wherestr)
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "count_data","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
      $clean_mosycomms_array_where_str="";
  
      if($mosycomms_array_wherestr!='')
      {
        $clean_mosycomms_array_where_str="Where ".$mosycomms_array_wherestr;
      }

      return get_mosycomms_array("count(*) as return_result", " ".$clean_mosycomms_array_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosycomms_array_;

      }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }    
    }
    
    function mgcount_mosycomms_array($mosycomms_array_wherestr, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "count_data","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
      $clean_mosycomms_array_where_str="";
  
      if($mosycomms_array_wherestr!='')
      {
        $clean_mosycomms_array_where_str="Where ".$mosycomms_array_wherestr;
      }

         $return_data_set= mosyget_("mosycomms_array", "count(*) as return_result", " ".$clean_mosycomms_array_where_str."", "l", $function_json, $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_mosycomms_array_;

      }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");


     }    
    }    
    //======== count mosycomms_array data function
    
    

    //======== sum  mosycomms_array data function
    
    function sum_mosycomms_array($mosycomms_array_sumcol, $mosycomms_array_wherestr)
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "sum_data","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
      $clean_mosycomms_array_where_str="";
  
      if($mosycomms_array_wherestr!='')
      {
        $clean_mosycomms_array_where_str="Where ".$mosycomms_array_wherestr;
      }

      $_sum_return = get_mosycomms_array("sum($mosycomms_array_sumcol) as return_result", " ".$clean_mosycomms_array_where_str."", "r")["return_result"];
      
      if($_sum_return=="")
      {
      
       $_sum_return="0";
            
      }
      
      return $_sum_return;
      
      //echo $gwauthenticate_mosycomms_array_;


      }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");
        


     }    
    }
    
    function mgsum_mosycomms_array($mosycomms_array_sumcol, $mosycomms_array_wherestr, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "sum_data","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
      $clean_mosycomms_array_where_str="";
  
      if($mosycomms_array_wherestr!='')
      {
        $clean_mosycomms_array_where_str="Where ".$mosycomms_array_wherestr;
      }
      
        $return_data_set = mosyget_("mosycomms_array", "sum($mosycomms_array_sumcol) as return_result", " ".$clean_mosycomms_array_where_str."", "l",$function_json, $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

        
		return $result_node;

      //echo $gwauthenticate_mosycomms_array_;


      }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");
        


     }    
    }    
    
    //======== sum  mosycomms_array data function   
    
    
    //Start drop  mosycomms_array Data ===============
    
    function drop_mosycomms_array($where_str)
    {
     
     $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "drop_data","");
     
     $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
     
     if($gwauthenticate_mosycomms_array_json["response"]=="ok")
     {    
    	return magic_sql_delete("mosycomms_array", $where_str);

		//echo $gwauthenticate_mosycomms_array_;

      }else{
     
     	echo $gwauthenticate_mosycomms_array_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");
		

     }
    }
    //End drop  mosycomms_array Data ===============    
    
    
?>