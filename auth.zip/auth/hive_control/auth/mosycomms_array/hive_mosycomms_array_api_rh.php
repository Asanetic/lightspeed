<?php 

        if(isset($_POST["mpmosycomms_array_insert_btn"]))
        {
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "insert","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {                   
                  $mosycomms_array_return_key=mpadd_mosycomms_array();  
               // print_r($_POST);                
                //echo "ret keyyyyyyy ".$mosycomms_array_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosycomms_array_return_key; 

                      } 

                    }else{ 

                                    
                $mosycomms_array_custom_redir1=add_url_param ("mosycomms_array_uptoken", base64_encode($mosycomms_array_return_key), "");
                $mosycomms_array_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosycomms_array_custom_redir1);
                $mosycomms_array_custom_redir3=add_url_param ("mosycomms_array_table_alert", "mosycomms_array_added",$mosycomms_array_custom_redir2);
                
                ///echo magic_message($mosycomms_array_custom_redir1." -- ".$mosycomms_array_custom_redir2."--".$mosycomms_array_custom_redir3);
                
                $mosycomms_array_custom_redir=$mosycomms_array_custom_redir3;
                
               if (is_numeric($mosycomms_array_return_key)) {
                  header('location:'.$mosycomms_array_custom_redir.'');
                }else{
                  echo magic_message($mosycomms_array_return_key);
                }
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_mosycomms_array_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");

           }

         }
         
         
      
        if(isset($_POST["mpmosycomms_array_update_btn"]))
        {
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "insert","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
                    
                  $mosycomms_array_return_key=mpupdate_mosycomms_array();  
                    
               /// print_r($_POST);
                
               // echo "ret keyyyyyyy ".$mosycomms_array_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosycomms_array_return_key; 

                      } 

                    }else{ 

                                    
                $mosycomms_array_custom_redir1=add_url_param ("mosycomms_array_uptoken", base64_encode($mosycomms_array_return_key), "");
                $mosycomms_array_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosycomms_array_custom_redir1);
                $mosycomms_array_custom_redir3=add_url_param ("mosycomms_array_table_alert", "mosycomms_array_added",$mosycomms_array_custom_redir2);
                
                ///echo magic_message($mosycomms_array_custom_redir1." -- ".$mosycomms_array_custom_redir2."--".$mosycomms_array_custom_redir3);
                
                $mosycomms_array_custom_redir=$mosycomms_array_custom_redir3;
                
               if (is_numeric($mosycomms_array_return_key)) {

				header('location:'.$mosycomms_array_custom_redir.'');
                  
                }else{
                  echo magic_message($mosycomms_array_return_key);
                }                
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_mosycomms_array_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");

           }

         }
      //<--ncgh-->

?>