<?php //===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section mosycomms_array
  //************************************************* START  mosycomms_array OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize mosycomms_array edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['mosycomms_array_table_alert']))
              	{	
                  if(isset($mosycomms_array_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$mosycomms_array_uptoken="";

		if(isset($_GET["mosycomms_array_uptoken"]))
		{
		$mosycomms_array_uptoken=base64_decode($_GET["mosycomms_array_uptoken"]);
		}
        
        if(isset($_POST["mosycomms_array_uptoken"]))
		{
		$mosycomms_array_uptoken=base64_decode($_POST["mosycomms_array_uptoken"]);
		}
        //
        
          $mosycomms_array_alias_name="MOSYCOMMS ARRAY";

          if(isset($mosycomms_array_alias))
          {
             $mosycomms_array_alias_name=$mosycomms_array_alias;

          }
          
        //get single data record query with $mosycomms_array_uptoken
        
        ///$mosycomms_array_node=get_mosycomms_array("*", "WHERE primkey='$mosycomms_array_uptoken'", "r");
        
	
//************* START INSERT  mosycomms_array QUERY 
if(isset($_POST["mosycomms_array_insert_btn"])){
//------- begin mosycomms_array_arr_ins --> 
$mosycomms_array_arr_ins_=array(

"primkey"=>"NULL",
"messageid"=>magic_random_str(7),
"receiver_contacts"=>"?",
"reciver_names"=>"?",
"message_type"=>"?",
"site_id"=>"?",
"group_name"=>"?",
"message_date"=>"?",
"sent_state"=>"?",
"msg_read_state"=>"?",
"subject"=>"?",
"message_label"=>"?",
"message"=>"?",
"delvery_receipt"=>"?",
"mosycomms_dictionary"=>"?",
"sms_cost"=>"?",
"page_count"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End mosycomms_array_arr_ins -->


          
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "insert","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {

              $mosycomms_array_validated_ins_str=$mosycomms_array_arr_ins_;

              if(isset($mosycomms_array_ins_inputs))
              {
                $mosycomms_array_validated_ins_str=$mosycomms_array_ins_inputs;	
              }

              if(empty($mosycomms_array_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$mosycomms_array_alias_name." request cannot be empty. Record not added");
              }else{


                $mosycomms_array_return_key=add_mosycomms_array($mosycomms_array_validated_ins_str);
                
                mosy_sql_rollback("mosycomms_array", "primkey='$mosycomms_array_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$mosycomms_array_mosy_rest_req_vars=http_build_query($_POST);
                echo $mosycomms_array_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $mosycomms_array_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosycomms_array_return_key; 

                      } 

                    }else{ 

                                    
                $mosycomms_array_custom_redir1=add_url_param ("mosycomms_array_uptoken", base64_encode($mosycomms_array_return_key), "");
                $mosycomms_array_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosycomms_array_custom_redir1);
                $mosycomms_array_custom_redir3=add_url_param ("mosycomms_array_table_alert", "mosycomms_array_added",$mosycomms_array_custom_redir2);
                
                ///echo magic_message($mosycomms_array_custom_redir1." -- ".$mosycomms_array_custom_redir2."--".$mosycomms_array_custom_redir3);
                
                $mosycomms_array_custom_redir=$mosycomms_array_custom_redir3;
                
               header('location:'.$mosycomms_array_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_mosycomms_array_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");
         
         }
      
}
//************* END  mosycomms_array INSERT QUERY 	
	

//************* START mosycomms_array  UPDATE QUERY 
if(isset($_POST["mosycomms_array_update_btn"])){
//------- begin mosycomms_array_arr_updt --> 
$mosycomms_array_arr_updt_=array(



"receiver_contacts"=>"?",
"reciver_names"=>"?",
"message_type"=>"?",
"site_id"=>"?",
"group_name"=>"?",
"message_date"=>"?",
"sent_state"=>"?",
"msg_read_state"=>"?",
"subject"=>"?",
"message_label"=>"?",
"message"=>"?",
"delvery_receipt"=>"?",
"mosycomms_dictionary"=>"?",
"sms_cost"=>"?",
"page_count"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End mosycomms_array_arr_updt -->



                     
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "update","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
         
            $mosycomms_array_validated_updt_str=$mosycomms_array_arr_updt_;

            if(isset($mosycomms_array_updt_inputs))
            {
              $mosycomms_array_validated_updt_str=$mosycomms_array_updt_inputs;	
            }

            if(empty($mosycomms_array_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$mosycomms_array_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$mosycomms_array_key_salt=initialize_mosycomms_array()["messageid"];
            
              update_mosycomms_array($mosycomms_array_validated_updt_str, "primkey='$mosycomms_array_uptoken' and messageid='$mosycomms_array_key_salt'");
				

			 mosy_sql_rollback("mosycomms_array", "primkey='$mosycomms_array_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $mosycomms_array_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $mosycomms_array_mosy_rest_req_vars, "POST");
                
                }
             
              



                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $mosycomms_array_uptoken; 

                    } 

                  }else{ 

                $mosycomms_array_custom_redir1=add_url_param ("mosycomms_array_uptoken", base64_encode($mosycomms_array_uptoken), "");
                $mosycomms_array_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosycomms_array_custom_redir1);
                $mosycomms_array_custom_redir3=add_url_param ("mosycomms_array_table_alert", "mosycomms_array_updated",$mosycomms_array_custom_redir2);
                
                ///echo magic_message($mosycomms_array_custom_redir1." -- ".$mosycomms_array_custom_redir2."--".$mosycomms_array_custom_redir3);
                
                $mosycomms_array_custom_redir=$mosycomms_array_custom_redir3;
                
               header('location:'.$mosycomms_array_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_mosycomms_array_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_array_)."");
         
         }

      

      
}
//************* END mosycomms_array  UPDATE QUERY 

    
    
      //== Start mosycomms_array delete record

      if(isset($_GET["deletemosycomms_array"]))
      {
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "super_delete_request","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }


      $conf_del_mosycomms_array_btn=magic_button_link("./".$current_file_url."?mosycomms_array_uptoken=".$_GET["mosycomms_array_uptoken"]."&conf_deletemosycomms_array&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_mosycomms_array_btn=magic_button_link("./".$current_file_url."?mosycomms_array_uptoken=".$_GET["mosycomms_array_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_mosycomms_array_btn." ".$cancel_del_mosycomms_array_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_mosycomms_array_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemosycomms_array"]))
      {
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "super_delete_confirm","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      //$mosycomms_array_del_key_salt=initialize_mosycomms_array()["messageid"];
      //mosy_sql_rollback("mosycomms_array", "primkey='$mosycomms_array_uptoken'", "DELETE");
      //drop_mosycomms_array("primkey='$mosycomms_array_uptoken' and messageid='$mosycomms_array_del_key_salt'");
      $mosycomms_arraycurlopt_url=$hive_routes["auth"];;
      $mosycomms_arraycurlopt_httpheader="";
      $mosycomms_arraycurlopt_userpwd="";
      $mosycomms_arraycurlopt_post_fields="?conf_deletemosycomms_array&mosycomms_array_uptoken=".base64_encode($mosycomms_array_uptoken);
      $mosycomms_arraycurlopt_customrequest="GET";

      magic_post_curl($mosycomms_arraycurlopt_url.$mosycomms_arraycurlopt_post_fields, $mosycomms_arraycurlopt_httpheader, $mosycomms_arraycurlopt_userpwd, "", $mosycomms_arraycurlopt_customrequest);

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_mosycomms_array_);

      }
      }

      //== End mosycomms_array delete record  
    
       ///SELECT STRING FOR mosycomms_array============================
              
       if(isset($_POST["qmosycomms_array_btn"])){
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "qmosycomms_array_btn","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
            $current_mosycomms_array_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_mosycomms_array_current_url=$current_mosycomms_array_url_params.'?qmosycomms_array=';


            if (strpos($current_mosycomms_array_url_params, '?') !== false) {

                $clean_mosycomms_array_current_url=$current_mosycomms_array_url_params.'&qmosycomms_array=';

            }
            if (strpos($current_mosycomms_array_url_params, '?qmosycomms_array')) {

                $remove_mosycomms_array_old_token = substr($current_mosycomms_array_url_params, 0, strpos($current_mosycomms_array_url_params, "?qmosycomms_array"));

                $clean_mosycomms_array_current_url=$remove_mosycomms_array_old_token.'?qmosycomms_array=';

            }
            if(strpos($current_mosycomms_array_url_params, '&qmosycomms_array')) {

                $remove_mosycomms_array_old_token = substr($current_mosycomms_array_url_params, 0, strpos($current_mosycomms_array_url_params, "&qmosycomms_array"));

                $clean_mosycomms_array_current_url=$remove_mosycomms_array_old_token.'&qmosycomms_array=';

            }
        $qmosycomms_array_str=base64_encode($_POST["txt_mosycomms_array"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_mosycomms_array_current_url.($qmosycomms_array_str);
            } 

          }else{ 


             header('location:'.$clean_mosycomms_array_current_url.($qmosycomms_array_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_mosycomms_array_);

        }
        }
        $qmosycomms_array="";
               //handle data sensisitve filters
        $mosycomms_array_mdsf_="";
        $mosycomms_array_mdsf_qstr_without_where_="";
        $mosycomms_array_mdsf_qstr_with_where_="";

        if(isset($mosy_dsft_))
        {
          $mosycomms_array_mdsf_=$mosy_dsft_["global_filter"];
          
          if(isset($mosy_dsft_["mosycomms_array"]))
          {
            $mosycomms_array_mdsf_=$mosy_dsft_["mosycomms_array"];
          }
          
          if($mosycomms_array_mdsf_!="")
          {
            $mosycomms_array_mdsf_qstr_without_where_=" AND $mosycomms_array_mdsf_";
            $mosycomms_array_mdsf_qstr_with_where_=" WHERE $mosycomms_array_mdsf_";
            
          }
          
        }

        ///echo " dsgft__ $mosycomms_array_mdsf_ with  $mosycomms_array_mdsf_qstr_with_where_ wihout $mosycomms_array_mdsf_qstr_without_where_ ";
        
		if(isset($_GET["mosycomms_array_mosyfilter"]) && isset($_GET["qmosycomms_array"])){
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "mosycomms_array_mosyfilter_n_query","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
         $qmosycomms_array=mmres(base64_decode($_GET["qmosycomms_array"]));
         
         $gft_mosycomms_array_where_query="(`messageid` LIKE '%".$qmosycomms_array."%' OR  `receiver_contacts` LIKE '%".$qmosycomms_array."%' OR  `reciver_names` LIKE '%".$qmosycomms_array."%' OR  `message_type` LIKE '%".$qmosycomms_array."%' OR  `site_id` LIKE '%".$qmosycomms_array."%' OR  `group_name` LIKE '%".$qmosycomms_array."%' OR  `message_date` LIKE '%".$qmosycomms_array."%' OR  `sent_state` LIKE '%".$qmosycomms_array."%' OR  `msg_read_state` LIKE '%".$qmosycomms_array."%' OR  `subject` LIKE '%".$qmosycomms_array."%' OR  `message_label` LIKE '%".$qmosycomms_array."%' OR  `message` LIKE '%".$qmosycomms_array."%' OR  `delvery_receipt` LIKE '%".$qmosycomms_array."%' OR  `mosycomms_dictionary` LIKE '%".$qmosycomms_array."%' OR  `sms_cost` LIKE '%".$qmosycomms_array."%' OR  `page_count` LIKE '%".$qmosycomms_array."%' OR  `hive_site_id` LIKE '%".$qmosycomms_array."%' OR  `hive_site_name` LIKE '%".$qmosycomms_array."%') ".$mosycomms_array_mdsf_qstr_without_where_."";
         
         if($_GET["mosycomms_array_mosyfilter"]!=""){
         
         $mosyfilter_mosycomms_array_queries_str=(base64_decode($_GET["mosycomms_array_mosyfilter"]));
        
         $gft_mosycomms_array_where_query="(`messageid` LIKE '%".$qmosycomms_array."%' OR  `receiver_contacts` LIKE '%".$qmosycomms_array."%' OR  `reciver_names` LIKE '%".$qmosycomms_array."%' OR  `message_type` LIKE '%".$qmosycomms_array."%' OR  `site_id` LIKE '%".$qmosycomms_array."%' OR  `group_name` LIKE '%".$qmosycomms_array."%' OR  `message_date` LIKE '%".$qmosycomms_array."%' OR  `sent_state` LIKE '%".$qmosycomms_array."%' OR  `msg_read_state` LIKE '%".$qmosycomms_array."%' OR  `subject` LIKE '%".$qmosycomms_array."%' OR  `message_label` LIKE '%".$qmosycomms_array."%' OR  `message` LIKE '%".$qmosycomms_array."%' OR  `delvery_receipt` LIKE '%".$qmosycomms_array."%' OR  `mosycomms_dictionary` LIKE '%".$qmosycomms_array."%' OR  `sms_cost` LIKE '%".$qmosycomms_array."%' OR  `page_count` LIKE '%".$qmosycomms_array."%' OR  `hive_site_id` LIKE '%".$qmosycomms_array."%' OR  `hive_site_name` LIKE '%".$qmosycomms_array."%') AND ".$mosyfilter_mosycomms_array_queries_str." ".$mosycomms_array_mdsf_qstr_without_where_."";
         
         }
         
		 $gft_mosycomms_array="WHERE ".$gft_mosycomms_array_where_query;
         
         $gft_mosycomms_array_and=$gft_mosycomms_array_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_mosycomms_array_);
        }
        }elseif(isset($_GET["qmosycomms_array"])){
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "get_qmosycomms_array","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
		 $qmosycomms_array=mmres(base64_decode($_GET["qmosycomms_array"]));
        
         $gft_mosycomms_array_where_query="(`messageid` LIKE '%".$qmosycomms_array."%' OR  `receiver_contacts` LIKE '%".$qmosycomms_array."%' OR  `reciver_names` LIKE '%".$qmosycomms_array."%' OR  `message_type` LIKE '%".$qmosycomms_array."%' OR  `site_id` LIKE '%".$qmosycomms_array."%' OR  `group_name` LIKE '%".$qmosycomms_array."%' OR  `message_date` LIKE '%".$qmosycomms_array."%' OR  `sent_state` LIKE '%".$qmosycomms_array."%' OR  `msg_read_state` LIKE '%".$qmosycomms_array."%' OR  `subject` LIKE '%".$qmosycomms_array."%' OR  `message_label` LIKE '%".$qmosycomms_array."%' OR  `message` LIKE '%".$qmosycomms_array."%' OR  `delvery_receipt` LIKE '%".$qmosycomms_array."%' OR  `mosycomms_dictionary` LIKE '%".$qmosycomms_array."%' OR  `sms_cost` LIKE '%".$qmosycomms_array."%' OR  `page_count` LIKE '%".$qmosycomms_array."%' OR  `hive_site_id` LIKE '%".$qmosycomms_array."%' OR  `hive_site_name` LIKE '%".$qmosycomms_array."%') ".$mosycomms_array_mdsf_qstr_without_where_."";
         
         $gft_mosycomms_array="WHERE ".$gft_mosycomms_array_where_query;
         
         $gft_mosycomms_array_and=$gft_mosycomms_array_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_mosycomms_array_);

        }
        }elseif(isset($_GET["mosycomms_array_mosyfilter"])){
         $gwauthenticate_mosycomms_array_=gw_oauth("table", magic_current_url(), "mosycomms_array", "mosycomms_array_mosyfilter","");

         $gwauthenticate_mosycomms_array_json=json_decode($gwauthenticate_mosycomms_array_, true);
         	
          //echo $gwauthenticate_mosycomms_array_;

         if($gwauthenticate_mosycomms_array_json["response"]=="ok")
         {
         $gft_mosycomms_array_where_query="";
         $gft_mosycomms_array="$mosycomms_array_mdsf_qstr_with_where_";

         if($_GET["mosycomms_array_mosyfilter"]!=""){
          $gft_mosycomms_array_where_query=(base64_decode($_GET["mosycomms_array_mosyfilter"]));
          $gft_mosycomms_array="WHERE ".$gft_mosycomms_array_where_query." ".$mosycomms_array_mdsf_qstr_without_where_." ";
         }
         
         
         $gft_mosycomms_array_and=$gft_mosycomms_array_where_query." ".$mosycomms_array_mdsf_qstr_without_where_." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_mosycomms_array_);

        }
        }else{
         $gft_mosycomms_array="$mosycomms_array_mdsf_qstr_with_where_";
         $gft_mosycomms_array_and="$mosycomms_array_mdsf_qstr_without_where_";
         $gft_mosycomms_array_where_query="";
        }
       
    //************************************************* END  mosycomms_array OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  ?>