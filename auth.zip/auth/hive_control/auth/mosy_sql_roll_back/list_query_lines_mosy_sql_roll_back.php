<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $auth_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$auth_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $auth_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$auth_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
  //add mosy list query
  $mosy_sql_roll_back_data_functions_arr=[];
  $mosy_sql_roll_back_data_functions=json_encode($mosy_sql_roll_back_data_functions_arr, true);
  
  $mosy_sql_roll_back_list_query=mosyget_("mosy_sql_roll_back", "*", " $gft_mosy_sql_roll_back order by primkey Desc", "l:qmosy_sql_roll_back_token:".$datalimit."", $mosy_sql_roll_back_data_functions, "auth");
?>