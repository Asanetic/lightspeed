<?php 

        if(isset($_POST["mpmosy_sql_roll_back_insert_btn"]))
        {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {                   
                  $mosy_sql_roll_back_return_key=mpadd_mosy_sql_roll_back();  
               // print_r($_POST);                
                //echo "ret keyyyyyyy ".$mosy_sql_roll_back_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               if (is_numeric($mosy_sql_roll_back_return_key)) {
                  header('location:'.$mosy_sql_roll_back_custom_redir.'');
                }else{
                  echo magic_message($mosy_sql_roll_back_return_key);
                }
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

           }

         }
         
         
      
        if(isset($_POST["mpmosy_sql_roll_back_update_btn"]))
        {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
                    
                  $mosy_sql_roll_back_return_key=mpupdate_mosy_sql_roll_back();  
                    
               /// print_r($_POST);
                
               // echo "ret keyyyyyyy ".$mosy_sql_roll_back_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               if (is_numeric($mosy_sql_roll_back_return_key)) {

				header('location:'.$mosy_sql_roll_back_custom_redir.'');
                  
                }else{
                  echo magic_message($mosy_sql_roll_back_return_key);
                }                
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

           }

         }
      //<--ncgh-->

?>