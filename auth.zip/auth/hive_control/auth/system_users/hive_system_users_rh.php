<?php //===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section system_users
  //************************************************* START  system_users OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize system_users edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['system_users_table_alert']))
              	{	
                  if(isset($system_users_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$system_users_uptoken="";

		if(isset($_GET["system_users_uptoken"]))
		{
		$system_users_uptoken=base64_decode($_GET["system_users_uptoken"]);
		}
        
        if(isset($_POST["system_users_uptoken"]))
		{
		$system_users_uptoken=base64_decode($_POST["system_users_uptoken"]);
		}
        //
        
          $system_users_alias_name="SYSTEM USERS";

          if(isset($system_users_alias))
          {
             $system_users_alias_name=$system_users_alias;

          }
          
        //get single data record query with $system_users_uptoken
        
        ///$system_users_node=get_system_users("*", "WHERE primkey='$system_users_uptoken'", "r");
        
	
//************* START INSERT  system_users QUERY 
if(isset($_POST["system_users_insert_btn"])){
//------- begin system_users_arr_ins --> 
$system_users_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?",
"auth_token"=>"?",
"token_status"=>"?",
"token_expiring_in"=>"?",
"project_id"=>"?",
"project_name"=>"?"

);
//===-- End system_users_arr_ins -->


          
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "insert","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {

              $system_users_validated_ins_str=$system_users_arr_ins_;

              if(isset($system_users_ins_inputs))
              {
                $system_users_validated_ins_str=$system_users_ins_inputs;	
              }

              if(empty($system_users_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$system_users_alias_name." request cannot be empty. Record not added");
              }else{


                $system_users_return_key=add_system_users($system_users_validated_ins_str);
                
                mosy_sql_rollback("system_users", "primkey='$system_users_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_system_users_user_pic']['tmp_name']))
                {
                
                 upload_system_users_user_pic('txt_system_users_user_pic', "primkey='$system_users_return_key'");
                 
				}
                
         

				if($run_mosy_api=="yes")
                {
				$system_users_mosy_rest_req_vars=http_build_query($_POST);
                echo $system_users_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $system_users_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $system_users_return_key; 

                      } 

                    }else{ 

                                    
                $system_users_custom_redir1=add_url_param ("system_users_uptoken", base64_encode($system_users_return_key), "");
                $system_users_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$system_users_custom_redir1);
                $system_users_custom_redir3=add_url_param ("system_users_table_alert", "system_users_added",$system_users_custom_redir2);
                
                ///echo magic_message($system_users_custom_redir1." -- ".$system_users_custom_redir2."--".$system_users_custom_redir3);
                
                $system_users_custom_redir=$system_users_custom_redir3;
                
               header('location:'.$system_users_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_system_users_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");
         
         }
      
}
//************* END  system_users INSERT QUERY 	
	

//************* START system_users  UPDATE QUERY 
if(isset($_POST["system_users_update_btn"])){
//------- begin system_users_arr_updt --> 
$system_users_arr_updt_=array(



"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?",
"auth_token"=>"?",
"token_status"=>"?",
"token_expiring_in"=>"?",
"project_id"=>"?",
"project_name"=>"?"

);
//===-- End system_users_arr_updt -->



                     
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "update","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
         
            $system_users_validated_updt_str=$system_users_arr_updt_;

            if(isset($system_users_updt_inputs))
            {
              $system_users_validated_updt_str=$system_users_updt_inputs;	
            }

            if(empty($system_users_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$system_users_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$system_users_key_salt=initialize_system_users()["user_id"];
            
              update_system_users($system_users_validated_updt_str, "primkey='$system_users_uptoken' and user_id='$system_users_key_salt'");
				
         
                if(!empty($_FILES['txt_system_users_user_pic']['tmp_name']))
                {
                
                 upload_system_users_user_pic('txt_system_users_user_pic', "primkey='$system_users_uptoken'");
                 
				}

			 mosy_sql_rollback("system_users", "primkey='$system_users_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $system_users_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $system_users_mosy_rest_req_vars, "POST");
                
                }
             
              



                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $system_users_uptoken; 

                    } 

                  }else{ 

                $system_users_custom_redir1=add_url_param ("system_users_uptoken", base64_encode($system_users_uptoken), "");
                $system_users_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$system_users_custom_redir1);
                $system_users_custom_redir3=add_url_param ("system_users_table_alert", "system_users_updated",$system_users_custom_redir2);
                
                ///echo magic_message($system_users_custom_redir1." -- ".$system_users_custom_redir2."--".$system_users_custom_redir3);
                
                $system_users_custom_redir=$system_users_custom_redir3;
                
               header('location:'.$system_users_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_system_users_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");
         
         }

      

      
}
//************* END system_users  UPDATE QUERY 

    

          //===-====Start upload system_users_user_pic 
          if(isset($_POST["btn_upload_system_users_user_pic"]))
          {
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "upload_system_users_user_pic","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_system_users_user_pic']['tmp_name'])){

				upload_system_users_user_pic('txt_system_users_user_pic', "primkey='$system_users_uptoken'");
                
                $system_users_custom_redir1=add_url_param ("system_users_uptoken", base64_encode($system_users_uptoken), "");
                $system_users_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$system_users_custom_redir1);
                $system_users_custom_redir3=add_url_param ("system_users_table_alert", "system_users_uploaded",$system_users_custom_redir2);
                
                ///echo magic_message($system_users_custom_redir1." -- ".$system_users_custom_redir2."--".$system_users_custom_redir3);
                
                $system_users_custom_redir=$system_users_custom_redir3;
                
               header('location:'.$system_users_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_system_users_);

          }
          }
          //===-====End upload system_users_user_pic  

			//drop system_users_user_pic image 
            
          /*if(isset($_GET["conf_deletesystem_users"]))
          {
          	$system_users_node=initialize_system_users();
          	if($system_users_node["user_pic"]!="")
            {
          	 unlink($system_users_node["user_pic"]);
            }
          }
          */ 
          
    
      //== Start system_users delete record

      if(isset($_GET["deletesystem_users"]))
      {
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "super_delete_request","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }


      $conf_del_system_users_btn=magic_button_link("./".$current_file_url."?system_users_uptoken=".$_GET["system_users_uptoken"]."&conf_deletesystem_users&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_system_users_btn=magic_button_link("./".$current_file_url."?system_users_uptoken=".$_GET["system_users_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_system_users_btn." ".$cancel_del_system_users_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_system_users_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesystem_users"]))
      {
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "super_delete_confirm","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      //$system_users_del_key_salt=initialize_system_users()["user_id"];
      //mosy_sql_rollback("system_users", "primkey='$system_users_uptoken'", "DELETE");
      //drop_system_users("primkey='$system_users_uptoken' and user_id='$system_users_del_key_salt'");
      $system_userscurlopt_url=$hive_routes["auth"];;
      $system_userscurlopt_httpheader="";
      $system_userscurlopt_userpwd="";
      $system_userscurlopt_post_fields="?conf_deletesystem_users&system_users_uptoken=".base64_encode($system_users_uptoken);
      $system_userscurlopt_customrequest="GET";

      magic_post_curl($system_userscurlopt_url.$system_userscurlopt_post_fields, $system_userscurlopt_httpheader, $system_userscurlopt_userpwd, "", $system_userscurlopt_customrequest);

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_system_users_);

      }
      }

      //== End system_users delete record  
    
       ///SELECT STRING FOR system_users============================
              
       if(isset($_POST["qsystem_users_btn"])){
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "qsystem_users_btn","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
            $current_system_users_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_system_users_current_url=$current_system_users_url_params.'?qsystem_users=';


            if (strpos($current_system_users_url_params, '?') !== false) {

                $clean_system_users_current_url=$current_system_users_url_params.'&qsystem_users=';

            }
            if (strpos($current_system_users_url_params, '?qsystem_users')) {

                $remove_system_users_old_token = substr($current_system_users_url_params, 0, strpos($current_system_users_url_params, "?qsystem_users"));

                $clean_system_users_current_url=$remove_system_users_old_token.'?qsystem_users=';

            }
            if(strpos($current_system_users_url_params, '&qsystem_users')) {

                $remove_system_users_old_token = substr($current_system_users_url_params, 0, strpos($current_system_users_url_params, "&qsystem_users"));

                $clean_system_users_current_url=$remove_system_users_old_token.'&qsystem_users=';

            }
        $qsystem_users_str=base64_encode($_POST["txt_system_users"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_system_users_current_url.($qsystem_users_str);
            } 

          }else{ 


             header('location:'.$clean_system_users_current_url.($qsystem_users_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_system_users_);

        }
        }
        $qsystem_users="";
               //handle data sensisitve filters
        $system_users_mdsf_="";
        $system_users_mdsf_qstr_without_where_="";
        $system_users_mdsf_qstr_with_where_="";

        if(isset($mosy_dsft_))
        {
          $system_users_mdsf_=$mosy_dsft_["global_filter"];
          
          if(isset($mosy_dsft_["system_users"]))
          {
            $system_users_mdsf_=$mosy_dsft_["system_users"];
          }
          
          if($system_users_mdsf_!="")
          {
            $system_users_mdsf_qstr_without_where_=" AND $system_users_mdsf_";
            $system_users_mdsf_qstr_with_where_=" WHERE $system_users_mdsf_";
            
          }
          
        }

        ///echo " dsgft__ $system_users_mdsf_ with  $system_users_mdsf_qstr_with_where_ wihout $system_users_mdsf_qstr_without_where_ ";
        
		if(isset($_GET["system_users_mosyfilter"]) && isset($_GET["qsystem_users"])){
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "system_users_mosyfilter_n_query","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
         $qsystem_users=mmres(base64_decode($_GET["qsystem_users"]));
         
         $gft_system_users_where_query="(`user_id` LIKE '%".$qsystem_users."%' OR  `name` LIKE '%".$qsystem_users."%' OR  `email` LIKE '%".$qsystem_users."%' OR  `tel` LIKE '%".$qsystem_users."%' OR  `login_password` LIKE '%".$qsystem_users."%' OR  `ref_id` LIKE '%".$qsystem_users."%' OR  `regdate` LIKE '%".$qsystem_users."%' OR  `user_no` LIKE '%".$qsystem_users."%' OR  `user_pic` LIKE '%".$qsystem_users."%' OR  `user_gender` LIKE '%".$qsystem_users."%' OR  `last_seen` LIKE '%".$qsystem_users."%' OR  `about` LIKE '%".$qsystem_users."%' OR  `hive_site_id` LIKE '%".$qsystem_users."%' OR  `hive_site_name` LIKE '%".$qsystem_users."%' OR  `auth_token` LIKE '%".$qsystem_users."%' OR  `token_status` LIKE '%".$qsystem_users."%' OR  `token_expiring_in` LIKE '%".$qsystem_users."%' OR  `project_id` LIKE '%".$qsystem_users."%' OR  `project_name` LIKE '%".$qsystem_users."%') ".$system_users_mdsf_qstr_without_where_."";
         
         if($_GET["system_users_mosyfilter"]!=""){
         
         $mosyfilter_system_users_queries_str=(base64_decode($_GET["system_users_mosyfilter"]));
        
         $gft_system_users_where_query="(`user_id` LIKE '%".$qsystem_users."%' OR  `name` LIKE '%".$qsystem_users."%' OR  `email` LIKE '%".$qsystem_users."%' OR  `tel` LIKE '%".$qsystem_users."%' OR  `login_password` LIKE '%".$qsystem_users."%' OR  `ref_id` LIKE '%".$qsystem_users."%' OR  `regdate` LIKE '%".$qsystem_users."%' OR  `user_no` LIKE '%".$qsystem_users."%' OR  `user_pic` LIKE '%".$qsystem_users."%' OR  `user_gender` LIKE '%".$qsystem_users."%' OR  `last_seen` LIKE '%".$qsystem_users."%' OR  `about` LIKE '%".$qsystem_users."%' OR  `hive_site_id` LIKE '%".$qsystem_users."%' OR  `hive_site_name` LIKE '%".$qsystem_users."%' OR  `auth_token` LIKE '%".$qsystem_users."%' OR  `token_status` LIKE '%".$qsystem_users."%' OR  `token_expiring_in` LIKE '%".$qsystem_users."%' OR  `project_id` LIKE '%".$qsystem_users."%' OR  `project_name` LIKE '%".$qsystem_users."%') AND ".$mosyfilter_system_users_queries_str." ".$system_users_mdsf_qstr_without_where_."";
         
         }
         
		 $gft_system_users="WHERE ".$gft_system_users_where_query;
         
         $gft_system_users_and=$gft_system_users_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_system_users_);
        }
        }elseif(isset($_GET["qsystem_users"])){
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "get_qsystem_users","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
		 $qsystem_users=mmres(base64_decode($_GET["qsystem_users"]));
        
         $gft_system_users_where_query="(`user_id` LIKE '%".$qsystem_users."%' OR  `name` LIKE '%".$qsystem_users."%' OR  `email` LIKE '%".$qsystem_users."%' OR  `tel` LIKE '%".$qsystem_users."%' OR  `login_password` LIKE '%".$qsystem_users."%' OR  `ref_id` LIKE '%".$qsystem_users."%' OR  `regdate` LIKE '%".$qsystem_users."%' OR  `user_no` LIKE '%".$qsystem_users."%' OR  `user_pic` LIKE '%".$qsystem_users."%' OR  `user_gender` LIKE '%".$qsystem_users."%' OR  `last_seen` LIKE '%".$qsystem_users."%' OR  `about` LIKE '%".$qsystem_users."%' OR  `hive_site_id` LIKE '%".$qsystem_users."%' OR  `hive_site_name` LIKE '%".$qsystem_users."%' OR  `auth_token` LIKE '%".$qsystem_users."%' OR  `token_status` LIKE '%".$qsystem_users."%' OR  `token_expiring_in` LIKE '%".$qsystem_users."%' OR  `project_id` LIKE '%".$qsystem_users."%' OR  `project_name` LIKE '%".$qsystem_users."%') ".$system_users_mdsf_qstr_without_where_."";
         
         $gft_system_users="WHERE ".$gft_system_users_where_query;
         
         $gft_system_users_and=$gft_system_users_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_system_users_);

        }
        }elseif(isset($_GET["system_users_mosyfilter"])){
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "system_users_mosyfilter","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
         $gft_system_users_where_query="";
         $gft_system_users="$system_users_mdsf_qstr_with_where_";

         if($_GET["system_users_mosyfilter"]!=""){
          $gft_system_users_where_query=(base64_decode($_GET["system_users_mosyfilter"]));
          $gft_system_users="WHERE ".$gft_system_users_where_query." ".$system_users_mdsf_qstr_without_where_." ";
         }
         
         
         $gft_system_users_and=$gft_system_users_where_query." ".$system_users_mdsf_qstr_without_where_." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_system_users_);

        }
        }else{
         $gft_system_users="$system_users_mdsf_qstr_with_where_";
         $gft_system_users_and="$system_users_mdsf_qstr_without_where_";
         $gft_system_users_where_query="";
        }
       
    //************************************************* END  system_users OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  ?>