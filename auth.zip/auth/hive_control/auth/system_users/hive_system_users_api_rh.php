<?php 

        if(isset($_POST["mpsystem_users_insert_btn"]))
        {
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "insert","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {                   
                  $system_users_return_key=mpadd_system_users();  
               // print_r($_POST);                
                //echo "ret keyyyyyyy ".$system_users_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $system_users_return_key; 

                      } 

                    }else{ 

                                    
                $system_users_custom_redir1=add_url_param ("system_users_uptoken", base64_encode($system_users_return_key), "");
                $system_users_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$system_users_custom_redir1);
                $system_users_custom_redir3=add_url_param ("system_users_table_alert", "system_users_added",$system_users_custom_redir2);
                
                ///echo magic_message($system_users_custom_redir1." -- ".$system_users_custom_redir2."--".$system_users_custom_redir3);
                
                $system_users_custom_redir=$system_users_custom_redir3;
                
               if (is_numeric($system_users_return_key)) {
                  header('location:'.$system_users_custom_redir.'');
                }else{
                  echo magic_message($system_users_return_key);
                }
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_system_users_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");

           }

         }
         
         
      
        if(isset($_POST["mpsystem_users_update_btn"]))
        {
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "insert","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
                    
                  $system_users_return_key=mpupdate_system_users();  
                    
               /// print_r($_POST);
                
               // echo "ret keyyyyyyy ".$system_users_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $system_users_return_key; 

                      } 

                    }else{ 

                                    
                $system_users_custom_redir1=add_url_param ("system_users_uptoken", base64_encode($system_users_return_key), "");
                $system_users_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$system_users_custom_redir1);
                $system_users_custom_redir3=add_url_param ("system_users_table_alert", "system_users_added",$system_users_custom_redir2);
                
                ///echo magic_message($system_users_custom_redir1." -- ".$system_users_custom_redir2."--".$system_users_custom_redir3);
                
                $system_users_custom_redir=$system_users_custom_redir3;
                
               if (is_numeric($system_users_return_key)) {

				header('location:'.$system_users_custom_redir.'');
                  
                }else{
                  echo magic_message($system_users_return_key);
                }                
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_system_users_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");

           }

         }
      //<--ncgh-->

?>