<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $auth_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$auth_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $auth_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$auth_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
  
  //add mosy list query
  $system_users_data_functions_arr=["_system_role_bundles_bundle_name_ref_id"=>'checkblank(getarr_val_(qsystem_role_bundles_ddata("bundle_id", $data_res["ref_id"]), "bundle_name"), $data_res["ref_id"])',
];
  $system_users_data_functions=json_encode($system_users_data_functions_arr, true);
  
  
  
  $system_users__list_query=mosyget_("system_users", "*", "  $gft_system_users order by primkey desc  ", "l:qsystem_users_token:".$datalimit."", $system_users_data_functions, "auth");
?>