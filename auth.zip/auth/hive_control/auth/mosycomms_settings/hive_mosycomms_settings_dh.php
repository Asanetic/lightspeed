<?php //===============Start Mosy queries-============ 

        function mpupdate_mosycomms_settings($custom_input_array="", $appname="auth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "insert","");

           $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);

            //echo $gwauthenticate_mosycomms_settings_;

           if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $mosycomms_settings_post_arr=$new_input_array;

                  

                  $mosycomms_settings_return_key=mosypost_arr_($mosycomms_settings_post_arr, ["mosycomms_settings_update_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$mosycomms_settings_return_key;

                  return $mosycomms_settings_return_key;

           }
         
         }
         
        
        function mpadd_mosycomms_settings($custom_input_array="", $appname="auth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "insert","");

           $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);

            //echo $gwauthenticate_mosycomms_settings_;

           if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $mosycomms_settings_post_arr=$new_input_array;

                  

                  $mosycomms_settings_return_key=mosypost_arr_($mosycomms_settings_post_arr, ["mosycomms_settings_insert_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$mosycomms_settings_return_key;

                  return $mosycomms_settings_return_key;

           }
         
         }
         
         
         
 	//Start Add mosycomms_settings Data ===============
 	function add_mosycomms_settings($mosycomms_settings_arr_)
    {
     $gw_mosycomms_settings_cols=array();
     
     foreach($mosycomms_settings_arr_ as $mosycomms_settings_arr_gw => $mosycomms_settings_arr_gw_val)
     {
     
     	$gw_mosycomms_settings_cols[]=$mosycomms_settings_arr_gw;
        
     }
     
     $gw_mosycomms_settings_cols_str=implode(",", $gw_mosycomms_settings_cols);
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "insert",$gw_mosycomms_settings_cols_str);
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("mosycomms_settings", $mosycomms_settings_arr_);
     
     	//echo $gwauthenticate_mosycomms_settings_;

     }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");

     }
     
    }
    
       function initialize_mosycomms_settings()
        {
        
         global $mosycomms_settings_uptoken;
             
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "select","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
         
         	return get_mosycomms_settings("*", "WHERE primkey='$mosycomms_settings_uptoken'", "r");
         
            echo $gwauthenticate_mosycomms_settings_;

         }else{

         	echo $gwauthenticate_mosycomms_settings_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");
         
         }
        } 
        
       function mginitialize_mosycomms_settings($endpoint="auth",$function_json="")
        {
        
         global $mosycomms_settings_uptoken;
             
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "select","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("mosycomms_settings", "*", "WHERE primkey='$mosycomms_settings_uptoken'", "l",$function_json, $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_mosycomms_settings_;

         }else{

         	echo $gwauthenticate_mosycomms_settings_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");
         
         }
        }         
    //End Add mosycomms_settings Data ===============
                
    //Start Update mosycomms_settings Data ===============
    
 	function update_mosycomms_settings($mosycomms_settings_arr_, $where_str)
    {
         $gw_mosycomms_settings_cols=array();
     
     foreach($mosycomms_settings_arr_ as $mosycomms_settings_arr_gw => $mosycomms_settings_arr_gw_val)
     {
     
     	$gw_mosycomms_settings_cols[]=$mosycomms_settings_arr_gw;
        
     }
     
     $gw_mosycomms_settings_cols_str=implode(",", $gw_mosycomms_settings_cols);
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "update",$gw_mosycomms_settings_cols_str);
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("mosycomms_settings", $mosycomms_settings_arr_, $where_str);

       // echo $gwauthenticate_mosycomms_settings_;
        
        exit;

     }else{

        echo $gwauthenticate_mosycomms_settings_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


      }
    
    }
 	
    
    //End Update mosycomms_settings Data ===============


    //Start get  mosycomms_settings Data ===============
    
    function get_mosycomms_settings($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "select","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {
    	return mosyflex_sel("mosycomms_settings", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosycomms_settings_;

	  }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }    
    }
    //End get  mosycomms_settings Data ===============
    
  //Start get  mosycomms_settings Data ===============
    
    function mgget_mosycomms_settings($colstr="*", $where_str="", $type="l", $endpoint="auth",$function_json="")
    {
          
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "select","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {
     
        return mosyget_("mosycomms_settings", $colstr, $where_str, $type,$function_json, $endpoint);
        
        
    	//return mosyflex_sel("mosycomms_settings", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosycomms_settings_;

	  }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }    
    }
    //End get  mosycomms_settings Data ===============
            

    //======== qmosycomms_settings_data qsingle query function
    
    function qmosycomms_settings_data($qrecord_id_key)
    {
          
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "qdata","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
    	return get_mosycomms_settings("*", "WHERE record_id='$qrecord_id_key'", "r");

		//echo $gwauthenticate_mosycomms_settings_;

      }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }  
    }
    
    function mgqmosycomms_settings_data($qrecord_id_key, $endpoint="auth",$function_json="")
    {
          
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "qdata","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("mosycomms_settings", "*", "WHERE record_id='$qrecord_id_key'", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosycomms_settings_;

      }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }  
    }
   
    //======== qmosycomms_settings_data qsingle query function
    
    
     //======== mosycomms_settings data to array
    
    function mosycomms_settings_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "data_array","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {  
     	$append_mosycomms_settings_arr=array();
    
    	$array_mosycomms_settings_q=get_mosycomms_settings($colstr, $where_str, "l");
        while($array_mosycomms_settings_res=mysqli_fetch_array($array_mosycomms_settings_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_mosycomms_settings_arr[]=$array_mosycomms_settings_res[$tbl_col];
            }
          }else{
          	          
               $append_mosycomms_settings_arr[]=$array_mosycomms_settings_res;

          }
        }
        
        return $append_mosycomms_settings_arr;

		//echo $gwauthenticate_mosycomms_settings_;

      }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }  
    }
   
    //======== qmosycomms_settings_data qsingle query function   
        
    //======== qmosycomms_settings_ddata qsingle query function    
    function qmosycomms_settings_ddata($record_id_col, $qrecord_id_key)
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "qddata","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
    	return get_mosycomms_settings("*", "WHERE $record_id_col='$qrecord_id_key'", "r");



		//echo $gwauthenticate_mosycomms_settings_;

     }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }   
    }
    
    function mgqmosycomms_settings_ddata($record_id_col, $qrecord_id_key, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "qddata","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("mosycomms_settings", "*", "WHERE $record_id_col='$qrecord_id_key'", "l",$function_json, $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosycomms_settings_;

     }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }   
    }    
    //======== qmosycomms_settings_ddata qsingle query function
    
        //======== qmosycomms_settings_gdata qsingle query function    
    function qmosycomms_settings_gdata($mosycomms_settings_where="")
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "gddata","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
     	$where_str="";
        if($mosycomms_settings_where!=="")
        {
        $where_str=" ".$mosycomms_settings_where;
        }
    	return get_mosycomms_settings("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_mosycomms_settings_;

     }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }   
    }
    
    function mgqmosycomms_settings_gdata($mosycomms_settings_where="", $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "gddata","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
     	$where_str="";
        if($mosycomms_settings_where!=="")
        {
        $where_str=" ".$mosycomms_settings_where;
        }
        
        $return_data_set = mosyget_("mosycomms_settings", "*", " ".$where_str." ", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosycomms_settings_;

     }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }   
    }
    //======== qmosycomms_settings_gdata qsingle query function
    

    //======== count mosycomms_settings data function
    
    function count_mosycomms_settings($mosycomms_settings_wherestr)
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "count_data","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
      $clean_mosycomms_settings_where_str="";
  
      if($mosycomms_settings_wherestr!='')
      {
        $clean_mosycomms_settings_where_str="Where ".$mosycomms_settings_wherestr;
      }

      return get_mosycomms_settings("count(*) as return_result", " ".$clean_mosycomms_settings_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosycomms_settings_;

      }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }    
    }
    
    function mgcount_mosycomms_settings($mosycomms_settings_wherestr, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "count_data","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
      $clean_mosycomms_settings_where_str="";
  
      if($mosycomms_settings_wherestr!='')
      {
        $clean_mosycomms_settings_where_str="Where ".$mosycomms_settings_wherestr;
      }

         $return_data_set= mosyget_("mosycomms_settings", "count(*) as return_result", " ".$clean_mosycomms_settings_where_str."", "l", $function_json, $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_mosycomms_settings_;

      }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");


     }    
    }    
    //======== count mosycomms_settings data function
    
    

    //======== sum  mosycomms_settings data function
    
    function sum_mosycomms_settings($mosycomms_settings_sumcol, $mosycomms_settings_wherestr)
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "sum_data","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
      $clean_mosycomms_settings_where_str="";
  
      if($mosycomms_settings_wherestr!='')
      {
        $clean_mosycomms_settings_where_str="Where ".$mosycomms_settings_wherestr;
      }

      $_sum_return = get_mosycomms_settings("sum($mosycomms_settings_sumcol) as return_result", " ".$clean_mosycomms_settings_where_str."", "r")["return_result"];
      
      if($_sum_return=="")
      {
      
       $_sum_return="0";
            
      }
      
      return $_sum_return;
      
      //echo $gwauthenticate_mosycomms_settings_;


      }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");
        


     }    
    }
    
    function mgsum_mosycomms_settings($mosycomms_settings_sumcol, $mosycomms_settings_wherestr, $endpoint="auth",$function_json="")
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "sum_data","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
      $clean_mosycomms_settings_where_str="";
  
      if($mosycomms_settings_wherestr!='')
      {
        $clean_mosycomms_settings_where_str="Where ".$mosycomms_settings_wherestr;
      }
      
        $return_data_set = mosyget_("mosycomms_settings", "sum($mosycomms_settings_sumcol) as return_result", " ".$clean_mosycomms_settings_where_str."", "l",$function_json, $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

        
		return $result_node;

      //echo $gwauthenticate_mosycomms_settings_;


      }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");
        


     }    
    }    
    
    //======== sum  mosycomms_settings data function   
    
    
    //Start drop  mosycomms_settings Data ===============
    
    function drop_mosycomms_settings($where_str)
    {
     
     $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "drop_data","");
     
     $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
     
     if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
     {    
    	return magic_sql_delete("mosycomms_settings", $where_str);

		//echo $gwauthenticate_mosycomms_settings_;

      }else{
     
     	echo $gwauthenticate_mosycomms_settings_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");
		

     }
    }
    //End drop  mosycomms_settings Data ===============    
    
    
?>