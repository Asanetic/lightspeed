<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $auth_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$auth_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $auth_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$auth_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
 ///add mosy profile query 
  
  
  //add mosy profile query line
  $mosycomms_settings_data_functions_arr=[];
  $mosycomms_settings_data_functions=json_encode($mosycomms_settings_data_functions_arr, true);
  
  
  $mosycomms_settings_profile_node_query=mosyget_("mosycomms_settings", "*", " WHERE primkey='$mosycomms_settings_uptoken' ", "l", $mosycomms_settings_data_functions, "auth");
  $mosycomms_settings_profile_result_node=[];   
  
  if(isset($mosycomms_settings_profile_node_query["data"][0]))
  {  
    $mosycomms_settings_profile_result_node=$mosycomms_settings_profile_node_query["data"][0];
  }
 $mosycomms_settings_node=$mosycomms_settings_profile_result_node; 
?>
