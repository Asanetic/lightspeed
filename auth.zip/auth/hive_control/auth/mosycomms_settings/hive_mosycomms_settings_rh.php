<?php //===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section mosycomms_settings
  //************************************************* START  mosycomms_settings OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize mosycomms_settings edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['mosycomms_settings_table_alert']))
              	{	
                  if(isset($mosycomms_settings_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$mosycomms_settings_uptoken="";

		if(isset($_GET["mosycomms_settings_uptoken"]))
		{
		$mosycomms_settings_uptoken=base64_decode($_GET["mosycomms_settings_uptoken"]);
		}
        
        if(isset($_POST["mosycomms_settings_uptoken"]))
		{
		$mosycomms_settings_uptoken=base64_decode($_POST["mosycomms_settings_uptoken"]);
		}
        //
        
          $mosycomms_settings_alias_name="MOSYCOMMS SETTINGS";

          if(isset($mosycomms_settings_alias))
          {
             $mosycomms_settings_alias_name=$mosycomms_settings_alias;

          }
          
        //get single data record query with $mosycomms_settings_uptoken
        
        ///$mosycomms_settings_node=get_mosycomms_settings("*", "WHERE primkey='$mosycomms_settings_uptoken'", "r");
        
	
//************* START INSERT  mosycomms_settings QUERY 
if(isset($_POST["mosycomms_settings_insert_btn"])){
//------- begin mosycomms_settings_arr_ins --> 
$mosycomms_settings_arr_ins_=array(

"primkey"=>"NULL",
"record_id"=>magic_random_str(7),
"company_name"=>"?",
"company_email"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End mosycomms_settings_arr_ins -->


          
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "insert","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {

              $mosycomms_settings_validated_ins_str=$mosycomms_settings_arr_ins_;

              if(isset($mosycomms_settings_ins_inputs))
              {
                $mosycomms_settings_validated_ins_str=$mosycomms_settings_ins_inputs;	
              }

              if(empty($mosycomms_settings_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$mosycomms_settings_alias_name." request cannot be empty. Record not added");
              }else{


                $mosycomms_settings_return_key=add_mosycomms_settings($mosycomms_settings_validated_ins_str);
                
                mosy_sql_rollback("mosycomms_settings", "primkey='$mosycomms_settings_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$mosycomms_settings_mosy_rest_req_vars=http_build_query($_POST);
                echo $mosycomms_settings_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $mosycomms_settings_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosycomms_settings_return_key; 

                      } 

                    }else{ 

                                    
                $mosycomms_settings_custom_redir1=add_url_param ("mosycomms_settings_uptoken", base64_encode($mosycomms_settings_return_key), "");
                $mosycomms_settings_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosycomms_settings_custom_redir1);
                $mosycomms_settings_custom_redir3=add_url_param ("mosycomms_settings_table_alert", "mosycomms_settings_added",$mosycomms_settings_custom_redir2);
                
                ///echo magic_message($mosycomms_settings_custom_redir1." -- ".$mosycomms_settings_custom_redir2."--".$mosycomms_settings_custom_redir3);
                
                $mosycomms_settings_custom_redir=$mosycomms_settings_custom_redir3;
                
               header('location:'.$mosycomms_settings_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_mosycomms_settings_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");
         
         }
      
}
//************* END  mosycomms_settings INSERT QUERY 	
	

//************* START mosycomms_settings  UPDATE QUERY 
if(isset($_POST["mosycomms_settings_update_btn"])){
//------- begin mosycomms_settings_arr_updt --> 
$mosycomms_settings_arr_updt_=array(



"company_name"=>"?",
"company_email"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End mosycomms_settings_arr_updt -->



                     
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "update","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
         
            $mosycomms_settings_validated_updt_str=$mosycomms_settings_arr_updt_;

            if(isset($mosycomms_settings_updt_inputs))
            {
              $mosycomms_settings_validated_updt_str=$mosycomms_settings_updt_inputs;	
            }

            if(empty($mosycomms_settings_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$mosycomms_settings_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$mosycomms_settings_key_salt=initialize_mosycomms_settings()["record_id"];
            
              update_mosycomms_settings($mosycomms_settings_validated_updt_str, "primkey='$mosycomms_settings_uptoken' and record_id='$mosycomms_settings_key_salt'");
				

			 mosy_sql_rollback("mosycomms_settings", "primkey='$mosycomms_settings_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $mosycomms_settings_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $mosycomms_settings_mosy_rest_req_vars, "POST");
                
                }
             
              



                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $mosycomms_settings_uptoken; 

                    } 

                  }else{ 

                $mosycomms_settings_custom_redir1=add_url_param ("mosycomms_settings_uptoken", base64_encode($mosycomms_settings_uptoken), "");
                $mosycomms_settings_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosycomms_settings_custom_redir1);
                $mosycomms_settings_custom_redir3=add_url_param ("mosycomms_settings_table_alert", "mosycomms_settings_updated",$mosycomms_settings_custom_redir2);
                
                ///echo magic_message($mosycomms_settings_custom_redir1." -- ".$mosycomms_settings_custom_redir2."--".$mosycomms_settings_custom_redir3);
                
                $mosycomms_settings_custom_redir=$mosycomms_settings_custom_redir3;
                
               header('location:'.$mosycomms_settings_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_mosycomms_settings_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");
         
         }

      

      
}
//************* END mosycomms_settings  UPDATE QUERY 

    
    
      //== Start mosycomms_settings delete record

      if(isset($_GET["deletemosycomms_settings"]))
      {
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "super_delete_request","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }


      $conf_del_mosycomms_settings_btn=magic_button_link("./".$current_file_url."?mosycomms_settings_uptoken=".$_GET["mosycomms_settings_uptoken"]."&conf_deletemosycomms_settings&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_mosycomms_settings_btn=magic_button_link("./".$current_file_url."?mosycomms_settings_uptoken=".$_GET["mosycomms_settings_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_mosycomms_settings_btn." ".$cancel_del_mosycomms_settings_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_mosycomms_settings_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemosycomms_settings"]))
      {
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "super_delete_confirm","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      //$mosycomms_settings_del_key_salt=initialize_mosycomms_settings()["record_id"];
      //mosy_sql_rollback("mosycomms_settings", "primkey='$mosycomms_settings_uptoken'", "DELETE");
      //drop_mosycomms_settings("primkey='$mosycomms_settings_uptoken' and record_id='$mosycomms_settings_del_key_salt'");
      $mosycomms_settingscurlopt_url=$hive_routes["auth"];;
      $mosycomms_settingscurlopt_httpheader="";
      $mosycomms_settingscurlopt_userpwd="";
      $mosycomms_settingscurlopt_post_fields="?conf_deletemosycomms_settings&mosycomms_settings_uptoken=".base64_encode($mosycomms_settings_uptoken);
      $mosycomms_settingscurlopt_customrequest="GET";

      magic_post_curl($mosycomms_settingscurlopt_url.$mosycomms_settingscurlopt_post_fields, $mosycomms_settingscurlopt_httpheader, $mosycomms_settingscurlopt_userpwd, "", $mosycomms_settingscurlopt_customrequest);

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_mosycomms_settings_);

      }
      }

      //== End mosycomms_settings delete record  
    
       ///SELECT STRING FOR mosycomms_settings============================
              
       if(isset($_POST["qmosycomms_settings_btn"])){
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "qmosycomms_settings_btn","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
            $current_mosycomms_settings_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_mosycomms_settings_current_url=$current_mosycomms_settings_url_params.'?qmosycomms_settings=';


            if (strpos($current_mosycomms_settings_url_params, '?') !== false) {

                $clean_mosycomms_settings_current_url=$current_mosycomms_settings_url_params.'&qmosycomms_settings=';

            }
            if (strpos($current_mosycomms_settings_url_params, '?qmosycomms_settings')) {

                $remove_mosycomms_settings_old_token = substr($current_mosycomms_settings_url_params, 0, strpos($current_mosycomms_settings_url_params, "?qmosycomms_settings"));

                $clean_mosycomms_settings_current_url=$remove_mosycomms_settings_old_token.'?qmosycomms_settings=';

            }
            if(strpos($current_mosycomms_settings_url_params, '&qmosycomms_settings')) {

                $remove_mosycomms_settings_old_token = substr($current_mosycomms_settings_url_params, 0, strpos($current_mosycomms_settings_url_params, "&qmosycomms_settings"));

                $clean_mosycomms_settings_current_url=$remove_mosycomms_settings_old_token.'&qmosycomms_settings=';

            }
        $qmosycomms_settings_str=base64_encode($_POST["txt_mosycomms_settings"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_mosycomms_settings_current_url.($qmosycomms_settings_str);
            } 

          }else{ 


             header('location:'.$clean_mosycomms_settings_current_url.($qmosycomms_settings_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_mosycomms_settings_);

        }
        }
        $qmosycomms_settings="";
               //handle data sensisitve filters
        $mosycomms_settings_mdsf_="";
        $mosycomms_settings_mdsf_qstr_without_where_="";
        $mosycomms_settings_mdsf_qstr_with_where_="";

        if(isset($mosy_dsft_))
        {
          $mosycomms_settings_mdsf_=$mosy_dsft_["global_filter"];
          
          if(isset($mosy_dsft_["mosycomms_settings"]))
          {
            $mosycomms_settings_mdsf_=$mosy_dsft_["mosycomms_settings"];
          }
          
          if($mosycomms_settings_mdsf_!="")
          {
            $mosycomms_settings_mdsf_qstr_without_where_=" AND $mosycomms_settings_mdsf_";
            $mosycomms_settings_mdsf_qstr_with_where_=" WHERE $mosycomms_settings_mdsf_";
            
          }
          
        }

        ///echo " dsgft__ $mosycomms_settings_mdsf_ with  $mosycomms_settings_mdsf_qstr_with_where_ wihout $mosycomms_settings_mdsf_qstr_without_where_ ";
        
		if(isset($_GET["mosycomms_settings_mosyfilter"]) && isset($_GET["qmosycomms_settings"])){
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "mosycomms_settings_mosyfilter_n_query","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
         $qmosycomms_settings=mmres(base64_decode($_GET["qmosycomms_settings"]));
         
         $gft_mosycomms_settings_where_query="(`record_id` LIKE '%".$qmosycomms_settings."%' OR  `company_name` LIKE '%".$qmosycomms_settings."%' OR  `company_email` LIKE '%".$qmosycomms_settings."%' OR  `hive_site_id` LIKE '%".$qmosycomms_settings."%' OR  `hive_site_name` LIKE '%".$qmosycomms_settings."%') ".$mosycomms_settings_mdsf_qstr_without_where_."";
         
         if($_GET["mosycomms_settings_mosyfilter"]!=""){
         
         $mosyfilter_mosycomms_settings_queries_str=(base64_decode($_GET["mosycomms_settings_mosyfilter"]));
        
         $gft_mosycomms_settings_where_query="(`record_id` LIKE '%".$qmosycomms_settings."%' OR  `company_name` LIKE '%".$qmosycomms_settings."%' OR  `company_email` LIKE '%".$qmosycomms_settings."%' OR  `hive_site_id` LIKE '%".$qmosycomms_settings."%' OR  `hive_site_name` LIKE '%".$qmosycomms_settings."%') AND ".$mosyfilter_mosycomms_settings_queries_str." ".$mosycomms_settings_mdsf_qstr_without_where_."";
         
         }
         
		 $gft_mosycomms_settings="WHERE ".$gft_mosycomms_settings_where_query;
         
         $gft_mosycomms_settings_and=$gft_mosycomms_settings_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_mosycomms_settings_);
        }
        }elseif(isset($_GET["qmosycomms_settings"])){
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "get_qmosycomms_settings","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
		 $qmosycomms_settings=mmres(base64_decode($_GET["qmosycomms_settings"]));
        
         $gft_mosycomms_settings_where_query="(`record_id` LIKE '%".$qmosycomms_settings."%' OR  `company_name` LIKE '%".$qmosycomms_settings."%' OR  `company_email` LIKE '%".$qmosycomms_settings."%' OR  `hive_site_id` LIKE '%".$qmosycomms_settings."%' OR  `hive_site_name` LIKE '%".$qmosycomms_settings."%') ".$mosycomms_settings_mdsf_qstr_without_where_."";
         
         $gft_mosycomms_settings="WHERE ".$gft_mosycomms_settings_where_query;
         
         $gft_mosycomms_settings_and=$gft_mosycomms_settings_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_mosycomms_settings_);

        }
        }elseif(isset($_GET["mosycomms_settings_mosyfilter"])){
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "mosycomms_settings_mosyfilter","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
         $gft_mosycomms_settings_where_query="";
         $gft_mosycomms_settings="$mosycomms_settings_mdsf_qstr_with_where_";

         if($_GET["mosycomms_settings_mosyfilter"]!=""){
          $gft_mosycomms_settings_where_query=(base64_decode($_GET["mosycomms_settings_mosyfilter"]));
          $gft_mosycomms_settings="WHERE ".$gft_mosycomms_settings_where_query." ".$mosycomms_settings_mdsf_qstr_without_where_." ";
         }
         
         
         $gft_mosycomms_settings_and=$gft_mosycomms_settings_where_query." ".$mosycomms_settings_mdsf_qstr_without_where_." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_mosycomms_settings_);

        }
        }else{
         $gft_mosycomms_settings="$mosycomms_settings_mdsf_qstr_with_where_";
         $gft_mosycomms_settings_and="$mosycomms_settings_mdsf_qstr_without_where_";
         $gft_mosycomms_settings_where_query="";
        }
       
    //************************************************* END  mosycomms_settings OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  ?>