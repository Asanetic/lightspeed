<?php 

        if(isset($_POST["mpmosycomms_settings_insert_btn"]))
        {
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "insert","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {                   
                  $mosycomms_settings_return_key=mpadd_mosycomms_settings();  
               // print_r($_POST);                
                //echo "ret keyyyyyyy ".$mosycomms_settings_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosycomms_settings_return_key; 

                      } 

                    }else{ 

                                    
                $mosycomms_settings_custom_redir1=add_url_param ("mosycomms_settings_uptoken", base64_encode($mosycomms_settings_return_key), "");
                $mosycomms_settings_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosycomms_settings_custom_redir1);
                $mosycomms_settings_custom_redir3=add_url_param ("mosycomms_settings_table_alert", "mosycomms_settings_added",$mosycomms_settings_custom_redir2);
                
                ///echo magic_message($mosycomms_settings_custom_redir1." -- ".$mosycomms_settings_custom_redir2."--".$mosycomms_settings_custom_redir3);
                
                $mosycomms_settings_custom_redir=$mosycomms_settings_custom_redir3;
                
               if (is_numeric($mosycomms_settings_return_key)) {
                  header('location:'.$mosycomms_settings_custom_redir.'');
                }else{
                  echo magic_message($mosycomms_settings_return_key);
                }
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_mosycomms_settings_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");

           }

         }
         
         
      
        if(isset($_POST["mpmosycomms_settings_update_btn"]))
        {
         $gwauthenticate_mosycomms_settings_=gw_oauth("table", magic_current_url(), "mosycomms_settings", "insert","");

         $gwauthenticate_mosycomms_settings_json=json_decode($gwauthenticate_mosycomms_settings_, true);
         	
          //echo $gwauthenticate_mosycomms_settings_;

         if($gwauthenticate_mosycomms_settings_json["response"]=="ok")
         {
                    
                  $mosycomms_settings_return_key=mpupdate_mosycomms_settings();  
                    
               /// print_r($_POST);
                
               // echo "ret keyyyyyyy ".$mosycomms_settings_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosycomms_settings_return_key; 

                      } 

                    }else{ 

                                    
                $mosycomms_settings_custom_redir1=add_url_param ("mosycomms_settings_uptoken", base64_encode($mosycomms_settings_return_key), "");
                $mosycomms_settings_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosycomms_settings_custom_redir1);
                $mosycomms_settings_custom_redir3=add_url_param ("mosycomms_settings_table_alert", "mosycomms_settings_added",$mosycomms_settings_custom_redir2);
                
                ///echo magic_message($mosycomms_settings_custom_redir1." -- ".$mosycomms_settings_custom_redir2."--".$mosycomms_settings_custom_redir3);
                
                $mosycomms_settings_custom_redir=$mosycomms_settings_custom_redir3;
                
               if (is_numeric($mosycomms_settings_return_key)) {

				header('location:'.$mosycomms_settings_custom_redir.'');
                  
                }else{
                  echo magic_message($mosycomms_settings_return_key);
                }                
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_mosycomms_settings_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosycomms_settings_)."");

           }

         }
      //<--ncgh-->

?>