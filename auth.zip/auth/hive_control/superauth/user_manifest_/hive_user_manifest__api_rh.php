<?php 

        if(isset($_POST["mpuser_manifest__insert_btn"]))
        {
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "insert","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {                   
                  $user_manifest__return_key=mpadd_user_manifest_();  
                print_r($_POST);                
                echo "ret keyyyyyyy ".$user_manifest__return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $user_manifest__return_key; 

                      } 

                    }else{ 

                                    
                $user_manifest__custom_redir1=add_url_param ("user_manifest__uptoken", base64_encode($user_manifest__return_key), "");
                $user_manifest__custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$user_manifest__custom_redir1);
                $user_manifest__custom_redir3=add_url_param ("user_manifest__table_alert", "user_manifest__added",$user_manifest__custom_redir2);
                
                ///echo magic_message($user_manifest__custom_redir1." -- ".$user_manifest__custom_redir2."--".$user_manifest__custom_redir3);
                
                $user_manifest__custom_redir=$user_manifest__custom_redir3;
                
               header('location:'.$user_manifest__custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_user_manifest__);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");

           }

         }
         
         
      
        if(isset($_POST["mpuser_manifest__update_btn"]))
        {
         $gwauthenticate_user_manifest__=gw_oauth("table", magic_current_url(), "user_manifest_", "insert","");

         $gwauthenticate_user_manifest__json=json_decode($gwauthenticate_user_manifest__, true);
         	
          //echo $gwauthenticate_user_manifest__;

         if($gwauthenticate_user_manifest__json["response"]=="ok")
         {
                    
                  $user_manifest__return_key=mpupdate_user_manifest_();  
                    
                print_r($_POST);
                
                echo "ret keyyyyyyy ".$user_manifest__return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $user_manifest__return_key; 

                      } 

                    }else{ 

                                    
                $user_manifest__custom_redir1=add_url_param ("user_manifest__uptoken", base64_encode($user_manifest__return_key), "");
                $user_manifest__custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$user_manifest__custom_redir1);
                $user_manifest__custom_redir3=add_url_param ("user_manifest__table_alert", "user_manifest__added",$user_manifest__custom_redir2);
                
                ///echo magic_message($user_manifest__custom_redir1." -- ".$user_manifest__custom_redir2."--".$user_manifest__custom_redir3);
                
                $user_manifest__custom_redir=$user_manifest__custom_redir3;
                
               header('location:'.$user_manifest__custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_user_manifest__);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_manifest__)."");

           }

         }
      //<--ncgh-->

?>