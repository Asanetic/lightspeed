<?php //===============Start Mosy queries-============ 

        function mpupdate_system_users($custom_input_array="", $appname="superauth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "insert","");

           $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);

            //echo $gwauthenticate_system_users_;

           if($gwauthenticate_system_users_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $system_users_post_arr=$new_input_array;

                  
         
                if(!empty($_FILES['txt_system_users_user_pic']['tmp_name']))
                {
                
			 $system_users_user_pic_curl_media_arr = curl_file_create($_FILES['txt_system_users_user_pic']['tmp_name'],$_FILES['txt_system_users_user_pic']['type'],$_FILES['txt_system_users_user_pic']['name']);

		      $system_users_user_pic_post_media_arr = array('txt_system_users_user_pic' => $system_users_user_pic_curl_media_arr);
           
           
                 $system_users_post_arr=array_merge($system_users_user_pic_post_media_arr,$new_input_array);                  
				}

                  $system_users_return_key=mosypost_arr_($system_users_post_arr, ["system_users_update_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$system_users_return_key;

                  return $system_users_return_key;

           }
         
         }
         
        
        function mpadd_system_users($custom_input_array="", $appname="superauth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "insert","");

           $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);

            //echo $gwauthenticate_system_users_;

           if($gwauthenticate_system_users_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $system_users_post_arr=$new_input_array;

                  
         
                if(!empty($_FILES['txt_system_users_user_pic']['tmp_name']))
                {
                                 

			 $system_users_user_pic_curl_media_arr = curl_file_create($_FILES['txt_system_users_user_pic']['tmp_name'],$_FILES['txt_system_users_user_pic']['type'],$_FILES['txt_system_users_user_pic']['name']);

		      $system_users_user_pic_post_media_arr = array('txt_system_users_user_pic' => $system_users_user_pic_curl_media_arr);
           
           
                 $system_users_post_arr=array_merge($system_users_user_pic_post_media_arr,$new_input_array); 
                 
				}
                
         

                  $system_users_return_key=mosypost_arr_($system_users_post_arr, ["system_users_insert_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$system_users_return_key;

                  return $system_users_return_key;

           }
         
         }
         
         
         
 	//Start Add system_users Data ===============
 	function add_system_users($system_users_arr_)
    {
     $gw_system_users_cols=array();
     
     foreach($system_users_arr_ as $system_users_arr_gw => $system_users_arr_gw_val)
     {
     
     	$gw_system_users_cols[]=$system_users_arr_gw;
        
     }
     
     $gw_system_users_cols_str=implode(",", $gw_system_users_cols);
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "insert",$gw_system_users_cols_str);
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("system_users", $system_users_arr_);
     
     	//echo $gwauthenticate_system_users_;

     }else{
     
     	echo $gwauthenticate_system_users_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");

     }
     
    }
    
       function initialize_system_users()
        {
        
         global $system_users_uptoken;
             
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "select","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
         
         	return get_system_users("*", "WHERE primkey='$system_users_uptoken'", "r");
         
            echo $gwauthenticate_system_users_;

         }else{

         	echo $gwauthenticate_system_users_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");
         
         }
        } 
        
       function mginitialize_system_users($endpoint="superauth",$function_json="")
        {
        
         global $system_users_uptoken;
             
         $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "select","");

         $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
         	
          //echo $gwauthenticate_system_users_;

         if($gwauthenticate_system_users_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("system_users", "*", "WHERE primkey='$system_users_uptoken'", "l",$function_json, $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_system_users_;

         }else{

         	echo $gwauthenticate_system_users_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");
         
         }
        }         
    //End Add system_users Data ===============
                
    //Start Update system_users Data ===============
    
 	function update_system_users($system_users_arr_, $where_str)
    {
         $gw_system_users_cols=array();
     
     foreach($system_users_arr_ as $system_users_arr_gw => $system_users_arr_gw_val)
     {
     
     	$gw_system_users_cols[]=$system_users_arr_gw;
        
     }
     
     $gw_system_users_cols_str=implode(",", $gw_system_users_cols);
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "update",$gw_system_users_cols_str);
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("system_users", $system_users_arr_, $where_str);

       // echo $gwauthenticate_system_users_;
        
        exit;

     }else{

        echo $gwauthenticate_system_users_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


      }
    
    }
 	
    
    //End Update system_users Data ===============


    //Start get  system_users Data ===============
    
    function get_system_users($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "select","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {
    	return mosyflex_sel("system_users", $colstr, $where_str, $type);

        //echo $gwauthenticate_system_users_;

	  }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }    
    }
    //End get  system_users Data ===============
    
  //Start get  system_users Data ===============
    
    function mgget_system_users($colstr="*", $where_str="", $type="l", $endpoint="superauth",$function_json="")
    {
          
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "select","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {
     
        return mosyget_("system_users", $colstr, $where_str, $type,$function_json, $endpoint);
        
        
    	//return mosyflex_sel("system_users", $colstr, $where_str, $type);

        //echo $gwauthenticate_system_users_;

	  }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }    
    }
    //End get  system_users Data ===============
            

    //======== qsystem_users_data qsingle query function
    
    function qsystem_users_data($quser_id_key)
    {
          
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "qdata","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
    	return get_system_users("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_system_users_;

      }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }  
    }
    
    function mgqsystem_users_data($quser_id_key, $endpoint="superauth",$function_json="")
    {
          
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "qdata","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("system_users", "*", "WHERE user_id='$quser_id_key'", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_system_users_;

      }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }  
    }
   
    //======== qsystem_users_data qsingle query function
    
    
     //======== system_users data to array
    
    function system_users_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "data_array","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {  
     	$append_system_users_arr=array();
    
    	$array_system_users_q=get_system_users($colstr, $where_str, "l");
        while($array_system_users_res=mysqli_fetch_array($array_system_users_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_system_users_arr[]=$array_system_users_res[$tbl_col];
            }
          }else{
          	          
               $append_system_users_arr[]=$array_system_users_res;

          }
        }
        
        return $append_system_users_arr;

		//echo $gwauthenticate_system_users_;

      }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }  
    }
   
    //======== qsystem_users_data qsingle query function   
        
    //======== qsystem_users_ddata qsingle query function    
    function qsystem_users_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "qddata","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
    	return get_system_users("*", "WHERE $user_id_col='$quser_id_key'", "r");



		//echo $gwauthenticate_system_users_;

     }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }   
    }
    
    function mgqsystem_users_ddata($user_id_col, $quser_id_key, $endpoint="superauth",$function_json="")
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "qddata","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("system_users", "*", "WHERE $user_id_col='$quser_id_key'", "l",$function_json, $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_system_users_;

     }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }   
    }    
    //======== qsystem_users_ddata qsingle query function
    
        //======== qsystem_users_gdata qsingle query function    
    function qsystem_users_gdata($system_users_where="")
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "gddata","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
     	$where_str="";
        if($system_users_where!=="")
        {
        $where_str=" ".$system_users_where;
        }
    	return get_system_users("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_system_users_;

     }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }   
    }
    
    function mgqsystem_users_gdata($system_users_where="", $endpoint="superauth",$function_json="")
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "gddata","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
     	$where_str="";
        if($system_users_where!=="")
        {
        $where_str=" ".$system_users_where;
        }
        
        $return_data_set = mosyget_("system_users", "*", " ".$where_str." ", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_system_users_;

     }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }   
    }
    //======== qsystem_users_gdata qsingle query function
    

    //======== count system_users data function
    
    function count_system_users($system_users_wherestr)
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "count_data","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
      $clean_system_users_where_str="";
  
      if($system_users_wherestr!='')
      {
        $clean_system_users_where_str="Where ".$system_users_wherestr;
      }

      return get_system_users("count(*) as return_result", " ".$clean_system_users_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_system_users_;

      }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }    
    }
    
    function mgcount_system_users($system_users_wherestr, $endpoint="superauth",$function_json="")
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "count_data","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
      $clean_system_users_where_str="";
  
      if($system_users_wherestr!='')
      {
        $clean_system_users_where_str="Where ".$system_users_wherestr;
      }

         $return_data_set= mosyget_("system_users", "count(*) as return_result", " ".$clean_system_users_where_str."", "l", $function_json, $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_system_users_;

      }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");


     }    
    }    
    //======== count system_users data function
    
    

    //======== sum  system_users data function
    
    function sum_system_users($system_users_sumcol, $system_users_wherestr)
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "sum_data","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
      $clean_system_users_where_str="";
  
      if($system_users_wherestr!='')
      {
        $clean_system_users_where_str="Where ".$system_users_wherestr;
      }

      $_sum_return = get_system_users("sum($system_users_sumcol) as return_result", " ".$clean_system_users_where_str."", "r")["return_result"];
      
      if($_sum_return=="")
      {
      
       $_sum_return="0";
            
      }
      
      return $_sum_return;
      
      //echo $gwauthenticate_system_users_;


      }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");
        


     }    
    }
    
    function mgsum_system_users($system_users_sumcol, $system_users_wherestr, $endpoint="superauth",$function_json="")
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "sum_data","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
      $clean_system_users_where_str="";
  
      if($system_users_wherestr!='')
      {
        $clean_system_users_where_str="Where ".$system_users_wherestr;
      }
      
        $return_data_set = mosyget_("system_users", "sum($system_users_sumcol) as return_result", " ".$clean_system_users_where_str."", "l",$function_json, $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

        
		return $result_node;

      //echo $gwauthenticate_system_users_;


      }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");
        


     }    
    }    
    
    //======== sum  system_users data function   
    
    
    //Start drop  system_users Data ===============
    
    function drop_system_users($where_str)
    {
     
     $gwauthenticate_system_users_=gw_oauth("table", magic_current_url(), "system_users", "drop_data","");
     
     $gwauthenticate_system_users_json=json_decode($gwauthenticate_system_users_, true);
     
     if($gwauthenticate_system_users_json["response"]=="ok")
     {    
    	return magic_sql_delete("system_users", $where_str);

		//echo $gwauthenticate_system_users_;

      }else{
     
     	echo $gwauthenticate_system_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_users_)."");
		

     }
    }
    //End drop  system_users Data ===============    
    
    
            //Start Upload system_users_user_pic Function 
            function upload_system_users_user_pic($txt_system_users_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_system_users_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('img/system_users_user_pic')) @mkdir('./img/system_users_user_pic');

                $cur_item_photos=magic_upload_file('img/system_users_user_pic/', $txt_system_users_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $system_users_node=get_system_users("*", "WHERE ".$where_str."", "r");

                  if (file_exists($system_users_node["user_pic"]))
                  {

                      unlink($system_users_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('system_users', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload system_users_user_pic Function 

            
?>