<?php 
include('./hive_control/superauth/system_users/hive_system_users_dh.php');

include('./hive_control/superauth/page_manifest_/hive_page_manifest__dh.php');
include('./hive_control/superauth/user_manifest_/hive_user_manifest__dh.php');

include('./hive_control/superauth/system_users/hive_system_users_rh.php');
include('./hive_control/superauth/user_manifest_/hive_user_manifest__rh.php');
include('./hive_control/superauth/page_manifest_/hive_page_manifest__rh.php');
include('./hive_control/superauth/page_manifest_/hive_page_manifest__api_rh.php');
include('./saconfig.php');

$system_users_node=mginitialize_system_users();
$node_manifest_user_id=getarr_val_($system_users_node, $user_id_col);
$page_manifest__node=mginitialize_page_manifest_();
$accesseditor_admin="acc_control";
?>