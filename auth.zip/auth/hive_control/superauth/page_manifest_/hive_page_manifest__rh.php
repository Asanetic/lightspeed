<?php //===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section page_manifest_
  //************************************************* START  page_manifest_ OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize page_manifest_ edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['page_manifest__table_alert']))
              	{	
                  if(isset($page_manifest__custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$page_manifest__uptoken="";

		if(isset($_GET["page_manifest__uptoken"]))
		{
		$page_manifest__uptoken=base64_decode($_GET["page_manifest__uptoken"]);
		}
        
        if(isset($_POST["page_manifest__uptoken"]))
		{
		$page_manifest__uptoken=base64_decode($_POST["page_manifest__uptoken"]);
		}
        //
        
          $page_manifest__alias_name="PAGE MANIFEST ";

          if(isset($page_manifest__alias))
          {
             $page_manifest__alias_name=$page_manifest__alias;

          }
          
        //get single data record query with $page_manifest__uptoken
        
        ///$page_manifest__node=get_page_manifest_("*", "WHERE primkey='$page_manifest__uptoken'", "r");
        
	
//************* START INSERT  page_manifest_ QUERY 
if(isset($_POST["page_manifest__insert_btn"])){
//------- begin page_manifest__arr_ins --> 
$page_manifest__arr_ins_=array(

"primkey"=>"NULL",
"manikey"=>magic_random_str(7),
"page_group"=>"?",
"site_id"=>"?",
"page_url"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End page_manifest__arr_ins -->


          
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "insert","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {

              $page_manifest__validated_ins_str=$page_manifest__arr_ins_;

              if(isset($page_manifest__ins_inputs))
              {
                $page_manifest__validated_ins_str=$page_manifest__ins_inputs;	
              }

              if(empty($page_manifest__validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$page_manifest__alias_name." request cannot be empty. Record not added");
              }else{


                $page_manifest__return_key=add_page_manifest_($page_manifest__validated_ins_str);
                
                mosy_sql_rollback("page_manifest_", "primkey='$page_manifest__return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$page_manifest__mosy_rest_req_vars=http_build_query($_POST);
                echo $page_manifest__mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $page_manifest__mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $page_manifest__return_key; 

                      } 

                    }else{ 

                                    
                $page_manifest__custom_redir1=add_url_param ("page_manifest__uptoken", base64_encode($page_manifest__return_key), "");
                $page_manifest__custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$page_manifest__custom_redir1);
                $page_manifest__custom_redir3=add_url_param ("page_manifest__table_alert", "page_manifest__added",$page_manifest__custom_redir2);
                
                ///echo magic_message($page_manifest__custom_redir1." -- ".$page_manifest__custom_redir2."--".$page_manifest__custom_redir3);
                
                $page_manifest__custom_redir=$page_manifest__custom_redir3;
                
               header('location:'.$page_manifest__custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_page_manifest__);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");
         
         }
      
}
//************* END  page_manifest_ INSERT QUERY 	
	

//************* START page_manifest_  UPDATE QUERY 
if(isset($_POST["page_manifest__update_btn"])){
//------- begin page_manifest__arr_updt --> 
$page_manifest__arr_updt_=array(



"page_group"=>"?",
"site_id"=>"?",
"page_url"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End page_manifest__arr_updt -->



                     
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "update","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
         
            $page_manifest__validated_updt_str=$page_manifest__arr_updt_;

            if(isset($page_manifest__updt_inputs))
            {
              $page_manifest__validated_updt_str=$page_manifest__updt_inputs;	
            }

            if(empty($page_manifest__validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$page_manifest__alias_name."  input cannot be empty. Record not Updated");

            }else{
			$page_manifest__key_salt=initialize_page_manifest_()["manikey"];
            
              update_page_manifest_($page_manifest__validated_updt_str, "primkey='$page_manifest__uptoken' and manikey='$page_manifest__key_salt'");
				

			 mosy_sql_rollback("page_manifest_", "primkey='$page_manifest__uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $page_manifest__mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $page_manifest__mosy_rest_req_vars, "POST");
                
                }
             
              



                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $page_manifest__uptoken; 

                    } 

                  }else{ 

                $page_manifest__custom_redir1=add_url_param ("page_manifest__uptoken", base64_encode($page_manifest__uptoken), "");
                $page_manifest__custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$page_manifest__custom_redir1);
                $page_manifest__custom_redir3=add_url_param ("page_manifest__table_alert", "page_manifest__updated",$page_manifest__custom_redir2);
                
                ///echo magic_message($page_manifest__custom_redir1." -- ".$page_manifest__custom_redir2."--".$page_manifest__custom_redir3);
                
                $page_manifest__custom_redir=$page_manifest__custom_redir3;
                
               header('location:'.$page_manifest__custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_page_manifest__);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");
         
         }

      

      
}
//************* END page_manifest_  UPDATE QUERY 

    
    
      //== Start page_manifest_ delete record

      if(isset($_GET["deletepage_manifest_"]))
      {
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "super_delete_request","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }


      $conf_del_page_manifest__btn=magic_button_link("./".$current_file_url."?page_manifest__uptoken=".$_GET["page_manifest__uptoken"]."&conf_deletepage_manifest_&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_page_manifest__btn=magic_button_link("./".$current_file_url."?page_manifest__uptoken=".$_GET["page_manifest__uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_page_manifest__btn." ".$cancel_del_page_manifest__btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_page_manifest__);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletepage_manifest_"]))
      {
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "super_delete_confirm","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      //$page_manifest__del_key_salt=initialize_page_manifest_()["manikey"];
      //mosy_sql_rollback("page_manifest_", "primkey='$page_manifest__uptoken'", "DELETE");
      //drop_page_manifest_("primkey='$page_manifest__uptoken' and manikey='$page_manifest__del_key_salt'");
      $page_manifest_curlopt_url=$hive_routes["superauth"];;
      $page_manifest_curlopt_httpheader="";
      $page_manifest_curlopt_userpwd="";
      $page_manifest_curlopt_post_fields="?conf_deletepage_manifest_&page_manifest__uptoken=".base64_encode($page_manifest__uptoken);
      $page_manifest_curlopt_customrequest="GET";

      magic_post_curl($page_manifest_curlopt_url.$page_manifest_curlopt_post_fields, $page_manifest_curlopt_httpheader, $page_manifest_curlopt_userpwd, "", $page_manifest_curlopt_customrequest);

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_page_manifest__);

      }
      }

      //== End page_manifest_ delete record  
    
       ///SELECT STRING FOR page_manifest_============================
              
       if(isset($_POST["qpage_manifest__btn"])){
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "qpage_manifest__btn","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
            $current_page_manifest__url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_page_manifest__current_url=$current_page_manifest__url_params.'?qpage_manifest_=';


            if (strpos($current_page_manifest__url_params, '?') !== false) {

                $clean_page_manifest__current_url=$current_page_manifest__url_params.'&qpage_manifest_=';

            }
            if (strpos($current_page_manifest__url_params, '?qpage_manifest_')) {

                $remove_page_manifest__old_token = substr($current_page_manifest__url_params, 0, strpos($current_page_manifest__url_params, "?qpage_manifest_"));

                $clean_page_manifest__current_url=$remove_page_manifest__old_token.'?qpage_manifest_=';

            }
            if(strpos($current_page_manifest__url_params, '&qpage_manifest_')) {

                $remove_page_manifest__old_token = substr($current_page_manifest__url_params, 0, strpos($current_page_manifest__url_params, "&qpage_manifest_"));

                $clean_page_manifest__current_url=$remove_page_manifest__old_token.'&qpage_manifest_=';

            }
        $qpage_manifest__str=base64_encode($_POST["txt_page_manifest_"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_page_manifest__current_url.($qpage_manifest__str);
            } 

          }else{ 


             header('location:'.$clean_page_manifest__current_url.($qpage_manifest__str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_page_manifest__);

        }
        }
        $qpage_manifest_="";
		if(isset($_GET["page_manifest__mosyfilter"]) && isset($_GET["qpage_manifest_"])){
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "page_manifest__mosyfilter_n_query","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
         $qpage_manifest_=mmres(base64_decode($_GET["qpage_manifest_"]));
         
         $gft_page_manifest__where_query="(`manikey` LIKE '%".$qpage_manifest_."%' OR  `page_group` LIKE '%".$qpage_manifest_."%' OR  `site_id` LIKE '%".$qpage_manifest_."%' OR  `page_url` LIKE '%".$qpage_manifest_."%' OR  `hive_site_id` LIKE '%".$qpage_manifest_."%' OR  `hive_site_name` LIKE '%".$qpage_manifest_."%')";
         
         if($_GET["page_manifest__mosyfilter"]!=""){
         
         $mosyfilter_page_manifest__queries_str=(base64_decode($_GET["page_manifest__mosyfilter"]));
        
         $gft_page_manifest__where_query="(`manikey` LIKE '%".$qpage_manifest_."%' OR  `page_group` LIKE '%".$qpage_manifest_."%' OR  `site_id` LIKE '%".$qpage_manifest_."%' OR  `page_url` LIKE '%".$qpage_manifest_."%' OR  `hive_site_id` LIKE '%".$qpage_manifest_."%' OR  `hive_site_name` LIKE '%".$qpage_manifest_."%') AND ".$mosyfilter_page_manifest__queries_str."";
         
         }
         
		 $gft_page_manifest_="WHERE ".$gft_page_manifest__where_query;
         
         $gft_page_manifest__and=$gft_page_manifest__where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_page_manifest__);
        }
        }elseif(isset($_GET["qpage_manifest_"])){
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "get_qpage_manifest_","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
		 $qpage_manifest_=mmres(base64_decode($_GET["qpage_manifest_"]));
        
         $gft_page_manifest__where_query="(`manikey` LIKE '%".$qpage_manifest_."%' OR  `page_group` LIKE '%".$qpage_manifest_."%' OR  `site_id` LIKE '%".$qpage_manifest_."%' OR  `page_url` LIKE '%".$qpage_manifest_."%' OR  `hive_site_id` LIKE '%".$qpage_manifest_."%' OR  `hive_site_name` LIKE '%".$qpage_manifest_."%')";
         
         $gft_page_manifest_="WHERE ".$gft_page_manifest__where_query;
         
         $gft_page_manifest__and=$gft_page_manifest__where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_page_manifest__);

        }
        }elseif(isset($_GET["page_manifest__mosyfilter"])){
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "page_manifest__mosyfilter","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
         $gft_page_manifest__where_query="";
         $gft_page_manifest_="";

         if($_GET["page_manifest__mosyfilter"]!=""){
          $gft_page_manifest__where_query=(base64_decode($_GET["page_manifest__mosyfilter"]));
          $gft_page_manifest_="WHERE ".$gft_page_manifest__where_query;
         }
         
         
         $gft_page_manifest__and=$gft_page_manifest__where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_page_manifest__);

        }
        }else{
         $gft_page_manifest_="";
         $gft_page_manifest__and="";
         $gft_page_manifest__where_query="";
        }
       
    //************************************************* END  page_manifest_ OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  ?>