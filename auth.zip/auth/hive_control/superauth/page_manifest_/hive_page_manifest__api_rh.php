<?php 

        if(isset($_POST["mppage_manifest__insert_btn"]))
        {
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "insert","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {                   
                  $page_manifest__return_key=mpadd_page_manifest_();  
                print_r($_POST);                
                echo "ret keyyyyyyy ".$page_manifest__return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $page_manifest__return_key; 

                      } 

                    }else{ 

                                    
                $page_manifest__custom_redir1=add_url_param ("page_manifest__uptoken", base64_encode($page_manifest__return_key), "");
                $page_manifest__custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$page_manifest__custom_redir1);
                $page_manifest__custom_redir3=add_url_param ("page_manifest__table_alert", "page_manifest__added",$page_manifest__custom_redir2);
                
                ///echo magic_message($page_manifest__custom_redir1." -- ".$page_manifest__custom_redir2."--".$page_manifest__custom_redir3);
                
                $page_manifest__custom_redir=$page_manifest__custom_redir3;
                
               header('location:'.$page_manifest__custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_page_manifest__);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");

           }

         }
         
         
      
        if(isset($_POST["mppage_manifest__update_btn"]))
        {
         $gwauthenticate_page_manifest__=gw_oauth("table", magic_current_url(), "page_manifest_", "insert","");

         $gwauthenticate_page_manifest__json=json_decode($gwauthenticate_page_manifest__, true);
         	
          //echo $gwauthenticate_page_manifest__;

         if($gwauthenticate_page_manifest__json["response"]=="ok")
         {
                    
                  $page_manifest__return_key=mpupdate_page_manifest_();  
                    
                print_r($_POST);
                
                echo "ret keyyyyyyy ".$page_manifest__return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $page_manifest__return_key; 

                      } 

                    }else{ 

                                    
                $page_manifest__custom_redir1=add_url_param ("page_manifest__uptoken", base64_encode($page_manifest__return_key), "");
                $page_manifest__custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$page_manifest__custom_redir1);
                $page_manifest__custom_redir3=add_url_param ("page_manifest__table_alert", "page_manifest__added",$page_manifest__custom_redir2);
                
                ///echo magic_message($page_manifest__custom_redir1." -- ".$page_manifest__custom_redir2."--".$page_manifest__custom_redir3);
                
                $page_manifest__custom_redir=$page_manifest__custom_redir3;
                
               header('location:'.$page_manifest__custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_page_manifest__);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_manifest__)."");

           }

         }
      //<--ncgh-->

?>