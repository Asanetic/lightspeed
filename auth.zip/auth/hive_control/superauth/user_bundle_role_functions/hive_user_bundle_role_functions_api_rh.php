<?php 

        if(isset($_POST["mpuser_bundle_role_functions_insert_btn"]))
        {
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "insert","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {                   
                  $user_bundle_role_functions_return_key=mpadd_user_bundle_role_functions();  
               // print_r($_POST);                
                //echo "ret keyyyyyyy ".$user_bundle_role_functions_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $user_bundle_role_functions_return_key; 

                      } 

                    }else{ 

                                    
                $user_bundle_role_functions_custom_redir1=add_url_param ("user_bundle_role_functions_uptoken", base64_encode($user_bundle_role_functions_return_key), "");
                $user_bundle_role_functions_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$user_bundle_role_functions_custom_redir1);
                $user_bundle_role_functions_custom_redir3=add_url_param ("user_bundle_role_functions_table_alert", "user_bundle_role_functions_added",$user_bundle_role_functions_custom_redir2);
                
                ///echo magic_message($user_bundle_role_functions_custom_redir1." -- ".$user_bundle_role_functions_custom_redir2."--".$user_bundle_role_functions_custom_redir3);
                
                $user_bundle_role_functions_custom_redir=$user_bundle_role_functions_custom_redir3;
                
               if (is_numeric($user_bundle_role_functions_return_key)) {
                  header('location:'.$user_bundle_role_functions_custom_redir.'');
                }else{
                  echo magic_message($user_bundle_role_functions_return_key);
                }
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_user_bundle_role_functions_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");

           }

         }
         
         
      
        if(isset($_POST["mpuser_bundle_role_functions_update_btn"]))
        {
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "insert","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
                    
                  $user_bundle_role_functions_return_key=mpupdate_user_bundle_role_functions();  
                    
               /// print_r($_POST);
                
               // echo "ret keyyyyyyy ".$user_bundle_role_functions_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $user_bundle_role_functions_return_key; 

                      } 

                    }else{ 

                                    
                $user_bundle_role_functions_custom_redir1=add_url_param ("user_bundle_role_functions_uptoken", base64_encode($user_bundle_role_functions_return_key), "");
                $user_bundle_role_functions_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$user_bundle_role_functions_custom_redir1);
                $user_bundle_role_functions_custom_redir3=add_url_param ("user_bundle_role_functions_table_alert", "user_bundle_role_functions_added",$user_bundle_role_functions_custom_redir2);
                
                ///echo magic_message($user_bundle_role_functions_custom_redir1." -- ".$user_bundle_role_functions_custom_redir2."--".$user_bundle_role_functions_custom_redir3);
                
                $user_bundle_role_functions_custom_redir=$user_bundle_role_functions_custom_redir3;
                
               if (is_numeric($user_bundle_role_functions_return_key)) {

				header('location:'.$user_bundle_role_functions_custom_redir.'');
                  
                }else{
                  echo magic_message($user_bundle_role_functions_return_key);
                }                
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_user_bundle_role_functions_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");

           }

         }
      //<--ncgh-->

?>