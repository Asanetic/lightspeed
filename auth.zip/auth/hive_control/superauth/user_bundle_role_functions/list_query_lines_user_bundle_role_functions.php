<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $mpesaengine_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$mpesaengine_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $mpesaengine_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$mpesaengine_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
  //add mosy list query
  $user_bundle_role_functions_data_functions_arr=[];
  $user_bundle_role_functions_data_functions=json_encode($user_bundle_role_functions_data_functions_arr, true);
  
  $user_bundle_role_functions_list_query=mosyget_("user_bundle_role_functions", "*", "  Where $gft_user_bundle_role_functions_and hive_site_id='$mpesaengine_session_hive_site_id'  order by primkey Desc", "l:quser_bundle_role_functions_token:".$datalimit."", $user_bundle_role_functions_data_functions, "mpesaengine");
?>