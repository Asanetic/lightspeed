<?php //===============Start Mosy queries-============ 

        function mpupdate_user_bundle_role_functions($custom_input_array="", $appname="mpesaengine")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "insert","");

           $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);

            //echo $gwauthenticate_user_bundle_role_functions_;

           if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $user_bundle_role_functions_post_arr=$new_input_array;

                  

                  $user_bundle_role_functions_return_key=mosypost_arr_($user_bundle_role_functions_post_arr, ["user_bundle_role_functions_update_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$user_bundle_role_functions_return_key;

                  return $user_bundle_role_functions_return_key;

           }
         
         }
         
        
        function mpadd_user_bundle_role_functions($custom_input_array="", $appname="mpesaengine")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "insert","");

           $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);

            //echo $gwauthenticate_user_bundle_role_functions_;

           if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $user_bundle_role_functions_post_arr=$new_input_array;

                  

                  $user_bundle_role_functions_return_key=mosypost_arr_($user_bundle_role_functions_post_arr, ["user_bundle_role_functions_insert_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$user_bundle_role_functions_return_key;

                  return $user_bundle_role_functions_return_key;

           }
         
         }
         
         
         
 	//Start Add user_bundle_role_functions Data ===============
 	function add_user_bundle_role_functions($user_bundle_role_functions_arr_)
    {
     $gw_user_bundle_role_functions_cols=array();
     
     foreach($user_bundle_role_functions_arr_ as $user_bundle_role_functions_arr_gw => $user_bundle_role_functions_arr_gw_val)
     {
     
     	$gw_user_bundle_role_functions_cols[]=$user_bundle_role_functions_arr_gw;
        
     }
     
     $gw_user_bundle_role_functions_cols_str=implode(",", $gw_user_bundle_role_functions_cols);
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "insert",$gw_user_bundle_role_functions_cols_str);
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("user_bundle_role_functions", $user_bundle_role_functions_arr_);
     
     	//echo $gwauthenticate_user_bundle_role_functions_;

     }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");

     }
     
    }
    
       function initialize_user_bundle_role_functions()
        {
        
         global $user_bundle_role_functions_uptoken;
             
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "select","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
         
         	return get_user_bundle_role_functions("*", "WHERE primkey='$user_bundle_role_functions_uptoken'", "r");
         
            echo $gwauthenticate_user_bundle_role_functions_;

         }else{

         	echo $gwauthenticate_user_bundle_role_functions_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");
         
         }
        } 
        
       function mginitialize_user_bundle_role_functions($endpoint="mpesaengine",$function_json="")
        {
        
         global $user_bundle_role_functions_uptoken;
             
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "select","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("user_bundle_role_functions", "*", "WHERE primkey='$user_bundle_role_functions_uptoken'", "l",$function_json, $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_user_bundle_role_functions_;

         }else{

         	echo $gwauthenticate_user_bundle_role_functions_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");
         
         }
        }         
    //End Add user_bundle_role_functions Data ===============
                
    //Start Update user_bundle_role_functions Data ===============
    
 	function update_user_bundle_role_functions($user_bundle_role_functions_arr_, $where_str)
    {
         $gw_user_bundle_role_functions_cols=array();
     
     foreach($user_bundle_role_functions_arr_ as $user_bundle_role_functions_arr_gw => $user_bundle_role_functions_arr_gw_val)
     {
     
     	$gw_user_bundle_role_functions_cols[]=$user_bundle_role_functions_arr_gw;
        
     }
     
     $gw_user_bundle_role_functions_cols_str=implode(",", $gw_user_bundle_role_functions_cols);
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "update",$gw_user_bundle_role_functions_cols_str);
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("user_bundle_role_functions", $user_bundle_role_functions_arr_, $where_str);

       // echo $gwauthenticate_user_bundle_role_functions_;
        
        exit;

     }else{

        echo $gwauthenticate_user_bundle_role_functions_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


      }
    
    }
 	
    
    //End Update user_bundle_role_functions Data ===============


    //Start get  user_bundle_role_functions Data ===============
    
    function get_user_bundle_role_functions($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "select","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {
    	return mosyflex_sel("user_bundle_role_functions", $colstr, $where_str, $type);

        //echo $gwauthenticate_user_bundle_role_functions_;

	  }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }    
    }
    //End get  user_bundle_role_functions Data ===============
    
  //Start get  user_bundle_role_functions Data ===============
    
    function mgget_user_bundle_role_functions($colstr="*", $where_str="", $type="l", $endpoint="mpesaengine",$function_json="")
    {
          
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "select","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {
     
        return mosyget_("user_bundle_role_functions", $colstr, $where_str, $type,$function_json, $endpoint);
        
        
    	//return mosyflex_sel("user_bundle_role_functions", $colstr, $where_str, $type);

        //echo $gwauthenticate_user_bundle_role_functions_;

	  }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }    
    }
    //End get  user_bundle_role_functions Data ===============
            

    //======== quser_bundle_role_functions_data qsingle query function
    
    function quser_bundle_role_functions_data($qrecord_id_key)
    {
          
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "qdata","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
    	return get_user_bundle_role_functions("*", "WHERE record_id='$qrecord_id_key'", "r");

		//echo $gwauthenticate_user_bundle_role_functions_;

      }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }  
    }
    
    function mgquser_bundle_role_functions_data($qrecord_id_key, $endpoint="mpesaengine",$function_json="")
    {
          
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "qdata","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("user_bundle_role_functions", "*", "WHERE record_id='$qrecord_id_key'", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_user_bundle_role_functions_;

      }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }  
    }
   
    //======== quser_bundle_role_functions_data qsingle query function
    
    
     //======== user_bundle_role_functions data to array
    
    function user_bundle_role_functions_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "data_array","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {  
     	$append_user_bundle_role_functions_arr=array();
    
    	$array_user_bundle_role_functions_q=get_user_bundle_role_functions($colstr, $where_str, "l");
        while($array_user_bundle_role_functions_res=mysqli_fetch_array($array_user_bundle_role_functions_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_user_bundle_role_functions_arr[]=$array_user_bundle_role_functions_res[$tbl_col];
            }
          }else{
          	          
               $append_user_bundle_role_functions_arr[]=$array_user_bundle_role_functions_res;

          }
        }
        
        return $append_user_bundle_role_functions_arr;

		//echo $gwauthenticate_user_bundle_role_functions_;

      }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }  
    }
   
    //======== quser_bundle_role_functions_data qsingle query function   
        
    //======== quser_bundle_role_functions_ddata qsingle query function    
    function quser_bundle_role_functions_ddata($record_id_col, $qrecord_id_key)
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "qddata","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
    	return get_user_bundle_role_functions("*", "WHERE $record_id_col='$qrecord_id_key'", "r");



		//echo $gwauthenticate_user_bundle_role_functions_;

     }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }   
    }
    
    function mgquser_bundle_role_functions_ddata($record_id_col, $qrecord_id_key, $endpoint="mpesaengine",$function_json="")
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "qddata","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("user_bundle_role_functions", "*", "WHERE $record_id_col='$qrecord_id_key'", "l",$function_json, $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_user_bundle_role_functions_;

     }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }   
    }    
    //======== quser_bundle_role_functions_ddata qsingle query function
    
        //======== quser_bundle_role_functions_gdata qsingle query function    
    function quser_bundle_role_functions_gdata($user_bundle_role_functions_where="")
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "gddata","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
     	$where_str="";
        if($user_bundle_role_functions_where!=="")
        {
        $where_str=" ".$user_bundle_role_functions_where;
        }
    	return get_user_bundle_role_functions("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_user_bundle_role_functions_;

     }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }   
    }
    
    function mgquser_bundle_role_functions_gdata($user_bundle_role_functions_where="", $endpoint="mpesaengine",$function_json="")
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "gddata","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
     	$where_str="";
        if($user_bundle_role_functions_where!=="")
        {
        $where_str=" ".$user_bundle_role_functions_where;
        }
        
        $return_data_set = mosyget_("user_bundle_role_functions", "*", " ".$where_str." ", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_user_bundle_role_functions_;

     }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }   
    }
    //======== quser_bundle_role_functions_gdata qsingle query function
    

    //======== count user_bundle_role_functions data function
    
    function count_user_bundle_role_functions($user_bundle_role_functions_wherestr)
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "count_data","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
      $clean_user_bundle_role_functions_where_str="";
  
      if($user_bundle_role_functions_wherestr!='')
      {
        $clean_user_bundle_role_functions_where_str="Where ".$user_bundle_role_functions_wherestr;
      }

      return get_user_bundle_role_functions("count(*) as return_result", " ".$clean_user_bundle_role_functions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_user_bundle_role_functions_;

      }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }    
    }
    
    function mgcount_user_bundle_role_functions($user_bundle_role_functions_wherestr, $endpoint="mpesaengine",$function_json="")
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "count_data","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
      $clean_user_bundle_role_functions_where_str="";
  
      if($user_bundle_role_functions_wherestr!='')
      {
        $clean_user_bundle_role_functions_where_str="Where ".$user_bundle_role_functions_wherestr;
      }

         $return_data_set= mosyget_("user_bundle_role_functions", "count(*) as return_result", " ".$clean_user_bundle_role_functions_where_str."", "l", $function_json, $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_user_bundle_role_functions_;

      }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");


     }    
    }    
    //======== count user_bundle_role_functions data function
    
    

    //======== sum  user_bundle_role_functions data function
    
    function sum_user_bundle_role_functions($user_bundle_role_functions_sumcol, $user_bundle_role_functions_wherestr)
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "sum_data","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
      $clean_user_bundle_role_functions_where_str="";
  
      if($user_bundle_role_functions_wherestr!='')
      {
        $clean_user_bundle_role_functions_where_str="Where ".$user_bundle_role_functions_wherestr;
      }

      $_sum_return = get_user_bundle_role_functions("sum($user_bundle_role_functions_sumcol) as return_result", " ".$clean_user_bundle_role_functions_where_str."", "r")["return_result"];
      
      if($_sum_return=="")
      {
      
       $_sum_return="0";
            
      }
      
      return $_sum_return;
      
      //echo $gwauthenticate_user_bundle_role_functions_;


      }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");
        


     }    
    }
    
    function mgsum_user_bundle_role_functions($user_bundle_role_functions_sumcol, $user_bundle_role_functions_wherestr, $endpoint="mpesaengine",$function_json="")
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "sum_data","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
      $clean_user_bundle_role_functions_where_str="";
  
      if($user_bundle_role_functions_wherestr!='')
      {
        $clean_user_bundle_role_functions_where_str="Where ".$user_bundle_role_functions_wherestr;
      }
      
        $return_data_set = mosyget_("user_bundle_role_functions", "sum($user_bundle_role_functions_sumcol) as return_result", " ".$clean_user_bundle_role_functions_where_str."", "l",$function_json, $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

        
		return $result_node;

      //echo $gwauthenticate_user_bundle_role_functions_;


      }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");
        


     }    
    }    
    
    //======== sum  user_bundle_role_functions data function   
    
    
    //Start drop  user_bundle_role_functions Data ===============
    
    function drop_user_bundle_role_functions($where_str)
    {
     
     $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "drop_data","");
     
     $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
     
     if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
     {    
    	return magic_sql_delete("user_bundle_role_functions", $where_str);

		//echo $gwauthenticate_user_bundle_role_functions_;

      }else{
     
     	echo $gwauthenticate_user_bundle_role_functions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");
		

     }
    }
    //End drop  user_bundle_role_functions Data ===============    
    
    
?>