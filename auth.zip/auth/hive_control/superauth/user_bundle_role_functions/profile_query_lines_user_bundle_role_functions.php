<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $mpesaengine_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$mpesaengine_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $mpesaengine_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$mpesaengine_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
 ///add mosy profile query 
  
  
  //add mosy profile query line
  $user_bundle_role_functions_data_functions_arr=[];
  $user_bundle_role_functions_data_functions=json_encode($user_bundle_role_functions_data_functions_arr, true);
  
  
  $user_bundle_role_functions_profile_node_query=mosyget_("user_bundle_role_functions", "*", " WHERE primkey='$user_bundle_role_functions_uptoken' ", "l", $user_bundle_role_functions_data_functions, "mpesaengine");
  $user_bundle_role_functions_profile_result_node=[];   
  
  if(isset($user_bundle_role_functions_profile_node_query["data"][0]))
  {  
    $user_bundle_role_functions_profile_result_node=$user_bundle_role_functions_profile_node_query["data"][0];
  }
 $user_bundle_role_functions_node=$user_bundle_role_functions_profile_result_node; 
?>
    <input type="hidden" id="txt_hive_site_id" name="txt_hive_site_id" value="<?php echo checkblank(getarr_val_($user_bundle_role_functions_node, "hive_site_id"), $mpesaengine_session_hive_site_id); ?>"/>
    <input type="hidden" id="txt_hive_site_name" name="txt_hive_site_name" value="<?php echo checkblank(getarr_val_($user_bundle_role_functions_node, "hive_site_name"), $mpesaengine_session_hive_site_name); ?>"/>
     
