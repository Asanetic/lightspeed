<?php //===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section user_bundle_role_functions
  //************************************************* START  user_bundle_role_functions OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize user_bundle_role_functions edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['user_bundle_role_functions_table_alert']))
              	{	
                  if(isset($user_bundle_role_functions_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$user_bundle_role_functions_uptoken="";

		if(isset($_GET["user_bundle_role_functions_uptoken"]))
		{
		$user_bundle_role_functions_uptoken=base64_decode($_GET["user_bundle_role_functions_uptoken"]);
		}
        
        if(isset($_POST["user_bundle_role_functions_uptoken"]))
		{
		$user_bundle_role_functions_uptoken=base64_decode($_POST["user_bundle_role_functions_uptoken"]);
		}
        //
        
          $user_bundle_role_functions_alias_name="USER BUNDLE ROLE FUNCTIONS";

          if(isset($user_bundle_role_functions_alias))
          {
             $user_bundle_role_functions_alias_name=$user_bundle_role_functions_alias;

          }
          
        //get single data record query with $user_bundle_role_functions_uptoken
        
        ///$user_bundle_role_functions_node=get_user_bundle_role_functions("*", "WHERE primkey='$user_bundle_role_functions_uptoken'", "r");
        
	
//************* START INSERT  user_bundle_role_functions QUERY 
if(isset($_POST["user_bundle_role_functions_insert_btn"])){
//------- begin user_bundle_role_functions_arr_ins --> 
$user_bundle_role_functions_arr_ins_=array(

"primkey"=>"NULL",
"record_id"=>magic_random_str(7),
"bundle_id"=>"?",
"bundle_name"=>"?",
"role_id"=>"?",
"role_name"=>"?",
"remark"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End user_bundle_role_functions_arr_ins -->


          
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "insert","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {

              $user_bundle_role_functions_validated_ins_str=$user_bundle_role_functions_arr_ins_;

              if(isset($user_bundle_role_functions_ins_inputs))
              {
                $user_bundle_role_functions_validated_ins_str=$user_bundle_role_functions_ins_inputs;	
              }

              if(empty($user_bundle_role_functions_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$user_bundle_role_functions_alias_name." request cannot be empty. Record not added");
              }else{


                $user_bundle_role_functions_return_key=add_user_bundle_role_functions($user_bundle_role_functions_validated_ins_str);
                
                mosy_sql_rollback("user_bundle_role_functions", "primkey='$user_bundle_role_functions_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$user_bundle_role_functions_mosy_rest_req_vars=http_build_query($_POST);
                echo $user_bundle_role_functions_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $user_bundle_role_functions_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $user_bundle_role_functions_return_key; 

                      } 

                    }else{ 

                                    
                $user_bundle_role_functions_custom_redir1=add_url_param ("user_bundle_role_functions_uptoken", base64_encode($user_bundle_role_functions_return_key), "");
                $user_bundle_role_functions_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$user_bundle_role_functions_custom_redir1);
                $user_bundle_role_functions_custom_redir3=add_url_param ("user_bundle_role_functions_table_alert", "user_bundle_role_functions_added",$user_bundle_role_functions_custom_redir2);
                
                ///echo magic_message($user_bundle_role_functions_custom_redir1." -- ".$user_bundle_role_functions_custom_redir2."--".$user_bundle_role_functions_custom_redir3);
                
                $user_bundle_role_functions_custom_redir=$user_bundle_role_functions_custom_redir3;
                
               header('location:'.$user_bundle_role_functions_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_user_bundle_role_functions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");
         
         }
      
}
//************* END  user_bundle_role_functions INSERT QUERY 	
	

//************* START user_bundle_role_functions  UPDATE QUERY 
if(isset($_POST["user_bundle_role_functions_update_btn"])){
//------- begin user_bundle_role_functions_arr_updt --> 
$user_bundle_role_functions_arr_updt_=array(



"bundle_id"=>"?",
"bundle_name"=>"?",
"role_id"=>"?",
"role_name"=>"?",
"remark"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End user_bundle_role_functions_arr_updt -->



                     
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "update","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
         
            $user_bundle_role_functions_validated_updt_str=$user_bundle_role_functions_arr_updt_;

            if(isset($user_bundle_role_functions_updt_inputs))
            {
              $user_bundle_role_functions_validated_updt_str=$user_bundle_role_functions_updt_inputs;	
            }

            if(empty($user_bundle_role_functions_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$user_bundle_role_functions_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$user_bundle_role_functions_key_salt=initialize_user_bundle_role_functions()["record_id"];
            
              update_user_bundle_role_functions($user_bundle_role_functions_validated_updt_str, "primkey='$user_bundle_role_functions_uptoken' and record_id='$user_bundle_role_functions_key_salt'");
				

			 mosy_sql_rollback("user_bundle_role_functions", "primkey='$user_bundle_role_functions_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $user_bundle_role_functions_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $user_bundle_role_functions_mosy_rest_req_vars, "POST");
                
                }
             
              



                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $user_bundle_role_functions_uptoken; 

                    } 

                  }else{ 

                $user_bundle_role_functions_custom_redir1=add_url_param ("user_bundle_role_functions_uptoken", base64_encode($user_bundle_role_functions_uptoken), "");
                $user_bundle_role_functions_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$user_bundle_role_functions_custom_redir1);
                $user_bundle_role_functions_custom_redir3=add_url_param ("user_bundle_role_functions_table_alert", "user_bundle_role_functions_updated",$user_bundle_role_functions_custom_redir2);
                
                ///echo magic_message($user_bundle_role_functions_custom_redir1." -- ".$user_bundle_role_functions_custom_redir2."--".$user_bundle_role_functions_custom_redir3);
                
                $user_bundle_role_functions_custom_redir=$user_bundle_role_functions_custom_redir3;
                
               header('location:'.$user_bundle_role_functions_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_user_bundle_role_functions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_user_bundle_role_functions_)."");
         
         }

      

      
}
//************* END user_bundle_role_functions  UPDATE QUERY 

    
    
      //== Start user_bundle_role_functions delete record

      if(isset($_GET["deleteuser_bundle_role_functions"]))
      {
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "super_delete_request","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }


      $conf_del_user_bundle_role_functions_btn=magic_button_link("./".$current_file_url."?user_bundle_role_functions_uptoken=".$_GET["user_bundle_role_functions_uptoken"]."&conf_deleteuser_bundle_role_functions&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_user_bundle_role_functions_btn=magic_button_link("./".$current_file_url."?user_bundle_role_functions_uptoken=".$_GET["user_bundle_role_functions_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_user_bundle_role_functions_btn." ".$cancel_del_user_bundle_role_functions_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_user_bundle_role_functions_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteuser_bundle_role_functions"]))
      {
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "super_delete_confirm","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      //$user_bundle_role_functions_del_key_salt=initialize_user_bundle_role_functions()["record_id"];
      //mosy_sql_rollback("user_bundle_role_functions", "primkey='$user_bundle_role_functions_uptoken'", "DELETE");
      //drop_user_bundle_role_functions("primkey='$user_bundle_role_functions_uptoken' and record_id='$user_bundle_role_functions_del_key_salt'");
      $user_bundle_role_functionscurlopt_url=$hive_routes["mpesaengine"];;
      $user_bundle_role_functionscurlopt_httpheader="";
      $user_bundle_role_functionscurlopt_userpwd="";
      $user_bundle_role_functionscurlopt_post_fields="?conf_deleteuser_bundle_role_functions&user_bundle_role_functions_uptoken=".base64_encode($user_bundle_role_functions_uptoken);
      $user_bundle_role_functionscurlopt_customrequest="GET";

      magic_post_curl($user_bundle_role_functionscurlopt_url.$user_bundle_role_functionscurlopt_post_fields, $user_bundle_role_functionscurlopt_httpheader, $user_bundle_role_functionscurlopt_userpwd, "", $user_bundle_role_functionscurlopt_customrequest);

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_user_bundle_role_functions_);

      }
      }

      //== End user_bundle_role_functions delete record  
    
       ///SELECT STRING FOR user_bundle_role_functions============================
              
       if(isset($_POST["quser_bundle_role_functions_btn"])){
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "quser_bundle_role_functions_btn","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
            $current_user_bundle_role_functions_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_user_bundle_role_functions_current_url=$current_user_bundle_role_functions_url_params.'?quser_bundle_role_functions=';


            if (strpos($current_user_bundle_role_functions_url_params, '?') !== false) {

                $clean_user_bundle_role_functions_current_url=$current_user_bundle_role_functions_url_params.'&quser_bundle_role_functions=';

            }
            if (strpos($current_user_bundle_role_functions_url_params, '?quser_bundle_role_functions')) {

                $remove_user_bundle_role_functions_old_token = substr($current_user_bundle_role_functions_url_params, 0, strpos($current_user_bundle_role_functions_url_params, "?quser_bundle_role_functions"));

                $clean_user_bundle_role_functions_current_url=$remove_user_bundle_role_functions_old_token.'?quser_bundle_role_functions=';

            }
            if(strpos($current_user_bundle_role_functions_url_params, '&quser_bundle_role_functions')) {

                $remove_user_bundle_role_functions_old_token = substr($current_user_bundle_role_functions_url_params, 0, strpos($current_user_bundle_role_functions_url_params, "&quser_bundle_role_functions"));

                $clean_user_bundle_role_functions_current_url=$remove_user_bundle_role_functions_old_token.'&quser_bundle_role_functions=';

            }
        $quser_bundle_role_functions_str=base64_encode($_POST["txt_user_bundle_role_functions"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_user_bundle_role_functions_current_url.($quser_bundle_role_functions_str);
            } 

          }else{ 


             header('location:'.$clean_user_bundle_role_functions_current_url.($quser_bundle_role_functions_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_user_bundle_role_functions_);

        }
        }
        $quser_bundle_role_functions="";
		if(isset($_GET["user_bundle_role_functions_mosyfilter"]) && isset($_GET["quser_bundle_role_functions"])){
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "user_bundle_role_functions_mosyfilter_n_query","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
         $quser_bundle_role_functions=mmres(base64_decode($_GET["quser_bundle_role_functions"]));
         
         $gft_user_bundle_role_functions_where_query="(`record_id` LIKE '%".$quser_bundle_role_functions."%' OR  `bundle_id` LIKE '%".$quser_bundle_role_functions."%' OR  `bundle_name` LIKE '%".$quser_bundle_role_functions."%' OR  `role_id` LIKE '%".$quser_bundle_role_functions."%' OR  `role_name` LIKE '%".$quser_bundle_role_functions."%' OR  `remark` LIKE '%".$quser_bundle_role_functions."%' OR  `hive_site_id` LIKE '%".$quser_bundle_role_functions."%' OR  `hive_site_name` LIKE '%".$quser_bundle_role_functions."%')";
         
         if($_GET["user_bundle_role_functions_mosyfilter"]!=""){
         
         $mosyfilter_user_bundle_role_functions_queries_str=(base64_decode($_GET["user_bundle_role_functions_mosyfilter"]));
        
         $gft_user_bundle_role_functions_where_query="(`record_id` LIKE '%".$quser_bundle_role_functions."%' OR  `bundle_id` LIKE '%".$quser_bundle_role_functions."%' OR  `bundle_name` LIKE '%".$quser_bundle_role_functions."%' OR  `role_id` LIKE '%".$quser_bundle_role_functions."%' OR  `role_name` LIKE '%".$quser_bundle_role_functions."%' OR  `remark` LIKE '%".$quser_bundle_role_functions."%' OR  `hive_site_id` LIKE '%".$quser_bundle_role_functions."%' OR  `hive_site_name` LIKE '%".$quser_bundle_role_functions."%') AND ".$mosyfilter_user_bundle_role_functions_queries_str."";
         
         }
         
		 $gft_user_bundle_role_functions="WHERE ".$gft_user_bundle_role_functions_where_query;
         
         $gft_user_bundle_role_functions_and=$gft_user_bundle_role_functions_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_user_bundle_role_functions_);
        }
        }elseif(isset($_GET["quser_bundle_role_functions"])){
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "get_quser_bundle_role_functions","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
		 $quser_bundle_role_functions=mmres(base64_decode($_GET["quser_bundle_role_functions"]));
        
         $gft_user_bundle_role_functions_where_query="(`record_id` LIKE '%".$quser_bundle_role_functions."%' OR  `bundle_id` LIKE '%".$quser_bundle_role_functions."%' OR  `bundle_name` LIKE '%".$quser_bundle_role_functions."%' OR  `role_id` LIKE '%".$quser_bundle_role_functions."%' OR  `role_name` LIKE '%".$quser_bundle_role_functions."%' OR  `remark` LIKE '%".$quser_bundle_role_functions."%' OR  `hive_site_id` LIKE '%".$quser_bundle_role_functions."%' OR  `hive_site_name` LIKE '%".$quser_bundle_role_functions."%')";
         
         $gft_user_bundle_role_functions="WHERE ".$gft_user_bundle_role_functions_where_query;
         
         $gft_user_bundle_role_functions_and=$gft_user_bundle_role_functions_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_user_bundle_role_functions_);

        }
        }elseif(isset($_GET["user_bundle_role_functions_mosyfilter"])){
         $gwauthenticate_user_bundle_role_functions_=gw_oauth("table", magic_current_url(), "user_bundle_role_functions", "user_bundle_role_functions_mosyfilter","");

         $gwauthenticate_user_bundle_role_functions_json=json_decode($gwauthenticate_user_bundle_role_functions_, true);
         	
          //echo $gwauthenticate_user_bundle_role_functions_;

         if($gwauthenticate_user_bundle_role_functions_json["response"]=="ok")
         {
         $gft_user_bundle_role_functions_where_query="";
         $gft_user_bundle_role_functions="";

         if($_GET["user_bundle_role_functions_mosyfilter"]!=""){
          $gft_user_bundle_role_functions_where_query=(base64_decode($_GET["user_bundle_role_functions_mosyfilter"]));
          $gft_user_bundle_role_functions="WHERE ".$gft_user_bundle_role_functions_where_query;
         }
         
         
         $gft_user_bundle_role_functions_and=$gft_user_bundle_role_functions_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_user_bundle_role_functions_);

        }
        }else{
         $gft_user_bundle_role_functions="";
         $gft_user_bundle_role_functions_and="";
         $gft_user_bundle_role_functions_where_query="";
        }
       
    //************************************************* END  user_bundle_role_functions OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  ?>