<?php 
///check if superauth is active
  if(!isset($session_prefix))
  {
    $session_prefix="";
  }  

  //set hive_site_id  to superauth _logged_hive_site_id  
  $superauth_session_hive_site_id="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_id']))
  {
  	$superauth_session_hive_site_id=$_SESSION['session_'.$session_prefix.'_logged_hive_site_id'];
  }
  
  //set hive_site_name  to superauth _logged_hive_site_name
  $superauth_session_hive_site_name="";
  if(isset($_SESSION['session_'.$session_prefix.'_logged_hive_site_name']))
  {
  	$superauth_session_hive_site_name=$_SESSION['session_'.$session_prefix.'_logged_hive_site_name'];
  }
  
  
 ///add mosy profile query 
  
  
  //add mosy profile query line
  $system_role_bundles_data_functions_arr=[];
  $system_role_bundles_data_functions=json_encode($system_role_bundles_data_functions_arr, true);
  
  
  $system_role_bundles_profile_node_query=mosyget_("system_role_bundles", "*", " WHERE primkey='$system_role_bundles_uptoken' ", "l", $system_role_bundles_data_functions, "superauth");
  $system_role_bundles_profile_result_node=[];   
  
  if(isset($system_role_bundles_profile_node_query["data"][0]))
  {  
    $system_role_bundles_profile_result_node=$system_role_bundles_profile_node_query["data"][0];
  }
 $system_role_bundles_node=$system_role_bundles_profile_result_node; 
?>
    <input type="hidden" id="txt_hive_site_id" name="txt_hive_site_id" value="<?php echo checkblank(getarr_val_($system_role_bundles_node, "hive_site_id"), $superauth_session_hive_site_id); ?>"/>
    <input type="hidden" id="txt_hive_site_name" name="txt_hive_site_name" value="<?php echo checkblank(getarr_val_($system_role_bundles_node, "hive_site_name"), $superauth_session_hive_site_name); ?>"/>
     
