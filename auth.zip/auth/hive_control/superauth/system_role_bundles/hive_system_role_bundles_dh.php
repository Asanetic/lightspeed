<?php //===============Start Mosy queries-============ 

        function mpupdate_system_role_bundles($custom_input_array="", $appname="superauth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "insert","");

           $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);

            //echo $gwauthenticate_system_role_bundles_;

           if($gwauthenticate_system_role_bundles_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $system_role_bundles_post_arr=$new_input_array;

                  

                  $system_role_bundles_return_key=mosypost_arr_($system_role_bundles_post_arr, ["system_role_bundles_update_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$system_role_bundles_return_key;

                  return $system_role_bundles_return_key;

           }
         
         }
         
        
        function mpadd_system_role_bundles($custom_input_array="", $appname="superauth")
        {
          global $_POST;
          global $_FILES;
          global $hive_routes;
          
          $new_input_array=$_POST;
          
           $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "insert","");

           $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);

            //echo $gwauthenticate_system_role_bundles_;

           if($gwauthenticate_system_role_bundles_json["response"]=="ok")
           {
                  if($custom_input_array!="")
                  {

                   $new_input_array=$custom_input_array;

                  }

                  $system_role_bundles_post_arr=$new_input_array;

                  

                  $system_role_bundles_return_key=mosypost_arr_($system_role_bundles_post_arr, ["system_role_bundles_insert_btn"=>"ok"], $appname);

                  /////print_r($_POST);

                  ////echo "ret keyyyyyyy ".$system_role_bundles_return_key;

                  return $system_role_bundles_return_key;

           }
         
         }
         
         
         
 	//Start Add system_role_bundles Data ===============
 	function add_system_role_bundles($system_role_bundles_arr_)
    {
     $gw_system_role_bundles_cols=array();
     
     foreach($system_role_bundles_arr_ as $system_role_bundles_arr_gw => $system_role_bundles_arr_gw_val)
     {
     
     	$gw_system_role_bundles_cols[]=$system_role_bundles_arr_gw;
        
     }
     
     $gw_system_role_bundles_cols_str=implode(",", $gw_system_role_bundles_cols);
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "insert",$gw_system_role_bundles_cols_str);
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("system_role_bundles", $system_role_bundles_arr_);
     
     	//echo $gwauthenticate_system_role_bundles_;

     }else{
     
     	echo $gwauthenticate_system_role_bundles_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");

     }
     
    }
    
       function initialize_system_role_bundles()
        {
        
         global $system_role_bundles_uptoken;
             
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "select","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
         
         	return get_system_role_bundles("*", "WHERE primkey='$system_role_bundles_uptoken'", "r");
         
            echo $gwauthenticate_system_role_bundles_;

         }else{

         	echo $gwauthenticate_system_role_bundles_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");
         
         }
        } 
        
       function mginitialize_system_role_bundles($endpoint="superauth",$function_json="")
        {
        
         global $system_role_bundles_uptoken;
             
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "select","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("system_role_bundles", "*", "WHERE primkey='$system_role_bundles_uptoken'", "l",$function_json, $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_system_role_bundles_;

         }else{

         	echo $gwauthenticate_system_role_bundles_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");
         
         }
        }         
    //End Add system_role_bundles Data ===============
                
    //Start Update system_role_bundles Data ===============
    
 	function update_system_role_bundles($system_role_bundles_arr_, $where_str)
    {
         $gw_system_role_bundles_cols=array();
     
     foreach($system_role_bundles_arr_ as $system_role_bundles_arr_gw => $system_role_bundles_arr_gw_val)
     {
     
     	$gw_system_role_bundles_cols[]=$system_role_bundles_arr_gw;
        
     }
     
     $gw_system_role_bundles_cols_str=implode(",", $gw_system_role_bundles_cols);
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "update",$gw_system_role_bundles_cols_str);
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("system_role_bundles", $system_role_bundles_arr_, $where_str);

       // echo $gwauthenticate_system_role_bundles_;
        
        exit;

     }else{

        echo $gwauthenticate_system_role_bundles_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


      }
    
    }
 	
    
    //End Update system_role_bundles Data ===============


    //Start get  system_role_bundles Data ===============
    
    function get_system_role_bundles($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "select","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {
    	return mosyflex_sel("system_role_bundles", $colstr, $where_str, $type);

        //echo $gwauthenticate_system_role_bundles_;

	  }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }    
    }
    //End get  system_role_bundles Data ===============
    
  //Start get  system_role_bundles Data ===============
    
    function mgget_system_role_bundles($colstr="*", $where_str="", $type="l", $endpoint="superauth",$function_json="")
    {
          
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "select","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {
     
        return mosyget_("system_role_bundles", $colstr, $where_str, $type,$function_json, $endpoint);
        
        
    	//return mosyflex_sel("system_role_bundles", $colstr, $where_str, $type);

        //echo $gwauthenticate_system_role_bundles_;

	  }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }    
    }
    //End get  system_role_bundles Data ===============
            

    //======== qsystem_role_bundles_data qsingle query function
    
    function qsystem_role_bundles_data($qrecord_id_key)
    {
          
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "qdata","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
    	return get_system_role_bundles("*", "WHERE record_id='$qrecord_id_key'", "r");

		//echo $gwauthenticate_system_role_bundles_;

      }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }  
    }
    
    function mgqsystem_role_bundles_data($qrecord_id_key, $endpoint="superauth",$function_json="")
    {
          
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "qdata","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("system_role_bundles", "*", "WHERE record_id='$qrecord_id_key'", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_system_role_bundles_;

      }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }  
    }
   
    //======== qsystem_role_bundles_data qsingle query function
    
    
     //======== system_role_bundles data to array
    
    function system_role_bundles_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "data_array","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {  
     	$append_system_role_bundles_arr=array();
    
    	$array_system_role_bundles_q=get_system_role_bundles($colstr, $where_str, "l");
        while($array_system_role_bundles_res=mysqli_fetch_array($array_system_role_bundles_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_system_role_bundles_arr[]=$array_system_role_bundles_res[$tbl_col];
            }
          }else{
          	          
               $append_system_role_bundles_arr[]=$array_system_role_bundles_res;

          }
        }
        
        return $append_system_role_bundles_arr;

		//echo $gwauthenticate_system_role_bundles_;

      }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }  
    }
   
    //======== qsystem_role_bundles_data qsingle query function   
        
    //======== qsystem_role_bundles_ddata qsingle query function    
    function qsystem_role_bundles_ddata($record_id_col, $qrecord_id_key)
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "qddata","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
    	return get_system_role_bundles("*", "WHERE $record_id_col='$qrecord_id_key'", "r");



		//echo $gwauthenticate_system_role_bundles_;

     }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }   
    }
    
    function mgqsystem_role_bundles_ddata($record_id_col, $qrecord_id_key, $endpoint="superauth",$function_json="")
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "qddata","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("system_role_bundles", "*", "WHERE $record_id_col='$qrecord_id_key'", "l",$function_json, $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_system_role_bundles_;

     }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }   
    }    
    //======== qsystem_role_bundles_ddata qsingle query function
    
        //======== qsystem_role_bundles_gdata qsingle query function    
    function qsystem_role_bundles_gdata($system_role_bundles_where="")
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "gddata","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
     	$where_str="";
        if($system_role_bundles_where!=="")
        {
        $where_str=" ".$system_role_bundles_where;
        }
    	return get_system_role_bundles("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_system_role_bundles_;

     }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }   
    }
    
    function mgqsystem_role_bundles_gdata($system_role_bundles_where="", $endpoint="superauth",$function_json="")
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "gddata","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
     	$where_str="";
        if($system_role_bundles_where!=="")
        {
        $where_str=" ".$system_role_bundles_where;
        }
        
        $return_data_set = mosyget_("system_role_bundles", "*", " ".$where_str." ", "l",$function_json, $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_system_role_bundles_;

     }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }   
    }
    //======== qsystem_role_bundles_gdata qsingle query function
    

    //======== count system_role_bundles data function
    
    function count_system_role_bundles($system_role_bundles_wherestr)
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "count_data","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
      $clean_system_role_bundles_where_str="";
  
      if($system_role_bundles_wherestr!='')
      {
        $clean_system_role_bundles_where_str="Where ".$system_role_bundles_wherestr;
      }

      return get_system_role_bundles("count(*) as return_result", " ".$clean_system_role_bundles_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_system_role_bundles_;

      }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }    
    }
    
    function mgcount_system_role_bundles($system_role_bundles_wherestr, $endpoint="superauth",$function_json="")
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "count_data","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
      $clean_system_role_bundles_where_str="";
  
      if($system_role_bundles_wherestr!='')
      {
        $clean_system_role_bundles_where_str="Where ".$system_role_bundles_wherestr;
      }

         $return_data_set= mosyget_("system_role_bundles", "count(*) as return_result", " ".$clean_system_role_bundles_where_str."", "l", $function_json, $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_system_role_bundles_;

      }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");


     }    
    }    
    //======== count system_role_bundles data function
    
    

    //======== sum  system_role_bundles data function
    
    function sum_system_role_bundles($system_role_bundles_sumcol, $system_role_bundles_wherestr)
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "sum_data","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
      $clean_system_role_bundles_where_str="";
  
      if($system_role_bundles_wherestr!='')
      {
        $clean_system_role_bundles_where_str="Where ".$system_role_bundles_wherestr;
      }

      $_sum_return = get_system_role_bundles("sum($system_role_bundles_sumcol) as return_result", " ".$clean_system_role_bundles_where_str."", "r")["return_result"];
      
      if($_sum_return=="")
      {
      
       $_sum_return="0";
            
      }
      
      return $_sum_return;
      
      //echo $gwauthenticate_system_role_bundles_;


      }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");
        


     }    
    }
    
    function mgsum_system_role_bundles($system_role_bundles_sumcol, $system_role_bundles_wherestr, $endpoint="superauth",$function_json="")
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "sum_data","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
      $clean_system_role_bundles_where_str="";
  
      if($system_role_bundles_wherestr!='')
      {
        $clean_system_role_bundles_where_str="Where ".$system_role_bundles_wherestr;
      }
      
        $return_data_set = mosyget_("system_role_bundles", "sum($system_role_bundles_sumcol) as return_result", " ".$clean_system_role_bundles_where_str."", "l",$function_json, $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

        
		return $result_node;

      //echo $gwauthenticate_system_role_bundles_;


      }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");
        


     }    
    }    
    
    //======== sum  system_role_bundles data function   
    
    
    //Start drop  system_role_bundles Data ===============
    
    function drop_system_role_bundles($where_str)
    {
     
     $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "drop_data","");
     
     $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
     
     if($gwauthenticate_system_role_bundles_json["response"]=="ok")
     {    
    	return magic_sql_delete("system_role_bundles", $where_str);

		//echo $gwauthenticate_system_role_bundles_;

      }else{
     
     	echo $gwauthenticate_system_role_bundles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");
		

     }
    }
    //End drop  system_role_bundles Data ===============    
    
    
?>