<?php //===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section system_role_bundles
  //************************************************* START  system_role_bundles OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize system_role_bundles edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['system_role_bundles_table_alert']))
              	{	
                  if(isset($system_role_bundles_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$system_role_bundles_uptoken="";

		if(isset($_GET["system_role_bundles_uptoken"]))
		{
		$system_role_bundles_uptoken=base64_decode($_GET["system_role_bundles_uptoken"]);
		}
        
        if(isset($_POST["system_role_bundles_uptoken"]))
		{
		$system_role_bundles_uptoken=base64_decode($_POST["system_role_bundles_uptoken"]);
		}
        //
        
          $system_role_bundles_alias_name="SYSTEM ROLE BUNDLES";

          if(isset($system_role_bundles_alias))
          {
             $system_role_bundles_alias_name=$system_role_bundles_alias;

          }
          
        //get single data record query with $system_role_bundles_uptoken
        
        ///$system_role_bundles_node=get_system_role_bundles("*", "WHERE primkey='$system_role_bundles_uptoken'", "r");
        
	
//************* START INSERT  system_role_bundles QUERY 
if(isset($_POST["system_role_bundles_insert_btn"])){
//------- begin system_role_bundles_arr_ins --> 
$system_role_bundles_arr_ins_=array(

"primkey"=>"NULL",
"record_id"=>magic_random_str(7),
"bundle_id"=>"?",
"bundle_name"=>"?",
"remark"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End system_role_bundles_arr_ins -->


          
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "insert","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {

              $system_role_bundles_validated_ins_str=$system_role_bundles_arr_ins_;

              if(isset($system_role_bundles_ins_inputs))
              {
                $system_role_bundles_validated_ins_str=$system_role_bundles_ins_inputs;	
              }

              if(empty($system_role_bundles_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$system_role_bundles_alias_name." request cannot be empty. Record not added");
              }else{


                $system_role_bundles_return_key=add_system_role_bundles($system_role_bundles_validated_ins_str);
                
                mosy_sql_rollback("system_role_bundles", "primkey='$system_role_bundles_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$system_role_bundles_mosy_rest_req_vars=http_build_query($_POST);
                echo $system_role_bundles_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $system_role_bundles_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $system_role_bundles_return_key; 

                      } 

                    }else{ 

                                    
                $system_role_bundles_custom_redir1=add_url_param ("system_role_bundles_uptoken", base64_encode($system_role_bundles_return_key), "");
                $system_role_bundles_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$system_role_bundles_custom_redir1);
                $system_role_bundles_custom_redir3=add_url_param ("system_role_bundles_table_alert", "system_role_bundles_added",$system_role_bundles_custom_redir2);
                
                ///echo magic_message($system_role_bundles_custom_redir1." -- ".$system_role_bundles_custom_redir2."--".$system_role_bundles_custom_redir3);
                
                $system_role_bundles_custom_redir=$system_role_bundles_custom_redir3;
                
               header('location:'.$system_role_bundles_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_system_role_bundles_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");
         
         }
      
}
//************* END  system_role_bundles INSERT QUERY 	
	

//************* START system_role_bundles  UPDATE QUERY 
if(isset($_POST["system_role_bundles_update_btn"])){
//------- begin system_role_bundles_arr_updt --> 
$system_role_bundles_arr_updt_=array(



"bundle_id"=>"?",
"bundle_name"=>"?",
"remark"=>"?",
"hive_site_id"=>"?",
"hive_site_name"=>"?"

);
//===-- End system_role_bundles_arr_updt -->



                     
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "update","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
         
            $system_role_bundles_validated_updt_str=$system_role_bundles_arr_updt_;

            if(isset($system_role_bundles_updt_inputs))
            {
              $system_role_bundles_validated_updt_str=$system_role_bundles_updt_inputs;	
            }

            if(empty($system_role_bundles_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$system_role_bundles_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$system_role_bundles_key_salt=initialize_system_role_bundles()["record_id"];
            
              update_system_role_bundles($system_role_bundles_validated_updt_str, "primkey='$system_role_bundles_uptoken' and record_id='$system_role_bundles_key_salt'");
				

			 mosy_sql_rollback("system_role_bundles", "primkey='$system_role_bundles_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $system_role_bundles_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $system_role_bundles_mosy_rest_req_vars, "POST");
                
                }
             
              



                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $system_role_bundles_uptoken; 

                    } 

                  }else{ 

                $system_role_bundles_custom_redir1=add_url_param ("system_role_bundles_uptoken", base64_encode($system_role_bundles_uptoken), "");
                $system_role_bundles_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$system_role_bundles_custom_redir1);
                $system_role_bundles_custom_redir3=add_url_param ("system_role_bundles_table_alert", "system_role_bundles_updated",$system_role_bundles_custom_redir2);
                
                ///echo magic_message($system_role_bundles_custom_redir1." -- ".$system_role_bundles_custom_redir2."--".$system_role_bundles_custom_redir3);
                
                $system_role_bundles_custom_redir=$system_role_bundles_custom_redir3;
                
               header('location:'.$system_role_bundles_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_system_role_bundles_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_role_bundles_)."");
         
         }

      

      
}
//************* END system_role_bundles  UPDATE QUERY 

    
    
      //== Start system_role_bundles delete record

      if(isset($_GET["deletesystem_role_bundles"]))
      {
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "super_delete_request","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }


      $conf_del_system_role_bundles_btn=magic_button_link("./".$current_file_url."?system_role_bundles_uptoken=".$_GET["system_role_bundles_uptoken"]."&conf_deletesystem_role_bundles&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_system_role_bundles_btn=magic_button_link("./".$current_file_url."?system_role_bundles_uptoken=".$_GET["system_role_bundles_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_system_role_bundles_btn." ".$cancel_del_system_role_bundles_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_system_role_bundles_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesystem_role_bundles"]))
      {
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "super_delete_confirm","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      //$system_role_bundles_del_key_salt=initialize_system_role_bundles()["record_id"];
      //mosy_sql_rollback("system_role_bundles", "primkey='$system_role_bundles_uptoken'", "DELETE");
      //drop_system_role_bundles("primkey='$system_role_bundles_uptoken' and record_id='$system_role_bundles_del_key_salt'");
      $system_role_bundlescurlopt_url=$hive_routes["mpesaengine"];;
      $system_role_bundlescurlopt_httpheader="";
      $system_role_bundlescurlopt_userpwd="";
      $system_role_bundlescurlopt_post_fields="?conf_deletesystem_role_bundles&system_role_bundles_uptoken=".base64_encode($system_role_bundles_uptoken);
      $system_role_bundlescurlopt_customrequest="GET";

      magic_post_curl($system_role_bundlescurlopt_url.$system_role_bundlescurlopt_post_fields, $system_role_bundlescurlopt_httpheader, $system_role_bundlescurlopt_userpwd, "", $system_role_bundlescurlopt_customrequest);

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_system_role_bundles_);

      }
      }

      //== End system_role_bundles delete record  
    
       ///SELECT STRING FOR system_role_bundles============================
              
       if(isset($_POST["qsystem_role_bundles_btn"])){
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "qsystem_role_bundles_btn","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
            $current_system_role_bundles_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_system_role_bundles_current_url=$current_system_role_bundles_url_params.'?qsystem_role_bundles=';


            if (strpos($current_system_role_bundles_url_params, '?') !== false) {

                $clean_system_role_bundles_current_url=$current_system_role_bundles_url_params.'&qsystem_role_bundles=';

            }
            if (strpos($current_system_role_bundles_url_params, '?qsystem_role_bundles')) {

                $remove_system_role_bundles_old_token = substr($current_system_role_bundles_url_params, 0, strpos($current_system_role_bundles_url_params, "?qsystem_role_bundles"));

                $clean_system_role_bundles_current_url=$remove_system_role_bundles_old_token.'?qsystem_role_bundles=';

            }
            if(strpos($current_system_role_bundles_url_params, '&qsystem_role_bundles')) {

                $remove_system_role_bundles_old_token = substr($current_system_role_bundles_url_params, 0, strpos($current_system_role_bundles_url_params, "&qsystem_role_bundles"));

                $clean_system_role_bundles_current_url=$remove_system_role_bundles_old_token.'&qsystem_role_bundles=';

            }
        $qsystem_role_bundles_str=base64_encode($_POST["txt_system_role_bundles"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_system_role_bundles_current_url.($qsystem_role_bundles_str);
            } 

          }else{ 


             header('location:'.$clean_system_role_bundles_current_url.($qsystem_role_bundles_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_system_role_bundles_);

        }
        }
        $qsystem_role_bundles="";
		if(isset($_GET["system_role_bundles_mosyfilter"]) && isset($_GET["qsystem_role_bundles"])){
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "system_role_bundles_mosyfilter_n_query","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
         $qsystem_role_bundles=mmres(base64_decode($_GET["qsystem_role_bundles"]));
         
         $gft_system_role_bundles_where_query="(`record_id` LIKE '%".$qsystem_role_bundles."%' OR  `bundle_id` LIKE '%".$qsystem_role_bundles."%' OR  `bundle_name` LIKE '%".$qsystem_role_bundles."%' OR  `remark` LIKE '%".$qsystem_role_bundles."%' OR  `hive_site_id` LIKE '%".$qsystem_role_bundles."%' OR  `hive_site_name` LIKE '%".$qsystem_role_bundles."%')";
         
         if($_GET["system_role_bundles_mosyfilter"]!=""){
         
         $mosyfilter_system_role_bundles_queries_str=(base64_decode($_GET["system_role_bundles_mosyfilter"]));
        
         $gft_system_role_bundles_where_query="(`record_id` LIKE '%".$qsystem_role_bundles."%' OR  `bundle_id` LIKE '%".$qsystem_role_bundles."%' OR  `bundle_name` LIKE '%".$qsystem_role_bundles."%' OR  `remark` LIKE '%".$qsystem_role_bundles."%' OR  `hive_site_id` LIKE '%".$qsystem_role_bundles."%' OR  `hive_site_name` LIKE '%".$qsystem_role_bundles."%') AND ".$mosyfilter_system_role_bundles_queries_str."";
         
         }
         
		 $gft_system_role_bundles="WHERE ".$gft_system_role_bundles_where_query;
         
         $gft_system_role_bundles_and=$gft_system_role_bundles_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_system_role_bundles_);
        }
        }elseif(isset($_GET["qsystem_role_bundles"])){
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "get_qsystem_role_bundles","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
		 $qsystem_role_bundles=mmres(base64_decode($_GET["qsystem_role_bundles"]));
        
         $gft_system_role_bundles_where_query="(`record_id` LIKE '%".$qsystem_role_bundles."%' OR  `bundle_id` LIKE '%".$qsystem_role_bundles."%' OR  `bundle_name` LIKE '%".$qsystem_role_bundles."%' OR  `remark` LIKE '%".$qsystem_role_bundles."%' OR  `hive_site_id` LIKE '%".$qsystem_role_bundles."%' OR  `hive_site_name` LIKE '%".$qsystem_role_bundles."%')";
         
         $gft_system_role_bundles="WHERE ".$gft_system_role_bundles_where_query;
         
         $gft_system_role_bundles_and=$gft_system_role_bundles_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_system_role_bundles_);

        }
        }elseif(isset($_GET["system_role_bundles_mosyfilter"])){
         $gwauthenticate_system_role_bundles_=gw_oauth("table", magic_current_url(), "system_role_bundles", "system_role_bundles_mosyfilter","");

         $gwauthenticate_system_role_bundles_json=json_decode($gwauthenticate_system_role_bundles_, true);
         	
          //echo $gwauthenticate_system_role_bundles_;

         if($gwauthenticate_system_role_bundles_json["response"]=="ok")
         {
         $gft_system_role_bundles_where_query="";
         $gft_system_role_bundles="";

         if($_GET["system_role_bundles_mosyfilter"]!=""){
          $gft_system_role_bundles_where_query=(base64_decode($_GET["system_role_bundles_mosyfilter"]));
          $gft_system_role_bundles="WHERE ".$gft_system_role_bundles_where_query;
         }
         
         
         $gft_system_role_bundles_and=$gft_system_role_bundles_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_system_role_bundles_);

        }
        }else{
         $gft_system_role_bundles="";
         $gft_system_role_bundles_and="";
         $gft_system_role_bundles_where_query="";
        }
       
    //************************************************* END  system_role_bundles OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  ?>