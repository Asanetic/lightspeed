<?php
ob_start();
include('../root_configs/s_env_root.php');
include($s_env_root.'/superauth_env.php');
include($common_root.'/data_control/conn.php');
include($common_root.'/data_control/phpmagicbits.php');
include($common_root.'/data_control/gwdna.php');
include($common_root.'/data_control/hive_routes.php');
include($common_root.'/data_control/hive_gw.php');

include('./saconfig.php');
include('./sauth_sessionmonitor.php');

$default_home_crumb="";
if(isset($home_crumb))
{
 $default_home_crumb=$home_crumb;
}

$first_name_logged=mgqhivesql_data($oauth_table, $user_id_col, $session_sauth_logged_user_id, 'superauth')[$username];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="refresh" content="2; url='<?php echo $aftersplash_page ?>'">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Bootstrap core CSS -->
<?php include("$common_root/includes/admin_css_scripts.php");?>
<title><?php echo $mep_app_name ?> :: Welcome</title>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
	<?php ///include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma " style="min-height:100vh;">
      <div class="row justify-content-center pl-1 pr-1">
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
        
        <?php include('./features/superauth/hive_splash_wgt.php'); ?>
        
          <!--<{ncgh}/>-->
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("$common_root/includes/footer.php");?>
    </form>
</body>
</html>