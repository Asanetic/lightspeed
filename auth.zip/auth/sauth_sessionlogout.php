<?php
  //session logout script 
ob_start();
include('../root_configs/s_env_root.php');
include($s_env_root.'/superauth_env.php');
include($common_root.'/data_control/conn.php');
include($common_root.'/data_control/phpmagicbits.php');
include($common_root.'/data_control/gwdna.php');
include($common_root.'/data_control/hive_routes.php');
include($common_root.'/data_control/hive_gw.php');

  include('./saconfig.php');

  unset($_SESSION['session_'.$session_prefix.'_logged']);
  unset($_SESSION['session_'.$session_prefix.'_logged_email']);
  unset($_SESSION['session_'.$session_prefix.'_logged_name']);
  unset($_SESSION['session_'.$session_prefix.'_logged_tel']);
  unset($_SESSION['session_'.$session_prefix.'_logged_user_id']);
  unset($_SESSION['session_'.$session_prefix.'_logged_ref_id']);

  header('location:'.$login_file.'');

  ?>