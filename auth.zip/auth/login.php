<?php 
ob_start();
include('../root_configs/s_env_root.php');
include($s_env_root.'/superauth_env.php');
include($common_root.'/data_control/conn.php');
include($common_root.'/data_control/phpmagicbits.php');
include($common_root.'/data_control/gwdna.php');
include($common_root.'/data_control/hive_routes.php');
include($common_root.'/data_control/hive_gw.php');

include('./saconfig.php');
include('./sauth_oauth.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

<?php include($common_root.'/includes/admin_css_scripts.php'); ?>
<title><?php echo $mep_app_name ?> :: App Login </title>

<style type="text/css">
.login-body {
    background-image: url('<?php echo ""; //$login_bg_img ?>');
}

.login-wrapper .loginbox {
    box-shadow: 0 0 0px;
    background-color:transparent;

}

        .login_logo_tray_{
            width: 350px;
            height: 350px;
            border-radius: 50%;
            background-color: #ffffff;
            margin: auto; /* Center the container */
        }

        @media (max-width: 768px) {
            /* Adjust styles for smaller screens */
            .login_logo_tray_{
                width: 80%;
                height: 80%;
            }
        }
</style>
</head>
<body>

 <?php  include('./features/auth/'.$login_widget__.'.php');  ?>
 <?php include($common_root.'/includes/admin_footer.php');?>
</body>
</html>