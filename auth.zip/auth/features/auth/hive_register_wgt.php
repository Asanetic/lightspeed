<div class="row justify-content-center m-0 p-0 col-md-12 skin_plasma">
  <div class="col-md-5 p-0 m-0">    
    
    <div class="main-wrapper login-body">
    <div class="login-wrapper">
      <div class="container">
        <div class="loginbox">
          <div class="login-right">
            <div class="login-right-wrap">
            <div class="col-md-12 py-3 text-center ">
              <img src="<?php echo $mep_app_logo; ?>" class="" style="width:100px;" id=""/>
            </div>
            <h1 class="mt-2"> <?php echo $mep_app_name ?> </h1>

            <p class="account-subtitle">Create Account</p>
            <form method="post">
              <div class="form-group">
                  <label >Your Names </label>
                  <input class="form-control mosy_tup" data-mosy_tup="push_newval('txt_hive_site_name', get_newval('txt_<?php echo $username; ?>'))" required id="txt_<?php echo $username; ?>" name="txt_<?php echo $username; ?>" value="" placeholder="Enter your names" type="text">
              </div>
              <div class="form-group">
                  <label > Email </label>
                  <input class="form-control" required id="txt_<?php echo $session_user_mail; ?>" name="txt_<?php echo $session_user_mail; ?>" value="" placeholder="Enter your email" type="text">
              </div>  
              <div class="form-group">
                  <label >Password </label>
                  <input class="form-control" required id="txt_<?php echo $password_col; ?>" name="txt_<?php echo $password_col; ?>" value="" placeholder="Enter password" type="password">
              </div>
              <input type="hidden" id="txt_hive_site_id" name="txt_hive_site_id" value="<?php echo magic_random_str(15)."_".date("Y-m-d-h-i-s-a") ?>"/>
              <input type="hidden" id="txt_hive_site_name" name="txt_hive_site_name" value=""/>
              <input type="hidden" name="txt_regdate" id="txt_regdate" class="form-control" placeholder="Regdate"  value="<?php echo date("Y-m-d H:i:s");?>" />
              <input type="hidden" name="txt_ref_id" id="txt_ref_id" class="form-control" placeholder="Ref id"  value="<?php echo magic_random_str(7).date("ymd") ?>" />  

              <div class="form-group">
                  <button class="btn btn-primary btn-block" name="create_user_acc" type="submit"> Proceed </button>
              </div>            
            </form>            
            <div class="text-center "><a href="<?php echo $login_file ?>">Back to Login</a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    
  </div>
  <div class="col-md-7 order-1 order-lg-2 text-center p-0 m-0 bg_w_img" style="background-image: url('<?php echo $login_bg_img ?>');">
      <div class="col-md-12 p-0 m-0 p-0 align-items-center d-flex" style="background-color: rgba(255, 255, 255, 0.6); height: 100vh;">
          <div class="col-md-12 text-center d-none">
              <img src="<?php echo $mep_app_logo; ?>" style="width: 150px;" alt="Logo" />
              <h1 class="col-md-12 mt-3"><?php echo $mep_app_name ?></h1>
          </div>

      </div>
  </div>
</div>