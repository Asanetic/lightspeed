		         <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                    <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                    <div class="col-md-8 text-center"> You have insufficient rights to access this page.</div>
                    <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                  </h5>
                  <!-- End Title ribbon-->
				 <div class="row justify-content-center m-0 p-0 col-md-12">
  
  					<h1 class="col-md-12 text-center mt-4 text-warning"><i class="fa fa-warning"></i></h1>

  				
  				</div>