            <?php if(isset($_GET['system_users_uptoken'])){?>                            
            <div class="col-md-12">                                
                 <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                    <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                    <div class="col-md-8 p-0 text-center"> User Access</div>
                    <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                  </h5>
                  <!-- End Title ribbon-->
                                  
                 <div class="col-md-12 mt-5" id=""></div>

                  <!-- Start side bar image card list -->
                <a href="<?php echo $accesseditor_admin ?>?system_users_uptoken=<?php echo base64_encode($system_users_node['primkey']) ?>" class="row mb-2 skin_plasma text-dark mb-2 pt-2 pb-2 justify-content-center m-0 col-md-12 rounded_big border-bottom shadow-sm">
                  <div class="col-4 p-0">
                    <img src="<?php $card_photo_src="img/useravatar.png"; if($card_photo_src==''){ echo './img/logo.png';}else{ echo $card_photo_src;}?>" class=" " style="width:50px; height:50px; border-radius:50%;" id=""/>
                  </div>
                  <div class="col-8  text-left p-0" style="font-size:12px">
                    <div><b><?php echo getarr_val_($system_users_node, $username);?></b></div>
                    <div><b><?php echo getarr_val_($system_users_node,$session_user_mail);?></b></div>
                    <div class="border-top border_set pt-2"><span>Assigned roles: <?php echo mgcount_user_manifest_(" user_id='$node_manifest_user_id' ","superauth");?> </span></div>
                  </div>
                </a>
          <!-- End side bar image card list-->            
          <div class="col-md-12 m-4"></div>
           <div class="row justify-content-center m-0 p-0 col-md-12 mt-3 ">                                     
             <div class="col-md-5 border p-0 mr-2 rounded_medium skin_plasma " title="Click role to add" >
               <div class="col-md-12 border-bottom bg-white"><b>Select Roles</b></div>
               <div class="col-md-12 border p-0  skin_plasma " id="select_roles_id" style="max-height:200px; overflow-y:auto;">               
                 <?php $existing_roles_q=mgget_page_manifest_("*", "$gft_page_manifest_ group by page_group order by primkey desc", "l"); ?>
                 <?php 
					foreach($existing_roles_q['data']  as $existing_roles_res){
 					$role_key=$existing_roles_res['page_group'];
					if(mgcount_user_manifest_(" user_id='$node_manifest_user_id' and role_id='$role_key'", "superauth")==0){?>				
                   <div class="col-md-12 border-bottom  border_set cpointer " onclick="push_newval('txt_role_id', '<?php echo $existing_roles_res['page_group'] ?>');push_newval('txt_role_name', '<?php echo $existing_roles_res['page_group'] ?>');user_manifest__ins_('mosy_form', '','load_user_roles')">
                     <span class="badge"> <i class="fa fa-check-circle text-success"></i> <?php echo $existing_roles_res['page_group']?></span>
                   </div>
                 <?php } } ?>
               </div>
             </div>
             <div class="col-md-6 border p-0 rounded_medium skin_plasma " title="Click role to remove">
               <div class="col-md-12 border-bottom btn_neoo2 rounded text-white"><b>Assigned Roles</b></div>
               <div class="col-md-12 border p-0  bg-white " id="assigned_roles" style="max-height:200px; overflow-y:auto;"></div>
             </div>             
           </div>
            </div>
          <?php }?>