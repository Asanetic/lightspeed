<div class="row justify-content-center m-0 p-0 col-md-12 skin_plasma">
  <div class="col-md-4">
   <?php include('./features/superauth/acess_control/pg_grp_ac_wgt.php');?>
  </div>
  <div class="col-md-4">
   <?php include('./features/superauth/acess_control/user_list_ac_wgt.php'); ?>
  </div>
              
  <?php if(isset($_GET['system_users_uptoken'])){?>                            
  <div class="col-md-4">
  <?php include('./features/superauth/acess_control/user_access_wgt.php');?>
  </div>
  <?php } ?>
  <input type="hidden" name="txt_user_name" id="txt_user_name" class="form-control" placeholder="admin_name"  value="<?php echo getarr_val_($system_users_node, $username);?>" />
  <input type="hidden" name="txt_user_id" id="txt_user_id" class="form-control" placeholder="Admin id"  value="<?php echo getarr_val_($system_users_node, $user_id_col);?>" />
  <input type="hidden" name="txt_role_id" id="txt_role_id" class="form-control" placeholder="Role id"  value="<?php echo getarr_val_($user_manifest__node, "role_id");?>" />
  <input type="hidden" name="txt_role_name" id="txt_role_name" class="form-control" placeholder="Role name"  value="<?php echo getarr_val_($user_manifest__node, "role_name");?>" />

  <script type="text/javascript">
     var assigned_roles=`
                        <div class="col-md-12 border-bottom  border_set cpointer " onclick="user_manifest__rem_(btoa('{{primkey}}'), 'load_user_roles')" >
                         <span class="badge"> <i class="fa fa-times-circle text-danger "></i> {{role_name}}</span>
                       </div>
     `;

    var emptyuser =`
    <div class="row justify-content-center cpointer m-0 p-0 col-md-12" >
    <div class="col-md-12 text-center p-3 "><span class=" text-wrap"> No roles Found for this user, click on an exisiting role to assign role.</span></div>
    </div>

    `;
    function load_user_roles()
    { 
    qkload_user_manifest_("", 'push_grid_result:assigned_roles:0:emptyuser', assigned_roles, "user_id='<?php echo getarr_val_($system_users_node, $user_id_col) ?>'");
    }  

    load_user_roles();
  </script> 
</div>
