
           <!--==============================  page group sections  ============================-->
            <div class="col-md-12 ">
                               <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                    <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                    <div class="col-md-8 text-center"> Page Manifest </div>
                    <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                  </h5>
                 <div class="col-md-12 mt-5" id=""></div>
                  <!-- End Title ribbon-->
             <input type="text" class="col-md-7 mb-2 ml-2 bg-transparent" placeholder="Search page manifest " name="txt_page_manifest_" style="color:#000; border:none; border-bottom:1px solid #000;"/>
             <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="qpage_manifest__btn"><i class="fa fa-search"></i> Go</button>
             <a href="<?php echo $accesseditor_admin ?>" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3"><i class="fa fa-refresh"></i> Refresh </a>       
             <div class="row justify-content-center m-0 p-0 col-md-12">
             

  <div class="form-group col-md-4 p-0 text-left">
	
	
              <label ><span>Group</span> 
              <span  id="_toggle_on_page_group"   onclick="document.getElementById('txt_page_group').type='text';document.getElementById('txt_page_group').value='';document.getElementById('sel_page_group').style.display='none';this.style.display='none';document.getElementById('_toggle_off_page_group').style.display='inline-block';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              <span style="display:none" id="_toggle_off_page_group"   onclick="document.getElementById('txt_page_group').type='hidden';document.getElementById('sel_page_group').style.display='block';this.style.display='none';document.getElementById('_toggle_on_page_group').style.display='inline-block';if(document.getElementById('txt_page_group').value=='') document.getElementById('txt_page_group').value=document.getElementById('sel_page_group').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_page_group" id="txt_page_group" class="form-control" placeholder="Type new Page group"  value="<?php echo getarr_val_($page_manifest__node, "page_group");?>" /> 
              <select name="sel_page_group" id="sel_page_group" class="form-control" onchange="document.getElementById('txt_page_group').value=this.value;">
                  <option  value="<?php echo getarr_val_($page_manifest__node, "page_group");?>">
                   <?php if(getarr_val_($page_manifest__node, "page_group")==""){echo "Page group";}else{ echo getarr_val_($page_manifest__node, "page_group");}?>
                  </option>
                  <?php
                  $dropdown_list_page_manifest__page_group_q = mgget_page_manifest_("*", " group by page_group ", "l");    
              foreach($dropdown_list_page_manifest__page_group_q['data'] as $dropdown_list_page_manifest__page_group_r){?>
                 <option value="<?php echo $dropdown_list_page_manifest__page_group_r["page_group"] ?>" >
                  <?php echo $dropdown_list_page_manifest__page_group_r["page_group"] ?>
                 </option>
                 <?php }?>
               </select>
         
  </div>

        <div class="form-group col-md-4 p-0 ">
          <label >Page Key</label>
          <input class="form-control" id="txt_page_url" name="txt_page_url" value="<?php echo getarr_val_($page_manifest__node, "page_url");?>" placeholder="Page Url" type="text">
        </div>
        
      <div class="col-md-4 pt-2">
            <button type="submit" id="page_manifest__insert_btn" name="mppage_manifest__insert_btn" class="badge badge-primary btn_neoo2 p-2 mt-4" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
    </div>
  

             </div>
             <div class="col-md-12 "></div>
              
              <?php 
               $page_manifest__list_query=mgget_page_manifest_("*", "  $gft_page_manifest_ group by page_group ", "l");
				foreach($page_manifest__list_query['data'] as $page_manifest__list_res){
               $page_group=$page_manifest__list_res['page_group'];
              ?>                                
              <details class="text-wrap border-right cpointer text-left m-0 p-1 border_set">
              	<summary class="shadow-sm"><span class="badge text-wrap"> <?php echo $page_manifest__list_res["page_group"] ?></span></summary>
                <?php 
				$page_group_arr=mgget_page_manifest_("*", " where $gft_page_manifest__and page_group='$page_group' ", "l");
				foreach($page_group_arr['data'] as $page_group_arr_res){
				?>
                <div class="row justify-content-center m-0 p-0 col-md-12">
                 <div class="col-7 p-0  "><i  onclick="page_manifest__rem_(btoa('<?php echo $page_group_arr_res['primkey'] ?>'), 'mosy_reload')" class="fa fa-times-circle mr-2 text-danger "></i> <?php echo $page_group_arr_res['page_url'] ?></div>
                 <div class="col-5 p-0 ">                   	
                   
  					<div class="form-group col-md-12 p-0  text-left">		
                      <label ><span>Page group</span> 
                      <span  id="_toggle_on_page_group_<?php echo $page_group_arr_res['primkey'] ?>"   onclick="document.getElementById('txt_page_group_<?php echo $page_group_arr_res['primkey'] ?>').type='text';document.getElementById('txt_page_group_<?php echo $page_group_arr_res['primkey'] ?>').value='';document.getElementById('sel_page_group_<?php echo $page_group_arr_res['primkey'] ?>').style.display='none';this.style.display='none';document.getElementById('_toggle_off_page_group_<?php echo $page_group_arr_res['primkey'] ?>').style.display='inline-block';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>

                      <span style="display:none" id="_toggle_off_page_group_<?php echo $page_group_arr_res['primkey'] ?>"   onclick="document.getElementById('txt_page_group_<?php echo $page_group_arr_res['primkey'] ?>').type='hidden';document.getElementById('sel_page_group_<?php echo $page_group_arr_res['primkey'] ?>').style.display='block';this.style.display='none';document.getElementById('_toggle_on_page_group_<?php echo $page_group_arr_res['primkey'] ?>').style.display='inline-block';if(document.getElementById('txt_page_group_<?php echo $page_group_arr_res['primkey'] ?>').value=='') document.getElementById('txt_page_group_<?php echo $page_group_arr_res['primkey'] ?>').value=document.getElementById('sel_page_group_<?php echo $page_group_arr_res['primkey'] ?>').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>
                      </label>
                      <input type="hidden" name="txt_page_group_<?php echo $page_group_arr_res['primkey'] ?>" id="txt_page_group_<?php echo $page_group_arr_res['primkey'] ?>" onkeyup="grid_page_manifest__updt_('<?php echo $page_group_arr_res['primkey'] ?>', 'page_group',this.value,'blackhole')" class="form-control" placeholder="Type new Page group"  value="<?php echo $page_group_arr_res["page_group"];?>" /> 
                      <select name="sel_page_group_<?php echo $page_group_arr_res['primkey'] ?>" id="sel_page_group_<?php echo $page_group_arr_res['primkey'] ?>" class="form-control" onchange="grid_page_manifest__updt_('<?php echo $page_group_arr_res['primkey'] ?>', 'page_group',this.value,'blackhole');document.getElementById('txt_page_group_<?php echo $page_group_arr_res['primkey'] ?>').value=this.value;">
                          <option  value="<?php echo $page_group_arr_res["page_group"];?>">
                           <?php if($page_group_arr_res["page_group"]==""){echo "Page group";}else{ echo $page_group_arr_res["page_group"];}?>
                          </option>
                          <?php
                          $dropdown_list_page_manifest__page_group_q = mgget_page_manifest_("*", "  group by page_group desc","l");    
                         foreach($dropdown_list_page_manifest__page_group_q['data'] as $dropdown_list_page_manifest__page_group_r ){?>
                         <option value="<?php echo $dropdown_list_page_manifest__page_group_r["page_group"] ?>" >
                          <?php echo $dropdown_list_page_manifest__page_group_r["page_group"] ?>
                         </option>
                         <?php }?>
                       </select>         
  					</div>         
  				</div>
                 </div>
                <?php } ?>
			  </details>
              <?php } ?>

            </div>
           <!--==============================  page group sections  ============================-->