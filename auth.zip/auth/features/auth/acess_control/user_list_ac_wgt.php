            <div class="col-md-12">                               
              <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                    <div class="col-md-3 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                    <div class="col-md-5 text-center"> User List </div>
                    <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>
                  </h5>
                 <div class="col-md-12 mt-5" id=""></div>              
                  <!-- End Title ribbon-->              	 
                   <input type="text" class="col-md-7 mb-2 ml-2 bg-transparent" placeholder="Search system admins" name="txt_system_users" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                   <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="qsystem_users_btn"><i class="fa fa-search"></i> Go</button>
                   <a href="<?php echo $accesseditor_admin ?>" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3"><i class="fa fa-refresh"></i> Refresh </a>       
                   <div class="col-md-12"></div>
               <?php $system_users_list_query=mgget_system_users("*", "$gft_system_users ", "l"); ?>
               <?php foreach($system_users_list_query['data'] as $system_users_list_res){ 
                $manifest_user_id=$system_users_list_res[$user_id_col];
                ?>
              <!-- Start side bar image card list -->
              <a href="<?php echo $accesseditor_admin ?>?system_users_uptoken=<?php echo base64_encode($system_users_list_res['primkey']) ?>" class="row  bg-white text-dark mb-3 pt-2 pb-2 justify-content-center m-0 col-md-12 rounded_big border-bottom shadow-sm mb-2">
                <div class="col-4 p-0">
                  <img src="<?php $card_photo_src="img/useravatar.png"; if($card_photo_src==''){ echo './img/logo.png';}else{ echo $card_photo_src;}?>" class=" " style="width:50px; height:50px; border-radius:50%;" id=""/>
                </div>
                <div class="col-8  text-left p-0" style="font-size:12px">
                  <div><b><?php echo $system_users_list_res[$username];?></b></div>
                  <div><b><?php echo $system_users_list_res[$session_user_mail];?></b></div>
                  <div class="border-top border_set pt-2"><span>Assigned roles: <?php echo mgcount_user_manifest_(" user_id='$manifest_user_id' ","superauth");?> </span></div>
                </div>
              </a>
              <!-- End side bar image card list-->
              <div class="col-md-12 p-1 "></div>
             <?php } ?>
            </div>