<div class="row justify-content-center m-0 p-0 col-md-12 skin_plasma">
  <div class="col-md-9 text-center row justify-content-center">
   <?php include('./features/auth/acess_control/pg_grp_ac_wgt.php'); ?>
  </div>
  <div class="col-md-4">
   <?php //include('./features/superauth/acess_control/user_list_ac_wgt.php'); ?>
  </div>
  <?php if(isset($_GET['system_users_uptoken'])){?>                            
  <div class="col-md-3">
  <?php //include('./features/superauth/acess_control/user_access_wgt.php');?>
  </div>
  <?php } ?> 
  <input type="hidden" name="txt_user_name" id="txt_user_name" class="form-control" placeholder="admin_nayme"  value="<?php echo getarr_val_($system_users_node, $username);?>" />
  <input type="hidden" name="txt_user_id" id="txt_user_id" class="form-control" placeholder="Admin id"  value="<?php echo getarr_val_($system_users_node, $user_id_col);?>" />
  <input type="hidden" name="txt_role_id" id="txt_role_id" class="form-control" placeholder="Role id"  value="<?php echo getarr_val_($user_manifest__node, "role_id");?>" />
  <input type="hidden" name="txt_role_name" id="txt_role_name" class="form-control" placeholder="Role name"  value="<?php echo getarr_val_($user_manifest__node, "role_name");?>" />

</div>
