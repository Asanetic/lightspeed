
    <div class="p-0 col-md-12">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">

       

       <?php  include("./hive_control/auth/user_bundle_role_functions/custom_list_query_line__srt_overall_user_functions_.php");?>
      </section>

    <!-- ================== End Feature Header Section ========================== -------->
    </div>
    
  <style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="col-md-12 bg-white border " style="margin-top: 0px; padding-bottom: 150px;">

<div class="row justify-content-end col-md-12 text-right pt-3 pb-3 data_list_section ml-0 mr-0 mb-3 border-bottom pr-0 pl-0" id="">

  <div class="col-md-6 p-0 text-left pt-3 hive_list_title">
    <h6 class="text-muted"><b> <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "User overall functions";}?> </b></h6>
  </div>

  <div class="col-md-6 p-0 text-right hive_list_search_tray">
    <input type="text" id="txt_user_bundle_role_functions" name="txt_user_bundle_role_functions" class="custom-search-input form-control" placeholder="Search in <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "User overall functions";}?>">
    <button class="custom-search-botton" id="quser_bundle_role_functions_btn" name="quser_bundle_role_functions_btn" type="submit"><i class="fa fa-search mr-1"></i> Go </button>  

  </div>                       
  <div class="col-md-12 pt-5 p-0 hive_list_search_divider" id=""></div>

  <div class="row justify-content-end m-0 p-0 col-md-12 hive_list_action_btn_tray" id="">
  
    <div class="col-md-5 d-none p-0 text-left hive_list_nav_left_ribbon" id="">
    </div>
    <div class="col-md-12 p-0 hive_list_nav_right_ribbon" id="">
      <!--<navgation_buttons/>-->
      <a href="<?php echo magic_basename(magic_current_url()) ?>" class="medium_btn border border_set btn-white hive_list_nav_refresh ml-3"><i class="fa fa-refresh mr-1 "></i> Refresh </a>   	 		      
    </div>    
      
  </div>
</div> 

      <div class="table-responsive  data-tables bg-white" style="margin-top: 0px; padding-bottom: 10px;">
       
       <table class="table table-hover  text-left" id="user_bundle_role_functions_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col"><b>Allowed access</b></th>

		   </tr>
           
	    </thead>
	    <tbody>
      <?php 
          $default_user_bundle_role_functions_add_new="overall_user_functions_profile";      
          $default_user_bundle_role_functions_profile="./overall_user_functions_profile.php";
          if(isset($user_bundle_role_functions_profile))
          {
          $default_user_bundle_role_functions_profile=$user_bundle_role_functions_profile;
          } 
          
          $default_user_bundle_role_functions_listing="./overall_user_functions_list.php";
          if(isset($user_bundle_role_functions_listing))
          {
          $default_user_bundle_role_functions_listing=$user_bundle_role_functions_listing;
          } 
          
          $default_user_bundle_role_functions_show_edit_btn="yes";
          if(isset($user_bundle_role_functions_show_edit_btn))
          {
          $default_user_bundle_role_functions_show_edit_btn=$user_bundle_role_functions_show_edit_btn;
          } 
      	
          echo drop_css();
        
          $i=0;

		  

          
          
        //<--outloop-dope-->
 
 	   if(!isset($user_bundle_role_functions__list_query_sorted))
       {
         $user_bundle_role_functions__list_query_sorted=$user_bundle_role_functions__list_query["data"];
       }
       
 	   foreach($user_bundle_role_functions__list_query_sorted as $listuser_bundle_role_functions_result)
       {
        
        $i++;
		
 
         
        
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_user_bundle_role_functions_show_edit_btn=="yes"){
           $edit_drop_link_control=magic_link($default_user_bundle_role_functions_profile.'?user_bundle_role_functions_uptoken='.base64_encode($listuser_bundle_role_functions_result["primkey"]).'', '<i class="fa fa-edit"></i> View More', '');;
           
           //$edit_drop_link=mosy_data_component("view_more:user_bundle_role_functions","component_control",$edit_drop_link_control);

           
          }
          
           //{{edit_drop_link}}
           if($default_user_bundle_role_functions_show_edit_btn=="yes")
           {
            $delete_drop_link_control='';
           //$delete_drop_link=mosy_data_component("delete:user_bundle_role_functions","component_control",$delete_drop_link_control);
            
            
		   }
	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr>
              <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
            
                         <td scope="col"><span title="<?php echo $listuser_bundle_role_functions_result["role_id"] ?>"><?php echo magic_strip_if($listuser_bundle_role_functions_result["_page_manifest__page_group_role_id"], 70, 70);?></span></td>

			</tr>
            
       <?php }?>

          <tr>
          <th></th>
          
                       <th scope="col"><b></b></th>

          </tr>
  <!--add_new_row_here-->
	    </tbody>
	    </table>
        
             <?php if($i==0){?>
            <h6 class="col-md-12 text-center p-3 mb-5 text-muted"><i class="fa fa-search"></i> Sorry, no user bundle role functions records found</h6>
            <div class="col-md-12 text-center mt-4">
            	<?php $search_user_bundle_role_functions_class="ml-0"; if($default_user_bundle_role_functions_show_edit_btn=="yes"){
                $search_user_bundle_role_functions_class="ml-4";
                ?>
            	
                <?php }?>
            	<a href="<?php echo  $default_user_bundle_role_functions_listing?>" class="medium_btn border border_set btn-primary data_list_section <?php echo $search_user_bundle_role_functions_class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
                <div class="col-md-12 pt-5 " id=""></div>                
            </div>
          <?php }?>
          <?php $user_bundle_role_functions_main__pagination_isle__=mosy_paginate_ui($user_bundle_role_functions__list_query["page_count"], $datalimit, "quser_bundle_role_functions_token",""); ?>
          <div class="col-md-12 data_list_section p-0 m-0  " id=""><?php echo $user_bundle_role_functions_main__pagination_isle__;?></div>

        </div>
        </div>        
       
    <!-- ================== Start Feature Footer Section ========================== -------->
    <section class="hive_footer_section">

     <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/auth/wrhs_auth_control.js?v=<?php echo date("dmyhisa") ?>"></script>

     <script type="text/javascript"></script>  
     
   <section  id="import_module"   >
    
       
     
    
   </section>
   
<!--mosy_page_script-->

    <input type="hidden" id="user_bundle_role_functions_uptoken" name="user_bundle_role_functions_uptoken" value="<?php echo base64_encode($user_bundle_role_functions_uptoken) ?>"/>
    </section>
     <!-- ================== End Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    