    <main role="main" class="container-fluid skin_plasma " style="min-height:100vh;">
      <div class="row justify-content-center pl-1 pr-1 pt-lg-5">
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
           <h3 class="col-md-12 text-center pt- 5 mt-5 padding_row"><?php echo daytime()." ".explode(" ", $first_name_logged)[0]; ?></h3>
           <h5 class="col-md-12 text-center pt-4">Welcome to <?php echo $mep_app_name ?></h5>
  			<h3 class="col-md-12 text-center">
  				<img src="<?php echo $mep_app_logo; ?>" class="pt-5 mt-lg-5 blink"   style="width:200px; height:auto;" id=""/>
  			</h3>              
              <h3 class="col-md-12 text-center"> Loading... </h3>                                         
           <!--<{ncgh}/>-->
      </div>

    </main>