<div class="p-0 col-md-12 text-center ">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">
      <?php  include("./hive_control/auth/client_list/custom_profile_query_line__srt_client_.php");?>
         
        </section>

       <!-- ================== Feature Header Section ========================== -------->
        <div class="col-md-12 rounded text-left p-0 mb-0 rounded shadow-sm bg-white  border" style="min-height:100vh;">   
          <div class="col-md-12 pr-lg-5 pl-lg-5 m-0">   
               
     <div class="col-md-12 pt-4 p-0 hive_profile_title_top" id=""></div>
     <h3 class="col-md-12 title_text text-left p-0 mb-0 pl-lg-3 hive_profile_title"><?php if(isset($_GET["client_list_uptoken"]) & !isset($_GET["mosy_page_title"])){ echo "Account / ".$client_list_node["client_name"]." / ".$client_list_node["username"]."";}elseif(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo " Create client account"; }?></h3>                                   
                 
              <div class="row justify-content-end m-0 p-0 col-md-12  p-3 bg-white hive_profile_navigation" id="">

                <div class="col-md-4 text-left p-0 hive_profile_nav_back_to_list_tray" id="">

                 <a href="./client_list.php" class="text-info hive_profile_nav_back_to_list"><i class="fa fa-arrow-left"></i> Back to list</a>

                </div>
                <div class="col-md-8 p-0 text-right hive_profile_nav_add_new_tray" id="">   
                    
              <?php if(isset($_GET["client_list_uptoken"])){ 
               $client_list_profile_uptoken_=$_GET["client_list_uptoken"];
               $client_list_del_redirect_page__=base64_encode("./client_list.php");
              ?>
              
              <!--<navgation_buttons/>--><a id="send_message_client_list__btn_"  class="medium_btn border border_set cpointer p-2 mb-3 ml-3  text-dark mosy_msdn" data-mosy_msdn="load_smartsend_iframe_('<?php echo $client_list_node['tel'];?>')"><i class="fa fa-send"></i> Send message </a>


               <?php echo mosy_data_component("client_list", "add_new", "client_profile:Create client account:plus-circle") ?>
              
              <?php  ?>

              <?php echo mosy_data_component("client_list", "delete", "client_profile:$client_list_del_redirect_page__:$client_list_profile_uptoken_") ?>
                
                <?php } ?>              
                </div>              
              </div>
               <div class="col-md-12 pt-4 p-0 hive_profile_navigation_divider" id=""></div>
              
              
         <div class="col-md-12 p-0 m-0" style="">
           <div class="row justify-content-center m-0 p-0 col-md-12 ">
                    
                <div class="col-md-12 row justify-content-left m-0  p-0">
                   <div class="col-md-12 row p-0 justify-content-center p-0 m-0">
    <div class="col-md-12 row justify-content-center p-0 m-0">
        <div class="col-md-12 row p-0 justify-content-center p-0 m-0">
            
        <div class="form-group col-md-8 hive_data_cell ">
          <label >Client Name</label>
          <input class="form-control" id="txt_client_name" name="txt_client_name" value="<?php echo getarr_val_($client_list_node, "client_name");?>" placeholder="Client Name" type="text" <?php echo mosy_data_component("client_list", "input","client_name")?>>
        </div>


         <div class="form-group col-md-8 hive_data_cell ">
           <label >Date Registered</label>
           <input class="form-control" id="txt_date_registered" name="txt_date_registered" value="<?php echo date_time_input(getarr_val_($client_list_node, "date_registered"), "full");?>" placeholder="Date Registered" type="datetime-local" <?php echo mosy_data_component("client_list", "input","date_registered")?>>
         </div>


        <div class="form-group col-md-8 hive_data_cell ">
          <label >Tel</label>
          <input class="form-control" id="txt_tel" name="txt_tel" value="<?php echo getarr_val_($client_list_node, "tel");?>" placeholder="Tel" type="text" <?php echo mosy_data_component("client_list", "input","tel")?>>
        </div>


        <div class="form-group col-md-8 hive_data_cell ">
          <label >Email</label>
          <input class="form-control" id="txt_email" name="txt_email" value="<?php echo getarr_val_($client_list_node, "email");?>" placeholder="Email" type="text" <?php echo mosy_data_component("client_list", "input","email")?>>
        </div>


        <div class="form-group col-md-8 hive_data_cell ">
          <label >GeTV Account number</label>
          <input class="form-control" id="txt_username" name="txt_username" value="<?php echo checkblank(getarr_val_($client_list_node,"username"), magic_post_curl_min($hive_routes["iptv"],"getv_number"))?>" placeholder="GeTV Account number" type="text" <?php echo mosy_data_component("client_list", "input","username")?>>
        </div>

 
               <div class="form-group col-md-8 hive_data_cell ">
                 <label >Device Type</label>
                  <select name="txt_device_type" id="txt_device_type" class="form-control" <?php echo mosy_data_component("client_list", "input","device_type")?>>
                      <option  value="<?php echo getarr_val_($client_list_node, "device_type");?>">
                       <?php if(getarr_val_($client_list_node, "device_type")==""){echo "Device Type";}else{ echo getarr_val_($client_list_node, "device_type");}?>
                      </option>
                          <option>Tv</option>
<option>Laptop / PC</option>
<option>Mobile</option>
<option>TV Box</option>

                   </select>
               </div>

 
               <div class="form-group col-md-8 hive_data_cell ">
                 <label >Operating System</label>
                  <select name="txt_operating_system" id="txt_operating_system" class="form-control" <?php echo mosy_data_component("client_list", "input","operating_system")?>>
                      <option  value="<?php echo getarr_val_($client_list_node, "operating_system");?>">
                       <?php if(getarr_val_($client_list_node, "operating_system")==""){echo "Operating System";}else{ echo getarr_val_($client_list_node, "operating_system");}?>
                      </option>
                          <option>Android</option>
<option>iOS (iPhone)</option>
<option>WebOS (LG Tv)</option>
<option>Windows</option>
<option>Tizen (Samsung)</option>

                   </select>
               </div>


        <div class="form-group col-md-8 hive_data_cell ">
          <label >Device Key</label>
          <input class="form-control" id="txt_device_key" name="txt_device_key" value="<?php echo getarr_val_($client_list_node, "device_key");?>" placeholder="Device Key" type="text" <?php echo mosy_data_component("client_list", "input","device_key")?>>
        </div>


        <div class="form-group col-md-8 hive_data_cell ">
          <label >Macaddress</label>
          <input class="form-control" id="txt_macaddress" name="txt_macaddress" value="<?php echo getarr_val_($client_list_node, "macaddress");?>" placeholder="Macaddress" type="text" <?php echo mosy_data_component("client_list", "input","macaddress")?>>
        </div>

                    
           <div class="form-group col-md-8 hive_data_cell  ">
             <div class="col-md-12 p-0 m-0 " id="">
              <label >Reffered By</label>
              <?php $_record_id=getarr_val_($client_list_node, "reffered_by"); if(isset($_GET["record_id"])){$_record_id=base64_decode($_GET["record_id"]);}?>
              <?php $mgq_affiliates_client_list_record_id_ = mosyget_("affiliates", "*", " where record_id='$_record_id' ", "l", "","auth")["data"];  ?>
              <?php 
                $mgq_affiliates_client_list_record_id_res =[];                 
                if(isset($mgq_affiliates_client_list_record_id_[0])){               
                  $mgq_affiliates_client_list_record_id_res=$mgq_affiliates_client_list_record_id_[0];                
                }
                
                $client_list_reffered_by_js_mini_dsf_=",_:".(base64_encode(mosy_dsf_custom_filter("affiliates", "without", "reffered_by:client_list", "js_dd_search")));

              ?>
                <input autocomplete="off" type="text" name="txt__affiliates_name_reffered_by_disp" id="txt__affiliates_name_reffered_by_disp" class="form-control hive_dcall_tup mosy_msdn" data-mosy_msdn="mosyauto_dropdown('txt__affiliates_name_reffered_by_disp')" data-hive_dcall_fun="hive_mosy_dsearch" data-hive_dcall_arg="affiliates:cs_dtray,txt__affiliates_name_reffered_by_disp,_affiliates_name_reffered_by_cstemp,_affiliates_name_reffered_by_data_isle<?php echo $client_list_reffered_by_js_mini_dsf_ ?>,primkey" class="form-control" placeholder="Search Reffered By"  value="<?php echo getarr_val_($mgq_affiliates_client_list_record_id_res, "name", "affiliates_affiliates_disp");?>" <?php echo mosy_data_component("client_list", "input","reffered_by")?> />
              <template id="_affiliates_name_reffered_by_cstemp">                             
                <div class=" row justify-content-center m-0 p-0 col-md-12">
                  <div class="col-md-12 border-bottom cpointer p-2 mosy_msdn " data-mosy_msdn="push_newval('txt_reffered_by','{{record_id}}');push_newval('txt__affiliates_name_reffered_by_disp','{{name}}');;mosyhide_elem('_affiliates_name_reffered_by_data_isle')">{{name}}</div>  
                </div>
              </template>
              <input type="hidden" name="txt_reffered_by" id="txt_reffered_by" value="<?php echo $_record_id;?>"/>
             </div>
           </div>
                    
           <div class="form-group col-md-8 hive_data_cell  ">
             <div class="col-md-12 p-0 m-0 " id="">
              <label >Active Service</label>
              <?php $_record_id=getarr_val_($client_list_node, "active_service"); if(isset($_GET["record_id"])){$_record_id=base64_decode($_GET["record_id"]);}?>
              <?php $mgq_services_client_list_record_id_ = mosyget_("services", "*", " where record_id='$_record_id' ", "l", "","auth")["data"];  ?>
              <?php 
                $mgq_services_client_list_record_id_res =[];                 
                if(isset($mgq_services_client_list_record_id_[0])){               
                  $mgq_services_client_list_record_id_res=$mgq_services_client_list_record_id_[0];                
                }
                
                $client_list_active_service_js_mini_dsf_=",_:".(base64_encode(mosy_dsf_custom_filter("services", "without", "active_service:client_list", "js_dd_search")));

              ?>
                <input autocomplete="off" type="text" name="txt__services_service_name_active_service_disp" id="txt__services_service_name_active_service_disp" class="form-control hive_dcall_tup mosy_msdn" data-mosy_msdn="mosyauto_dropdown('txt__services_service_name_active_service_disp')" data-hive_dcall_fun="hive_mosy_dsearch" data-hive_dcall_arg="services:cs_dtray,txt__services_service_name_active_service_disp,_services_service_name_active_service_cstemp,_services_service_name_active_service_data_isle<?php echo $client_list_active_service_js_mini_dsf_ ?>,primkey" class="form-control" placeholder="Search Active Service"  value="<?php echo getarr_val_($mgq_services_client_list_record_id_res, "service_name", "services_services_disp");?>" <?php echo mosy_data_component("client_list", "input","active_service")?> />
              <template id="_services_service_name_active_service_cstemp">                             
                <div class=" row justify-content-center m-0 p-0 col-md-12">
                  <div class="col-md-12 border-bottom cpointer p-2 mosy_msdn " data-mosy_msdn="push_newval('txt_active_service','{{record_id}}');push_newval('txt__services_service_name_active_service_disp','{{service_name}}');push_newval('txt_commission_amount','{{commission}}');push_newval('txt_package_amount','{{selling_price}}');mosyhide_elem('_services_service_name_active_service_data_isle')">{{service_name}}</div>  
                </div>
              </template>
              <input type="hidden" name="txt_active_service" id="txt_active_service" value="<?php echo $_record_id;?>"/>
             </div>
           </div>

         <div class="form-group col-md-8 hive_data_cell ">
           <label >Expiring On</label>
           <input class="form-control" id="txt_expiring_on" name="txt_expiring_on" value="<?php echo date_time_input(getarr_val_($client_list_node, "expiring_on"), "full");?>" placeholder="Expiring On" type="datetime-local" <?php echo mosy_data_component("client_list", "input","expiring_on")?>>
         </div>


        <div class="form-group col-md-8 hive_data_cell ">
          <label >Package Amount</label>
          <input class="form-control" id="txt_package_amount" name="txt_package_amount" value="<?php echo getarr_val_($client_list_node, "package_amount");?>" placeholder="Package Amount" type="text" <?php echo mosy_data_component("client_list", "input","package_amount")?>>
        </div>


        <div class="form-group col-md-8 hive_data_cell ">
          <label >Commission Amount</label>
          <input class="form-control" id="txt_commission_amount" name="txt_commission_amount" value="<?php echo getarr_val_($client_list_node, "commission_amount");?>" placeholder="Commission Amount" type="text" <?php echo mosy_data_component("client_list", "input","commission_amount")?>>
        </div>

 
               <div class="form-group col-md-8 hive_data_cell ">
                 <label >Account Status</label>
                  <select name="txt_account_status" id="txt_account_status" class="form-control" <?php echo mosy_data_component("client_list", "input","account_status")?>>
                      <option  value="<?php echo getarr_val_($client_list_node, "account_status");?>">
                       <?php if(getarr_val_($client_list_node, "account_status")==""){echo "Account Status";}else{ echo getarr_val_($client_list_node, "account_status");}?>
                      </option>
                          <option>Active</option>
<option>Expired</option>

                   </select>
               </div>


        <div class="form-group col-md-8 hive_data_cell ">
          <label >Client Group</label>
          <input class="form-control" id="txt_client_group" name="txt_client_group" value="<?php echo getarr_val_($client_list_node, "client_group");?>" placeholder="Client Group" type="text" <?php echo mosy_data_component("client_list", "input","client_group")?>>
        </div>


       		<div class="form-group col-md-8 hive_data_cell ">
              <label ><span>City</span> 
              <span  id="_toggle_on_city"   onclick="document.getElementById('txt_city').type='text';push_newval('txt_city', '');document.getElementById('sel_city').style.display='none';this.style.display='none';document.getElementById('_toggle_off_city').style.display='inline-block';" class="cpointer badge mosy_msdn"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              <span style="display:none" id="_toggle_off_city"   onclick="document.getElementById('txt_city').type='hidden';document.getElementById('sel_city').style.display='block';this.style.display='none';document.getElementById('_toggle_on_city').style.display='inline-block';if(document.getElementById('txt_city').value=='') document.getElementById('txt_city').value=document.getElementById('sel_city').value" class="cpointer badge mosy_msdn"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_city" id="txt_city" class="form-control" placeholder="Type new City"  value="<?php echo getarr_val_($client_list_node, "city");?>" /> 
              <select <?php echo mosy_data_component("client_list", "input","city")?> name="sel_city" id="sel_city" class="form-control" onchange="document.getElementById('txt_city').value=this.value;">
                  <option  value="<?php echo getarr_val_($client_list_node, "city");?>">
                   <?php if(getarr_val_($client_list_node, "city")==""){echo "City";}else{ echo getarr_val_($client_list_node, "city");}?>
                  </option>
                  <?php
                  $client_list_city_mini_dsf_=(mosy_dsf_custom_filter("client_list", "with", "city", "dd_group"));
                  
                  $dropdown_list_client_list_city_q = mosyget_("client_list", "*", "  $client_list_city_mini_dsf_ group by city ", "l", "","auth");    
                   foreach($dropdown_list_client_list_city_q["data"] as $dropdown_list_client_list_city_r){?>
                 <option value="<?php echo $dropdown_list_client_list_city_r["city"] ?>" >
                  <?php echo $dropdown_list_client_list_city_r["city"] ?>
                 </option>
                 <?php }?>
               </select>
          </div>
         


       		<div class="form-group col-md-8 hive_data_cell ">
              <label ><span>Town</span> 
              <span  id="_toggle_on_town"   onclick="document.getElementById('txt_town').type='text';push_newval('txt_town', '');document.getElementById('sel_town').style.display='none';this.style.display='none';document.getElementById('_toggle_off_town').style.display='inline-block';" class="cpointer badge mosy_msdn"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              <span style="display:none" id="_toggle_off_town"   onclick="document.getElementById('txt_town').type='hidden';document.getElementById('sel_town').style.display='block';this.style.display='none';document.getElementById('_toggle_on_town').style.display='inline-block';if(document.getElementById('txt_town').value=='') document.getElementById('txt_town').value=document.getElementById('sel_town').value" class="cpointer badge mosy_msdn"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_town" id="txt_town" class="form-control" placeholder="Type new Town"  value="<?php echo getarr_val_($client_list_node, "town");?>" /> 
              <select <?php echo mosy_data_component("client_list", "input","town")?> name="sel_town" id="sel_town" class="form-control" onchange="document.getElementById('txt_town').value=this.value;">
                  <option  value="<?php echo getarr_val_($client_list_node, "town");?>">
                   <?php if(getarr_val_($client_list_node, "town")==""){echo "Town";}else{ echo getarr_val_($client_list_node, "town");}?>
                  </option>
                  <?php
                  $client_list_town_mini_dsf_=(mosy_dsf_custom_filter("client_list", "with", "town", "dd_group"));
                  
                  $dropdown_list_client_list_town_q = mosyget_("client_list", "*", "  $client_list_town_mini_dsf_ group by town ", "l", "","auth");    
                   foreach($dropdown_list_client_list_town_q["data"] as $dropdown_list_client_list_town_r){?>
                 <option value="<?php echo $dropdown_list_client_list_town_r["town"] ?>" >
                  <?php echo $dropdown_list_client_list_town_r["town"] ?>
                 </option>
                 <?php }?>
               </select>
          </div>
         


                   <input class="form-control" id="txt_trial_service_date" name="txt_trial_service_date" value="<?php echo getarr_val_($client_list_node, "trial_service_date");?>" placeholder="Trial Service Date" type="hidden">


            <div class="form-group col-md-12 hive_data_cell   hive_data_cell ">
              <label >Remark</label>
              <textarea class="form-control" id="txt_remark" name="txt_remark" placeholder="Remark" style="min-height:200px;" <?php echo mosy_data_component("client_list", "input","remark")?> ><?php echo getarr_val_($client_list_node, "remark");?></textarea>
            </div>

        </div>
              
<div class="col-md-12 text-center">
  <?php echo mosy_data_component("client_list","cu","") ?>
</div>
    </div></div>
                   
                </div>
              </div>
          </div>
          </div>
          <div class="row justify-content-center m-0 pr-lg-4 pl-lg-4 pt-0 col-md-12" id="">        
            <!--<hive_mini_list/>-->    
    <section class="col-md-12 m-0 pl-lg-4 pr-lg-4" id="hive_lease_item_list">
        <?php if(isset($_GET["client_list_uptoken"])){?>
        <h5 class="col-md-12 text-left mt-3 mb-3 border-bottom pl-lg-1 text-muted"> Payment History </h5>
        
            <style type="text/css">
          .data_list_section {
                  display:none;
                }
        </style> 
        <?php $gft_transactions=" where BillRefNumber='".$client_list_node["username"]."' "; ?>
        
        <?php include("features/auth/transactions/custom_transactions_clientpayment_list_wgt.php"); ?>
        <?php }?>
      </section>      
          </div>
        </div>

    <!-- ================== Feature Footer Section ========================== -------->
    <section class="hive_footer_section">
    <input type="hidden" id="client_list_uptoken" name="client_list_uptoken" value="<?php echo base64_encode($client_list_uptoken) ?>"/>

    <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/auth/wrhs_auth_control.js?v=<?php echo date("dmyhisa") ?>"></script>
    </section>
    
   <section  id="sendmsg"   >
    
     
       <?php include($common_root.'/smartsend/smartsend_iframe.php'); ?>
      
     
    
   </section>
   
<!--mosy_page_script-->
    
     <!-- ================== Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    