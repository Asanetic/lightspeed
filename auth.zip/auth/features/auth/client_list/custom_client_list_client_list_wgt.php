
    <div class="p-0 col-md-12">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">

       

       <?php  include("./hive_control/auth/client_list/custom_list_query_line__srt_client_.php");?>
      </section>

    <!-- ================== End Feature Header Section ========================== -------->
    </div>
    
        <style>
        .table thead th {
        white-space: nowrap;
        }
      </style>
      <div class="col-md-12 bg-white border " style="margin-top: 0px; padding-bottom: 150px;">

        <div class="row justify-content-end col-md-12 text-right pt-3 pb-3 data_list_section ml-0 mr-0 mb-3 border-bottom pr-0 pl-0" id="">

          <div class="col-md-6 p-0 text-left pt-3 hive_list_title">
            <h6 class="text-muted"><b> <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Client list";}?> </b></h6>
          </div>
          
          <div class="col-md-6 p-0 text-right hive_list_search_tray">
            <input type="text" id="txt_client_list" name="txt_client_list" class="custom-search-input form-control" placeholder="Search in <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Client list";}?>">
            <button class="custom-search-botton" id="qclient_list_btn" name="qclient_list_btn" type="submit"><i class="fa fa-search mr-1"></i> Go </button>  
          </div> 
          
          <div class="col-md-12 pt-5 p-0 hive_list_search_divider" id=""></div>

          <div class="row justify-content-end m-0 p-0 col-md-12 hive_list_action_btn_tray" id="">
            <div class="col-md-5 d-none p-0 text-left hive_list_nav_left_ribbon" id="">
            </div>
            <div class="col-md-12 p-0 hive_list_nav_right_ribbon" id="">
              <!--<navgation_buttons/>--><a id="filter_registrations_date_client_list__btn_"  class="medium_btn border border_set cpointer p-2 mb-3 ml-3  text-dark mosy_msdn" data-mosy_msdn="filter_by_datetime('registration date','client_list?client_list_mosyfilter','date_registered')"><i class="fa fa-calendar"></i> Filter registrations date </a>
<a id="send_message__client_list__btn_"  class="medium_btn border border_set cpointer p-2 mb-3 ml-3  text-dark mosy_msdn" data-mosy_msdn="load_smartsend_iframe_('<?php  echo base64_encode(json_encode($_GET, true));?>','load_client_filters')"><i class="fa fa-send"></i> Send message  </a>

              <a href="<?php echo magic_basename(magic_current_url()) ?>" class="medium_btn border border_set btn-white hive_list_nav_refresh ml-3"><i class="fa fa-refresh mr-1 "></i> Refresh </a>   	 		       

<?php echo mosy_data_component("client_list", "add_new", "client_profile:Create client account:plus-circle") ?>
      
      
            </div>    
          </div>
        </div> 

      <div class="table-responsive  data-tables bg-white" style="margin-top: 0px; padding-bottom: 10px;">
                   
         <div class="text-left m-0 p-0 col-md-12">
              <div class="ml-2 cpointer badge btn_neo p-2 rounded badge-primary mb-3 tbl_print_btn" onclick="mosy_print_elem('client_list_print_card', '<?php echo $mosy_page_title?>', '')">
                <i class="fa fa-print "></i> Print List 
              </div>               
              <div class="cpointer p-2 ml-2 badge rounded border border_set badge-whte mb-3 tbl_print_to_excel_btn" onclick="mosy_print_excel('client_list_data_table', '<?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Client list";}?>')">
                <i class="fa fa-arrow-right "></i> Export to excel 
              </div>    
        </div>  
          <div class="col-md-12 " id="client_list_print_card">
       <table class="table table-hover  text-left" id="client_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col"><b>Client Name</b></th>
             <th scope="col"><b>Date Registered</b></th>
             <th scope="col"><b>Tel</b></th>
             <th scope="col"><b>Email</b></th>
             <th scope="col"><b>GeTV Account number</b></th>
             <th scope="col"><b>Device Type</b></th>
             <th scope="col"><b>Operating System</b></th>
             <th scope="col"><b>Device Key</b></th>
             <th scope="col"><b>Macaddress</b></th>
             <th scope="col"><b>Reffered By</b></th>
             <th scope="col"><b>Active Service</b></th>
             <th scope="col"><b>Expiring On</b></th>
             <th scope="col"><b>Package Amount</b></th>
             <th scope="col"><b>Commission Amount</b></th>
             <th scope="col"><b>Account Status</b></th>
             <th scope="col"><b>Client Group</b></th>
             <th scope="col"><b>City</b></th>
             <th scope="col"><b>Town</b></th>
             <th scope="col"><b>Trial Service Date</b></th>
             <th scope="col"><b>Remark</b></th>

		   </tr>
           
	    </thead>
	    <tbody>
      <?php 
          $default_client_list_add_new="client_profile";      
          $default_client_list_profile="./client_profile.php";
          if(isset($client_list_profile))
          {
          $default_client_list_profile=$client_list_profile;
          } 
          
          $default_client_list_listing="./client_list.php";
          if(isset($client_list_listing))
          {
          $default_client_list_listing=$client_list_listing;
          } 
          
          $default_client_list_show_edit_btn="yes";
          if(isset($client_list_show_edit_btn))
          {
          $default_client_list_show_edit_btn=$client_list_show_edit_btn;
          } 
      	
          echo drop_css();
        
          $i=0;

		  

          
          
        //<--outloop-dope-->
 
 	   if(!isset($client_list__list_query_sorted))
       {
         $client_list__list_query_sorted=$client_list__list_query["data"];
       }
       
 	   foreach($client_list__list_query_sorted as $listclient_list_result)
       {
        
        $i++;
		
 
         
        
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_client_list_show_edit_btn=="yes"){
           $edit_drop_link_control=magic_link($default_client_list_profile.'?client_list_uptoken='.base64_encode($listclient_list_result["primkey"]).'', '<i class="fa fa-edit"></i> View More', '');;
           
           $edit_drop_link=mosy_data_component("view_more:client_list","component_control",$edit_drop_link_control);

           
          }
          
           //{{edit_drop_link}}
           if($default_client_list_show_edit_btn=="yes")
           {
           $delete_drop_link_control=magic_link($default_client_list_profile.'?after_delete='.base64_encode(magic_current_url()).'&client_list_uptoken='.base64_encode($listclient_list_result["primkey"]).'&deleteclient_list','<i class="fa fa-trash"></i> Delete', '');
           $delete_drop_link=mosy_data_component("delete:client_list","component_control",$delete_drop_link_control);
            
            
		   }
	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr>
              <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
            
                         <td scope="col"><span title="<?php echo $listclient_list_result["client_name"] ?>"><?php echo magic_strip_if($listclient_list_result["client_name"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["date_registered"] ?>"><?php echo magic_strip_if($listclient_list_result["date_registered"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["tel"] ?>"><?php echo magic_strip_if($listclient_list_result["tel"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["email"] ?>"><?php echo magic_strip_if($listclient_list_result["email"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["username"] ?>"><?php echo magic_strip_if($listclient_list_result["username"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["device_type"] ?>"><?php echo magic_strip_if($listclient_list_result["device_type"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["operating_system"] ?>"><?php echo magic_strip_if($listclient_list_result["operating_system"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["device_key"] ?>"><?php echo magic_strip_if($listclient_list_result["device_key"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["macaddress"] ?>"><?php echo magic_strip_if($listclient_list_result["macaddress"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["reffered_by"] ?>"><?php echo magic_strip_if($listclient_list_result["_affiliates_name_reffered_by"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["active_service"] ?>"><?php echo magic_strip_if($listclient_list_result["_services_service_name_active_service"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["expiring_on"] ?>"><?php echo magic_strip_if($listclient_list_result["expiring_on"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["package_amount"] ?>"><?php echo magic_strip_if($listclient_list_result["package_amount"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["commission_amount"] ?>"><?php echo magic_strip_if($listclient_list_result["commission_amount"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["account_status"] ?>"><?php echo magic_strip_if($listclient_list_result["account_status"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["client_group"] ?>"><?php echo magic_strip_if($listclient_list_result["client_group"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["city"] ?>"><?php echo magic_strip_if($listclient_list_result["city"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["town"] ?>"><?php echo magic_strip_if($listclient_list_result["town"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listclient_list_result["trial_service_date"] ?>"><?php echo magic_strip_if($listclient_list_result["trial_service_date"], 70, 70);?></span></td>
             <td scope="col"><span><?php echo magic_strip_if($listclient_list_result["remark"],70, 70);?></span></td>

			</tr>
            
       <?php }?>

          <tr>
          <th></th>
          
                       <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>

          </tr>
          <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
             <?php if($i==0){?>
            <h6 class="col-md-12 text-center p-3 mb-5 text-muted"><i class="fa fa-search"></i> Sorry, no clients records found</h6>
            <div class="col-md-12 text-center mt-4">
            	<?php $search_client_list_class="ml-0"; if($default_client_list_show_edit_btn=="yes"){
                $search_client_list_class="ml-4";
                ?>
            	 
<?php echo mosy_data_component("client_list", "add_new", "".$default_client_list_add_new.":Create client account:plus-circle:medium_btn border border_set btn-white data_list_section ") ?>


                <?php }?>
            	<a href="<?php echo  $default_client_list_listing?>" class="medium_btn border border_set btn-primary data_list_section <?php echo $search_client_list_class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
                <div class="col-md-12 pt-5 " id=""></div>                
            </div>
          <?php }?>
          <?php $client_list_main__pagination_isle__=mosy_paginate_ui($client_list__list_query["page_count"], $datalimit, "qclient_list_token",""); ?>
          <div class="col-md-12 data_list_section p-0 m-0  " id=""><?php echo $client_list_main__pagination_isle__;?></div>

        </div>
        </div>        
       
    <!-- ================== Start Feature Footer Section ========================== -------->
    <section class="hive_footer_section">

     <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/auth/wrhs_auth_control.js?v=<?php echo date("dmyhisa") ?>"></script>

     <script type="text/javascript"></script>  
     
   <section  id="sendmsg"   >
    
     
       <?php include($common_root.'/smartsend/smartsend_iframe.php'); ?>
      
     
    
   </section>
   
<!--mosy_page_script-->

    <input type="hidden" id="client_list_uptoken" name="client_list_uptoken" value="<?php echo base64_encode($client_list_uptoken) ?>"/>
    </section>
     <!-- ================== End Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    