
    <div class="p-0 col-md-12">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">

       

       <?php  include("./hive_control/auth/system_users/custom_list_query_line__srt_system_users_w_roles_.php");?>
      </section>

    <!-- ================== End Feature Header Section ========================== -------->
    </div>
    
  <style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="col-md-12 bg-white border " style="margin-top: 0px; padding-bottom: 150px;">

<div class="row justify-content-end col-md-12 text-right pt-3 pb-3 data_list_section ml-0 mr-0 mb-3 border-bottom pr-0 pl-0" id="">

  <div class="col-md-6 p-0 text-left pt-3 hive_list_title">
    <h6 class="text-muted"><b> <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "System users";}?> </b></h6>
  </div>

  <div class="col-md-6 p-0 text-right hive_list_search_tray">
    <input type="text" id="txt_system_users" name="txt_system_users" class="custom-search-input form-control" placeholder="Search in <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "System users";}?>">
    <button class="custom-search-botton" id="qsystem_users_btn" name="qsystem_users_btn" type="submit"><i class="fa fa-search mr-1"></i> Go </button>  

  </div>                       
  <div class="col-md-12 pt-5 p-0 hive_list_search_divider" id=""></div>

  <div class="row justify-content-end m-0 p-0 col-md-12 hive_list_action_btn_tray" id="">
  
    <div class="col-md-5 d-none p-0 text-left hive_list_nav_left_ribbon" id="">
    </div>
    <div class="col-md-12 p-0 hive_list_nav_right_ribbon" id="">
      <!--<navgation_buttons/>--><a id="send_message__system_users__btn_"  class="medium_btn border border_set cpointer p-2 mb-3 ml-3  text-dark mosy_msdn" data-mosy_msdn="load_smartsend_iframe_('<?php  echo base64_encode(json_encode($_GET, true));?>','load_system_users_filters')"><i class="fa fa-send"></i> Send message  </a>
<a id="manage_use_roles_system_users__btn_"    href="system_role_bundles_list?system_users_custom=<?php echo base64_encode("na") ?>" class="medium_btn border border_set  p-2 mb-3 ml-3  text-dark"><i class="fa fa-users"></i> Manage use roles </a>

      <a href="<?php echo magic_basename(magic_current_url()) ?>" class="medium_btn border border_set btn-white hive_list_nav_refresh ml-3"><i class="fa fa-refresh mr-1 "></i> Refresh </a>   	 		       

<?php echo mosy_data_component("system_users", "add_new", "system_users_w_roles_profile:Create account:user-plus") ?>
      
      
    </div>    
      
  </div>
</div> 

      <div class="table-responsive  data-tables bg-white" style="margin-top: 0px; padding-bottom: 10px;">
       
       <table class="table table-hover  text-left" id="system_users_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col"><b>Fullnames</b></th>
             <th scope="col"><b>Email / Username</b></th>
             <th scope="col"><b>Contact / mobile</b></th>
             <th scope="col"><b>User role</b></th>
             <th scope="col"><b>Date created</b></th>

		   </tr>
           
	    </thead>
	    <tbody>
      <?php 
          $default_system_users_add_new="system_users_w_roles_profile";      
          $default_system_users_profile="./system_users_w_roles_profile.php";
          if(isset($system_users_profile))
          {
          $default_system_users_profile=$system_users_profile;
          } 
          
          $default_system_users_listing="./system_users_w_roles_list.php";
          if(isset($system_users_listing))
          {
          $default_system_users_listing=$system_users_listing;
          } 
          
          $default_system_users_show_edit_btn="yes";
          if(isset($system_users_show_edit_btn))
          {
          $default_system_users_show_edit_btn=$system_users_show_edit_btn;
          } 
      	
          echo drop_css();
        
          $i=0;

		  

          
          
        //<--outloop-dope-->
 
 	   if(!isset($system_users__list_query_sorted))
       {
         $system_users__list_query_sorted=$system_users__list_query["data"];
       }
       
 	   foreach($system_users__list_query_sorted as $listsystem_users_result)
       {
        
        $i++;
		
 
         
        
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_system_users_show_edit_btn=="yes"){
           $edit_drop_link_control=magic_link($default_system_users_profile.'?system_users_uptoken='.base64_encode($listsystem_users_result["primkey"]).'', '<i class="fa fa-edit"></i> View More', '');;
           
           $edit_drop_link=mosy_data_component("view_more:system_users","component_control",$edit_drop_link_control);

           
          }
          
           //{{edit_drop_link}}
           if($default_system_users_show_edit_btn=="yes")
           {
            $delete_drop_link_control=magic_link($default_system_users_profile.'?after_delete='.base64_encode(magic_current_url()).'&system_users_uptoken='.base64_encode($listsystem_users_result["primkey"]).'&deletesystem_users','<i class="fa fa-trash"></i> Delete', '');
           $delete_drop_link=mosy_data_component("delete:system_users","component_control",$delete_drop_link_control);
            
            
		   }
	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr>
              <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
            <td><?php
            
            $file_type_image=magic_if_image($listsystem_users_result["user_pic"]);
            if($file_type_image=='Yes' || $listsystem_users_result["user_pic"]==""){ ?>           
            <img src="<?php  $system_users_img=$listsystem_users_result["user_pic"];  if($system_users_img!=""){ echo $media_roots["auth"].$system_users_img;}else{ echo $mep_app_logo; }?>" class="shadow-sm" style="width:40px; height:40px; border-radius:20%;"/>
            <?php }else{?>
                <i class="fa fa-paperclip text-primary" style="font-size:40px;"></i>
            <?php }?>
            </td>
                         <td scope="col"><span title="<?php echo $listsystem_users_result["name"] ?>"><?php echo magic_strip_if($listsystem_users_result["name"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["email"] ?>"><?php echo magic_strip_if($listsystem_users_result["email"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["tel"] ?>"><?php echo magic_strip_if($listsystem_users_result["tel"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["ref_id"] ?>"><?php echo magic_strip_if($listsystem_users_result["_system_role_bundles_bundle_name_ref_id"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["regdate"] ?>"><?php echo magic_strip_if($listsystem_users_result["regdate"], 70, 70);?></span></td>

			</tr>
            
       <?php }?>

          <tr>
          <th></th>
          <th></th>
                       <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>
             <th scope="col"><b></b></th>

          </tr>
  <!--add_new_row_here-->
	    </tbody>
	    </table>
        
             <?php if($i==0){?>
            <h6 class="col-md-12 text-center p-3 mb-5 text-muted"><i class="fa fa-search"></i> Sorry, no system users records found</h6>
            <div class="col-md-12 text-center mt-4">
            	<?php $search_system_users_class="ml-0"; if($default_system_users_show_edit_btn=="yes"){
                $search_system_users_class="ml-4";
                ?>
            	 
<?php echo mosy_data_component("system_users", "add_new", "".$default_system_users_add_new.":Create account:user-plus:medium_btn border border_set btn-white data_list_section ") ?>


                <?php }?>
            	<a href="<?php echo  $default_system_users_listing?>" class="medium_btn border border_set btn-primary data_list_section <?php echo $search_system_users_class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
                <div class="col-md-12 pt-5 " id=""></div>                
            </div>
          <?php }?>
          <?php $system_users_main__pagination_isle__=mosy_paginate_ui($system_users__list_query["page_count"], $datalimit, "qsystem_users_token",""); ?>
          <div class="col-md-12 data_list_section p-0 m-0  " id=""><?php echo $system_users_main__pagination_isle__;?></div>

        </div>
        </div>        
       
    <!-- ================== Start Feature Footer Section ========================== -------->
    <section class="hive_footer_section">

     <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/auth/wrhs_auth_control.js?v=<?php echo date("dmyhisa") ?>"></script>

     <script type="text/javascript"></script>  
     
   <section  id="sys_users"   >
    
       <?php include($common_root.'/smartsend/smartsend_iframe.php'); ?> 
       
       
   </section>
   
<!--mosy_page_script-->

    <input type="hidden" id="system_users_uptoken" name="system_users_uptoken" value="<?php echo base64_encode($system_users_uptoken) ?>"/>
    </section>
     <!-- ================== End Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    