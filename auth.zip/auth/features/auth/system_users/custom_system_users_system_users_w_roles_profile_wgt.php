<div class="p-0 col-md-12 text-center ">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">
      <?php  include("./hive_control/auth/system_users/custom_profile_query_line__srt_system_users_w_roles_.php");?>
         
        </section>

       <!-- ================== Feature Header Section ========================== -------->
        <div class="col-md-12 bg-white p-0 m-0" style="min-height:100vh;">   
          <div class="col-md-12 m-0 p-0 ">   
                                                  
               
              
	<div class="col-md-12 rounded text-left pr-lg-5 pl-lg-5 mb-0">   
          <div class="col-md-12 pt-4 p-0" id=""></div>
			  
                        <div class="row justify-content-end mr-0 ml-0 mb-2 p-0 col-md-12  p-2 bg-white hive_profile_navigation " id="">

                          <div class="col-md-4 text-left p-0 hive_profile_nav_back_to_list_tray" id="">

                           <a href="./system_users_w_roles_list.php" class="hive_profile_nav_back_to_list text-info"><i class="fa fa-arrow-left"></i> Back to list</a>

                          </div>
                          <div class="col-md-8 p-0 text-right hive_profile_nav_add_new_tray " id="">   
                              
              <?php if(isset($_GET["system_users_uptoken"])){ 
               $system_users_profile_uptoken_=$_GET["system_users_uptoken"];
               $system_users_del_redirect_page__=base64_encode("./system_users_w_roles_list.php");
              ?>
              
              <!--<navgation_buttons/>--><a id="send_message_system_users__btn_"  class="medium_btn border border_set cpointer p-2 mb-3 ml-3  text-dark mosy_msdn" data-mosy_msdn="load_smartsend_iframe_('<?php echo $system_users_node['tel'];?>','load_users_list')"><i class="fa fa-send"></i> Send message </a>


               <?php echo mosy_data_component("system_users", "add_new", "system_users_w_roles_profile:Create account:user-plus") ?>
              
              <?php  ?>

              <?php echo mosy_data_component("system_users", "delete", "system_users_w_roles_profile:$system_users_del_redirect_page__:$system_users_profile_uptoken_") ?>
                
                <?php } ?>              
                          </div>              
                        </div>
                        
          
 		  <h3 class="col-md-12 title_text text-left p-0 mb-3 pl-lg-2"><?php echo getarr_val_($system_users_node, "name");?> Account</h3>                                           
                            
           <div class="col-md-12 p-0 m-0 " style="">
             <div class="row justify-content-center m-0 p-0 col-md-12 ">

               <div class="col-md-12 bg_w_img p-0 m-0  " style="background-image:url('<?php if(getarr_val_($system_users_node, "user_pic")=="") { echo $mep_app_logo;}else{ echo $media_roots["auth"].getarr_val_($system_users_node, "user_pic");}?>'); " >

                   <div class="col-md-12 p-0 m-0 " style="background-color:rgba(255,255,255,0.7)">
                <div class="col-md-12 p-0 text-center m-0 ">
                <div class="col-md-12 p-2 "><b></b></div>
                   <img src="<?php if(getarr_val_($system_users_node, "user_pic")=="") { echo $mep_app_logo;}else{ echo $media_roots["auth"].getarr_val_($system_users_node, "user_pic");}?>" onclick="mosy_img_pop(this.src, 'max-width:100%; max-height:70vh');glass_modal()" class=" cpointer" style="width:200px; height:200px; border-radius:50%;"/>
                                                                          
                
                <?php echo mosy_data_component("system_users","upload","user_pic")?>
                
              <?php if(isset($_GET['system_users_uptoken'])){?> 
              <input type="submit" name="btn_upload_system_users_user_pic" class="btn btn-primary mt-2 d-none" value="Upload">
              <?php }?>
              <input type="hidden" name="txt_old_user_pic" id="txt_old_user_pic" value="<?php echo getarr_val_($system_users_node,  "user_pic");?>">
                 </div>
                     
                  </div>
               </div>

               <div class="col-md-12 pt-5 p-0 " id=""></div>
               <div class="col-md-12 border-top border_set mb-4 " id=""></div>

               <div class="col-md-12 row justify-content-left m-0  p-0">

                  
        <div class="form-group col-md-4">
          <label >Fullnames</label>
          <input class="form-control" id="txt_name" name="txt_name" value="<?php echo getarr_val_($system_users_node, "name");?>" placeholder="Fullnames" type="text" <?php echo mosy_data_component("system_users", "input","name")?>>
        </div>

        <div class="form-group col-md-4">
          <label >Email / Username</label>
          <input class="form-control" id="txt_email" name="txt_email" value="<?php echo getarr_val_($system_users_node, "email");?>" placeholder="Email / Username" type="text" <?php echo mosy_data_component("system_users", "input","email")?>>
        </div>

        <div class="form-group col-md-4">
          <label >Contact / mobile</label>
          <input class="form-control" id="txt_tel" name="txt_tel" value="<?php echo getarr_val_($system_users_node, "tel");?>" placeholder="Contact / mobile" type="text" <?php echo mosy_data_component("system_users", "input","tel")?>>
        </div>
                    
           <div class="form-group col-md-4 ">
             <div class="col-md-12 p-0 m-0 " id="">
              <label >User role</label>
              <?php $_bundle_id=getarr_val_($system_users_node, "ref_id"); if(isset($_GET["bundle_id"])){$_bundle_id=base64_decode($_GET["bundle_id"]);}?>
              <?php $mgq_system_role_bundles_system_users_bundle_id_ = mosyget_("system_role_bundles", "*", " where bundle_id='$_bundle_id' ", "l", "","auth")["data"];  ?>
              <?php 
                $mgq_system_role_bundles_system_users_bundle_id_res =[];                 
                if(isset($mgq_system_role_bundles_system_users_bundle_id_[0])){               
                  $mgq_system_role_bundles_system_users_bundle_id_res=$mgq_system_role_bundles_system_users_bundle_id_[0];                
                }
                
                $system_users_ref_id_js_mini_dsf_=",_:".(base64_encode(mosy_dsf_custom_filter("system_role_bundles", "without", "ref_id:system_users", "js_dd_search")));

              ?>
                <input autocomplete="off" type="text" name="txt__system_role_bundles_bundle_name_ref_id_disp" id="txt__system_role_bundles_bundle_name_ref_id_disp" class="form-control hive_dcall_tup mosy_msdn" data-mosy_msdn="mosyauto_dropdown('txt__system_role_bundles_bundle_name_ref_id_disp')" data-hive_dcall_fun="hive_mosy_dsearch" data-hive_dcall_arg="system_role_bundles:cs_dtray,txt__system_role_bundles_bundle_name_ref_id_disp,_system_role_bundles_bundle_name_ref_id_cstemp,_system_role_bundles_bundle_name_ref_id_data_isle<?php echo $system_users_ref_id_js_mini_dsf_ ?>,primkey" class="form-control" placeholder="Search User role"  value="<?php echo getarr_val_($mgq_system_role_bundles_system_users_bundle_id_res, "bundle_name", "system_role_bundles_system_role_bundles_disp");?>" <?php echo mosy_data_component("system_users", "input","ref_id")?> />
              <template id="_system_role_bundles_bundle_name_ref_id_cstemp">                             
                <div class=" row justify-content-center m-0 p-0 col-md-12">
                  <div class="col-md-12 border-bottom cpointer p-2 mosy_msdn " data-mosy_msdn="push_newval('txt_ref_id','{{bundle_id}}');push_newval('txt__system_role_bundles_bundle_name_ref_id_disp','{{bundle_name}}');add_user_role();mosyhide_elem('_system_role_bundles_bundle_name_ref_id_data_isle')">{{bundle_name}}</div>  
                </div>
              </template>
              <input type="hidden" name="txt_ref_id" id="txt_ref_id" value="<?php echo $_bundle_id;?>"/>
             </div>
           </div>
                   <input class="form-control" id="txt_regdate" name="txt_regdate" value="<?php echo date_time_input(getarr_val_($system_users_node, "regdate"), "full");?>" placeholder="Date created" type="hidden">

                 <div class="form-group col-md-4">
                   <label >Login password</label>
                   <input class="form-control" id="txt_login_password" name="txt_login_password" value="<?php echo getarr_val_($system_users_node, "login_password");?>" placeholder="Login password" type="password" <?php echo mosy_data_component("system_users", "input","login_password")?>>
                   <input type="checkbox"  onclick="show_password('txt_login_password')"> <span class=""><em>Show Password</em></span>
                  </div>
              

        <div class="form-group col-md-4">
          <label >User ID</label>
          <input class="form-control" id="txt_user_no" name="txt_user_no" value="<?php echo getarr_val_($system_users_node, "user_no");?>" placeholder="User ID" type="text" <?php echo mosy_data_component("system_users", "input","user_no")?>>
        </div>


                  
      <div class="col-md-12 text-center">
      <?php echo mosy_data_component("system_users","cu","d-none") ?>

    </div>
  

               </div>
            </div>
          </div>
  </div>
          </div>
          <div class="row justify-content-center m-0 pr-lg-4 pl-lg-4 pt-0 col-md-12" id="">        
            <!--<hive_mini_list/>-->    
    <section class="col-md-12 m-0 pl-lg-4 pr-lg-4" id="hive_lease_item_list">
        <?php if(isset($_GET["system_users_uptoken"])){?>
        <h5 class="col-md-12 text-left mt-3 mb-3 border-bottom pl-lg-1 text-muted"> User roles </h5>
        
            <style type="text/css">
          .data_list_section {
                  display:none;
                }
        </style> 
        <?php $gft_user_bundle_role_functions=" where bundle_id='".$system_users_node["ref_id"]."' $user_bundle_role_functions_mdsf_qstr_without_where_ "; ?>
        
        <?php include("features/auth/user_bundle_role_functions/custom_user_bundle_role_functions_overall_user_functions_list_wgt.php"); ?>
        <?php }?>
      </section>      
          </div>
        </div>

    <!-- ================== Feature Footer Section ========================== -------->
    <section class="hive_footer_section">
    <input type="hidden" id="system_users_uptoken" name="system_users_uptoken" value="<?php echo base64_encode($system_users_uptoken) ?>"/>

    <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/auth/wrhs_auth_control.js?v=<?php echo date("dmyhisa") ?>"></script>
    </section>
    
   <section  id="sys_users"   >
    
       <?php include($common_root.'/smartsend/smartsend_iframe.php'); ?>    
       <input type="hidden" name="txt_user_id" id="txt_user_id" class="form-control" placeholder="User id"  value="<?php echo getarr_val_($system_users_node, "user_id");?>" />
       <script type="text/javascript">
         function add_user_role ()
         {
         
          if(get_newval("system_users_uptoken")!=""){
           magic_message("assigning role...", "dialog_box")
           mosy_form_data("mosy_form","assign_user_role","role_assigned")
           }
           
         }

         function role_assigned(serv_)
         {
          magic_message(serv_,"dialog_box")
          if(get_newval("system_users_uptoken")!=""){
          magic_message(serv_+`<hr>Refreshing user account`,"dialog_box")

          mosy_form_data("mosy_form","system_users_update_btn","mosy_refresh")
          }

         }
	   </script>
     
    
   </section>
   
<!--mosy_page_script-->
    
     <!-- ================== Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    