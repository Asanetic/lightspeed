<div class="row justify-content-center m-0 p-0 col-md-12 skin_plasma">
  <div class="col-md-5 p-0 m-0">

      <div class="main-wrapper login-body">
        <div class="login-wrapper">
          <div class="container">
            <div class="loginbox">
              <div class="login-right">
                <div class="login-right-wrap">
                <div class="col-md-12 py-3 text-center d-lg-block d-none">
                  <img src="<?php echo "./img/useravatar.png" //"$mep_app_logo"; ?>" class="" style="width:100px;" id=""/>
                </div>
                <div class="col-md-12 py-3 text-center d-lg-none">
                  <img src="<?php echo $mep_app_logo; ?>" class="" style="width:100px;" id=""/>
                </div>  
                <h1 class="col-md-12 mb-3"> <?php echo "Welcome to $mep_app_name" ?> </h1>

                <p class="account-subtitle ">Login to proceed</p>
                <form method="post">
                  <div class="form-group">
                      <label >Username </label>
                      <input class="form-control" required id="txt_username" name="txt_username" value="" placeholder="Enter your username" type="text">
                  </div>
                  <div class="form-group">
                      <label >Password </label>
                      <input class="form-control" required id="txt_password" name="txt_password" value="" placeholder="Enter password" type="password">
                  </div>
                  <div class="form-group">
                      <button class="btn btn-primary btn-block" name="btn_login" type="submit"> Login </button>
                  </div>            
                </form> 
                <?php if($show_reset_link=="yes"){?>
                <div class="text-center "><a href="<?php echo $reset_password_file ?>"> Reset Password </a></div>
                <?php } ?>
                <?php if($show_create_account=="yes"){?>
                <div class="text-center pt-4 text-dark"><a href="<?php echo $register_file ?>" class="text-dark "> <b>New Here? Create an account </b></a></div>
                <?php } ?>
                <div class="col-md-12 pt-3 p-0" id=""></div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    
  </div>
  <div class="col-md-7 order-1 order-lg-2 text-center p-0 m-0 bg_w_img d-none d-lg-block" style="background-image: url('<?php echo $login_bg_img ?>');">
      <div class="col-md-12 p-0 m-0 p-0 align-items-center d-flex" style="background-color: rgba(255, 255, 255, 0.6); height: 100vh;">
         <div class="login_logo_tray_  d-flex align-items-center ">                                  
          <div class="col-md-12 text-center">
              <img src="<?php echo $mep_app_logo; ?>" style="width: 150px; border-radius:20%" alt="Logo" />
              <h1 class="col-md-12 mt-3"><?php echo $mep_app_name ?></h1>
            </div>
          </div>

      </div>
  </div>
</div>