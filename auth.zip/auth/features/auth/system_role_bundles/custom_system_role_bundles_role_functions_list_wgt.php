
    <div class="p-0 col-md-12">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">

       <?php  include("./hive_control/auth/system_role_bundles/custom_profile_query_line__srt_role_functions_.php");?>

       <?php  include("./hive_control/auth/system_role_bundles/custom_list_query_line__srt_role_functions_.php");?>
      </section>

    <!-- ================== End Feature Header Section ========================== -------->
    </div>
     
 <!-- Start Table -->
    <div class="p-2 col-md-12 bg-white " id="">
        <div class="row justify-content-end col-md-12 text-right pt-3 pb-3 data_list_section ml-0 mr-0 mb-3 border-bottom pr-0 pl-0" id="">

          <div class="col-md-6 p-0 text-left pt-3 hive_list_title">
            <h6 class="text-muted"><b> <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Role functions";}?> </b></h6>
          </div>

          <div class="col-md-6 p-0 text-right hive_list_search_tray">
            <input type="text" id="txt_system_role_bundles" name="txt_system_role_bundles" class="custom-search-input form-control" placeholder="Search in <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Role functions";}?>">
            <button class="custom-search-botton" id="qsystem_role_bundles_btn" name="qsystem_role_bundles_btn" type="submit"><i class="fa fa-search mr-1"></i> Go </button>  

          </div>                       
          <div class="col-md-12 pt-5 p-0 hive_list_search_divider" id=""></div>

          <div class="row justify-content-end m-0 p-0 col-md-12 hive_list_action_btn_tray" id="">

            <div class="col-md-5 d-none p-0 text-left hive_list_nav_left_ribbon" id="">
            </div>
            <div class="col-md-12 p-0 hive_list_nav_right_ribbon" id="">
              <!--<navgation_buttons/>-->
              <a href="<?php echo magic_basename(magic_current_url()) ?>" class="medium_btn border border_set btn-white hive_list_nav_refresh "><i class="fa fa-refresh mr-1 "></i> Refresh </a>   	 		       

<?php echo mosy_data_component("system_role_bundles", "add_new", "role_functions_profile: Add new:plus-circle") ?>
      
      
            </div>    

          </div>
        </div>
        <style>
        .table thead tr th {
            min-width: 150px;
        }
        </style>
        <?php echo drop_css(); ?>
                  <div class="table-responsive data-tables" style="padding-bottom: 0px; max-height:80vh;overflow-y:auto;">
                  <table class="table table-hover text-left">
                    <thead class="text-uppercase sticky_scroll bg-white">
                      <tr>
                        <th scope="col">#</th>
                         							<th><b>HIVE SITE ID</b></th>
							<th><b>HIVE SITE NAME</b></th>

                       </tr>

					  		   
            <tr class="bg-light" id="system_role_bundles_jsgrid_edit_row" >
		      <th scope="col" class="pb-3">

               <?php echo mosy_data_component("system_role_bundles", "jsgrid_cu") ?>

              </th>              
            	      
                             <th scope="col"><b><input id="txt_hive_site_id" name="txt_hive_site_id"  value="<?php echo getarr_val_($system_role_bundles_node, "hive_site_id");?>" class="form-control" <?php echo mosy_data_component("system_role_bundles", "input","hive_site_id")?> /></b></th>
             <th scope="col"><b><input id="txt_hive_site_name" name="txt_hive_site_name"  value="<?php echo getarr_val_($system_role_bundles_node, "hive_site_name");?>" class="form-control" <?php echo mosy_data_component("system_role_bundles", "input","hive_site_name")?> /></b></th>

		   </tr>  
                       
                    </thead>
                      <tbody id="system_role_bundles_data_isle"><tr><th colspan="3"><h6 class="text-center p-3"><i class="fa fa-spinner fa-spin"></i> Working on it ... </h6></th></tr></tbody>
                        </tr>
                          <tr>
                          <th></th>
                          
                                       <th scope="col"><b id="js_sum_hive_site_id"></b></th>
             <th scope="col"><b id="js_sum_hive_site_name"></b></th>

                          </tr>                        
                  </table>
                        <!--- system_role_bundles data nodes -->
                        <table class="d-none">
                        <tbody id="system_role_bundles_tbl_nodes">
                         <tr class="cpointer ">
                           <td scope="col" ><b class="">{{row_count}}</b>                                                                               
                              <div class="table_cell_dropdown">
                              
                              
                                
                                 <div class="table_cell_dropbtn"></div>
                                 <div class="table_cell_dropdown-content">
                                   

            <?php echo mosy_data_component("system_role_bundles", "jsgrid_drop_down", "primkey:./role_functions_profile.php?system_role_bundles_uptoken='+btoa('{{primkey}}')+':") ?>

       
                               </div>
                              </div>
                           
                           </td>
                           
                          							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
                        
                        </tbody>
                        </table>
                                                <div class="row justify-content-center m-0 p-0 col-md-12" id="system_role_bundles_pagination_isle"></div>

                  </div>
                </div>
                <!-- End Table -->
                                      
                 <script type="text/javascript">

                         function load_system_role_bundles_(new_uptoken)
                         {
                             var tbl_col_span = 3
                               var response_fun='{"cbfun":"mosysql_process_jsondata","tbl":"system_role_bundles","_data_isle":"system_role_bundles_data_isle:'+tbl_col_span+'","_pagination_isle":"system_role_bundles_pagination_isle","_data_template":"system_role_bundles_tbl_nodes","_payload_str":"req","_pagination_prefix":"system_role_bundles_pagination_prefix_input","req_url":"gridmaster"}';

                           mosysql_jsondata("system_role_bundles"," <?php echo base64_encode("$gft_system_role_bundles order by primkey desc");?> ", response_fun, '<?php echo base64_encode($system_role_bundles_data_functions);?>',"*","l:system_role_bundles_page_no:"+mosy_limit, "system_role_bundles_pagination_prefix_input","auth")

                         }

                          document.addEventListener('DOMContentLoaded', function() {
                          // Your code here, it will run after the document has fully loaded

                            load_system_role_bundles_()
					
                            <?php if(isset($_GET['system_role_bundles_uptoken'])){?>                       
                                mosytoggle_addclass("mp_js_system_role_bundles_insert_btn","d-none")
                                mosytoggle_remclass("mp_js_system_role_bundles_update_btn","d-none")
                                mosytoggle_remclass("mp_js_system_role_bundles_clone_btn","d-none")
                            <?php } ?>                            

                          });

					function _madd_system_role_bundles_()
                    {
                      magic_message('<i class="fa fa-spinner fa-spin"></i> Sending create request...', 'dialog_box')
                      mosy_livecu("system_role_bundles_insert_btn", "_system_role_bundles_dsaved_:Added")
                    }

					function _msave_system_role_bundles_()
                    {
                      magic_message('<i class="fa fa-spinner fa-spin"></i> Sending update request...', 'dialog_box')
                      mosy_livecu("system_role_bundles_update_btn", "_system_role_bundles_dsaved_:Updated")
                    }


					function _system_role_bundles_dsaved_(new_uptoken, request_type="")
                    {
                    
                      ////
                      
                      if (!isNaN(new_uptoken) && isFinite(new_uptoken)) {

                      push_html('dialog_box')
                      
                      create_msnack_box_('<i class="fa fa-check-circle"></i> Record '+request_type+' successfully')
                      load_system_role_bundles_()     
                      
                      mginitialize__dsql("system_role_bundles", new_uptoken)
                      push_newval("system_role_bundles_uptoken", btoa(new_uptoken))
                        
                      if(request_type=="Added")
                      {
                        mosytoggle_addclass("mp_js_system_role_bundles_insert_btn","d-none")
                        mosytoggle_remclass("mp_js_system_role_bundles_update_btn","d-none")
                        mosytoggle_remclass("mp_js_system_role_bundles_clone_btn","d-none")
                      }
                      
                      } else {
                          magic_message(`<i class="fa fa-times-circle text-danger"></i> ${new_uptoken}`, "dialog_box")
                      }                      
                      
                    }
                    
                      function _minit_system_role_bundles_(new_uptoken)
                      {

                         push_newval("system_role_bundles_uptoken", btoa(new_uptoken))
                         mginitialize__dsql("system_role_bundles", new_uptoken,"",'<?php echo base64_encode($system_role_bundles_data_functions);?>')
                         mosytoggle_addclass("mp_js_system_role_bundles_insert_btn","d-none")
                         mosytoggle_remclass("mp_js_system_role_bundles_update_btn","d-none")
                         mosytoggle_remclass("mp_js_system_role_bundles_clone_btn","d-none")                        
                      }
                      
                      function create_msnack_box_(message){

                      mosy_snack_wgt(message, "top", "snack_box", "200px", "table_alert_toast", '<?php echo $btn_txt ?>',  '<?php echo $btn_bg ?>', '');
                      mosytoggle_class('table_alert_toast', 'show');

                        setTimeout(function(){ 

                         push_html('snack_box', '');                                          

                          }, 3000);
                      }

					 function _mdrop_system_role_bundles(qkey)
                     {
                        
                       magic_message('<i class="fa fa-spinner fa-spin"></i> Sending update request...', 'dialog_box')
                       var drop_payload="mosyajax_get('conf_deletesystem_role_bundles&system_role_bundles_uptoken="+(qkey)+"', '_system_role_bundles_dsaved_:Deleted')";

                       magic_yes_no_alert('Delete record?', 'dialog_box', drop_payload, 'blackhole')
                     }
                    </script> 

                  
    <!-- ================== Start Feature Footer Section ========================== -------->
    <section class="hive_footer_section">

     <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/auth/wrhs_auth_control.js?v=<?php echo date("dmyhisa") ?>"></script>

     <script type="text/javascript"></script>  
     
   <section  id="import_module"   >
    
       
     
    
   </section>
   
<!--mosy_page_script-->

    <input type="hidden" id="system_role_bundles_uptoken" name="system_role_bundles_uptoken" value="<?php echo base64_encode($system_role_bundles_uptoken) ?>"/>
    </section>
     <!-- ================== End Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    