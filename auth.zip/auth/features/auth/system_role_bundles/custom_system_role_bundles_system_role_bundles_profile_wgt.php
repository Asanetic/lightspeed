<div class="p-0 col-md-12 text-center ">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">
      <?php  include("./hive_control/auth/system_role_bundles/custom_profile_query_line__srt_system_role_bundles_.php");?>
         
        </section>

       <!-- ================== Feature Header Section ========================== -------->
        <div class="col-md-12 rounded text-left p-0 mb-0 rounded shadow-sm bg-white  border" style="min-height:100vh;">   
          <div class="col-md-12 pr-lg-5 pl-lg-5 m-0">   
               
     <div class="col-md-12 pt-4 p-0 hive_profile_title_top" id=""></div>
     <h3 class="col-md-12 title_text text-left p-0 mb-0 pl-lg-3 hive_profile_title"><?php if(isset($_GET["system_role_bundles_uptoken"]) & !isset($_GET["mosy_page_title"])){ echo "System role / ".$system_role_bundles_node["bundle_name"]."";}elseif(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "  Create system role"; }?></h3>                                   
                 
              <div class="row justify-content-end m-0 p-0 col-md-12  p-3 bg-white hive_profile_navigation" id="">

                <div class="col-md-4 text-left p-0 hive_profile_nav_back_to_list_tray" id="">

                 <a href="./system_role_bundles_list.php" class="text-info hive_profile_nav_back_to_list"><i class="fa fa-arrow-left"></i> Back to list</a>

                </div>
                <div class="col-md-8 p-0 text-right hive_profile_nav_add_new_tray" id="">   
                    
              <?php if(isset($_GET["system_role_bundles_uptoken"])){ 
               $system_role_bundles_profile_uptoken_=$_GET["system_role_bundles_uptoken"];
               $system_role_bundles_del_redirect_page__=base64_encode("./system_role_bundles_list.php");
              ?>
              
              <!--<navgation_buttons/>-->

               <?php echo mosy_data_component("system_role_bundles", "add_new", "system_role_bundles_profile: Create system role:plus-circle") ?>
              
              <?php  ?>

              <?php echo mosy_data_component("system_role_bundles", "delete", "system_role_bundles_profile:$system_role_bundles_del_redirect_page__:$system_role_bundles_profile_uptoken_") ?>
                
                <?php } ?>              
                </div>              
              </div>
               <div class="col-md-12 pt-4 p-0 hive_profile_navigation_divider" id=""></div>
              
              
         <div class="col-md-12 p-0 m-0" style="">
           <div class="row justify-content-center m-0 p-0 col-md-12 ">
                    
                <div class="col-md-12 row justify-content-left m-0  p-0">
                   
        <div class="form-group col-md-12">
          <label >Role name</label>
          <input class="form-control" id="txt_bundle_name" name="txt_bundle_name" value="<?php echo getarr_val_($system_role_bundles_node, "bundle_name");?>" placeholder="Role name" type="text" <?php echo mosy_data_component("system_role_bundles", "input","bundle_name")?>>
        </div>

            <div class="form-group col-md-12 hive_data_cell   hive_data_cell ">
              <label >Description / details</label>
              <textarea class="form-control" id="txt_remark" name="txt_remark" placeholder="Description / details" style="min-height:200px;" <?php echo mosy_data_component("system_role_bundles", "input","remark")?> ><?php echo getarr_val_($system_role_bundles_node, "remark");?></textarea>
            </div>

                   
      <div class="col-md-12 text-center">
      <?php echo mosy_data_component("system_role_bundles","cu","d-none") ?>

    </div>
  
                </div>
              </div>
          </div>
          </div>
          <div class="row justify-content-center m-0 pr-lg-4 pl-lg-4 pt-0 col-md-12" id="">        
            <!--<hive_mini_list/>-->    
    <section class="col-md-12 m-0 pl-lg-4 pr-lg-4" id="hive_lease_item_list">
        <?php if(isset($_GET["system_role_bundles_uptoken"])){?>
        <h5 class="col-md-12 text-left mt-3 mb-3 border-bottom pl-lg-1 text-muted"> Role functions </h5>
        
            <style type="text/css">
          .data_list_section {
                  display:none;
                }
        </style> 
        <?php $gft_user_bundle_role_functions="where bundle_id='".$system_role_bundles_node["bundle_id"]."' "; ?>
        
        <?php include("features/auth/user_bundle_role_functions/custom_user_bundle_role_functions_role_functions_list_wgt.php"); ?>
        <?php }?>
      </section>      
          </div>
        </div>

    <!-- ================== Feature Footer Section ========================== -------->
    <section class="hive_footer_section">
    <input type="hidden" id="system_role_bundles_uptoken" name="system_role_bundles_uptoken" value="<?php echo base64_encode($system_role_bundles_uptoken) ?>"/>

    <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/auth/wrhs_auth_control.js?v=<?php echo date("dmyhisa") ?>"></script>
    </section>
    
   <section  id="import_module"   >
    
     <input type="hidden" name="txt_bundle_id" id="txt_bundle_id" class="form-control" placeholder="Bundle id"  value="<?php echo checkblank(getarr_val_($system_role_bundles_node, "bundle_id"),magic_random_str(10));?>" />
     
    
   </section>
   
<!--mosy_page_script-->
    
     <!-- ================== Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    