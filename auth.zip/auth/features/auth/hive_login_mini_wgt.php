<style type="text/css">
.form-control{
 background-color:transparent!important;
}

.loginbox {
    max-width: 100%!important;

}
</style>
<div class="row justify-content-center m-0 p-0 col-md-12">
  <div class="col-md-12 m-0 p-0  " >

      <div class="main-wrapper login-body" >
        <div class="login-wrapper  m-0 p-1 p-lg-0">
        <div class=" m-0 p-lg-4 row justify-content-center col-md-12">
          <div class=" m-0 p-1 p-lg-0  row justify-content-center col-md-8 shadow ">
            
            <div class="col-md-6  bg_w_img" style="background-image: url('<?php echo $login_bg_img ?>');"> </div>
                 <div class="col-md-6 p-0 m-0 " id="">
                  <div class="loginbox  bg-white p-0 m-0">
                    <div class="login-right text-dark">
                      <div class="login-right-wrap">
                      <div class="col-md-12 py-3 text-center">
                        <img src="<?php echo $mep_app_logo; ?>" class="" style="width:100px;" id=""/>
                      </div>  
                      <h1 class="col-md-12 mb-3"> <?php echo "Welcome to $mep_app_name" ?> </h1>

                      <p class="account-subtitle text-dark ">Login to proceed</p>
                      <form method="post">
                        <div class="form-group">
                            <label >Username </label>
                            <input class="form-control border-top-0 border-left-0 border-right-0 border-bottom border-dark text-dark" required id="txt_username" name="txt_username" value="" placeholder="Enter your username" type="text">
                        </div>
                        <div class="form-group">
                            <label >Password </label>
                            <input class="form-control border-top-0 border-left-0 border-right-0 border-bottom border-dark text-dark" required id="txt_password" name="txt_password" value="" placeholder="Enter password" type="password">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-block" name="btn_login" type="submit"> Login </button>
                        </div>            
                      </form> 
                      <?php if($show_reset_link=="yes"){?>
                      <div class="text-center "><a href="<?php echo $reset_password_file ?>"> Reset Password </a></div>
                      <?php } ?>
                      <?php if($show_create_account=="yes"){?>
                      <div class="text-center pt-4 text-light"><a href="<?php echo $register_file ?>" class="text-dark"> <b>New Here? Create an account </b></a></div>
                      <?php } ?>
                      <div class="col-md-12 pt-3 p-0" id=""></div>

                      </div>
                    </div>
                  </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    
  </div>

</div>