
    <div class="p-0 col-md-12">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">

       <?php  include("./hive_control/superauth/user_bundle_role_functions/custom_profile_query_line__srt_role_functions_.php");?>

       <?php  include("./hive_control/superauth/user_bundle_role_functions/custom_list_query_line__srt_role_functions_.php");?>
      </section>

    <!-- ================== End Feature Header Section ========================== -------->
    </div>
     
 <!-- Start Table -->
    <div class="p-2 col-md-12 bg-white " id="">
        <div class="row justify-content-end col-md-12 text-right pt-3 pb-3 data_list_section ml-0 mr-0 mb-3 border-bottom pr-0 pl-0" id="">

          <div class="col-md-6 p-0 text-left pt-3 hive_list_title">
            <h6 class="text-muted"><b> <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Role functions";}?> </b></h6>
          </div>

          <div class="col-md-6 p-0 text-right hive_list_search_tray">
            <input type="text" id="txt_user_bundle_role_functions" name="txt_user_bundle_role_functions" class="custom-search-input form-control" placeholder="Search in <?php if(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Role functions";}?>">
            <button class="custom-search-botton" id="quser_bundle_role_functions_btn" name="quser_bundle_role_functions_btn" type="submit"><i class="fa fa-search mr-1"></i> Go </button>  

          </div>                       
          <div class="col-md-12 pt-5 p-0 hive_list_search_divider" id=""></div>

          <div class="row justify-content-end m-0 p-0 col-md-12 hive_list_action_btn_tray" id="">

            <div class="col-md-5 d-none p-0 text-left hive_list_nav_left_ribbon" id="">
            </div>
            <div class="col-md-12 p-0 hive_list_nav_right_ribbon" id="">
              <!--<navgation_buttons/>-->
              <a href="<?php echo magic_basename(magic_current_url()) ?>" class="medium_btn border border_set btn-white hive_list_nav_refresh "><i class="fa fa-refresh mr-1 "></i> Refresh </a>   	 		       
      <a href="role_functions_profile" class="medium_btn border border_set btn-primary ml-3 hive_list_nav_new_btn"><i class="fa fa-plus-circle"></i>  Add new</a>
      
      
            </div>    

          </div>
        </div>
        <style>
        .table thead tr th {
            min-width: 150px;
        }
        </style>
        <?php echo drop_css(); ?>
                  <div class="table-responsive data-tables" style="padding-bottom: 0px; max-height:80vh;overflow-y:auto;">
                  <table class="table table-hover text-left">
                    <thead class="text-uppercase sticky_scroll bg-white">
                      <tr>
                        <th scope="col">#</th>
                         							<th><b>ALLOWED ACCESS</b></th>

                       </tr>

					  		   
            <tr class="bg-light" id="user_bundle_role_functions_jsgrid_edit_row" >
		      <th scope="col" class="pb-3">
             <button type="button" id="mp_js_user_bundle_role_functions_insert_btn" style="font-size:12px;" name="mp_js_user_bundle_role_functions_insert_btn" class="medium_btn border border_set btn-primary hive_list_nav_new mosy_msdn" data-mosy_msdn="_madd_user_bundle_role_functions_()" >
              <i class="fa fa-arrow-down"></i> Add new 
              </button>                             
                 <button type="button" id="mp_js_user_bundle_role_functions_clone_btn" style="font-size:12px;" name="mp_js_user_bundle_role_functions_clone_btn" class="medium_btn border border_set bg-whitehive_list_nav_new d-none mosy_msdn" data-mosy_msdn="_madd_user_bundle_role_functions_()">
              <i class="fa fa-arrow-down"></i> Clone 
              </button>

                  <button type="button" id="mp_js_user_bundle_role_functions_update_btn" style="font-size:12px;" name="mp_js_user_bundle_role_functions_update_btn" class="medium_btn border border_set ml-lg-3  btn-primary hive_list_nav_new mosy_msdn d-none" data-mosy_msdn="_msave_user_bundle_role_functions_()" > 
                    <i class="fa fa-save"></i> Update 
                  </button> 
              </th>              
            	      
                             <th scope="col"><b>
             <div class="col-md-12 p-0 m-0 " id="">
              <label ></label>
              <?php $_page_group=getarr_val_($user_bundle_role_functions_node, "role_id"); if(isset($_GET["page_group"])){$_page_group=base64_decode($_GET["page_group"]);}?>
              <?php $mgq_page_manifest__user_bundle_role_functions_page_group_ = mosyget_("page_manifest_", "*", " where page_group='$_page_group' ", "l", "","superauth")["data"];  ?>
              <?php 
                $mgq_page_manifest__user_bundle_role_functions_page_group_res =[];                 
                if(isset($mgq_page_manifest__user_bundle_role_functions_page_group_[0])){               
                  $mgq_page_manifest__user_bundle_role_functions_page_group_res=$mgq_page_manifest__user_bundle_role_functions_page_group_[0];                
                }
              ?>
                <input autocomplete="off" type="text" name="txt__page_manifest__page_group_role_id_disp" id="txt__page_manifest__page_group_role_id_disp" class="form-control hive_dcall_tup  mosy_msdn" data-mosy_msdn="mosyauto_dropdown('txt__page_manifest__page_group_role_id_disp')" data-hive_dcall_fun="hive_mosy_dsearch" data-hive_dcall_arg="page_manifest_:cs_dtray,txt__page_manifest__page_group_role_id_disp,_page_manifest__page_group_role_id_cstemp,_page_manifest__page_group_role_id_data_isle, _:<?php echo base64_encode(" group by page_group ")?>" class="form-control" placeholder="Search Allowed access"  value="<?php echo getarr_val_($mgq_page_manifest__user_bundle_role_functions_page_group_res, "page_group", "page_manifest__page_manifest__disp");?>" />
              <template id="_page_manifest__page_group_role_id_cstemp">                             
                <div data-mosy_msdn="push_newval('txt_role_id','{{page_group}}');push_newval('txt__page_manifest__page_group_role_id_disp','{{page_group}}');;mosyhide_elem('_page_manifest__page_group_role_id_data_isle')" class="mosy_msdn row justify-content-center m-0 p-0 col-md-12">
                  <div class="col-md-12 border-bottom cpointer p-2">{{page_group}}</div>  
                </div>
              </template>
              <input type="hidden" name="txt_role_id" id="txt_role_id" value="<?php echo $_page_group;?>"/>
             </div>             
          </b></th>

		   </tr>  
                       
                    </thead>
                      <tbody id="user_bundle_role_functions_data_isle"><tr><th colspan="2"><h6 class="text-center p-3"><i class="fa fa-spinner fa-spin"></i> Working on it ... </h6></th></tr></tbody>
                        </tr>
                          <tr>
                          <th></th>
                          
                                       <th scope="col"><b id="js_sum_role_id"></b></th>

                          </tr>                        
                  </table>
                        <!--- user_bundle_role_functions data nodes -->
                        <table class="d-none">
                        <tbody id="user_bundle_role_functions_tbl_nodes">
                         <tr class="cpointer ">
                           <td scope="col" ><b class="">{{row_count}}</b>                                                                               
                              <div class="table_cell_dropdown">
                              
                              
                                
                                 <div class="table_cell_dropbtn"></div>
                                 <div class="table_cell_dropdown-content">
                                                                     
       <span class="mosy_msdn"  data-mosy_msdn="_minit_user_bundle_role_functions_('{{primkey}}')"><i class="fa fa-edit"></i> Edit </span>
              
       <span class="mosy_msdn"  data-mosy_msdn="_mdrop_user_bundle_role_functions(btoa('{{primkey}}'))"><i class="fa fa-trash"></i> Delete </span>
                               </div>
                              </div>
                           
                           </td>
                           
                          							<td>{{_page_manifest__page_group_role_id}}</td>
                        
                        </tbody>
                        </table>
                                                <div class="row justify-content-center m-0 p-0 col-md-12" id="user_bundle_role_functions_pagination_isle"></div>

                  </div>
                </div>
                <!-- End Table -->
                                      
                 <script type="text/javascript">

                         function load_user_bundle_role_functions_(new_uptoken)
                         {
                             var tbl_col_span = 2
                               var response_fun='{"cbfun":"mosysql_process_jsondata","tbl":"user_bundle_role_functions","_data_isle":"user_bundle_role_functions_data_isle:'+tbl_col_span+'","_pagination_isle":"user_bundle_role_functions_pagination_isle","_data_template":"user_bundle_role_functions_tbl_nodes","_payload_str":"req","_pagination_prefix":"user_bundle_role_functions_pagination_prefix_input","req_url":"gridmaster"}';

                           mosysql_jsondata("user_bundle_role_functions"," <?php echo base64_encode(" $gft_user_bundle_role_functions  order by primkey desc ");?> ", response_fun, '<?php echo base64_encode($user_bundle_role_functions_data_functions);?>',"*","l:user_bundle_role_functions_page_no:"+mosy_limit, "user_bundle_role_functions_pagination_prefix_input","superauth")

                         }

                          document.addEventListener('DOMContentLoaded', function() {
                          // Your code here, it will run after the document has fully loaded

                            load_user_bundle_role_functions_()
					
                            <?php if(isset($_GET['user_bundle_role_functions_uptoken'])){?>                       
                                mosytoggle_addclass("mp_js_user_bundle_role_functions_insert_btn","d-none")
                                mosytoggle_remclass("mp_js_user_bundle_role_functions_update_btn","d-none")
                                mosytoggle_remclass("mp_js_user_bundle_role_functions_clone_btn","d-none")
                            <?php } ?>                            

                          });

					function _madd_user_bundle_role_functions_()
                    {
                      magic_message('<i class="fa fa-spinner fa-spin"></i> Sending create request...', 'dialog_box')
                      mosy_livecu("user_bundle_role_functions_insert_btn", "_user_bundle_role_functions_dsaved_:Added")
                    }

					function _msave_user_bundle_role_functions_()
                    {
                      magic_message('<i class="fa fa-spinner fa-spin"></i> Sending update request...', 'dialog_box')
                      mosy_livecu("user_bundle_role_functions_update_btn", "_user_bundle_role_functions_dsaved_:Updated")
                    }


					function _user_bundle_role_functions_dsaved_(new_uptoken, request_type="")
                    {
                    
                      ////
                      
                      if (!isNaN(new_uptoken) && isFinite(new_uptoken)) {

                      push_html('dialog_box')
                      
                      create_msnack_box_('<i class="fa fa-check-circle"></i> Record '+request_type+' successfully')
                      load_user_bundle_role_functions_()     
                      
                      mginitialize__dsql("user_bundle_role_functions", new_uptoken)
                      push_newval("user_bundle_role_functions_uptoken", btoa(new_uptoken))
                        
                      if(request_type=="Added")
                      {
                        mosytoggle_addclass("mp_js_user_bundle_role_functions_insert_btn","d-none")
                        mosytoggle_remclass("mp_js_user_bundle_role_functions_update_btn","d-none")
                        mosytoggle_remclass("mp_js_user_bundle_role_functions_clone_btn","d-none")
                      }
                      
                      } else {
                          magic_message(`<i class="fa fa-times-circle text-danger"></i> ${new_uptoken}`, "dialog_box")
                      }                      
                      
                    }
                    
                      function _minit_user_bundle_role_functions_(new_uptoken)
                      {

                         push_newval("user_bundle_role_functions_uptoken", btoa(new_uptoken))
                         mginitialize__dsql("user_bundle_role_functions", new_uptoken,"",'<?php echo base64_encode($user_bundle_role_functions_data_functions);?>')
                         mosytoggle_addclass("mp_js_user_bundle_role_functions_insert_btn","d-none")
                         mosytoggle_remclass("mp_js_user_bundle_role_functions_update_btn","d-none")
                         mosytoggle_remclass("mp_js_user_bundle_role_functions_clone_btn","d-none")                        
                      }
                      
                      function create_msnack_box_(message){

                      mosy_snack_wgt(message, "top", "snack_box", "200px", "table_alert_toast", '<?php echo $btn_txt ?>',  '<?php echo $btn_bg ?>', '');
                      mosytoggle_class('table_alert_toast', 'show');

                        setTimeout(function(){ 

                         push_html('snack_box', '');                                          

                          }, 3000);
                      }

					 function _mdrop_user_bundle_role_functions(qkey)
                     {
                        
                       magic_message('<i class="fa fa-spinner fa-spin"></i> Sending update request...', 'dialog_box')
                       var drop_payload="mosyajax_get('conf_deleteuser_bundle_role_functions&user_bundle_role_functions_uptoken="+(qkey)+"', '_user_bundle_role_functions_dsaved_:Deleted')";

                       magic_yes_no_alert('Delete record?', 'dialog_box', drop_payload, 'blackhole')
                     }
                    </script> 

                  
    <!-- ================== Start Feature Footer Section ========================== -------->
    <section class="hive_footer_section">

     <script type="text/javascript" src="./js/wrhs_auth_control.js?v=<?php echo date("dmyhisa") ?>"></script>

     <script type="text/javascript"></script>  
     
   <section  id="import_module"   >
    
       
     
    
   </section>
   
<!--mosy_page_script-->

    <input type="hidden" id="user_bundle_role_functions_uptoken" name="user_bundle_role_functions_uptoken" value="<?php echo base64_encode($user_bundle_role_functions_uptoken) ?>"/>
    </section>
     <!-- ================== End Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    