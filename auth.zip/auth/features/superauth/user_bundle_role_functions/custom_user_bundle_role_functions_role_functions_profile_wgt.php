<div class="p-0 col-md-12 text-center ">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">
      <?php  include("./hive_control/mpesaengine/user_bundle_role_functions/custom_profile_query_line__srt_role_functions_.php");?>
         
        </section>

       <!-- ================== Feature Header Section ========================== -------->
        <div class="col-md-12 rounded text-left p-0 mb-0 rounded shadow-sm bg-white  border" style="min-height:100vh;">   
          <div class="col-md-12 pr-lg-5 pl-lg-5 m-0">   
               
     <div class="col-md-12 pt-4 p-0 hive_profile_title_top" id=""></div>
     <h3 class="col-md-12 title_text text-left p-0 mb-0 pl-lg-3 hive_profile_title"><?php if(isset($_GET["user_bundle_role_functions_uptoken"]) & !isset($_GET["mosy_page_title"])){ echo "Role functions Profile";}elseif(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Add User Bundle Role Functions"; }?></h3>                                   
                 
              <div class="row justify-content-end m-0 p-0 col-md-12  p-3 bg-white hive_profile_navigation" id="">

                <div class="col-md-4 text-left p-0 hive_profile_nav_back_to_list_tray" id="">

                 <a href="./role_functions_list.php" class="text-info hive_profile_nav_back_to_list"><i class="fa fa-arrow-left"></i> Back to list</a>

                </div>
                <div class="col-md-8 p-0 text-right hive_profile_nav_add_new_tray" id="">   
                  
              <?php if(isset($_GET["user_bundle_role_functions_uptoken"])){?>
              <!--<navgation_buttons/>-->
              <?php } ?>
                            
                </div>              
              </div>
               <div class="col-md-12 pt-4 p-0 hive_profile_navigation_divider" id=""></div>
              
              
         <div class="col-md-12 p-0 m-0" style="">
           <div class="row justify-content-center m-0 p-0 col-md-12 ">
                    
                <div class="col-md-12 row justify-content-left m-0  p-0">
                                       
           <div class="form-group col-md-6 hive_data_cell  ">
             <div class="col-md-12 p-0 m-0 " id="">
              <label >Allowed access</label>
              <?php $_page_group=getarr_val_($user_bundle_role_functions_node, "role_id"); if(isset($_GET["page_group"])){$_page_group=base64_decode($_GET["page_group"]);}?>
              <?php $mgq_page_manifest__user_bundle_role_functions_page_group_ = mosyget_("page_manifest_", "*", " where page_group='$_page_group' ", "l", "","mpesaengine")["data"];  ?>
              <?php 
                $mgq_page_manifest__user_bundle_role_functions_page_group_res =[];                 
                if(isset($mgq_page_manifest__user_bundle_role_functions_page_group_[0])){               
                  $mgq_page_manifest__user_bundle_role_functions_page_group_res=$mgq_page_manifest__user_bundle_role_functions_page_group_[0];                
                }
              ?>
                <input autocomplete="off" type="text" name="txt__page_manifest__page_group_role_id_disp" id="txt__page_manifest__page_group_role_id_disp" class="form-control hive_dcall_tup mosy_msdn" data-mosy_msdn="mosyauto_dropdown('txt__page_manifest__page_group_role_id_disp')" data-hive_dcall_fun="hive_mosy_dsearch" data-hive_dcall_arg="page_manifest_:cs_dtray,txt__page_manifest__page_group_role_id_disp,_page_manifest__page_group_role_id_cstemp,_page_manifest__page_group_role_id_data_isle, _:<?php echo base64_encode(" and hive_site_id='$mpesaengine_session_hive_site_id'  ")?>,primkey" class="form-control" placeholder="Search Allowed access"  value="<?php echo getarr_val_($mgq_page_manifest__user_bundle_role_functions_page_group_res, "page_group", "page_manifest__page_manifest__disp");?>" />
              <template id="_page_manifest__page_group_role_id_cstemp">                             
                <div class=" row justify-content-center m-0 p-0 col-md-12">
                  <div class="col-md-12 border-bottom cpointer p-2 mosy_msdn " data-mosy_msdn="push_newval('txt_role_id','{{page_group}}');push_newval('txt__page_manifest__page_group_role_id_disp','{{page_group}}');;mosyhide_elem('_page_manifest__page_group_role_id_data_isle')">{{page_group}}</div>  
                </div>
              </template>
              <input type="hidden" name="txt_role_id" id="txt_role_id" value="<?php echo $_page_group;?>"/>
             </div>
           </div>
                   
      <div class="col-md-12 text-center">
      <?php if(!isset($_GET['user_bundle_role_functions_uptoken'])){?> 
            <button type="submit" id="mpuser_bundle_role_functions_insert_btn" name="mpuser_bundle_role_functions_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET['user_bundle_role_functions_uptoken'])) {?>
            <button type="submit" id="mpuser_bundle_role_functions_update_btn" name="mpuser_bundle_role_functions_update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="mpuser_bundle_role_functions_insert_btn" name="mpuser_bundle_role_functions_insert_btn" class="ml-lg-3 mt-lg-0 d-none mt-4 btn border border_set text-dark" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>          
            <?php } ?>
    </div>
  
                </div>
              </div>
          </div>
          </div>
          <div class="row justify-content-center m-0 pr-lg-4 pl-lg-4 pt-0 col-md-12" id="">        
            <!--<hive_mini_list/>-->      
          </div>
        </div>

    <!-- ================== Feature Footer Section ========================== -------->
    <section class="hive_footer_section">
    <input type="hidden" id="user_bundle_role_functions_uptoken" name="user_bundle_role_functions_uptoken" value="<?php echo base64_encode($user_bundle_role_functions_uptoken) ?>"/>

    <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/mpesaengine/wrhs_mpesaengine_control.js?v=<?php echo date("dmyhisa") ?>"></script>
    </section>
    <!--mosy_page_script-->
    
     <!-- ================== Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    