<script type="text/javascript" src="./js/hives/firebirdb2c/behive/hive_user_manifest__control.js"></script>
<script type="text/javascript" src="./js/hives/firebirdb2c/behive/hive_page_manifest__control.js"></script>

  <script type="text/javascript">
     var assigned_roles=`
                        <div class="col-md-12 border-bottom  border_set cpointer " onclick="user_manifest__rem_(btoa('{{primkey}}'), 'load_user_roles')" >
                         <span class="badge"> <i class="fa fa-times-circle text-danger "></i> {{role_name}}</span>
                       </div>
     `;

    var emptyuser =`
    <div class="row justify-content-center cpointer m-0 p-0 col-md-12" >
    <div class="col-md-12 text-center p-3 "><span class=" text-wrap"> No roles Found for this user, click on an exisiting role to assign role.</span></div>
    </div>

    `;
    function load_user_roles()
    { 
    qkload_user_manifest_("", 'push_grid_result:assigned_roles:0:emptyuser', assigned_roles, "user_id='<?php echo getarr_val_($system_users_node, $user_id_col) ?>'");
    }  

    load_user_roles();
</script>  