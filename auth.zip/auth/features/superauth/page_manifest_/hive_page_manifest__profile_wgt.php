<div class="p-0 col-md-12 text-center ">
 <!-- ================== Start Feature Section========================== -------->
 
 <!-- ================== Feature Header Section ========================== -------->
  <section class="hive_header_section">
  <?php    
   include("./hive_control/superauth/page_manifest_/profile_query_lines_page_manifest_.php")
  ?>

   
    </section>

   <!-- ================== Feature Header Section ========================== -------->
   	<div class="col-md-12 rounded text-left p-0 mb-3  p-lg-5 mb-4 rounded shadow-sm bg-white  border">   
         <h3 class="col-md-12 title_text text-left p-0 mb-3">Page Manifest  Profile</h3>                                  
         <div class="col-md-12 pt-3 p-0" id=""></div>
  
          <div class="row justify-content-end m-0 p-0 col-md-12 border-bottom p-3 bg-light rounded_medium" id="">
          
            <div class="col-md-4 text-left p-0 " id="">
            
             <a href="./page_manifest__list.php" class="text-info"><i class="fa fa-arrow-left"></i> Back to list</a>
            
            </div>
            <div class="col-md-8 p-0 text-right " id="">            
			    
          <?php if(isset($_GET["page_manifest__uptoken"])){?>
          <a href="./page_manifest__profile.php" class="medium_btn btn-primary border border_set  p-2 mb-3"><i class="fa fa-plus-circle"></i>  Add new</a>
            <?php } if(isset($_GET["page_manifest__uptoken"]))
            {?>
         <a href="./page_manifest__profile.php?page_manifest__uptoken=<?php echo $_GET["page_manifest__uptoken"];?>&deletepage_manifest_&after_delete=<?php echo base64_encode("./page_manifest__list.php");?>" class="medium_btn  border border-danger  text-danger p-2  ml-3 mb-3 ">
              <i class="fa fa-trash"></i> Delete
            </a>
            <?php } ?>              
            </div>
              
          </div>
         <div class="col-md-12 pt-5 p-0" id=""></div>
      
		
     <div class="col-md-12" style="">
       <div class="row justify-content-center m-0 p-0 col-md-12 ">
				
            <div class="col-md-12 row justify-content-left m-0  p-0">
               
        <div class="form-group col-md-6">
          <label >Page Group</label>
          <input class="form-control" id="txt_page_group" name="txt_page_group" value="<?php echo getarr_val_($page_manifest__node, "page_group");?>" placeholder="Page Group" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Site Id</label>
          <input class="form-control" id="txt_site_id" name="txt_site_id" value="<?php echo getarr_val_($page_manifest__node, "site_id");?>" placeholder="Site Id" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Page Url</label>
          <input class="form-control" id="txt_page_url" name="txt_page_url" value="<?php echo getarr_val_($page_manifest__node, "page_url");?>" placeholder="Page Url" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Hive Site Id</label>
          <input class="form-control" id="txt_hive_site_id" name="txt_hive_site_id" value="<?php echo getarr_val_($page_manifest__node, "hive_site_id");?>" placeholder="Hive Site Id" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Hive Site Name</label>
          <input class="form-control" id="txt_hive_site_name" name="txt_hive_site_name" value="<?php echo getarr_val_($page_manifest__node, "hive_site_name");?>" placeholder="Hive Site Name" type="text">
        </div>

               
      <div class="col-md-12 text-center">
      <?php if(!isset($_GET['page_manifest__uptoken'])){?> 
            <button type="submit" id="mppage_manifest__insert_btn" name="mppage_manifest__insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET['page_manifest__uptoken'])) {?>
            <button type="submit" id="mppage_manifest__update_btn" name="mppage_manifest__update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="mppage_manifest__insert_btn" name="mppage_manifest__insert_btn" class="ml-lg-3 mt-lg-0 d-none mt-4 btn border border_set text-dark" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>          
            <?php } ?>
    </div>
  
            </div>
          </div>
      </div>
    </div>

<!-- ================== Feature Footer Section ========================== -------->
<section class="hive_footer_section">
  <?php  ?>

 <script type="text/javascript">

 </script>  
<input type="hidden" id="page_manifest__uptoken" name="page_manifest__uptoken" value="<?php echo base64_encode($page_manifest__uptoken) ?>"/>
</section>
 <!-- ================== Feature Footer Section ========================== -------->
 
 <!-- ================== End Feature Section========================== -------->
