<div class="row justify-content-center m-0 p-0 col-md-12 skin_plasma">
  <div class="col-md-5 p-0 m-0">    
    

    <div class="main-wrapper login-body" style="background-image:url()">
      <div class="login-wrapper">
        <div class="container">
          <div class="loginbox">
            <div class="login-right">
              <div class="login-right-wrap">
              <div class="col-md-12 py-3 text-center ">
                <img src="<?php echo $mep_app_logo; ?>" class="" style="width:100px;" id=""/>
              </div>
              <h1 class="mt-2"> <?php echo $mep_app_name ?> </h1>
              <?php if(isset($_GET['reset_token']))
              {?>
              <p class="account-subtitle">Change Password </p>
              <form method="post">
                <div class="form-group">
                    <label >Enter New Password </label>
                    <input class="form-control" required id="txt_password_one" name="txt_password_one" value="" placeholder="Enter New Password" type="password">
                </div>
                <div class="form-group">
                    <label >Confirm New Password </label>
                    <input class="form-control" required id="txt_password_two" name="txt_password_two" value="" placeholder="Confirm new password" type="password">
                </div>
                <div class="form-group">
                    <button class="btn btn-primary btn-block" name="confirm_password_reset_btn" type="submit"> Proceed </button>
                </div>
              <div class=" text-center p-2 "><a href="<?php echo $login_file ?>">Back to login </a></div>            
              </form>            
              <?php }else{?>
              <p class="account-subtitle">Request Password Reset </p>
              <form method="post">
                <div class="form-group">
                    <input class="form-control" name="txt_email" required type="email" placeholder="Type your Email to reset password ">
                </div>

                <div class="form-group">
                    <button class="btn btn-primary btn-block" name="request_password_reset_btn" type="submit"> Request Reset </button>
                </div>
              </form>
              <div class=" text-center p-2 "><a href="<?php echo $login_file ?>">Back to login </a></div>            
              <?php } ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


  </div>
  <div class="col-md-7 order-1 order-lg-2 text-center p-0 m-0 bg_w_img" style="background-image: url('<?php echo $login_bg_img ?>');">
      <div class="col-md-12 p-0  m-0 p-0 align-items-center d-flex" style="background-color: rgba(255, 255, 255, 0.6); height: 100vh;">
          <div class="col-md-12 text-center d-none">
              <img src="<?php echo $mep_app_logo; ?>" style="width: 150px;" alt="Logo" />
              <h1 class="col-md-12 mt-3"><?php echo $mep_app_name ?></h1>
          </div>

      </div>
  </div>
</div>