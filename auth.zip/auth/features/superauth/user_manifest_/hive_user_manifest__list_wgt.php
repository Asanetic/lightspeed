
<div class="p-0 col-md-12">
 <!-- ================== Start Feature Section========================== -------->
 
 <!-- ================== Feature Header Section ========================== -------->
  <section class="hive_header_section">
  <?php  include("./hive_control/superauth/user_manifest_/list_query_lines_user_manifest_.php");?>
  
   
    </section>
    
<!-- ================== End Feature Header Section ========================== -------->
</div>

  <style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="col-md-12 bg-white border pl-3 pr-3 " style="margin-top: 0px; padding-bottom: 150px;">

<div class="row justify-content-end col-md-12 text-right pt-3 pb-3 " id="">

  <div class="col-md-6 p-0 text-left pt-3">
    <h6 class="text-muted"><b> User Manifest  </b></h6>
  </div>

  <div class="col-md-6 p-0 text-right">
    <input type="text" id="txt_user_manifest_" name="txt_user_manifest_" class="custom-search-input form-control" placeholder="Search User Manifest ">
    <button class="custom-search-botton" id="quser_manifest__btn" name="quser_manifest__btn" type="submit"><i class="fa fa-search mr-1"></i> Go </button>  

  </div>                       
  <div class="col-md-12 pt-5 p-0" id=""></div>

  <div class="row justify-content-end m-0 p-0 col-md-12" id="">
  
    <div class="col-md-5 p-0 text-left" id="">
    </div>
    <div class="col-md-7 p-0 " id=""> 	    	  
      <a href="<?php echo magic_basename(magic_current_url()) ?>" class="medium_btn border border_set btn-white "><i class="fa fa-refresh mr-1 "></i> Refresh </a>   	 	
      <a href="./user_manifest__profile.php" class="medium_btn border border_set btn-primary ml-3 "><i class="fa fa-plus-circle"></i>  Add new</a>
      
    </div>    
      
  </div>
</div> 

<div class="table-responsive  data-tables bg-white" style="margin-top: 0px; padding-bottom: 10px;">

<table class="table table-hover  text-left" id="user_manifest__data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Id</th>
             <th scope="col">User Name</th>
             <th scope="col">Role Id</th>
             <th scope="col">Site Id</th>
             <th scope="col">Role Name</th>
             <th scope="col">Hive Site Id</th>
             <th scope="col">Hive Site Name</th>

		   </tr>
	    </thead>
	    <tbody>
      <?php 
          $default_user_manifest__profile="./user_manifest__profile.php";
          if(isset($user_manifest__profile))
          {
          $default_user_manifest__profile=$user_manifest__profile;
          } 
          
          $default_user_manifest__listing="./user_manifest__list.php";
          if(isset($user_manifest__listing))
          {
          $default_user_manifest__listing=$user_manifest__listing;
          } 
          
          $default_user_manifest__show_edit_btn="yes";
          if(isset($user_manifest__show_edit_btn))
          {
          $default_user_manifest__show_edit_btn=$user_manifest__show_edit_btn;
          } 
      	
          echo drop_css();
        
          $i=0;

		  
          
        //<--outloop-dope-->
 
 	   foreach($user_manifest__list_query["data"] as $listuser_manifest__result)
    	{
        
        $i++;
		
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_user_manifest__show_edit_btn=="yes"){
          $edit_drop_link=magic_link($default_user_manifest__profile.'?user_manifest__uptoken='.base64_encode($listuser_manifest__result["primkey"]).'', '<i class="fa fa-edit"></i> View More', '');
          }
          
           //{{edit_drop_link}}
           if($default_user_manifest__show_edit_btn=="yes")
           {
            $delete_drop_link=magic_link($default_user_manifest__profile.'?after_delete='.base64_encode(magic_current_url()).'&user_manifest__uptoken='.base64_encode($listuser_manifest__result["primkey"]).'&deleteuser_manifest_','<i class="fa fa-trash"></i> Delete', '');
		   }
	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr>
              <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
            
                         <td scope="col"><span title="<?php echo $listuser_manifest__result["user_id"] ?>"><?php echo magic_strip_if($listuser_manifest__result["user_id"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listuser_manifest__result["user_name"] ?>"><?php echo magic_strip_if($listuser_manifest__result["user_name"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listuser_manifest__result["role_id"] ?>"><?php echo magic_strip_if($listuser_manifest__result["role_id"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listuser_manifest__result["site_id"] ?>"><?php echo magic_strip_if($listuser_manifest__result["site_id"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listuser_manifest__result["role_name"] ?>"><?php echo magic_strip_if($listuser_manifest__result["role_name"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listuser_manifest__result["hive_site_id"] ?>"><?php echo magic_strip_if($listuser_manifest__result["hive_site_id"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listuser_manifest__result["hive_site_name"] ?>"><?php echo magic_strip_if($listuser_manifest__result["hive_site_name"], 70, 70);?></span></td>

			</tr>
       <?php }?>

          <tr>
          <th></th>
          
                       <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>

          </tr>
  <!--add_new_row_here-->
	    </tbody>
	    </table>
             <?php if($i==0){?>
            <h6 class="col-md-12 text-center p-3 mb-5 text-muted"><i class="fa fa-search"></i> Sorry, no user manifest  records found</h6>
            <div class="col-md-12 text-center mt-4">
            	<?php $search_user_manifest__class="ml-0"; if($default_user_manifest__show_edit_btn=="yes"){
                $search_user_manifest__class="ml-4";
                ?>
            	<a href="<?php echo $default_user_manifest__profile ?>" class="medium_btn border border_set btn-white "><i class="fa fa-plus-circle"></i>  Add new </a>
                <?php }?>
            	<a href="<?php echo  $default_user_manifest__listing?>" class="medium_btn border border_set btn-primary <?php echo $search_user_manifest__class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
            </div>
          <?php }?>
         <?php echo mosy_paginate_ui($user_manifest__list_query["page_count"], $datalimit, "quser_manifest__token","skip")?>
        </div>
        </div>
        
       
<!-- ================== Start Feature Footer Section ========================== -------->
<section class="hive_footer_section">

 <script type="text/javascript">

 </script>  
<input type="hidden" id="user_manifest__uptoken" name="user_manifest__uptoken" value="<?php echo base64_encode($user_manifest__uptoken) ?>"/>
</section>
 <!-- ================== End Feature Footer Section ========================== -------->
 
 <!-- ================== End Feature Section========================== -------->
