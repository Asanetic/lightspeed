<div class="p-0 col-md-12 text-center ">
     <!-- ================== Start Feature Section========================== -------->

     <!-- ================== Feature Header Section ========================== -------->
      <section class="hive_header_section">
      <?php  include("./hive_control/superauth/system_role_bundles/custom_profile_query_line__srt_role_functions_.php");?>
         
        </section>

       <!-- ================== Feature Header Section ========================== -------->
        <div class="col-md-12 rounded text-left p-0 mb-0 rounded shadow-sm bg-white  border" style="min-height:100vh;">   
          <div class="col-md-12 pr-lg-5 pl-lg-5 m-0">   
               
     <div class="col-md-12 pt-4 p-0 hive_profile_title_top" id=""></div>
     <h3 class="col-md-12 title_text text-left p-0 mb-0 pl-lg-3 hive_profile_title"><?php if(isset($_GET["system_role_bundles_uptoken"]) & !isset($_GET["mosy_page_title"])){ echo "Role functions Profile";}elseif(isset($_GET["mosy_page_title"])){ echo base64_decode($_GET["mosy_page_title"]); }else{ echo "Add System Role Bundles"; }?></h3>                                   
                 
              <div class="row justify-content-end m-0 p-0 col-md-12  p-3 bg-white hive_profile_navigation" id="">

                <div class="col-md-4 text-left p-0 hive_profile_nav_back_to_list_tray" id="">

                 <a href="./role_functions_list.php" class="text-info hive_profile_nav_back_to_list"><i class="fa fa-arrow-left"></i> Back to list</a>

                </div>
                <div class="col-md-8 p-0 text-right hive_profile_nav_add_new_tray" id="">   
                  
              <?php if(isset($_GET["system_role_bundles_uptoken"])){?>
              <!--<navgation_buttons/>-->
              <?php } ?>
                            
                </div>              
              </div>
               <div class="col-md-12 pt-4 p-0 hive_profile_navigation_divider" id=""></div>
              
              
         <div class="col-md-12 p-0 m-0" style="">
           <div class="row justify-content-center m-0 p-0 col-md-12 ">
                    
                <div class="col-md-12 row justify-content-left m-0  p-0">
                   
        <div class="form-group col-md-6 hive_data_cell ">
          <label >Hive Site Id</label>
          <input class="form-control" id="txt_hive_site_id" name="txt_hive_site_id" value="<?php echo getarr_val_($system_role_bundles_node, "hive_site_id");?>" placeholder="Hive Site Id" type="text">
        </div>

        <div class="form-group col-md-6 hive_data_cell ">
          <label >Hive Site Name</label>
          <input class="form-control" id="txt_hive_site_name" name="txt_hive_site_name" value="<?php echo getarr_val_($system_role_bundles_node, "hive_site_name");?>" placeholder="Hive Site Name" type="text">
        </div>

                   
      <div class="col-md-12 text-center">
      <?php if(!isset($_GET['system_role_bundles_uptoken'])){?> 
            <button type="submit" id="mpsystem_role_bundles_insert_btn" name="mpsystem_role_bundles_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET['system_role_bundles_uptoken'])) {?>
            <button type="submit" id="mpsystem_role_bundles_update_btn" name="mpsystem_role_bundles_update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="mpsystem_role_bundles_insert_btn" name="mpsystem_role_bundles_insert_btn" class="ml-lg-3 mt-lg-0 d-none mt-4 btn border border_set text-dark" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>          
            <?php } ?>
    </div>
  
                </div>
              </div>
          </div>
          </div>
          <div class="row justify-content-center m-0 pr-lg-4 pl-lg-4 pt-0 col-md-12" id="">        
            <!--<hive_mini_list/>-->      
          </div>
        </div>

    <!-- ================== Feature Footer Section ========================== -------->
    <section class="hive_footer_section">
    <input type="hidden" id="system_role_bundles_uptoken" name="system_role_bundles_uptoken" value="<?php echo base64_encode($system_role_bundles_uptoken) ?>"/>

    <script type="text/javascript" src="<?php echo $common_root ?>/js/hives/mpesaengine/wrhs_mpesaengine_control.js?v=<?php echo date("dmyhisa") ?>"></script>
    </section>
    <!--mosy_page_script-->
    
     <!-- ================== Feature Footer Section ========================== -------->

     <!-- ================== End Feature Section========================== -------->
    