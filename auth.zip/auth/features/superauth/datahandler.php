<?php 
//===============Start Mosy queries-============//===============End Mosy queries-============

//============= Start Sql chart  Script =====================

function mosy_sql_rollback($tbl, $where, $type)
{
  $sql_fun="get_".$tbl;

  $curr_sql_ret_=$sql_fun("*", " where ".$where." ", "r");
  
  $json_sql_str=json_encode($curr_sql_ret_, true);
  
  //------- begin mosy_sql_roll_back_post_arr --> 
  $mosy_sql_roll_back_post_arr_=array(

  "primkey"=>"NULL",
  "roll_bk_key"=>mmres(magic_random_str(20)),
  "table_name"=>mmres($tbl),
  "where_str"=>mmres($where),
  "roll_type"=>mmres($type),
  "roll_timestamp"=>date("Y-m-d H:i:s"),
  "value_entries"=>mmres($json_sql_str)

  );
  //===-- End mosy_sql_roll_back_post_arr -->

  add_mosy_sql_roll_back($mosy_sql_roll_back_post_arr_);
  
  return $json_sql_str;
  
}


function get_mosychart_data($tbl, $colstr, $where_str, $xcol, $ycol, $groupby)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str="";
   $groupby_cols="";
   
   if($where_str!='')
   {
     $fun_where_str=" WHERE ".$where_str;
   }
   
   if($groupby!='')
   {
     $groupby_cols=" GROUP BY ".$groupby;
   }
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ".$groupby_cols." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================

//============= End Sql chart  Script =====================

function get_mosyflex_chart($tbl, $colstr, $where_str, $xcol, $ycol)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str=$where_str;
  
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================


//============= Start   mosy flex select script =====================

function mosyflex_sel($tbl, $colstr, $where_str, $loop_or_row_l_r,$show_str="")
{
   global $single_conn;
   global $single_db;
   global $flex_result;
   global $datalimit;
  
  $paginate_q="";
  $paginate_state="";
  
  $pagination_token=$tbl."_mpgtkn";
  
  $loop_or_row_l_rtype=$loop_or_row_l_r;
  
  if (strpos($loop_or_row_l_r, ':') !== false)
  {
    $loop_or_row_l_r_str=explode(":", $loop_or_row_l_r);

    $pagination_token=$loop_or_row_l_r_str[1];

    $loop_or_row_l_rtype=$loop_or_row_l_r_str[0];

    $paginate_state="paginate";
    
    if(isset($loop_or_row_l_r_str[2]))
    {
    $datalimit=$loop_or_row_l_r_str[2];
    }
    
    $pagination_sql="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

    $process_pagination=mysqli_query($single_conn, $pagination_sql) or die(mysqli_error($single_conn));

    $requested_page=1;
    if(isset($_GET[$pagination_token]))
    {
      $requested_page=base64_decode($_GET[$pagination_token]);
      if($requested_page=="")
      {
        $requested_page=1;
      }
      ////echo " yyyyyyyyy token ".$requested_page." isset yyyyyyy";
    }
    
    if(isset($loop_or_row_l_r_str[3]))
    {    
      $requested_page=$loop_or_row_l_r_str[3];
    }    
    
    
    $paginate_q=mosy_paginate($process_pagination, $datalimit, $pagination_token, $requested_page);

    $first_page_record_=$paginate_q[0];       
    
    $new_where_str=$where_str." LIMIT ".$first_page_record_.", $datalimit ";
    
    $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_str."";
    

  }else{
    
      $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

  }
  if($show_str=="yes")
  {
   echo $sql_str;
  } 
  $flex_result_q=mysqli_query($single_conn, $sql_str) or die(mysqli_error($single_conn));
  
  $flex_result=$flex_result_q;

  if($loop_or_row_l_rtype=='r')
  {
    $flex_result_r=mysqli_fetch_array($flex_result_q);
    
    $flex_result=$flex_result_r;
    
  }
  
  if($loop_or_row_l_rtype=="j")
  {
    $json_data_resp=array();
    
    while($flex_result_json=mysqli_fetch_array($flex_result_q)){      
    
     $json_data_resp[]=$flex_result_json;
      
    }
    
    $json_data_rows=$json_data_resp;
    
  } 
  
 /// echo $loop_or_row_l_rtype;
  
  if($paginate_state=='paginate' && $loop_or_row_l_rtype=="j")
  {
  	$flex_result=json_encode(array("data"=>$json_data_rows, "first_row"=>$paginate_q[1], "page_count"=>$paginate_q[0], "query_string"=>$sql_str, "pagination_sql"=>$pagination_sql));  
  }
  
  if($paginate_state=='' && $loop_or_row_l_rtype=="j")
  {
  	$flex_result=json_encode(array("data"=>$json_data_rows, "first_row"=>"", "page_count"=>"", "query_string"=>$sql_str, "pagination_sql"=>""));  
  }
  
  if($paginate_state=='paginate' && $loop_or_row_l_rtype=="l")
  {
  	$flex_result=array($flex_result_q, $paginate_q[1], $paginate_q[0], $sql_str, $pagination_sql);  
  }
  
  
  return $flex_result;
  
}


function mosy_paginate($sqlstring, $reclimit, $token_name,$requested_page)
{


  $rows_count = mysqli_num_rows($sqlstring);

  $items_per_page = $reclimit;

  $page_count = ceil($rows_count / $items_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_row = ($requested_page - 1) * $items_per_page;

  $recordperpage_data=array($first_row,$page_count);

  return $recordperpage_data;
  
}
//============= End  mosy flex select script =====================

  function tonum($number_str, $decplaces=0)
  {
	if($number_str=='')
    {
      $number_str=0;
    }
  	return number_format($number_str, $decplaces, ".", ",");
  	

  }
  
//checkblank fuction

function checkblank($value, $return_val)
{
  
  global $fun_resonse;

  if($value!='')
  {
  $fun_resonse=$value;
  }else{
    $fun_resonse=$return_val;

  }
  return $fun_resonse;

}

//get date foramrt

function ftime($time_st, $type)
{
  	global $timeresp;
    
  $timeresp=date("l, jS, M, y, @ H:i:s");

  if($time_st=="") 
  {
    $timeresp=date("l, jS, M, y, @ H:i:s");

  	if($type=="date")
    {
    $timeresp=date("l, jS, M, y");
    }
    
  }
  
  if($time_st!=""){
  
     $timeresp=date("l, jS, M, y, @ H:i:s", strtotime($time_st));

    if($type=="date")
    {
    	$timeresp=date("l, jS, M, y", strtotime($time_st));
    }
    
  }
	return $timeresp;
}

function date_time_input($time_st, $full_date_time="")
{
  	global $timeresp;
    
    $date_form="Y-m-d\TH:i:s";
    
    if($full_date_time=="date")
    {
    $date_form="Y-m-d";
    }
    
    if($full_date_time=="time")
    {
    $date_form="H:i:s";
    }
    
  if($time_st==""){
  	$timeresp=date($date_form);
  }else{
   
   $timeresp=date($date_form, strtotime($time_st));

  }
	return $timeresp;
}
function daytime()
{
  global $daytime;

  $daytime='Hello';

  $fromdate=date('A');
  $eve_aft=date("H");

  if($fromdate=='AM'){
 	 $daytime='Morning';
  }
  
  if($fromdate=='PM' && $eve_aft<17){
  	$daytime='Afternoon';
  }
  
  if($fromdate=='PM' && $eve_aft>=17){
  	$daytime='Evening';
  }

  return $daytime;
}

function mosy_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest)
{
	global $curl_post_response;

	$new_curl_method='POST';
	if($curlopt_customrequest!='')
	{
		$new_curl_method=$curlopt_customrequest;
	}

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $curlopt_url);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $new_curl_method); 
		curl_setopt($ch, CURLOPT_HTTPHEADER, ($curlopt_httpheader));
		curl_setopt($ch, CURLOPT_USERPWD, $curlopt_userpwd);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $curlopt_post_fields);

		$curl_post_response = curl_exec($ch);

	return $curl_post_response;
}

function mosy_month_year_diff($start_date, $end_date, $myd="m")
{

  $ts1 = strtotime($start_date);
  $ts2 = strtotime($end_date);

  $year1 = date("Y", $ts1);
  $year2 = date("Y", $ts2);

  $month1 = date("m", $ts1);
  $month2 = date("m", $ts2);

  $date1=date_create($start_date);
  $date2=date_create($end_date);

  $day_diff=date_diff($date1,$date2);

  $day_diff_count=$day_diff->format("%R%a");
    
  $year_diff_=$year2 - $year1;
  $month_diff_=$month2 - $month1;

  $diff = (($year_diff_) * 12) + ($month_diff_);

  $ret_diff=$year_diff_;

  if($myd=="m")
  {
    $ret_diff=$diff;
  }
  
  if($myd=="d")
  {
    $ret_diff=$day_diff_count;
  }
  
  if($myd=="y")
  {
    $ret_diff=$year_diff_;
  }

  return $ret_diff;

}

function ifnotblank($str,$replacement)
{
	
    if($str!="")
    {
     return $replacement;
     
    }else{
    return $str;
    }

}

function time_elapsed_string($datetime, $full = false) 
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        "y" => "year",
        "m" => "month",
        "w" => "week",
        "d" => "day",
        "h" => "hour",
        "i" => "minute",
        "s" => "second",
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . " " . $v . ($diff->$k > 1 ? "s" : "");
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(", ", $string) . " ago" : "just now";
}

if (file_exists("./mosy_paginate.php")){
include("./mosy_paginate.php");
}

function pdf_url($current, $pdfurl)
{
  
  $filter_param=str_replace($current."", $pdfurl."", (magic_current_url()));

  if(strpos($filter_param, '?') !== false) 
  {
    $filter_param=str_replace($current."?", $pdfurl."?", (magic_current_url()));

  }

  if(strpos($filter_param, '.php?') !== false) 
  {
    $filter_param=str_replace($current.".php?", $pdfurl."?", (magic_current_url()));

  }

  return $filter_param;
  
}


function mosy_send_mail($to_email, $from_email, $sender_name, $subject, $message, $use_api="")
{
	// create email headers
	$replyto_mail="";
	$returnpath="";
	$headers="";

	if($from_email!='')
	{
    	$replyto_mail='Reply-To: ' .$sender_name." <".$from_email.">\r\n";
    	$returnpath='Return-Path: ' .$sender_name." <".$from_email.">\r\n";
	}

	$busmail=$from_email;
	$bus_name=$sender_name;

	if($to_email=='')
	{
		$busmail='info@clearphrases.com';
	}

	if($sender_name=='')
	{
		$bus_name="";
	}

    $headers = 'From: '.$bus_name.'<'.$busmail.'>' . "\r\n" .
    $headers.=$replyto_mail;
    $headers.=$returnpath;
    $headers .= "Organization: ".$bus_name."\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers.='Content-type: text/html; charset=UTF-8'. "\r\n";
    $headers .= "X-Priority: 3\r\n";
    $headers .= "X-Mailer: PHP". phpversion() ."\r\n";
   
  if($use_api=="yes")
  {
    
    $curlopt_url="https://origin.clearphrases.com/api/email/mosy_mail.php";
    
    $email_attr="send_mosy_email&to_email=".rawurlencode($to_email)."&from_email=".rawurlencode($from_email)."&sender_name=".rawurlencode($sender_name)."&subject=".rawurlencode($subject)."&message=".rawurlencode($message)."";
    
   return magic_post_curl($curlopt_url, "", "", $email_attr, "POST");

  }else{
    
  return mail($to_email, $subject, $message, $headers);        
  }
}


function mosy_push_sms($recp, $sms_body, $smsapi_url="")
{

  
  if($smsapi_url=="")
  {
    $smsapi_url="https://origin.clearphrases.com/api/sms/adminsmsgateway.php";
  }
  
  $sms_request="pushsms&recp=".$recp."&body=".$sms_body."";

  return magic_post_curl($smsapi_url, '', '', $sms_request, 'POST');

}
function add_url_param( $key, $value, $passed_url) 
{
  $url=$passed_url;
  if($passed_url=='')
  {
    $url=magic_current_url();
  }
  
  $info = parse_url( $url );

  if(isset($info['query']))
  {
    parse_str( $info['query'], $query );
  }else{
    $query="";
  }
    return $info['scheme'] . '://' . $info['host'] . $info['path'] . '?' . http_build_query( $query ? array_merge( $query, array($key => $value ) ) : array( $key => $value ) );
}


function mosy_user_acc_($user_id, $access_key="")
{
  
  if($access_key=="")    
  {
    $access_key=magic_basename(magic_current_url());
  }
  
    
  $access_key=str_replace(".php", "", $access_key); 
  
  $page_group=qpage_manifest__ddata("page_url", $access_key);

  $pagegrp=$page_group['page_group'];

  $user_access_req=count_user_manifest_(" user_id='$user_id' and role_name='$pagegrp' ");

  $user_role_attr=quser_manifest__gdata(" where  user_id='$user_id' and role_name='$pagegrp' ");

  ///echo " status - ".$user_access_req;
  ///echo " Page ".$pagegrp." - user_count - ".$user_access_req." NAme - ".$user_role_attr['user_name']." acc key - ".$access_key."<br>";  
  if($user_access_req>0)
  {
    $acc_state="Allowed";
  }else{
    $acc_state="Denied";
  }

  return $acc_state;
}



function mosy_log_notific($note_title,$note_remark,$note_link="",$note_type="",$note_icon="img/logo.png")
{
  
  //------- begin notification_manifest__arr --> 
  $notification_manifest__arr_=array(

  "notific_key"=>magic_random_str(10),
  "notification_type"=>$note_type,
  "notification_state"=>"Unread",
  "notification_icon"=>$note_icon,
  "notification_title"=>$note_title,
  "notification_link"=>$note_link,
  "notification_read_state"=>"Unread",
  "notification_time_stamp"=>date("Y-m-d H:i:a"),
  "notif_remark"=>$note_remark

  );
  //===-- End notification_manifest__arr -->

  return add_notification_manifest_($notification_manifest__arr_);
  
}

function trim_text($string)
{
 return magic_strip_if($string, 90, 90);
}


function mosyget_($tbl, $colstr="*",$where_str="",$pagination="l",$function_cols="", $endpoint="")
{
  global $root_url;
  
  if($endpoint=="")
  {
    $endpoint=$root_url;
  }
  
  $pagination_token="";
  $next_page="";
  
  if (strpos($pagination, ":") !== false)
  {
    $loop_or_row_l_r_str=explode(":", $pagination);

    $pagination_token=$loop_or_row_l_r_str[1];

    ///print_r($loop_or_row_l_r_str);
      
    }
  
  if(isset($_GET[$pagination_token]))
  {
    $next_page="&".$pagination_token."=".$_GET[$pagination_token];
  }
  
  $payload="mosyget_&tbl=".$tbl."&colstr=".base64_encode($colstr)."&where_str=".base64_encode($where_str)."&pagination=".$pagination."&function_cols=".base64_encode($function_cols)."".$next_page."";

  ///echo $endpoint;
  
  //echo  $payload;
    
  $curlopt_url=$endpoint."?".$payload;
  $curlopt_httpheader="";
  $curlopt_userpwd="";
  $curlopt_post_fields="";
  $curlopt_customrequest="GET";

  $json__=magic_post_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest);
  
   ///echo $json__;
  
  $decoded_resp=json_decode($json__, true);;

  return $decoded_resp;
}



function mosypost_($post_arr, $additional_posts, $endpoint="")
{
  global $root_url;
  
  if($endpoint=="")
  {
    $endpoint=$root_url;
  }
  
  $app_users_mosy_rest_req_vars=http_build_query($post_arr);
  
  $additional_posts_str="";
  
  if($additional_posts!="")
  {
    $additional_posts_str="&".$additional_posts;
  }
  
  
  $curlopt_url=$endpoint;
  $curlopt_httpheader="";
  $curlopt_userpwd="";
  $curlopt_post_fields="mosyrequest_type=ajax&".$app_users_mosy_rest_req_vars.$additional_posts_str;
  $curlopt_customrequest="POST";

  return magic_post_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest);
  
}



function mosypost_arr_($post_arr, $additional_posts, $endpoint="")
{
  global $root_url;
  
  if($endpoint=="")
  {
    $endpoint=$root_url;
  }
  
  $ajax_arr_req=array("mosyrequest_type"=>"ajax");
  
  $post_data_arr=array_merge($ajax_arr_req, $post_arr, $additional_posts);
  
  ////print_r($post_data_arr);
  
  $curlopt_url=$endpoint;
  $curlopt_httpheader="";
  $curlopt_userpwd="";
  $curlopt_post_fields=$post_data_arr;
  $curlopt_customrequest="POST";

  return magic_post_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest);
  
}


function getarr_val_($array_, $key)
{
  $msarray_val_="";
  
  if(isset($array_[$key]))
  {
   $msarray_val_=$array_[$key];
  }
  
  return $msarray_val_;
  
}

//<--ncgh-->
?>