
<div class="p-0 col-md-12">
 <!-- ================== Start Feature Section========================== -------->
 
 <!-- ================== Feature Header Section ========================== -------->
  <section class="hive_header_section">
  <?php  include("./hive_control/superauth/system_users/list_query_lines_system_users.php");?>
  
   
    </section>
    
<!-- ================== End Feature Header Section ========================== -------->
</div>

  <style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="col-md-12 bg-white border pl-3 pr-3 " style="margin-top: 0px; padding-bottom: 150px;">

<div class="row justify-content-end col-md-12 text-right pt-3 pb-3 " id="">

  <div class="col-md-6 p-0 text-left pt-3">
    <h6 class="text-muted"><b> System Users </b></h6>
  </div>

  <div class="col-md-6 p-0 text-right">
    <input type="text" id="txt_system_users" name="txt_system_users" class="custom-search-input form-control" placeholder="Search System Users">
    <button class="custom-search-botton" id="qsystem_users_btn" name="qsystem_users_btn" type="submit"><i class="fa fa-search mr-1"></i> Go </button>  

  </div>                       
  <div class="col-md-12 pt-5 p-0" id=""></div>

  <div class="row justify-content-end m-0 p-0 col-md-12" id="">
  
    <div class="col-md-5 p-0 text-left" id="">
    </div>
    <div class="col-md-7 p-0 " id=""> 	    	  
      <a href="<?php echo magic_basename(magic_current_url()) ?>" class="medium_btn border border_set btn-white "><i class="fa fa-refresh mr-1 "></i> Refresh </a>   	 	
      <a href="./system_users_profile.php" class="medium_btn border border_set btn-primary ml-3 "><i class="fa fa-plus-circle"></i>  Add new</a>
      
    </div>    
      
  </div>
</div> 

<div class="table-responsive  data-tables bg-white" style="margin-top: 0px; padding-bottom: 10px;">

<table class="table table-hover  text-left" id="system_users_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">User Fullnames</th>
             <th scope="col">User Email</th>
             <th scope="col">Tel</th>
             <th scope="col">User Gender</th>
             <th scope="col">User No</th>
             <th scope="col">About</th>
             <th scope="col">Ref Id</th>
             <th scope="col">Regdate</th>
             <th scope="col">Last Seen</th>
             <th scope="col">Hive Site Id</th>
             <th scope="col">Hive Site Name</th>
             <th scope="col">Auth Token</th>
             <th scope="col">Token Status</th>
             <th scope="col">Token Expiring In</th>

		   </tr>
	    </thead>
	    <tbody>
      <?php 
          $default_system_users_profile="./system_users_profile.php";
          if(isset($system_users_profile))
          {
          $default_system_users_profile=$system_users_profile;
          } 
          
          $default_system_users_listing="./system_users_list.php";
          if(isset($system_users_listing))
          {
          $default_system_users_listing=$system_users_listing;
          } 
          
          $default_system_users_show_edit_btn="yes";
          if(isset($system_users_show_edit_btn))
          {
          $default_system_users_show_edit_btn=$system_users_show_edit_btn;
          } 
      	
          echo drop_css();
        
          $i=0;

		  
          
        //<--outloop-dope-->
 
 	   foreach($system_users_list_query["data"] as $listsystem_users_result)
    	{
        
        $i++;
		
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_system_users_show_edit_btn=="yes"){
          $edit_drop_link=magic_link($default_system_users_profile.'?system_users_uptoken='.base64_encode($listsystem_users_result["primkey"]).'', '<i class="fa fa-edit"></i> View More', '');
          }
          
           //{{edit_drop_link}}
           if($default_system_users_show_edit_btn=="yes")
           {
            $delete_drop_link=magic_link($default_system_users_profile.'?after_delete='.base64_encode(magic_current_url()).'&system_users_uptoken='.base64_encode($listsystem_users_result["primkey"]).'&deletesystem_users','<i class="fa fa-trash"></i> Delete', '');
		   }
	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr>
              <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
            <td><?php
            
            $file_type_image=magic_if_image($listsystem_users_result["user_pic"]);
            if($file_type_image=='Yes' || $listsystem_users_result["user_pic"]==""){ ?>           
            <img src="<?php  $system_users_img=$listsystem_users_result["user_pic"];  if($system_users_img!=""){ echo $media_roots["superauth"].$system_users_img;}else{ echo $mep_app_logo; }?>" class="shadow-sm" style="width:40px; height:40px; border-radius:20%;"/>
            <?php }else{?>
                <i class="fa fa-paperclip text-primary" style="font-size:40px;"></i>
            <?php }?>
            </td>
                         <td scope="col"><span title="<?php echo $listsystem_users_result["name"] ?>"><?php echo magic_strip_if($listsystem_users_result["name"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["email"] ?>"><?php echo magic_strip_if($listsystem_users_result["email"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["tel"] ?>"><?php echo magic_strip_if($listsystem_users_result["tel"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["user_gender"] ?>"><?php echo magic_strip_if($listsystem_users_result["user_gender"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["user_no"] ?>"><?php echo magic_strip_if($listsystem_users_result["user_no"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["about"] ?>"><?php echo magic_strip_if($listsystem_users_result["about"],70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["ref_id"] ?>"><?php echo magic_strip_if($listsystem_users_result["ref_id"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["regdate"] ?>"><?php echo magic_strip_if($listsystem_users_result["regdate"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["last_seen"] ?>"><?php echo magic_strip_if($listsystem_users_result["last_seen"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["hive_site_id"] ?>"><?php echo magic_strip_if($listsystem_users_result["hive_site_id"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["hive_site_name"] ?>"><?php echo magic_strip_if($listsystem_users_result["hive_site_name"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["auth_token"] ?>"><?php echo magic_strip_if($listsystem_users_result["auth_token"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["token_status"] ?>"><?php echo magic_strip_if($listsystem_users_result["token_status"], 70, 70);?></span></td>
             <td scope="col"><span title="<?php echo $listsystem_users_result["token_expiring_in"] ?>"><?php echo magic_strip_if($listsystem_users_result["token_expiring_in"], 70, 70);?></span></td>

			</tr>
       <?php }?>

          <tr>
          <th></th>
          <th></th>
                       <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>

          </tr>
  <!--add_new_row_here-->
	    </tbody>
	    </table>
             <?php if($i==0){?>
            <h6 class="col-md-12 text-center p-3 mb-5 text-muted"><i class="fa fa-search"></i> Sorry, no system users records found</h6>
            <div class="col-md-12 text-center mt-4">
            	<?php $search_system_users_class="ml-0"; if($default_system_users_show_edit_btn=="yes"){
                $search_system_users_class="ml-4";
                ?>
            	<a href="<?php echo $default_system_users_profile ?>" class="medium_btn border border_set btn-white "><i class="fa fa-plus-circle"></i>  Add new </a>
                <?php }?>
            	<a href="<?php echo  $default_system_users_listing?>" class="medium_btn border border_set btn-primary <?php echo $search_system_users_class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
            </div>
          <?php }?>
         <?php echo mosy_paginate_ui($system_users_list_query["page_count"], $datalimit, "qsystem_users_token","skip")?>
        </div>
        </div>
        
       
<!-- ================== Start Feature Footer Section ========================== -------->
<section class="hive_footer_section">

 <script type="text/javascript">

 </script>  
<input type="hidden" id="system_users_uptoken" name="system_users_uptoken" value="<?php echo base64_encode($system_users_uptoken) ?>"/>
</section>
 <!-- ================== End Feature Footer Section ========================== -------->
 
 <!-- ================== End Feature Section========================== -------->
