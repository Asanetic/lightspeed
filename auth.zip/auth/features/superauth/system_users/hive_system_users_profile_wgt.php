<div class="p-0 col-md-12 text-center ">
 <!-- ================== Start Feature Section========================== -------->
 
 <!-- ================== Feature Header Section ========================== -------->
  <section class="hive_header_section">
  <?php    
   include("./hive_control/superauth/system_users/profile_query_lines_system_users.php")
  ?>

   
    </section>

   <!-- ================== Feature Header Section ========================== -------->
   	<div class="col-md-12 rounded text-left p-0 mb-3  p-lg-5 mb-4 rounded shadow-sm bg-white  border">   
         <h3 class="col-md-12 title_text text-left p-0 mb-3">System Users Profile</h3>                                  
         <div class="col-md-12 pt-3 p-0" id=""></div>
  
          <div class="row justify-content-end m-0 p-0 col-md-12 border-bottom p-3 bg-light rounded_medium" id="">
          
            <div class="col-md-4 text-left p-0 " id="">
            
             <a href="./system_users_list.php" class="text-info"><i class="fa fa-arrow-left"></i> Back to list</a>
            
            </div>
            <div class="col-md-8 p-0 text-right " id="">            
			    
          <?php if(isset($_GET["system_users_uptoken"])){?>
          <a href="./system_users_profile.php" class="medium_btn btn-primary border border_set  p-2 mb-3"><i class="fa fa-plus-circle"></i>  Add new</a>
            <?php } if(isset($_GET["system_users_uptoken"]))
            {?>
         <a href="./system_users_profile.php?system_users_uptoken=<?php echo $_GET["system_users_uptoken"];?>&deletesystem_users&after_delete=<?php echo base64_encode("./system_users_list.php");?>" class="medium_btn  border border-danger  text-danger p-2  ml-3 mb-3 ">
              <i class="fa fa-trash"></i> Delete
            </a>
            <?php } ?>              
            </div>
              
          </div>
         <div class="col-md-12 pt-5 p-0" id=""></div>
      
		
     <div class="col-md-12" style="">
       <div class="row justify-content-center m-0 p-0 col-md-12 ">
				            <div class="col-md-3 mr-lg-2 ">
            
                <div class="col-md-12 p-0 text-center mb-3">
                <div class="col-md-12 m-2"><b>User Pic</b></div>
                    <?php 
                          if(getarr_val_($system_users_node, "user_pic")!="") 
                            {
                              $file_type_image=magic_if_image(getarr_val_($system_users_node, "user_pic"));
                                if($file_type_image=='Yes')
                                {?>

                              <img src="<?php if(getarr_val_($system_users_node, "user_pic")=="") { echo $mep_app_logo;}else{ echo $media_roots["superauth"].getarr_val_($system_users_node, "user_pic");}?>" onclick="mosy_img_pop(this.src, 'max-width:100%; max-height:70vh');glass_modal()" class=" cpointer border border_set" style="width:200px; height:200px; border-radius:50%;"/>

                                <?php }else{
                                $actual_file_name=explode("/", getarr_val_($system_users_node, "user_pic"));
                                echo '<a href="'.$media_roots["superauth"].getarr_val_($system_users_node, "user_pic").'" target="_blank" class=""><i class="fa fa-paperclip" style="font-size:70px;"></i> 
                                <br>'.end($actual_file_name).'<hr> <i class="fa fa-download"></i> Download</a>';
                                }
                            }else{?>

                             <img src="<?php if(getarr_val_($system_users_node, "user_pic")=="") { echo $mep_app_logo;}else{ echo $media_roots["superauth"].getarr_val_($system_users_node, "user_pic");}?>" onclick="magic_img_pop(this.src, 'max-width:100%; max-height:70vh');glass_modal()" class=" border border_set" style="width:200px; height:200px; border-radius:50%;"/>

                            <?php } ?>
                                                                         
                
             <div class="col-md-12 pt-3 p-0" id="">          
                <em id="file_name_system_users_user_pic" class="trim_text badge "></em>
             </div>
               
              <label class="text-primary border border_set cpointer medium_btn pr-3 pl-3">
                  <i class="fa fa-upload mr-2"></i> Choose File
                  <input type="file" id="txt_system_users_user_pic" name="txt_system_users_user_pic" style="display: none;" onchange="push_html('file_name_system_users_user_pic', this.value.replace('C:\\fakepath\\', ''))">
              </label>
              
              <?php if(isset($_GET['system_users_uptoken'])){?> 
              <input type="submit" name="btn_upload_system_users_user_pic" class="btn btn-primary mt-2 d-none" value="Upload">
              <?php }?>
              <input type="hidden" name="txt_user_pic" value="<?php echo getarr_val_($system_users_node,  "user_pic");?>">
                </div> 
    
            </div>
            <div class="col-md-8 row justify-content-left m-0  p-0">
               
        <div class="form-group col-md-4">
          <label >User Fullnames</label>
          <input class="form-control" id="txt_name" name="txt_name" value="<?php echo getarr_val_($system_users_node, "name");?>" placeholder="User Fullnames" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >User Email</label>
          <input class="form-control" id="txt_email" name="txt_email" value="<?php echo getarr_val_($system_users_node, "email");?>" placeholder="User Email" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Tel</label>
          <input class="form-control" id="txt_tel" name="txt_tel" value="<?php echo getarr_val_($system_users_node, "tel");?>" placeholder="Tel" type="text">
        </div>

                 <div class="form-group col-md-6">
                   <label >Login Password</label>
                   <input class="form-control" id="txt_login_password" name="txt_login_password" value="<?php echo getarr_val_($system_users_node, "login_password");?>" placeholder="Login Password" type="password">
                   <input type="checkbox"  onclick="show_password('txt_login_password')"> <span class=""><em>Show Password</em></span>
                  </div>
              
 
               <div class="form-group col-md-6">
                 <label >User Gender</label>
                  <select name="txt_user_gender" id="txt_user_gender" class="form-control">
                      <option  value="<?php echo getarr_val_($system_users_node, "user_gender");?>">
                       <?php if(getarr_val_($system_users_node, "user_gender")==""){echo "User Gender";}else{ echo getarr_val_($system_users_node, "user_gender");}?>
                      </option>
                          <option>Male</option>
<option>Female</option>

                   </select>
               </div>

        <div class="form-group col-md-6">
          <label >User No</label>
          <input class="form-control" id="txt_user_no" name="txt_user_no" value="<?php echo getarr_val_($system_users_node, "user_no");?>" placeholder="User No" type="text">
        </div>

            <div class="form-group col-md-12">
              <label >About</label>
              <textarea class="form-control" id="txt_about" name="txt_about" placeholder="About" style="min-height:200px;"><?php echo getarr_val_($system_users_node, "about");?></textarea>
            </div>

        <div class="form-group col-md-6">
          <label >Ref Id</label>
          <input class="form-control" id="txt_ref_id" name="txt_ref_id" value="<?php echo getarr_val_($system_users_node, "ref_id");?>" placeholder="Ref Id" type="text">
        </div>

         <div class="form-group col-md-6">
           <label >Regdate</label>
           <input class="form-control" id="txt_regdate" name="txt_regdate" value="<?php echo date_time_input(getarr_val_($system_users_node, "regdate"), "full");?>" placeholder="Regdate" type="datetime-local">
         </div>

                   <input class="form-control" id="txt_last_seen" name="txt_last_seen" value="<?php echo getarr_val_($system_users_node, "last_seen");?>" placeholder="Last Seen" type="hidden">

        <div class="form-group col-md-6">
          <label >Hive Site Id</label>
          <input class="form-control" id="txt_hive_site_id" name="txt_hive_site_id" value="<?php echo getarr_val_($system_users_node, "hive_site_id");?>" placeholder="Hive Site Id" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Hive Site Name</label>
          <input class="form-control" id="txt_hive_site_name" name="txt_hive_site_name" value="<?php echo getarr_val_($system_users_node, "hive_site_name");?>" placeholder="Hive Site Name" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Auth Token</label>
          <input class="form-control" id="txt_auth_token" name="txt_auth_token" value="<?php echo getarr_val_($system_users_node, "auth_token");?>" placeholder="Auth Token" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Token Status</label>
          <input class="form-control" id="txt_token_status" name="txt_token_status" value="<?php echo getarr_val_($system_users_node, "token_status");?>" placeholder="Token Status" type="text">
        </div>

        <div class="form-group col-md-6">
          <label >Token Expiring In</label>
          <input class="form-control" id="txt_token_expiring_in" name="txt_token_expiring_in" value="<?php echo getarr_val_($system_users_node, "token_expiring_in");?>" placeholder="Token Expiring In" type="text">
        </div>

               
      <div class="col-md-12 text-center">
      <?php if(!isset($_GET['system_users_uptoken'])){?> 
            <button type="submit" id="mpsystem_users_insert_btn" name="mpsystem_users_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET['system_users_uptoken'])) {?>
            <button type="submit" id="mpsystem_users_update_btn" name="mpsystem_users_update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="mpsystem_users_insert_btn" name="mpsystem_users_insert_btn" class="ml-lg-3 mt-lg-0 d-none mt-4 btn border border_set text-dark" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>          
            <?php } ?>
    </div>
  
            </div>
          </div>
      </div>
    </div>

<!-- ================== Feature Footer Section ========================== -------->
<section class="hive_footer_section">
  <?php  ?>

 <script type="text/javascript">

 </script>  
<input type="hidden" id="system_users_uptoken" name="system_users_uptoken" value="<?php echo base64_encode($system_users_uptoken) ?>"/>
</section>
 <!-- ================== Feature Footer Section ========================== -------->
 
 <!-- ================== End Feature Section========================== -------->
