<?php
  include($common_root.'/auth/saconfig.php'); 
  //session monitor script
  $session_sauth_logged_user_id="";
 
  if(isset($_SESSION['session_'.$session_prefix.'_logged_user_id']))
  {
  	$session_sauth_logged_user_id=$_SESSION['session_'.$session_prefix.'_logged_user_id'];
  }
  
  if(!isset($_SESSION["session_".$session_prefix."_logged"]))
  {

      $ref_url_go_to='?ref_url_go_to='.base64_encode(magic_current_url());

      header('location:'.$common_root."auth/".$login_file.$ref_url_go_to.'');

      exit;

  }

$skip__access_denied_arr_files= magic_basename(magic_current_url());

$skip__access_denied_arr = ["userdenied", "userdenied.php", "superadmin_acc_control.php","superadmin_acc_control"];

if (!in_array($skip__access_denied_arr_files, $skip__access_denied_arr)) 
{
 include($common_root.'/auth/sa_access.php');
}
//include('./billingmonitor.php');
  

?>