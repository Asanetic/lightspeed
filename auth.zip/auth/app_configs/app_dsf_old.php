<?php

//global filters to apply to system tables 
$mosy_dsft_=[

  "global_filter"=>""
  
];  

//handle global filter across the entire system on the tbales

function mosy_dsf_custom_filter($tbl_name, $type="", $attributes="", $request_source="")
{
  global $mosy_dsft_;
  
  //handle data sensisitve filters
  $request_table_mdsf_="";
  $request_table_mdsf_qstr_without_where_="";
  $request_table_mdsf_qstr_with_where_="";

  
  $request_table_mdsf_=$mosy_dsft_["global_filter"];
          
  if(isset($mosy_dsft_[$tbl_name]))
  {
   
    $request_table_mdsf_=$mosy_dsft_[$tbl_name];

  }
          
  if($request_table_mdsf_!="")
  {
    $request_table_mdsf_qstr_without_where_=" AND $request_table_mdsf_";
    $request_table_mdsf_qstr_with_where_=" WHERE $request_table_mdsf_";          
          
  }                  
  
  $custom_filter_string="";  
  //retun_with_where
  if($type=="with")
  {
    $custom_filter_string =  mosy_dsf_data_control ($tbl_name, $type, $attributes, $request_table_mdsf_qstr_with_where_);
  }
  
  // and without
  if($type=="without")
  {
    $custom_filter_string = mosy_dsf_data_control ($tbl_name, $type, $attributes, $request_table_mdsf_qstr_without_where_);
  }
  
  
  
  //are we even filtering?? use system data for consistency 
  if($request_source=="dd_group" && in_array($attributes, $mosy_dsft_skip_filters_columns))
  {
    $custom_filter_string="";
    
  }
  
  return $custom_filter_string;
  
}


function mosy_dsf_data_control($tbl_name, $type="", $attributes="", $filter_verdict="")
{
    global $mosy_dsft_;

    return $filter_verdict;
}


//tables with disabled delete 
$mosy_dsft_disable_delete=["system_role_bundles", "system_users","client_list","affiliates","services","withdrawal_requests"];

//Control data control components visibility and attributes 
function mosy_data_component_control($tbl_name, $type="cu", $attributes="")
{
  global $mosy_dsft_disable_delete;
  
  $enabled_status="Enabled";
  
   //Block user deletion    
   $explode_table_name=explode(":", $tbl_name);
   $action_=$type;
  
   if(isset($explode_table_name[1]))
   {
     $tbl_name=$explode_table_name[1];
     $action_=$explode_table_name[0];
   }
  
     if(in_array($tbl_name, $mosy_dsft_disable_delete) && $action_=="delete")
     {
       $enabled_status="Disabled";
     }
   
    
  return $enabled_status;
}


//data action component control 
function mosy_data_component($tbl_name, $type="cu", $attributes="")
{
  $create_update_btns_ = "";
  
  if(!isset($_GET[''.$tbl_name.'_uptoken']))
  {
  
    $create_update_btns_ = '<button type="submit" id="mp'.$tbl_name.'_insert_btn" name="mp'.$tbl_name.'_insert_btn" class="btn btn-primary" >     
    <i class="fa fa-check"></i> Proceed     
   </button>';
    
   }
  
  if(isset($_GET[''.$tbl_name.'_uptoken'])) {
  
    $create_update_btns_= '<button type="submit" id="mp'.$tbl_name.'_update_btn" name="mp'.$tbl_name.'_update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="mp'.$tbl_name.'_insert_btn" name="mpclients_insert_btn" class="ml-lg-3 '.$attributes.' mt-lg-0  mt-4 btn border border_set text-dark" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>';     
  }
  
  
  $final_component_ui="";
 
  //add new link button 
  if($type=="add_new")
  {
    $new_btn_attr=explode(":",$attributes);
    $new_file_name=$new_btn_attr[0];
    $add_new_btn_name=$new_btn_attr[1];
    $add_new_btn_icon=$new_btn_attr[2];
    $class_list_="medium_btn btn-primary border border_set hive_profile_add_new_btn p-2 mb-3 ml-3";
    
    if(isset($new_btn_attr[3]))
    {
      $class_list_=$new_btn_attr[3];
    }
    
    $final_component_ui='             
    <a href="'.$new_file_name.'" class="'.$class_list_.' "><i class="fa fa-'.$add_new_btn_icon.'"></i> '.$add_new_btn_name.'</a>
';
  }
  
  //profile delete button 
  if($type=="delete")
  {
    
    $del_btn_component=explode(":",$attributes);
    $current_file=$del_btn_component[0];
    $after_delete=$del_btn_component[1];
    $deltoken=$del_btn_component[2];
    
  $final_component_ui ='
  
             <a href="'.$current_file.'?'.$tbl_name.'_uptoken='.$deltoken.'&delete'.$tbl_name.'&after_delete='.$after_delete.'" class="medium_btn  border border-danger  text-danger p-2  ml-3 mb-3 hive_profile_nav_del_btn">
                  <i class="fa fa-trash"></i> Delete
             </a>
  ';  
    
        $enabled_status= mosy_data_component_control($tbl_name, $type, $attributes);
      
        if($enabled_status!="Enabled")
        {
         $final_component_ui="";
        }    

 }
  //upload_buttons
  
  if($type=="upload")
  {
              
    $final_component_ui = '<div class="col-md-12 pt-3 p-0" id="">          
                <em id="file_name_'.$tbl_name.'_'.$attributes.'" class="trim_text badge "></em>
             </div>
               
              <label class="text-primary border border_set cpointer medium_btn pr-3 pl-3 bg-white">
                  <i class="fa fa-upload mr-2"></i> Choose File
                  <input type="file" id="txt_'.$tbl_name.'_'.$attributes.'" name="txt_'.$tbl_name.'_'.$attributes.'" style="display: none;" onchange="push_html(\'file_name_'.$tbl_name.'_'.$attributes.'\', this.value.replace(\'C:\\fakepath\\\', \'\'))">
              </label>';
    
        $enabled_status= mosy_data_component_control($tbl_name, $type, $attributes);
      
        if($enabled_status!="Enabled")
        {
         $final_component_ui="";
        }
    
  }
  
  
  //create and update btns 
  if($type=="cu")
  {
    $final_component_ui=$create_update_btns_;
        $enabled_status= mosy_data_component_control($tbl_name, $type, $attributes);
      
        if($enabled_status!="Enabled")
        {
         $final_component_ui="";
        }
    
  }
  
  //handle inputs
  if($type=="input")
  {
    $final_component_ui="";

        $enabled_status= mosy_data_component_control($tbl_name, $type, $attributes);
      
        if($enabled_status!="Enabled")
        {
         $final_component_ui="";
        }
    
  }
  
  
    // Component control request
    if ($type == "component_control") {
        $final_component_ui = $attributes;
      
        $enabled_status= mosy_data_component_control($tbl_name, $type, $attributes);
      
        if($enabled_status!="Enabled")
        {
         $final_component_ui="";
        }
      
    }

  
  //handle js grid crud buttons
  
     if($type=="jsgrid_cu"){
             
       $final_component_ui='<button type="button" id="mp_js_'.$tbl_name.'_insert_btn" style="font-size:12px;" name="mp_js_'.$tbl_name.'_insert_btn" class="medium_btn border border_set btn-primary hive_list_nav_new mosy_msdn" data-mosy_msdn="_madd_'.$tbl_name.'_()" >
              <i class="fa fa-arrow-down"></i> Add new 
              </button>                             
                 <button type="button" id="mp_js_'.$tbl_name.'_clone_btn" style="font-size:12px;" name="mp_js_'.$tbl_name.'_clone_btn" class="medium_btn border border_set bg-whitehive_list_nav_new d-none mosy_msdn" data-mosy_msdn="_madd_'.$tbl_name.'_()">
              <i class="fa fa-arrow-down"></i> Clone 
              </button>

             <button type="button" id="mp_js_'.$tbl_name.'_update_btn" style="font-size:12px;" name="mp_js_'.$tbl_name.'_update_btn" class="medium_btn border border_set ml-lg-3  btn-primary hive_list_nav_new mosy_msdn d-none" data-mosy_msdn="_msave_'.$tbl_name.'_()" > 
                    <i class="fa fa-save"></i> Update             
            </button>';
         
        $enabled_status= mosy_data_component_control($tbl_name, $type, $attributes);
      
        if($enabled_status!="Enabled")
        {
         $final_component_ui="";
        }
       
     }
  
  
  //handle jsgrid_drop down 
  if($type=="jsgrid_drop_down")
  {
    $drop_down_attr=explode(":",$attributes);
    $data_key=$drop_down_attr[0];
    $profile_url=$drop_down_attr[1];
    $skip_edit=$drop_down_attr[2];
    
    $js_edit_dd='     <span class="mosy_msdn"  data-mosy_msdn="new_location(\'./'.$profile_url.'\')"><i class="fa fa-arrow-right"></i> Profile </span>';
    if($skip_edit!="")
    {
      $js_edit_dd="";
    }
    
    $final_component_ui='                                         
     <span class="mosy_msdn"  data-mosy_msdn="_minit_'.$tbl_name.'_(\'{{'.$data_key.'}}\')"><i class="fa fa-edit"></i> Edit </span>
     '.$js_edit_dd.'
     <span class="mosy_msdn"  data-mosy_msdn="_mdrop_'.$tbl_name.'(btoa(\'{{'.$data_key.'}}\'))"><i class="fa fa-trash"></i> Delete </span>

    
    ';
    
        $enabled_status= mosy_data_component_control($tbl_name, $type, $attributes);
      
        if($enabled_status!="Enabled")
        {
         $final_component_ui="";
        }
    
  }
  return $final_component_ui;
  
  
}
?>