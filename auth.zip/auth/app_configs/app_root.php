<?php 
  
$app_root="../";

?>