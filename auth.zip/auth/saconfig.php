<?php
$session_prefix="authmaster5";
$oauth_table="system_users";
$primkey='primkey';


$user_id_col='user_id';
$username='name';
$session_user_mail='email';
$session_user_tel='tel';
$password_col='login_password';

$aftersplash_page=$common_root."authmaster5/sysadmins_list";
$show_reset_link="yes"; // yes || no
$show_create_account="yes";// yes || no

//====Oauth File Routes
$login_file="./login";
$register_file="./register";
$change_password_file="./resetpassword";
$reset_password_file="./resetpassword";
    
//====Oauth File Routes 

///==== login background image path 
$login_bg_img="$common_root/img/loginbg.jpg?v=67eei7";
$login_widget__="hive_login_clear_center_wgt"; // hive_login_center_wgt || hive_login_wgt  || hive_login_clear_center_wgt || hive_login_dark_clear_center_wgt || hive_login_mini_wgt   || hive_login_plain_center_wgt without.php
?>