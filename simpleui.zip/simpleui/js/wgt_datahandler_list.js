
 var doc_nos_list_cols ="primkey:Primkey,dockey:Dockey,user_id:User Id,doc_no:Doc No,file_type:File Type,creation_date:Creation Date,notif_remark:Notif Remark";

 var file_uploads_list_cols ="primkey:Primkey,file_id:File Id,item_id:Item Id,user_id:User Id,file_url:File Url,file_type:File Type,upload_data:Upload Data,notif_remark:Notif Remark";

 var messages_list_cols ="primkey:Primkey,message_id:Message Id,user_email:User Email,user_mobile:User Mobile,message_date:Message Date,message:Message,user_name:User Name,service_id:Service Id,service_name:Service Name";

 var model_list_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,location:Location,orientation:Orientation,haircolor:Haircolor,hips:Hips,bust:Bust,eyes:Eyes,color_complexion:Color Complexion,waist:Waist,verified:Verified,active_state:Active State,user_gender:User Gender,registred_on:Registred On,date_of_birth:Date Of Birth,last_seen:Last Seen,about:About,height:Height,breast_cup:Breast Cup,ethnicity:Ethnicity,weight:Weight,featured:Featured,account_state:Account State,slide_show:Slide Show,services_list:Services List,acc_no:Acc No";

 var mosy_sql_roll_back_list_cols ="primkey:Primkey,roll_bk_key:Roll Bk Key,table_name:Table Name,roll_type:Roll Type,where_str:Where Str,roll_timestamp:Roll Timestamp,value_entries:Value Entries";

 var service_tbl_list_cols ="primkey:Primkey,service_id:Service Id,user_id:User Id,service_name:Service Name";

 var system_admins_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,ref_id:Ref Id,regdate:Regdate,user_no:User No,user_pic:User Pic,user_gender:User Gender,last_seen:Last Seen,about:About";

 var user_traffic_list_cols ="primkey:Primkey,traffic_key:Traffic Key,traffic_date:Traffic Date,user_id:User Id,traffic_type:Traffic Type,notif_remark:Notif Remark";



 var doc_nos_list_nodes=`<tr class="cpointer" onclick="mosy_card('Doc Nos Profile ', doc_nos_input_wgt(doc_nos_js_input,'doc_nos_update_btn:Update:check-circle',''), '');initialize_doc_nos(&quot where primkey='{{primkey}}'&quot;);push_newval('doc_nos_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{user_id}}</td>
<td scope="col">{{doc_no}}</td>
<td scope="col">{{file_type}}</td>
<td scope="col">{{creation_date}}</td>
<td scope="col">{{notif_remark}}</td>
</tr>`;


 var file_uploads_list_nodes=`<tr class="cpointer" onclick="mosy_card('File Uploads Profile ', file_uploads_input_wgt(file_uploads_js_input,'file_uploads_update_btn:Update:check-circle',''), '');initialize_file_uploads(&quot where primkey='{{primkey}}'&quot;);push_newval('file_uploads_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{item_id}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{file_url}}</td>
<td scope="col">{{file_type}}</td>
<td scope="col">{{upload_data}}</td>
<td scope="col">{{notif_remark}}</td>
</tr>`;


 var messages_list_nodes=`<tr class="cpointer" onclick="mosy_card('Messages Profile ', messages_input_wgt(messages_js_input,'messages_update_btn:Update:check-circle',''), '');initialize_messages(&quot where primkey='{{primkey}}'&quot;);push_newval('messages_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{user_email}}</td>
<td scope="col">{{user_mobile}}</td>
<td scope="col">{{message_date}}</td>
<td scope="col">{{message}}</td>
<td scope="col">{{user_name}}</td>
<td scope="col">{{service_id}}</td>
<td scope="col">{{service_name}}</td>
</tr>`;


 var model_list_list_nodes=`<tr class="cpointer" onclick="mosy_card('Model List Profile ', model_list_input_wgt(model_list_js_input,'model_list_update_btn:Update:check-circle',''), '');initialize_model_list(&quot where primkey='{{primkey}}'&quot;);push_newval('model_list_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{location}}</td>
<td scope="col">{{orientation}}</td>
<td scope="col">{{haircolor}}</td>
<td scope="col">{{hips}}</td>
<td scope="col">{{bust}}</td>
<td scope="col">{{eyes}}</td>
<td scope="col">{{color_complexion}}</td>
<td scope="col">{{waist}}</td>
<td scope="col">{{verified}}</td>
<td scope="col">{{active_state}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{registred_on}}</td>
<td scope="col">{{date_of_birth}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
<td scope="col">{{height}}</td>
<td scope="col">{{breast_cup}}</td>
<td scope="col">{{ethnicity}}</td>
<td scope="col">{{weight}}</td>
<td scope="col">{{featured}}</td>
<td scope="col">{{account_state}}</td>
<td scope="col">{{slide_show}}</td>
<td scope="col">{{services_list}}</td>
<td scope="col">{{acc_no}}</td>
</tr>`;


 var mosy_sql_roll_back_list_nodes=`<tr class="cpointer" onclick="mosy_card('Mosy Sql Roll Back Profile ', mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input,'mosy_sql_roll_back_update_btn:Update:check-circle',''), '');initialize_mosy_sql_roll_back(&quot where primkey='{{primkey}}'&quot;);push_newval('mosy_sql_roll_back_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{table_name}}</td>
<td scope="col">{{roll_type}}</td>
<td scope="col">{{where_str}}</td>
<td scope="col">{{roll_timestamp}}</td>
<td scope="col">{{value_entries}}</td>
</tr>`;


 var service_tbl_list_nodes=`<tr class="cpointer" onclick="mosy_card('Service Tbl Profile ', service_tbl_input_wgt(service_tbl_js_input,'service_tbl_update_btn:Update:check-circle',''), '');initialize_service_tbl(&quot where primkey='{{primkey}}'&quot;);push_newval('service_tbl_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{user_id}}</td>
<td scope="col">{{service_name}}</td>
</tr>`;


 var system_admins_list_nodes=`<tr class="cpointer" onclick="mosy_card('System Admins Profile ', system_admins_input_wgt(system_admins_js_input,'system_admins_update_btn:Update:check-circle',''), '');initialize_system_admins(&quot where primkey='{{primkey}}'&quot;);push_newval('system_admins_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{regdate}}</td>
<td scope="col">{{user_no}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
</tr>`;


 var user_traffic_list_nodes=`<tr class="cpointer" onclick="mosy_card('User Traffic Profile ', user_traffic_input_wgt(user_traffic_js_input,'user_traffic_update_btn:Update:check-circle',''), '');initialize_user_traffic(&quot where primkey='{{primkey}}'&quot;);push_newval('user_traffic_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{traffic_date}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{traffic_type}}</td>
<td scope="col">{{notif_remark}}</td>
</tr>`;



        var doc_nos_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="doc_nos_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Id</th>
             <th scope="col">Doc No</th>
             <th scope="col">File Type</th>
             <th scope="col">Creation Date</th>
             <th scope="col">Notif Remark</th>

		   </tr>
	    </thead>
	    <tbody id="doc_nos_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var file_uploads_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="file_uploads_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Item Id</th>
             <th scope="col">User Id</th>
             <th scope="col">File Url</th>
             <th scope="col">File Type</th>
             <th scope="col">Upload Data</th>
             <th scope="col">Notif Remark</th>

		   </tr>
	    </thead>
	    <tbody id="file_uploads_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var messages_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="messages_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Email</th>
             <th scope="col">User Mobile</th>
             <th scope="col">Message Date</th>
             <th scope="col">Message</th>
             <th scope="col">User Name</th>
             <th scope="col">Service Id</th>
             <th scope="col">Service Name</th>

		   </tr>
	    </thead>
	    <tbody id="messages_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var model_list_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="model_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Login Password</th>
             <th scope="col">Location</th>
             <th scope="col">Orientation</th>
             <th scope="col">Haircolor</th>
             <th scope="col">Hips</th>
             <th scope="col">Bust</th>
             <th scope="col">Eyes</th>
             <th scope="col">Color Complexion</th>
             <th scope="col">Waist</th>
             <th scope="col">Verified</th>
             <th scope="col">Active State</th>
             <th scope="col">User Gender</th>
             <th scope="col">Registred On</th>
             <th scope="col">Date Of Birth</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>
             <th scope="col">Height</th>
             <th scope="col">Breast Cup</th>
             <th scope="col">Ethnicity</th>
             <th scope="col">Weight</th>
             <th scope="col">Featured</th>
             <th scope="col">Account State</th>
             <th scope="col">Slide Show</th>
             <th scope="col">Services List</th>
             <th scope="col">Acc No</th>

		   </tr>
	    </thead>
	    <tbody id="model_list_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var mosy_sql_roll_back_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="mosy_sql_roll_back_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Table Name</th>
             <th scope="col">Roll Type</th>
             <th scope="col">Where Str</th>
             <th scope="col">Roll Timestamp</th>
             <th scope="col">Value Entries</th>

		   </tr>
	    </thead>
	    <tbody id="mosy_sql_roll_back_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var service_tbl_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="service_tbl_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Id</th>
             <th scope="col">Service Name</th>

		   </tr>
	    </thead>
	    <tbody id="service_tbl_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var system_admins_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="system_admins_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Login Password</th>
             <th scope="col">Ref Id</th>
             <th scope="col">Regdate</th>
             <th scope="col">User No</th>
             <th scope="col">User Gender</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>

		   </tr>
	    </thead>
	    <tbody id="system_admins_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var user_traffic_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="user_traffic_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Traffic Date</th>
             <th scope="col">User Id</th>
             <th scope="col">Traffic Type</th>
             <th scope="col">Notif Remark</th>

		   </tr>
	    </thead>
	    <tbody id="user_traffic_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
