
 var config_list_cols ="primkey:Primkey,signature:Signature,shop_name:Shop Name,mobile:Mobile,email:Email,branch:Branch,location:Location,logo:Logo,license_key:License Key,created_at:Created At,updated_at:Updated At";

 var customers_list_cols ="primkey:Primkey,customer_id:Customer Id,customer_name:Customer Name,user_pic:User Pic,borrowing_score:Borrowing Score,phone:Phone,email:Email,gender:Gender,dob:Dob,id_no:Id No,created_at:Created At";

 var daily_sales_list_cols ="primkey:Primkey,sale_id:Sale Id,item_id:Item Id,item_code:Item Code,quantity:Quantity,selling_price:Selling Price,totals:Totals,item_name:Item Name,item_description:Item Description,sold_by:Sold By,shop_location:Shop Location,receipt_no:Receipt No,invoice_no:Invoice No,payment_mode:Payment Mode,customer_id:Customer Id,sales_date:Sales Date,sale_signature:Sale Signature,sale_state:Sale State,sale_type:Sale Type,tax_type:Tax Type,tax_value:Tax Value,tax_amount:Tax Amount,tax_rate:Tax Rate,amount_paid:Amount Paid,payment_ref:Payment Ref,buying_price:Buying Price,filter_date:Filter Date,customer_name:Customer Name,receipt_total:Receipt Total,receipt_balance:Receipt Balance,order_payment:Order Payment,margin_price:Margin Price";

 var expenses_list_list_cols ="primkey:Primkey,expense_key:Expense Key,expense_title:Expense Title,expense_amount:Expense Amount,expense_date:Expense Date,expense_remark:Expense Remark";

 var mosy_sql_roll_back_list_cols ="primkey:Primkey,roll_bk_key:Roll Bk Key,table_name:Table Name,roll_type:Roll Type,where_str:Where Str,roll_timestamp:Roll Timestamp,value_entries:Value Entries";

 var receipt_nos_list_cols ="primkey:Primkey,sales_date:Sales Date,amount:Amount,sold_by:Sold By,customer_id:Customer Id";

 var stock_history_list_cols ="primkey:Primkey,stock_key_sign:Stock Key Sign,item_id:Item Id,item_code:Item Code,quantity:Quantity,buying_price:Buying Price,selling_price:Selling Price,stock_alert:Stock Alert,tax_type:Tax Type,tax_rate:Tax Rate,tax_amount:Tax Amount,item_name:Item Name,item_description:Item Description,supplier:Supplier,shop_location:Shop Location,receipt_no:Receipt No,invoice_no:Invoice No,payment_mode:Payment Mode,inventory_date:Inventory Date,selling_price_n_tax:Selling Price N Tax,total_buying_price:Total Buying Price,margin_price:Margin Price,total_units:Total Units,unit_per_dz:Unit Per Dz,signature:Signature,invoice_amount:Invoice Amount,invoice_amount_paid:Invoice Amount Paid,invoice_bal_amount:Invoice Bal Amount";

 var stock_list_list_cols ="primkey:Primkey,item_id:Item Id,item_code:Item Code,item_name:Item Name,item_description:Item Description,buying_price:Buying Price,selling_price:Selling Price,quantity:Quantity,stock_alert:Stock Alert,tax_type:Tax Type,tax_rate:Tax Rate,tax_amount:Tax Amount,shop_location:Shop Location,receipt_no:Receipt No,invoice_no:Invoice No,payment_mode:Payment Mode,selling_price_n_tax:Selling Price N Tax,margin_price:Margin Price";

 var suppliers_list_cols ="primkey:Primkey,supplier_id:Supplier Id,vendor_no:Vendor No,specialization:Specialization,name:Name,phone:Phone,email:Email,postal_address:Postal Address,physical_address:Physical Address,website:Website,user_pic:User Pic,created_at:Created At";

 var suppliers_invoice_list_cols ="primkey:Primkey,data_id:Data Id,stock_amount:Stock Amount,supplier_id:Supplier Id,receipt_id:Receipt Id,invoice_no:Invoice No,stock_data:Stock Data,amount_paid:Amount Paid,stock_balance:Stock Balance,user_id:User Id,item_id:Item Id,purchase_amt:Purchase Amt";

 var users_tbl_list_cols ="primkey:Primkey,user_id:User Id,user_name:User Name,user_email:User Email,user_mobile:User Mobile,employee_id:Employee Id,national_id:National Id,login_name:Login Name,role:Role,login_password:Login Password,account_state:Account State,date_signed:Date Signed,user_pic:User Pic,last_seen:Last Seen";



 var config_list_nodes=`<tr class="cpointer" onclick="mosy_card('Config Profile ', config_input_wgt(config_js_input,'config_update_btn:Update:check-circle',''), '');initialize_config(&quot where primkey='{{primkey}}'&quot;);push_newval('config_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{shop_name}}</td>
<td scope="col">{{mobile}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{branch}}</td>
<td scope="col">{{location}}</td>
<td scope="col">{{logo}}</td>
<td scope="col">{{license_key}}</td>
<td scope="col">{{created_at}}</td>
<td scope="col">{{updated_at}}</td>
</tr>`;


 var customers_list_nodes=`<tr class="cpointer" onclick="mosy_card('Customers Profile ', customers_input_wgt(customers_js_input,'customers_update_btn:Update:check-circle',''), '');initialize_customers(&quot where primkey='{{primkey}}'&quot;);push_newval('customers_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{customer_name}}</td>
<td scope="col">{{borrowing_score}}</td>
<td scope="col">{{phone}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{gender}}</td>
<td scope="col">{{dob}}</td>
<td scope="col">{{id_no}}</td>
<td scope="col">{{created_at}}</td>
</tr>`;


 var daily_sales_list_nodes=`<tr class="cpointer" onclick="mosy_card('Daily Sales Profile ', daily_sales_input_wgt(daily_sales_js_input,'daily_sales_update_btn:Update:check-circle',''), '');initialize_daily_sales(&quot where primkey='{{primkey}}'&quot;);push_newval('daily_sales_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{item_id}}</td>
<td scope="col">{{item_code}}</td>
<td scope="col">{{quantity}}</td>
<td scope="col">{{selling_price}}</td>
<td scope="col">{{totals}}</td>
<td scope="col">{{item_name}}</td>
<td scope="col">{{item_description}}</td>
<td scope="col">{{sold_by}}</td>
<td scope="col">{{shop_location}}</td>
<td scope="col">{{receipt_no}}</td>
<td scope="col">{{invoice_no}}</td>
<td scope="col">{{payment_mode}}</td>
<td scope="col">{{customer_id}}</td>
<td scope="col">{{sales_date}}</td>
<td scope="col">{{sale_signature}}</td>
<td scope="col">{{sale_state}}</td>
<td scope="col">{{sale_type}}</td>
<td scope="col">{{tax_type}}</td>
<td scope="col">{{tax_value}}</td>
<td scope="col">{{tax_amount}}</td>
<td scope="col">{{tax_rate}}</td>
<td scope="col">{{amount_paid}}</td>
<td scope="col">{{payment_ref}}</td>
<td scope="col">{{buying_price}}</td>
<td scope="col">{{filter_date}}</td>
<td scope="col">{{customer_name}}</td>
<td scope="col">{{receipt_total}}</td>
<td scope="col">{{receipt_balance}}</td>
<td scope="col">{{order_payment}}</td>
<td scope="col">{{margin_price}}</td>
</tr>`;


 var expenses_list_list_nodes=`<tr class="cpointer" onclick="mosy_card('Expenses List Profile ', expenses_list_input_wgt(expenses_list_js_input,'expenses_list_update_btn:Update:check-circle',''), '');initialize_expenses_list(&quot where primkey='{{primkey}}'&quot;);push_newval('expenses_list_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{expense_title}}</td>
<td scope="col">{{expense_amount}}</td>
<td scope="col">{{expense_date}}</td>
<td scope="col">{{expense_remark}}</td>
</tr>`;


 var mosy_sql_roll_back_list_nodes=`<tr class="cpointer" onclick="mosy_card('Mosy Sql Roll Back Profile ', mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input,'mosy_sql_roll_back_update_btn:Update:check-circle',''), '');initialize_mosy_sql_roll_back(&quot where primkey='{{primkey}}'&quot;);push_newval('mosy_sql_roll_back_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{table_name}}</td>
<td scope="col">{{roll_type}}</td>
<td scope="col">{{where_str}}</td>
<td scope="col">{{roll_timestamp}}</td>
<td scope="col">{{value_entries}}</td>
</tr>`;


 var receipt_nos_list_nodes=`<tr class="cpointer" onclick="mosy_card('Receipt Nos Profile ', receipt_nos_input_wgt(receipt_nos_js_input,'receipt_nos_update_btn:Update:check-circle',''), '');initialize_receipt_nos(&quot where primkey='{{primkey}}'&quot;);push_newval('receipt_nos_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{amount}}</td>
<td scope="col">{{sold_by}}</td>
<td scope="col">{{customer_id}}</td>
</tr>`;


 var stock_history_list_nodes=`<tr class="cpointer" onclick="mosy_card('Stock History Profile ', stock_history_input_wgt(stock_history_js_input,'stock_history_update_btn:Update:check-circle',''), '');initialize_stock_history(&quot where primkey='{{primkey}}'&quot;);push_newval('stock_history_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{item_id}}</td>
<td scope="col">{{item_code}}</td>
<td scope="col">{{quantity}}</td>
<td scope="col">{{buying_price}}</td>
<td scope="col">{{selling_price}}</td>
<td scope="col">{{stock_alert}}</td>
<td scope="col">{{tax_type}}</td>
<td scope="col">{{tax_rate}}</td>
<td scope="col">{{tax_amount}}</td>
<td scope="col">{{item_name}}</td>
<td scope="col">{{item_description}}</td>
<td scope="col">{{supplier}}</td>
<td scope="col">{{shop_location}}</td>
<td scope="col">{{receipt_no}}</td>
<td scope="col">{{invoice_no}}</td>
<td scope="col">{{payment_mode}}</td>
<td scope="col">{{inventory_date}}</td>
<td scope="col">{{selling_price_n_tax}}</td>
<td scope="col">{{total_buying_price}}</td>
<td scope="col">{{margin_price}}</td>
<td scope="col">{{total_units}}</td>
<td scope="col">{{unit_per_dz}}</td>
<td scope="col">{{signature}}</td>
<td scope="col">{{invoice_amount}}</td>
<td scope="col">{{invoice_amount_paid}}</td>
<td scope="col">{{invoice_bal_amount}}</td>
</tr>`;


 var stock_list_list_nodes=`<tr class="cpointer" onclick="mosy_card('Stock List Profile ', stock_list_input_wgt(stock_list_js_input,'stock_list_update_btn:Update:check-circle',''), '');initialize_stock_list(&quot where primkey='{{primkey}}'&quot;);push_newval('stock_list_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{item_code}}</td>
<td scope="col">{{item_name}}</td>
<td scope="col">{{item_description}}</td>
<td scope="col">{{buying_price}}</td>
<td scope="col">{{selling_price}}</td>
<td scope="col">{{quantity}}</td>
<td scope="col">{{stock_alert}}</td>
<td scope="col">{{tax_type}}</td>
<td scope="col">{{tax_rate}}</td>
<td scope="col">{{tax_amount}}</td>
<td scope="col">{{shop_location}}</td>
<td scope="col">{{receipt_no}}</td>
<td scope="col">{{invoice_no}}</td>
<td scope="col">{{payment_mode}}</td>
<td scope="col">{{selling_price_n_tax}}</td>
<td scope="col">{{margin_price}}</td>
</tr>`;


 var suppliers_list_nodes=`<tr class="cpointer" onclick="mosy_card('Suppliers Profile ', suppliers_input_wgt(suppliers_js_input,'suppliers_update_btn:Update:check-circle',''), '');initialize_suppliers(&quot where primkey='{{primkey}}'&quot;);push_newval('suppliers_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{vendor_no}}</td>
<td scope="col">{{specialization}}</td>
<td scope="col">{{name}}</td>
<td scope="col">{{phone}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{postal_address}}</td>
<td scope="col">{{physical_address}}</td>
<td scope="col">{{website}}</td>
<td scope="col">{{created_at}}</td>
</tr>`;


 var suppliers_invoice_list_nodes=`<tr class="cpointer" onclick="mosy_card('Suppliers Invoice Profile ', suppliers_invoice_input_wgt(suppliers_invoice_js_input,'suppliers_invoice_update_btn:Update:check-circle',''), '');initialize_suppliers_invoice(&quot where primkey='{{primkey}}'&quot;);push_newval('suppliers_invoice_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{stock_amount}}</td>
<td scope="col">{{supplier_id}}</td>
<td scope="col">{{receipt_id}}</td>
<td scope="col">{{invoice_no}}</td>
<td scope="col">{{stock_data}}</td>
<td scope="col">{{amount_paid}}</td>
<td scope="col">{{stock_balance}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{item_id}}</td>
<td scope="col">{{purchase_amt}}</td>
</tr>`;


 var users_tbl_list_nodes=`<tr class="cpointer" onclick="mosy_card('Users Tbl Profile ', users_tbl_input_wgt(users_tbl_js_input,'users_tbl_update_btn:Update:check-circle',''), '');initialize_users_tbl(&quot where primkey='{{primkey}}'&quot;);push_newval('users_tbl_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{user_name}}</td>
<td scope="col">{{user_email}}</td>
<td scope="col">{{user_mobile}}</td>
<td scope="col">{{employee_id}}</td>
<td scope="col">{{national_id}}</td>
<td scope="col">{{login_name}}</td>
<td scope="col">{{role}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{account_state}}</td>
<td scope="col">{{date_signed}}</td>
<td scope="col">{{last_seen}}</td>
</tr>`;



        var config_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="config_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Shop Name</th>
             <th scope="col">Mobile</th>
             <th scope="col">Email</th>
             <th scope="col">Branch</th>
             <th scope="col">Location</th>
             <th scope="col">Logo</th>
             <th scope="col">License Key</th>
             <th scope="col">Created At</th>
             <th scope="col">Updated At</th>

		   </tr>
	    </thead>
	    <tbody id="config_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var customers_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="customers_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Customer Name</th>
             <th scope="col">Borrowing Score</th>
             <th scope="col">Phone</th>
             <th scope="col">Email</th>
             <th scope="col">Gender</th>
             <th scope="col">Dob</th>
             <th scope="col">Id No</th>
             <th scope="col">Created At</th>

		   </tr>
	    </thead>
	    <tbody id="customers_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var daily_sales_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="daily_sales_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Item Id</th>
             <th scope="col">Item Code</th>
             <th scope="col">Quantity</th>
             <th scope="col">Selling Price</th>
             <th scope="col">Totals</th>
             <th scope="col">Item Name</th>
             <th scope="col">Item Description</th>
             <th scope="col">Sold By</th>
             <th scope="col">Shop Location</th>
             <th scope="col">Receipt No</th>
             <th scope="col">Invoice No</th>
             <th scope="col">Payment Mode</th>
             <th scope="col">Customer Id</th>
             <th scope="col">Sales Date</th>
             <th scope="col">Sale Signature</th>
             <th scope="col">Sale State</th>
             <th scope="col">Sale Type</th>
             <th scope="col">Tax Type</th>
             <th scope="col">Tax Value</th>
             <th scope="col">Tax Amount</th>
             <th scope="col">Tax Rate</th>
             <th scope="col">Amount Paid</th>
             <th scope="col">Payment Ref</th>
             <th scope="col">Buying Price</th>
             <th scope="col">Filter Date</th>
             <th scope="col">Customer Name</th>
             <th scope="col">Receipt Total</th>
             <th scope="col">Receipt Balance</th>
             <th scope="col">Order Payment</th>
             <th scope="col">Margin Price</th>

		   </tr>
	    </thead>
	    <tbody id="daily_sales_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var expenses_list_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="expenses_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Expense Title</th>
             <th scope="col">Expense Amount</th>
             <th scope="col">Expense Date</th>
             <th scope="col">Expense Remark</th>

		   </tr>
	    </thead>
	    <tbody id="expenses_list_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var mosy_sql_roll_back_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="mosy_sql_roll_back_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Table Name</th>
             <th scope="col">Roll Type</th>
             <th scope="col">Where Str</th>
             <th scope="col">Roll Timestamp</th>
             <th scope="col">Value Entries</th>

		   </tr>
	    </thead>
	    <tbody id="mosy_sql_roll_back_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var receipt_nos_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="receipt_nos_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Amount</th>
             <th scope="col">Sold By</th>
             <th scope="col">Customer Id</th>

		   </tr>
	    </thead>
	    <tbody id="receipt_nos_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var stock_history_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="stock_history_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Item Id</th>
             <th scope="col">Item Code</th>
             <th scope="col">Quantity</th>
             <th scope="col">Buying Price</th>
             <th scope="col">Selling Price</th>
             <th scope="col">Stock Alert</th>
             <th scope="col">Tax Type</th>
             <th scope="col">Tax Rate</th>
             <th scope="col">Tax Amount</th>
             <th scope="col">Item Name</th>
             <th scope="col">Item Description</th>
             <th scope="col">Supplier</th>
             <th scope="col">Shop Location</th>
             <th scope="col">Receipt No</th>
             <th scope="col">Invoice No</th>
             <th scope="col">Payment Mode</th>
             <th scope="col">Inventory Date</th>
             <th scope="col">Selling Price N Tax</th>
             <th scope="col">Total Buying Price</th>
             <th scope="col">Margin Price</th>
             <th scope="col">Total Units</th>
             <th scope="col">Unit Per Dz</th>
             <th scope="col">Signature</th>
             <th scope="col">Invoice Amount</th>
             <th scope="col">Invoice Amount Paid</th>
             <th scope="col">Invoice Bal Amount</th>

		   </tr>
	    </thead>
	    <tbody id="stock_history_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var stock_list_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="stock_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Item Code</th>
             <th scope="col">Item Name</th>
             <th scope="col">Item Description</th>
             <th scope="col">Buying Price</th>
             <th scope="col">Selling Price</th>
             <th scope="col">Quantity</th>
             <th scope="col">Stock Alert</th>
             <th scope="col">Tax Type</th>
             <th scope="col">Tax Rate</th>
             <th scope="col">Tax Amount</th>
             <th scope="col">Shop Location</th>
             <th scope="col">Receipt No</th>
             <th scope="col">Invoice No</th>
             <th scope="col">Payment Mode</th>
             <th scope="col">Selling Price N Tax</th>
             <th scope="col">Margin Price</th>

		   </tr>
	    </thead>
	    <tbody id="stock_list_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var suppliers_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="suppliers_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Vendor No</th>
             <th scope="col">Specialization</th>
             <th scope="col">Name</th>
             <th scope="col">Phone</th>
             <th scope="col">Email</th>
             <th scope="col">Postal Address</th>
             <th scope="col">Physical Address</th>
             <th scope="col">Website</th>
             <th scope="col">Created At</th>

		   </tr>
	    </thead>
	    <tbody id="suppliers_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var suppliers_invoice_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="suppliers_invoice_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Stock Amount</th>
             <th scope="col">Supplier Id</th>
             <th scope="col">Receipt Id</th>
             <th scope="col">Invoice No</th>
             <th scope="col">Stock Data</th>
             <th scope="col">Amount Paid</th>
             <th scope="col">Stock Balance</th>
             <th scope="col">User Id</th>
             <th scope="col">Item Id</th>
             <th scope="col">Purchase Amt</th>

		   </tr>
	    </thead>
	    <tbody id="suppliers_invoice_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var users_tbl_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="users_tbl_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">User Name</th>
             <th scope="col">User Email</th>
             <th scope="col">User Mobile</th>
             <th scope="col">Employee Id</th>
             <th scope="col">National Id</th>
             <th scope="col">Login Name</th>
             <th scope="col">Role</th>
             <th scope="col">Login Password</th>
             <th scope="col">Account State</th>
             <th scope="col">Date Signed</th>
             <th scope="col">Last Seen</th>

		   </tr>
	    </thead>
	    <tbody id="users_tbl_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
