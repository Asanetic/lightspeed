 
//===============Start Mosy queries-============ 

    //Start get  config Data ===============
    
      function get_config(config_colstr, config_filter_col, config_cols, config_node_function_name, config_callback_function_string, config_ui_tag, config_pagination)
      {
        mosyflex_sel("config", config_colstr, config_filter_col , config_cols, config_node_function_name, config_callback_function_string, config_ui_tag, config_pagination);
        
      }
    //End get  config Data ===============

    //Start insert  config Data ===============

	function add_config(config_cols, config_vals, config_callback_function_string)
    {
		
        mosyajax_create_data("config", config_cols, config_vals, config_callback_function_string);
     }
     
    //End insert  config Data ===============

    
    //Start update  config Data ===============

    function update_config(config_update_str, config_where_str, config_callback_function_string){
    
		mosyajax_update("config", config_update_str, config_where_str, config_callback_function_string)
    
    }
    //end  update  config Data ===============

	//Start drop  config Data ===============
    function config_drop(config_where_str, config_callback_function_string)
    {
        mosyajax_drop("config", config_where_str, config_callback_function_string)

    }
	//End drop  config Data ===============
    
    function initialize_config(qstr="", config_callback_function_string="")
    {
    
    ///alert(qstr);
      var config_token_query =qstr;
      if(qstr=="")
      {
       var config_token_query_param="";
       var config_js_uptoken=mosy_get_param("config_uptoken");
       //alert(config_js_uptoken);
       if(config_js_uptoken!==undefined)
       {
       
        config_token_query_param = atob(config_js_uptoken);
       }
        config_token_query = " where primkey='"+(config_token_query_param)+"'";
        
           if (document.getElementById("config_uptoken") !==null) {
           	if(document.getElementById("config_uptoken").value!="")
            {
            
            var config_atob_tbl_key =atob(document.getElementById("config_uptoken").value);
            
                   
            config_token_query = " where primkey='"+(config_atob_tbl_key)+"'";

            }
           }
      }
      
      var config_push_ui_data_to =config_callback_function_string;
      if(config_callback_function_string=="")
      {
      config_push_ui_data_to = "add_config_ui_data";
      }
                
      console.log(config_token_query+" -- "+config_js_uptoken);

	  //alert(config_push_ui_data_to);

     get_config("*", config_token_query, "primkey", "blackhole", config_push_ui_data_to, "");
    }
    
    function add_config_ui_data(config_server_resp) 
    {
    
    ///alert(config_server_resp);
    
    var json_decoded_str=JSON.parse(config_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load config data on the fly ==============
    
	var gft_config_str="(signature LIKE '%{{qconfig}}%' OR  shop_name LIKE '%{{qconfig}}%' OR  mobile LIKE '%{{qconfig}}%' OR  email LIKE '%{{qconfig}}%' OR  branch LIKE '%{{qconfig}}%' OR  location LIKE '%{{qconfig}}%' OR  logo LIKE '%{{qconfig}}%' OR  license_key LIKE '%{{qconfig}}%' OR  created_at LIKE '%{{qconfig}}%' OR  updated_at LIKE '%{{qconfig}}%')";
    
    function  gft_config(qconfig_str)
    {
        	var clean_config_filter_str=gft_config_str.replace(/{{qconfig}}/g, magic_clean_str(qconfig_str));
            
            return  clean_config_filter_str;

    }
    
    function load_config(config_qstr, config_where_str, config_ret_cols, config_user_function, config_result_function, config_data_tray)
    {
    
    var fconfig_result_function="push_result";
      
    if(config_result_function!="")
    {
          var fconfig_result_function=config_result_function;

    }
    	var clean_config_filter_str=gft_config_str.replace(/{{qconfig}}/g, magic_clean_str(config_qstr));
        
        var fconfig_where_str=" where "+clean_config_filter_str;

    if(config_where_str!="")
    {
          var fconfig_where_str=" "+config_where_str;

    }
       
      get_config("*", fconfig_where_str, config_ret_cols, config_user_function, fconfig_result_function, config_data_tray);
      
    }
    ///=============== load config data on the fly ==============


 ///=quick load 
 
function qkload_config(qstr, push_fun="", ui_card="", and_query="", additional_cols="", config_pagination="")
{

	var config_list_nodes_str=config_list_nodes;
  
   if(ui_card!="")
   {
      config_list_nodes_str=ui_card;
   }
   
   var config_qret_fun="push_grid_result:config_tbl_list";
   
   if(push_fun!="")
   {
    config_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_config("*", ajaxw+" ("+gft_config(qstr)+") "+combined_query+"  order by primkey desc ", config_list_cols+additional_cols_str, "",config_qret_fun, "c=>"+config_list_nodes_str, config_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_config(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_config("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qconfig_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_config("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_config("*", config_token_query, "primkey", "blackhole", config_push_ui_data_to, "");
    

}



//sum 

function sum_config(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_config("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function config_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "config_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function config_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "config_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function config_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteconfig&config_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_config_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('config')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  customers Data ===============
    
      function get_customers(customers_colstr, customers_filter_col, customers_cols, customers_node_function_name, customers_callback_function_string, customers_ui_tag, customers_pagination)
      {
        mosyflex_sel("customers", customers_colstr, customers_filter_col , customers_cols, customers_node_function_name, customers_callback_function_string, customers_ui_tag, customers_pagination);
        
      }
    //End get  customers Data ===============

    //Start insert  customers Data ===============

	function add_customers(customers_cols, customers_vals, customers_callback_function_string)
    {
		
        mosyajax_create_data("customers", customers_cols, customers_vals, customers_callback_function_string);
     }
     
    //End insert  customers Data ===============

    
    //Start update  customers Data ===============

    function update_customers(customers_update_str, customers_where_str, customers_callback_function_string){
    
		mosyajax_update("customers", customers_update_str, customers_where_str, customers_callback_function_string)
    
    }
    //end  update  customers Data ===============

	//Start drop  customers Data ===============
    function customers_drop(customers_where_str, customers_callback_function_string)
    {
        mosyajax_drop("customers", customers_where_str, customers_callback_function_string)

    }
	//End drop  customers Data ===============
    
    function initialize_customers(qstr="", customers_callback_function_string="")
    {
    
    ///alert(qstr);
      var customers_token_query =qstr;
      if(qstr=="")
      {
       var customers_token_query_param="";
       var customers_js_uptoken=mosy_get_param("customers_uptoken");
       //alert(customers_js_uptoken);
       if(customers_js_uptoken!==undefined)
       {
       
        customers_token_query_param = atob(customers_js_uptoken);
       }
        customers_token_query = " where primkey='"+(customers_token_query_param)+"'";
        
           if (document.getElementById("customers_uptoken") !==null) {
           	if(document.getElementById("customers_uptoken").value!="")
            {
            
            var customers_atob_tbl_key =atob(document.getElementById("customers_uptoken").value);
            
                   
            customers_token_query = " where primkey='"+(customers_atob_tbl_key)+"'";

            }
           }
      }
      
      var customers_push_ui_data_to =customers_callback_function_string;
      if(customers_callback_function_string=="")
      {
      customers_push_ui_data_to = "add_customers_ui_data";
      }
                
      console.log(customers_token_query+" -- "+customers_js_uptoken);

	  //alert(customers_push_ui_data_to);

     get_customers("*", customers_token_query, "primkey", "blackhole", customers_push_ui_data_to, "");
    }
    
    function add_customers_ui_data(customers_server_resp) 
    {
    
    ///alert(customers_server_resp);
    
    var json_decoded_str=JSON.parse(customers_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load customers data on the fly ==============
    
	var gft_customers_str="(customer_id LIKE '%{{qcustomers}}%' OR  customer_name LIKE '%{{qcustomers}}%' OR  user_pic LIKE '%{{qcustomers}}%' OR  borrowing_score LIKE '%{{qcustomers}}%' OR  phone LIKE '%{{qcustomers}}%' OR  email LIKE '%{{qcustomers}}%' OR  gender LIKE '%{{qcustomers}}%' OR  dob LIKE '%{{qcustomers}}%' OR  id_no LIKE '%{{qcustomers}}%' OR  created_at LIKE '%{{qcustomers}}%')";
    
    function  gft_customers(qcustomers_str)
    {
        	var clean_customers_filter_str=gft_customers_str.replace(/{{qcustomers}}/g, magic_clean_str(qcustomers_str));
            
            return  clean_customers_filter_str;

    }
    
    function load_customers(customers_qstr, customers_where_str, customers_ret_cols, customers_user_function, customers_result_function, customers_data_tray)
    {
    
    var fcustomers_result_function="push_result";
      
    if(customers_result_function!="")
    {
          var fcustomers_result_function=customers_result_function;

    }
    	var clean_customers_filter_str=gft_customers_str.replace(/{{qcustomers}}/g, magic_clean_str(customers_qstr));
        
        var fcustomers_where_str=" where "+clean_customers_filter_str;

    if(customers_where_str!="")
    {
          var fcustomers_where_str=" "+customers_where_str;

    }
       
      get_customers("*", fcustomers_where_str, customers_ret_cols, customers_user_function, fcustomers_result_function, customers_data_tray);
      
    }
    ///=============== load customers data on the fly ==============


 ///=quick load 
 
function qkload_customers(qstr, push_fun="", ui_card="", and_query="", additional_cols="", customers_pagination="")
{

	var customers_list_nodes_str=customers_list_nodes;
  
   if(ui_card!="")
   {
      customers_list_nodes_str=ui_card;
   }
   
   var customers_qret_fun="push_grid_result:customers_tbl_list";
   
   if(push_fun!="")
   {
    customers_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_customers("*", ajaxw+" ("+gft_customers(qstr)+") "+combined_query+"  order by primkey desc ", customers_list_cols+additional_cols_str, "",customers_qret_fun, "c=>"+customers_list_nodes_str, customers_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_customers(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_customers("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qcustomers_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_customers("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_customers("*", customers_token_query, "primkey", "blackhole", customers_push_ui_data_to, "");
    

}



//sum 

function sum_customers(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_customers("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function customers_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "customers_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function customers_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "customers_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function customers_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletecustomers&customers_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_customers_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('customers')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  daily_sales Data ===============
    
      function get_daily_sales(daily_sales_colstr, daily_sales_filter_col, daily_sales_cols, daily_sales_node_function_name, daily_sales_callback_function_string, daily_sales_ui_tag, daily_sales_pagination)
      {
        mosyflex_sel("daily_sales", daily_sales_colstr, daily_sales_filter_col , daily_sales_cols, daily_sales_node_function_name, daily_sales_callback_function_string, daily_sales_ui_tag, daily_sales_pagination);
        
      }
    //End get  daily_sales Data ===============

    //Start insert  daily_sales Data ===============

	function add_daily_sales(daily_sales_cols, daily_sales_vals, daily_sales_callback_function_string)
    {
		
        mosyajax_create_data("daily_sales", daily_sales_cols, daily_sales_vals, daily_sales_callback_function_string);
     }
     
    //End insert  daily_sales Data ===============

    
    //Start update  daily_sales Data ===============

    function update_daily_sales(daily_sales_update_str, daily_sales_where_str, daily_sales_callback_function_string){
    
		mosyajax_update("daily_sales", daily_sales_update_str, daily_sales_where_str, daily_sales_callback_function_string)
    
    }
    //end  update  daily_sales Data ===============

	//Start drop  daily_sales Data ===============
    function daily_sales_drop(daily_sales_where_str, daily_sales_callback_function_string)
    {
        mosyajax_drop("daily_sales", daily_sales_where_str, daily_sales_callback_function_string)

    }
	//End drop  daily_sales Data ===============
    
    function initialize_daily_sales(qstr="", daily_sales_callback_function_string="")
    {
    
    ///alert(qstr);
      var daily_sales_token_query =qstr;
      if(qstr=="")
      {
       var daily_sales_token_query_param="";
       var daily_sales_js_uptoken=mosy_get_param("daily_sales_uptoken");
       //alert(daily_sales_js_uptoken);
       if(daily_sales_js_uptoken!==undefined)
       {
       
        daily_sales_token_query_param = atob(daily_sales_js_uptoken);
       }
        daily_sales_token_query = " where primkey='"+(daily_sales_token_query_param)+"'";
        
           if (document.getElementById("daily_sales_uptoken") !==null) {
           	if(document.getElementById("daily_sales_uptoken").value!="")
            {
            
            var daily_sales_atob_tbl_key =atob(document.getElementById("daily_sales_uptoken").value);
            
                   
            daily_sales_token_query = " where primkey='"+(daily_sales_atob_tbl_key)+"'";

            }
           }
      }
      
      var daily_sales_push_ui_data_to =daily_sales_callback_function_string;
      if(daily_sales_callback_function_string=="")
      {
      daily_sales_push_ui_data_to = "add_daily_sales_ui_data";
      }
                
      console.log(daily_sales_token_query+" -- "+daily_sales_js_uptoken);

	  //alert(daily_sales_push_ui_data_to);

     get_daily_sales("*", daily_sales_token_query, "primkey", "blackhole", daily_sales_push_ui_data_to, "");
    }
    
    function add_daily_sales_ui_data(daily_sales_server_resp) 
    {
    
    ///alert(daily_sales_server_resp);
    
    var json_decoded_str=JSON.parse(daily_sales_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load daily_sales data on the fly ==============
    
	var gft_daily_sales_str="(sale_id LIKE '%{{qdaily_sales}}%' OR  item_id LIKE '%{{qdaily_sales}}%' OR  item_code LIKE '%{{qdaily_sales}}%' OR  quantity LIKE '%{{qdaily_sales}}%' OR  selling_price LIKE '%{{qdaily_sales}}%' OR  totals LIKE '%{{qdaily_sales}}%' OR  item_name LIKE '%{{qdaily_sales}}%' OR  item_description LIKE '%{{qdaily_sales}}%' OR  sold_by LIKE '%{{qdaily_sales}}%' OR  shop_location LIKE '%{{qdaily_sales}}%' OR  receipt_no LIKE '%{{qdaily_sales}}%' OR  invoice_no LIKE '%{{qdaily_sales}}%' OR  payment_mode LIKE '%{{qdaily_sales}}%' OR  customer_id LIKE '%{{qdaily_sales}}%' OR  sales_date LIKE '%{{qdaily_sales}}%' OR  sale_signature LIKE '%{{qdaily_sales}}%' OR  sale_state LIKE '%{{qdaily_sales}}%' OR  sale_type LIKE '%{{qdaily_sales}}%' OR  tax_type LIKE '%{{qdaily_sales}}%' OR  tax_value LIKE '%{{qdaily_sales}}%' OR  tax_amount LIKE '%{{qdaily_sales}}%' OR  tax_rate LIKE '%{{qdaily_sales}}%' OR  amount_paid LIKE '%{{qdaily_sales}}%' OR  payment_ref LIKE '%{{qdaily_sales}}%' OR  buying_price LIKE '%{{qdaily_sales}}%' OR  filter_date LIKE '%{{qdaily_sales}}%' OR  customer_name LIKE '%{{qdaily_sales}}%' OR  receipt_total LIKE '%{{qdaily_sales}}%' OR  receipt_balance LIKE '%{{qdaily_sales}}%' OR  order_payment LIKE '%{{qdaily_sales}}%' OR  margin_price LIKE '%{{qdaily_sales}}%')";
    
    function  gft_daily_sales(qdaily_sales_str)
    {
        	var clean_daily_sales_filter_str=gft_daily_sales_str.replace(/{{qdaily_sales}}/g, magic_clean_str(qdaily_sales_str));
            
            return  clean_daily_sales_filter_str;

    }
    
    function load_daily_sales(daily_sales_qstr, daily_sales_where_str, daily_sales_ret_cols, daily_sales_user_function, daily_sales_result_function, daily_sales_data_tray)
    {
    
    var fdaily_sales_result_function="push_result";
      
    if(daily_sales_result_function!="")
    {
          var fdaily_sales_result_function=daily_sales_result_function;

    }
    	var clean_daily_sales_filter_str=gft_daily_sales_str.replace(/{{qdaily_sales}}/g, magic_clean_str(daily_sales_qstr));
        
        var fdaily_sales_where_str=" where "+clean_daily_sales_filter_str;

    if(daily_sales_where_str!="")
    {
          var fdaily_sales_where_str=" "+daily_sales_where_str;

    }
       
      get_daily_sales("*", fdaily_sales_where_str, daily_sales_ret_cols, daily_sales_user_function, fdaily_sales_result_function, daily_sales_data_tray);
      
    }
    ///=============== load daily_sales data on the fly ==============


 ///=quick load 
 
function qkload_daily_sales(qstr, push_fun="", ui_card="", and_query="", additional_cols="", daily_sales_pagination="")
{

	var daily_sales_list_nodes_str=daily_sales_list_nodes;
  
   if(ui_card!="")
   {
      daily_sales_list_nodes_str=ui_card;
   }
   
   var daily_sales_qret_fun="push_grid_result:daily_sales_tbl_list";
   
   if(push_fun!="")
   {
    daily_sales_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_daily_sales("*", ajaxw+" ("+gft_daily_sales(qstr)+") "+combined_query+"  order by primkey desc ", daily_sales_list_cols+additional_cols_str, "",daily_sales_qret_fun, "c=>"+daily_sales_list_nodes_str, daily_sales_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_daily_sales(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_daily_sales("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qdaily_sales_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_daily_sales("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_daily_sales("*", daily_sales_token_query, "primkey", "blackhole", daily_sales_push_ui_data_to, "");
    

}



//sum 

function sum_daily_sales(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_daily_sales("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function daily_sales_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "daily_sales_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function daily_sales_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "daily_sales_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function daily_sales_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletedaily_sales&daily_sales_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_daily_sales_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('daily_sales')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  expenses_list Data ===============
    
      function get_expenses_list(expenses_list_colstr, expenses_list_filter_col, expenses_list_cols, expenses_list_node_function_name, expenses_list_callback_function_string, expenses_list_ui_tag, expenses_list_pagination)
      {
        mosyflex_sel("expenses_list", expenses_list_colstr, expenses_list_filter_col , expenses_list_cols, expenses_list_node_function_name, expenses_list_callback_function_string, expenses_list_ui_tag, expenses_list_pagination);
        
      }
    //End get  expenses_list Data ===============

    //Start insert  expenses_list Data ===============

	function add_expenses_list(expenses_list_cols, expenses_list_vals, expenses_list_callback_function_string)
    {
		
        mosyajax_create_data("expenses_list", expenses_list_cols, expenses_list_vals, expenses_list_callback_function_string);
     }
     
    //End insert  expenses_list Data ===============

    
    //Start update  expenses_list Data ===============

    function update_expenses_list(expenses_list_update_str, expenses_list_where_str, expenses_list_callback_function_string){
    
		mosyajax_update("expenses_list", expenses_list_update_str, expenses_list_where_str, expenses_list_callback_function_string)
    
    }
    //end  update  expenses_list Data ===============

	//Start drop  expenses_list Data ===============
    function expenses_list_drop(expenses_list_where_str, expenses_list_callback_function_string)
    {
        mosyajax_drop("expenses_list", expenses_list_where_str, expenses_list_callback_function_string)

    }
	//End drop  expenses_list Data ===============
    
    function initialize_expenses_list(qstr="", expenses_list_callback_function_string="")
    {
    
    ///alert(qstr);
      var expenses_list_token_query =qstr;
      if(qstr=="")
      {
       var expenses_list_token_query_param="";
       var expenses_list_js_uptoken=mosy_get_param("expenses_list_uptoken");
       //alert(expenses_list_js_uptoken);
       if(expenses_list_js_uptoken!==undefined)
       {
       
        expenses_list_token_query_param = atob(expenses_list_js_uptoken);
       }
        expenses_list_token_query = " where primkey='"+(expenses_list_token_query_param)+"'";
        
           if (document.getElementById("expenses_list_uptoken") !==null) {
           	if(document.getElementById("expenses_list_uptoken").value!="")
            {
            
            var expenses_list_atob_tbl_key =atob(document.getElementById("expenses_list_uptoken").value);
            
                   
            expenses_list_token_query = " where primkey='"+(expenses_list_atob_tbl_key)+"'";

            }
           }
      }
      
      var expenses_list_push_ui_data_to =expenses_list_callback_function_string;
      if(expenses_list_callback_function_string=="")
      {
      expenses_list_push_ui_data_to = "add_expenses_list_ui_data";
      }
                
      console.log(expenses_list_token_query+" -- "+expenses_list_js_uptoken);

	  //alert(expenses_list_push_ui_data_to);

     get_expenses_list("*", expenses_list_token_query, "primkey", "blackhole", expenses_list_push_ui_data_to, "");
    }
    
    function add_expenses_list_ui_data(expenses_list_server_resp) 
    {
    
    ///alert(expenses_list_server_resp);
    
    var json_decoded_str=JSON.parse(expenses_list_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load expenses_list data on the fly ==============
    
	var gft_expenses_list_str="(expense_key LIKE '%{{qexpenses_list}}%' OR  expense_title LIKE '%{{qexpenses_list}}%' OR  expense_amount LIKE '%{{qexpenses_list}}%' OR  expense_date LIKE '%{{qexpenses_list}}%' OR  expense_remark LIKE '%{{qexpenses_list}}%')";
    
    function  gft_expenses_list(qexpenses_list_str)
    {
        	var clean_expenses_list_filter_str=gft_expenses_list_str.replace(/{{qexpenses_list}}/g, magic_clean_str(qexpenses_list_str));
            
            return  clean_expenses_list_filter_str;

    }
    
    function load_expenses_list(expenses_list_qstr, expenses_list_where_str, expenses_list_ret_cols, expenses_list_user_function, expenses_list_result_function, expenses_list_data_tray)
    {
    
    var fexpenses_list_result_function="push_result";
      
    if(expenses_list_result_function!="")
    {
          var fexpenses_list_result_function=expenses_list_result_function;

    }
    	var clean_expenses_list_filter_str=gft_expenses_list_str.replace(/{{qexpenses_list}}/g, magic_clean_str(expenses_list_qstr));
        
        var fexpenses_list_where_str=" where "+clean_expenses_list_filter_str;

    if(expenses_list_where_str!="")
    {
          var fexpenses_list_where_str=" "+expenses_list_where_str;

    }
       
      get_expenses_list("*", fexpenses_list_where_str, expenses_list_ret_cols, expenses_list_user_function, fexpenses_list_result_function, expenses_list_data_tray);
      
    }
    ///=============== load expenses_list data on the fly ==============


 ///=quick load 
 
function qkload_expenses_list(qstr, push_fun="", ui_card="", and_query="", additional_cols="", expenses_list_pagination="")
{

	var expenses_list_list_nodes_str=expenses_list_list_nodes;
  
   if(ui_card!="")
   {
      expenses_list_list_nodes_str=ui_card;
   }
   
   var expenses_list_qret_fun="push_grid_result:expenses_list_tbl_list";
   
   if(push_fun!="")
   {
    expenses_list_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_expenses_list("*", ajaxw+" ("+gft_expenses_list(qstr)+") "+combined_query+"  order by primkey desc ", expenses_list_list_cols+additional_cols_str, "",expenses_list_qret_fun, "c=>"+expenses_list_list_nodes_str, expenses_list_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_expenses_list(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_expenses_list("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qexpenses_list_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_expenses_list("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_expenses_list("*", expenses_list_token_query, "primkey", "blackhole", expenses_list_push_ui_data_to, "");
    

}



//sum 

function sum_expenses_list(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_expenses_list("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function expenses_list_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "expenses_list_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function expenses_list_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "expenses_list_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function expenses_list_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteexpenses_list&expenses_list_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_expenses_list_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('expenses_list')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  mosy_sql_roll_back Data ===============
    
      function get_mosy_sql_roll_back(mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col, mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination)
      {
        mosyflex_sel("mosy_sql_roll_back", mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col , mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination);
        
      }
    //End get  mosy_sql_roll_back Data ===============

    //Start insert  mosy_sql_roll_back Data ===============

	function add_mosy_sql_roll_back(mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string)
    {
		
        mosyajax_create_data("mosy_sql_roll_back", mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string);
     }
     
    //End insert  mosy_sql_roll_back Data ===============

    
    //Start update  mosy_sql_roll_back Data ===============

    function update_mosy_sql_roll_back(mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string){
    
		mosyajax_update("mosy_sql_roll_back", mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    
    }
    //end  update  mosy_sql_roll_back Data ===============

	//Start drop  mosy_sql_roll_back Data ===============
    function mosy_sql_roll_back_drop(mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    {
        mosyajax_drop("mosy_sql_roll_back", mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)

    }
	//End drop  mosy_sql_roll_back Data ===============
    
    function initialize_mosy_sql_roll_back(qstr="", mosy_sql_roll_back_callback_function_string="")
    {
    
    ///alert(qstr);
      var mosy_sql_roll_back_token_query =qstr;
      if(qstr=="")
      {
       var mosy_sql_roll_back_token_query_param="";
       var mosy_sql_roll_back_js_uptoken=mosy_get_param("mosy_sql_roll_back_uptoken");
       //alert(mosy_sql_roll_back_js_uptoken);
       if(mosy_sql_roll_back_js_uptoken!==undefined)
       {
       
        mosy_sql_roll_back_token_query_param = atob(mosy_sql_roll_back_js_uptoken);
       }
        mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_token_query_param)+"'";
        
           if (document.getElementById("mosy_sql_roll_back_uptoken") !==null) {
           	if(document.getElementById("mosy_sql_roll_back_uptoken").value!="")
            {
            
            var mosy_sql_roll_back_atob_tbl_key =atob(document.getElementById("mosy_sql_roll_back_uptoken").value);
            
                   
            mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_atob_tbl_key)+"'";

            }
           }
      }
      
      var mosy_sql_roll_back_push_ui_data_to =mosy_sql_roll_back_callback_function_string;
      if(mosy_sql_roll_back_callback_function_string=="")
      {
      mosy_sql_roll_back_push_ui_data_to = "add_mosy_sql_roll_back_ui_data";
      }
                
      console.log(mosy_sql_roll_back_token_query+" -- "+mosy_sql_roll_back_js_uptoken);

	  //alert(mosy_sql_roll_back_push_ui_data_to);

     get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    }
    
    function add_mosy_sql_roll_back_ui_data(mosy_sql_roll_back_server_resp) 
    {
    
    ///alert(mosy_sql_roll_back_server_resp);
    
    var json_decoded_str=JSON.parse(mosy_sql_roll_back_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load mosy_sql_roll_back data on the fly ==============
    
	var gft_mosy_sql_roll_back_str="(roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
    
    function  gft_mosy_sql_roll_back(qmosy_sql_roll_back_str)
    {
        	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(qmosy_sql_roll_back_str));
            
            return  clean_mosy_sql_roll_back_filter_str;

    }
    
    function load_mosy_sql_roll_back(mosy_sql_roll_back_qstr, mosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, mosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray)
    {
    
    var fmosy_sql_roll_back_result_function="push_result";
      
    if(mosy_sql_roll_back_result_function!="")
    {
          var fmosy_sql_roll_back_result_function=mosy_sql_roll_back_result_function;

    }
    	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(mosy_sql_roll_back_qstr));
        
        var fmosy_sql_roll_back_where_str=" where "+clean_mosy_sql_roll_back_filter_str;

    if(mosy_sql_roll_back_where_str!="")
    {
          var fmosy_sql_roll_back_where_str=" "+mosy_sql_roll_back_where_str;

    }
       
      get_mosy_sql_roll_back("*", fmosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, fmosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray);
      
    }
    ///=============== load mosy_sql_roll_back data on the fly ==============


 ///=quick load 
 
function qkload_mosy_sql_roll_back(qstr, push_fun="", ui_card="", and_query="", additional_cols="", mosy_sql_roll_back_pagination="")
{

	var mosy_sql_roll_back_list_nodes_str=mosy_sql_roll_back_list_nodes;
  
   if(ui_card!="")
   {
      mosy_sql_roll_back_list_nodes_str=ui_card;
   }
   
   var mosy_sql_roll_back_qret_fun="push_grid_result:mosy_sql_roll_back_tbl_list";
   
   if(push_fun!="")
   {
    mosy_sql_roll_back_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_mosy_sql_roll_back("*", ajaxw+" ("+gft_mosy_sql_roll_back(qstr)+") "+combined_query+"  order by primkey desc ", mosy_sql_roll_back_list_cols+additional_cols_str, "",mosy_sql_roll_back_qret_fun, "c=>"+mosy_sql_roll_back_list_nodes_str, mosy_sql_roll_back_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_mosy_sql_roll_back(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_mosy_sql_roll_back("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmosy_sql_roll_back_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_mosy_sql_roll_back("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    

}



//sum 

function sum_mosy_sql_roll_back(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_mosy_sql_roll_back("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function mosy_sql_roll_back_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function mosy_sql_roll_back_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function mosy_sql_roll_back_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemosy_sql_roll_back&mosy_sql_roll_back_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_mosy_sql_roll_back_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('mosy_sql_roll_back')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  receipt_nos Data ===============
    
      function get_receipt_nos(receipt_nos_colstr, receipt_nos_filter_col, receipt_nos_cols, receipt_nos_node_function_name, receipt_nos_callback_function_string, receipt_nos_ui_tag, receipt_nos_pagination)
      {
        mosyflex_sel("receipt_nos", receipt_nos_colstr, receipt_nos_filter_col , receipt_nos_cols, receipt_nos_node_function_name, receipt_nos_callback_function_string, receipt_nos_ui_tag, receipt_nos_pagination);
        
      }
    //End get  receipt_nos Data ===============

    //Start insert  receipt_nos Data ===============

	function add_receipt_nos(receipt_nos_cols, receipt_nos_vals, receipt_nos_callback_function_string)
    {
		
        mosyajax_create_data("receipt_nos", receipt_nos_cols, receipt_nos_vals, receipt_nos_callback_function_string);
     }
     
    //End insert  receipt_nos Data ===============

    
    //Start update  receipt_nos Data ===============

    function update_receipt_nos(receipt_nos_update_str, receipt_nos_where_str, receipt_nos_callback_function_string){
    
		mosyajax_update("receipt_nos", receipt_nos_update_str, receipt_nos_where_str, receipt_nos_callback_function_string)
    
    }
    //end  update  receipt_nos Data ===============

	//Start drop  receipt_nos Data ===============
    function receipt_nos_drop(receipt_nos_where_str, receipt_nos_callback_function_string)
    {
        mosyajax_drop("receipt_nos", receipt_nos_where_str, receipt_nos_callback_function_string)

    }
	//End drop  receipt_nos Data ===============
    
    function initialize_receipt_nos(qstr="", receipt_nos_callback_function_string="")
    {
    
    ///alert(qstr);
      var receipt_nos_token_query =qstr;
      if(qstr=="")
      {
       var receipt_nos_token_query_param="";
       var receipt_nos_js_uptoken=mosy_get_param("receipt_nos_uptoken");
       //alert(receipt_nos_js_uptoken);
       if(receipt_nos_js_uptoken!==undefined)
       {
       
        receipt_nos_token_query_param = atob(receipt_nos_js_uptoken);
       }
        receipt_nos_token_query = " where primkey='"+(receipt_nos_token_query_param)+"'";
        
           if (document.getElementById("receipt_nos_uptoken") !==null) {
           	if(document.getElementById("receipt_nos_uptoken").value!="")
            {
            
            var receipt_nos_atob_tbl_key =atob(document.getElementById("receipt_nos_uptoken").value);
            
                   
            receipt_nos_token_query = " where primkey='"+(receipt_nos_atob_tbl_key)+"'";

            }
           }
      }
      
      var receipt_nos_push_ui_data_to =receipt_nos_callback_function_string;
      if(receipt_nos_callback_function_string=="")
      {
      receipt_nos_push_ui_data_to = "add_receipt_nos_ui_data";
      }
                
      console.log(receipt_nos_token_query+" -- "+receipt_nos_js_uptoken);

	  //alert(receipt_nos_push_ui_data_to);

     get_receipt_nos("*", receipt_nos_token_query, "primkey", "blackhole", receipt_nos_push_ui_data_to, "");
    }
    
    function add_receipt_nos_ui_data(receipt_nos_server_resp) 
    {
    
    ///alert(receipt_nos_server_resp);
    
    var json_decoded_str=JSON.parse(receipt_nos_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load receipt_nos data on the fly ==============
    
	var gft_receipt_nos_str="(sales_date LIKE '%{{qreceipt_nos}}%' OR  amount LIKE '%{{qreceipt_nos}}%' OR  sold_by LIKE '%{{qreceipt_nos}}%' OR  customer_id LIKE '%{{qreceipt_nos}}%')";
    
    function  gft_receipt_nos(qreceipt_nos_str)
    {
        	var clean_receipt_nos_filter_str=gft_receipt_nos_str.replace(/{{qreceipt_nos}}/g, magic_clean_str(qreceipt_nos_str));
            
            return  clean_receipt_nos_filter_str;

    }
    
    function load_receipt_nos(receipt_nos_qstr, receipt_nos_where_str, receipt_nos_ret_cols, receipt_nos_user_function, receipt_nos_result_function, receipt_nos_data_tray)
    {
    
    var freceipt_nos_result_function="push_result";
      
    if(receipt_nos_result_function!="")
    {
          var freceipt_nos_result_function=receipt_nos_result_function;

    }
    	var clean_receipt_nos_filter_str=gft_receipt_nos_str.replace(/{{qreceipt_nos}}/g, magic_clean_str(receipt_nos_qstr));
        
        var freceipt_nos_where_str=" where "+clean_receipt_nos_filter_str;

    if(receipt_nos_where_str!="")
    {
          var freceipt_nos_where_str=" "+receipt_nos_where_str;

    }
       
      get_receipt_nos("*", freceipt_nos_where_str, receipt_nos_ret_cols, receipt_nos_user_function, freceipt_nos_result_function, receipt_nos_data_tray);
      
    }
    ///=============== load receipt_nos data on the fly ==============


 ///=quick load 
 
function qkload_receipt_nos(qstr, push_fun="", ui_card="", and_query="", additional_cols="", receipt_nos_pagination="")
{

	var receipt_nos_list_nodes_str=receipt_nos_list_nodes;
  
   if(ui_card!="")
   {
      receipt_nos_list_nodes_str=ui_card;
   }
   
   var receipt_nos_qret_fun="push_grid_result:receipt_nos_tbl_list";
   
   if(push_fun!="")
   {
    receipt_nos_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_receipt_nos("*", ajaxw+" ("+gft_receipt_nos(qstr)+") "+combined_query+"  order by primkey desc ", receipt_nos_list_cols+additional_cols_str, "",receipt_nos_qret_fun, "c=>"+receipt_nos_list_nodes_str, receipt_nos_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_receipt_nos(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_receipt_nos("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qreceipt_nos_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_receipt_nos("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_receipt_nos("*", receipt_nos_token_query, "primkey", "blackhole", receipt_nos_push_ui_data_to, "");
    

}



//sum 

function sum_receipt_nos(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_receipt_nos("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function receipt_nos_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "receipt_nos_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function receipt_nos_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "receipt_nos_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function receipt_nos_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletereceipt_nos&receipt_nos_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_receipt_nos_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('receipt_nos')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  stock_history Data ===============
    
      function get_stock_history(stock_history_colstr, stock_history_filter_col, stock_history_cols, stock_history_node_function_name, stock_history_callback_function_string, stock_history_ui_tag, stock_history_pagination)
      {
        mosyflex_sel("stock_history", stock_history_colstr, stock_history_filter_col , stock_history_cols, stock_history_node_function_name, stock_history_callback_function_string, stock_history_ui_tag, stock_history_pagination);
        
      }
    //End get  stock_history Data ===============

    //Start insert  stock_history Data ===============

	function add_stock_history(stock_history_cols, stock_history_vals, stock_history_callback_function_string)
    {
		
        mosyajax_create_data("stock_history", stock_history_cols, stock_history_vals, stock_history_callback_function_string);
     }
     
    //End insert  stock_history Data ===============

    
    //Start update  stock_history Data ===============

    function update_stock_history(stock_history_update_str, stock_history_where_str, stock_history_callback_function_string){
    
		mosyajax_update("stock_history", stock_history_update_str, stock_history_where_str, stock_history_callback_function_string)
    
    }
    //end  update  stock_history Data ===============

	//Start drop  stock_history Data ===============
    function stock_history_drop(stock_history_where_str, stock_history_callback_function_string)
    {
        mosyajax_drop("stock_history", stock_history_where_str, stock_history_callback_function_string)

    }
	//End drop  stock_history Data ===============
    
    function initialize_stock_history(qstr="", stock_history_callback_function_string="")
    {
    
    ///alert(qstr);
      var stock_history_token_query =qstr;
      if(qstr=="")
      {
       var stock_history_token_query_param="";
       var stock_history_js_uptoken=mosy_get_param("stock_history_uptoken");
       //alert(stock_history_js_uptoken);
       if(stock_history_js_uptoken!==undefined)
       {
       
        stock_history_token_query_param = atob(stock_history_js_uptoken);
       }
        stock_history_token_query = " where primkey='"+(stock_history_token_query_param)+"'";
        
           if (document.getElementById("stock_history_uptoken") !==null) {
           	if(document.getElementById("stock_history_uptoken").value!="")
            {
            
            var stock_history_atob_tbl_key =atob(document.getElementById("stock_history_uptoken").value);
            
                   
            stock_history_token_query = " where primkey='"+(stock_history_atob_tbl_key)+"'";

            }
           }
      }
      
      var stock_history_push_ui_data_to =stock_history_callback_function_string;
      if(stock_history_callback_function_string=="")
      {
      stock_history_push_ui_data_to = "add_stock_history_ui_data";
      }
                
      console.log(stock_history_token_query+" -- "+stock_history_js_uptoken);

	  //alert(stock_history_push_ui_data_to);

     get_stock_history("*", stock_history_token_query, "primkey", "blackhole", stock_history_push_ui_data_to, "");
    }
    
    function add_stock_history_ui_data(stock_history_server_resp) 
    {
    
    ///alert(stock_history_server_resp);
    
    var json_decoded_str=JSON.parse(stock_history_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load stock_history data on the fly ==============
    
	var gft_stock_history_str="(stock_key_sign LIKE '%{{qstock_history}}%' OR  item_id LIKE '%{{qstock_history}}%' OR  item_code LIKE '%{{qstock_history}}%' OR  quantity LIKE '%{{qstock_history}}%' OR  buying_price LIKE '%{{qstock_history}}%' OR  selling_price LIKE '%{{qstock_history}}%' OR  stock_alert LIKE '%{{qstock_history}}%' OR  tax_type LIKE '%{{qstock_history}}%' OR  tax_rate LIKE '%{{qstock_history}}%' OR  tax_amount LIKE '%{{qstock_history}}%' OR  item_name LIKE '%{{qstock_history}}%' OR  item_description LIKE '%{{qstock_history}}%' OR  supplier LIKE '%{{qstock_history}}%' OR  shop_location LIKE '%{{qstock_history}}%' OR  receipt_no LIKE '%{{qstock_history}}%' OR  invoice_no LIKE '%{{qstock_history}}%' OR  payment_mode LIKE '%{{qstock_history}}%' OR  inventory_date LIKE '%{{qstock_history}}%' OR  selling_price_n_tax LIKE '%{{qstock_history}}%' OR  total_buying_price LIKE '%{{qstock_history}}%' OR  margin_price LIKE '%{{qstock_history}}%' OR  total_units LIKE '%{{qstock_history}}%' OR  unit_per_dz LIKE '%{{qstock_history}}%' OR  signature LIKE '%{{qstock_history}}%' OR  invoice_amount LIKE '%{{qstock_history}}%' OR  invoice_amount_paid LIKE '%{{qstock_history}}%' OR  invoice_bal_amount LIKE '%{{qstock_history}}%')";
    
    function  gft_stock_history(qstock_history_str)
    {
        	var clean_stock_history_filter_str=gft_stock_history_str.replace(/{{qstock_history}}/g, magic_clean_str(qstock_history_str));
            
            return  clean_stock_history_filter_str;

    }
    
    function load_stock_history(stock_history_qstr, stock_history_where_str, stock_history_ret_cols, stock_history_user_function, stock_history_result_function, stock_history_data_tray)
    {
    
    var fstock_history_result_function="push_result";
      
    if(stock_history_result_function!="")
    {
          var fstock_history_result_function=stock_history_result_function;

    }
    	var clean_stock_history_filter_str=gft_stock_history_str.replace(/{{qstock_history}}/g, magic_clean_str(stock_history_qstr));
        
        var fstock_history_where_str=" where "+clean_stock_history_filter_str;

    if(stock_history_where_str!="")
    {
          var fstock_history_where_str=" "+stock_history_where_str;

    }
       
      get_stock_history("*", fstock_history_where_str, stock_history_ret_cols, stock_history_user_function, fstock_history_result_function, stock_history_data_tray);
      
    }
    ///=============== load stock_history data on the fly ==============


 ///=quick load 
 
function qkload_stock_history(qstr, push_fun="", ui_card="", and_query="", additional_cols="", stock_history_pagination="")
{

	var stock_history_list_nodes_str=stock_history_list_nodes;
  
   if(ui_card!="")
   {
      stock_history_list_nodes_str=ui_card;
   }
   
   var stock_history_qret_fun="push_grid_result:stock_history_tbl_list";
   
   if(push_fun!="")
   {
    stock_history_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_stock_history("*", ajaxw+" ("+gft_stock_history(qstr)+") "+combined_query+"  order by primkey desc ", stock_history_list_cols+additional_cols_str, "",stock_history_qret_fun, "c=>"+stock_history_list_nodes_str, stock_history_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_stock_history(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_stock_history("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qstock_history_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_stock_history("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_stock_history("*", stock_history_token_query, "primkey", "blackhole", stock_history_push_ui_data_to, "");
    

}



//sum 

function sum_stock_history(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_stock_history("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function stock_history_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "stock_history_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function stock_history_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "stock_history_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function stock_history_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletestock_history&stock_history_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_stock_history_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('stock_history')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  stock_list Data ===============
    
      function get_stock_list(stock_list_colstr, stock_list_filter_col, stock_list_cols, stock_list_node_function_name, stock_list_callback_function_string, stock_list_ui_tag, stock_list_pagination)
      {
        mosyflex_sel("stock_list", stock_list_colstr, stock_list_filter_col , stock_list_cols, stock_list_node_function_name, stock_list_callback_function_string, stock_list_ui_tag, stock_list_pagination);
        
      }
    //End get  stock_list Data ===============

    //Start insert  stock_list Data ===============

	function add_stock_list(stock_list_cols, stock_list_vals, stock_list_callback_function_string)
    {
		
        mosyajax_create_data("stock_list", stock_list_cols, stock_list_vals, stock_list_callback_function_string);
     }
     
    //End insert  stock_list Data ===============

    
    //Start update  stock_list Data ===============

    function update_stock_list(stock_list_update_str, stock_list_where_str, stock_list_callback_function_string){
    
		mosyajax_update("stock_list", stock_list_update_str, stock_list_where_str, stock_list_callback_function_string)
    
    }
    //end  update  stock_list Data ===============

	//Start drop  stock_list Data ===============
    function stock_list_drop(stock_list_where_str, stock_list_callback_function_string)
    {
        mosyajax_drop("stock_list", stock_list_where_str, stock_list_callback_function_string)

    }
	//End drop  stock_list Data ===============
    
    function initialize_stock_list(qstr="", stock_list_callback_function_string="")
    {
    
    ///alert(qstr);
      var stock_list_token_query =qstr;
      if(qstr=="")
      {
       var stock_list_token_query_param="";
       var stock_list_js_uptoken=mosy_get_param("stock_list_uptoken");
       //alert(stock_list_js_uptoken);
       if(stock_list_js_uptoken!==undefined)
       {
       
        stock_list_token_query_param = atob(stock_list_js_uptoken);
       }
        stock_list_token_query = " where primkey='"+(stock_list_token_query_param)+"'";
        
           if (document.getElementById("stock_list_uptoken") !==null) {
           	if(document.getElementById("stock_list_uptoken").value!="")
            {
            
            var stock_list_atob_tbl_key =atob(document.getElementById("stock_list_uptoken").value);
            
                   
            stock_list_token_query = " where primkey='"+(stock_list_atob_tbl_key)+"'";

            }
           }
      }
      
      var stock_list_push_ui_data_to =stock_list_callback_function_string;
      if(stock_list_callback_function_string=="")
      {
      stock_list_push_ui_data_to = "add_stock_list_ui_data";
      }
                
      console.log(stock_list_token_query+" -- "+stock_list_js_uptoken);

	  //alert(stock_list_push_ui_data_to);

     get_stock_list("*", stock_list_token_query, "primkey", "blackhole", stock_list_push_ui_data_to, "");
    }
    
    function add_stock_list_ui_data(stock_list_server_resp) 
    {
    
    ///alert(stock_list_server_resp);
    
    var json_decoded_str=JSON.parse(stock_list_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load stock_list data on the fly ==============
    
	var gft_stock_list_str="(item_id LIKE '%{{qstock_list}}%' OR  item_code LIKE '%{{qstock_list}}%' OR  item_name LIKE '%{{qstock_list}}%' OR  item_description LIKE '%{{qstock_list}}%' OR  buying_price LIKE '%{{qstock_list}}%' OR  selling_price LIKE '%{{qstock_list}}%' OR  quantity LIKE '%{{qstock_list}}%' OR  stock_alert LIKE '%{{qstock_list}}%' OR  tax_type LIKE '%{{qstock_list}}%' OR  tax_rate LIKE '%{{qstock_list}}%' OR  tax_amount LIKE '%{{qstock_list}}%' OR  shop_location LIKE '%{{qstock_list}}%' OR  receipt_no LIKE '%{{qstock_list}}%' OR  invoice_no LIKE '%{{qstock_list}}%' OR  payment_mode LIKE '%{{qstock_list}}%' OR  selling_price_n_tax LIKE '%{{qstock_list}}%' OR  margin_price LIKE '%{{qstock_list}}%')";
    
    function  gft_stock_list(qstock_list_str)
    {
        	var clean_stock_list_filter_str=gft_stock_list_str.replace(/{{qstock_list}}/g, magic_clean_str(qstock_list_str));
            
            return  clean_stock_list_filter_str;

    }
    
    function load_stock_list(stock_list_qstr, stock_list_where_str, stock_list_ret_cols, stock_list_user_function, stock_list_result_function, stock_list_data_tray)
    {
    
    var fstock_list_result_function="push_result";
      
    if(stock_list_result_function!="")
    {
          var fstock_list_result_function=stock_list_result_function;

    }
    	var clean_stock_list_filter_str=gft_stock_list_str.replace(/{{qstock_list}}/g, magic_clean_str(stock_list_qstr));
        
        var fstock_list_where_str=" where "+clean_stock_list_filter_str;

    if(stock_list_where_str!="")
    {
          var fstock_list_where_str=" "+stock_list_where_str;

    }
       
      get_stock_list("*", fstock_list_where_str, stock_list_ret_cols, stock_list_user_function, fstock_list_result_function, stock_list_data_tray);
      
    }
    ///=============== load stock_list data on the fly ==============


 ///=quick load 
 
function qkload_stock_list(qstr, push_fun="", ui_card="", and_query="", additional_cols="", stock_list_pagination="")
{

	var stock_list_list_nodes_str=stock_list_list_nodes;
  
   if(ui_card!="")
   {
      stock_list_list_nodes_str=ui_card;
   }
   
   var stock_list_qret_fun="push_grid_result:stock_list_tbl_list";
   
   if(push_fun!="")
   {
    stock_list_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_stock_list("*", ajaxw+" ("+gft_stock_list(qstr)+") "+combined_query+"  order by primkey desc ", stock_list_list_cols+additional_cols_str, "",stock_list_qret_fun, "c=>"+stock_list_list_nodes_str, stock_list_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_stock_list(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_stock_list("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qstock_list_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_stock_list("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_stock_list("*", stock_list_token_query, "primkey", "blackhole", stock_list_push_ui_data_to, "");
    

}



//sum 

function sum_stock_list(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_stock_list("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function stock_list_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "stock_list_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function stock_list_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "stock_list_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function stock_list_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletestock_list&stock_list_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_stock_list_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('stock_list')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  suppliers Data ===============
    
      function get_suppliers(suppliers_colstr, suppliers_filter_col, suppliers_cols, suppliers_node_function_name, suppliers_callback_function_string, suppliers_ui_tag, suppliers_pagination)
      {
        mosyflex_sel("suppliers", suppliers_colstr, suppliers_filter_col , suppliers_cols, suppliers_node_function_name, suppliers_callback_function_string, suppliers_ui_tag, suppliers_pagination);
        
      }
    //End get  suppliers Data ===============

    //Start insert  suppliers Data ===============

	function add_suppliers(suppliers_cols, suppliers_vals, suppliers_callback_function_string)
    {
		
        mosyajax_create_data("suppliers", suppliers_cols, suppliers_vals, suppliers_callback_function_string);
     }
     
    //End insert  suppliers Data ===============

    
    //Start update  suppliers Data ===============

    function update_suppliers(suppliers_update_str, suppliers_where_str, suppliers_callback_function_string){
    
		mosyajax_update("suppliers", suppliers_update_str, suppliers_where_str, suppliers_callback_function_string)
    
    }
    //end  update  suppliers Data ===============

	//Start drop  suppliers Data ===============
    function suppliers_drop(suppliers_where_str, suppliers_callback_function_string)
    {
        mosyajax_drop("suppliers", suppliers_where_str, suppliers_callback_function_string)

    }
	//End drop  suppliers Data ===============
    
    function initialize_suppliers(qstr="", suppliers_callback_function_string="")
    {
    
    ///alert(qstr);
      var suppliers_token_query =qstr;
      if(qstr=="")
      {
       var suppliers_token_query_param="";
       var suppliers_js_uptoken=mosy_get_param("suppliers_uptoken");
       //alert(suppliers_js_uptoken);
       if(suppliers_js_uptoken!==undefined)
       {
       
        suppliers_token_query_param = atob(suppliers_js_uptoken);
       }
        suppliers_token_query = " where primkey='"+(suppliers_token_query_param)+"'";
        
           if (document.getElementById("suppliers_uptoken") !==null) {
           	if(document.getElementById("suppliers_uptoken").value!="")
            {
            
            var suppliers_atob_tbl_key =atob(document.getElementById("suppliers_uptoken").value);
            
                   
            suppliers_token_query = " where primkey='"+(suppliers_atob_tbl_key)+"'";

            }
           }
      }
      
      var suppliers_push_ui_data_to =suppliers_callback_function_string;
      if(suppliers_callback_function_string=="")
      {
      suppliers_push_ui_data_to = "add_suppliers_ui_data";
      }
                
      console.log(suppliers_token_query+" -- "+suppliers_js_uptoken);

	  //alert(suppliers_push_ui_data_to);

     get_suppliers("*", suppliers_token_query, "primkey", "blackhole", suppliers_push_ui_data_to, "");
    }
    
    function add_suppliers_ui_data(suppliers_server_resp) 
    {
    
    ///alert(suppliers_server_resp);
    
    var json_decoded_str=JSON.parse(suppliers_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load suppliers data on the fly ==============
    
	var gft_suppliers_str="(supplier_id LIKE '%{{qsuppliers}}%' OR  vendor_no LIKE '%{{qsuppliers}}%' OR  specialization LIKE '%{{qsuppliers}}%' OR  name LIKE '%{{qsuppliers}}%' OR  phone LIKE '%{{qsuppliers}}%' OR  email LIKE '%{{qsuppliers}}%' OR  postal_address LIKE '%{{qsuppliers}}%' OR  physical_address LIKE '%{{qsuppliers}}%' OR  website LIKE '%{{qsuppliers}}%' OR  user_pic LIKE '%{{qsuppliers}}%' OR  created_at LIKE '%{{qsuppliers}}%')";
    
    function  gft_suppliers(qsuppliers_str)
    {
        	var clean_suppliers_filter_str=gft_suppliers_str.replace(/{{qsuppliers}}/g, magic_clean_str(qsuppliers_str));
            
            return  clean_suppliers_filter_str;

    }
    
    function load_suppliers(suppliers_qstr, suppliers_where_str, suppliers_ret_cols, suppliers_user_function, suppliers_result_function, suppliers_data_tray)
    {
    
    var fsuppliers_result_function="push_result";
      
    if(suppliers_result_function!="")
    {
          var fsuppliers_result_function=suppliers_result_function;

    }
    	var clean_suppliers_filter_str=gft_suppliers_str.replace(/{{qsuppliers}}/g, magic_clean_str(suppliers_qstr));
        
        var fsuppliers_where_str=" where "+clean_suppliers_filter_str;

    if(suppliers_where_str!="")
    {
          var fsuppliers_where_str=" "+suppliers_where_str;

    }
       
      get_suppliers("*", fsuppliers_where_str, suppliers_ret_cols, suppliers_user_function, fsuppliers_result_function, suppliers_data_tray);
      
    }
    ///=============== load suppliers data on the fly ==============


 ///=quick load 
 
function qkload_suppliers(qstr, push_fun="", ui_card="", and_query="", additional_cols="", suppliers_pagination="")
{

	var suppliers_list_nodes_str=suppliers_list_nodes;
  
   if(ui_card!="")
   {
      suppliers_list_nodes_str=ui_card;
   }
   
   var suppliers_qret_fun="push_grid_result:suppliers_tbl_list";
   
   if(push_fun!="")
   {
    suppliers_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_suppliers("*", ajaxw+" ("+gft_suppliers(qstr)+") "+combined_query+"  order by primkey desc ", suppliers_list_cols+additional_cols_str, "",suppliers_qret_fun, "c=>"+suppliers_list_nodes_str, suppliers_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_suppliers(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_suppliers("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qsuppliers_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_suppliers("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_suppliers("*", suppliers_token_query, "primkey", "blackhole", suppliers_push_ui_data_to, "");
    

}



//sum 

function sum_suppliers(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_suppliers("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function suppliers_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "suppliers_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function suppliers_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "suppliers_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function suppliers_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletesuppliers&suppliers_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_suppliers_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('suppliers')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  suppliers_invoice Data ===============
    
      function get_suppliers_invoice(suppliers_invoice_colstr, suppliers_invoice_filter_col, suppliers_invoice_cols, suppliers_invoice_node_function_name, suppliers_invoice_callback_function_string, suppliers_invoice_ui_tag, suppliers_invoice_pagination)
      {
        mosyflex_sel("suppliers_invoice", suppliers_invoice_colstr, suppliers_invoice_filter_col , suppliers_invoice_cols, suppliers_invoice_node_function_name, suppliers_invoice_callback_function_string, suppliers_invoice_ui_tag, suppliers_invoice_pagination);
        
      }
    //End get  suppliers_invoice Data ===============

    //Start insert  suppliers_invoice Data ===============

	function add_suppliers_invoice(suppliers_invoice_cols, suppliers_invoice_vals, suppliers_invoice_callback_function_string)
    {
		
        mosyajax_create_data("suppliers_invoice", suppliers_invoice_cols, suppliers_invoice_vals, suppliers_invoice_callback_function_string);
     }
     
    //End insert  suppliers_invoice Data ===============

    
    //Start update  suppliers_invoice Data ===============

    function update_suppliers_invoice(suppliers_invoice_update_str, suppliers_invoice_where_str, suppliers_invoice_callback_function_string){
    
		mosyajax_update("suppliers_invoice", suppliers_invoice_update_str, suppliers_invoice_where_str, suppliers_invoice_callback_function_string)
    
    }
    //end  update  suppliers_invoice Data ===============

	//Start drop  suppliers_invoice Data ===============
    function suppliers_invoice_drop(suppliers_invoice_where_str, suppliers_invoice_callback_function_string)
    {
        mosyajax_drop("suppliers_invoice", suppliers_invoice_where_str, suppliers_invoice_callback_function_string)

    }
	//End drop  suppliers_invoice Data ===============
    
    function initialize_suppliers_invoice(qstr="", suppliers_invoice_callback_function_string="")
    {
    
    ///alert(qstr);
      var suppliers_invoice_token_query =qstr;
      if(qstr=="")
      {
       var suppliers_invoice_token_query_param="";
       var suppliers_invoice_js_uptoken=mosy_get_param("suppliers_invoice_uptoken");
       //alert(suppliers_invoice_js_uptoken);
       if(suppliers_invoice_js_uptoken!==undefined)
       {
       
        suppliers_invoice_token_query_param = atob(suppliers_invoice_js_uptoken);
       }
        suppliers_invoice_token_query = " where primkey='"+(suppliers_invoice_token_query_param)+"'";
        
           if (document.getElementById("suppliers_invoice_uptoken") !==null) {
           	if(document.getElementById("suppliers_invoice_uptoken").value!="")
            {
            
            var suppliers_invoice_atob_tbl_key =atob(document.getElementById("suppliers_invoice_uptoken").value);
            
                   
            suppliers_invoice_token_query = " where primkey='"+(suppliers_invoice_atob_tbl_key)+"'";

            }
           }
      }
      
      var suppliers_invoice_push_ui_data_to =suppliers_invoice_callback_function_string;
      if(suppliers_invoice_callback_function_string=="")
      {
      suppliers_invoice_push_ui_data_to = "add_suppliers_invoice_ui_data";
      }
                
      console.log(suppliers_invoice_token_query+" -- "+suppliers_invoice_js_uptoken);

	  //alert(suppliers_invoice_push_ui_data_to);

     get_suppliers_invoice("*", suppliers_invoice_token_query, "primkey", "blackhole", suppliers_invoice_push_ui_data_to, "");
    }
    
    function add_suppliers_invoice_ui_data(suppliers_invoice_server_resp) 
    {
    
    ///alert(suppliers_invoice_server_resp);
    
    var json_decoded_str=JSON.parse(suppliers_invoice_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load suppliers_invoice data on the fly ==============
    
	var gft_suppliers_invoice_str="(data_id LIKE '%{{qsuppliers_invoice}}%' OR  stock_amount LIKE '%{{qsuppliers_invoice}}%' OR  supplier_id LIKE '%{{qsuppliers_invoice}}%' OR  receipt_id LIKE '%{{qsuppliers_invoice}}%' OR  invoice_no LIKE '%{{qsuppliers_invoice}}%' OR  stock_data LIKE '%{{qsuppliers_invoice}}%' OR  amount_paid LIKE '%{{qsuppliers_invoice}}%' OR  stock_balance LIKE '%{{qsuppliers_invoice}}%' OR  user_id LIKE '%{{qsuppliers_invoice}}%' OR  item_id LIKE '%{{qsuppliers_invoice}}%' OR  purchase_amt LIKE '%{{qsuppliers_invoice}}%')";
    
    function  gft_suppliers_invoice(qsuppliers_invoice_str)
    {
        	var clean_suppliers_invoice_filter_str=gft_suppliers_invoice_str.replace(/{{qsuppliers_invoice}}/g, magic_clean_str(qsuppliers_invoice_str));
            
            return  clean_suppliers_invoice_filter_str;

    }
    
    function load_suppliers_invoice(suppliers_invoice_qstr, suppliers_invoice_where_str, suppliers_invoice_ret_cols, suppliers_invoice_user_function, suppliers_invoice_result_function, suppliers_invoice_data_tray)
    {
    
    var fsuppliers_invoice_result_function="push_result";
      
    if(suppliers_invoice_result_function!="")
    {
          var fsuppliers_invoice_result_function=suppliers_invoice_result_function;

    }
    	var clean_suppliers_invoice_filter_str=gft_suppliers_invoice_str.replace(/{{qsuppliers_invoice}}/g, magic_clean_str(suppliers_invoice_qstr));
        
        var fsuppliers_invoice_where_str=" where "+clean_suppliers_invoice_filter_str;

    if(suppliers_invoice_where_str!="")
    {
          var fsuppliers_invoice_where_str=" "+suppliers_invoice_where_str;

    }
       
      get_suppliers_invoice("*", fsuppliers_invoice_where_str, suppliers_invoice_ret_cols, suppliers_invoice_user_function, fsuppliers_invoice_result_function, suppliers_invoice_data_tray);
      
    }
    ///=============== load suppliers_invoice data on the fly ==============


 ///=quick load 
 
function qkload_suppliers_invoice(qstr, push_fun="", ui_card="", and_query="", additional_cols="", suppliers_invoice_pagination="")
{

	var suppliers_invoice_list_nodes_str=suppliers_invoice_list_nodes;
  
   if(ui_card!="")
   {
      suppliers_invoice_list_nodes_str=ui_card;
   }
   
   var suppliers_invoice_qret_fun="push_grid_result:suppliers_invoice_tbl_list";
   
   if(push_fun!="")
   {
    suppliers_invoice_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_suppliers_invoice("*", ajaxw+" ("+gft_suppliers_invoice(qstr)+") "+combined_query+"  order by primkey desc ", suppliers_invoice_list_cols+additional_cols_str, "",suppliers_invoice_qret_fun, "c=>"+suppliers_invoice_list_nodes_str, suppliers_invoice_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_suppliers_invoice(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_suppliers_invoice("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qsuppliers_invoice_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_suppliers_invoice("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_suppliers_invoice("*", suppliers_invoice_token_query, "primkey", "blackhole", suppliers_invoice_push_ui_data_to, "");
    

}



//sum 

function sum_suppliers_invoice(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_suppliers_invoice("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function suppliers_invoice_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "suppliers_invoice_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function suppliers_invoice_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "suppliers_invoice_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function suppliers_invoice_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletesuppliers_invoice&suppliers_invoice_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_suppliers_invoice_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('suppliers_invoice')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  users_tbl Data ===============
    
      function get_users_tbl(users_tbl_colstr, users_tbl_filter_col, users_tbl_cols, users_tbl_node_function_name, users_tbl_callback_function_string, users_tbl_ui_tag, users_tbl_pagination)
      {
        mosyflex_sel("users_tbl", users_tbl_colstr, users_tbl_filter_col , users_tbl_cols, users_tbl_node_function_name, users_tbl_callback_function_string, users_tbl_ui_tag, users_tbl_pagination);
        
      }
    //End get  users_tbl Data ===============

    //Start insert  users_tbl Data ===============

	function add_users_tbl(users_tbl_cols, users_tbl_vals, users_tbl_callback_function_string)
    {
		
        mosyajax_create_data("users_tbl", users_tbl_cols, users_tbl_vals, users_tbl_callback_function_string);
     }
     
    //End insert  users_tbl Data ===============

    
    //Start update  users_tbl Data ===============

    function update_users_tbl(users_tbl_update_str, users_tbl_where_str, users_tbl_callback_function_string){
    
		mosyajax_update("users_tbl", users_tbl_update_str, users_tbl_where_str, users_tbl_callback_function_string)
    
    }
    //end  update  users_tbl Data ===============

	//Start drop  users_tbl Data ===============
    function users_tbl_drop(users_tbl_where_str, users_tbl_callback_function_string)
    {
        mosyajax_drop("users_tbl", users_tbl_where_str, users_tbl_callback_function_string)

    }
	//End drop  users_tbl Data ===============
    
    function initialize_users_tbl(qstr="", users_tbl_callback_function_string="")
    {
    
    ///alert(qstr);
      var users_tbl_token_query =qstr;
      if(qstr=="")
      {
       var users_tbl_token_query_param="";
       var users_tbl_js_uptoken=mosy_get_param("users_tbl_uptoken");
       //alert(users_tbl_js_uptoken);
       if(users_tbl_js_uptoken!==undefined)
       {
       
        users_tbl_token_query_param = atob(users_tbl_js_uptoken);
       }
        users_tbl_token_query = " where primkey='"+(users_tbl_token_query_param)+"'";
        
           if (document.getElementById("users_tbl_uptoken") !==null) {
           	if(document.getElementById("users_tbl_uptoken").value!="")
            {
            
            var users_tbl_atob_tbl_key =atob(document.getElementById("users_tbl_uptoken").value);
            
                   
            users_tbl_token_query = " where primkey='"+(users_tbl_atob_tbl_key)+"'";

            }
           }
      }
      
      var users_tbl_push_ui_data_to =users_tbl_callback_function_string;
      if(users_tbl_callback_function_string=="")
      {
      users_tbl_push_ui_data_to = "add_users_tbl_ui_data";
      }
                
      console.log(users_tbl_token_query+" -- "+users_tbl_js_uptoken);

	  //alert(users_tbl_push_ui_data_to);

     get_users_tbl("*", users_tbl_token_query, "primkey", "blackhole", users_tbl_push_ui_data_to, "");
    }
    
    function add_users_tbl_ui_data(users_tbl_server_resp) 
    {
    
    ///alert(users_tbl_server_resp);
    
    var json_decoded_str=JSON.parse(users_tbl_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load users_tbl data on the fly ==============
    
	var gft_users_tbl_str="(user_id LIKE '%{{qusers_tbl}}%' OR  user_name LIKE '%{{qusers_tbl}}%' OR  user_email LIKE '%{{qusers_tbl}}%' OR  user_mobile LIKE '%{{qusers_tbl}}%' OR  employee_id LIKE '%{{qusers_tbl}}%' OR  national_id LIKE '%{{qusers_tbl}}%' OR  login_name LIKE '%{{qusers_tbl}}%' OR  role LIKE '%{{qusers_tbl}}%' OR  login_password LIKE '%{{qusers_tbl}}%' OR  account_state LIKE '%{{qusers_tbl}}%' OR  date_signed LIKE '%{{qusers_tbl}}%' OR  user_pic LIKE '%{{qusers_tbl}}%' OR  last_seen LIKE '%{{qusers_tbl}}%')";
    
    function  gft_users_tbl(qusers_tbl_str)
    {
        	var clean_users_tbl_filter_str=gft_users_tbl_str.replace(/{{qusers_tbl}}/g, magic_clean_str(qusers_tbl_str));
            
            return  clean_users_tbl_filter_str;

    }
    
    function load_users_tbl(users_tbl_qstr, users_tbl_where_str, users_tbl_ret_cols, users_tbl_user_function, users_tbl_result_function, users_tbl_data_tray)
    {
    
    var fusers_tbl_result_function="push_result";
      
    if(users_tbl_result_function!="")
    {
          var fusers_tbl_result_function=users_tbl_result_function;

    }
    	var clean_users_tbl_filter_str=gft_users_tbl_str.replace(/{{qusers_tbl}}/g, magic_clean_str(users_tbl_qstr));
        
        var fusers_tbl_where_str=" where "+clean_users_tbl_filter_str;

    if(users_tbl_where_str!="")
    {
          var fusers_tbl_where_str=" "+users_tbl_where_str;

    }
       
      get_users_tbl("*", fusers_tbl_where_str, users_tbl_ret_cols, users_tbl_user_function, fusers_tbl_result_function, users_tbl_data_tray);
      
    }
    ///=============== load users_tbl data on the fly ==============


 ///=quick load 
 
function qkload_users_tbl(qstr, push_fun="", ui_card="", and_query="", additional_cols="", users_tbl_pagination="")
{

	var users_tbl_list_nodes_str=users_tbl_list_nodes;
  
   if(ui_card!="")
   {
      users_tbl_list_nodes_str=ui_card;
   }
   
   var users_tbl_qret_fun="push_grid_result:users_tbl_tbl_list";
   
   if(push_fun!="")
   {
    users_tbl_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_users_tbl("*", ajaxw+" ("+gft_users_tbl(qstr)+") "+combined_query+"  order by primkey desc ", users_tbl_list_cols+additional_cols_str, "",users_tbl_qret_fun, "c=>"+users_tbl_list_nodes_str, users_tbl_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_users_tbl(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_users_tbl("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qusers_tbl_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_users_tbl("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_users_tbl("*", users_tbl_token_query, "primkey", "blackhole", users_tbl_push_ui_data_to, "");
    

}



//sum 

function sum_users_tbl(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_users_tbl("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function users_tbl_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "users_tbl_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function users_tbl_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "users_tbl_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function users_tbl_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteusers_tbl&users_tbl_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_users_tbl_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('users_tbl')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
  //===============End Mosy queries-============

const mosy_msdn_elem = document.querySelectorAll('.mosy_msdn');

mosy_msdn_elem.forEach(el => el.addEventListener('click', event => {

var arguments = event.target.getAttribute("data-mosy_msdn");
  
eval(arguments);

}));

const mosy_tup_elem = document.querySelectorAll('.mosy_tup');

mosy_tup_elem.forEach(el => el.addEventListener('keyup', event => {

var arguments = event.target.getAttribute("data-mosy_tup");
  
eval(arguments);

}));
  
var ajax_url ="./ajaxreqhandler.php";
var mosyajax_sql_url=ajax_url;
   //Ajax Manager
function mosyflex_sel(tbl, colstr, filter_col , cols, node_function_name, callback_function_string, ui_tag, pagination="")
{
//alert(filter_col);
///alert(pagination);

    var clean_ui1=ui_tag.replace(/</g, "{{<}}");
    var clean_ui2=clean_ui1.replace(/>/g, "{{>}}");
    var clean_ui3=clean_ui2.replace(/onclick/g, "{{on click}}");
    var clean_ui4=clean_ui3.replace(/onkeyup/g, "{{on keyup}}");
    var clean_ui=clean_ui4.replace(/onchange/g, "{{on change}}");
    
  	var pagination_token=1;
    var pagination_name=pagination;
    
    if(pagination.indexOf(":") >= 0)
  	{
      pagination_token_expl=pagination.split(":");
      pagination_token=pagination_token_expl[1];
      pagination_name=pagination_token_expl[0];
    }
    
  
    var json_params_str={"mosyajax_sql_data":filter_col, "colstr":colstr, "cols":cols, "node_function_name":node_function_name, "tbl":tbl, "ui_tag":clean_ui,"pagination":pagination_name};
   
  	//alert(clean_ui);
  
  //alert(pagination_name);
  //alert(pagination_token);
  
    if(pagination_token>1)
    {
		mosy_ajax_post(ajax_url+"?"+pagination_name+"="+btoa(pagination_token), json_params_str, callback_function_string, "");
    }else{
		mosy_ajax_post(ajax_url, json_params_str, callback_function_string, "");

    }
}


function mosy_next_page(elem_id)
{
  if(get_newval(elem_id)=="")
  {
  	push_newval(elem_id,0)
  }
  var next_token_no=parseInt(get_newval(elem_id))+1;
  
  push_newval(elem_id, next_token_no);
  
  return next_token_no;
}

function mosy_prev_page(elem_id)
{
  if(get_newval(elem_id)=="")
  {
  	push_newval(elem_id,0)
  }
  var next_token_no=parseInt(get_newval(elem_id))-1;
  
  if(next_token_no<=0)
  {
  next_token_no=1;
  }
  
  push_newval(elem_id, next_token_no);
  
  return next_token_no;
}

function push_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp+'<div class="col-md-12 p-0 text-right"><span class="badge cpointer" style="font-size:10px;"><i class="fa fa-times-circle"></i> Close</span></div>';
  
  if(server_resp.toString().trim()=='')
  {
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray"> <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
  }
  
  
  if (document.getElementById(additional_callbacks) !==null) {
        
  document.getElementById(additional_callbacks).style.display="block";
  document.getElementById(additional_callbacks).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}



function push_grid_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp;
  
  var tbl_col_str="";
  var tbl_colspan ="";
  var elem_id=additional_callbacks;

  var empty_state_str="";
  
  if(additional_callbacks.indexOf(":") >= 0)
  {
     tbl_col_str=additional_callbacks.split(":");
     
     tbl_colspan=tbl_col_str[1];
     
     elem_id=tbl_col_str[0];

	if(typeof tbl_col_str[2] !== 'undefined') 
    {
     var empty_state_str = tbl_col_str[2];
    }

  }
///alert(additional_callbacks);
  if(server_resp.toString().trim()=='')
  {
  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid" > <td colspan="'+tbl_colspan+'" style="text-align:center;"><div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div></td> </tr>';
    if(empty_state_str!="")
    {
    var str_to_display =window[empty_state_str];
    
    }
    }else{
        
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
    
    if(empty_state_str!="")
    {
    var str_to_display =window[empty_state_str];
    
    }
    }
  }
  
  
  if (document.getElementById(elem_id) !==null) {
        
  ///document.getElementById(elem_id).style.display="block";
  document.getElementById(elem_id).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}

function mosy_empty_state(top_msg="", btm_msg="", tbl_colspan="")
{

    var str_to_display="";

  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid " > <td colspan="'+tbl_colspan+'" style="text-align:center;">'+top_msg+'<hr><div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"> '+btm_msg+'</div></td> </tr>';
 
    }else{
        
  	 str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12">'+top_msg+'<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"> '+btm_msg+'</div> </div>';
    
 
    }


///alert(str_to_display);

  return str_to_display;

}


function push_val(arrkeys, arrvalues)
{
    var r = {},i;
    
    for (let i = 0; i < arrkeys.length; i++) {
        r[arrkeys[i]] = arrvalues[i];
      document.getElementById(arrvalues[i]).value=[arrkeys[i]];
    }

}

    function qddata(server_resp,callbacks)
    {
    //alert(server_resp);
    var retjson = JSON.parse(server_resp)[0];
    
        ///alert(retjson.name);


    return retjson;
    
    
    }
function mosy_ajax_post(post_url, json_params, callback_function_string, additional_callbacks)
{


	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
         split_fun_str=callback_function_string.split(/:(.*)/s);
         
		 fcall_back_function =  split_fun_str[0];
        
         fadditional_callbacks =  split_fun_str[1] ;
    
    }
    
    if (document.getElementById(fadditional_callbacks) !==null) {
      ////  document.getElementById(fadditional_callbacks).style.display="block";
    	///document.getElementById(fadditional_callbacks).innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... '+document.getElementById(fadditional_callbacks).innerHTML;
        
    }
    
       if (document.getElementById("ajax_spinner") !==null) 
       {
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';

       }else{
       	mosy_snack_wgt("Processing request...", "top", "ajax_snack", "200px", "ajax_snack_id", "#000",  "#fff", "");
    
    	mosytoggle_class("ajax_snack_id", "show");
        
       }
       
       
  	var formData = ((json_params)); //Array 
  
      $.ajax({ 
      url: post_url,
      type: "POST",
      data:formData,

      success: function (data) 
      {
        //alert(data);
       if (document.getElementById("ajax_spinner") !==null) 
       {
       
         var result_response_='<i class="fa fa-info-circle"></i> Request Processed Succesfully.';
		
        	if(data=='')
            {
            
        		var result_response_='<i class="fa fa-info-circle"></i> No data .';
            
            }
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML=result_response_;

       } 
       
       push_html("ajax_snack", "");                                          

        window[fcall_back_function](data, fadditional_callbacks);

      }

  })
  
}  


   //Ajax Manager

function mosyajax_create_data(tbl, tbl_cols, tbl_vals, callback_function_string)
{
  ///alert(tbl_cols+" - "+tbl_vals);
  
    var json_params_str={"mosyajax_create":"ok", "tbl_cols":tbl_cols, "tbl_vals":tbl_vals, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

   //Ajax Exe
function mosyajax_update(tbl, update_str, where_str, callback_function_string)
{
  //alert(update_str);
  
    var json_params_str={"mosyajax_update":"ok", "update_str":update_str, "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

function mosyajax_drop(tbl, where_str, callback_function_string)
{
  //alert(where_str);
  
    var json_params_str={"mosyajax_drop":"ok", "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}


function mosyajax_get(getstr, callback_function_string)
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = "";
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
    if (document.getElementById("ajax_spinner") !==null) 
    {
        
      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

  	}

    $.ajax({
      url: ajax_url+"?"+getstr,
      type: 'GET',
      success: function(res) {
       if (document.getElementById("ajax_spinner") !==null) {

          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

       }              
            //alert(res);
        window[fcall_back_function](res, fadditional_callbacks);

          }
      });
}


function mosy_form_data(form_id,  save_action, callback_function_string, additional_callbacks, required_inp="")
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
	var formData = new FormData(document.getElementById(form_id));
  
    if (document.getElementById("ajax_spinner") !==null) {
        
    	document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';
        
    }
    
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
   ///alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
    {

	formData.append(save_action, "ok");
	formData.append('mosyrequest_type', "ajax");
        $.ajax({
            type: "POST",
            url: ajax_url,
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
                  if (document.getElementById("ajax_spinner") !==null) {
        
                      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

                  }
              ///alert(data);
        		window[fcall_back_function](data, fadditional_callbacks);
            },
	    complete: function(){
			//alert("Data uploaded successfully.");
	    },
	    error: function (jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
	    } 
        });
      // Display the key/value pairs
      for (var pair of formData.entries()) {
          ///console.log(pair[0]+ ", " + pair[1]); 
      }
        	  
     }else{
        magic_message(validate_msg, 'dialog_box');
      }
      
      
}

function blackhole(data)
{

}

function show_password(input_name) 
{
  var x = document.getElementById(input_name);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}


function get_newval(elemid)
{
    if (document.getElementById(elemid) !==null) {

	  return document.getElementById(elemid).value;
    }else{
  
  return "";
  }
}

function mosy_response(server_resp, callbacks)
{

	alert("server_resp"+server_resp+" -- Callbacks "+callbacks);

}

function get_html(elemid)
{
    if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).innerHTML;
  }else{
  
  return "";
  }
}

function get_src(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).src;
  }else{
  
  return "";
  }
}

function get_href(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).href;
  }else{
  
  return "";
  }
}


function push_ddown(server_items, selelem)
{

	$('#'+selelem+' option:not(:first)').remove();

	document.getElementById(selelem).innerHTML=document.getElementById(selelem).innerHTML+server_items;

}
//========= formart to num =================

function tonum(req_number, decplc=0)
{

///alert(req_number);

n = parseFloat(req_number).toFixed(decplc)
var withCommas = Number(n).toLocaleString('en');


return withCommas;
}

//========= formart to num =================

function mosy_qstr(string, query_str)
{
    
   if(string.indexOf(query_str)==-1)
    {
      
      var q_str_state="False";
      
    }else{
    
	  var q_str_state="True";
     
	}
    
  return q_str_state;
    
}
function mosy_refresh(new_location)
{

var new_location_str=window.location.href;

  window.location=new_location_str.replace("table_alert", "tbl_alert_old");

}

function mosy_srefresh(server_resp, new_location)
{

  window.location=new_location;

}
////////////////// ===================  js action listener ================  

  var _js_msdn=document.querySelectorAll('js_msdn');
  
  _js_msdn.forEach(el => el.addEventListener('click', event => {
  
  var _mosy_jsmsdn_event_trgt= event.currentTarget;

  
	 _mosy_jsmsdn_jsaction="";
	 _mosy_jsmsdn_arg="";
     
  if (!_mosy_jsmsdn_event_trgt.hasAttribute("data-mosy_js")) 
  {
    // data attribute doesnt exist
  }else{
  
	 _mosy_jsmsdn_jsaction=_mosy_jsmsdn_event_trgt.getAttribute("data-mosy_js");
	 _mosy_jsmsdn_arg=_mosy_jsmsdn_event_trgt.getAttribute("data-_mosy_jsmsdn_arg");
     
  }

     window[_mosy_jsmsdn_jsaction](_mosy_jsmsdn_arg);

  
}));
  
  
  
////////////////// ==================  js action listener ================  



function pop_filter_tray (data_src, card_title, where_str_req,cols,returnfun)
{
  magic_screen(pop_data_filter_card, "alert_box");
        
  var where_str =" and "+(where_str_req);
  var where_str_inp =" and "+magic_clean_str(where_str_req);
  
  if(where_str_req=="")
  {
    var where_str="";
    var where_str_inp ="";
  }
  
  var load_data_set ="load_"+data_src;
  var gft_data_str="gft_"+data_src;
  ///alert(where_str);
  window[load_data_set]("", ajaxw+" "+window[gft_data_str]("")+where_str, cols, returnfun, "push_result:result","card");
  
  //alert(cols);
  var textbox ='<input type="text" class="form-control" onkeyup="'+load_data_set+'(this.value, \''+ajaxw+' \'+'+gft_data_str+'(this.value)+\''+where_str_inp+'\', \''+magic_clean_str(cols)+'\', \''+returnfun+'\', \'push_result:result\',\'card\')" placeholder="Type your search here"/>';
        
  document.getElementById('card_title').innerHTML=card_title;
  document.getElementById('dope_text').innerHTML=textbox;

        
}


function mosytoggle_elem(elemid, new_val)
{
  if(new_val=='')
  {
  if(document.getElementById(elemid).style.display!='none')
  {
    document.getElementById(elemid).style.display='none';
  }else{
    document.getElementById(elemid).style.display='block';
  }
  }else{
    document.getElementById(elemid).style.display=new_val;
  }
}

function tray_uptoken(datakey,callbacks)
{
  
  window.location=callbacks[0]+'?'+callbacks[1]+'_uptoken='+btoa(datakey[0]);
}

var pop_data_filter_card=`
    <h5><i class="fa fa-search mr-2"></i><span id="card_title"></span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  	<div id="dope_text" class="col-md-12"></div>
	<div id="result" class="col-md-12" style="max-height:300px; overflow-y:auto;" onclick="this.style.display='none'"></div>
    
  	<div id="r" class="col-md-12 row justify-content-center m-0 p-0 mt-3">
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5 mr-lg-3" id="pop_tray_location"> 
        	View All <i class="fa fa-arrow-right"></i> 
        </a>
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5" id="new_pop_tray_location"> 
        	<i class="fa fa-plus" id="newclass"></i> 
        	<span id="new_record_label"> Add new </span> 
        </a>
    </div>
  </div>`;
  
function push_link(new_link,anchor_el)
{

	//alert(new_link);
	document.getElementById(anchor_el).href=new_link;

}


function push_html(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

	  document.getElementById(elemid).innerHTML=new_val;
      
      }
}

function push_newval(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

  		document.getElementById(elemid).value=new_val;
  
  }
}

function push_src(elemid, new_val)
{
	  if (document.getElementById(elemid) !==null) 
      {

	  		document.getElementById(elemid).src=new_val;
      
      }
}

function mosytoggle_class(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_addclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    //document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_remclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }
  
}


function mosyhide_elem(elemid, new_class="")
{
    var curr_class="none";
    if(new_class!="")
    {
    curr_class=new_class;
    }
    	
   if (document.getElementById(elemid) !==null) 
   {
   	document.getElementById(elemid).style.display=curr_class;
   }
}

function mosyshow_elem(elemid, new_class="")
{
    var curr_class="block";
    if(new_class!="")
    {
    curr_class=new_class;
    }
   if (document.getElementById(elemid) !==null) 
   {
   	document.getElementById(elemid).style.display=curr_class;
   }
}

function mosy_get_param(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}


function mosy_push_data(elemid,data)
{
	var elem_state ="false";
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      
      push_newval(elemid, data);
      push_html(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, "<option>"+data+"</option>"+get_html(elemid));
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  
}

function check_elem(elemid)
{
    if (document.getElementById(elemid) ===null) 
    {
    alert("element_"+elemid+" Not available");
    }
}

function push_shtml(server_res, callback)
{
  
  magic_message(callback, "dialog_box");
  
}
function mosy_push_num_ddata(_server_resp, elemid_str)
{
	//alert(_server_resp);
    
	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = (elemid_arr[0]);
        
          data_str = elemid_arr[1];
          
          console.log(elemid+" state "+ data_str+" serep "+_server_resp);

         data = tonum(json_decoded_str[data_str]);
        
    }
    
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
            
      push_html(elemid, data);
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function mosy_push_ddata(_server_resp, elemid_str)
{

///alert(_server_resp);

	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = elemid_arr[0];
        
          data_str = elemid_arr[1];
          

         var data = json_decoded_str[data_str];
        
    }else{

		var data = json_decoded_str[data_str];

    }
              
    console.log(elemid+" state "+ data_str+" serep "+_server_resp);

    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      push_html(elemid, data);      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function dope_token(token_url="", token_key="")
{
window.history.replaceState(null, null, "?"+token_url+"="+token_key+"");
}

function mosyrename_elem(elemid, newname)
{
    if (document.getElementById(elemid) !==null) 
    {
      document.getElementById(elemid).id=newname;
      document.getElementById(newname).setAttribute("name",newname);
    }
}
///////////////  slide show 
function mosy_slide_wgt(image_arr_n_captions, img_style, img_class, extra_attr, slide_indicators_yes_no)
{
  
const rem_array = image_arr_n_captions.slice(0, 0).concat(image_arr_n_captions.slice(0+1, image_arr_n_captions.length));
  
var curr_slide_id =magic_random_str(10);
    
var img_string =  image_arr_n_captions[0];
var caption_str = ""
var caption_str_div="";
var datakey = "";
  
if(image_arr_n_captions[0].includes(":"))
{
 img_string =  image_arr_n_captions[0].substring(0, image_arr_n_captions[0].indexOf(':')); 
 datakey_1 = image_arr_n_captions[0].substring(image_arr_n_captions[0].indexOf(':')+1); 
 datakey = datakey_1.substring(0, datakey_1.indexOf(':'));
 datakey_2 = datakey_1.substring(datakey_1.indexOf(':')+1);
 caption_str = datakey_2.substring(datakey_2.indexOf(':'));
 caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${caption_str} </div>`;
}
  ///alert("dkey1 -- "+datakey_2);
 var slide_node="";
 var slidecounter="";
 var i=0;
  
 if(slide_indicators_yes_no=='yes')
 {
   slidecounter=`<li data-target="#slide_s${curr_slide_id}" data-slide-to="0" class="active"></li>`;
 }
 for(img_arr of rem_array)
 {
   i++;
   
	if(slide_indicators_yes_no=='yes'){
 slidecounter+=`
        <li data-target="#slide_s${curr_slide_id}" data-slide-to="${i}" class="active"></li>
   `;  
    }
   
   var loop_img_string =  img_arr;
   var loop_caption_str = "";
   var loop_caption_str_div="";
   var loop_datakey="";
   
   if(img_arr.includes(":")){
 	loop_img_string =  img_arr.substring(0, img_arr.indexOf(':')); 
 	loop_datakey_1 = img_arr.substring(img_arr.indexOf(':')+1); 
 	loop_datakey = loop_datakey_1.substring(0, loop_datakey_1.indexOf(':'));
 	loop_datakey_2 = loop_datakey_1.substring(loop_datakey_1.indexOf(':')+1);
 	loop_caption_str = loop_datakey_2.substring(loop_datakey_2.indexOf(':'));
 	loop_caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${loop_caption_str} </div>`;
   }
   
   slide_node+=`   
            <!-- carousel item -->
            <div class="carousel-item">
             <div class="row pt-3 justify-content-center">
     			${loop_caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${loop_img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${loop_datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->`;
   
 }
  
var slide_tray=`
      <!--------------- Start carousel ---------->
      <div id="slide_s${curr_slide_id}" class="carousel slide w-100" data-ride="carousel" data-interval="2000">
        <ol class="carousel-indicators mt-2">
  		${slidecounter}
        </ol>
        <!-- carousel inner -->
          <div class="carousel-inner">
            <!-- carousel item -->
            <div class="carousel-item active">
             <div class="row pt-3 justify-content-center">
          	   ${caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->
		   ${slide_node}
            <!-- carousel inner -->
            <a class="carousel-control-prev" href="#slide_s${curr_slide_id}" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a class="carousel-control-next" href="#slide_s${curr_slide_id}" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a> 
          </div>
             
      </div>
      <!--------------- End carousel ---------->
        `;
  
return [slide_tray, curr_slide_id];  
}
///////////////  slide show 

//////////////  image alert 
function mosy_img_pop(img_src,img_style, img_class,  extra_attr, slide_show_yes_no)
{
  var img_tray=
    `
    <img src="${img_src}" style="${img_style}" class="${img_class}"/>
    
    `;
  
  if(slide_show_yes_no=='yes')
  {
    
    var pop_tray_carousel = mosy_slide_wgt(img_src, img_style, img_class, extra_attr)[0];
    
    magic_screen(pop_tray_carousel, 'alert_box');
    
  }else{
  	magic_screen(img_tray, 'alert_box');
  }
  
}  

//////////////  image alert \

function mosy_snack_wgt(content, curr_position, push_to, snack_pos, snackid, color, bg, onclick_fun)
{
              
var snack_cont=`
<style>
/* The snackbar - position it at the bottom and in the middle of the screen */
#${snackid} {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background:${bg}; /* Black background color */
  color: ${color}; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 9999; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  ${curr_position}: ${snack_pos}; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#${snackid}.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}

@keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}
</style>
  
  <div id="${snackid}" onclick="${onclick_fun};push_html('${push_to}', '')">${content}</div>

  `;


push_html(push_to, snack_cont);


} 

function new_location(new_location_str)
{
window.location=new_location_str;
}

function mosy_reload()
{
   document.location.reload()

} 

function glass_modal()
{
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("background-color", "transparent", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border-top", "0px solid", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border", "0px solid", "important");;
}

function mosy_card(card_title="", card_content, attach_To)
{
	var mosy_card_title="";
    if(card_title!="")
    {
    var mosy_card_title=`
                          <!-- Start  Title ribbon-->
                      <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                        <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                        <div class="col-md-8 text-center"><b> ${card_title}</b></div>
                        <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                      </h5>
                      <!-- End Title ribbon--> 
    `;
    }
    var link_pop=`
    <div class="row justify-content-center m-0 p-0 col-md-12">
						${mosy_card_title}
                      <div class="row justify-content-center m-0 p-0 col-md-12 mt-3 mb-3">
                        ${card_content}
                      </div>
      </div>
    </div>

    `;

    if(attach_To=='' || attach_To==undefined)
    {
    magic_screen(link_pop, 'alert_box');
    }else{
      push_html(attach_To, link_pop);
    }

    return link_pop;
 
}

  
function filter_by_date(card_title,filter_link,filter_col,and_query='',trailing_space="")
{

var def_date = mosy_ymd();
var pop_filter_date=`
    <h5>Filter by <span id="filter_title"> ${card_title} </span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
	<div class="form-group col-md-6">
		<label >Start Date</label>
		<input class="form-control" id="txt_start_date" name="" value="${def_date}" placeholder="Your Name" type="date">
	</div>
  	<div class="form-group col-md-6">
		<label >End Date</label>
		<input class="form-control" id="txt_end_date"  name="" value="${def_date}" placeholder="Your Name" type="date">
	</div>
    <input type="hidden" id="txt_mosy_filter_q" value="${filter_col}" />
    <input type="hidden" id="txt_mosy_and_query" value="${and_query}" />
  <div class="col-md-7 cpointer btn_neoo2 btn-primary text-center" onclick=" go_to_date('${filter_link}', get_newval('txt_start_date'), get_newval('txt_end_date'), get_newval('txt_mosy_filter_q'), get_newval('txt_mosy_and_query'), '${trailing_space}')"><i class="fa fa-arrow-right"></i> Proceed </div>
  </div>
  `;
  
  mosy_card('', pop_filter_date);
  
  return pop_filter_date;
  
}
  
function go_to_date(filter_link, start_date, end_date, filter_col, and_query, trailing_space)
{
  var filter_location=filter_link+"="+btoa(trailing_space+"DATE_FORMAT("+filter_col+", '%Y-%m-%d') >='" +start_date+"' AND DATE_FORMAT("+filter_col+", '%Y-%m-%d') <='" +end_date+ "' "+and_query+" ");
  ///alert(filter_location);
  window.location=filter_location;
  
}

function mosy_ymd(date='') {
return new Date().toISOString().slice(0, 10);

}


function mosy_modal(modal_content, attach_To="alert_box")
{

  var mosy_modal_tray =`
  <div class="col-md-12 mosy_modal rounded_big p-0 m-0 bg-white shadow  border border_set ">
    <div class="col-md-12 pt-2 text-right" onclick="push_html('${attach_To}','')"><span class="cpointer "><i class="fa fa-times-circle"></i></span></div>
    ${modal_content}
  </div>`;

///alert(modal_content);

  push_html(attach_To, mosy_modal_tray);

  return mosy_modal_tray;

}

//<--ncgh-->
