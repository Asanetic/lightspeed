 
//===============Start Mosy queries-============ 

    //Start get  doc_nos Data ===============
    
      function get_doc_nos(doc_nos_colstr, doc_nos_filter_col, doc_nos_cols, doc_nos_node_function_name, doc_nos_callback_function_string, doc_nos_ui_tag, doc_nos_pagination)
      {
        mosyflex_sel("doc_nos", doc_nos_colstr, doc_nos_filter_col , doc_nos_cols, doc_nos_node_function_name, doc_nos_callback_function_string, doc_nos_ui_tag, doc_nos_pagination);
        
      }
    //End get  doc_nos Data ===============

    //Start insert  doc_nos Data ===============

	function add_doc_nos(doc_nos_cols, doc_nos_vals, doc_nos_callback_function_string)
    {
		
        mosyajax_create_data("doc_nos", doc_nos_cols, doc_nos_vals, doc_nos_callback_function_string);
     }
     
    //End insert  doc_nos Data ===============

    
    //Start update  doc_nos Data ===============

    function update_doc_nos(doc_nos_update_str, doc_nos_where_str, doc_nos_callback_function_string){
    
		mosyajax_update("doc_nos", doc_nos_update_str, doc_nos_where_str, doc_nos_callback_function_string)
    
    }
    //end  update  doc_nos Data ===============

	//Start drop  doc_nos Data ===============
    function doc_nos_drop(doc_nos_where_str, doc_nos_callback_function_string)
    {
        mosyajax_drop("doc_nos", doc_nos_where_str, doc_nos_callback_function_string)

    }
	//End drop  doc_nos Data ===============
    
    function initialize_doc_nos(qstr="", doc_nos_callback_function_string="")
    {
    
    ///alert(qstr);
      var doc_nos_token_query =qstr;
      if(qstr=="")
      {
       var doc_nos_token_query_param="";
       var doc_nos_js_uptoken=mosy_get_param("doc_nos_uptoken");
       //alert(doc_nos_js_uptoken);
       if(doc_nos_js_uptoken!==undefined)
       {
       
        doc_nos_token_query_param = atob(doc_nos_js_uptoken);
       }
        doc_nos_token_query = " where primkey='"+(doc_nos_token_query_param)+"'";
        
           if (document.getElementById("doc_nos_uptoken") !==null) {
           	if(document.getElementById("doc_nos_uptoken").value!="")
            {
            
            var doc_nos_atob_tbl_key =atob(document.getElementById("doc_nos_uptoken").value);
            
                   
            doc_nos_token_query = " where primkey='"+(doc_nos_atob_tbl_key)+"'";

            }
           }
      }
      
      var doc_nos_push_ui_data_to =doc_nos_callback_function_string;
      if(doc_nos_callback_function_string=="")
      {
      doc_nos_push_ui_data_to = "add_doc_nos_ui_data";
      }
                
      console.log(doc_nos_token_query+" -- "+doc_nos_js_uptoken);

	  //alert(doc_nos_push_ui_data_to);

     get_doc_nos("*", doc_nos_token_query, "primkey", "blackhole", doc_nos_push_ui_data_to, "");
    }
    
    function add_doc_nos_ui_data(doc_nos_server_resp) 
    {
    
    ///alert(doc_nos_server_resp);
    
    var json_decoded_str=JSON.parse(doc_nos_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load doc_nos data on the fly ==============
    
	var gft_doc_nos_str="(dockey LIKE '%{{qdoc_nos}}%' OR  user_id LIKE '%{{qdoc_nos}}%' OR  doc_no LIKE '%{{qdoc_nos}}%' OR  file_type LIKE '%{{qdoc_nos}}%' OR  creation_date LIKE '%{{qdoc_nos}}%' OR  notif_remark LIKE '%{{qdoc_nos}}%')";
    
    function  gft_doc_nos(qdoc_nos_str)
    {
        	var clean_doc_nos_filter_str=gft_doc_nos_str.replace(/{{qdoc_nos}}/g, magic_clean_str(qdoc_nos_str));
            
            return  clean_doc_nos_filter_str;

    }
    
    function load_doc_nos(doc_nos_qstr, doc_nos_where_str, doc_nos_ret_cols, doc_nos_user_function, doc_nos_result_function, doc_nos_data_tray)
    {
    
    var fdoc_nos_result_function="push_result";
      
    if(doc_nos_result_function!="")
    {
          var fdoc_nos_result_function=doc_nos_result_function;

    }
    	var clean_doc_nos_filter_str=gft_doc_nos_str.replace(/{{qdoc_nos}}/g, magic_clean_str(doc_nos_qstr));
        
        var fdoc_nos_where_str=" where "+clean_doc_nos_filter_str;

    if(doc_nos_where_str!="")
    {
          var fdoc_nos_where_str=" "+doc_nos_where_str;

    }
       
      get_doc_nos("*", fdoc_nos_where_str, doc_nos_ret_cols, doc_nos_user_function, fdoc_nos_result_function, doc_nos_data_tray);
      
    }
    ///=============== load doc_nos data on the fly ==============


 ///=quick load 
 
function qkload_doc_nos(qstr, push_fun="", ui_card="", and_query="", additional_cols="", doc_nos_pagination="")
{

	var doc_nos_list_nodes_str=doc_nos_list_nodes;
  
   if(ui_card!="")
   {
      doc_nos_list_nodes_str=ui_card;
   }
   
   var doc_nos_qret_fun="push_grid_result:doc_nos_tbl_list";
   
   if(push_fun!="")
   {
    doc_nos_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_doc_nos("*", ajaxw+" ("+gft_doc_nos(qstr)+") "+combined_query+"  order by primkey desc ", doc_nos_list_cols+additional_cols_str, "",doc_nos_qret_fun, "c=>"+doc_nos_list_nodes_str, doc_nos_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_doc_nos(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_doc_nos("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qdoc_nos_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_doc_nos("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_doc_nos("*", doc_nos_token_query, "primkey", "blackhole", doc_nos_push_ui_data_to, "");
    

}



//sum 

function sum_doc_nos(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_doc_nos("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function doc_nos_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "doc_nos_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function doc_nos_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "doc_nos_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function doc_nos_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletedoc_nos&doc_nos_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_doc_nos_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('doc_nos')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  file_uploads Data ===============
    
      function get_file_uploads(file_uploads_colstr, file_uploads_filter_col, file_uploads_cols, file_uploads_node_function_name, file_uploads_callback_function_string, file_uploads_ui_tag, file_uploads_pagination)
      {
        mosyflex_sel("file_uploads", file_uploads_colstr, file_uploads_filter_col , file_uploads_cols, file_uploads_node_function_name, file_uploads_callback_function_string, file_uploads_ui_tag, file_uploads_pagination);
        
      }
    //End get  file_uploads Data ===============

    //Start insert  file_uploads Data ===============

	function add_file_uploads(file_uploads_cols, file_uploads_vals, file_uploads_callback_function_string)
    {
		
        mosyajax_create_data("file_uploads", file_uploads_cols, file_uploads_vals, file_uploads_callback_function_string);
     }
     
    //End insert  file_uploads Data ===============

    
    //Start update  file_uploads Data ===============

    function update_file_uploads(file_uploads_update_str, file_uploads_where_str, file_uploads_callback_function_string){
    
		mosyajax_update("file_uploads", file_uploads_update_str, file_uploads_where_str, file_uploads_callback_function_string)
    
    }
    //end  update  file_uploads Data ===============

	//Start drop  file_uploads Data ===============
    function file_uploads_drop(file_uploads_where_str, file_uploads_callback_function_string)
    {
        mosyajax_drop("file_uploads", file_uploads_where_str, file_uploads_callback_function_string)

    }
	//End drop  file_uploads Data ===============
    
    function initialize_file_uploads(qstr="", file_uploads_callback_function_string="")
    {
    
    ///alert(qstr);
      var file_uploads_token_query =qstr;
      if(qstr=="")
      {
       var file_uploads_token_query_param="";
       var file_uploads_js_uptoken=mosy_get_param("file_uploads_uptoken");
       //alert(file_uploads_js_uptoken);
       if(file_uploads_js_uptoken!==undefined)
       {
       
        file_uploads_token_query_param = atob(file_uploads_js_uptoken);
       }
        file_uploads_token_query = " where primkey='"+(file_uploads_token_query_param)+"'";
        
           if (document.getElementById("file_uploads_uptoken") !==null) {
           	if(document.getElementById("file_uploads_uptoken").value!="")
            {
            
            var file_uploads_atob_tbl_key =atob(document.getElementById("file_uploads_uptoken").value);
            
                   
            file_uploads_token_query = " where primkey='"+(file_uploads_atob_tbl_key)+"'";

            }
           }
      }
      
      var file_uploads_push_ui_data_to =file_uploads_callback_function_string;
      if(file_uploads_callback_function_string=="")
      {
      file_uploads_push_ui_data_to = "add_file_uploads_ui_data";
      }
                
      console.log(file_uploads_token_query+" -- "+file_uploads_js_uptoken);

	  //alert(file_uploads_push_ui_data_to);

     get_file_uploads("*", file_uploads_token_query, "primkey", "blackhole", file_uploads_push_ui_data_to, "");
    }
    
    function add_file_uploads_ui_data(file_uploads_server_resp) 
    {
    
    ///alert(file_uploads_server_resp);
    
    var json_decoded_str=JSON.parse(file_uploads_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load file_uploads data on the fly ==============
    
	var gft_file_uploads_str="(file_id LIKE '%{{qfile_uploads}}%' OR  item_id LIKE '%{{qfile_uploads}}%' OR  user_id LIKE '%{{qfile_uploads}}%' OR  file_url LIKE '%{{qfile_uploads}}%' OR  file_type LIKE '%{{qfile_uploads}}%' OR  upload_data LIKE '%{{qfile_uploads}}%' OR  notif_remark LIKE '%{{qfile_uploads}}%')";
    
    function  gft_file_uploads(qfile_uploads_str)
    {
        	var clean_file_uploads_filter_str=gft_file_uploads_str.replace(/{{qfile_uploads}}/g, magic_clean_str(qfile_uploads_str));
            
            return  clean_file_uploads_filter_str;

    }
    
    function load_file_uploads(file_uploads_qstr, file_uploads_where_str, file_uploads_ret_cols, file_uploads_user_function, file_uploads_result_function, file_uploads_data_tray)
    {
    
    var ffile_uploads_result_function="push_result";
      
    if(file_uploads_result_function!="")
    {
          var ffile_uploads_result_function=file_uploads_result_function;

    }
    	var clean_file_uploads_filter_str=gft_file_uploads_str.replace(/{{qfile_uploads}}/g, magic_clean_str(file_uploads_qstr));
        
        var ffile_uploads_where_str=" where "+clean_file_uploads_filter_str;

    if(file_uploads_where_str!="")
    {
          var ffile_uploads_where_str=" "+file_uploads_where_str;

    }
       
      get_file_uploads("*", ffile_uploads_where_str, file_uploads_ret_cols, file_uploads_user_function, ffile_uploads_result_function, file_uploads_data_tray);
      
    }
    ///=============== load file_uploads data on the fly ==============


 ///=quick load 
 
function qkload_file_uploads(qstr, push_fun="", ui_card="", and_query="", additional_cols="", file_uploads_pagination="")
{

	var file_uploads_list_nodes_str=file_uploads_list_nodes;
  
   if(ui_card!="")
   {
      file_uploads_list_nodes_str=ui_card;
   }
   
   var file_uploads_qret_fun="push_grid_result:file_uploads_tbl_list";
   
   if(push_fun!="")
   {
    file_uploads_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_file_uploads("*", ajaxw+" ("+gft_file_uploads(qstr)+") "+combined_query+"  order by primkey desc ", file_uploads_list_cols+additional_cols_str, "",file_uploads_qret_fun, "c=>"+file_uploads_list_nodes_str, file_uploads_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_file_uploads(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_file_uploads("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qfile_uploads_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_file_uploads("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_file_uploads("*", file_uploads_token_query, "primkey", "blackhole", file_uploads_push_ui_data_to, "");
    

}



//sum 

function sum_file_uploads(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_file_uploads("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function file_uploads_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "file_uploads_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function file_uploads_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "file_uploads_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function file_uploads_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletefile_uploads&file_uploads_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_file_uploads_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('file_uploads')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  messages Data ===============
    
      function get_messages(messages_colstr, messages_filter_col, messages_cols, messages_node_function_name, messages_callback_function_string, messages_ui_tag, messages_pagination)
      {
        mosyflex_sel("messages", messages_colstr, messages_filter_col , messages_cols, messages_node_function_name, messages_callback_function_string, messages_ui_tag, messages_pagination);
        
      }
    //End get  messages Data ===============

    //Start insert  messages Data ===============

	function add_messages(messages_cols, messages_vals, messages_callback_function_string)
    {
		
        mosyajax_create_data("messages", messages_cols, messages_vals, messages_callback_function_string);
     }
     
    //End insert  messages Data ===============

    
    //Start update  messages Data ===============

    function update_messages(messages_update_str, messages_where_str, messages_callback_function_string){
    
		mosyajax_update("messages", messages_update_str, messages_where_str, messages_callback_function_string)
    
    }
    //end  update  messages Data ===============

	//Start drop  messages Data ===============
    function messages_drop(messages_where_str, messages_callback_function_string)
    {
        mosyajax_drop("messages", messages_where_str, messages_callback_function_string)

    }
	//End drop  messages Data ===============
    
    function initialize_messages(qstr="", messages_callback_function_string="")
    {
    
    ///alert(qstr);
      var messages_token_query =qstr;
      if(qstr=="")
      {
       var messages_token_query_param="";
       var messages_js_uptoken=mosy_get_param("messages_uptoken");
       //alert(messages_js_uptoken);
       if(messages_js_uptoken!==undefined)
       {
       
        messages_token_query_param = atob(messages_js_uptoken);
       }
        messages_token_query = " where primkey='"+(messages_token_query_param)+"'";
        
           if (document.getElementById("messages_uptoken") !==null) {
           	if(document.getElementById("messages_uptoken").value!="")
            {
            
            var messages_atob_tbl_key =atob(document.getElementById("messages_uptoken").value);
            
                   
            messages_token_query = " where primkey='"+(messages_atob_tbl_key)+"'";

            }
           }
      }
      
      var messages_push_ui_data_to =messages_callback_function_string;
      if(messages_callback_function_string=="")
      {
      messages_push_ui_data_to = "add_messages_ui_data";
      }
                
      console.log(messages_token_query+" -- "+messages_js_uptoken);

	  //alert(messages_push_ui_data_to);

     get_messages("*", messages_token_query, "primkey", "blackhole", messages_push_ui_data_to, "");
    }
    
    function add_messages_ui_data(messages_server_resp) 
    {
    
    ///alert(messages_server_resp);
    
    var json_decoded_str=JSON.parse(messages_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load messages data on the fly ==============
    
	var gft_messages_str="(message_id LIKE '%{{qmessages}}%' OR  user_email LIKE '%{{qmessages}}%' OR  user_mobile LIKE '%{{qmessages}}%' OR  message_date LIKE '%{{qmessages}}%' OR  message LIKE '%{{qmessages}}%' OR  user_name LIKE '%{{qmessages}}%' OR  service_id LIKE '%{{qmessages}}%' OR  service_name LIKE '%{{qmessages}}%')";
    
    function  gft_messages(qmessages_str)
    {
        	var clean_messages_filter_str=gft_messages_str.replace(/{{qmessages}}/g, magic_clean_str(qmessages_str));
            
            return  clean_messages_filter_str;

    }
    
    function load_messages(messages_qstr, messages_where_str, messages_ret_cols, messages_user_function, messages_result_function, messages_data_tray)
    {
    
    var fmessages_result_function="push_result";
      
    if(messages_result_function!="")
    {
          var fmessages_result_function=messages_result_function;

    }
    	var clean_messages_filter_str=gft_messages_str.replace(/{{qmessages}}/g, magic_clean_str(messages_qstr));
        
        var fmessages_where_str=" where "+clean_messages_filter_str;

    if(messages_where_str!="")
    {
          var fmessages_where_str=" "+messages_where_str;

    }
       
      get_messages("*", fmessages_where_str, messages_ret_cols, messages_user_function, fmessages_result_function, messages_data_tray);
      
    }
    ///=============== load messages data on the fly ==============


 ///=quick load 
 
function qkload_messages(qstr, push_fun="", ui_card="", and_query="", additional_cols="", messages_pagination="")
{

	var messages_list_nodes_str=messages_list_nodes;
  
   if(ui_card!="")
   {
      messages_list_nodes_str=ui_card;
   }
   
   var messages_qret_fun="push_grid_result:messages_tbl_list";
   
   if(push_fun!="")
   {
    messages_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_messages("*", ajaxw+" ("+gft_messages(qstr)+") "+combined_query+"  order by primkey desc ", messages_list_cols+additional_cols_str, "",messages_qret_fun, "c=>"+messages_list_nodes_str, messages_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_messages(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_messages("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmessages_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_messages("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_messages("*", messages_token_query, "primkey", "blackhole", messages_push_ui_data_to, "");
    

}



//sum 

function sum_messages(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_messages("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function messages_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "messages_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function messages_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "messages_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function messages_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemessages&messages_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_messages_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('messages')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  model_list Data ===============
    
      function get_model_list(model_list_colstr, model_list_filter_col, model_list_cols, model_list_node_function_name, model_list_callback_function_string, model_list_ui_tag, model_list_pagination)
      {
        mosyflex_sel("model_list", model_list_colstr, model_list_filter_col , model_list_cols, model_list_node_function_name, model_list_callback_function_string, model_list_ui_tag, model_list_pagination);
        
      }
    //End get  model_list Data ===============

    //Start insert  model_list Data ===============

	function add_model_list(model_list_cols, model_list_vals, model_list_callback_function_string)
    {
		
        mosyajax_create_data("model_list", model_list_cols, model_list_vals, model_list_callback_function_string);
     }
     
    //End insert  model_list Data ===============

    
    //Start update  model_list Data ===============

    function update_model_list(model_list_update_str, model_list_where_str, model_list_callback_function_string){
    
		mosyajax_update("model_list", model_list_update_str, model_list_where_str, model_list_callback_function_string)
    
    }
    //end  update  model_list Data ===============

	//Start drop  model_list Data ===============
    function model_list_drop(model_list_where_str, model_list_callback_function_string)
    {
        mosyajax_drop("model_list", model_list_where_str, model_list_callback_function_string)

    }
	//End drop  model_list Data ===============
    
    function initialize_model_list(qstr="", model_list_callback_function_string="")
    {
    
    ///alert(qstr);
      var model_list_token_query =qstr;
      if(qstr=="")
      {
       var model_list_token_query_param="";
       var model_list_js_uptoken=mosy_get_param("model_list_uptoken");
       //alert(model_list_js_uptoken);
       if(model_list_js_uptoken!==undefined)
       {
       
        model_list_token_query_param = atob(model_list_js_uptoken);
       }
        model_list_token_query = " where primkey='"+(model_list_token_query_param)+"'";
        
           if (document.getElementById("model_list_uptoken") !==null) {
           	if(document.getElementById("model_list_uptoken").value!="")
            {
            
            var model_list_atob_tbl_key =atob(document.getElementById("model_list_uptoken").value);
            
                   
            model_list_token_query = " where primkey='"+(model_list_atob_tbl_key)+"'";

            }
           }
      }
      
      var model_list_push_ui_data_to =model_list_callback_function_string;
      if(model_list_callback_function_string=="")
      {
      model_list_push_ui_data_to = "add_model_list_ui_data";
      }
                
      console.log(model_list_token_query+" -- "+model_list_js_uptoken);

	  //alert(model_list_push_ui_data_to);

     get_model_list("*", model_list_token_query, "primkey", "blackhole", model_list_push_ui_data_to, "");
    }
    
    function add_model_list_ui_data(model_list_server_resp) 
    {
    
    ///alert(model_list_server_resp);
    
    var json_decoded_str=JSON.parse(model_list_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load model_list data on the fly ==============
    
	var gft_model_list_str="(user_id LIKE '%{{qmodel_list}}%' OR  name LIKE '%{{qmodel_list}}%' OR  email LIKE '%{{qmodel_list}}%' OR  tel LIKE '%{{qmodel_list}}%' OR  login_password LIKE '%{{qmodel_list}}%' OR  location LIKE '%{{qmodel_list}}%' OR  orientation LIKE '%{{qmodel_list}}%' OR  haircolor LIKE '%{{qmodel_list}}%' OR  hips LIKE '%{{qmodel_list}}%' OR  bust LIKE '%{{qmodel_list}}%' OR  eyes LIKE '%{{qmodel_list}}%' OR  color_complexion LIKE '%{{qmodel_list}}%' OR  waist LIKE '%{{qmodel_list}}%' OR  verified LIKE '%{{qmodel_list}}%' OR  active_state LIKE '%{{qmodel_list}}%' OR  user_gender LIKE '%{{qmodel_list}}%' OR  registred_on LIKE '%{{qmodel_list}}%' OR  date_of_birth LIKE '%{{qmodel_list}}%' OR  last_seen LIKE '%{{qmodel_list}}%' OR  about LIKE '%{{qmodel_list}}%' OR  height LIKE '%{{qmodel_list}}%' OR  breast_cup LIKE '%{{qmodel_list}}%' OR  ethnicity LIKE '%{{qmodel_list}}%' OR  weight LIKE '%{{qmodel_list}}%' OR  featured LIKE '%{{qmodel_list}}%' OR  account_state LIKE '%{{qmodel_list}}%' OR  slide_show LIKE '%{{qmodel_list}}%' OR  services_list LIKE '%{{qmodel_list}}%' OR  acc_no LIKE '%{{qmodel_list}}%')";
    
    function  gft_model_list(qmodel_list_str)
    {
        	var clean_model_list_filter_str=gft_model_list_str.replace(/{{qmodel_list}}/g, magic_clean_str(qmodel_list_str));
            
            return  clean_model_list_filter_str;

    }
    
    function load_model_list(model_list_qstr, model_list_where_str, model_list_ret_cols, model_list_user_function, model_list_result_function, model_list_data_tray)
    {
    
    var fmodel_list_result_function="push_result";
      
    if(model_list_result_function!="")
    {
          var fmodel_list_result_function=model_list_result_function;

    }
    	var clean_model_list_filter_str=gft_model_list_str.replace(/{{qmodel_list}}/g, magic_clean_str(model_list_qstr));
        
        var fmodel_list_where_str=" where "+clean_model_list_filter_str;

    if(model_list_where_str!="")
    {
          var fmodel_list_where_str=" "+model_list_where_str;

    }
       
      get_model_list("*", fmodel_list_where_str, model_list_ret_cols, model_list_user_function, fmodel_list_result_function, model_list_data_tray);
      
    }
    ///=============== load model_list data on the fly ==============


 ///=quick load 
 
function qkload_model_list(qstr, push_fun="", ui_card="", and_query="", additional_cols="", model_list_pagination="")
{

	var model_list_list_nodes_str=model_list_list_nodes;
  
   if(ui_card!="")
   {
      model_list_list_nodes_str=ui_card;
   }
   
   var model_list_qret_fun="push_grid_result:model_list_tbl_list";
   
   if(push_fun!="")
   {
    model_list_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_model_list("*", ajaxw+" ("+gft_model_list(qstr)+") "+combined_query+"  order by primkey desc ", model_list_list_cols+additional_cols_str, "",model_list_qret_fun, "c=>"+model_list_list_nodes_str, model_list_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_model_list(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_model_list("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmodel_list_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_model_list("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_model_list("*", model_list_token_query, "primkey", "blackhole", model_list_push_ui_data_to, "");
    

}



//sum 

function sum_model_list(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_model_list("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function model_list_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "model_list_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function model_list_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "model_list_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function model_list_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemodel_list&model_list_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_model_list_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('model_list')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  mosy_sql_roll_back Data ===============
    
      function get_mosy_sql_roll_back(mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col, mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination)
      {
        mosyflex_sel("mosy_sql_roll_back", mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col , mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination);
        
      }
    //End get  mosy_sql_roll_back Data ===============

    //Start insert  mosy_sql_roll_back Data ===============

	function add_mosy_sql_roll_back(mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string)
    {
		
        mosyajax_create_data("mosy_sql_roll_back", mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string);
     }
     
    //End insert  mosy_sql_roll_back Data ===============

    
    //Start update  mosy_sql_roll_back Data ===============

    function update_mosy_sql_roll_back(mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string){
    
		mosyajax_update("mosy_sql_roll_back", mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    
    }
    //end  update  mosy_sql_roll_back Data ===============

	//Start drop  mosy_sql_roll_back Data ===============
    function mosy_sql_roll_back_drop(mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    {
        mosyajax_drop("mosy_sql_roll_back", mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)

    }
	//End drop  mosy_sql_roll_back Data ===============
    
    function initialize_mosy_sql_roll_back(qstr="", mosy_sql_roll_back_callback_function_string="")
    {
    
    ///alert(qstr);
      var mosy_sql_roll_back_token_query =qstr;
      if(qstr=="")
      {
       var mosy_sql_roll_back_token_query_param="";
       var mosy_sql_roll_back_js_uptoken=mosy_get_param("mosy_sql_roll_back_uptoken");
       //alert(mosy_sql_roll_back_js_uptoken);
       if(mosy_sql_roll_back_js_uptoken!==undefined)
       {
       
        mosy_sql_roll_back_token_query_param = atob(mosy_sql_roll_back_js_uptoken);
       }
        mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_token_query_param)+"'";
        
           if (document.getElementById("mosy_sql_roll_back_uptoken") !==null) {
           	if(document.getElementById("mosy_sql_roll_back_uptoken").value!="")
            {
            
            var mosy_sql_roll_back_atob_tbl_key =atob(document.getElementById("mosy_sql_roll_back_uptoken").value);
            
                   
            mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_atob_tbl_key)+"'";

            }
           }
      }
      
      var mosy_sql_roll_back_push_ui_data_to =mosy_sql_roll_back_callback_function_string;
      if(mosy_sql_roll_back_callback_function_string=="")
      {
      mosy_sql_roll_back_push_ui_data_to = "add_mosy_sql_roll_back_ui_data";
      }
                
      console.log(mosy_sql_roll_back_token_query+" -- "+mosy_sql_roll_back_js_uptoken);

	  //alert(mosy_sql_roll_back_push_ui_data_to);

     get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    }
    
    function add_mosy_sql_roll_back_ui_data(mosy_sql_roll_back_server_resp) 
    {
    
    ///alert(mosy_sql_roll_back_server_resp);
    
    var json_decoded_str=JSON.parse(mosy_sql_roll_back_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load mosy_sql_roll_back data on the fly ==============
    
	var gft_mosy_sql_roll_back_str="(roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
    
    function  gft_mosy_sql_roll_back(qmosy_sql_roll_back_str)
    {
        	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(qmosy_sql_roll_back_str));
            
            return  clean_mosy_sql_roll_back_filter_str;

    }
    
    function load_mosy_sql_roll_back(mosy_sql_roll_back_qstr, mosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, mosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray)
    {
    
    var fmosy_sql_roll_back_result_function="push_result";
      
    if(mosy_sql_roll_back_result_function!="")
    {
          var fmosy_sql_roll_back_result_function=mosy_sql_roll_back_result_function;

    }
    	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(mosy_sql_roll_back_qstr));
        
        var fmosy_sql_roll_back_where_str=" where "+clean_mosy_sql_roll_back_filter_str;

    if(mosy_sql_roll_back_where_str!="")
    {
          var fmosy_sql_roll_back_where_str=" "+mosy_sql_roll_back_where_str;

    }
       
      get_mosy_sql_roll_back("*", fmosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, fmosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray);
      
    }
    ///=============== load mosy_sql_roll_back data on the fly ==============


 ///=quick load 
 
function qkload_mosy_sql_roll_back(qstr, push_fun="", ui_card="", and_query="", additional_cols="", mosy_sql_roll_back_pagination="")
{

	var mosy_sql_roll_back_list_nodes_str=mosy_sql_roll_back_list_nodes;
  
   if(ui_card!="")
   {
      mosy_sql_roll_back_list_nodes_str=ui_card;
   }
   
   var mosy_sql_roll_back_qret_fun="push_grid_result:mosy_sql_roll_back_tbl_list";
   
   if(push_fun!="")
   {
    mosy_sql_roll_back_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_mosy_sql_roll_back("*", ajaxw+" ("+gft_mosy_sql_roll_back(qstr)+") "+combined_query+"  order by primkey desc ", mosy_sql_roll_back_list_cols+additional_cols_str, "",mosy_sql_roll_back_qret_fun, "c=>"+mosy_sql_roll_back_list_nodes_str, mosy_sql_roll_back_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_mosy_sql_roll_back(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_mosy_sql_roll_back("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmosy_sql_roll_back_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_mosy_sql_roll_back("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    

}



//sum 

function sum_mosy_sql_roll_back(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_mosy_sql_roll_back("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function mosy_sql_roll_back_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function mosy_sql_roll_back_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function mosy_sql_roll_back_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemosy_sql_roll_back&mosy_sql_roll_back_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_mosy_sql_roll_back_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('mosy_sql_roll_back')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  service_tbl Data ===============
    
      function get_service_tbl(service_tbl_colstr, service_tbl_filter_col, service_tbl_cols, service_tbl_node_function_name, service_tbl_callback_function_string, service_tbl_ui_tag, service_tbl_pagination)
      {
        mosyflex_sel("service_tbl", service_tbl_colstr, service_tbl_filter_col , service_tbl_cols, service_tbl_node_function_name, service_tbl_callback_function_string, service_tbl_ui_tag, service_tbl_pagination);
        
      }
    //End get  service_tbl Data ===============

    //Start insert  service_tbl Data ===============

	function add_service_tbl(service_tbl_cols, service_tbl_vals, service_tbl_callback_function_string)
    {
		
        mosyajax_create_data("service_tbl", service_tbl_cols, service_tbl_vals, service_tbl_callback_function_string);
     }
     
    //End insert  service_tbl Data ===============

    
    //Start update  service_tbl Data ===============

    function update_service_tbl(service_tbl_update_str, service_tbl_where_str, service_tbl_callback_function_string){
    
		mosyajax_update("service_tbl", service_tbl_update_str, service_tbl_where_str, service_tbl_callback_function_string)
    
    }
    //end  update  service_tbl Data ===============

	//Start drop  service_tbl Data ===============
    function service_tbl_drop(service_tbl_where_str, service_tbl_callback_function_string)
    {
        mosyajax_drop("service_tbl", service_tbl_where_str, service_tbl_callback_function_string)

    }
	//End drop  service_tbl Data ===============
    
    function initialize_service_tbl(qstr="", service_tbl_callback_function_string="")
    {
    
    ///alert(qstr);
      var service_tbl_token_query =qstr;
      if(qstr=="")
      {
       var service_tbl_token_query_param="";
       var service_tbl_js_uptoken=mosy_get_param("service_tbl_uptoken");
       //alert(service_tbl_js_uptoken);
       if(service_tbl_js_uptoken!==undefined)
       {
       
        service_tbl_token_query_param = atob(service_tbl_js_uptoken);
       }
        service_tbl_token_query = " where primkey='"+(service_tbl_token_query_param)+"'";
        
           if (document.getElementById("service_tbl_uptoken") !==null) {
           	if(document.getElementById("service_tbl_uptoken").value!="")
            {
            
            var service_tbl_atob_tbl_key =atob(document.getElementById("service_tbl_uptoken").value);
            
                   
            service_tbl_token_query = " where primkey='"+(service_tbl_atob_tbl_key)+"'";

            }
           }
      }
      
      var service_tbl_push_ui_data_to =service_tbl_callback_function_string;
      if(service_tbl_callback_function_string=="")
      {
      service_tbl_push_ui_data_to = "add_service_tbl_ui_data";
      }
                
      console.log(service_tbl_token_query+" -- "+service_tbl_js_uptoken);

	  //alert(service_tbl_push_ui_data_to);

     get_service_tbl("*", service_tbl_token_query, "primkey", "blackhole", service_tbl_push_ui_data_to, "");
    }
    
    function add_service_tbl_ui_data(service_tbl_server_resp) 
    {
    
    ///alert(service_tbl_server_resp);
    
    var json_decoded_str=JSON.parse(service_tbl_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load service_tbl data on the fly ==============
    
	var gft_service_tbl_str="(service_id LIKE '%{{qservice_tbl}}%' OR  user_id LIKE '%{{qservice_tbl}}%' OR  service_name LIKE '%{{qservice_tbl}}%')";
    
    function  gft_service_tbl(qservice_tbl_str)
    {
        	var clean_service_tbl_filter_str=gft_service_tbl_str.replace(/{{qservice_tbl}}/g, magic_clean_str(qservice_tbl_str));
            
            return  clean_service_tbl_filter_str;

    }
    
    function load_service_tbl(service_tbl_qstr, service_tbl_where_str, service_tbl_ret_cols, service_tbl_user_function, service_tbl_result_function, service_tbl_data_tray)
    {
    
    var fservice_tbl_result_function="push_result";
      
    if(service_tbl_result_function!="")
    {
          var fservice_tbl_result_function=service_tbl_result_function;

    }
    	var clean_service_tbl_filter_str=gft_service_tbl_str.replace(/{{qservice_tbl}}/g, magic_clean_str(service_tbl_qstr));
        
        var fservice_tbl_where_str=" where "+clean_service_tbl_filter_str;

    if(service_tbl_where_str!="")
    {
          var fservice_tbl_where_str=" "+service_tbl_where_str;

    }
       
      get_service_tbl("*", fservice_tbl_where_str, service_tbl_ret_cols, service_tbl_user_function, fservice_tbl_result_function, service_tbl_data_tray);
      
    }
    ///=============== load service_tbl data on the fly ==============


 ///=quick load 
 
function qkload_service_tbl(qstr, push_fun="", ui_card="", and_query="", additional_cols="", service_tbl_pagination="")
{

	var service_tbl_list_nodes_str=service_tbl_list_nodes;
  
   if(ui_card!="")
   {
      service_tbl_list_nodes_str=ui_card;
   }
   
   var service_tbl_qret_fun="push_grid_result:service_tbl_tbl_list";
   
   if(push_fun!="")
   {
    service_tbl_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_service_tbl("*", ajaxw+" ("+gft_service_tbl(qstr)+") "+combined_query+"  order by primkey desc ", service_tbl_list_cols+additional_cols_str, "",service_tbl_qret_fun, "c=>"+service_tbl_list_nodes_str, service_tbl_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_service_tbl(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_service_tbl("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qservice_tbl_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_service_tbl("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_service_tbl("*", service_tbl_token_query, "primkey", "blackhole", service_tbl_push_ui_data_to, "");
    

}



//sum 

function sum_service_tbl(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_service_tbl("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function service_tbl_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "service_tbl_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function service_tbl_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "service_tbl_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function service_tbl_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteservice_tbl&service_tbl_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_service_tbl_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('service_tbl')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  system_admins Data ===============
    
      function get_system_admins(system_admins_colstr, system_admins_filter_col, system_admins_cols, system_admins_node_function_name, system_admins_callback_function_string, system_admins_ui_tag, system_admins_pagination)
      {
        mosyflex_sel("system_admins", system_admins_colstr, system_admins_filter_col , system_admins_cols, system_admins_node_function_name, system_admins_callback_function_string, system_admins_ui_tag, system_admins_pagination);
        
      }
    //End get  system_admins Data ===============

    //Start insert  system_admins Data ===============

	function add_system_admins(system_admins_cols, system_admins_vals, system_admins_callback_function_string)
    {
		
        mosyajax_create_data("system_admins", system_admins_cols, system_admins_vals, system_admins_callback_function_string);
     }
     
    //End insert  system_admins Data ===============

    
    //Start update  system_admins Data ===============

    function update_system_admins(system_admins_update_str, system_admins_where_str, system_admins_callback_function_string){
    
		mosyajax_update("system_admins", system_admins_update_str, system_admins_where_str, system_admins_callback_function_string)
    
    }
    //end  update  system_admins Data ===============

	//Start drop  system_admins Data ===============
    function system_admins_drop(system_admins_where_str, system_admins_callback_function_string)
    {
        mosyajax_drop("system_admins", system_admins_where_str, system_admins_callback_function_string)

    }
	//End drop  system_admins Data ===============
    
    function initialize_system_admins(qstr="", system_admins_callback_function_string="")
    {
    
    ///alert(qstr);
      var system_admins_token_query =qstr;
      if(qstr=="")
      {
       var system_admins_token_query_param="";
       var system_admins_js_uptoken=mosy_get_param("system_admins_uptoken");
       //alert(system_admins_js_uptoken);
       if(system_admins_js_uptoken!==undefined)
       {
       
        system_admins_token_query_param = atob(system_admins_js_uptoken);
       }
        system_admins_token_query = " where primkey='"+(system_admins_token_query_param)+"'";
        
           if (document.getElementById("system_admins_uptoken") !==null) {
           	if(document.getElementById("system_admins_uptoken").value!="")
            {
            
            var system_admins_atob_tbl_key =atob(document.getElementById("system_admins_uptoken").value);
            
                   
            system_admins_token_query = " where primkey='"+(system_admins_atob_tbl_key)+"'";

            }
           }
      }
      
      var system_admins_push_ui_data_to =system_admins_callback_function_string;
      if(system_admins_callback_function_string=="")
      {
      system_admins_push_ui_data_to = "add_system_admins_ui_data";
      }
                
      console.log(system_admins_token_query+" -- "+system_admins_js_uptoken);

	  //alert(system_admins_push_ui_data_to);

     get_system_admins("*", system_admins_token_query, "primkey", "blackhole", system_admins_push_ui_data_to, "");
    }
    
    function add_system_admins_ui_data(system_admins_server_resp) 
    {
    
    ///alert(system_admins_server_resp);
    
    var json_decoded_str=JSON.parse(system_admins_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load system_admins data on the fly ==============
    
	var gft_system_admins_str="(user_id LIKE '%{{qsystem_admins}}%' OR  name LIKE '%{{qsystem_admins}}%' OR  email LIKE '%{{qsystem_admins}}%' OR  tel LIKE '%{{qsystem_admins}}%' OR  login_password LIKE '%{{qsystem_admins}}%' OR  ref_id LIKE '%{{qsystem_admins}}%' OR  regdate LIKE '%{{qsystem_admins}}%' OR  user_no LIKE '%{{qsystem_admins}}%' OR  user_pic LIKE '%{{qsystem_admins}}%' OR  user_gender LIKE '%{{qsystem_admins}}%' OR  last_seen LIKE '%{{qsystem_admins}}%' OR  about LIKE '%{{qsystem_admins}}%')";
    
    function  gft_system_admins(qsystem_admins_str)
    {
        	var clean_system_admins_filter_str=gft_system_admins_str.replace(/{{qsystem_admins}}/g, magic_clean_str(qsystem_admins_str));
            
            return  clean_system_admins_filter_str;

    }
    
    function load_system_admins(system_admins_qstr, system_admins_where_str, system_admins_ret_cols, system_admins_user_function, system_admins_result_function, system_admins_data_tray)
    {
    
    var fsystem_admins_result_function="push_result";
      
    if(system_admins_result_function!="")
    {
          var fsystem_admins_result_function=system_admins_result_function;

    }
    	var clean_system_admins_filter_str=gft_system_admins_str.replace(/{{qsystem_admins}}/g, magic_clean_str(system_admins_qstr));
        
        var fsystem_admins_where_str=" where "+clean_system_admins_filter_str;

    if(system_admins_where_str!="")
    {
          var fsystem_admins_where_str=" "+system_admins_where_str;

    }
       
      get_system_admins("*", fsystem_admins_where_str, system_admins_ret_cols, system_admins_user_function, fsystem_admins_result_function, system_admins_data_tray);
      
    }
    ///=============== load system_admins data on the fly ==============


 ///=quick load 
 
function qkload_system_admins(qstr, push_fun="", ui_card="", and_query="", additional_cols="", system_admins_pagination="")
{

	var system_admins_list_nodes_str=system_admins_list_nodes;
  
   if(ui_card!="")
   {
      system_admins_list_nodes_str=ui_card;
   }
   
   var system_admins_qret_fun="push_grid_result:system_admins_tbl_list";
   
   if(push_fun!="")
   {
    system_admins_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_system_admins("*", ajaxw+" ("+gft_system_admins(qstr)+") "+combined_query+"  order by primkey desc ", system_admins_list_cols+additional_cols_str, "",system_admins_qret_fun, "c=>"+system_admins_list_nodes_str, system_admins_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_system_admins(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_system_admins("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qsystem_admins_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_system_admins("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_system_admins("*", system_admins_token_query, "primkey", "blackhole", system_admins_push_ui_data_to, "");
    

}



//sum 

function sum_system_admins(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_system_admins("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function system_admins_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_admins_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function system_admins_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_admins_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function system_admins_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletesystem_admins&system_admins_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_system_admins_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('system_admins')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  user_traffic Data ===============
    
      function get_user_traffic(user_traffic_colstr, user_traffic_filter_col, user_traffic_cols, user_traffic_node_function_name, user_traffic_callback_function_string, user_traffic_ui_tag, user_traffic_pagination)
      {
        mosyflex_sel("user_traffic", user_traffic_colstr, user_traffic_filter_col , user_traffic_cols, user_traffic_node_function_name, user_traffic_callback_function_string, user_traffic_ui_tag, user_traffic_pagination);
        
      }
    //End get  user_traffic Data ===============

    //Start insert  user_traffic Data ===============

	function add_user_traffic(user_traffic_cols, user_traffic_vals, user_traffic_callback_function_string)
    {
		
        mosyajax_create_data("user_traffic", user_traffic_cols, user_traffic_vals, user_traffic_callback_function_string);
     }
     
    //End insert  user_traffic Data ===============

    
    //Start update  user_traffic Data ===============

    function update_user_traffic(user_traffic_update_str, user_traffic_where_str, user_traffic_callback_function_string){
    
		mosyajax_update("user_traffic", user_traffic_update_str, user_traffic_where_str, user_traffic_callback_function_string)
    
    }
    //end  update  user_traffic Data ===============

	//Start drop  user_traffic Data ===============
    function user_traffic_drop(user_traffic_where_str, user_traffic_callback_function_string)
    {
        mosyajax_drop("user_traffic", user_traffic_where_str, user_traffic_callback_function_string)

    }
	//End drop  user_traffic Data ===============
    
    function initialize_user_traffic(qstr="", user_traffic_callback_function_string="")
    {
    
    ///alert(qstr);
      var user_traffic_token_query =qstr;
      if(qstr=="")
      {
       var user_traffic_token_query_param="";
       var user_traffic_js_uptoken=mosy_get_param("user_traffic_uptoken");
       //alert(user_traffic_js_uptoken);
       if(user_traffic_js_uptoken!==undefined)
       {
       
        user_traffic_token_query_param = atob(user_traffic_js_uptoken);
       }
        user_traffic_token_query = " where primkey='"+(user_traffic_token_query_param)+"'";
        
           if (document.getElementById("user_traffic_uptoken") !==null) {
           	if(document.getElementById("user_traffic_uptoken").value!="")
            {
            
            var user_traffic_atob_tbl_key =atob(document.getElementById("user_traffic_uptoken").value);
            
                   
            user_traffic_token_query = " where primkey='"+(user_traffic_atob_tbl_key)+"'";

            }
           }
      }
      
      var user_traffic_push_ui_data_to =user_traffic_callback_function_string;
      if(user_traffic_callback_function_string=="")
      {
      user_traffic_push_ui_data_to = "add_user_traffic_ui_data";
      }
                
      console.log(user_traffic_token_query+" -- "+user_traffic_js_uptoken);

	  //alert(user_traffic_push_ui_data_to);

     get_user_traffic("*", user_traffic_token_query, "primkey", "blackhole", user_traffic_push_ui_data_to, "");
    }
    
    function add_user_traffic_ui_data(user_traffic_server_resp) 
    {
    
    ///alert(user_traffic_server_resp);
    
    var json_decoded_str=JSON.parse(user_traffic_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load user_traffic data on the fly ==============
    
	var gft_user_traffic_str="(traffic_key LIKE '%{{quser_traffic}}%' OR  traffic_date LIKE '%{{quser_traffic}}%' OR  user_id LIKE '%{{quser_traffic}}%' OR  traffic_type LIKE '%{{quser_traffic}}%' OR  notif_remark LIKE '%{{quser_traffic}}%')";
    
    function  gft_user_traffic(quser_traffic_str)
    {
        	var clean_user_traffic_filter_str=gft_user_traffic_str.replace(/{{quser_traffic}}/g, magic_clean_str(quser_traffic_str));
            
            return  clean_user_traffic_filter_str;

    }
    
    function load_user_traffic(user_traffic_qstr, user_traffic_where_str, user_traffic_ret_cols, user_traffic_user_function, user_traffic_result_function, user_traffic_data_tray)
    {
    
    var fuser_traffic_result_function="push_result";
      
    if(user_traffic_result_function!="")
    {
          var fuser_traffic_result_function=user_traffic_result_function;

    }
    	var clean_user_traffic_filter_str=gft_user_traffic_str.replace(/{{quser_traffic}}/g, magic_clean_str(user_traffic_qstr));
        
        var fuser_traffic_where_str=" where "+clean_user_traffic_filter_str;

    if(user_traffic_where_str!="")
    {
          var fuser_traffic_where_str=" "+user_traffic_where_str;

    }
       
      get_user_traffic("*", fuser_traffic_where_str, user_traffic_ret_cols, user_traffic_user_function, fuser_traffic_result_function, user_traffic_data_tray);
      
    }
    ///=============== load user_traffic data on the fly ==============


 ///=quick load 
 
function qkload_user_traffic(qstr, push_fun="", ui_card="", and_query="", additional_cols="", user_traffic_pagination="")
{

	var user_traffic_list_nodes_str=user_traffic_list_nodes;
  
   if(ui_card!="")
   {
      user_traffic_list_nodes_str=ui_card;
   }
   
   var user_traffic_qret_fun="push_grid_result:user_traffic_tbl_list";
   
   if(push_fun!="")
   {
    user_traffic_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_user_traffic("*", ajaxw+" ("+gft_user_traffic(qstr)+") "+combined_query+"  order by primkey desc ", user_traffic_list_cols+additional_cols_str, "",user_traffic_qret_fun, "c=>"+user_traffic_list_nodes_str, user_traffic_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_user_traffic(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_user_traffic("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function quser_traffic_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_user_traffic("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_user_traffic("*", user_traffic_token_query, "primkey", "blackhole", user_traffic_push_ui_data_to, "");
    

}



//sum 

function sum_user_traffic(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_user_traffic("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function user_traffic_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "user_traffic_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function user_traffic_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "user_traffic_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function user_traffic_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteuser_traffic&user_traffic_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_user_traffic_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('user_traffic')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
  //===============End Mosy queries-============

const mosy_msdn_elem = document.querySelectorAll('.mosy_msdn');

mosy_msdn_elem.forEach(el => el.addEventListener('click', event => {

var arguments = event.target.getAttribute("data-mosy_msdn");
  
eval(arguments);

}));

const mosy_tup_elem = document.querySelectorAll('.mosy_tup');

mosy_tup_elem.forEach(el => el.addEventListener('keyup', event => {

var arguments = event.target.getAttribute("data-mosy_tup");
  
eval(arguments);

}));
  
var ajax_url ="./ajaxreqhandler.php";
var mosyajax_sql_url=ajax_url;
   //Ajax Manager
function mosyflex_sel(tbl, colstr, filter_col , cols, node_function_name, callback_function_string, ui_tag, pagination)
{
//alert(filter_col);

    var clean_ui1=ui_tag.replace(/</g, "{{<}}");
    var clean_ui2=clean_ui1.replace(/>/g, "{{>}}");
    var clean_ui3=clean_ui2.replace(/onclick/g, "{{on click}}");
    var clean_ui4=clean_ui3.replace(/onkeyup/g, "{{on keyup}}");
    var clean_ui=clean_ui4.replace(/onchange/g, "{{on change}}");
    
    var json_params_str={"mosyajax_sql_data":filter_col, "colstr":colstr, "cols":cols, "node_function_name":node_function_name, "tbl":tbl, "ui_tag":clean_ui,"pagination":pagination};
   
  	//alert(clean_ui);
  
	mosy_ajax_post(ajax_url, json_params_str, callback_function_string, "");
}

function push_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp+'<div class="col-md-12 p-0 text-right"><span class="badge cpointer" style="font-size:10px;"><i class="fa fa-times-circle"></i> Close</span></div>';
  
  if(server_resp.toString().trim()=='')
  {
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray"> <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
  }
  
  
  if (document.getElementById(additional_callbacks) !==null) {
        
  document.getElementById(additional_callbacks).style.display="block";
  document.getElementById(additional_callbacks).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}



function push_grid_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp;
  
  var tbl_col_str="";
  var tbl_colspan ="";
  var elem_id=additional_callbacks;

  if(additional_callbacks.indexOf(":") >= 0)
  {
     tbl_col_str=additional_callbacks.split(":");
     
     tbl_colspan=tbl_col_str[1];
     
     elem_id=tbl_col_str[0];

  }
///alert(additional_callbacks);
  if(server_resp.toString().trim()=='')
  {
  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid" > <td colspan="'+tbl_colspan+'" style="text-align:center;"><div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div></td> </tr>';

    }else{
        
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
    
    }
  }
  
  
  if (document.getElementById(elem_id) !==null) {
        
  ///document.getElementById(elem_id).style.display="block";
  document.getElementById(elem_id).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}


function push_val(arrkeys, arrvalues)
{
    var r = {},i;
    
    for (let i = 0; i < arrkeys.length; i++) {
        r[arrkeys[i]] = arrvalues[i];
      document.getElementById(arrvalues[i]).value=[arrkeys[i]];
    }

}

    function qddata(server_resp,callbacks)
    {
    //alert(server_resp);
    var retjson = JSON.parse(server_resp)[0];
    
        ///alert(retjson.name);


    return retjson;
    
    
    }
function mosy_ajax_post(post_url, json_params, callback_function_string, additional_callbacks)
{


	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
         split_fun_str=callback_function_string.split(/:(.*)/s);
         
		 fcall_back_function =  split_fun_str[0];
        
         fadditional_callbacks =  split_fun_str[1] ;
    
    }
    
    if (document.getElementById(fadditional_callbacks) !==null) {
      ////  document.getElementById(fadditional_callbacks).style.display="block";
    	///document.getElementById(fadditional_callbacks).innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... '+document.getElementById(fadditional_callbacks).innerHTML;
        
    }
    
       if (document.getElementById("ajax_spinner") !==null) 
       {
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';

       }else{
       	mosy_snack_wgt("Processing request...", "top", "ajax_snack", "200px", "ajax_snack_id", "#000",  "#fff", "");
    
    	mosytoggle_class("ajax_snack_id", "show");
        
       }
       
       
  	var formData = ((json_params)); //Array 
  
      $.ajax({ 
      url: post_url,
      type: "POST",
      data:formData,

      success: function (data) 
      {
        //alert(data);
       if (document.getElementById("ajax_spinner") !==null) 
       {
       
         var result_response_='<i class="fa fa-info-circle"></i> Request Processed Succesfully.';
		
        	if(data=='')
            {
            
        		var result_response_='<i class="fa fa-info-circle"></i> No data .';
            
            }
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML=result_response_;

       } 
       
       push_html("ajax_snack", "");                                          

        window[fcall_back_function](data, fadditional_callbacks);

      }

  })
  
}  


   //Ajax Manager

function mosyajax_create_data(tbl, tbl_cols, tbl_vals, callback_function_string)
{
  ///alert(tbl_cols+" - "+tbl_vals);
  
    var json_params_str={"mosyajax_create":"ok", "tbl_cols":tbl_cols, "tbl_vals":tbl_vals, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

   //Ajax Exe
function mosyajax_update(tbl, update_str, where_str, callback_function_string)
{
  //alert(update_str);
  
    var json_params_str={"mosyajax_update":"ok", "update_str":update_str, "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

function mosyajax_drop(tbl, where_str, callback_function_string)
{
  //alert(where_str);
  
    var json_params_str={"mosyajax_drop":"ok", "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}


function mosyajax_get(getstr, callback_function_string)
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = "";
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
    if (document.getElementById("ajax_spinner") !==null) 
    {
        
      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

  	}

    $.ajax({
      url: ajax_url+"?"+getstr,
      type: 'GET',
      success: function(res) {
       if (document.getElementById("ajax_spinner") !==null) {

          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

       }              
            //alert(res);
        window[fcall_back_function](res, fadditional_callbacks);

          }
      });
}


function mosy_form_data(form_id,  save_action, callback_function_string, additional_callbacks, required_inp="")
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
	var formData = new FormData(document.getElementById(form_id));
  
    if (document.getElementById("ajax_spinner") !==null) {
        
    	document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';
        
    }
    
  	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
    {

	formData.append(save_action, "ok");
	formData.append('mosyrequest_type', "ajax");
        $.ajax({
            type: "POST",
            url: ajax_url,
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
                  if (document.getElementById("ajax_spinner") !==null) {
        
                      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

                  }
              ///alert(data);
        		window[fcall_back_function](data, fadditional_callbacks);
            },
	    complete: function(){
			//alert("Data uploaded successfully.");
	    },
	    error: function (jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
	    } 
        });
      // Display the key/value pairs
      for (var pair of formData.entries()) {
          console.log(pair[0]+ ", " + pair[1]); 
      }
        	  
     }else{
        magic_message('Kindly fill out the required fields', 'dialog_box');
      }
      
      
}

function blackhole(data)
{

}

function show_password(input_name) 
{
  var x = document.getElementById(input_name);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}


function get_newval(elemid)
{
    if (document.getElementById(elemid) !==null) {

	  return document.getElementById(elemid).value;
    }else{
  
  return "";
  }
}

function mosy_response(server_resp, callbacks)
{

	alert("server_resp"+server_resp+" -- Callbacks "+callbacks);

}

function get_html(elemid)
{
    if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).innerHTML;
  }else{
  
  return "";
  }
}

function get_src(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).src;
  }else{
  
  return "";
  }
}

function get_href(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).href;
  }else{
  
  return "";
  }
}


function push_ddown(server_items, selelem)
{

	$('#'+selelem+' option:not(:first)').remove();

	document.getElementById(selelem).innerHTML=document.getElementById(selelem).innerHTML+server_items;

}
//========= formart to num =================

function tonum(req_number, decplc=0)
{

///alert(req_number);

n = parseFloat(req_number).toFixed(decplc)
var withCommas = Number(n).toLocaleString('en');


return withCommas;
}

//========= formart to num =================

function mosy_qstr(string, query_str)
{
    
   if(string.indexOf(query_str)==-1)
    {
      
      var q_str_state="False";
      
    }else{
    
	  var q_str_state="True";
     
	}
    
  return q_str_state;
    
}
function mosy_refresh(new_location)
{

var new_location_str=window.location.href;

  window.location=new_location_str.replace("table_alert", "tbl_alert_old");

}

function mosy_srefresh(server_resp, new_location)
{

  window.location=new_location;

}
////////////////// ===================  js action listener ================  

  var _js_msdn=document.querySelectorAll('js_msdn');
  
  _js_msdn.forEach(el => el.addEventListener('click', event => {
  
  var _mosy_jsmsdn_event_trgt= event.currentTarget;

  
	 _mosy_jsmsdn_jsaction="";
	 _mosy_jsmsdn_arg="";
     
  if (!_mosy_jsmsdn_event_trgt.hasAttribute("data-mosy_js")) 
  {
    // data attribute doesnt exist
  }else{
  
	 _mosy_jsmsdn_jsaction=_mosy_jsmsdn_event_trgt.getAttribute("data-mosy_js");
	 _mosy_jsmsdn_arg=_mosy_jsmsdn_event_trgt.getAttribute("data-_mosy_jsmsdn_arg");
     
  }

     window[_mosy_jsmsdn_jsaction](_mosy_jsmsdn_arg);

  
}));
  
  
  
////////////////// ==================  js action listener ================  



function pop_filter_tray (data_src, card_title, where_str_req,cols,returnfun)
{
  magic_screen(pop_data_filter_card, "alert_box");
        
  var where_str =" and "+(where_str_req);
  var where_str_inp =" and "+magic_clean_str(where_str_req);
  
  if(where_str_req=="")
  {
    var where_str="";
    var where_str_inp ="";
  }
  
  var load_data_set ="load_"+data_src;
  var gft_data_str="gft_"+data_src;
  ///alert(where_str);
  window[load_data_set]("", ajaxw+" "+window[gft_data_str]("")+where_str, cols, returnfun, "push_result:result","card");
  
  //alert(cols);
  var textbox ='<input type="text" class="form-control" onkeyup="'+load_data_set+'(this.value, \''+ajaxw+' \'+'+gft_data_str+'(this.value)+\''+where_str_inp+'\', \''+magic_clean_str(cols)+'\', \''+returnfun+'\', \'push_result:result\',\'card\')" placeholder="Type your search here"/>';
        
  document.getElementById('card_title').innerHTML=card_title;
  document.getElementById('dope_text').innerHTML=textbox;

        
}


function mosytoggle_elem(elemid, new_val)
{
  if(new_val=='')
  {
  if(document.getElementById(elemid).style.display!='none')
  {
    document.getElementById(elemid).style.display='none';
  }else{
    document.getElementById(elemid).style.display='block';
  }
  }else{
    document.getElementById(elemid).style.display=new_val;
  }
}

function tray_uptoken(datakey,callbacks)
{
  
  window.location=callbacks[0]+'?'+callbacks[1]+'_uptoken='+btoa(datakey[0]);
}

var pop_data_filter_card=`
    <h5><i class="fa fa-search mr-2"></i><span id="card_title"></span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  	<div id="dope_text" class="col-md-12"></div>
	<div id="result" class="col-md-12" style="max-height:300px; overflow-y:auto;" onclick="this.style.display='none'"></div>
    
  	<div id="r" class="col-md-12 row justify-content-center m-0 p-0 mt-3">
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5 mr-lg-3" id="pop_tray_location"> 
        	View All <i class="fa fa-arrow-right"></i> 
        </a>
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5" id="new_pop_tray_location"> 
        	<i class="fa fa-plus" id="newclass"></i> 
        	<span id="new_record_label"> Add new </span> 
        </a>
    </div>
  </div>`;
  
function push_link(new_link,anchor_el)
{

	//alert(new_link);
	document.getElementById(anchor_el).href=new_link;

}


function push_html(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

	  document.getElementById(elemid).innerHTML=new_val;
      
      }
}

function push_newval(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

  		document.getElementById(elemid).value=new_val;
  
  }
}

function push_src(elemid, new_val)
{
	    if (document.getElementById(elemid) !==null) {

	  		document.getElementById(elemid).src=new_val;
      
      }
}

function mosytoggle_class(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_addclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    //document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_remclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }
  
}


function mosyhide_elem(elemid, new_class="")
{
    var curr_class="none";
    if(new_class!="")
    {
    curr_class=new_class;
    }
   document.getElementById(elemid).style.display=curr_class;

}

function mosyshow_elem(elemid, new_class="")
{
    var curr_class="block";
    if(new_class!="")
    {
    curr_class=new_class;
    }
   document.getElementById(elemid).style.display=curr_class;

}

function mosy_get_param(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}


function mosy_push_data(elemid,data)
{
	var elem_state ="false";
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      
      push_newval(elemid, data);
      push_html(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, "<option>"+data+"</option>"+get_html(elemid));
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  
}

function check_elem(elemid)
{
    if (document.getElementById(elemid) ===null) 
    {
    alert("element_"+elemid+" Not available");
    }
}

function push_shtml(server_res, callback)
{
  
  magic_message(callback, "dialog_box");
  
}
function mosy_push_num_ddata(_server_resp, elemid_str)
{
	//alert(_server_resp);
    
	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = (elemid_arr[0]);
        
          data_str = elemid_arr[1];
          
          console.log(elemid+" state "+ data_str+" serep "+_server_resp);

         data = tonum(json_decoded_str[data_str]);
        
    }
    
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
            
      push_html(elemid, data);
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function mosy_push_ddata(_server_resp, elemid_str)
{

///alert(_server_resp);

	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = elemid_arr[0];
        
          data_str = elemid_arr[1];
          

         data = json_decoded_str[data_str];
        
    }
              
    console.log(elemid+" state "+ data_str+" serep "+_server_resp);

    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      push_html(elemid, data);      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}


///////////////  slide show 
function mosy_slide_wgt(image_arr_n_captions, img_style, img_class, extra_attr, slide_indicators_yes_no)
{
  
const rem_array = image_arr_n_captions.slice(0, 0).concat(image_arr_n_captions.slice(0+1, image_arr_n_captions.length));
  
var curr_slide_id =magic_random_str(10);
    
var img_string =  image_arr_n_captions[0];
var caption_str = ""
var caption_str_div="";
var datakey = "";
  
if(image_arr_n_captions[0].includes(":"))
{
 img_string =  image_arr_n_captions[0].substring(0, image_arr_n_captions[0].indexOf(':')); 
 datakey_1 = image_arr_n_captions[0].substring(image_arr_n_captions[0].indexOf(':')+1); 
 datakey = datakey_1.substring(0, datakey_1.indexOf(':'));
 datakey_2 = datakey_1.substring(datakey_1.indexOf(':')+1);
 caption_str = datakey_2.substring(datakey_2.indexOf(':'));
 caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${caption_str} </div>`;
}
  ///alert("dkey1 -- "+datakey_2);
 var slide_node="";
 var slidecounter="";
 var i=0;
  
 if(slide_indicators_yes_no=='yes')
 {
   slidecounter=`<li data-target="#slide_s${curr_slide_id}" data-slide-to="0" class="active"></li>`;
 }
 for(img_arr of rem_array)
 {
   i++;
   
	if(slide_indicators_yes_no=='yes'){
 slidecounter+=`
        <li data-target="#slide_s${curr_slide_id}" data-slide-to="${i}" class="active"></li>
   `;  
    }
   
   var loop_img_string =  img_arr;
   var loop_caption_str = "";
   var loop_caption_str_div="";
   var loop_datakey="";
   
   if(img_arr.includes(":")){
 	loop_img_string =  img_arr.substring(0, img_arr.indexOf(':')); 
 	loop_datakey_1 = img_arr.substring(img_arr.indexOf(':')+1); 
 	loop_datakey = loop_datakey_1.substring(0, loop_datakey_1.indexOf(':'));
 	loop_datakey_2 = loop_datakey_1.substring(loop_datakey_1.indexOf(':')+1);
 	loop_caption_str = loop_datakey_2.substring(loop_datakey_2.indexOf(':'));
 	loop_caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${loop_caption_str} </div>`;
   }
   
   slide_node+=`   
            <!-- carousel item -->
            <div class="carousel-item">
             <div class="row pt-3 justify-content-center">
     			${loop_caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${loop_img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${loop_datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->`;
   
 }
  
var slide_tray=`
      <!--------------- Start carousel ---------->
      <div id="slide_s${curr_slide_id}" class="carousel slide w-100" data-ride="carousel" data-interval="2000">
        <ol class="carousel-indicators mt-2">
  		${slidecounter}
        </ol>
        <!-- carousel inner -->
          <div class="carousel-inner">
            <!-- carousel item -->
            <div class="carousel-item active">
             <div class="row pt-3 justify-content-center">
          	   ${caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->
		   ${slide_node}
            <!-- carousel inner -->
            <a class="carousel-control-prev" href="#slide_s${curr_slide_id}" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a class="carousel-control-next" href="#slide_s${curr_slide_id}" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a> 
          </div>
             
      </div>
      <!--------------- End carousel ---------->
        `;
  
return [slide_tray, curr_slide_id];  
}
///////////////  slide show 

//////////////  image alert 
function mosy_img_pop(img_src,img_style, img_class,  extra_attr, slide_show_yes_no)
{
  var img_tray=
    `
    <img src="${img_src}" style="${img_style}" class="${img_class}"/>
    
    `;
  
  if(slide_show_yes_no=='yes')
  {
    
    var pop_tray_carousel = mosy_slide_wgt(img_src, img_style, img_class, extra_attr)[0];
    
    magic_screen(pop_tray_carousel, 'alert_box');
    
  }else{
  	magic_screen(img_tray, 'alert_box');
  }
  
}  

//////////////  image alert \

function mosy_snack_wgt(content, curr_position, push_to, snack_pos, snackid, color, bg, onclick_fun)
{
              
var snack_cont=`
<style>
/* The snackbar - position it at the bottom and in the middle of the screen */
#${snackid} {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background:${bg}; /* Black background color */
  color: ${color}; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 9999; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  ${curr_position}: ${snack_pos}; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#${snackid}.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}

@keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}
</style>
  
  <div id="${snackid}" onclick="${onclick_fun};push_html('${push_to}', '')">${content}</div>

  `;


push_html(push_to, snack_cont);


} 

function new_location(new_location_str)
{
window.location=new_location_str;
}

function mosy_reload()
{
   document.location.reload()

} 

function glass_modal()
{
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("background-color", "transparent", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border-top", "0px solid", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border", "0px solid", "important");;
}

function mosy_card(card_title="", card_content, attach_To)
{
	var mosy_card_title="";
    if(card_title!="")
    {
    var mosy_card_title=`
                          <!-- Start  Title ribbon-->
                      <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                        <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                        <div class="col-md-8 text-center"><b> ${card_title}</b></div>
                        <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                      </h5>
                      <!-- End Title ribbon--> 
    `;
    }
    var link_pop=`
    <div class="row justify-content-center m-0 p-0 col-md-12">
						${mosy_card_title}
                      <div class="row justify-content-center m-0 p-0 col-md-12 mt-3 mb-3">
                        ${card_content}
                      </div>
      </div>
    </div>

    `;

    if(attach_To=='' || attach_To==undefined)
    {
    magic_screen(link_pop, 'alert_box');
    }else{
      push_html(attach_To, link_pop);
    }

    return link_pop;
 
}
//<--ncgh-->
