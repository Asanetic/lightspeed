
  
  
////========================= start doc_nos inputs widget 



function doc_nos_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, doc_nos_input_wgt(doc_nos_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== doc_nos ========================

 var doc_nos_js_input=["txt_user_id:User Id:text:col-md-6","txt_doc_no:Doc No:text:col-md-6","txt_file_type:File Type:text:col-md-6","txt_creation_date:Creation Date:text:col-md-6","txt_notif_remark:Notif Remark:text:col-md-6",];


function doc_nos_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_user_id":"User Id:text:col-md-6","txt_doc_no":"Doc No:text:col-md-6","txt_file_type":"File Type:text:col-md-6","txt_creation_date":"Creation Date:text:col-md-6","txt_notif_remark":"Notif Remark:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start file_uploads inputs widget 



function file_uploads_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, file_uploads_input_wgt(file_uploads_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== file_uploads ========================

 var file_uploads_js_input=["txt_item_id:Item Id:text:col-md-6","txt_user_id:User Id:text:col-md-6","txt_file_url:File Url:text:col-md-6","txt_file_type:File Type:text:col-md-6","txt_upload_data:Upload Data:text:col-md-6","txt_notif_remark:Notif Remark:text:col-md-6",];


function file_uploads_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_item_id":"Item Id:text:col-md-6","txt_user_id":"User Id:text:col-md-6","txt_file_url":"File Url:text:col-md-6","txt_file_type":"File Type:text:col-md-6","txt_upload_data":"Upload Data:text:col-md-6","txt_notif_remark":"Notif Remark:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start messages inputs widget 



function messages_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, messages_input_wgt(messages_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== messages ========================

 var messages_js_input=["txt_user_email:User Email:text:col-md-6","txt_user_mobile:User Mobile:text:col-md-6","txt_message_date:Message Date:text:col-md-6","txt_message:Message:text:col-md-6","txt_user_name:User Name:text:col-md-6","txt_service_id:Service Id:text:col-md-6","txt_service_name:Service Name:text:col-md-6",];


function messages_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_user_email":"User Email:text:col-md-6","txt_user_mobile":"User Mobile:text:col-md-6","txt_message_date":"Message Date:text:col-md-6","txt_message":"Message:text:col-md-6","txt_user_name":"User Name:text:col-md-6","txt_service_id":"Service Id:text:col-md-6","txt_service_name":"Service Name:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start model_list inputs widget 



function model_list_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, model_list_input_wgt(model_list_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== model_list ========================

 var model_list_js_input=["txt_name:Name:text:col-md-6","txt_email:Email:text:col-md-6","txt_tel:Tel:text:col-md-6","txt_login_password:Login Password:text:col-md-6","txt_location:Location:text:col-md-6","txt_orientation:Orientation:text:col-md-6","txt_haircolor:Haircolor:text:col-md-6","txt_hips:Hips:text:col-md-6","txt_bust:Bust:text:col-md-6","txt_eyes:Eyes:text:col-md-6","txt_color_complexion:Color Complexion:text:col-md-6","txt_waist:Waist:text:col-md-6","txt_verified:Verified:text:col-md-6","txt_active_state:Active State:text:col-md-6","txt_user_gender:User Gender:user_gender_static_drop_down:col-md-6","txt_registred_on:Registred On:text:col-md-6","txt_date_of_birth:Date Of Birth:text:col-md-6","txt_last_seen:Last Seen:text:col-md-6","txt_about:About:text:col-md-6","txt_height:Height:text:col-md-6","txt_breast_cup:Breast Cup:text:col-md-6","txt_ethnicity:Ethnicity:text:col-md-6","txt_weight:Weight:text:col-md-6","txt_featured:Featured:text:col-md-6","txt_account_state:Account State:text:col-md-6","txt_slide_show:Slide Show:text:col-md-6","txt_services_list:Services List:text:col-md-6","txt_acc_no:Acc No:text:col-md-6",];


function model_list_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_name":"Name:text:col-md-6","txt_email":"Email:text:col-md-6","txt_tel":"Tel:text:col-md-6","txt_login_password":"Login Password:text:col-md-6","txt_location":"Location:text:col-md-6","txt_orientation":"Orientation:text:col-md-6","txt_haircolor":"Haircolor:text:col-md-6","txt_hips":"Hips:text:col-md-6","txt_bust":"Bust:text:col-md-6","txt_eyes":"Eyes:text:col-md-6","txt_color_complexion":"Color Complexion:text:col-md-6","txt_waist":"Waist:text:col-md-6","txt_verified":"Verified:text:col-md-6","txt_active_state":"Active State:text:col-md-6","txt_user_gender":"User Gender:user_gender_static_drop_down:col-md-6","txt_registred_on":"Registred On:text:col-md-6","txt_date_of_birth":"Date Of Birth:text:col-md-6","txt_last_seen":"Last Seen:text:col-md-6","txt_about":"About:text:col-md-6","txt_height":"Height:text:col-md-6","txt_breast_cup":"Breast Cup:text:col-md-6","txt_ethnicity":"Ethnicity:text:col-md-6","txt_weight":"Weight:text:col-md-6","txt_featured":"Featured:text:col-md-6","txt_account_state":"Account State:text:col-md-6","txt_slide_show":"Slide Show:text:col-md-6","txt_services_list":"Services List:text:col-md-6","txt_acc_no":"Acc No:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
           

                
				if(input_type=="user_gender_static_drop_down")
                  {
                input_tag=`
                   <select name="txt_user_gender" id="txt_user_gender" class="form-control">
                   <option>Male</option>
<option>Female</option>

                   </select>`;
                   }
           
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  
              function load_model_list_user_gender_items ()
              {
                var default_user_gender_static_drop_down_val = `                      
                <option >User Gender</option>`;
                
                var static_user_gender_drop_down_items=`<option>Male</option>
<option>Female</option>
`;
           push_html("txt_user_gender", default_user_gender_static_drop_down_val+static_user_gender_drop_down_items);
           }


  
  
////========================= start mosy_sql_roll_back inputs widget 



function mosy_sql_roll_back_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== mosy_sql_roll_back ========================

 var mosy_sql_roll_back_js_input=["txt_table_name:Table Name:text:col-md-6","txt_roll_type:Roll Type:text:col-md-6","txt_where_str:Where Str:text:col-md-6","txt_roll_timestamp:Roll Timestamp:text:col-md-6","txt_value_entries:Value Entries:text:col-md-6",];


function mosy_sql_roll_back_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_table_name":"Table Name:text:col-md-6","txt_roll_type":"Roll Type:text:col-md-6","txt_where_str":"Where Str:text:col-md-6","txt_roll_timestamp":"Roll Timestamp:text:col-md-6","txt_value_entries":"Value Entries:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start service_tbl inputs widget 



function service_tbl_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, service_tbl_input_wgt(service_tbl_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== service_tbl ========================

 var service_tbl_js_input=["txt_user_id:User Id:text:col-md-6","txt_service_name:Service Name:text:col-md-6",];


function service_tbl_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_user_id":"User Id:text:col-md-6","txt_service_name":"Service Name:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start system_admins inputs widget 



function system_admins_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, system_admins_input_wgt(system_admins_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== system_admins ========================

 var system_admins_js_input=["txt_name:Name:text:col-md-6","txt_email:Email:text:col-md-6","txt_tel:Tel:text:col-md-6","txt_login_password:Login Password:text:col-md-6","txt_ref_id:Ref Id:text:col-md-6","txt_regdate:Regdate:datetime-local:col-md-6","txt_user_no:User No:text:col-md-6","txt_system_admins_user_pic:User Pic:file:col-md-6","txt_user_gender:User Gender:user_gender_static_drop_down:col-md-6","txt_last_seen:Last Seen:text:col-md-6","txt_about:About:text:col-md-6",];


function system_admins_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_name":"Name:text:col-md-6","txt_email":"Email:text:col-md-6","txt_tel":"Tel:text:col-md-6","txt_login_password":"Login Password:text:col-md-6","txt_ref_id":"Ref Id:text:col-md-6","txt_regdate":"Regdate:datetime-local:col-md-6","txt_user_no":"User No:text:col-md-6","txt_system_admins_user_pic":"User Pic:file:col-md-6","txt_user_gender":"User Gender:user_gender_static_drop_down:col-md-6","txt_last_seen":"Last Seen:text:col-md-6","txt_about":"About:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
           

                
				if(input_type=="user_gender_static_drop_down")
                  {
                input_tag=`
                   <select name="txt_user_gender" id="txt_user_gender" class="form-control">
                   <option>Male</option>
<option>Female</option>

                   </select>`;
                   }
           
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  
              function load_system_admins_user_gender_items ()
              {
                var default_user_gender_static_drop_down_val = `                      
                <option >User Gender</option>`;
                
                var static_user_gender_drop_down_items=`<option>Male</option>
<option>Female</option>
`;
           push_html("txt_user_gender", default_user_gender_static_drop_down_val+static_user_gender_drop_down_items);
           }


  
  
////========================= start user_traffic inputs widget 



function user_traffic_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, user_traffic_input_wgt(user_traffic_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== user_traffic ========================

 var user_traffic_js_input=["txt_traffic_date:Traffic Date:text:col-md-6","txt_user_id:User Id:text:col-md-6","txt_traffic_type:Traffic Type:text:col-md-6","txt_notif_remark:Notif Remark:text:col-md-6",];


function user_traffic_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_traffic_date":"Traffic Date:text:col-md-6","txt_user_id":"User Id:text:col-md-6","txt_traffic_type":"Traffic Type:text:col-md-6","txt_notif_remark":"Notif Remark:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


 var doc_nos_list_cols ="primkey:Primkey,dockey:Dockey,user_id:User Id,doc_no:Doc No,file_type:File Type,creation_date:Creation Date,notif_remark:Notif Remark";

 var file_uploads_list_cols ="primkey:Primkey,file_id:File Id,item_id:Item Id,user_id:User Id,file_url:File Url,file_type:File Type,upload_data:Upload Data,notif_remark:Notif Remark";

 var messages_list_cols ="primkey:Primkey,message_id:Message Id,user_email:User Email,user_mobile:User Mobile,message_date:Message Date,message:Message,user_name:User Name,service_id:Service Id,service_name:Service Name";

 var model_list_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,location:Location,orientation:Orientation,haircolor:Haircolor,hips:Hips,bust:Bust,eyes:Eyes,color_complexion:Color Complexion,waist:Waist,verified:Verified,active_state:Active State,user_gender:User Gender,registred_on:Registred On,date_of_birth:Date Of Birth,last_seen:Last Seen,about:About,height:Height,breast_cup:Breast Cup,ethnicity:Ethnicity,weight:Weight,featured:Featured,account_state:Account State,slide_show:Slide Show,services_list:Services List,acc_no:Acc No";

 var mosy_sql_roll_back_list_cols ="primkey:Primkey,roll_bk_key:Roll Bk Key,table_name:Table Name,roll_type:Roll Type,where_str:Where Str,roll_timestamp:Roll Timestamp,value_entries:Value Entries";

 var service_tbl_list_cols ="primkey:Primkey,service_id:Service Id,user_id:User Id,service_name:Service Name";

 var system_admins_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,ref_id:Ref Id,regdate:Regdate,user_no:User No,user_pic:User Pic,user_gender:User Gender,last_seen:Last Seen,about:About";

 var user_traffic_list_cols ="primkey:Primkey,traffic_key:Traffic Key,traffic_date:Traffic Date,user_id:User Id,traffic_type:Traffic Type,notif_remark:Notif Remark";



 var doc_nos_list_nodes=`<tr class="cpointer" onclick="mosy_card('Doc Nos Profile ', doc_nos_input_wgt(doc_nos_js_input,'doc_nos_update_btn:Update:check-circle',''), '');initialize_doc_nos(&quot where primkey='{{primkey}}'&quot;);push_newval('doc_nos_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{user_id}}</td>
<td scope="col">{{doc_no}}</td>
<td scope="col">{{file_type}}</td>
<td scope="col">{{creation_date}}</td>
<td scope="col">{{notif_remark}}</td>
</tr>`;


 var file_uploads_list_nodes=`<tr class="cpointer" onclick="mosy_card('File Uploads Profile ', file_uploads_input_wgt(file_uploads_js_input,'file_uploads_update_btn:Update:check-circle',''), '');initialize_file_uploads(&quot where primkey='{{primkey}}'&quot;);push_newval('file_uploads_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{item_id}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{file_url}}</td>
<td scope="col">{{file_type}}</td>
<td scope="col">{{upload_data}}</td>
<td scope="col">{{notif_remark}}</td>
</tr>`;


 var messages_list_nodes=`<tr class="cpointer" onclick="mosy_card('Messages Profile ', messages_input_wgt(messages_js_input,'messages_update_btn:Update:check-circle',''), '');initialize_messages(&quot where primkey='{{primkey}}'&quot;);push_newval('messages_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{user_email}}</td>
<td scope="col">{{user_mobile}}</td>
<td scope="col">{{message_date}}</td>
<td scope="col">{{message}}</td>
<td scope="col">{{user_name}}</td>
<td scope="col">{{service_id}}</td>
<td scope="col">{{service_name}}</td>
</tr>`;


 var model_list_list_nodes=`<tr class="cpointer" onclick="mosy_card('Model List Profile ', model_list_input_wgt(model_list_js_input,'model_list_update_btn:Update:check-circle',''), '');initialize_model_list(&quot where primkey='{{primkey}}'&quot;);push_newval('model_list_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{location}}</td>
<td scope="col">{{orientation}}</td>
<td scope="col">{{haircolor}}</td>
<td scope="col">{{hips}}</td>
<td scope="col">{{bust}}</td>
<td scope="col">{{eyes}}</td>
<td scope="col">{{color_complexion}}</td>
<td scope="col">{{waist}}</td>
<td scope="col">{{verified}}</td>
<td scope="col">{{active_state}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{registred_on}}</td>
<td scope="col">{{date_of_birth}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
<td scope="col">{{height}}</td>
<td scope="col">{{breast_cup}}</td>
<td scope="col">{{ethnicity}}</td>
<td scope="col">{{weight}}</td>
<td scope="col">{{featured}}</td>
<td scope="col">{{account_state}}</td>
<td scope="col">{{slide_show}}</td>
<td scope="col">{{services_list}}</td>
<td scope="col">{{acc_no}}</td>
</tr>`;


 var mosy_sql_roll_back_list_nodes=`<tr class="cpointer" onclick="mosy_card('Mosy Sql Roll Back Profile ', mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input,'mosy_sql_roll_back_update_btn:Update:check-circle',''), '');initialize_mosy_sql_roll_back(&quot where primkey='{{primkey}}'&quot;);push_newval('mosy_sql_roll_back_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{table_name}}</td>
<td scope="col">{{roll_type}}</td>
<td scope="col">{{where_str}}</td>
<td scope="col">{{roll_timestamp}}</td>
<td scope="col">{{value_entries}}</td>
</tr>`;


 var service_tbl_list_nodes=`<tr class="cpointer" onclick="mosy_card('Service Tbl Profile ', service_tbl_input_wgt(service_tbl_js_input,'service_tbl_update_btn:Update:check-circle',''), '');initialize_service_tbl(&quot where primkey='{{primkey}}'&quot;);push_newval('service_tbl_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{user_id}}</td>
<td scope="col">{{service_name}}</td>
</tr>`;


 var system_admins_list_nodes=`<tr class="cpointer" onclick="mosy_card('System Admins Profile ', system_admins_input_wgt(system_admins_js_input,'system_admins_update_btn:Update:check-circle',''), '');initialize_system_admins(&quot where primkey='{{primkey}}'&quot;);push_newval('system_admins_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{regdate}}</td>
<td scope="col">{{user_no}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
</tr>`;


 var user_traffic_list_nodes=`<tr class="cpointer" onclick="mosy_card('User Traffic Profile ', user_traffic_input_wgt(user_traffic_js_input,'user_traffic_update_btn:Update:check-circle',''), '');initialize_user_traffic(&quot where primkey='{{primkey}}'&quot;);push_newval('user_traffic_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{traffic_date}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{traffic_type}}</td>
<td scope="col">{{notif_remark}}</td>
</tr>`;



        var doc_nos_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="doc_nos_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Id</th>
             <th scope="col">Doc No</th>
             <th scope="col">File Type</th>
             <th scope="col">Creation Date</th>
             <th scope="col">Notif Remark</th>

		   </tr>
	    </thead>
	    <tbody id="doc_nos_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var file_uploads_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="file_uploads_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Item Id</th>
             <th scope="col">User Id</th>
             <th scope="col">File Url</th>
             <th scope="col">File Type</th>
             <th scope="col">Upload Data</th>
             <th scope="col">Notif Remark</th>

		   </tr>
	    </thead>
	    <tbody id="file_uploads_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var messages_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="messages_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Email</th>
             <th scope="col">User Mobile</th>
             <th scope="col">Message Date</th>
             <th scope="col">Message</th>
             <th scope="col">User Name</th>
             <th scope="col">Service Id</th>
             <th scope="col">Service Name</th>

		   </tr>
	    </thead>
	    <tbody id="messages_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var model_list_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="model_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Login Password</th>
             <th scope="col">Location</th>
             <th scope="col">Orientation</th>
             <th scope="col">Haircolor</th>
             <th scope="col">Hips</th>
             <th scope="col">Bust</th>
             <th scope="col">Eyes</th>
             <th scope="col">Color Complexion</th>
             <th scope="col">Waist</th>
             <th scope="col">Verified</th>
             <th scope="col">Active State</th>
             <th scope="col">User Gender</th>
             <th scope="col">Registred On</th>
             <th scope="col">Date Of Birth</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>
             <th scope="col">Height</th>
             <th scope="col">Breast Cup</th>
             <th scope="col">Ethnicity</th>
             <th scope="col">Weight</th>
             <th scope="col">Featured</th>
             <th scope="col">Account State</th>
             <th scope="col">Slide Show</th>
             <th scope="col">Services List</th>
             <th scope="col">Acc No</th>

		   </tr>
	    </thead>
	    <tbody id="model_list_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var mosy_sql_roll_back_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="mosy_sql_roll_back_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Table Name</th>
             <th scope="col">Roll Type</th>
             <th scope="col">Where Str</th>
             <th scope="col">Roll Timestamp</th>
             <th scope="col">Value Entries</th>

		   </tr>
	    </thead>
	    <tbody id="mosy_sql_roll_back_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var service_tbl_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="service_tbl_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Id</th>
             <th scope="col">Service Name</th>

		   </tr>
	    </thead>
	    <tbody id="service_tbl_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var system_admins_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="system_admins_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Login Password</th>
             <th scope="col">Ref Id</th>
             <th scope="col">Regdate</th>
             <th scope="col">User No</th>
             <th scope="col">User Gender</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>

		   </tr>
	    </thead>
	    <tbody id="system_admins_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var user_traffic_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="user_traffic_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Traffic Date</th>
             <th scope="col">User Id</th>
             <th scope="col">Traffic Type</th>
             <th scope="col">Notif Remark</th>

		   </tr>
	    </thead>
	    <tbody id="user_traffic_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
