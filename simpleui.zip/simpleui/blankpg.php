<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
 


?>
  
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title>Dreamchat - Dashboard</title>

<?php include('./includes/admin_css_scripts.php');?>
</head>
<body class="mini-sidebar">
    
<form method="post" enctype="multipart/form-data" id="model_form">

<div class="main-wrapper">
<?php include('./includes/adminnav.php'); ?>


<div class="page-wrapper">
<div class="content container-fluid">

<div class="page-header">
<div class="row">
<div class="col-sm-12">
<h3 class="page-title">System Admin </h3>
<ul class="breadcrumb">
<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
<li class="breadcrumb-item active"> System Admin </li>
</ul>
</div>
</div>
</div>

<div class="row">
<div class="col-sm-12">

 
  
</div>
</div>
</div>
</div>

</div>

<?php include('./includes/admin_footer.php');?>
  
</form>
</body> 
</html>