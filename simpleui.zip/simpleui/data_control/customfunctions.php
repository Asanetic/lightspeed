<?php

  if(isset($_POST['post_restock']))
  {
    //------- begin stock_history_arr --> 
$stock_history_arr_=array(

"stock_key_sign"=>magic_random_str(7),
"item_name"=>"Restock Invoice",
"supplier"=>"?",
"shop_location"=>"?",
"receipt_no"=>"?",
"invoice_no"=>"?",
"payment_mode"=>"?",
"inventory_date"=>"?",
"signature"=>"?",
"invoice_amount"=>"?",
"invoice_amount_paid"=>"?",
"invoice_bal_amount"=>"?"

);
//===-- End stock_history_arr -->

 if(count_stock_history("item_name='Restock Invoice' and signature='".$_POST['txt_signature']."' ")==0)
 {
 
   add_stock_history($stock_history_arr_);
   
 }else{
   update_stock_history($stock_history_arr_, " item_name='Restock Invoice' and signature='".$_POST['txt_signature']."' ");
 }  
    
  unset($_SESSION['restock_signature']);
  }

 if(!isset($_SESSION['restock_signature']))
 {
  $_SESSION['restock_signature']=magic_random_str(20);   
 }

 $session_restock_sign=magic_random_str(20);

 if(isset($_SESSION['restock_signature']))
 {
  $session_restock_sign=$_SESSION['restock_signature'];
 }

if(isset($_GET['update_buying_price']))
{
    $update_price_key=$_GET['update_buying_price'];
    $new_price_amt=$_GET['new_bp'];

  update_stock_list(["buying_price"=>$new_price_amt], " item_id='$update_price_key' ");
  
  echo $update_price_key." - ".$new_price_amt;

}


if(isset($_GET['update_selling_price']))
{
    $update_price_key=$_GET['update_selling_price'];
    $new_price_amt=$_GET['new_sp'];

  update_stock_list(["selling_price"=>$new_price_amt], " item_id='$update_price_key' ");
  
  echo $update_price_key." - ".$new_price_amt;

}


if(isset($_GET['update_margin_price']))
{
    $update_price_key=$_GET['update_margin_price'];
    $new_price_amt=$_GET['new_mp'];

  update_stock_list(["margin_price"=>$new_price_amt], " item_id='$update_price_key' ");
  
  echo $update_price_key." - ".$new_price_amt;

}



if(isset($_GET['update_price']))
{
  $update_price_key=$_GET['update_price'];
  
  update_daily_sales(["quantity"=>$_GET['new_qty']], " primkey='$update_price_key' ");
  $new_tots=sum_daily_sales(" quantity*selling_price ", "  primkey='$update_price_key' ");
  $new_margin_tots=sum_daily_sales(" quantity*(selling_price-buying_price) ", "  primkey='$update_price_key' ");
  update_daily_sales(["totals"=>$new_tots], " primkey='$update_price_key' ");
  update_daily_sales(["margin_price"=>$new_margin_tots], " primkey='$update_price_key' ");
  echo $new_tots;
    
} 

if(isset($_POST['btn_updt_date']))
{
    $currsale_sign=$_POST['txt_sale_signature'];

    update_daily_sales(['filter_date'=>"?"], " sale_signature='$currsale_sign' ");

}


if(isset($_POST['btn_updt_restock_date']))
{
    $currsale_sign=$_POST['txt_signature'];

    update_stock_history(['inventory_date'=>"?"], " signature='$currsale_sign' ");

}

if(isset($_GET['post_sale']))
{
  
     $curr_rec_no="ORPNT/".magic_random_str(7);
     $curr_signature=$_GET['sale_signature'];
     //------- begin daily_sales_arr --> 
      $daily_sales_arr_=array(

      "sale_id"=>$curr_rec_no,
      "item_id"=>"ORNPAYMENT",
      "item_code"=>"ORNPAYMENT",
      "quantity"=>"?",
      "selling_price"=>"?",
      "totals"=>"0",
      "item_name"=>"ORNPAYMENT",
      "item_description"=>"ORNPAYMENT",
      "sold_by"=>"?",
      "shop_location"=>"?",
      "receipt_no"=>$curr_rec_no,
      "invoice_no"=>"?",
      "payment_mode"=>$_GET['payment_mode'],
      "customer_id"=>"?",
      "sales_date"=>$_GET['filter_date'],
      "sale_signature"=>$_GET['sale_signature'],
      "sale_state"=>"Complete",
      "amount_paid"=>$_GET['amount_paid'],
      "payment_ref"=>$_GET['payment_ref'],
      "filter_date"=>$_GET['filter_date'],
      "customer_name"=>$_GET['customer_name'],
      "receipt_total"=>$_GET['receipt_total'],
      "receipt_balance"=>$_GET['receipt_balance'],
      "order_payment"=>$_GET['order_payment']

      );
      //===-- End daily_sales_arr -->
      
  	  if(count_daily_sales("sale_signature='$curr_signature'")==0)
      {        
      
        add_daily_sales($daily_sales_arr_);
        
      }else{
        drop_daily_sales("sale_signature='$curr_signature' and item_name='ORNPAYMENT'");
        add_daily_sales($daily_sales_arr_);
      }
      unset($_SESSION['sales_signature']);
  
      echo " Sale Posted Successfully ";
      
      
  	     
}

if(isset($_GET['set_new_sales_session']))
{
  
  if(!isset($_SESSION["sales_signature"]))
  {

    $_SESSION['sales_signature']=date("Ymdhisa");

  } 
  
  echo $_SESSION['sales_signature'];
  
}

if(isset($_GET['get_time']))
{
  echo date("h:i:s A");
}


?>