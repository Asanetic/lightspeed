<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


 $parent_path=[
'http://localhost/origin/pos/',
//{{next_root_str}}
];

$active_parent_dir=date('dmyhisa');
if(isset($_SESSION[$mosy_gw_appname.'active_parent_dir'])){
 $active_parent_dir=$_SESSION[$mosy_gw_appname.'active_parent_dir'];
 ///echo $active_parent_dir;
}
$access_arr=[

    ///start access clearance array for $active_parent_dir.'adminlist.php
    $active_parent_dir.'adminlist.php'=>
      [
      'users_tbl'=>['select','qusers_tbl_btn','get_qusers_tbl','qdata','{{next_adminlist.php_users_tbl}}'],
        //next_adminlist.php_access

      ],
      ///end access clearance array for $active_parent_dir.'adminlist.php

      
    ///start access clearance array for $active_parent_dir.'adminprof.php
    $active_parent_dir.'adminprof.php'=>
      [
      'users_tbl'=>['select','upload_users_tbl_user_pic','update','insert','super_delete_request','super_delete_confirm','drop_data','qdata','{{next_adminprof.php_users_tbl}}'],
        
      'mosy_sql_roll_back'=>['insert','{{next_adminprof.php_mosy_sql_roll_back}}'],
      //next_adminprof.php_access

      ],
      ///end access clearance array for $active_parent_dir.'adminprof.php

      
    ///start access clearance array for $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php
    $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php'=>
      [
      'users_tbl'=>['select','qdata','{{next_load_preview_iframe_23_01_21_438pm.php_users_tbl}}'],
        
      'suppliers'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_suppliers}}'],
      
      'customers'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_customers}}'],
      
      'stock_list'=>['select','count_data','{{next_load_preview_iframe_23_01_21_438pm.php_stock_list}}'],
      
      'stock_history'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_stock_history}}'],
      
      'daily_sales'=>['select','qddata','sum_data','{{next_load_preview_iframe_23_01_21_438pm.php_daily_sales}}'],
      
      'expenses_list'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_expenses_list}}'],
      //next_load_preview_iframe_23_01_21_438pm.php_access

      ],
      ///end access clearance array for $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php

      
    ///start access clearance array for $active_parent_dir.'index.php
    $active_parent_dir.'index.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_index.php_users_tbl}}'],
        
      'stock_list'=>['count_data','select','{{next_index.php_stock_list}}'],
      
      'daily_sales'=>['sum_data','select','{{next_index.php_daily_sales}}'],
      //next_index.php_access

      ],
      ///end access clearance array for $active_parent_dir.'index.php

      
    ///start access clearance array for $active_parent_dir.'suppliers.php
    $active_parent_dir.'suppliers.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_suppliers.php_users_tbl}}'],
        
      'suppliers'=>['select','qsuppliers_btn','get_qsuppliers','{{next_suppliers.php_suppliers}}'],
      //next_suppliers.php_access

      ],
      ///end access clearance array for $active_parent_dir.'suppliers.php

      
    ///start access clearance array for $active_parent_dir.'supplierprof.php
    $active_parent_dir.'supplierprof.php'=>
      [
      'suppliers'=>['select','update','insert','super_delete_request','super_delete_confirm','drop_data','{{next_supplierprof.php_suppliers}}'],
        
      'users_tbl'=>['qdata','select','{{next_supplierprof.php_users_tbl}}'],
      
      'mosy_sql_roll_back'=>['insert','{{next_supplierprof.php_mosy_sql_roll_back}}'],
      //next_supplierprof.php_access

      ],
      ///end access clearance array for $active_parent_dir.'supplierprof.php

      
    ///start access clearance array for $active_parent_dir.'customerslist.php
    $active_parent_dir.'customerslist.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_customerslist.php_users_tbl}}'],
        
      'customers'=>['select','qcustomers_btn','get_qcustomers','{{next_customerslist.php_customers}}'],
      //next_customerslist.php_access

      ],
      ///end access clearance array for $active_parent_dir.'customerslist.php

      
    ///start access clearance array for $active_parent_dir.'customerprof.php
    $active_parent_dir.'customerprof.php'=>
      [
      'customers'=>['select','update','upload_customers_user_pic','super_delete_request','super_delete_confirm','drop_data','insert','{{next_customerprof.php_customers}}'],
        
      'users_tbl'=>['qdata','select','{{next_customerprof.php_users_tbl}}'],
      
      'mosy_sql_roll_back'=>['insert','{{next_customerprof.php_mosy_sql_roll_back}}'],
      //next_customerprof.php_access

      ],
      ///end access clearance array for $active_parent_dir.'customerprof.php

      
    ///start access clearance array for $active_parent_dir.'stocklist.php
    $active_parent_dir.'stocklist.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_stocklist.php_users_tbl}}'],
        
      'stock_list'=>['select','qstock_list_btn','get_qstock_list','insert','update','{{next_stocklist.php_stock_list}}'],
      
      'mosy_sql_roll_back'=>['insert','{{next_stocklist.php_mosy_sql_roll_back}}'],
      //next_stocklist.php_access

      ],
      ///end access clearance array for $active_parent_dir.'stocklist.php

      
    ///start access clearance array for $active_parent_dir.'stockprofile.php
    $active_parent_dir.'stockprofile.php'=>
      [
      'stock_list'=>['select','{{next_stockprofile.php_stock_list}}'],
        
      'users_tbl'=>['qdata','select','{{next_stockprofile.php_users_tbl}}'],
      //next_stockprofile.php_access

      ],
      ///end access clearance array for $active_parent_dir.'stockprofile.php

      
    ///start access clearance array for $active_parent_dir.'ajaxreqhandler.php
    $active_parent_dir.'ajaxreqhandler.php'=>
      [
      'stock_list'=>['select','update','insert','{{next_ajaxreqhandler.php_stock_list}}'],
        
      'mosy_sql_roll_back'=>['insert','{{next_ajaxreqhandler.php_mosy_sql_roll_back}}'],
      
      'stock_history'=>['select','insert','update','super_delete_confirm','drop_data','count_data','{{next_ajaxreqhandler.php_stock_history}}'],
      
      'suppliers'=>['select','insert','{{next_ajaxreqhandler.php_suppliers}}'],
      
      'daily_sales'=>['select','insert','update','sum_data','super_delete_confirm','drop_data','{{next_ajaxreqhandler.php_daily_sales}}'],
      
      'customers'=>['select','insert','{{next_ajaxreqhandler.php_customers}}'],
      //next_ajaxreqhandler.php_access

      ],
      ///end access clearance array for $active_parent_dir.'ajaxreqhandler.php

      
    ///start access clearance array for $active_parent_dir.'restockitems.php
    $active_parent_dir.'restockitems.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_restockitems.php_users_tbl}}'],
        
      'stock_history'=>['select','qstock_history_btn','get_qstock_history','{{next_restockitems.php_stock_history}}'],
      
      'stock_list'=>['select','{{next_restockitems.php_stock_list}}'],
      
      'suppliers'=>['select','{{next_restockitems.php_suppliers}}'],
      //next_restockitems.php_access

      ],
      ///end access clearance array for $active_parent_dir.'restockitems.php

      
    ///start access clearance array for $active_parent_dir.'stockhistory.php
    $active_parent_dir.'stockhistory.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_stockhistory.php_users_tbl}}'],
        
      'stock_history'=>['select','qstock_history_btn','get_qstock_history','stock_history_mosyfilter','{{next_stockhistory.php_stock_history}}'],
      //next_stockhistory.php_access

      ],
      ///end access clearance array for $active_parent_dir.'stockhistory.php

      
    ///start access clearance array for $active_parent_dir.'pos.php
    $active_parent_dir.'pos.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_pos.php_users_tbl}}'],
        
      'stock_list'=>['select','{{next_pos.php_stock_list}}'],
      
      'suppliers'=>['select','{{next_pos.php_suppliers}}'],
      
      'daily_sales'=>['select','{{next_pos.php_daily_sales}}'],
      
      'customers'=>['select','{{next_pos.php_customers}}'],
      //next_pos.php_access

      ],
      ///end access clearance array for $active_parent_dir.'pos.php

      
    ///start access clearance array for $active_parent_dir.'salesrep.php
    $active_parent_dir.'salesrep.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_salesrep.php_users_tbl}}'],
        
      'daily_sales'=>['select','qdaily_sales_btn','get_qdaily_sales','daily_sales_mosyfilter','{{next_salesrep.php_daily_sales}}'],
      //next_salesrep.php_access

      ],
      ///end access clearance array for $active_parent_dir.'salesrep.php

      
    ///start access clearance array for $active_parent_dir.'calc.php
    $active_parent_dir.'calc.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_calc.php_users_tbl}}'],
        //next_calc.php_access

      ],
      ///end access clearance array for $active_parent_dir.'calc.php

      
    ///start access clearance array for $active_parent_dir.'listexpenses.php
    $active_parent_dir.'listexpenses.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_listexpenses.php_users_tbl}}'],
        
      'expenses_list'=>['select','insert','qexpenses_list_btn','get_qexpenses_list','expenses_list_mosyfilter','{{next_listexpenses.php_expenses_list}}'],
      
      'mosy_sql_roll_back'=>['insert','{{next_listexpenses.php_mosy_sql_roll_back}}'],
      //next_listexpenses.php_access

      ],
      ///end access clearance array for $active_parent_dir.'listexpenses.php

      
    ///start access clearance array for $active_parent_dir.'infinite.php
    $active_parent_dir.'infinite.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_infinite.php_users_tbl}}'],
        
      'stock_list'=>['select','{{next_infinite.php_stock_list}}'],
      //next_infinite.php_access

      ],
      ///end access clearance array for $active_parent_dir.'infinite.php

      
    ///start access clearance array for $active_parent_dir.'lockscrn.php
    $active_parent_dir.'lockscrn.php'=>
      [
      'users_tbl'=>['qdata','select','{{next_lockscrn.php_users_tbl}}'],
        //next_lockscrn.php_access

      ],
      ///end access clearance array for $active_parent_dir.'lockscrn.php

      
    ///start access clearance array for $active_parent_dir.'loginscrn.php
    $active_parent_dir.'loginscrn.php'=>
      [
      'users_tbl'=>['qdata','{{next_loginscrn.php_users_tbl}}'],
        //next_loginscrn.php_access

      ],
      ///end access clearance array for $active_parent_dir.'loginscrn.php

      //{{next_file_block}}




















];
?>