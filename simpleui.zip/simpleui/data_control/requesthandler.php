<?php 
//===============Start DATA HANDLER QUERIES ===================
				
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section config
  //************************************************* START  config OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize config edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['config_table_alert']))
              	{	
                  if(isset($config_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$config_uptoken="";

		if(isset($_GET["config_uptoken"]))
		{
		$config_uptoken=base64_decode($_GET["config_uptoken"]);
		}
        
        if(isset($_POST["config_uptoken"]))
		{
		$config_uptoken=base64_decode($_POST["config_uptoken"]);
		}
        //
        
          $config_alias_name="CONFIG";

          if(isset($config_alias))
          {
             $config_alias_name=$config_alias;

          }
          
        //get single data record query with $config_uptoken
        
        ///$config_node=get_config("*", "WHERE primkey='$config_uptoken'", "r");
        
	
//************* START INSERT  config QUERY 
if(isset($_POST["config_insert_btn"])){
//------- begin config_arr_ins --> 
$config_arr_ins_=array(

"primkey"=>"NULL",
"signature"=>magic_random_str(7),
"shop_name"=>"?",
"mobile"=>"?",
"email"=>"?",
"branch"=>"?",
"location"=>"?",
"logo"=>"?",
"license_key"=>"?",
"created_at"=>"?",
"updated_at"=>"?"

);
//===-- End config_arr_ins -->


          
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "insert","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {

              $config_validated_ins_str=$config_arr_ins_;

              if(isset($config_ins_inputs))
              {
                $config_validated_ins_str=$config_ins_inputs;	
              }

              if(empty($config_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$config_alias_name." request cannot be empty. Record not added");
              }else{

                $config_return_key=add_config($config_validated_ins_str);
                
                mosy_sql_rollback("config", "primkey='$config_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $config_return_key; 

                      } 

                    }else{ 

                                    
                $config_custom_redir1=add_url_param ("config_uptoken", base64_encode($config_return_key), "");
                $config_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$config_custom_redir1);
                $config_custom_redir3=add_url_param ("config_table_alert", "config_added",$config_custom_redir2);
                
                ///echo magic_message($config_custom_redir1." -- ".$config_custom_redir2."--".$config_custom_redir3);
                
                $config_custom_redir=$config_custom_redir3;
                
               header('location:'.$config_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_config_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");
         
         }
      
}
//************* END  config INSERT QUERY 	
	

//************* START config  UPDATE QUERY 
if(isset($_POST["config_update_btn"])){
//------- begin config_arr_updt --> 
$config_arr_updt_=array(
"shop_name"=>"?",
"mobile"=>"?",
"email"=>"?",
"branch"=>"?",
"location"=>"?",
"logo"=>"?",
"license_key"=>"?",
"created_at"=>"?",
"updated_at"=>"?"

);
//===-- End config_arr_updt -->
                     
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "update","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {
         
            $config_validated_updt_str=$config_arr_updt_;

            if(isset($config_updt_inputs))
            {
              $config_validated_updt_str=$config_updt_inputs;	
            }

            if(empty($config_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$config_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$config_key_salt=initialize_config()["signature"];
            
              update_config($config_validated_updt_str, "primkey='$config_uptoken' and signature='$config_key_salt'");
				

			 mosy_sql_rollback("config", "primkey='$config_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $config_uptoken; 

                    } 

                  }else{ 

                $config_custom_redir1=add_url_param ("config_uptoken", base64_encode($config_uptoken), "");
                $config_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$config_custom_redir1);
                $config_custom_redir3=add_url_param ("config_table_alert", "config_updated",$config_custom_redir2);
                
                ///echo magic_message($config_custom_redir1." -- ".$config_custom_redir2."--".$config_custom_redir3);
                
                $config_custom_redir=$config_custom_redir3;
                
               header('location:'.$config_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_config_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");
         
         }

      

      
}
//************* END config  UPDATE QUERY 

    
    
      //== Start config delete record

      if(isset($_GET["deleteconfig"]))
      {
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "super_delete_request","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_config_btn=magic_button_link("./".$current_file_url."?config_uptoken=".$_GET["config_uptoken"]."&conf_deleteconfig&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_config_btn=magic_button_link("./".$current_file_url."?config_uptoken=".$_GET["config_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_config_btn." ".$cancel_del_config_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_config_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteconfig"]))
      {
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "super_delete_confirm","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $config_del_key_salt=initialize_config()["signature"];
      mosy_sql_rollback("config", "primkey='$config_uptoken'", "DELETE");
      drop_config("primkey='$config_uptoken' and signature='$config_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_config_);

      }
      }

      //== End config delete record  
    
       ///SELECT STRING FOR config============================
              
       if(isset($_POST["qconfig_btn"])){
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "qconfig_btn","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {
            $current_config_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_config_current_url=$current_config_url_params.'?qconfig=';
            if (strpos($current_config_url_params, '?') !== false) {

                $clean_config_current_url=$current_config_url_params.'&qconfig=';

            }
            if (strpos($current_config_url_params, '?qconfig')) {

                $remove_config_old_token = substr($current_config_url_params, 0, strpos($current_config_url_params, "?qconfig"));

                $clean_config_current_url=$remove_config_old_token.'?qconfig=';

            }
            if(strpos($current_config_url_params, '&qconfig')) {

                $remove_config_old_token = substr($current_config_url_params, 0, strpos($current_config_url_params, "&qconfig"));

                $clean_config_current_url=$remove_config_old_token.'&qconfig=';

            }
        $qconfig_str=base64_encode($_POST["txt_config"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_config_current_url.($qconfig_str);
            } 

          }else{ 
             header('location:'.$clean_config_current_url.($qconfig_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_config_);

        }
        }
        $qconfig="";
		if(isset($_GET["config_mosyfilter"]) && isset($_GET["qconfig"])){
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "config_mosyfilter_n_query","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {
         $qconfig=mmres(base64_decode($_GET["qconfig"]));
         
         $gft_config_where_query="(`signature` LIKE '%".$qconfig."%' OR  `shop_name` LIKE '%".$qconfig."%' OR  `mobile` LIKE '%".$qconfig."%' OR  `email` LIKE '%".$qconfig."%' OR  `branch` LIKE '%".$qconfig."%' OR  `location` LIKE '%".$qconfig."%' OR  `logo` LIKE '%".$qconfig."%' OR  `license_key` LIKE '%".$qconfig."%' OR  `created_at` LIKE '%".$qconfig."%' OR  `updated_at` LIKE '%".$qconfig."%')";
         
         if($_GET["config_mosyfilter"]!=""){
         
         $mosyfilter_config_queries_str=(base64_decode($_GET["config_mosyfilter"]));
        
         $gft_config_where_query="(`signature` LIKE '%".$qconfig."%' OR  `shop_name` LIKE '%".$qconfig."%' OR  `mobile` LIKE '%".$qconfig."%' OR  `email` LIKE '%".$qconfig."%' OR  `branch` LIKE '%".$qconfig."%' OR  `location` LIKE '%".$qconfig."%' OR  `logo` LIKE '%".$qconfig."%' OR  `license_key` LIKE '%".$qconfig."%' OR  `created_at` LIKE '%".$qconfig."%' OR  `updated_at` LIKE '%".$qconfig."%') AND ".$mosyfilter_config_queries_str."";
         
         }
         
		 $gft_config="WHERE ".$gft_config_where_query;
         
         $gft_config_and=$gft_config_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_config_);
        }
        }elseif(isset($_GET["qconfig"])){
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "get_qconfig","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {
		 $qconfig=mmres(base64_decode($_GET["qconfig"]));
        
         $gft_config_where_query="(`signature` LIKE '%".$qconfig."%' OR  `shop_name` LIKE '%".$qconfig."%' OR  `mobile` LIKE '%".$qconfig."%' OR  `email` LIKE '%".$qconfig."%' OR  `branch` LIKE '%".$qconfig."%' OR  `location` LIKE '%".$qconfig."%' OR  `logo` LIKE '%".$qconfig."%' OR  `license_key` LIKE '%".$qconfig."%' OR  `created_at` LIKE '%".$qconfig."%' OR  `updated_at` LIKE '%".$qconfig."%')";
         
         $gft_config="WHERE ".$gft_config_where_query;
         
         $gft_config_and=$gft_config_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_config_);

        }
        }elseif(isset($_GET["config_mosyfilter"])){
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "config_mosyfilter","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {
         $gft_config_where_query="";
         $gft_config="";

         if($_GET["config_mosyfilter"]!=""){
          $gft_config_where_query=(base64_decode($_GET["config_mosyfilter"]));
          $gft_config="WHERE ".$gft_config_where_query;
         }
         
         
         $gft_config_and=$gft_config_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_config_);

        }
        }else{
         $gft_config="";
         $gft_config_and="";
         $gft_config_where_query="";
        }
       
    //************************************************* END  config OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section customers
  //************************************************* START  customers OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize customers edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['customers_table_alert']))
              	{	
                  if(isset($customers_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$customers_uptoken="";

		if(isset($_GET["customers_uptoken"]))
		{
		$customers_uptoken=base64_decode($_GET["customers_uptoken"]);
		}
        
        if(isset($_POST["customers_uptoken"]))
		{
		$customers_uptoken=base64_decode($_POST["customers_uptoken"]);
		}
        //
        
          $customers_alias_name="CUSTOMERS";

          if(isset($customers_alias))
          {
             $customers_alias_name=$customers_alias;

          }
          
        //get single data record query with $customers_uptoken
        
        ///$customers_node=get_customers("*", "WHERE primkey='$customers_uptoken'", "r");
        
	
//************* START INSERT  customers QUERY 
if(isset($_POST["customers_insert_btn"])){
//------- begin customers_arr_ins --> 
$customers_arr_ins_=array(

"primkey"=>"NULL",
"customer_id"=>magic_random_str(7),
"customer_name"=>"?",
"user_pic"=>"?",
"borrowing_score"=>"?",
"phone"=>"?",
"email"=>"?",
"gender"=>"?",
"dob"=>"?",
"id_no"=>"?",
"created_at"=>"?"

);
//===-- End customers_arr_ins -->


          
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "insert","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {

              $customers_validated_ins_str=$customers_arr_ins_;

              if(isset($customers_ins_inputs))
              {
                $customers_validated_ins_str=$customers_ins_inputs;	
              }

              if(empty($customers_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$customers_alias_name." request cannot be empty. Record not added");
              }else{

                $customers_return_key=add_customers($customers_validated_ins_str);
                
                mosy_sql_rollback("customers", "primkey='$customers_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_customers_user_pic']['tmp_name']))
                {
                
                 upload_customers_user_pic('txt_customers_user_pic', "primkey='$customers_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $customers_return_key; 

                      } 

                    }else{ 

                                    
                $customers_custom_redir1=add_url_param ("customers_uptoken", base64_encode($customers_return_key), "");
                $customers_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$customers_custom_redir1);
                $customers_custom_redir3=add_url_param ("customers_table_alert", "customers_added",$customers_custom_redir2);
                
                ///echo magic_message($customers_custom_redir1." -- ".$customers_custom_redir2."--".$customers_custom_redir3);
                
                $customers_custom_redir=$customers_custom_redir3;
                
               header('location:'.$customers_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_customers_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");
         
         }
      
}
//************* END  customers INSERT QUERY 	
	

//************* START customers  UPDATE QUERY 
if(isset($_POST["customers_update_btn"])){
//------- begin customers_arr_updt --> 
$customers_arr_updt_=array(
"customer_name"=>"?",
"user_pic"=>"?",
"borrowing_score"=>"?",
"phone"=>"?",
"email"=>"?",
"gender"=>"?",
"dob"=>"?",
"id_no"=>"?",
"created_at"=>"?"

);
//===-- End customers_arr_updt -->
                     
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "update","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
         
            $customers_validated_updt_str=$customers_arr_updt_;

            if(isset($customers_updt_inputs))
            {
              $customers_validated_updt_str=$customers_updt_inputs;	
            }

            if(empty($customers_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$customers_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$customers_key_salt=initialize_customers()["customer_id"];
            
              update_customers($customers_validated_updt_str, "primkey='$customers_uptoken' and customer_id='$customers_key_salt'");
				
         
                if(!empty($_FILES['txt_customers_user_pic']['tmp_name']))
                {
                
                 upload_customers_user_pic('txt_customers_user_pic', "primkey='$customers_uptoken'");
                 
				}

			 mosy_sql_rollback("customers", "primkey='$customers_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $customers_uptoken; 

                    } 

                  }else{ 

                $customers_custom_redir1=add_url_param ("customers_uptoken", base64_encode($customers_uptoken), "");
                $customers_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$customers_custom_redir1);
                $customers_custom_redir3=add_url_param ("customers_table_alert", "customers_updated",$customers_custom_redir2);
                
                ///echo magic_message($customers_custom_redir1." -- ".$customers_custom_redir2."--".$customers_custom_redir3);
                
                $customers_custom_redir=$customers_custom_redir3;
                
               header('location:'.$customers_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_customers_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");
         
         }

      

      
}
//************* END customers  UPDATE QUERY 

    

          //===-====Start upload customers_user_pic 
          if(isset($_POST["btn_upload_customers_user_pic"]))
          {
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "upload_customers_user_pic","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_customers_user_pic']['tmp_name'])){

				upload_customers_user_pic('txt_customers_user_pic', "primkey='$customers_uptoken'");
                
                $customers_custom_redir1=add_url_param ("customers_uptoken", base64_encode($customers_uptoken), "");
                $customers_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$customers_custom_redir1);
                $customers_custom_redir3=add_url_param ("customers_table_alert", "customers_uploaded",$customers_custom_redir2);
                
                ///echo magic_message($customers_custom_redir1." -- ".$customers_custom_redir2."--".$customers_custom_redir3);
                
                $customers_custom_redir=$customers_custom_redir3;
                
               header('location:'.$customers_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_customers_);

          }
          }
          //===-====End upload customers_user_pic  

			//drop customers_user_pic image 
            
          if(isset($_GET["conf_deletecustomers"]))
          {
          	$customers_node=initialize_customers();
          	if($customers_node["user_pic"]!="")
            {
          	 unlink($customers_node["user_pic"]);
            }
          }
          
          
    
      //== Start customers delete record

      if(isset($_GET["deletecustomers"]))
      {
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "super_delete_request","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_customers_btn=magic_button_link("./".$current_file_url."?customers_uptoken=".$_GET["customers_uptoken"]."&conf_deletecustomers&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_customers_btn=magic_button_link("./".$current_file_url."?customers_uptoken=".$_GET["customers_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_customers_btn." ".$cancel_del_customers_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_customers_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletecustomers"]))
      {
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "super_delete_confirm","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $customers_del_key_salt=initialize_customers()["customer_id"];
      mosy_sql_rollback("customers", "primkey='$customers_uptoken'", "DELETE");
      drop_customers("primkey='$customers_uptoken' and customer_id='$customers_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_customers_);

      }
      }

      //== End customers delete record  
    
       ///SELECT STRING FOR customers============================
              
       if(isset($_POST["qcustomers_btn"])){
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "qcustomers_btn","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
            $current_customers_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_customers_current_url=$current_customers_url_params.'?qcustomers=';
            if (strpos($current_customers_url_params, '?') !== false) {

                $clean_customers_current_url=$current_customers_url_params.'&qcustomers=';

            }
            if (strpos($current_customers_url_params, '?qcustomers')) {

                $remove_customers_old_token = substr($current_customers_url_params, 0, strpos($current_customers_url_params, "?qcustomers"));

                $clean_customers_current_url=$remove_customers_old_token.'?qcustomers=';

            }
            if(strpos($current_customers_url_params, '&qcustomers')) {

                $remove_customers_old_token = substr($current_customers_url_params, 0, strpos($current_customers_url_params, "&qcustomers"));

                $clean_customers_current_url=$remove_customers_old_token.'&qcustomers=';

            }
        $qcustomers_str=base64_encode($_POST["txt_customers"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_customers_current_url.($qcustomers_str);
            } 

          }else{ 
             header('location:'.$clean_customers_current_url.($qcustomers_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_customers_);

        }
        }
        $qcustomers="";
		if(isset($_GET["customers_mosyfilter"]) && isset($_GET["qcustomers"])){
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "customers_mosyfilter_n_query","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
         $qcustomers=mmres(base64_decode($_GET["qcustomers"]));
         
         $gft_customers_where_query="(`customer_id` LIKE '%".$qcustomers."%' OR  `customer_name` LIKE '%".$qcustomers."%' OR  `user_pic` LIKE '%".$qcustomers."%' OR  `borrowing_score` LIKE '%".$qcustomers."%' OR  `phone` LIKE '%".$qcustomers."%' OR  `email` LIKE '%".$qcustomers."%' OR  `gender` LIKE '%".$qcustomers."%' OR  `dob` LIKE '%".$qcustomers."%' OR  `id_no` LIKE '%".$qcustomers."%' OR  `created_at` LIKE '%".$qcustomers."%')";
         
         if($_GET["customers_mosyfilter"]!=""){
         
         $mosyfilter_customers_queries_str=(base64_decode($_GET["customers_mosyfilter"]));
        
         $gft_customers_where_query="(`customer_id` LIKE '%".$qcustomers."%' OR  `customer_name` LIKE '%".$qcustomers."%' OR  `user_pic` LIKE '%".$qcustomers."%' OR  `borrowing_score` LIKE '%".$qcustomers."%' OR  `phone` LIKE '%".$qcustomers."%' OR  `email` LIKE '%".$qcustomers."%' OR  `gender` LIKE '%".$qcustomers."%' OR  `dob` LIKE '%".$qcustomers."%' OR  `id_no` LIKE '%".$qcustomers."%' OR  `created_at` LIKE '%".$qcustomers."%') AND ".$mosyfilter_customers_queries_str."";
         
         }
         
		 $gft_customers="WHERE ".$gft_customers_where_query;
         
         $gft_customers_and=$gft_customers_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_customers_);
        }
        }elseif(isset($_GET["qcustomers"])){
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "get_qcustomers","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
		 $qcustomers=mmres(base64_decode($_GET["qcustomers"]));
        
         $gft_customers_where_query="(`customer_id` LIKE '%".$qcustomers."%' OR  `customer_name` LIKE '%".$qcustomers."%' OR  `user_pic` LIKE '%".$qcustomers."%' OR  `borrowing_score` LIKE '%".$qcustomers."%' OR  `phone` LIKE '%".$qcustomers."%' OR  `email` LIKE '%".$qcustomers."%' OR  `gender` LIKE '%".$qcustomers."%' OR  `dob` LIKE '%".$qcustomers."%' OR  `id_no` LIKE '%".$qcustomers."%' OR  `created_at` LIKE '%".$qcustomers."%')";
         
         $gft_customers="WHERE ".$gft_customers_where_query;
         
         $gft_customers_and=$gft_customers_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_customers_);

        }
        }elseif(isset($_GET["customers_mosyfilter"])){
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "customers_mosyfilter","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
         $gft_customers_where_query="";
         $gft_customers="";

         if($_GET["customers_mosyfilter"]!=""){
          $gft_customers_where_query=(base64_decode($_GET["customers_mosyfilter"]));
          $gft_customers="WHERE ".$gft_customers_where_query;
         }
         
         
         $gft_customers_and=$gft_customers_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_customers_);

        }
        }else{
         $gft_customers="";
         $gft_customers_and="";
         $gft_customers_where_query="";
        }
       
    //************************************************* END  customers OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section daily_sales
  //************************************************* START  daily_sales OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize daily_sales edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['daily_sales_table_alert']))
              	{	
                  if(isset($daily_sales_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$daily_sales_uptoken="";

		if(isset($_GET["daily_sales_uptoken"]))
		{
		$daily_sales_uptoken=base64_decode($_GET["daily_sales_uptoken"]);
		}
        
        if(isset($_POST["daily_sales_uptoken"]))
		{
		$daily_sales_uptoken=base64_decode($_POST["daily_sales_uptoken"]);
		}
        //
        
          $daily_sales_alias_name="DAILY SALES";

          if(isset($daily_sales_alias))
          {
             $daily_sales_alias_name=$daily_sales_alias;

          }
          
        //get single data record query with $daily_sales_uptoken
        
        ///$daily_sales_node=get_daily_sales("*", "WHERE primkey='$daily_sales_uptoken'", "r");
        
	
//************* START INSERT  daily_sales QUERY 
if(isset($_POST["daily_sales_insert_btn"])){
//------- begin daily_sales_arr_ins --> 
$daily_sales_arr_ins_=array(

"primkey"=>"NULL",
"sale_id"=>magic_random_str(7),
"item_id"=>"?",
"item_code"=>"?",
"quantity"=>"?",
"selling_price"=>"?",
"totals"=>"?",
"item_name"=>"?",
"item_description"=>"?",
"sold_by"=>"?",
"shop_location"=>"?",
"receipt_no"=>"?",
"invoice_no"=>"?",
"payment_mode"=>"?",
"customer_id"=>"?",
"sales_date"=>"?",
"sale_signature"=>"?",
"sale_state"=>"?",
"sale_type"=>"?",
"tax_type"=>"?",
"tax_value"=>"?",
"tax_amount"=>"?",
"tax_rate"=>"?",
"amount_paid"=>"?",
"payment_ref"=>"?",
"buying_price"=>"?",
"filter_date"=>"?",
"customer_name"=>"?",
"receipt_total"=>"?",
"receipt_balance"=>"?",
"order_payment"=>"?",
"margin_price"=>"?"

);
//===-- End daily_sales_arr_ins -->


          
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "insert","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {

              $daily_sales_validated_ins_str=$daily_sales_arr_ins_;

              if(isset($daily_sales_ins_inputs))
              {
                $daily_sales_validated_ins_str=$daily_sales_ins_inputs;	
              }

              if(empty($daily_sales_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$daily_sales_alias_name." request cannot be empty. Record not added");
              }else{

                $daily_sales_return_key=add_daily_sales($daily_sales_validated_ins_str);
                
                mosy_sql_rollback("daily_sales", "primkey='$daily_sales_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $daily_sales_return_key; 

                      } 

                    }else{ 

                                    
                $daily_sales_custom_redir1=add_url_param ("daily_sales_uptoken", base64_encode($daily_sales_return_key), "");
                $daily_sales_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$daily_sales_custom_redir1);
                $daily_sales_custom_redir3=add_url_param ("daily_sales_table_alert", "daily_sales_added",$daily_sales_custom_redir2);
                
                ///echo magic_message($daily_sales_custom_redir1." -- ".$daily_sales_custom_redir2."--".$daily_sales_custom_redir3);
                
                $daily_sales_custom_redir=$daily_sales_custom_redir3;
                
               header('location:'.$daily_sales_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_daily_sales_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");
         
         }
      
}
//************* END  daily_sales INSERT QUERY 	
	

//************* START daily_sales  UPDATE QUERY 
if(isset($_POST["daily_sales_update_btn"])){
//------- begin daily_sales_arr_updt --> 
$daily_sales_arr_updt_=array(
"item_id"=>"?",
"item_code"=>"?",
"quantity"=>"?",
"selling_price"=>"?",
"totals"=>"?",
"item_name"=>"?",
"item_description"=>"?",
"sold_by"=>"?",
"shop_location"=>"?",
"receipt_no"=>"?",
"invoice_no"=>"?",
"payment_mode"=>"?",
"customer_id"=>"?",
"sales_date"=>"?",
"sale_signature"=>"?",
"sale_state"=>"?",
"sale_type"=>"?",
"tax_type"=>"?",
"tax_value"=>"?",
"tax_amount"=>"?",
"tax_rate"=>"?",
"amount_paid"=>"?",
"payment_ref"=>"?",
"buying_price"=>"?",
"filter_date"=>"?",
"customer_name"=>"?",
"receipt_total"=>"?",
"receipt_balance"=>"?",
"order_payment"=>"?",
"margin_price"=>"?"

);
//===-- End daily_sales_arr_updt -->
                     
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "update","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {
         
            $daily_sales_validated_updt_str=$daily_sales_arr_updt_;

            if(isset($daily_sales_updt_inputs))
            {
              $daily_sales_validated_updt_str=$daily_sales_updt_inputs;	
            }

            if(empty($daily_sales_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$daily_sales_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$daily_sales_key_salt=initialize_daily_sales()["sale_id"];
            
              update_daily_sales($daily_sales_validated_updt_str, "primkey='$daily_sales_uptoken' and sale_id='$daily_sales_key_salt'");
				

			 mosy_sql_rollback("daily_sales", "primkey='$daily_sales_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $daily_sales_uptoken; 

                    } 

                  }else{ 

                $daily_sales_custom_redir1=add_url_param ("daily_sales_uptoken", base64_encode($daily_sales_uptoken), "");
                $daily_sales_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$daily_sales_custom_redir1);
                $daily_sales_custom_redir3=add_url_param ("daily_sales_table_alert", "daily_sales_updated",$daily_sales_custom_redir2);
                
                ///echo magic_message($daily_sales_custom_redir1." -- ".$daily_sales_custom_redir2."--".$daily_sales_custom_redir3);
                
                $daily_sales_custom_redir=$daily_sales_custom_redir3;
                
               header('location:'.$daily_sales_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_daily_sales_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");
         
         }

      

      
}
//************* END daily_sales  UPDATE QUERY 

    
    
      //== Start daily_sales delete record

      if(isset($_GET["deletedaily_sales"]))
      {
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "super_delete_request","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_daily_sales_btn=magic_button_link("./".$current_file_url."?daily_sales_uptoken=".$_GET["daily_sales_uptoken"]."&conf_deletedaily_sales&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_daily_sales_btn=magic_button_link("./".$current_file_url."?daily_sales_uptoken=".$_GET["daily_sales_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_daily_sales_btn." ".$cancel_del_daily_sales_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_daily_sales_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletedaily_sales"]))
      {
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "super_delete_confirm","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $daily_sales_del_key_salt=initialize_daily_sales()["sale_id"];
      mosy_sql_rollback("daily_sales", "primkey='$daily_sales_uptoken'", "DELETE");
      drop_daily_sales("primkey='$daily_sales_uptoken' and sale_id='$daily_sales_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_daily_sales_);

      }
      }

      //== End daily_sales delete record  
    
       ///SELECT STRING FOR daily_sales============================
              
       if(isset($_POST["qdaily_sales_btn"])){
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "qdaily_sales_btn","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {
            $current_daily_sales_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_daily_sales_current_url=$current_daily_sales_url_params.'?qdaily_sales=';
            if (strpos($current_daily_sales_url_params, '?') !== false) {

                $clean_daily_sales_current_url=$current_daily_sales_url_params.'&qdaily_sales=';

            }
            if (strpos($current_daily_sales_url_params, '?qdaily_sales')) {

                $remove_daily_sales_old_token = substr($current_daily_sales_url_params, 0, strpos($current_daily_sales_url_params, "?qdaily_sales"));

                $clean_daily_sales_current_url=$remove_daily_sales_old_token.'?qdaily_sales=';

            }
            if(strpos($current_daily_sales_url_params, '&qdaily_sales')) {

                $remove_daily_sales_old_token = substr($current_daily_sales_url_params, 0, strpos($current_daily_sales_url_params, "&qdaily_sales"));

                $clean_daily_sales_current_url=$remove_daily_sales_old_token.'&qdaily_sales=';

            }
        $qdaily_sales_str=base64_encode($_POST["txt_daily_sales"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_daily_sales_current_url.($qdaily_sales_str);
            } 

          }else{ 
             header('location:'.$clean_daily_sales_current_url.($qdaily_sales_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_daily_sales_);

        }
        }
        $qdaily_sales="";
		if(isset($_GET["daily_sales_mosyfilter"]) && isset($_GET["qdaily_sales"])){
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "daily_sales_mosyfilter_n_query","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {
         $qdaily_sales=mmres(base64_decode($_GET["qdaily_sales"]));
         
         $gft_daily_sales_where_query="(`sale_id` LIKE '%".$qdaily_sales."%' OR  `item_id` LIKE '%".$qdaily_sales."%' OR  `item_code` LIKE '%".$qdaily_sales."%' OR  `quantity` LIKE '%".$qdaily_sales."%' OR  `selling_price` LIKE '%".$qdaily_sales."%' OR  `totals` LIKE '%".$qdaily_sales."%' OR  `item_name` LIKE '%".$qdaily_sales."%' OR  `item_description` LIKE '%".$qdaily_sales."%' OR  `sold_by` LIKE '%".$qdaily_sales."%' OR  `shop_location` LIKE '%".$qdaily_sales."%' OR  `receipt_no` LIKE '%".$qdaily_sales."%' OR  `invoice_no` LIKE '%".$qdaily_sales."%' OR  `payment_mode` LIKE '%".$qdaily_sales."%' OR  `customer_id` LIKE '%".$qdaily_sales."%' OR  `sales_date` LIKE '%".$qdaily_sales."%' OR  `sale_signature` LIKE '%".$qdaily_sales."%' OR  `sale_state` LIKE '%".$qdaily_sales."%' OR  `sale_type` LIKE '%".$qdaily_sales."%' OR  `tax_type` LIKE '%".$qdaily_sales."%' OR  `tax_value` LIKE '%".$qdaily_sales."%' OR  `tax_amount` LIKE '%".$qdaily_sales."%' OR  `tax_rate` LIKE '%".$qdaily_sales."%' OR  `amount_paid` LIKE '%".$qdaily_sales."%' OR  `payment_ref` LIKE '%".$qdaily_sales."%' OR  `buying_price` LIKE '%".$qdaily_sales."%' OR  `filter_date` LIKE '%".$qdaily_sales."%' OR  `customer_name` LIKE '%".$qdaily_sales."%' OR  `receipt_total` LIKE '%".$qdaily_sales."%' OR  `receipt_balance` LIKE '%".$qdaily_sales."%' OR  `order_payment` LIKE '%".$qdaily_sales."%' OR  `margin_price` LIKE '%".$qdaily_sales."%')";
         
         if($_GET["daily_sales_mosyfilter"]!=""){
         
         $mosyfilter_daily_sales_queries_str=(base64_decode($_GET["daily_sales_mosyfilter"]));
        
         $gft_daily_sales_where_query="(`sale_id` LIKE '%".$qdaily_sales."%' OR  `item_id` LIKE '%".$qdaily_sales."%' OR  `item_code` LIKE '%".$qdaily_sales."%' OR  `quantity` LIKE '%".$qdaily_sales."%' OR  `selling_price` LIKE '%".$qdaily_sales."%' OR  `totals` LIKE '%".$qdaily_sales."%' OR  `item_name` LIKE '%".$qdaily_sales."%' OR  `item_description` LIKE '%".$qdaily_sales."%' OR  `sold_by` LIKE '%".$qdaily_sales."%' OR  `shop_location` LIKE '%".$qdaily_sales."%' OR  `receipt_no` LIKE '%".$qdaily_sales."%' OR  `invoice_no` LIKE '%".$qdaily_sales."%' OR  `payment_mode` LIKE '%".$qdaily_sales."%' OR  `customer_id` LIKE '%".$qdaily_sales."%' OR  `sales_date` LIKE '%".$qdaily_sales."%' OR  `sale_signature` LIKE '%".$qdaily_sales."%' OR  `sale_state` LIKE '%".$qdaily_sales."%' OR  `sale_type` LIKE '%".$qdaily_sales."%' OR  `tax_type` LIKE '%".$qdaily_sales."%' OR  `tax_value` LIKE '%".$qdaily_sales."%' OR  `tax_amount` LIKE '%".$qdaily_sales."%' OR  `tax_rate` LIKE '%".$qdaily_sales."%' OR  `amount_paid` LIKE '%".$qdaily_sales."%' OR  `payment_ref` LIKE '%".$qdaily_sales."%' OR  `buying_price` LIKE '%".$qdaily_sales."%' OR  `filter_date` LIKE '%".$qdaily_sales."%' OR  `customer_name` LIKE '%".$qdaily_sales."%' OR  `receipt_total` LIKE '%".$qdaily_sales."%' OR  `receipt_balance` LIKE '%".$qdaily_sales."%' OR  `order_payment` LIKE '%".$qdaily_sales."%' OR  `margin_price` LIKE '%".$qdaily_sales."%') AND ".$mosyfilter_daily_sales_queries_str."";
         
         }
         
		 $gft_daily_sales="WHERE ".$gft_daily_sales_where_query;
         
         $gft_daily_sales_and=$gft_daily_sales_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_daily_sales_);
        }
        }elseif(isset($_GET["qdaily_sales"])){
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "get_qdaily_sales","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {
		 $qdaily_sales=mmres(base64_decode($_GET["qdaily_sales"]));
        
         $gft_daily_sales_where_query="(`sale_id` LIKE '%".$qdaily_sales."%' OR  `item_id` LIKE '%".$qdaily_sales."%' OR  `item_code` LIKE '%".$qdaily_sales."%' OR  `quantity` LIKE '%".$qdaily_sales."%' OR  `selling_price` LIKE '%".$qdaily_sales."%' OR  `totals` LIKE '%".$qdaily_sales."%' OR  `item_name` LIKE '%".$qdaily_sales."%' OR  `item_description` LIKE '%".$qdaily_sales."%' OR  `sold_by` LIKE '%".$qdaily_sales."%' OR  `shop_location` LIKE '%".$qdaily_sales."%' OR  `receipt_no` LIKE '%".$qdaily_sales."%' OR  `invoice_no` LIKE '%".$qdaily_sales."%' OR  `payment_mode` LIKE '%".$qdaily_sales."%' OR  `customer_id` LIKE '%".$qdaily_sales."%' OR  `sales_date` LIKE '%".$qdaily_sales."%' OR  `sale_signature` LIKE '%".$qdaily_sales."%' OR  `sale_state` LIKE '%".$qdaily_sales."%' OR  `sale_type` LIKE '%".$qdaily_sales."%' OR  `tax_type` LIKE '%".$qdaily_sales."%' OR  `tax_value` LIKE '%".$qdaily_sales."%' OR  `tax_amount` LIKE '%".$qdaily_sales."%' OR  `tax_rate` LIKE '%".$qdaily_sales."%' OR  `amount_paid` LIKE '%".$qdaily_sales."%' OR  `payment_ref` LIKE '%".$qdaily_sales."%' OR  `buying_price` LIKE '%".$qdaily_sales."%' OR  `filter_date` LIKE '%".$qdaily_sales."%' OR  `customer_name` LIKE '%".$qdaily_sales."%' OR  `receipt_total` LIKE '%".$qdaily_sales."%' OR  `receipt_balance` LIKE '%".$qdaily_sales."%' OR  `order_payment` LIKE '%".$qdaily_sales."%' OR  `margin_price` LIKE '%".$qdaily_sales."%')";
         
         $gft_daily_sales="WHERE ".$gft_daily_sales_where_query;
         
         $gft_daily_sales_and=$gft_daily_sales_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_daily_sales_);

        }
        }elseif(isset($_GET["daily_sales_mosyfilter"])){
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "daily_sales_mosyfilter","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {
         $gft_daily_sales_where_query="";
         $gft_daily_sales="";

         if($_GET["daily_sales_mosyfilter"]!=""){
          $gft_daily_sales_where_query=(base64_decode($_GET["daily_sales_mosyfilter"]));
          $gft_daily_sales="WHERE ".$gft_daily_sales_where_query;
         }
         
         
         $gft_daily_sales_and=$gft_daily_sales_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_daily_sales_);

        }
        }else{
         $gft_daily_sales="";
         $gft_daily_sales_and="";
         $gft_daily_sales_where_query="";
        }
       
    //************************************************* END  daily_sales OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section expenses_list
  //************************************************* START  expenses_list OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize expenses_list edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['expenses_list_table_alert']))
              	{	
                  if(isset($expenses_list_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$expenses_list_uptoken="";

		if(isset($_GET["expenses_list_uptoken"]))
		{
		$expenses_list_uptoken=base64_decode($_GET["expenses_list_uptoken"]);
		}
        
        if(isset($_POST["expenses_list_uptoken"]))
		{
		$expenses_list_uptoken=base64_decode($_POST["expenses_list_uptoken"]);
		}
        //
        
          $expenses_list_alias_name="EXPENSES LIST";

          if(isset($expenses_list_alias))
          {
             $expenses_list_alias_name=$expenses_list_alias;

          }
          
        //get single data record query with $expenses_list_uptoken
        
        ///$expenses_list_node=get_expenses_list("*", "WHERE primkey='$expenses_list_uptoken'", "r");
        
	
//************* START INSERT  expenses_list QUERY 
if(isset($_POST["expenses_list_insert_btn"])){
//------- begin expenses_list_arr_ins --> 
$expenses_list_arr_ins_=array(

"primkey"=>"NULL",
"expense_key"=>magic_random_str(7),
"expense_title"=>"?",
"expense_amount"=>"?",
"expense_date"=>"?",
"expense_remark"=>"?"

);
//===-- End expenses_list_arr_ins -->


          
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "insert","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {

              $expenses_list_validated_ins_str=$expenses_list_arr_ins_;

              if(isset($expenses_list_ins_inputs))
              {
                $expenses_list_validated_ins_str=$expenses_list_ins_inputs;	
              }

              if(empty($expenses_list_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$expenses_list_alias_name." request cannot be empty. Record not added");
              }else{

                $expenses_list_return_key=add_expenses_list($expenses_list_validated_ins_str);
                
                mosy_sql_rollback("expenses_list", "primkey='$expenses_list_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $expenses_list_return_key; 

                      } 

                    }else{ 

                                    
                $expenses_list_custom_redir1=add_url_param ("expenses_list_uptoken", base64_encode($expenses_list_return_key), "");
                $expenses_list_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$expenses_list_custom_redir1);
                $expenses_list_custom_redir3=add_url_param ("expenses_list_table_alert", "expenses_list_added",$expenses_list_custom_redir2);
                
                ///echo magic_message($expenses_list_custom_redir1." -- ".$expenses_list_custom_redir2."--".$expenses_list_custom_redir3);
                
                $expenses_list_custom_redir=$expenses_list_custom_redir3;
                
               header('location:'.$expenses_list_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_expenses_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");
         
         }
      
}
//************* END  expenses_list INSERT QUERY 	
	

//************* START expenses_list  UPDATE QUERY 
if(isset($_POST["expenses_list_update_btn"])){
//------- begin expenses_list_arr_updt --> 
$expenses_list_arr_updt_=array(
"expense_title"=>"?",
"expense_amount"=>"?",
"expense_date"=>"?",
"expense_remark"=>"?"

);
//===-- End expenses_list_arr_updt -->
                     
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "update","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {
         
            $expenses_list_validated_updt_str=$expenses_list_arr_updt_;

            if(isset($expenses_list_updt_inputs))
            {
              $expenses_list_validated_updt_str=$expenses_list_updt_inputs;	
            }

            if(empty($expenses_list_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$expenses_list_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$expenses_list_key_salt=initialize_expenses_list()["expense_key"];
            
              update_expenses_list($expenses_list_validated_updt_str, "primkey='$expenses_list_uptoken' and expense_key='$expenses_list_key_salt'");
				

			 mosy_sql_rollback("expenses_list", "primkey='$expenses_list_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $expenses_list_uptoken; 

                    } 

                  }else{ 

                $expenses_list_custom_redir1=add_url_param ("expenses_list_uptoken", base64_encode($expenses_list_uptoken), "");
                $expenses_list_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$expenses_list_custom_redir1);
                $expenses_list_custom_redir3=add_url_param ("expenses_list_table_alert", "expenses_list_updated",$expenses_list_custom_redir2);
                
                ///echo magic_message($expenses_list_custom_redir1." -- ".$expenses_list_custom_redir2."--".$expenses_list_custom_redir3);
                
                $expenses_list_custom_redir=$expenses_list_custom_redir3;
                
               header('location:'.$expenses_list_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_expenses_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");
         
         }

      

      
}
//************* END expenses_list  UPDATE QUERY 

    
    
      //== Start expenses_list delete record

      if(isset($_GET["deleteexpenses_list"]))
      {
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "super_delete_request","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_expenses_list_btn=magic_button_link("./".$current_file_url."?expenses_list_uptoken=".$_GET["expenses_list_uptoken"]."&conf_deleteexpenses_list&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_expenses_list_btn=magic_button_link("./".$current_file_url."?expenses_list_uptoken=".$_GET["expenses_list_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_expenses_list_btn." ".$cancel_del_expenses_list_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_expenses_list_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteexpenses_list"]))
      {
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "super_delete_confirm","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $expenses_list_del_key_salt=initialize_expenses_list()["expense_key"];
      mosy_sql_rollback("expenses_list", "primkey='$expenses_list_uptoken'", "DELETE");
      drop_expenses_list("primkey='$expenses_list_uptoken' and expense_key='$expenses_list_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_expenses_list_);

      }
      }

      //== End expenses_list delete record  
    
       ///SELECT STRING FOR expenses_list============================
              
       if(isset($_POST["qexpenses_list_btn"])){
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "qexpenses_list_btn","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {
            $current_expenses_list_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_expenses_list_current_url=$current_expenses_list_url_params.'?qexpenses_list=';
            if (strpos($current_expenses_list_url_params, '?') !== false) {

                $clean_expenses_list_current_url=$current_expenses_list_url_params.'&qexpenses_list=';

            }
            if (strpos($current_expenses_list_url_params, '?qexpenses_list')) {

                $remove_expenses_list_old_token = substr($current_expenses_list_url_params, 0, strpos($current_expenses_list_url_params, "?qexpenses_list"));

                $clean_expenses_list_current_url=$remove_expenses_list_old_token.'?qexpenses_list=';

            }
            if(strpos($current_expenses_list_url_params, '&qexpenses_list')) {

                $remove_expenses_list_old_token = substr($current_expenses_list_url_params, 0, strpos($current_expenses_list_url_params, "&qexpenses_list"));

                $clean_expenses_list_current_url=$remove_expenses_list_old_token.'&qexpenses_list=';

            }
        $qexpenses_list_str=base64_encode($_POST["txt_expenses_list"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_expenses_list_current_url.($qexpenses_list_str);
            } 

          }else{ 
             header('location:'.$clean_expenses_list_current_url.($qexpenses_list_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_expenses_list_);

        }
        }
        $qexpenses_list="";
		if(isset($_GET["expenses_list_mosyfilter"]) && isset($_GET["qexpenses_list"])){
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "expenses_list_mosyfilter_n_query","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {
         $qexpenses_list=mmres(base64_decode($_GET["qexpenses_list"]));
         
         $gft_expenses_list_where_query="(`expense_key` LIKE '%".$qexpenses_list."%' OR  `expense_title` LIKE '%".$qexpenses_list."%' OR  `expense_amount` LIKE '%".$qexpenses_list."%' OR  `expense_date` LIKE '%".$qexpenses_list."%' OR  `expense_remark` LIKE '%".$qexpenses_list."%')";
         
         if($_GET["expenses_list_mosyfilter"]!=""){
         
         $mosyfilter_expenses_list_queries_str=(base64_decode($_GET["expenses_list_mosyfilter"]));
        
         $gft_expenses_list_where_query="(`expense_key` LIKE '%".$qexpenses_list."%' OR  `expense_title` LIKE '%".$qexpenses_list."%' OR  `expense_amount` LIKE '%".$qexpenses_list."%' OR  `expense_date` LIKE '%".$qexpenses_list."%' OR  `expense_remark` LIKE '%".$qexpenses_list."%') AND ".$mosyfilter_expenses_list_queries_str."";
         
         }
         
		 $gft_expenses_list="WHERE ".$gft_expenses_list_where_query;
         
         $gft_expenses_list_and=$gft_expenses_list_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_expenses_list_);
        }
        }elseif(isset($_GET["qexpenses_list"])){
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "get_qexpenses_list","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {
		 $qexpenses_list=mmres(base64_decode($_GET["qexpenses_list"]));
        
         $gft_expenses_list_where_query="(`expense_key` LIKE '%".$qexpenses_list."%' OR  `expense_title` LIKE '%".$qexpenses_list."%' OR  `expense_amount` LIKE '%".$qexpenses_list."%' OR  `expense_date` LIKE '%".$qexpenses_list."%' OR  `expense_remark` LIKE '%".$qexpenses_list."%')";
         
         $gft_expenses_list="WHERE ".$gft_expenses_list_where_query;
         
         $gft_expenses_list_and=$gft_expenses_list_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_expenses_list_);

        }
        }elseif(isset($_GET["expenses_list_mosyfilter"])){
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "expenses_list_mosyfilter","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {
         $gft_expenses_list_where_query="";
         $gft_expenses_list="";

         if($_GET["expenses_list_mosyfilter"]!=""){
          $gft_expenses_list_where_query=(base64_decode($_GET["expenses_list_mosyfilter"]));
          $gft_expenses_list="WHERE ".$gft_expenses_list_where_query;
         }
         
         
         $gft_expenses_list_and=$gft_expenses_list_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_expenses_list_);

        }
        }else{
         $gft_expenses_list="";
         $gft_expenses_list_and="";
         $gft_expenses_list_where_query="";
        }
       
    //************************************************* END  expenses_list OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section mosy_sql_roll_back
  //************************************************* START  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize mosy_sql_roll_back edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['mosy_sql_roll_back_table_alert']))
              	{	
                  if(isset($mosy_sql_roll_back_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$mosy_sql_roll_back_uptoken="";

		if(isset($_GET["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_GET["mosy_sql_roll_back_uptoken"]);
		}
        
        if(isset($_POST["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_POST["mosy_sql_roll_back_uptoken"]);
		}
        //
        
          $mosy_sql_roll_back_alias_name="MOSY SQL ROLL BACK";

          if(isset($mosy_sql_roll_back_alias))
          {
             $mosy_sql_roll_back_alias_name=$mosy_sql_roll_back_alias;

          }
          
        //get single data record query with $mosy_sql_roll_back_uptoken
        
        ///$mosy_sql_roll_back_node=get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
        
	
//************* START INSERT  mosy_sql_roll_back QUERY 
if(isset($_POST["mosy_sql_roll_back_insert_btn"])){
//------- begin mosy_sql_roll_back_arr_ins --> 
$mosy_sql_roll_back_arr_ins_=array(

"primkey"=>"NULL",
"roll_bk_key"=>magic_random_str(7),
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_ins -->


          
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {

              $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_arr_ins_;

              if(isset($mosy_sql_roll_back_ins_inputs))
              {
                $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_ins_inputs;	
              }

              if(empty($mosy_sql_roll_back_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name." request cannot be empty. Record not added");
              }else{

                $mosy_sql_roll_back_return_key=add_mosy_sql_roll_back($mosy_sql_roll_back_validated_ins_str);
                
                mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
      
}
//************* END  mosy_sql_roll_back INSERT QUERY 	
	

//************* START mosy_sql_roll_back  UPDATE QUERY 
if(isset($_POST["mosy_sql_roll_back_update_btn"])){
//------- begin mosy_sql_roll_back_arr_updt --> 
$mosy_sql_roll_back_arr_updt_=array(
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_updt -->
                     
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
            $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_arr_updt_;

            if(isset($mosy_sql_roll_back_updt_inputs))
            {
              $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_updt_inputs;	
            }

            if(empty($mosy_sql_roll_back_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$mosy_sql_roll_back_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
            
              update_mosy_sql_roll_back($mosy_sql_roll_back_validated_updt_str, "primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_key_salt'");
				

			 mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $mosy_sql_roll_back_uptoken; 

                    } 

                  }else{ 

                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_uptoken), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_updated",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }

      

      
}
//************* END mosy_sql_roll_back  UPDATE QUERY 

    
    
      //== Start mosy_sql_roll_back delete record

      if(isset($_GET["deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_request","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"]."&conf_deletemosy_sql_roll_back&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_mosy_sql_roll_back_btn." ".$cancel_del_mosy_sql_roll_back_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_confirm","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $mosy_sql_roll_back_del_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
      mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "DELETE");
      drop_mosy_sql_roll_back("primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

      }
      }

      //== End mosy_sql_roll_back delete record  
    
       ///SELECT STRING FOR mosy_sql_roll_back============================
              
       if(isset($_POST["qmosy_sql_roll_back_btn"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qmosy_sql_roll_back_btn","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
            $current_mosy_sql_roll_back_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'?qmosy_sql_roll_back=';
            if (strpos($current_mosy_sql_roll_back_url_params, '?') !== false) {

                $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'&qmosy_sql_roll_back=';

            }
            if (strpos($current_mosy_sql_roll_back_url_params, '?qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "?qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'?qmosy_sql_roll_back=';

            }
            if(strpos($current_mosy_sql_roll_back_url_params, '&qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "&qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'&qmosy_sql_roll_back=';

            }
        $qmosy_sql_roll_back_str=base64_encode($_POST["txt_mosy_sql_roll_back"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str);
            } 

          }else{ 
             header('location:'.$clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }
        $qmosy_sql_roll_back="";
		if(isset($_GET["mosy_sql_roll_back_mosyfilter"]) && isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter_n_query","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
         
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
         
         $mosyfilter_mosy_sql_roll_back_queries_str=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%') AND ".$mosyfilter_mosy_sql_roll_back_queries_str."";
         
         }
         
		 $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
        }
        }elseif(isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "get_qmosy_sql_roll_back","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
		 $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }elseif(isset($_GET["mosy_sql_roll_back_mosyfilter"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $gft_mosy_sql_roll_back_where_query="";
         $gft_mosy_sql_roll_back="";

         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
          $gft_mosy_sql_roll_back_where_query=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
          $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         }
         
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }else{
         $gft_mosy_sql_roll_back="";
         $gft_mosy_sql_roll_back_and="";
         $gft_mosy_sql_roll_back_where_query="";
        }
       
    //************************************************* END  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section receipt_nos
  //************************************************* START  receipt_nos OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize receipt_nos edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['receipt_nos_table_alert']))
              	{	
                  if(isset($receipt_nos_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$receipt_nos_uptoken="";

		if(isset($_GET["receipt_nos_uptoken"]))
		{
		$receipt_nos_uptoken=base64_decode($_GET["receipt_nos_uptoken"]);
		}
        
        if(isset($_POST["receipt_nos_uptoken"]))
		{
		$receipt_nos_uptoken=base64_decode($_POST["receipt_nos_uptoken"]);
		}
        //
        
          $receipt_nos_alias_name="RECEIPT NOS";

          if(isset($receipt_nos_alias))
          {
             $receipt_nos_alias_name=$receipt_nos_alias;

          }
          
        //get single data record query with $receipt_nos_uptoken
        
        ///$receipt_nos_node=get_receipt_nos("*", "WHERE primkey='$receipt_nos_uptoken'", "r");
        
	
//************* START INSERT  receipt_nos QUERY 
if(isset($_POST["receipt_nos_insert_btn"])){
//------- begin receipt_nos_arr_ins --> 
$receipt_nos_arr_ins_=array(

"primkey"=>"NULL",
"sales_date"=>magic_random_str(7),
"amount"=>"?",
"sold_by"=>"?",
"customer_id"=>"?"

);
//===-- End receipt_nos_arr_ins -->


          
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "insert","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {

              $receipt_nos_validated_ins_str=$receipt_nos_arr_ins_;

              if(isset($receipt_nos_ins_inputs))
              {
                $receipt_nos_validated_ins_str=$receipt_nos_ins_inputs;	
              }

              if(empty($receipt_nos_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$receipt_nos_alias_name." request cannot be empty. Record not added");
              }else{

                $receipt_nos_return_key=add_receipt_nos($receipt_nos_validated_ins_str);
                
                mosy_sql_rollback("receipt_nos", "primkey='$receipt_nos_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $receipt_nos_return_key; 

                      } 

                    }else{ 

                                    
                $receipt_nos_custom_redir1=add_url_param ("receipt_nos_uptoken", base64_encode($receipt_nos_return_key), "");
                $receipt_nos_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$receipt_nos_custom_redir1);
                $receipt_nos_custom_redir3=add_url_param ("receipt_nos_table_alert", "receipt_nos_added",$receipt_nos_custom_redir2);
                
                ///echo magic_message($receipt_nos_custom_redir1." -- ".$receipt_nos_custom_redir2."--".$receipt_nos_custom_redir3);
                
                $receipt_nos_custom_redir=$receipt_nos_custom_redir3;
                
               header('location:'.$receipt_nos_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_receipt_nos_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");
         
         }
      
}
//************* END  receipt_nos INSERT QUERY 	
	

//************* START receipt_nos  UPDATE QUERY 
if(isset($_POST["receipt_nos_update_btn"])){
//------- begin receipt_nos_arr_updt --> 
$receipt_nos_arr_updt_=array(
"amount"=>"?",
"sold_by"=>"?",
"customer_id"=>"?"

);
//===-- End receipt_nos_arr_updt -->
                     
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "update","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {
         
            $receipt_nos_validated_updt_str=$receipt_nos_arr_updt_;

            if(isset($receipt_nos_updt_inputs))
            {
              $receipt_nos_validated_updt_str=$receipt_nos_updt_inputs;	
            }

            if(empty($receipt_nos_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$receipt_nos_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$receipt_nos_key_salt=initialize_receipt_nos()["sales_date"];
            
              update_receipt_nos($receipt_nos_validated_updt_str, "primkey='$receipt_nos_uptoken' and sales_date='$receipt_nos_key_salt'");
				

			 mosy_sql_rollback("receipt_nos", "primkey='$receipt_nos_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $receipt_nos_uptoken; 

                    } 

                  }else{ 

                $receipt_nos_custom_redir1=add_url_param ("receipt_nos_uptoken", base64_encode($receipt_nos_uptoken), "");
                $receipt_nos_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$receipt_nos_custom_redir1);
                $receipt_nos_custom_redir3=add_url_param ("receipt_nos_table_alert", "receipt_nos_updated",$receipt_nos_custom_redir2);
                
                ///echo magic_message($receipt_nos_custom_redir1." -- ".$receipt_nos_custom_redir2."--".$receipt_nos_custom_redir3);
                
                $receipt_nos_custom_redir=$receipt_nos_custom_redir3;
                
               header('location:'.$receipt_nos_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_receipt_nos_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");
         
         }

      

      
}
//************* END receipt_nos  UPDATE QUERY 

    
    
      //== Start receipt_nos delete record

      if(isset($_GET["deletereceipt_nos"]))
      {
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "super_delete_request","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_receipt_nos_btn=magic_button_link("./".$current_file_url."?receipt_nos_uptoken=".$_GET["receipt_nos_uptoken"]."&conf_deletereceipt_nos&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_receipt_nos_btn=magic_button_link("./".$current_file_url."?receipt_nos_uptoken=".$_GET["receipt_nos_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_receipt_nos_btn." ".$cancel_del_receipt_nos_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_receipt_nos_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletereceipt_nos"]))
      {
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "super_delete_confirm","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $receipt_nos_del_key_salt=initialize_receipt_nos()["sales_date"];
      mosy_sql_rollback("receipt_nos", "primkey='$receipt_nos_uptoken'", "DELETE");
      drop_receipt_nos("primkey='$receipt_nos_uptoken' and sales_date='$receipt_nos_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_receipt_nos_);

      }
      }

      //== End receipt_nos delete record  
    
       ///SELECT STRING FOR receipt_nos============================
              
       if(isset($_POST["qreceipt_nos_btn"])){
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "qreceipt_nos_btn","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {
            $current_receipt_nos_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_receipt_nos_current_url=$current_receipt_nos_url_params.'?qreceipt_nos=';
            if (strpos($current_receipt_nos_url_params, '?') !== false) {

                $clean_receipt_nos_current_url=$current_receipt_nos_url_params.'&qreceipt_nos=';

            }
            if (strpos($current_receipt_nos_url_params, '?qreceipt_nos')) {

                $remove_receipt_nos_old_token = substr($current_receipt_nos_url_params, 0, strpos($current_receipt_nos_url_params, "?qreceipt_nos"));

                $clean_receipt_nos_current_url=$remove_receipt_nos_old_token.'?qreceipt_nos=';

            }
            if(strpos($current_receipt_nos_url_params, '&qreceipt_nos')) {

                $remove_receipt_nos_old_token = substr($current_receipt_nos_url_params, 0, strpos($current_receipt_nos_url_params, "&qreceipt_nos"));

                $clean_receipt_nos_current_url=$remove_receipt_nos_old_token.'&qreceipt_nos=';

            }
        $qreceipt_nos_str=base64_encode($_POST["txt_receipt_nos"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_receipt_nos_current_url.($qreceipt_nos_str);
            } 

          }else{ 
             header('location:'.$clean_receipt_nos_current_url.($qreceipt_nos_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_receipt_nos_);

        }
        }
        $qreceipt_nos="";
		if(isset($_GET["receipt_nos_mosyfilter"]) && isset($_GET["qreceipt_nos"])){
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "receipt_nos_mosyfilter_n_query","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {
         $qreceipt_nos=mmres(base64_decode($_GET["qreceipt_nos"]));
         
         $gft_receipt_nos_where_query="(`sales_date` LIKE '%".$qreceipt_nos."%' OR  `amount` LIKE '%".$qreceipt_nos."%' OR  `sold_by` LIKE '%".$qreceipt_nos."%' OR  `customer_id` LIKE '%".$qreceipt_nos."%')";
         
         if($_GET["receipt_nos_mosyfilter"]!=""){
         
         $mosyfilter_receipt_nos_queries_str=(base64_decode($_GET["receipt_nos_mosyfilter"]));
        
         $gft_receipt_nos_where_query="(`sales_date` LIKE '%".$qreceipt_nos."%' OR  `amount` LIKE '%".$qreceipt_nos."%' OR  `sold_by` LIKE '%".$qreceipt_nos."%' OR  `customer_id` LIKE '%".$qreceipt_nos."%') AND ".$mosyfilter_receipt_nos_queries_str."";
         
         }
         
		 $gft_receipt_nos="WHERE ".$gft_receipt_nos_where_query;
         
         $gft_receipt_nos_and=$gft_receipt_nos_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_receipt_nos_);
        }
        }elseif(isset($_GET["qreceipt_nos"])){
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "get_qreceipt_nos","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {
		 $qreceipt_nos=mmres(base64_decode($_GET["qreceipt_nos"]));
        
         $gft_receipt_nos_where_query="(`sales_date` LIKE '%".$qreceipt_nos."%' OR  `amount` LIKE '%".$qreceipt_nos."%' OR  `sold_by` LIKE '%".$qreceipt_nos."%' OR  `customer_id` LIKE '%".$qreceipt_nos."%')";
         
         $gft_receipt_nos="WHERE ".$gft_receipt_nos_where_query;
         
         $gft_receipt_nos_and=$gft_receipt_nos_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_receipt_nos_);

        }
        }elseif(isset($_GET["receipt_nos_mosyfilter"])){
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "receipt_nos_mosyfilter","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {
         $gft_receipt_nos_where_query="";
         $gft_receipt_nos="";

         if($_GET["receipt_nos_mosyfilter"]!=""){
          $gft_receipt_nos_where_query=(base64_decode($_GET["receipt_nos_mosyfilter"]));
          $gft_receipt_nos="WHERE ".$gft_receipt_nos_where_query;
         }
         
         
         $gft_receipt_nos_and=$gft_receipt_nos_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_receipt_nos_);

        }
        }else{
         $gft_receipt_nos="";
         $gft_receipt_nos_and="";
         $gft_receipt_nos_where_query="";
        }
       
    //************************************************* END  receipt_nos OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section stock_history
  //************************************************* START  stock_history OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize stock_history edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['stock_history_table_alert']))
              	{	
                  if(isset($stock_history_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$stock_history_uptoken="";

		if(isset($_GET["stock_history_uptoken"]))
		{
		$stock_history_uptoken=base64_decode($_GET["stock_history_uptoken"]);
		}
        
        if(isset($_POST["stock_history_uptoken"]))
		{
		$stock_history_uptoken=base64_decode($_POST["stock_history_uptoken"]);
		}
        //
        
          $stock_history_alias_name="STOCK HISTORY";

          if(isset($stock_history_alias))
          {
             $stock_history_alias_name=$stock_history_alias;

          }
          
        //get single data record query with $stock_history_uptoken
        
        ///$stock_history_node=get_stock_history("*", "WHERE primkey='$stock_history_uptoken'", "r");
        
	
//************* START INSERT  stock_history QUERY 
if(isset($_POST["stock_history_insert_btn"])){
//------- begin stock_history_arr_ins --> 
$stock_history_arr_ins_=array(

"primkey"=>"NULL",
"stock_key_sign"=>magic_random_str(7),
"item_id"=>"?",
"item_code"=>"?",
"quantity"=>"?",
"buying_price"=>"?",
"selling_price"=>"?",
"stock_alert"=>"?",
"tax_type"=>"?",
"tax_rate"=>"?",
"tax_amount"=>"?",
"item_name"=>"?",
"item_description"=>"?",
"supplier"=>"?",
"shop_location"=>"?",
"receipt_no"=>"?",
"invoice_no"=>"?",
"payment_mode"=>"?",
"inventory_date"=>"?",
"selling_price_n_tax"=>"?",
"total_buying_price"=>"?",
"margin_price"=>"?",
"total_units"=>"?",
"unit_per_dz"=>"?",
"signature"=>"?",
"invoice_amount"=>"?",
"invoice_amount_paid"=>"?",
"invoice_bal_amount"=>"?"

);
//===-- End stock_history_arr_ins -->


          
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "insert","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {

              $stock_history_validated_ins_str=$stock_history_arr_ins_;

              if(isset($stock_history_ins_inputs))
              {
                $stock_history_validated_ins_str=$stock_history_ins_inputs;	
              }

              if(empty($stock_history_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$stock_history_alias_name." request cannot be empty. Record not added");
              }else{

                $stock_history_return_key=add_stock_history($stock_history_validated_ins_str);
                
                mosy_sql_rollback("stock_history", "primkey='$stock_history_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $stock_history_return_key; 

                      } 

                    }else{ 

                                    
                $stock_history_custom_redir1=add_url_param ("stock_history_uptoken", base64_encode($stock_history_return_key), "");
                $stock_history_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$stock_history_custom_redir1);
                $stock_history_custom_redir3=add_url_param ("stock_history_table_alert", "stock_history_added",$stock_history_custom_redir2);
                
                ///echo magic_message($stock_history_custom_redir1." -- ".$stock_history_custom_redir2."--".$stock_history_custom_redir3);
                
                $stock_history_custom_redir=$stock_history_custom_redir3;
                
               header('location:'.$stock_history_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_stock_history_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
         
         }
      
}
//************* END  stock_history INSERT QUERY 	
	

//************* START stock_history  UPDATE QUERY 
if(isset($_POST["stock_history_update_btn"])){
//------- begin stock_history_arr_updt --> 
$stock_history_arr_updt_=array(
"item_id"=>"?",
"item_code"=>"?",
"quantity"=>"?",
"buying_price"=>"?",
"selling_price"=>"?",
"stock_alert"=>"?",
"tax_type"=>"?",
"tax_rate"=>"?",
"tax_amount"=>"?",
"item_name"=>"?",
"item_description"=>"?",
"supplier"=>"?",
"shop_location"=>"?",
"receipt_no"=>"?",
"invoice_no"=>"?",
"payment_mode"=>"?",
"inventory_date"=>"?",
"selling_price_n_tax"=>"?",
"total_buying_price"=>"?",
"margin_price"=>"?",
"total_units"=>"?",
"unit_per_dz"=>"?",
"signature"=>"?",
"invoice_amount"=>"?",
"invoice_amount_paid"=>"?",
"invoice_bal_amount"=>"?"

);
//===-- End stock_history_arr_updt -->
                     
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "update","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
         
            $stock_history_validated_updt_str=$stock_history_arr_updt_;

            if(isset($stock_history_updt_inputs))
            {
              $stock_history_validated_updt_str=$stock_history_updt_inputs;	
            }

            if(empty($stock_history_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$stock_history_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$stock_history_key_salt=initialize_stock_history()["stock_key_sign"];
            
              update_stock_history($stock_history_validated_updt_str, "primkey='$stock_history_uptoken' and stock_key_sign='$stock_history_key_salt'");
				

			 mosy_sql_rollback("stock_history", "primkey='$stock_history_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $stock_history_uptoken; 

                    } 

                  }else{ 

                $stock_history_custom_redir1=add_url_param ("stock_history_uptoken", base64_encode($stock_history_uptoken), "");
                $stock_history_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$stock_history_custom_redir1);
                $stock_history_custom_redir3=add_url_param ("stock_history_table_alert", "stock_history_updated",$stock_history_custom_redir2);
                
                ///echo magic_message($stock_history_custom_redir1." -- ".$stock_history_custom_redir2."--".$stock_history_custom_redir3);
                
                $stock_history_custom_redir=$stock_history_custom_redir3;
                
               header('location:'.$stock_history_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_stock_history_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
         
         }

      

      
}
//************* END stock_history  UPDATE QUERY 

    
    
      //== Start stock_history delete record

      if(isset($_GET["deletestock_history"]))
      {
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "super_delete_request","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_stock_history_btn=magic_button_link("./".$current_file_url."?stock_history_uptoken=".$_GET["stock_history_uptoken"]."&conf_deletestock_history&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_stock_history_btn=magic_button_link("./".$current_file_url."?stock_history_uptoken=".$_GET["stock_history_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_stock_history_btn." ".$cancel_del_stock_history_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_stock_history_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletestock_history"]))
      {
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "super_delete_confirm","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $stock_history_del_key_salt=initialize_stock_history()["stock_key_sign"];
      mosy_sql_rollback("stock_history", "primkey='$stock_history_uptoken'", "DELETE");
      drop_stock_history("primkey='$stock_history_uptoken' and stock_key_sign='$stock_history_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_stock_history_);

      }
      }

      //== End stock_history delete record  
    
       ///SELECT STRING FOR stock_history============================
              
       if(isset($_POST["qstock_history_btn"])){
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "qstock_history_btn","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
            $current_stock_history_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_stock_history_current_url=$current_stock_history_url_params.'?qstock_history=';
            if (strpos($current_stock_history_url_params, '?') !== false) {

                $clean_stock_history_current_url=$current_stock_history_url_params.'&qstock_history=';

            }
            if (strpos($current_stock_history_url_params, '?qstock_history')) {

                $remove_stock_history_old_token = substr($current_stock_history_url_params, 0, strpos($current_stock_history_url_params, "?qstock_history"));

                $clean_stock_history_current_url=$remove_stock_history_old_token.'?qstock_history=';

            }
            if(strpos($current_stock_history_url_params, '&qstock_history')) {

                $remove_stock_history_old_token = substr($current_stock_history_url_params, 0, strpos($current_stock_history_url_params, "&qstock_history"));

                $clean_stock_history_current_url=$remove_stock_history_old_token.'&qstock_history=';

            }
        $qstock_history_str=base64_encode($_POST["txt_stock_history"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_stock_history_current_url.($qstock_history_str);
            } 

          }else{ 
             header('location:'.$clean_stock_history_current_url.($qstock_history_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_stock_history_);

        }
        }
        $qstock_history="";
		if(isset($_GET["stock_history_mosyfilter"]) && isset($_GET["qstock_history"])){
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "stock_history_mosyfilter_n_query","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
         $qstock_history=mmres(base64_decode($_GET["qstock_history"]));
         
         $gft_stock_history_where_query="(`stock_key_sign` LIKE '%".$qstock_history."%' OR  `item_id` LIKE '%".$qstock_history."%' OR  `item_code` LIKE '%".$qstock_history."%' OR  `quantity` LIKE '%".$qstock_history."%' OR  `buying_price` LIKE '%".$qstock_history."%' OR  `selling_price` LIKE '%".$qstock_history."%' OR  `stock_alert` LIKE '%".$qstock_history."%' OR  `tax_type` LIKE '%".$qstock_history."%' OR  `tax_rate` LIKE '%".$qstock_history."%' OR  `tax_amount` LIKE '%".$qstock_history."%' OR  `item_name` LIKE '%".$qstock_history."%' OR  `item_description` LIKE '%".$qstock_history."%' OR  `supplier` LIKE '%".$qstock_history."%' OR  `shop_location` LIKE '%".$qstock_history."%' OR  `receipt_no` LIKE '%".$qstock_history."%' OR  `invoice_no` LIKE '%".$qstock_history."%' OR  `payment_mode` LIKE '%".$qstock_history."%' OR  `inventory_date` LIKE '%".$qstock_history."%' OR  `selling_price_n_tax` LIKE '%".$qstock_history."%' OR  `total_buying_price` LIKE '%".$qstock_history."%' OR  `margin_price` LIKE '%".$qstock_history."%' OR  `total_units` LIKE '%".$qstock_history."%' OR  `unit_per_dz` LIKE '%".$qstock_history."%' OR  `signature` LIKE '%".$qstock_history."%' OR  `invoice_amount` LIKE '%".$qstock_history."%' OR  `invoice_amount_paid` LIKE '%".$qstock_history."%' OR  `invoice_bal_amount` LIKE '%".$qstock_history."%')";
         
         if($_GET["stock_history_mosyfilter"]!=""){
         
         $mosyfilter_stock_history_queries_str=(base64_decode($_GET["stock_history_mosyfilter"]));
        
         $gft_stock_history_where_query="(`stock_key_sign` LIKE '%".$qstock_history."%' OR  `item_id` LIKE '%".$qstock_history."%' OR  `item_code` LIKE '%".$qstock_history."%' OR  `quantity` LIKE '%".$qstock_history."%' OR  `buying_price` LIKE '%".$qstock_history."%' OR  `selling_price` LIKE '%".$qstock_history."%' OR  `stock_alert` LIKE '%".$qstock_history."%' OR  `tax_type` LIKE '%".$qstock_history."%' OR  `tax_rate` LIKE '%".$qstock_history."%' OR  `tax_amount` LIKE '%".$qstock_history."%' OR  `item_name` LIKE '%".$qstock_history."%' OR  `item_description` LIKE '%".$qstock_history."%' OR  `supplier` LIKE '%".$qstock_history."%' OR  `shop_location` LIKE '%".$qstock_history."%' OR  `receipt_no` LIKE '%".$qstock_history."%' OR  `invoice_no` LIKE '%".$qstock_history."%' OR  `payment_mode` LIKE '%".$qstock_history."%' OR  `inventory_date` LIKE '%".$qstock_history."%' OR  `selling_price_n_tax` LIKE '%".$qstock_history."%' OR  `total_buying_price` LIKE '%".$qstock_history."%' OR  `margin_price` LIKE '%".$qstock_history."%' OR  `total_units` LIKE '%".$qstock_history."%' OR  `unit_per_dz` LIKE '%".$qstock_history."%' OR  `signature` LIKE '%".$qstock_history."%' OR  `invoice_amount` LIKE '%".$qstock_history."%' OR  `invoice_amount_paid` LIKE '%".$qstock_history."%' OR  `invoice_bal_amount` LIKE '%".$qstock_history."%') AND ".$mosyfilter_stock_history_queries_str."";
         
         }
         
		 $gft_stock_history="WHERE ".$gft_stock_history_where_query;
         
         $gft_stock_history_and=$gft_stock_history_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_stock_history_);
        }
        }elseif(isset($_GET["qstock_history"])){
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "get_qstock_history","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
		 $qstock_history=mmres(base64_decode($_GET["qstock_history"]));
        
         $gft_stock_history_where_query="(`stock_key_sign` LIKE '%".$qstock_history."%' OR  `item_id` LIKE '%".$qstock_history."%' OR  `item_code` LIKE '%".$qstock_history."%' OR  `quantity` LIKE '%".$qstock_history."%' OR  `buying_price` LIKE '%".$qstock_history."%' OR  `selling_price` LIKE '%".$qstock_history."%' OR  `stock_alert` LIKE '%".$qstock_history."%' OR  `tax_type` LIKE '%".$qstock_history."%' OR  `tax_rate` LIKE '%".$qstock_history."%' OR  `tax_amount` LIKE '%".$qstock_history."%' OR  `item_name` LIKE '%".$qstock_history."%' OR  `item_description` LIKE '%".$qstock_history."%' OR  `supplier` LIKE '%".$qstock_history."%' OR  `shop_location` LIKE '%".$qstock_history."%' OR  `receipt_no` LIKE '%".$qstock_history."%' OR  `invoice_no` LIKE '%".$qstock_history."%' OR  `payment_mode` LIKE '%".$qstock_history."%' OR  `inventory_date` LIKE '%".$qstock_history."%' OR  `selling_price_n_tax` LIKE '%".$qstock_history."%' OR  `total_buying_price` LIKE '%".$qstock_history."%' OR  `margin_price` LIKE '%".$qstock_history."%' OR  `total_units` LIKE '%".$qstock_history."%' OR  `unit_per_dz` LIKE '%".$qstock_history."%' OR  `signature` LIKE '%".$qstock_history."%' OR  `invoice_amount` LIKE '%".$qstock_history."%' OR  `invoice_amount_paid` LIKE '%".$qstock_history."%' OR  `invoice_bal_amount` LIKE '%".$qstock_history."%')";
         
         $gft_stock_history="WHERE ".$gft_stock_history_where_query;
         
         $gft_stock_history_and=$gft_stock_history_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_stock_history_);

        }
        }elseif(isset($_GET["stock_history_mosyfilter"])){
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "stock_history_mosyfilter","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
         $gft_stock_history_where_query="";
         $gft_stock_history="";

         if($_GET["stock_history_mosyfilter"]!=""){
          $gft_stock_history_where_query=(base64_decode($_GET["stock_history_mosyfilter"]));
          $gft_stock_history="WHERE ".$gft_stock_history_where_query;
         }
         
         
         $gft_stock_history_and=$gft_stock_history_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_stock_history_);

        }
        }else{
         $gft_stock_history="";
         $gft_stock_history_and="";
         $gft_stock_history_where_query="";
        }
       
    //************************************************* END  stock_history OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section stock_list
  //************************************************* START  stock_list OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize stock_list edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['stock_list_table_alert']))
              	{	
                  if(isset($stock_list_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$stock_list_uptoken="";

		if(isset($_GET["stock_list_uptoken"]))
		{
		$stock_list_uptoken=base64_decode($_GET["stock_list_uptoken"]);
		}
        
        if(isset($_POST["stock_list_uptoken"]))
		{
		$stock_list_uptoken=base64_decode($_POST["stock_list_uptoken"]);
		}
        //
        
          $stock_list_alias_name="STOCK LIST";

          if(isset($stock_list_alias))
          {
             $stock_list_alias_name=$stock_list_alias;

          }
          
        //get single data record query with $stock_list_uptoken
        
        ///$stock_list_node=get_stock_list("*", "WHERE primkey='$stock_list_uptoken'", "r");
        
	
//************* START INSERT  stock_list QUERY 
if(isset($_POST["stock_list_insert_btn"])){
//------- begin stock_list_arr_ins --> 
$stock_list_arr_ins_=array(

"primkey"=>"NULL",
"item_id"=>magic_random_str(7),
"item_code"=>"?",
"item_name"=>"?",
"item_description"=>"?",
"buying_price"=>"?",
"selling_price"=>"?",
"quantity"=>"?",
"stock_alert"=>"?",
"tax_type"=>"?",
"tax_rate"=>"?",
"tax_amount"=>"?",
"shop_location"=>"?",
"receipt_no"=>"?",
"invoice_no"=>"?",
"payment_mode"=>"?",
"selling_price_n_tax"=>"?",
"margin_price"=>"?"

);
//===-- End stock_list_arr_ins -->


          
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "insert","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {

              $stock_list_validated_ins_str=$stock_list_arr_ins_;

              if(isset($stock_list_ins_inputs))
              {
                $stock_list_validated_ins_str=$stock_list_ins_inputs;	
              }

              if(empty($stock_list_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$stock_list_alias_name." request cannot be empty. Record not added");
              }else{

                $stock_list_return_key=add_stock_list($stock_list_validated_ins_str);
                
                mosy_sql_rollback("stock_list", "primkey='$stock_list_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $stock_list_return_key; 

                      } 

                    }else{ 

                                    
                $stock_list_custom_redir1=add_url_param ("stock_list_uptoken", base64_encode($stock_list_return_key), "");
                $stock_list_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$stock_list_custom_redir1);
                $stock_list_custom_redir3=add_url_param ("stock_list_table_alert", "stock_list_added",$stock_list_custom_redir2);
                
                ///echo magic_message($stock_list_custom_redir1." -- ".$stock_list_custom_redir2."--".$stock_list_custom_redir3);
                
                $stock_list_custom_redir=$stock_list_custom_redir3;
                
               header('location:'.$stock_list_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_stock_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");
         
         }
      
}
//************* END  stock_list INSERT QUERY 	
	

//************* START stock_list  UPDATE QUERY 
if(isset($_POST["stock_list_update_btn"])){
//------- begin stock_list_arr_updt --> 
$stock_list_arr_updt_=array(
"item_code"=>"?",
"item_name"=>"?",
"item_description"=>"?",
"buying_price"=>"?",
"selling_price"=>"?",
"quantity"=>"?",
"stock_alert"=>"?",
"tax_type"=>"?",
"tax_rate"=>"?",
"tax_amount"=>"?",
"shop_location"=>"?",
"receipt_no"=>"?",
"invoice_no"=>"?",
"payment_mode"=>"?",
"selling_price_n_tax"=>"?",
"margin_price"=>"?"

);
//===-- End stock_list_arr_updt -->
                     
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "update","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {
         
            $stock_list_validated_updt_str=$stock_list_arr_updt_;

            if(isset($stock_list_updt_inputs))
            {
              $stock_list_validated_updt_str=$stock_list_updt_inputs;	
            }

            if(empty($stock_list_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$stock_list_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$stock_list_key_salt=initialize_stock_list()["item_id"];
            
              update_stock_list($stock_list_validated_updt_str, "primkey='$stock_list_uptoken' and item_id='$stock_list_key_salt'");
				

			 mosy_sql_rollback("stock_list", "primkey='$stock_list_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $stock_list_uptoken; 

                    } 

                  }else{ 

                $stock_list_custom_redir1=add_url_param ("stock_list_uptoken", base64_encode($stock_list_uptoken), "");
                $stock_list_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$stock_list_custom_redir1);
                $stock_list_custom_redir3=add_url_param ("stock_list_table_alert", "stock_list_updated",$stock_list_custom_redir2);
                
                ///echo magic_message($stock_list_custom_redir1." -- ".$stock_list_custom_redir2."--".$stock_list_custom_redir3);
                
                $stock_list_custom_redir=$stock_list_custom_redir3;
                
               header('location:'.$stock_list_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_stock_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");
         
         }

      

      
}
//************* END stock_list  UPDATE QUERY 

    
    
      //== Start stock_list delete record

      if(isset($_GET["deletestock_list"]))
      {
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "super_delete_request","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_stock_list_btn=magic_button_link("./".$current_file_url."?stock_list_uptoken=".$_GET["stock_list_uptoken"]."&conf_deletestock_list&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_stock_list_btn=magic_button_link("./".$current_file_url."?stock_list_uptoken=".$_GET["stock_list_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_stock_list_btn." ".$cancel_del_stock_list_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_stock_list_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletestock_list"]))
      {
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "super_delete_confirm","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $stock_list_del_key_salt=initialize_stock_list()["item_id"];
      mosy_sql_rollback("stock_list", "primkey='$stock_list_uptoken'", "DELETE");
      drop_stock_list("primkey='$stock_list_uptoken' and item_id='$stock_list_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_stock_list_);

      }
      }

      //== End stock_list delete record  
    
       ///SELECT STRING FOR stock_list============================
              
       if(isset($_POST["qstock_list_btn"])){
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "qstock_list_btn","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {
            $current_stock_list_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_stock_list_current_url=$current_stock_list_url_params.'?qstock_list=';
            if (strpos($current_stock_list_url_params, '?') !== false) {

                $clean_stock_list_current_url=$current_stock_list_url_params.'&qstock_list=';

            }
            if (strpos($current_stock_list_url_params, '?qstock_list')) {

                $remove_stock_list_old_token = substr($current_stock_list_url_params, 0, strpos($current_stock_list_url_params, "?qstock_list"));

                $clean_stock_list_current_url=$remove_stock_list_old_token.'?qstock_list=';

            }
            if(strpos($current_stock_list_url_params, '&qstock_list')) {

                $remove_stock_list_old_token = substr($current_stock_list_url_params, 0, strpos($current_stock_list_url_params, "&qstock_list"));

                $clean_stock_list_current_url=$remove_stock_list_old_token.'&qstock_list=';

            }
        $qstock_list_str=base64_encode($_POST["txt_stock_list"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_stock_list_current_url.($qstock_list_str);
            } 

          }else{ 
             header('location:'.$clean_stock_list_current_url.($qstock_list_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_stock_list_);

        }
        }
        $qstock_list="";
		if(isset($_GET["stock_list_mosyfilter"]) && isset($_GET["qstock_list"])){
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "stock_list_mosyfilter_n_query","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {
         $qstock_list=mmres(base64_decode($_GET["qstock_list"]));
         
         $gft_stock_list_where_query="(`item_id` LIKE '%".$qstock_list."%' OR  `item_code` LIKE '%".$qstock_list."%' OR  `item_name` LIKE '%".$qstock_list."%' OR  `item_description` LIKE '%".$qstock_list."%' OR  `buying_price` LIKE '%".$qstock_list."%' OR  `selling_price` LIKE '%".$qstock_list."%' OR  `quantity` LIKE '%".$qstock_list."%' OR  `stock_alert` LIKE '%".$qstock_list."%' OR  `tax_type` LIKE '%".$qstock_list."%' OR  `tax_rate` LIKE '%".$qstock_list."%' OR  `tax_amount` LIKE '%".$qstock_list."%' OR  `shop_location` LIKE '%".$qstock_list."%' OR  `receipt_no` LIKE '%".$qstock_list."%' OR  `invoice_no` LIKE '%".$qstock_list."%' OR  `payment_mode` LIKE '%".$qstock_list."%' OR  `selling_price_n_tax` LIKE '%".$qstock_list."%' OR  `margin_price` LIKE '%".$qstock_list."%')";
         
         if($_GET["stock_list_mosyfilter"]!=""){
         
         $mosyfilter_stock_list_queries_str=(base64_decode($_GET["stock_list_mosyfilter"]));
        
         $gft_stock_list_where_query="(`item_id` LIKE '%".$qstock_list."%' OR  `item_code` LIKE '%".$qstock_list."%' OR  `item_name` LIKE '%".$qstock_list."%' OR  `item_description` LIKE '%".$qstock_list."%' OR  `buying_price` LIKE '%".$qstock_list."%' OR  `selling_price` LIKE '%".$qstock_list."%' OR  `quantity` LIKE '%".$qstock_list."%' OR  `stock_alert` LIKE '%".$qstock_list."%' OR  `tax_type` LIKE '%".$qstock_list."%' OR  `tax_rate` LIKE '%".$qstock_list."%' OR  `tax_amount` LIKE '%".$qstock_list."%' OR  `shop_location` LIKE '%".$qstock_list."%' OR  `receipt_no` LIKE '%".$qstock_list."%' OR  `invoice_no` LIKE '%".$qstock_list."%' OR  `payment_mode` LIKE '%".$qstock_list."%' OR  `selling_price_n_tax` LIKE '%".$qstock_list."%' OR  `margin_price` LIKE '%".$qstock_list."%') AND ".$mosyfilter_stock_list_queries_str."";
         
         }
         
		 $gft_stock_list="WHERE ".$gft_stock_list_where_query;
         
         $gft_stock_list_and=$gft_stock_list_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_stock_list_);
        }
        }elseif(isset($_GET["qstock_list"])){
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "get_qstock_list","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {
		 $qstock_list=mmres(base64_decode($_GET["qstock_list"]));
        
         $gft_stock_list_where_query="(`item_id` LIKE '%".$qstock_list."%' OR  `item_code` LIKE '%".$qstock_list."%' OR  `item_name` LIKE '%".$qstock_list."%' OR  `item_description` LIKE '%".$qstock_list."%' OR  `buying_price` LIKE '%".$qstock_list."%' OR  `selling_price` LIKE '%".$qstock_list."%' OR  `quantity` LIKE '%".$qstock_list."%' OR  `stock_alert` LIKE '%".$qstock_list."%' OR  `tax_type` LIKE '%".$qstock_list."%' OR  `tax_rate` LIKE '%".$qstock_list."%' OR  `tax_amount` LIKE '%".$qstock_list."%' OR  `shop_location` LIKE '%".$qstock_list."%' OR  `receipt_no` LIKE '%".$qstock_list."%' OR  `invoice_no` LIKE '%".$qstock_list."%' OR  `payment_mode` LIKE '%".$qstock_list."%' OR  `selling_price_n_tax` LIKE '%".$qstock_list."%' OR  `margin_price` LIKE '%".$qstock_list."%')";
         
         $gft_stock_list="WHERE ".$gft_stock_list_where_query;
         
         $gft_stock_list_and=$gft_stock_list_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_stock_list_);

        }
        }elseif(isset($_GET["stock_list_mosyfilter"])){
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "stock_list_mosyfilter","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {
         $gft_stock_list_where_query="";
         $gft_stock_list="";

         if($_GET["stock_list_mosyfilter"]!=""){
          $gft_stock_list_where_query=(base64_decode($_GET["stock_list_mosyfilter"]));
          $gft_stock_list="WHERE ".$gft_stock_list_where_query;
         }
         
         
         $gft_stock_list_and=$gft_stock_list_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_stock_list_);

        }
        }else{
         $gft_stock_list="";
         $gft_stock_list_and="";
         $gft_stock_list_where_query="";
        }
       
    //************************************************* END  stock_list OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section suppliers
  //************************************************* START  suppliers OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize suppliers edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['suppliers_table_alert']))
              	{	
                  if(isset($suppliers_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$suppliers_uptoken="";

		if(isset($_GET["suppliers_uptoken"]))
		{
		$suppliers_uptoken=base64_decode($_GET["suppliers_uptoken"]);
		}
        
        if(isset($_POST["suppliers_uptoken"]))
		{
		$suppliers_uptoken=base64_decode($_POST["suppliers_uptoken"]);
		}
        //
        
          $suppliers_alias_name="SUPPLIERS";

          if(isset($suppliers_alias))
          {
             $suppliers_alias_name=$suppliers_alias;

          }
          
        //get single data record query with $suppliers_uptoken
        
        ///$suppliers_node=get_suppliers("*", "WHERE primkey='$suppliers_uptoken'", "r");
        
	
//************* START INSERT  suppliers QUERY 
if(isset($_POST["suppliers_insert_btn"])){
//------- begin suppliers_arr_ins --> 
$suppliers_arr_ins_=array(

"primkey"=>"NULL",
"supplier_id"=>magic_random_str(7),
"vendor_no"=>"?",
"specialization"=>"?",
"name"=>"?",
"phone"=>"?",
"email"=>"?",
"postal_address"=>"?",
"physical_address"=>"?",
"website"=>"?",
"user_pic"=>"?",
"created_at"=>"?"

);
//===-- End suppliers_arr_ins -->


          
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "insert","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {

              $suppliers_validated_ins_str=$suppliers_arr_ins_;

              if(isset($suppliers_ins_inputs))
              {
                $suppliers_validated_ins_str=$suppliers_ins_inputs;	
              }

              if(empty($suppliers_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$suppliers_alias_name." request cannot be empty. Record not added");
              }else{

                $suppliers_return_key=add_suppliers($suppliers_validated_ins_str);
                
                mosy_sql_rollback("suppliers", "primkey='$suppliers_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_suppliers_user_pic']['tmp_name']))
                {
                
                 upload_suppliers_user_pic('txt_suppliers_user_pic', "primkey='$suppliers_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $suppliers_return_key; 

                      } 

                    }else{ 

                                    
                $suppliers_custom_redir1=add_url_param ("suppliers_uptoken", base64_encode($suppliers_return_key), "");
                $suppliers_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$suppliers_custom_redir1);
                $suppliers_custom_redir3=add_url_param ("suppliers_table_alert", "suppliers_added",$suppliers_custom_redir2);
                
                ///echo magic_message($suppliers_custom_redir1." -- ".$suppliers_custom_redir2."--".$suppliers_custom_redir3);
                
                $suppliers_custom_redir=$suppliers_custom_redir3;
                
               header('location:'.$suppliers_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_suppliers_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
         
         }
      
}
//************* END  suppliers INSERT QUERY 	
	

//************* START suppliers  UPDATE QUERY 
if(isset($_POST["suppliers_update_btn"])){
//------- begin suppliers_arr_updt --> 
$suppliers_arr_updt_=array(
"vendor_no"=>"?",
"specialization"=>"?",
"name"=>"?",
"phone"=>"?",
"email"=>"?",
"postal_address"=>"?",
"physical_address"=>"?",
"website"=>"?",
"user_pic"=>"?",
"created_at"=>"?"

);
//===-- End suppliers_arr_updt -->
                     
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "update","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
         
            $suppliers_validated_updt_str=$suppliers_arr_updt_;

            if(isset($suppliers_updt_inputs))
            {
              $suppliers_validated_updt_str=$suppliers_updt_inputs;	
            }

            if(empty($suppliers_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$suppliers_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$suppliers_key_salt=initialize_suppliers()["supplier_id"];
            
              update_suppliers($suppliers_validated_updt_str, "primkey='$suppliers_uptoken' and supplier_id='$suppliers_key_salt'");
				
         
                if(!empty($_FILES['txt_suppliers_user_pic']['tmp_name']))
                {
                
                 upload_suppliers_user_pic('txt_suppliers_user_pic', "primkey='$suppliers_uptoken'");
                 
				}

			 mosy_sql_rollback("suppliers", "primkey='$suppliers_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $suppliers_uptoken; 

                    } 

                  }else{ 

                $suppliers_custom_redir1=add_url_param ("suppliers_uptoken", base64_encode($suppliers_uptoken), "");
                $suppliers_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$suppliers_custom_redir1);
                $suppliers_custom_redir3=add_url_param ("suppliers_table_alert", "suppliers_updated",$suppliers_custom_redir2);
                
                ///echo magic_message($suppliers_custom_redir1." -- ".$suppliers_custom_redir2."--".$suppliers_custom_redir3);
                
                $suppliers_custom_redir=$suppliers_custom_redir3;
                
               header('location:'.$suppliers_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_suppliers_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
         
         }

      

      
}
//************* END suppliers  UPDATE QUERY 

    

          //===-====Start upload suppliers_user_pic 
          if(isset($_POST["btn_upload_suppliers_user_pic"]))
          {
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "upload_suppliers_user_pic","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_suppliers_user_pic']['tmp_name'])){

				upload_suppliers_user_pic('txt_suppliers_user_pic', "primkey='$suppliers_uptoken'");
                
                $suppliers_custom_redir1=add_url_param ("suppliers_uptoken", base64_encode($suppliers_uptoken), "");
                $suppliers_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$suppliers_custom_redir1);
                $suppliers_custom_redir3=add_url_param ("suppliers_table_alert", "suppliers_uploaded",$suppliers_custom_redir2);
                
                ///echo magic_message($suppliers_custom_redir1." -- ".$suppliers_custom_redir2."--".$suppliers_custom_redir3);
                
                $suppliers_custom_redir=$suppliers_custom_redir3;
                
               header('location:'.$suppliers_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_suppliers_);

          }
          }
          //===-====End upload suppliers_user_pic  

			//drop suppliers_user_pic image 
            
          if(isset($_GET["conf_deletesuppliers"]))
          {
          	$suppliers_node=initialize_suppliers();
          	if($suppliers_node["user_pic"]!="")
            {
          	 unlink($suppliers_node["user_pic"]);
            }
          }
          
          
    
      //== Start suppliers delete record

      if(isset($_GET["deletesuppliers"]))
      {
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "super_delete_request","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_suppliers_btn=magic_button_link("./".$current_file_url."?suppliers_uptoken=".$_GET["suppliers_uptoken"]."&conf_deletesuppliers&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_suppliers_btn=magic_button_link("./".$current_file_url."?suppliers_uptoken=".$_GET["suppliers_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_suppliers_btn." ".$cancel_del_suppliers_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_suppliers_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesuppliers"]))
      {
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "super_delete_confirm","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $suppliers_del_key_salt=initialize_suppliers()["supplier_id"];
      mosy_sql_rollback("suppliers", "primkey='$suppliers_uptoken'", "DELETE");
      drop_suppliers("primkey='$suppliers_uptoken' and supplier_id='$suppliers_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_suppliers_);

      }
      }

      //== End suppliers delete record  
    
       ///SELECT STRING FOR suppliers============================
              
       if(isset($_POST["qsuppliers_btn"])){
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "qsuppliers_btn","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
            $current_suppliers_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_suppliers_current_url=$current_suppliers_url_params.'?qsuppliers=';
            if (strpos($current_suppliers_url_params, '?') !== false) {

                $clean_suppliers_current_url=$current_suppliers_url_params.'&qsuppliers=';

            }
            if (strpos($current_suppliers_url_params, '?qsuppliers')) {

                $remove_suppliers_old_token = substr($current_suppliers_url_params, 0, strpos($current_suppliers_url_params, "?qsuppliers"));

                $clean_suppliers_current_url=$remove_suppliers_old_token.'?qsuppliers=';

            }
            if(strpos($current_suppliers_url_params, '&qsuppliers')) {

                $remove_suppliers_old_token = substr($current_suppliers_url_params, 0, strpos($current_suppliers_url_params, "&qsuppliers"));

                $clean_suppliers_current_url=$remove_suppliers_old_token.'&qsuppliers=';

            }
        $qsuppliers_str=base64_encode($_POST["txt_suppliers"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_suppliers_current_url.($qsuppliers_str);
            } 

          }else{ 
             header('location:'.$clean_suppliers_current_url.($qsuppliers_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_suppliers_);

        }
        }
        $qsuppliers="";
		if(isset($_GET["suppliers_mosyfilter"]) && isset($_GET["qsuppliers"])){
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "suppliers_mosyfilter_n_query","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
         $qsuppliers=mmres(base64_decode($_GET["qsuppliers"]));
         
         $gft_suppliers_where_query="(`supplier_id` LIKE '%".$qsuppliers."%' OR  `vendor_no` LIKE '%".$qsuppliers."%' OR  `specialization` LIKE '%".$qsuppliers."%' OR  `name` LIKE '%".$qsuppliers."%' OR  `phone` LIKE '%".$qsuppliers."%' OR  `email` LIKE '%".$qsuppliers."%' OR  `postal_address` LIKE '%".$qsuppliers."%' OR  `physical_address` LIKE '%".$qsuppliers."%' OR  `website` LIKE '%".$qsuppliers."%' OR  `user_pic` LIKE '%".$qsuppliers."%' OR  `created_at` LIKE '%".$qsuppliers."%')";
         
         if($_GET["suppliers_mosyfilter"]!=""){
         
         $mosyfilter_suppliers_queries_str=(base64_decode($_GET["suppliers_mosyfilter"]));
        
         $gft_suppliers_where_query="(`supplier_id` LIKE '%".$qsuppliers."%' OR  `vendor_no` LIKE '%".$qsuppliers."%' OR  `specialization` LIKE '%".$qsuppliers."%' OR  `name` LIKE '%".$qsuppliers."%' OR  `phone` LIKE '%".$qsuppliers."%' OR  `email` LIKE '%".$qsuppliers."%' OR  `postal_address` LIKE '%".$qsuppliers."%' OR  `physical_address` LIKE '%".$qsuppliers."%' OR  `website` LIKE '%".$qsuppliers."%' OR  `user_pic` LIKE '%".$qsuppliers."%' OR  `created_at` LIKE '%".$qsuppliers."%') AND ".$mosyfilter_suppliers_queries_str."";
         
         }
         
		 $gft_suppliers="WHERE ".$gft_suppliers_where_query;
         
         $gft_suppliers_and=$gft_suppliers_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_suppliers_);
        }
        }elseif(isset($_GET["qsuppliers"])){
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "get_qsuppliers","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
		 $qsuppliers=mmres(base64_decode($_GET["qsuppliers"]));
        
         $gft_suppliers_where_query="(`supplier_id` LIKE '%".$qsuppliers."%' OR  `vendor_no` LIKE '%".$qsuppliers."%' OR  `specialization` LIKE '%".$qsuppliers."%' OR  `name` LIKE '%".$qsuppliers."%' OR  `phone` LIKE '%".$qsuppliers."%' OR  `email` LIKE '%".$qsuppliers."%' OR  `postal_address` LIKE '%".$qsuppliers."%' OR  `physical_address` LIKE '%".$qsuppliers."%' OR  `website` LIKE '%".$qsuppliers."%' OR  `user_pic` LIKE '%".$qsuppliers."%' OR  `created_at` LIKE '%".$qsuppliers."%')";
         
         $gft_suppliers="WHERE ".$gft_suppliers_where_query;
         
         $gft_suppliers_and=$gft_suppliers_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_suppliers_);

        }
        }elseif(isset($_GET["suppliers_mosyfilter"])){
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "suppliers_mosyfilter","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
         $gft_suppliers_where_query="";
         $gft_suppliers="";

         if($_GET["suppliers_mosyfilter"]!=""){
          $gft_suppliers_where_query=(base64_decode($_GET["suppliers_mosyfilter"]));
          $gft_suppliers="WHERE ".$gft_suppliers_where_query;
         }
         
         
         $gft_suppliers_and=$gft_suppliers_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_suppliers_);

        }
        }else{
         $gft_suppliers="";
         $gft_suppliers_and="";
         $gft_suppliers_where_query="";
        }
       
    //************************************************* END  suppliers OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section suppliers_invoice
  //************************************************* START  suppliers_invoice OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize suppliers_invoice edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['suppliers_invoice_table_alert']))
              	{	
                  if(isset($suppliers_invoice_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$suppliers_invoice_uptoken="";

		if(isset($_GET["suppliers_invoice_uptoken"]))
		{
		$suppliers_invoice_uptoken=base64_decode($_GET["suppliers_invoice_uptoken"]);
		}
        
        if(isset($_POST["suppliers_invoice_uptoken"]))
		{
		$suppliers_invoice_uptoken=base64_decode($_POST["suppliers_invoice_uptoken"]);
		}
        //
        
          $suppliers_invoice_alias_name="SUPPLIERS INVOICE";

          if(isset($suppliers_invoice_alias))
          {
             $suppliers_invoice_alias_name=$suppliers_invoice_alias;

          }
          
        //get single data record query with $suppliers_invoice_uptoken
        
        ///$suppliers_invoice_node=get_suppliers_invoice("*", "WHERE primkey='$suppliers_invoice_uptoken'", "r");
        
	
//************* START INSERT  suppliers_invoice QUERY 
if(isset($_POST["suppliers_invoice_insert_btn"])){
//------- begin suppliers_invoice_arr_ins --> 
$suppliers_invoice_arr_ins_=array(

"primkey"=>"NULL",
"data_id"=>magic_random_str(7),
"stock_amount"=>"?",
"supplier_id"=>"?",
"receipt_id"=>"?",
"invoice_no"=>"?",
"stock_data"=>"?",
"amount_paid"=>"?",
"stock_balance"=>"?",
"user_id"=>"?",
"item_id"=>"?",
"purchase_amt"=>"?"

);
//===-- End suppliers_invoice_arr_ins -->


          
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "insert","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {

              $suppliers_invoice_validated_ins_str=$suppliers_invoice_arr_ins_;

              if(isset($suppliers_invoice_ins_inputs))
              {
                $suppliers_invoice_validated_ins_str=$suppliers_invoice_ins_inputs;	
              }

              if(empty($suppliers_invoice_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$suppliers_invoice_alias_name." request cannot be empty. Record not added");
              }else{

                $suppliers_invoice_return_key=add_suppliers_invoice($suppliers_invoice_validated_ins_str);
                
                mosy_sql_rollback("suppliers_invoice", "primkey='$suppliers_invoice_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $suppliers_invoice_return_key; 

                      } 

                    }else{ 

                                    
                $suppliers_invoice_custom_redir1=add_url_param ("suppliers_invoice_uptoken", base64_encode($suppliers_invoice_return_key), "");
                $suppliers_invoice_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$suppliers_invoice_custom_redir1);
                $suppliers_invoice_custom_redir3=add_url_param ("suppliers_invoice_table_alert", "suppliers_invoice_added",$suppliers_invoice_custom_redir2);
                
                ///echo magic_message($suppliers_invoice_custom_redir1." -- ".$suppliers_invoice_custom_redir2."--".$suppliers_invoice_custom_redir3);
                
                $suppliers_invoice_custom_redir=$suppliers_invoice_custom_redir3;
                
               header('location:'.$suppliers_invoice_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_suppliers_invoice_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");
         
         }
      
}
//************* END  suppliers_invoice INSERT QUERY 	
	

//************* START suppliers_invoice  UPDATE QUERY 
if(isset($_POST["suppliers_invoice_update_btn"])){
//------- begin suppliers_invoice_arr_updt --> 
$suppliers_invoice_arr_updt_=array(
"stock_amount"=>"?",
"supplier_id"=>"?",
"receipt_id"=>"?",
"invoice_no"=>"?",
"stock_data"=>"?",
"amount_paid"=>"?",
"stock_balance"=>"?",
"user_id"=>"?",
"item_id"=>"?",
"purchase_amt"=>"?"

);
//===-- End suppliers_invoice_arr_updt -->
                     
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "update","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {
         
            $suppliers_invoice_validated_updt_str=$suppliers_invoice_arr_updt_;

            if(isset($suppliers_invoice_updt_inputs))
            {
              $suppliers_invoice_validated_updt_str=$suppliers_invoice_updt_inputs;	
            }

            if(empty($suppliers_invoice_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$suppliers_invoice_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$suppliers_invoice_key_salt=initialize_suppliers_invoice()["data_id"];
            
              update_suppliers_invoice($suppliers_invoice_validated_updt_str, "primkey='$suppliers_invoice_uptoken' and data_id='$suppliers_invoice_key_salt'");
				

			 mosy_sql_rollback("suppliers_invoice", "primkey='$suppliers_invoice_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $suppliers_invoice_uptoken; 

                    } 

                  }else{ 

                $suppliers_invoice_custom_redir1=add_url_param ("suppliers_invoice_uptoken", base64_encode($suppliers_invoice_uptoken), "");
                $suppliers_invoice_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$suppliers_invoice_custom_redir1);
                $suppliers_invoice_custom_redir3=add_url_param ("suppliers_invoice_table_alert", "suppliers_invoice_updated",$suppliers_invoice_custom_redir2);
                
                ///echo magic_message($suppliers_invoice_custom_redir1." -- ".$suppliers_invoice_custom_redir2."--".$suppliers_invoice_custom_redir3);
                
                $suppliers_invoice_custom_redir=$suppliers_invoice_custom_redir3;
                
               header('location:'.$suppliers_invoice_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_suppliers_invoice_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");
         
         }

      

      
}
//************* END suppliers_invoice  UPDATE QUERY 

    
    
      //== Start suppliers_invoice delete record

      if(isset($_GET["deletesuppliers_invoice"]))
      {
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "super_delete_request","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_suppliers_invoice_btn=magic_button_link("./".$current_file_url."?suppliers_invoice_uptoken=".$_GET["suppliers_invoice_uptoken"]."&conf_deletesuppliers_invoice&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_suppliers_invoice_btn=magic_button_link("./".$current_file_url."?suppliers_invoice_uptoken=".$_GET["suppliers_invoice_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_suppliers_invoice_btn." ".$cancel_del_suppliers_invoice_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_suppliers_invoice_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesuppliers_invoice"]))
      {
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "super_delete_confirm","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $suppliers_invoice_del_key_salt=initialize_suppliers_invoice()["data_id"];
      mosy_sql_rollback("suppliers_invoice", "primkey='$suppliers_invoice_uptoken'", "DELETE");
      drop_suppliers_invoice("primkey='$suppliers_invoice_uptoken' and data_id='$suppliers_invoice_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_suppliers_invoice_);

      }
      }

      //== End suppliers_invoice delete record  
    
       ///SELECT STRING FOR suppliers_invoice============================
              
       if(isset($_POST["qsuppliers_invoice_btn"])){
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "qsuppliers_invoice_btn","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {
            $current_suppliers_invoice_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_suppliers_invoice_current_url=$current_suppliers_invoice_url_params.'?qsuppliers_invoice=';
            if (strpos($current_suppliers_invoice_url_params, '?') !== false) {

                $clean_suppliers_invoice_current_url=$current_suppliers_invoice_url_params.'&qsuppliers_invoice=';

            }
            if (strpos($current_suppliers_invoice_url_params, '?qsuppliers_invoice')) {

                $remove_suppliers_invoice_old_token = substr($current_suppliers_invoice_url_params, 0, strpos($current_suppliers_invoice_url_params, "?qsuppliers_invoice"));

                $clean_suppliers_invoice_current_url=$remove_suppliers_invoice_old_token.'?qsuppliers_invoice=';

            }
            if(strpos($current_suppliers_invoice_url_params, '&qsuppliers_invoice')) {

                $remove_suppliers_invoice_old_token = substr($current_suppliers_invoice_url_params, 0, strpos($current_suppliers_invoice_url_params, "&qsuppliers_invoice"));

                $clean_suppliers_invoice_current_url=$remove_suppliers_invoice_old_token.'&qsuppliers_invoice=';

            }
        $qsuppliers_invoice_str=base64_encode($_POST["txt_suppliers_invoice"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_suppliers_invoice_current_url.($qsuppliers_invoice_str);
            } 

          }else{ 
             header('location:'.$clean_suppliers_invoice_current_url.($qsuppliers_invoice_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_suppliers_invoice_);

        }
        }
        $qsuppliers_invoice="";
		if(isset($_GET["suppliers_invoice_mosyfilter"]) && isset($_GET["qsuppliers_invoice"])){
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "suppliers_invoice_mosyfilter_n_query","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {
         $qsuppliers_invoice=mmres(base64_decode($_GET["qsuppliers_invoice"]));
         
         $gft_suppliers_invoice_where_query="(`data_id` LIKE '%".$qsuppliers_invoice."%' OR  `stock_amount` LIKE '%".$qsuppliers_invoice."%' OR  `supplier_id` LIKE '%".$qsuppliers_invoice."%' OR  `receipt_id` LIKE '%".$qsuppliers_invoice."%' OR  `invoice_no` LIKE '%".$qsuppliers_invoice."%' OR  `stock_data` LIKE '%".$qsuppliers_invoice."%' OR  `amount_paid` LIKE '%".$qsuppliers_invoice."%' OR  `stock_balance` LIKE '%".$qsuppliers_invoice."%' OR  `user_id` LIKE '%".$qsuppliers_invoice."%' OR  `item_id` LIKE '%".$qsuppliers_invoice."%' OR  `purchase_amt` LIKE '%".$qsuppliers_invoice."%')";
         
         if($_GET["suppliers_invoice_mosyfilter"]!=""){
         
         $mosyfilter_suppliers_invoice_queries_str=(base64_decode($_GET["suppliers_invoice_mosyfilter"]));
        
         $gft_suppliers_invoice_where_query="(`data_id` LIKE '%".$qsuppliers_invoice."%' OR  `stock_amount` LIKE '%".$qsuppliers_invoice."%' OR  `supplier_id` LIKE '%".$qsuppliers_invoice."%' OR  `receipt_id` LIKE '%".$qsuppliers_invoice."%' OR  `invoice_no` LIKE '%".$qsuppliers_invoice."%' OR  `stock_data` LIKE '%".$qsuppliers_invoice."%' OR  `amount_paid` LIKE '%".$qsuppliers_invoice."%' OR  `stock_balance` LIKE '%".$qsuppliers_invoice."%' OR  `user_id` LIKE '%".$qsuppliers_invoice."%' OR  `item_id` LIKE '%".$qsuppliers_invoice."%' OR  `purchase_amt` LIKE '%".$qsuppliers_invoice."%') AND ".$mosyfilter_suppliers_invoice_queries_str."";
         
         }
         
		 $gft_suppliers_invoice="WHERE ".$gft_suppliers_invoice_where_query;
         
         $gft_suppliers_invoice_and=$gft_suppliers_invoice_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_suppliers_invoice_);
        }
        }elseif(isset($_GET["qsuppliers_invoice"])){
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "get_qsuppliers_invoice","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {
		 $qsuppliers_invoice=mmres(base64_decode($_GET["qsuppliers_invoice"]));
        
         $gft_suppliers_invoice_where_query="(`data_id` LIKE '%".$qsuppliers_invoice."%' OR  `stock_amount` LIKE '%".$qsuppliers_invoice."%' OR  `supplier_id` LIKE '%".$qsuppliers_invoice."%' OR  `receipt_id` LIKE '%".$qsuppliers_invoice."%' OR  `invoice_no` LIKE '%".$qsuppliers_invoice."%' OR  `stock_data` LIKE '%".$qsuppliers_invoice."%' OR  `amount_paid` LIKE '%".$qsuppliers_invoice."%' OR  `stock_balance` LIKE '%".$qsuppliers_invoice."%' OR  `user_id` LIKE '%".$qsuppliers_invoice."%' OR  `item_id` LIKE '%".$qsuppliers_invoice."%' OR  `purchase_amt` LIKE '%".$qsuppliers_invoice."%')";
         
         $gft_suppliers_invoice="WHERE ".$gft_suppliers_invoice_where_query;
         
         $gft_suppliers_invoice_and=$gft_suppliers_invoice_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_suppliers_invoice_);

        }
        }elseif(isset($_GET["suppliers_invoice_mosyfilter"])){
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "suppliers_invoice_mosyfilter","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {
         $gft_suppliers_invoice_where_query="";
         $gft_suppliers_invoice="";

         if($_GET["suppliers_invoice_mosyfilter"]!=""){
          $gft_suppliers_invoice_where_query=(base64_decode($_GET["suppliers_invoice_mosyfilter"]));
          $gft_suppliers_invoice="WHERE ".$gft_suppliers_invoice_where_query;
         }
         
         
         $gft_suppliers_invoice_and=$gft_suppliers_invoice_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_suppliers_invoice_);

        }
        }else{
         $gft_suppliers_invoice="";
         $gft_suppliers_invoice_and="";
         $gft_suppliers_invoice_where_query="";
        }
       
    //************************************************* END  suppliers_invoice OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section users_tbl
  //************************************************* START  users_tbl OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize users_tbl edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['users_tbl_table_alert']))
              	{	
                  if(isset($users_tbl_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$users_tbl_uptoken="";

		if(isset($_GET["users_tbl_uptoken"]))
		{
		$users_tbl_uptoken=base64_decode($_GET["users_tbl_uptoken"]);
		}
        
        if(isset($_POST["users_tbl_uptoken"]))
		{
		$users_tbl_uptoken=base64_decode($_POST["users_tbl_uptoken"]);
		}
        //
        
          $users_tbl_alias_name="USERS TBL";

          if(isset($users_tbl_alias))
          {
             $users_tbl_alias_name=$users_tbl_alias;

          }
          
        //get single data record query with $users_tbl_uptoken
        
        ///$users_tbl_node=get_users_tbl("*", "WHERE primkey='$users_tbl_uptoken'", "r");
        
	
//************* START INSERT  users_tbl QUERY 
if(isset($_POST["users_tbl_insert_btn"])){
//------- begin users_tbl_arr_ins --> 
$users_tbl_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"user_name"=>"?",
"user_email"=>"?",
"user_mobile"=>"?",
"employee_id"=>"?",
"national_id"=>"?",
"login_name"=>"?",
"role"=>"?",
"login_password"=>"?",
"account_state"=>"?",
"date_signed"=>"?",
"user_pic"=>"?",
"last_seen"=>"?"

);
//===-- End users_tbl_arr_ins -->


          
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "insert","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {

              $users_tbl_validated_ins_str=$users_tbl_arr_ins_;

              if(isset($users_tbl_ins_inputs))
              {
                $users_tbl_validated_ins_str=$users_tbl_ins_inputs;	
              }

              if(empty($users_tbl_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$users_tbl_alias_name." request cannot be empty. Record not added");
              }else{

                $users_tbl_return_key=add_users_tbl($users_tbl_validated_ins_str);
                
                mosy_sql_rollback("users_tbl", "primkey='$users_tbl_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_users_tbl_user_pic']['tmp_name']))
                {
                
                 upload_users_tbl_user_pic('txt_users_tbl_user_pic', "primkey='$users_tbl_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $users_tbl_return_key; 

                      } 

                    }else{ 

                                    
                $users_tbl_custom_redir1=add_url_param ("users_tbl_uptoken", base64_encode($users_tbl_return_key), "");
                $users_tbl_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$users_tbl_custom_redir1);
                $users_tbl_custom_redir3=add_url_param ("users_tbl_table_alert", "users_tbl_added",$users_tbl_custom_redir2);
                
                ///echo magic_message($users_tbl_custom_redir1." -- ".$users_tbl_custom_redir2."--".$users_tbl_custom_redir3);
                
                $users_tbl_custom_redir=$users_tbl_custom_redir3;
                
               header('location:'.$users_tbl_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_users_tbl_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");
         
         }
      
}
//************* END  users_tbl INSERT QUERY 	
	

//************* START users_tbl  UPDATE QUERY 
if(isset($_POST["users_tbl_update_btn"])){
//------- begin users_tbl_arr_updt --> 
$users_tbl_arr_updt_=array(
"user_name"=>"?",
"user_email"=>"?",
"user_mobile"=>"?",
"employee_id"=>"?",
"national_id"=>"?",
"login_name"=>"?",
"role"=>"?",
"login_password"=>"?",
"account_state"=>"?",
"date_signed"=>"?",
"user_pic"=>"?",
"last_seen"=>"?"

);
//===-- End users_tbl_arr_updt -->
                     
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "update","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
         
            $users_tbl_validated_updt_str=$users_tbl_arr_updt_;

            if(isset($users_tbl_updt_inputs))
            {
              $users_tbl_validated_updt_str=$users_tbl_updt_inputs;	
            }

            if(empty($users_tbl_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$users_tbl_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$users_tbl_key_salt=initialize_users_tbl()["user_id"];
            
              update_users_tbl($users_tbl_validated_updt_str, "primkey='$users_tbl_uptoken' and user_id='$users_tbl_key_salt'");
				
         
                if(!empty($_FILES['txt_users_tbl_user_pic']['tmp_name']))
                {
                
                 upload_users_tbl_user_pic('txt_users_tbl_user_pic', "primkey='$users_tbl_uptoken'");
                 
				}

			 mosy_sql_rollback("users_tbl", "primkey='$users_tbl_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $users_tbl_uptoken; 

                    } 

                  }else{ 

                $users_tbl_custom_redir1=add_url_param ("users_tbl_uptoken", base64_encode($users_tbl_uptoken), "");
                $users_tbl_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$users_tbl_custom_redir1);
                $users_tbl_custom_redir3=add_url_param ("users_tbl_table_alert", "users_tbl_updated",$users_tbl_custom_redir2);
                
                ///echo magic_message($users_tbl_custom_redir1." -- ".$users_tbl_custom_redir2."--".$users_tbl_custom_redir3);
                
                $users_tbl_custom_redir=$users_tbl_custom_redir3;
                
               header('location:'.$users_tbl_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_users_tbl_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");
         
         }

      

      
}
//************* END users_tbl  UPDATE QUERY 

    

          //===-====Start upload users_tbl_user_pic 
          if(isset($_POST["btn_upload_users_tbl_user_pic"]))
          {
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "upload_users_tbl_user_pic","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_users_tbl_user_pic']['tmp_name'])){

				upload_users_tbl_user_pic('txt_users_tbl_user_pic', "primkey='$users_tbl_uptoken'");
                
                $users_tbl_custom_redir1=add_url_param ("users_tbl_uptoken", base64_encode($users_tbl_uptoken), "");
                $users_tbl_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$users_tbl_custom_redir1);
                $users_tbl_custom_redir3=add_url_param ("users_tbl_table_alert", "users_tbl_uploaded",$users_tbl_custom_redir2);
                
                ///echo magic_message($users_tbl_custom_redir1." -- ".$users_tbl_custom_redir2."--".$users_tbl_custom_redir3);
                
                $users_tbl_custom_redir=$users_tbl_custom_redir3;
                
               header('location:'.$users_tbl_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_users_tbl_);

          }
          }
          //===-====End upload users_tbl_user_pic  

			//drop users_tbl_user_pic image 
            
          if(isset($_GET["conf_deleteusers_tbl"]))
          {
          	$users_tbl_node=initialize_users_tbl();
          	if($users_tbl_node["user_pic"]!="")
            {
          	 unlink($users_tbl_node["user_pic"]);
            }
          }
          
          
    
      //== Start users_tbl delete record

      if(isset($_GET["deleteusers_tbl"]))
      {
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "super_delete_request","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_users_tbl_btn=magic_button_link("./".$current_file_url."?users_tbl_uptoken=".$_GET["users_tbl_uptoken"]."&conf_deleteusers_tbl&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_users_tbl_btn=magic_button_link("./".$current_file_url."?users_tbl_uptoken=".$_GET["users_tbl_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_users_tbl_btn." ".$cancel_del_users_tbl_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_users_tbl_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteusers_tbl"]))
      {
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "super_delete_confirm","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $users_tbl_del_key_salt=initialize_users_tbl()["user_id"];
      mosy_sql_rollback("users_tbl", "primkey='$users_tbl_uptoken'", "DELETE");
      drop_users_tbl("primkey='$users_tbl_uptoken' and user_id='$users_tbl_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_users_tbl_);

      }
      }

      //== End users_tbl delete record  
    
       ///SELECT STRING FOR users_tbl============================
              
       if(isset($_POST["qusers_tbl_btn"])){
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "qusers_tbl_btn","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
            $current_users_tbl_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_users_tbl_current_url=$current_users_tbl_url_params.'?qusers_tbl=';
            if (strpos($current_users_tbl_url_params, '?') !== false) {

                $clean_users_tbl_current_url=$current_users_tbl_url_params.'&qusers_tbl=';

            }
            if (strpos($current_users_tbl_url_params, '?qusers_tbl')) {

                $remove_users_tbl_old_token = substr($current_users_tbl_url_params, 0, strpos($current_users_tbl_url_params, "?qusers_tbl"));

                $clean_users_tbl_current_url=$remove_users_tbl_old_token.'?qusers_tbl=';

            }
            if(strpos($current_users_tbl_url_params, '&qusers_tbl')) {

                $remove_users_tbl_old_token = substr($current_users_tbl_url_params, 0, strpos($current_users_tbl_url_params, "&qusers_tbl"));

                $clean_users_tbl_current_url=$remove_users_tbl_old_token.'&qusers_tbl=';

            }
        $qusers_tbl_str=base64_encode($_POST["txt_users_tbl"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_users_tbl_current_url.($qusers_tbl_str);
            } 

          }else{ 
             header('location:'.$clean_users_tbl_current_url.($qusers_tbl_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_users_tbl_);

        }
        }
        $qusers_tbl="";
		if(isset($_GET["users_tbl_mosyfilter"]) && isset($_GET["qusers_tbl"])){
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "users_tbl_mosyfilter_n_query","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
         $qusers_tbl=mmres(base64_decode($_GET["qusers_tbl"]));
         
         $gft_users_tbl_where_query="(`user_id` LIKE '%".$qusers_tbl."%' OR  `user_name` LIKE '%".$qusers_tbl."%' OR  `user_email` LIKE '%".$qusers_tbl."%' OR  `user_mobile` LIKE '%".$qusers_tbl."%' OR  `employee_id` LIKE '%".$qusers_tbl."%' OR  `national_id` LIKE '%".$qusers_tbl."%' OR  `login_name` LIKE '%".$qusers_tbl."%' OR  `role` LIKE '%".$qusers_tbl."%' OR  `login_password` LIKE '%".$qusers_tbl."%' OR  `account_state` LIKE '%".$qusers_tbl."%' OR  `date_signed` LIKE '%".$qusers_tbl."%' OR  `user_pic` LIKE '%".$qusers_tbl."%' OR  `last_seen` LIKE '%".$qusers_tbl."%')";
         
         if($_GET["users_tbl_mosyfilter"]!=""){
         
         $mosyfilter_users_tbl_queries_str=(base64_decode($_GET["users_tbl_mosyfilter"]));
        
         $gft_users_tbl_where_query="(`user_id` LIKE '%".$qusers_tbl."%' OR  `user_name` LIKE '%".$qusers_tbl."%' OR  `user_email` LIKE '%".$qusers_tbl."%' OR  `user_mobile` LIKE '%".$qusers_tbl."%' OR  `employee_id` LIKE '%".$qusers_tbl."%' OR  `national_id` LIKE '%".$qusers_tbl."%' OR  `login_name` LIKE '%".$qusers_tbl."%' OR  `role` LIKE '%".$qusers_tbl."%' OR  `login_password` LIKE '%".$qusers_tbl."%' OR  `account_state` LIKE '%".$qusers_tbl."%' OR  `date_signed` LIKE '%".$qusers_tbl."%' OR  `user_pic` LIKE '%".$qusers_tbl."%' OR  `last_seen` LIKE '%".$qusers_tbl."%') AND ".$mosyfilter_users_tbl_queries_str."";
         
         }
         
		 $gft_users_tbl="WHERE ".$gft_users_tbl_where_query;
         
         $gft_users_tbl_and=$gft_users_tbl_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_users_tbl_);
        }
        }elseif(isset($_GET["qusers_tbl"])){
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "get_qusers_tbl","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
		 $qusers_tbl=mmres(base64_decode($_GET["qusers_tbl"]));
        
         $gft_users_tbl_where_query="(`user_id` LIKE '%".$qusers_tbl."%' OR  `user_name` LIKE '%".$qusers_tbl."%' OR  `user_email` LIKE '%".$qusers_tbl."%' OR  `user_mobile` LIKE '%".$qusers_tbl."%' OR  `employee_id` LIKE '%".$qusers_tbl."%' OR  `national_id` LIKE '%".$qusers_tbl."%' OR  `login_name` LIKE '%".$qusers_tbl."%' OR  `role` LIKE '%".$qusers_tbl."%' OR  `login_password` LIKE '%".$qusers_tbl."%' OR  `account_state` LIKE '%".$qusers_tbl."%' OR  `date_signed` LIKE '%".$qusers_tbl."%' OR  `user_pic` LIKE '%".$qusers_tbl."%' OR  `last_seen` LIKE '%".$qusers_tbl."%')";
         
         $gft_users_tbl="WHERE ".$gft_users_tbl_where_query;
         
         $gft_users_tbl_and=$gft_users_tbl_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_users_tbl_);

        }
        }elseif(isset($_GET["users_tbl_mosyfilter"])){
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "users_tbl_mosyfilter","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
         $gft_users_tbl_where_query="";
         $gft_users_tbl="";

         if($_GET["users_tbl_mosyfilter"]!=""){
          $gft_users_tbl_where_query=(base64_decode($_GET["users_tbl_mosyfilter"]));
          $gft_users_tbl="WHERE ".$gft_users_tbl_where_query;
         }
         
         
         $gft_users_tbl_and=$gft_users_tbl_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_users_tbl_);

        }
        }else{
         $gft_users_tbl="";
         $gft_users_tbl_and="";
         $gft_users_tbl_where_query="";
        }
       
    //************************************************* END  users_tbl OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  

//<--ncgh-->

?>