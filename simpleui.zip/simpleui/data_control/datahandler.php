<?php 
//===============Start Mosy queries-============ 

    
 	//Start Add config Data ===============
 	function add_config($config_arr_)
    {
     $gw_config_cols=array();
     
     foreach($config_arr_ as $config_arr_gw => $config_arr_gw_val)
     {
     
     	$gw_config_cols[]=$config_arr_gw;
        
     }
     
     $gw_config_cols_str=implode(",", $gw_config_cols);
     
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "insert",$gw_config_cols_str);
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("config", $config_arr_);
     
     	//echo $gwauthenticate_config_;

     }else{
     
     	echo $gwauthenticate_config_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");

     }
     
    }
    
       function initialize_config()
        {
        
         global $config_uptoken;
             
         $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "select","");

         $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
         	
          //echo $gwauthenticate_config_;

         if($gwauthenticate_config_json["response"]=="ok")
         {
         
         	return get_config("*", "WHERE primkey='$config_uptoken'", "r");
         
            echo $gwauthenticate_config_;

         }else{

         	echo $gwauthenticate_config_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");
         
         }
        }   
    //End Add config Data ===============
                
    //Start Update config Data ===============
    
 	function update_config($config_arr_, $where_str)
    {
         $gw_config_cols=array();
     
     foreach($config_arr_ as $config_arr_gw => $config_arr_gw_val)
     {
     
     	$gw_config_cols[]=$config_arr_gw;
        
     }
     
     $gw_config_cols_str=implode(",", $gw_config_cols);
     
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "update",$gw_config_cols_str);
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("config", $config_arr_, $where_str);

       // echo $gwauthenticate_config_;
        
        exit;

     }else{

        echo $gwauthenticate_config_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");


      }
    
    }
 	
    
    //End Update config Data ===============

    //Start get  config Data ===============
    
    function get_config($colstr, $where_str, $type)
    {
          
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "select","");
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {
    	return mosyflex_sel("config", $colstr, $where_str, $type);

        //echo $gwauthenticate_config_;

	  }else{
     
     	echo $gwauthenticate_config_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");


     }    
    }
    //End get  config Data ===============
    
    
    //======== qconfig_data qsingle query function
    
    function qconfig_data($qsignature_key)
    {
          
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "qdata","");
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {    
    	return get_config("*", "WHERE signature='$qsignature_key'", "r");

		//echo $gwauthenticate_config_;

      }else{
     
     	echo $gwauthenticate_config_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");


     }  
    }
   
    //======== qconfig_data qsingle query function
    
    
     //======== config data to array
    
    function config_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "data_array","");
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {  
     	$append_config_arr=array();
    
    	$array_config_q=get_config($colstr, $where_str, "l");
        while($array_config_res=mysqli_fetch_array($array_config_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_config_arr[]=$array_config_res[$tbl_col];
            }
          }else{
          	          
               $append_config_arr[]=$array_config_res;

          }
        }
        
        return $append_config_arr;

		//echo $gwauthenticate_config_;

      }else{
     
     	echo $gwauthenticate_config_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");


     }  
    }
   
    //======== qconfig_data qsingle query function   
        
    //======== qconfig_ddata qsingle query function    
    function qconfig_ddata($signature_col, $qsignature_key)
    {
     
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "qddata","");
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {    
    	return get_config("*", "WHERE $signature_col='$qsignature_key'", "r");

		//echo $gwauthenticate_config_;

     }else{
     
     	echo $gwauthenticate_config_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");


     }   
    }
    //======== qconfig_ddata qsingle query function

    //======== count config data function
    
    function count_config($config_wherestr)
    {
     
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "count_data","");
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {    
      $clean_config_where_str="";
  
      if($config_wherestr!='')
      {
        $clean_config_where_str="Where ".$config_wherestr;
      }

      return get_config("count(*) as return_result", " ".$clean_config_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_config_;

      }else{
     
     	echo $gwauthenticate_config_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");


     }    
    }
    //======== count config data function

    //======== sum  config data function
    
    function sum_config($config_sumcol, $config_wherestr)
    {
     
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "sum_data","");
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {    
      $clean_config_where_str="";
  
      if($config_wherestr!='')
      {
        $clean_config_where_str="Where ".$config_wherestr;
      }

      return get_config("sum($config_sumcol) as return_result", " ".$clean_config_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_config_;


      }else{
     
     	echo $gwauthenticate_config_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");
        


     }    
    }
    
    //======== sum  config data function   
    
    
    //Start drop  config Data ===============
    
    function drop_config($where_str)
    {
     
     $gwauthenticate_config_=gw_oauth("table", magic_current_url(), "config", "drop_data","");
     
     $gwauthenticate_config_json=json_decode($gwauthenticate_config_, true);
     
     if($gwauthenticate_config_json["response"]=="ok")
     {    
    	return magic_sql_delete("config", $where_str);

		//echo $gwauthenticate_config_;

      }else{
     
     	echo $gwauthenticate_config_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_config_)."");
		

     }
    }
    //End drop  config Data ===============    
    
    
   

    
 	//Start Add customers Data ===============
 	function add_customers($customers_arr_)
    {
     $gw_customers_cols=array();
     
     foreach($customers_arr_ as $customers_arr_gw => $customers_arr_gw_val)
     {
     
     	$gw_customers_cols[]=$customers_arr_gw;
        
     }
     
     $gw_customers_cols_str=implode(",", $gw_customers_cols);
     
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "insert",$gw_customers_cols_str);
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("customers", $customers_arr_);
     
     	//echo $gwauthenticate_customers_;

     }else{
     
     	echo $gwauthenticate_customers_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");

     }
     
    }
    
       function initialize_customers()
        {
        
         global $customers_uptoken;
             
         $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "select","");

         $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
         	
          //echo $gwauthenticate_customers_;

         if($gwauthenticate_customers_json["response"]=="ok")
         {
         
         	return get_customers("*", "WHERE primkey='$customers_uptoken'", "r");
         
            echo $gwauthenticate_customers_;

         }else{

         	echo $gwauthenticate_customers_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");
         
         }
        }   
    //End Add customers Data ===============
                
    //Start Update customers Data ===============
    
 	function update_customers($customers_arr_, $where_str)
    {
         $gw_customers_cols=array();
     
     foreach($customers_arr_ as $customers_arr_gw => $customers_arr_gw_val)
     {
     
     	$gw_customers_cols[]=$customers_arr_gw;
        
     }
     
     $gw_customers_cols_str=implode(",", $gw_customers_cols);
     
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "update",$gw_customers_cols_str);
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("customers", $customers_arr_, $where_str);

       // echo $gwauthenticate_customers_;
        
        exit;

     }else{

        echo $gwauthenticate_customers_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");


      }
    
    }
 	
    
    //End Update customers Data ===============

    //Start get  customers Data ===============
    
    function get_customers($colstr, $where_str, $type)
    {
          
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "select","");
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {
    	return mosyflex_sel("customers", $colstr, $where_str, $type);

        //echo $gwauthenticate_customers_;

	  }else{
     
     	echo $gwauthenticate_customers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");


     }    
    }
    //End get  customers Data ===============
    
    
    //======== qcustomers_data qsingle query function
    
    function qcustomers_data($qcustomer_id_key)
    {
          
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "qdata","");
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {    
    	return get_customers("*", "WHERE customer_id='$qcustomer_id_key'", "r");

		//echo $gwauthenticate_customers_;

      }else{
     
     	echo $gwauthenticate_customers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");


     }  
    }
   
    //======== qcustomers_data qsingle query function
    
    
     //======== customers data to array
    
    function customers_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "data_array","");
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {  
     	$append_customers_arr=array();
    
    	$array_customers_q=get_customers($colstr, $where_str, "l");
        while($array_customers_res=mysqli_fetch_array($array_customers_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_customers_arr[]=$array_customers_res[$tbl_col];
            }
          }else{
          	          
               $append_customers_arr[]=$array_customers_res;

          }
        }
        
        return $append_customers_arr;

		//echo $gwauthenticate_customers_;

      }else{
     
     	echo $gwauthenticate_customers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");


     }  
    }
   
    //======== qcustomers_data qsingle query function   
        
    //======== qcustomers_ddata qsingle query function    
    function qcustomers_ddata($customer_id_col, $qcustomer_id_key)
    {
     
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "qddata","");
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {    
    	return get_customers("*", "WHERE $customer_id_col='$qcustomer_id_key'", "r");

		//echo $gwauthenticate_customers_;

     }else{
     
     	echo $gwauthenticate_customers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");


     }   
    }
    //======== qcustomers_ddata qsingle query function

    //======== count customers data function
    
    function count_customers($customers_wherestr)
    {
     
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "count_data","");
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {    
      $clean_customers_where_str="";
  
      if($customers_wherestr!='')
      {
        $clean_customers_where_str="Where ".$customers_wherestr;
      }

      return get_customers("count(*) as return_result", " ".$clean_customers_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_customers_;

      }else{
     
     	echo $gwauthenticate_customers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");


     }    
    }
    //======== count customers data function

    //======== sum  customers data function
    
    function sum_customers($customers_sumcol, $customers_wherestr)
    {
     
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "sum_data","");
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {    
      $clean_customers_where_str="";
  
      if($customers_wherestr!='')
      {
        $clean_customers_where_str="Where ".$customers_wherestr;
      }

      return get_customers("sum($customers_sumcol) as return_result", " ".$clean_customers_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_customers_;


      }else{
     
     	echo $gwauthenticate_customers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");
        


     }    
    }
    
    //======== sum  customers data function   
    
    
    //Start drop  customers Data ===============
    
    function drop_customers($where_str)
    {
     
     $gwauthenticate_customers_=gw_oauth("table", magic_current_url(), "customers", "drop_data","");
     
     $gwauthenticate_customers_json=json_decode($gwauthenticate_customers_, true);
     
     if($gwauthenticate_customers_json["response"]=="ok")
     {    
    	return magic_sql_delete("customers", $where_str);

		//echo $gwauthenticate_customers_;

      }else{
     
     	echo $gwauthenticate_customers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_customers_)."");
		

     }
    }
    //End drop  customers Data ===============    
    
    
            //Start Upload customers_user_pic Function 
            function upload_customers_user_pic($txt_customers_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_customers_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/customers_user_pic')) @mkdir('./img/customers_user_pic');

                $cur_item_photos=magic_upload_file('./img/customers_user_pic/', $txt_customers_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $customers_node=get_customers("*", "WHERE ".$where_str."", "r");

                  if (file_exists($customers_node["user_pic"]))
                  {

                      unlink($customers_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('customers', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload customers_user_pic Function 

            
   

    
 	//Start Add daily_sales Data ===============
 	function add_daily_sales($daily_sales_arr_)
    {
     $gw_daily_sales_cols=array();
     
     foreach($daily_sales_arr_ as $daily_sales_arr_gw => $daily_sales_arr_gw_val)
     {
     
     	$gw_daily_sales_cols[]=$daily_sales_arr_gw;
        
     }
     
     $gw_daily_sales_cols_str=implode(",", $gw_daily_sales_cols);
     
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "insert",$gw_daily_sales_cols_str);
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("daily_sales", $daily_sales_arr_);
     
     	//echo $gwauthenticate_daily_sales_;

     }else{
     
     	echo $gwauthenticate_daily_sales_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");

     }
     
    }
    
       function initialize_daily_sales()
        {
        
         global $daily_sales_uptoken;
             
         $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "select","");

         $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
         	
          //echo $gwauthenticate_daily_sales_;

         if($gwauthenticate_daily_sales_json["response"]=="ok")
         {
         
         	return get_daily_sales("*", "WHERE primkey='$daily_sales_uptoken'", "r");
         
            echo $gwauthenticate_daily_sales_;

         }else{

         	echo $gwauthenticate_daily_sales_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");
         
         }
        }   
    //End Add daily_sales Data ===============
                
    //Start Update daily_sales Data ===============
    
 	function update_daily_sales($daily_sales_arr_, $where_str)
    {
         $gw_daily_sales_cols=array();
     
     foreach($daily_sales_arr_ as $daily_sales_arr_gw => $daily_sales_arr_gw_val)
     {
     
     	$gw_daily_sales_cols[]=$daily_sales_arr_gw;
        
     }
     
     $gw_daily_sales_cols_str=implode(",", $gw_daily_sales_cols);
     
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "update",$gw_daily_sales_cols_str);
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("daily_sales", $daily_sales_arr_, $where_str);

       // echo $gwauthenticate_daily_sales_;
        
        exit;

     }else{

        echo $gwauthenticate_daily_sales_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");


      }
    
    }
 	
    
    //End Update daily_sales Data ===============

    //Start get  daily_sales Data ===============
    
    function get_daily_sales($colstr, $where_str, $type)
    {
          
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "select","");
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {
    	return mosyflex_sel("daily_sales", $colstr, $where_str, $type);

        //echo $gwauthenticate_daily_sales_;

	  }else{
     
     	echo $gwauthenticate_daily_sales_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");


     }    
    }
    //End get  daily_sales Data ===============
    
    
    //======== qdaily_sales_data qsingle query function
    
    function qdaily_sales_data($qsale_id_key)
    {
          
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "qdata","");
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {    
    	return get_daily_sales("*", "WHERE sale_id='$qsale_id_key'", "r");

		//echo $gwauthenticate_daily_sales_;

      }else{
     
     	echo $gwauthenticate_daily_sales_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");


     }  
    }
   
    //======== qdaily_sales_data qsingle query function
    
    
     //======== daily_sales data to array
    
    function daily_sales_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "data_array","");
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {  
     	$append_daily_sales_arr=array();
    
    	$array_daily_sales_q=get_daily_sales($colstr, $where_str, "l");
        while($array_daily_sales_res=mysqli_fetch_array($array_daily_sales_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_daily_sales_arr[]=$array_daily_sales_res[$tbl_col];
            }
          }else{
          	          
               $append_daily_sales_arr[]=$array_daily_sales_res;

          }
        }
        
        return $append_daily_sales_arr;

		//echo $gwauthenticate_daily_sales_;

      }else{
     
     	echo $gwauthenticate_daily_sales_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");


     }  
    }
   
    //======== qdaily_sales_data qsingle query function   
        
    //======== qdaily_sales_ddata qsingle query function    
    function qdaily_sales_ddata($sale_id_col, $qsale_id_key)
    {
     
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "qddata","");
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {    
    	return get_daily_sales("*", "WHERE $sale_id_col='$qsale_id_key'", "r");

		//echo $gwauthenticate_daily_sales_;

     }else{
     
     	echo $gwauthenticate_daily_sales_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");


     }   
    }
    //======== qdaily_sales_ddata qsingle query function

    //======== count daily_sales data function
    
    function count_daily_sales($daily_sales_wherestr)
    {
     
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "count_data","");
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {    
      $clean_daily_sales_where_str="";
  
      if($daily_sales_wherestr!='')
      {
        $clean_daily_sales_where_str="Where ".$daily_sales_wherestr;
      }

      return get_daily_sales("count(*) as return_result", " ".$clean_daily_sales_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_daily_sales_;

      }else{
     
     	echo $gwauthenticate_daily_sales_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");


     }    
    }
    //======== count daily_sales data function

    //======== sum  daily_sales data function
    
    function sum_daily_sales($daily_sales_sumcol, $daily_sales_wherestr)
    {
     
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "sum_data","");
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {    
      $clean_daily_sales_where_str="";
  
      if($daily_sales_wherestr!='')
      {
        $clean_daily_sales_where_str="Where ".$daily_sales_wherestr;
      }

      return get_daily_sales("sum($daily_sales_sumcol) as return_result", " ".$clean_daily_sales_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_daily_sales_;


      }else{
     
     	echo $gwauthenticate_daily_sales_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");
        


     }    
    }
    
    //======== sum  daily_sales data function   
    
    
    //Start drop  daily_sales Data ===============
    
    function drop_daily_sales($where_str)
    {
     
     $gwauthenticate_daily_sales_=gw_oauth("table", magic_current_url(), "daily_sales", "drop_data","");
     
     $gwauthenticate_daily_sales_json=json_decode($gwauthenticate_daily_sales_, true);
     
     if($gwauthenticate_daily_sales_json["response"]=="ok")
     {    
    	return magic_sql_delete("daily_sales", $where_str);

		//echo $gwauthenticate_daily_sales_;

      }else{
     
     	echo $gwauthenticate_daily_sales_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_daily_sales_)."");
		

     }
    }
    //End drop  daily_sales Data ===============    
    
    
   

    
 	//Start Add expenses_list Data ===============
 	function add_expenses_list($expenses_list_arr_)
    {
     $gw_expenses_list_cols=array();
     
     foreach($expenses_list_arr_ as $expenses_list_arr_gw => $expenses_list_arr_gw_val)
     {
     
     	$gw_expenses_list_cols[]=$expenses_list_arr_gw;
        
     }
     
     $gw_expenses_list_cols_str=implode(",", $gw_expenses_list_cols);
     
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "insert",$gw_expenses_list_cols_str);
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("expenses_list", $expenses_list_arr_);
     
     	//echo $gwauthenticate_expenses_list_;

     }else{
     
     	echo $gwauthenticate_expenses_list_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");

     }
     
    }
    
       function initialize_expenses_list()
        {
        
         global $expenses_list_uptoken;
             
         $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "select","");

         $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
         	
          //echo $gwauthenticate_expenses_list_;

         if($gwauthenticate_expenses_list_json["response"]=="ok")
         {
         
         	return get_expenses_list("*", "WHERE primkey='$expenses_list_uptoken'", "r");
         
            echo $gwauthenticate_expenses_list_;

         }else{

         	echo $gwauthenticate_expenses_list_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");
         
         }
        }   
    //End Add expenses_list Data ===============
                
    //Start Update expenses_list Data ===============
    
 	function update_expenses_list($expenses_list_arr_, $where_str)
    {
         $gw_expenses_list_cols=array();
     
     foreach($expenses_list_arr_ as $expenses_list_arr_gw => $expenses_list_arr_gw_val)
     {
     
     	$gw_expenses_list_cols[]=$expenses_list_arr_gw;
        
     }
     
     $gw_expenses_list_cols_str=implode(",", $gw_expenses_list_cols);
     
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "update",$gw_expenses_list_cols_str);
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("expenses_list", $expenses_list_arr_, $where_str);

       // echo $gwauthenticate_expenses_list_;
        
        exit;

     }else{

        echo $gwauthenticate_expenses_list_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");


      }
    
    }
 	
    
    //End Update expenses_list Data ===============

    //Start get  expenses_list Data ===============
    
    function get_expenses_list($colstr, $where_str, $type)
    {
          
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "select","");
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {
    	return mosyflex_sel("expenses_list", $colstr, $where_str, $type);

        //echo $gwauthenticate_expenses_list_;

	  }else{
     
     	echo $gwauthenticate_expenses_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");


     }    
    }
    //End get  expenses_list Data ===============
    
    
    //======== qexpenses_list_data qsingle query function
    
    function qexpenses_list_data($qexpense_key_key)
    {
          
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "qdata","");
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {    
    	return get_expenses_list("*", "WHERE expense_key='$qexpense_key_key'", "r");

		//echo $gwauthenticate_expenses_list_;

      }else{
     
     	echo $gwauthenticate_expenses_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");


     }  
    }
   
    //======== qexpenses_list_data qsingle query function
    
    
     //======== expenses_list data to array
    
    function expenses_list_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "data_array","");
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {  
     	$append_expenses_list_arr=array();
    
    	$array_expenses_list_q=get_expenses_list($colstr, $where_str, "l");
        while($array_expenses_list_res=mysqli_fetch_array($array_expenses_list_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_expenses_list_arr[]=$array_expenses_list_res[$tbl_col];
            }
          }else{
          	          
               $append_expenses_list_arr[]=$array_expenses_list_res;

          }
        }
        
        return $append_expenses_list_arr;

		//echo $gwauthenticate_expenses_list_;

      }else{
     
     	echo $gwauthenticate_expenses_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");


     }  
    }
   
    //======== qexpenses_list_data qsingle query function   
        
    //======== qexpenses_list_ddata qsingle query function    
    function qexpenses_list_ddata($expense_key_col, $qexpense_key_key)
    {
     
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "qddata","");
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {    
    	return get_expenses_list("*", "WHERE $expense_key_col='$qexpense_key_key'", "r");

		//echo $gwauthenticate_expenses_list_;

     }else{
     
     	echo $gwauthenticate_expenses_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");


     }   
    }
    //======== qexpenses_list_ddata qsingle query function

    //======== count expenses_list data function
    
    function count_expenses_list($expenses_list_wherestr)
    {
     
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "count_data","");
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {    
      $clean_expenses_list_where_str="";
  
      if($expenses_list_wherestr!='')
      {
        $clean_expenses_list_where_str="Where ".$expenses_list_wherestr;
      }

      return get_expenses_list("count(*) as return_result", " ".$clean_expenses_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_expenses_list_;

      }else{
     
     	echo $gwauthenticate_expenses_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");


     }    
    }
    //======== count expenses_list data function

    //======== sum  expenses_list data function
    
    function sum_expenses_list($expenses_list_sumcol, $expenses_list_wherestr)
    {
     
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "sum_data","");
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {    
      $clean_expenses_list_where_str="";
  
      if($expenses_list_wherestr!='')
      {
        $clean_expenses_list_where_str="Where ".$expenses_list_wherestr;
      }

      return get_expenses_list("sum($expenses_list_sumcol) as return_result", " ".$clean_expenses_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_expenses_list_;


      }else{
     
     	echo $gwauthenticate_expenses_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");
        


     }    
    }
    
    //======== sum  expenses_list data function   
    
    
    //Start drop  expenses_list Data ===============
    
    function drop_expenses_list($where_str)
    {
     
     $gwauthenticate_expenses_list_=gw_oauth("table", magic_current_url(), "expenses_list", "drop_data","");
     
     $gwauthenticate_expenses_list_json=json_decode($gwauthenticate_expenses_list_, true);
     
     if($gwauthenticate_expenses_list_json["response"]=="ok")
     {    
    	return magic_sql_delete("expenses_list", $where_str);

		//echo $gwauthenticate_expenses_list_;

      }else{
     
     	echo $gwauthenticate_expenses_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expenses_list_)."");
		

     }
    }
    //End drop  expenses_list Data ===============    
    
    
   

    
 	//Start Add mosy_sql_roll_back Data ===============
 	function add_mosy_sql_roll_back($mosy_sql_roll_back_arr_)
    {
     $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("mosy_sql_roll_back", $mosy_sql_roll_back_arr_);
     
     	//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

     }
     
    }
    
       function initialize_mosy_sql_roll_back()
        {
        
         global $mosy_sql_roll_back_uptoken;
             
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
         	return get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
         
            echo $gwauthenticate_mosy_sql_roll_back_;

         }else{

         	echo $gwauthenticate_mosy_sql_roll_back_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
        }   
    //End Add mosy_sql_roll_back Data ===============
                
    //Start Update mosy_sql_roll_back Data ===============
    
 	function update_mosy_sql_roll_back($mosy_sql_roll_back_arr_, $where_str)
    {
         $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("mosy_sql_roll_back", $mosy_sql_roll_back_arr_, $where_str);

       // echo $gwauthenticate_mosy_sql_roll_back_;
        
        exit;

     }else{

        echo $gwauthenticate_mosy_sql_roll_back_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


      }
    
    }
 	
    
    //End Update mosy_sql_roll_back Data ===============

    //Start get  mosy_sql_roll_back Data ===============
    
    function get_mosy_sql_roll_back($colstr, $where_str, $type)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
    	return mosyflex_sel("mosy_sql_roll_back", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosy_sql_roll_back_;

	  }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //End get  mosy_sql_roll_back Data ===============
    
    
    //======== qmosy_sql_roll_back_data qsingle query function
    
    function qmosy_sql_roll_back_data($qroll_bk_key_key)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qdata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE roll_bk_key='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function
    
    
     //======== mosy_sql_roll_back data to array
    
    function mosy_sql_roll_back_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "data_array","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {  
     	$append_mosy_sql_roll_back_arr=array();
    
    	$array_mosy_sql_roll_back_q=get_mosy_sql_roll_back($colstr, $where_str, "l");
        while($array_mosy_sql_roll_back_res=mysqli_fetch_array($array_mosy_sql_roll_back_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res[$tbl_col];
            }
          }else{
          	          
               $append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res;

          }
        }
        
        return $append_mosy_sql_roll_back_arr;

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function   
        
    //======== qmosy_sql_roll_back_ddata qsingle query function    
    function qmosy_sql_roll_back_ddata($roll_bk_key_col, $qroll_bk_key_key)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE $roll_bk_key_col='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }
    //======== qmosy_sql_roll_back_ddata qsingle query function

    //======== count mosy_sql_roll_back data function
    
    function count_mosy_sql_roll_back($mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "count_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("count(*) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //======== count mosy_sql_roll_back data function

    //======== sum  mosy_sql_roll_back data function
    
    function sum_mosy_sql_roll_back($mosy_sql_roll_back_sumcol, $mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "sum_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("sum($mosy_sql_roll_back_sumcol) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;


      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
        


     }    
    }
    
    //======== sum  mosy_sql_roll_back data function   
    
    
    //Start drop  mosy_sql_roll_back Data ===============
    
    function drop_mosy_sql_roll_back($where_str)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "drop_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return magic_sql_delete("mosy_sql_roll_back", $where_str);

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
		

     }
    }
    //End drop  mosy_sql_roll_back Data ===============    
    
    
   

    
 	//Start Add receipt_nos Data ===============
 	function add_receipt_nos($receipt_nos_arr_)
    {
     $gw_receipt_nos_cols=array();
     
     foreach($receipt_nos_arr_ as $receipt_nos_arr_gw => $receipt_nos_arr_gw_val)
     {
     
     	$gw_receipt_nos_cols[]=$receipt_nos_arr_gw;
        
     }
     
     $gw_receipt_nos_cols_str=implode(",", $gw_receipt_nos_cols);
     
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "insert",$gw_receipt_nos_cols_str);
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("receipt_nos", $receipt_nos_arr_);
     
     	//echo $gwauthenticate_receipt_nos_;

     }else{
     
     	echo $gwauthenticate_receipt_nos_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");

     }
     
    }
    
       function initialize_receipt_nos()
        {
        
         global $receipt_nos_uptoken;
             
         $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "select","");

         $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
         	
          //echo $gwauthenticate_receipt_nos_;

         if($gwauthenticate_receipt_nos_json["response"]=="ok")
         {
         
         	return get_receipt_nos("*", "WHERE primkey='$receipt_nos_uptoken'", "r");
         
            echo $gwauthenticate_receipt_nos_;

         }else{

         	echo $gwauthenticate_receipt_nos_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");
         
         }
        }   
    //End Add receipt_nos Data ===============
                
    //Start Update receipt_nos Data ===============
    
 	function update_receipt_nos($receipt_nos_arr_, $where_str)
    {
         $gw_receipt_nos_cols=array();
     
     foreach($receipt_nos_arr_ as $receipt_nos_arr_gw => $receipt_nos_arr_gw_val)
     {
     
     	$gw_receipt_nos_cols[]=$receipt_nos_arr_gw;
        
     }
     
     $gw_receipt_nos_cols_str=implode(",", $gw_receipt_nos_cols);
     
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "update",$gw_receipt_nos_cols_str);
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("receipt_nos", $receipt_nos_arr_, $where_str);

       // echo $gwauthenticate_receipt_nos_;
        
        exit;

     }else{

        echo $gwauthenticate_receipt_nos_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");


      }
    
    }
 	
    
    //End Update receipt_nos Data ===============

    //Start get  receipt_nos Data ===============
    
    function get_receipt_nos($colstr, $where_str, $type)
    {
          
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "select","");
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {
    	return mosyflex_sel("receipt_nos", $colstr, $where_str, $type);

        //echo $gwauthenticate_receipt_nos_;

	  }else{
     
     	echo $gwauthenticate_receipt_nos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");


     }    
    }
    //End get  receipt_nos Data ===============
    
    
    //======== qreceipt_nos_data qsingle query function
    
    function qreceipt_nos_data($qsales_date_key)
    {
          
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "qdata","");
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {    
    	return get_receipt_nos("*", "WHERE sales_date='$qsales_date_key'", "r");

		//echo $gwauthenticate_receipt_nos_;

      }else{
     
     	echo $gwauthenticate_receipt_nos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");


     }  
    }
   
    //======== qreceipt_nos_data qsingle query function
    
    
     //======== receipt_nos data to array
    
    function receipt_nos_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "data_array","");
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {  
     	$append_receipt_nos_arr=array();
    
    	$array_receipt_nos_q=get_receipt_nos($colstr, $where_str, "l");
        while($array_receipt_nos_res=mysqli_fetch_array($array_receipt_nos_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_receipt_nos_arr[]=$array_receipt_nos_res[$tbl_col];
            }
          }else{
          	          
               $append_receipt_nos_arr[]=$array_receipt_nos_res;

          }
        }
        
        return $append_receipt_nos_arr;

		//echo $gwauthenticate_receipt_nos_;

      }else{
     
     	echo $gwauthenticate_receipt_nos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");


     }  
    }
   
    //======== qreceipt_nos_data qsingle query function   
        
    //======== qreceipt_nos_ddata qsingle query function    
    function qreceipt_nos_ddata($sales_date_col, $qsales_date_key)
    {
     
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "qddata","");
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {    
    	return get_receipt_nos("*", "WHERE $sales_date_col='$qsales_date_key'", "r");

		//echo $gwauthenticate_receipt_nos_;

     }else{
     
     	echo $gwauthenticate_receipt_nos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");


     }   
    }
    //======== qreceipt_nos_ddata qsingle query function

    //======== count receipt_nos data function
    
    function count_receipt_nos($receipt_nos_wherestr)
    {
     
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "count_data","");
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {    
      $clean_receipt_nos_where_str="";
  
      if($receipt_nos_wherestr!='')
      {
        $clean_receipt_nos_where_str="Where ".$receipt_nos_wherestr;
      }

      return get_receipt_nos("count(*) as return_result", " ".$clean_receipt_nos_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_receipt_nos_;

      }else{
     
     	echo $gwauthenticate_receipt_nos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");


     }    
    }
    //======== count receipt_nos data function

    //======== sum  receipt_nos data function
    
    function sum_receipt_nos($receipt_nos_sumcol, $receipt_nos_wherestr)
    {
     
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "sum_data","");
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {    
      $clean_receipt_nos_where_str="";
  
      if($receipt_nos_wherestr!='')
      {
        $clean_receipt_nos_where_str="Where ".$receipt_nos_wherestr;
      }

      return get_receipt_nos("sum($receipt_nos_sumcol) as return_result", " ".$clean_receipt_nos_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_receipt_nos_;


      }else{
     
     	echo $gwauthenticate_receipt_nos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");
        


     }    
    }
    
    //======== sum  receipt_nos data function   
    
    
    //Start drop  receipt_nos Data ===============
    
    function drop_receipt_nos($where_str)
    {
     
     $gwauthenticate_receipt_nos_=gw_oauth("table", magic_current_url(), "receipt_nos", "drop_data","");
     
     $gwauthenticate_receipt_nos_json=json_decode($gwauthenticate_receipt_nos_, true);
     
     if($gwauthenticate_receipt_nos_json["response"]=="ok")
     {    
    	return magic_sql_delete("receipt_nos", $where_str);

		//echo $gwauthenticate_receipt_nos_;

      }else{
     
     	echo $gwauthenticate_receipt_nos_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_receipt_nos_)."");
		

     }
    }
    //End drop  receipt_nos Data ===============    
    
    
   

    
 	//Start Add stock_history Data ===============
 	function add_stock_history($stock_history_arr_)
    {
     $gw_stock_history_cols=array();
     
     foreach($stock_history_arr_ as $stock_history_arr_gw => $stock_history_arr_gw_val)
     {
     
     	$gw_stock_history_cols[]=$stock_history_arr_gw;
        
     }
     
     $gw_stock_history_cols_str=implode(",", $gw_stock_history_cols);
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "insert",$gw_stock_history_cols_str);
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("stock_history", $stock_history_arr_);
     
     	//echo $gwauthenticate_stock_history_;

     }else{
     
     	echo $gwauthenticate_stock_history_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");

     }
     
    }
    
       function initialize_stock_history()
        {
        
         global $stock_history_uptoken;
             
         $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "select","");

         $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
         	
          //echo $gwauthenticate_stock_history_;

         if($gwauthenticate_stock_history_json["response"]=="ok")
         {
         
         	return get_stock_history("*", "WHERE primkey='$stock_history_uptoken'", "r");
         
            echo $gwauthenticate_stock_history_;

         }else{

         	echo $gwauthenticate_stock_history_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
         
         }
        }   
    //End Add stock_history Data ===============
                
    //Start Update stock_history Data ===============
    
 	function update_stock_history($stock_history_arr_, $where_str)
    {
         $gw_stock_history_cols=array();
     
     foreach($stock_history_arr_ as $stock_history_arr_gw => $stock_history_arr_gw_val)
     {
     
     	$gw_stock_history_cols[]=$stock_history_arr_gw;
        
     }
     
     $gw_stock_history_cols_str=implode(",", $gw_stock_history_cols);
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "update",$gw_stock_history_cols_str);
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("stock_history", $stock_history_arr_, $where_str);

       // echo $gwauthenticate_stock_history_;
        
        exit;

     }else{

        echo $gwauthenticate_stock_history_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


      }
    
    }
 	
    
    //End Update stock_history Data ===============

    //Start get  stock_history Data ===============
    
    function get_stock_history($colstr, $where_str, $type)
    {
          
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "select","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {
    	return mosyflex_sel("stock_history", $colstr, $where_str, $type);

        //echo $gwauthenticate_stock_history_;

	  }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }    
    }
    //End get  stock_history Data ===============
    
    
    //======== qstock_history_data qsingle query function
    
    function qstock_history_data($qstock_key_sign_key)
    {
          
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "qdata","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
    	return get_stock_history("*", "WHERE stock_key_sign='$qstock_key_sign_key'", "r");

		//echo $gwauthenticate_stock_history_;

      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }  
    }
   
    //======== qstock_history_data qsingle query function
    
    
     //======== stock_history data to array
    
    function stock_history_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "data_array","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {  
     	$append_stock_history_arr=array();
    
    	$array_stock_history_q=get_stock_history($colstr, $where_str, "l");
        while($array_stock_history_res=mysqli_fetch_array($array_stock_history_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_stock_history_arr[]=$array_stock_history_res[$tbl_col];
            }
          }else{
          	          
               $append_stock_history_arr[]=$array_stock_history_res;

          }
        }
        
        return $append_stock_history_arr;

		//echo $gwauthenticate_stock_history_;

      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }  
    }
   
    //======== qstock_history_data qsingle query function   
        
    //======== qstock_history_ddata qsingle query function    
    function qstock_history_ddata($stock_key_sign_col, $qstock_key_sign_key)
    {
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "qddata","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
    	return get_stock_history("*", "WHERE $stock_key_sign_col='$qstock_key_sign_key'", "r");

		//echo $gwauthenticate_stock_history_;

     }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }   
    }
    //======== qstock_history_ddata qsingle query function

    //======== count stock_history data function
    
    function count_stock_history($stock_history_wherestr)
    {
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "count_data","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
      $clean_stock_history_where_str="";
  
      if($stock_history_wherestr!='')
      {
        $clean_stock_history_where_str="Where ".$stock_history_wherestr;
      }

      return get_stock_history("count(*) as return_result", " ".$clean_stock_history_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_stock_history_;

      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");


     }    
    }
    //======== count stock_history data function

    //======== sum  stock_history data function
    
    function sum_stock_history($stock_history_sumcol, $stock_history_wherestr)
    {
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "sum_data","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
      $clean_stock_history_where_str="";
  
      if($stock_history_wherestr!='')
      {
        $clean_stock_history_where_str="Where ".$stock_history_wherestr;
      }

      return get_stock_history("sum($stock_history_sumcol) as return_result", " ".$clean_stock_history_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_stock_history_;


      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
        


     }    
    }
    
    //======== sum  stock_history data function   
    
    
    //Start drop  stock_history Data ===============
    
    function drop_stock_history($where_str)
    {
     
     $gwauthenticate_stock_history_=gw_oauth("table", magic_current_url(), "stock_history", "drop_data","");
     
     $gwauthenticate_stock_history_json=json_decode($gwauthenticate_stock_history_, true);
     
     if($gwauthenticate_stock_history_json["response"]=="ok")
     {    
    	return magic_sql_delete("stock_history", $where_str);

		//echo $gwauthenticate_stock_history_;

      }else{
     
     	echo $gwauthenticate_stock_history_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_history_)."");
		

     }
    }
    //End drop  stock_history Data ===============    
    
    
   

    
 	//Start Add stock_list Data ===============
 	function add_stock_list($stock_list_arr_)
    {
     $gw_stock_list_cols=array();
     
     foreach($stock_list_arr_ as $stock_list_arr_gw => $stock_list_arr_gw_val)
     {
     
     	$gw_stock_list_cols[]=$stock_list_arr_gw;
        
     }
     
     $gw_stock_list_cols_str=implode(",", $gw_stock_list_cols);
     
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "insert",$gw_stock_list_cols_str);
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("stock_list", $stock_list_arr_);
     
     	//echo $gwauthenticate_stock_list_;

     }else{
     
     	echo $gwauthenticate_stock_list_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");

     }
     
    }
    
       function initialize_stock_list()
        {
        
         global $stock_list_uptoken;
             
         $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "select","");

         $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
         	
          //echo $gwauthenticate_stock_list_;

         if($gwauthenticate_stock_list_json["response"]=="ok")
         {
         
         	return get_stock_list("*", "WHERE primkey='$stock_list_uptoken'", "r");
         
            echo $gwauthenticate_stock_list_;

         }else{

         	echo $gwauthenticate_stock_list_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");
         
         }
        }   
    //End Add stock_list Data ===============
                
    //Start Update stock_list Data ===============
    
 	function update_stock_list($stock_list_arr_, $where_str)
    {
         $gw_stock_list_cols=array();
     
     foreach($stock_list_arr_ as $stock_list_arr_gw => $stock_list_arr_gw_val)
     {
     
     	$gw_stock_list_cols[]=$stock_list_arr_gw;
        
     }
     
     $gw_stock_list_cols_str=implode(",", $gw_stock_list_cols);
     
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "update",$gw_stock_list_cols_str);
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("stock_list", $stock_list_arr_, $where_str);

       // echo $gwauthenticate_stock_list_;
        
        exit;

     }else{

        echo $gwauthenticate_stock_list_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");


      }
    
    }
 	
    
    //End Update stock_list Data ===============

    //Start get  stock_list Data ===============
    
    function get_stock_list($colstr, $where_str, $type)
    {
          
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "select","");
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {
    	return mosyflex_sel("stock_list", $colstr, $where_str, $type);

        //echo $gwauthenticate_stock_list_;

	  }else{
     
     	echo $gwauthenticate_stock_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");


     }    
    }
    //End get  stock_list Data ===============
    
    
    //======== qstock_list_data qsingle query function
    
    function qstock_list_data($qitem_id_key)
    {
          
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "qdata","");
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {    
    	return get_stock_list("*", "WHERE item_id='$qitem_id_key'", "r");

		//echo $gwauthenticate_stock_list_;

      }else{
     
     	echo $gwauthenticate_stock_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");


     }  
    }
   
    //======== qstock_list_data qsingle query function
    
    
     //======== stock_list data to array
    
    function stock_list_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "data_array","");
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {  
     	$append_stock_list_arr=array();
    
    	$array_stock_list_q=get_stock_list($colstr, $where_str, "l");
        while($array_stock_list_res=mysqli_fetch_array($array_stock_list_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_stock_list_arr[]=$array_stock_list_res[$tbl_col];
            }
          }else{
          	          
               $append_stock_list_arr[]=$array_stock_list_res;

          }
        }
        
        return $append_stock_list_arr;

		//echo $gwauthenticate_stock_list_;

      }else{
     
     	echo $gwauthenticate_stock_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");


     }  
    }
   
    //======== qstock_list_data qsingle query function   
        
    //======== qstock_list_ddata qsingle query function    
    function qstock_list_ddata($item_id_col, $qitem_id_key)
    {
     
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "qddata","");
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {    
    	return get_stock_list("*", "WHERE $item_id_col='$qitem_id_key'", "r");

		//echo $gwauthenticate_stock_list_;

     }else{
     
     	echo $gwauthenticate_stock_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");


     }   
    }
    //======== qstock_list_ddata qsingle query function

    //======== count stock_list data function
    
    function count_stock_list($stock_list_wherestr)
    {
     
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "count_data","");
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {    
      $clean_stock_list_where_str="";
  
      if($stock_list_wherestr!='')
      {
        $clean_stock_list_where_str="Where ".$stock_list_wherestr;
      }

      return get_stock_list("count(*) as return_result", " ".$clean_stock_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_stock_list_;

      }else{
     
     	echo $gwauthenticate_stock_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");


     }    
    }
    //======== count stock_list data function

    //======== sum  stock_list data function
    
    function sum_stock_list($stock_list_sumcol, $stock_list_wherestr)
    {
     
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "sum_data","");
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {    
      $clean_stock_list_where_str="";
  
      if($stock_list_wherestr!='')
      {
        $clean_stock_list_where_str="Where ".$stock_list_wherestr;
      }

      return get_stock_list("sum($stock_list_sumcol) as return_result", " ".$clean_stock_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_stock_list_;


      }else{
     
     	echo $gwauthenticate_stock_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");
        


     }    
    }
    
    //======== sum  stock_list data function   
    
    
    //Start drop  stock_list Data ===============
    
    function drop_stock_list($where_str)
    {
     
     $gwauthenticate_stock_list_=gw_oauth("table", magic_current_url(), "stock_list", "drop_data","");
     
     $gwauthenticate_stock_list_json=json_decode($gwauthenticate_stock_list_, true);
     
     if($gwauthenticate_stock_list_json["response"]=="ok")
     {    
    	return magic_sql_delete("stock_list", $where_str);

		//echo $gwauthenticate_stock_list_;

      }else{
     
     	echo $gwauthenticate_stock_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_stock_list_)."");
		

     }
    }
    //End drop  stock_list Data ===============    
    
    
   

    
 	//Start Add suppliers Data ===============
 	function add_suppliers($suppliers_arr_)
    {
     $gw_suppliers_cols=array();
     
     foreach($suppliers_arr_ as $suppliers_arr_gw => $suppliers_arr_gw_val)
     {
     
     	$gw_suppliers_cols[]=$suppliers_arr_gw;
        
     }
     
     $gw_suppliers_cols_str=implode(",", $gw_suppliers_cols);
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "insert",$gw_suppliers_cols_str);
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("suppliers", $suppliers_arr_);
     
     	//echo $gwauthenticate_suppliers_;

     }else{
     
     	echo $gwauthenticate_suppliers_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");

     }
     
    }
    
       function initialize_suppliers()
        {
        
         global $suppliers_uptoken;
             
         $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "select","");

         $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
         	
          //echo $gwauthenticate_suppliers_;

         if($gwauthenticate_suppliers_json["response"]=="ok")
         {
         
         	return get_suppliers("*", "WHERE primkey='$suppliers_uptoken'", "r");
         
            echo $gwauthenticate_suppliers_;

         }else{

         	echo $gwauthenticate_suppliers_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
         
         }
        }   
    //End Add suppliers Data ===============
                
    //Start Update suppliers Data ===============
    
 	function update_suppliers($suppliers_arr_, $where_str)
    {
         $gw_suppliers_cols=array();
     
     foreach($suppliers_arr_ as $suppliers_arr_gw => $suppliers_arr_gw_val)
     {
     
     	$gw_suppliers_cols[]=$suppliers_arr_gw;
        
     }
     
     $gw_suppliers_cols_str=implode(",", $gw_suppliers_cols);
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "update",$gw_suppliers_cols_str);
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("suppliers", $suppliers_arr_, $where_str);

       // echo $gwauthenticate_suppliers_;
        
        exit;

     }else{

        echo $gwauthenticate_suppliers_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


      }
    
    }
 	
    
    //End Update suppliers Data ===============

    //Start get  suppliers Data ===============
    
    function get_suppliers($colstr, $where_str, $type)
    {
          
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "select","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {
    	return mosyflex_sel("suppliers", $colstr, $where_str, $type);

        //echo $gwauthenticate_suppliers_;

	  }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }    
    }
    //End get  suppliers Data ===============
    
    
    //======== qsuppliers_data qsingle query function
    
    function qsuppliers_data($qsupplier_id_key)
    {
          
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "qdata","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
    	return get_suppliers("*", "WHERE supplier_id='$qsupplier_id_key'", "r");

		//echo $gwauthenticate_suppliers_;

      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }  
    }
   
    //======== qsuppliers_data qsingle query function
    
    
     //======== suppliers data to array
    
    function suppliers_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "data_array","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {  
     	$append_suppliers_arr=array();
    
    	$array_suppliers_q=get_suppliers($colstr, $where_str, "l");
        while($array_suppliers_res=mysqli_fetch_array($array_suppliers_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_suppliers_arr[]=$array_suppliers_res[$tbl_col];
            }
          }else{
          	          
               $append_suppliers_arr[]=$array_suppliers_res;

          }
        }
        
        return $append_suppliers_arr;

		//echo $gwauthenticate_suppliers_;

      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }  
    }
   
    //======== qsuppliers_data qsingle query function   
        
    //======== qsuppliers_ddata qsingle query function    
    function qsuppliers_ddata($supplier_id_col, $qsupplier_id_key)
    {
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "qddata","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
    	return get_suppliers("*", "WHERE $supplier_id_col='$qsupplier_id_key'", "r");

		//echo $gwauthenticate_suppliers_;

     }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }   
    }
    //======== qsuppliers_ddata qsingle query function

    //======== count suppliers data function
    
    function count_suppliers($suppliers_wherestr)
    {
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "count_data","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
      $clean_suppliers_where_str="";
  
      if($suppliers_wherestr!='')
      {
        $clean_suppliers_where_str="Where ".$suppliers_wherestr;
      }

      return get_suppliers("count(*) as return_result", " ".$clean_suppliers_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_suppliers_;

      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");


     }    
    }
    //======== count suppliers data function

    //======== sum  suppliers data function
    
    function sum_suppliers($suppliers_sumcol, $suppliers_wherestr)
    {
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "sum_data","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
      $clean_suppliers_where_str="";
  
      if($suppliers_wherestr!='')
      {
        $clean_suppliers_where_str="Where ".$suppliers_wherestr;
      }

      return get_suppliers("sum($suppliers_sumcol) as return_result", " ".$clean_suppliers_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_suppliers_;


      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
        


     }    
    }
    
    //======== sum  suppliers data function   
    
    
    //Start drop  suppliers Data ===============
    
    function drop_suppliers($where_str)
    {
     
     $gwauthenticate_suppliers_=gw_oauth("table", magic_current_url(), "suppliers", "drop_data","");
     
     $gwauthenticate_suppliers_json=json_decode($gwauthenticate_suppliers_, true);
     
     if($gwauthenticate_suppliers_json["response"]=="ok")
     {    
    	return magic_sql_delete("suppliers", $where_str);

		//echo $gwauthenticate_suppliers_;

      }else{
     
     	echo $gwauthenticate_suppliers_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_)."");
		

     }
    }
    //End drop  suppliers Data ===============    
    
    
            //Start Upload suppliers_user_pic Function 
            function upload_suppliers_user_pic($txt_suppliers_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_suppliers_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/suppliers_user_pic')) @mkdir('./img/suppliers_user_pic');

                $cur_item_photos=magic_upload_file('./img/suppliers_user_pic/', $txt_suppliers_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $suppliers_node=get_suppliers("*", "WHERE ".$where_str."", "r");

                  if (file_exists($suppliers_node["user_pic"]))
                  {

                      unlink($suppliers_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('suppliers', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload suppliers_user_pic Function 

            
   

    
 	//Start Add suppliers_invoice Data ===============
 	function add_suppliers_invoice($suppliers_invoice_arr_)
    {
     $gw_suppliers_invoice_cols=array();
     
     foreach($suppliers_invoice_arr_ as $suppliers_invoice_arr_gw => $suppliers_invoice_arr_gw_val)
     {
     
     	$gw_suppliers_invoice_cols[]=$suppliers_invoice_arr_gw;
        
     }
     
     $gw_suppliers_invoice_cols_str=implode(",", $gw_suppliers_invoice_cols);
     
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "insert",$gw_suppliers_invoice_cols_str);
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("suppliers_invoice", $suppliers_invoice_arr_);
     
     	//echo $gwauthenticate_suppliers_invoice_;

     }else{
     
     	echo $gwauthenticate_suppliers_invoice_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");

     }
     
    }
    
       function initialize_suppliers_invoice()
        {
        
         global $suppliers_invoice_uptoken;
             
         $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "select","");

         $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
         	
          //echo $gwauthenticate_suppliers_invoice_;

         if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
         {
         
         	return get_suppliers_invoice("*", "WHERE primkey='$suppliers_invoice_uptoken'", "r");
         
            echo $gwauthenticate_suppliers_invoice_;

         }else{

         	echo $gwauthenticate_suppliers_invoice_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");
         
         }
        }   
    //End Add suppliers_invoice Data ===============
                
    //Start Update suppliers_invoice Data ===============
    
 	function update_suppliers_invoice($suppliers_invoice_arr_, $where_str)
    {
         $gw_suppliers_invoice_cols=array();
     
     foreach($suppliers_invoice_arr_ as $suppliers_invoice_arr_gw => $suppliers_invoice_arr_gw_val)
     {
     
     	$gw_suppliers_invoice_cols[]=$suppliers_invoice_arr_gw;
        
     }
     
     $gw_suppliers_invoice_cols_str=implode(",", $gw_suppliers_invoice_cols);
     
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "update",$gw_suppliers_invoice_cols_str);
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("suppliers_invoice", $suppliers_invoice_arr_, $where_str);

       // echo $gwauthenticate_suppliers_invoice_;
        
        exit;

     }else{

        echo $gwauthenticate_suppliers_invoice_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");


      }
    
    }
 	
    
    //End Update suppliers_invoice Data ===============

    //Start get  suppliers_invoice Data ===============
    
    function get_suppliers_invoice($colstr, $where_str, $type)
    {
          
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "select","");
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {
    	return mosyflex_sel("suppliers_invoice", $colstr, $where_str, $type);

        //echo $gwauthenticate_suppliers_invoice_;

	  }else{
     
     	echo $gwauthenticate_suppliers_invoice_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");


     }    
    }
    //End get  suppliers_invoice Data ===============
    
    
    //======== qsuppliers_invoice_data qsingle query function
    
    function qsuppliers_invoice_data($qdata_id_key)
    {
          
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "qdata","");
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {    
    	return get_suppliers_invoice("*", "WHERE data_id='$qdata_id_key'", "r");

		//echo $gwauthenticate_suppliers_invoice_;

      }else{
     
     	echo $gwauthenticate_suppliers_invoice_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");


     }  
    }
   
    //======== qsuppliers_invoice_data qsingle query function
    
    
     //======== suppliers_invoice data to array
    
    function suppliers_invoice_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "data_array","");
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {  
     	$append_suppliers_invoice_arr=array();
    
    	$array_suppliers_invoice_q=get_suppliers_invoice($colstr, $where_str, "l");
        while($array_suppliers_invoice_res=mysqli_fetch_array($array_suppliers_invoice_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_suppliers_invoice_arr[]=$array_suppliers_invoice_res[$tbl_col];
            }
          }else{
          	          
               $append_suppliers_invoice_arr[]=$array_suppliers_invoice_res;

          }
        }
        
        return $append_suppliers_invoice_arr;

		//echo $gwauthenticate_suppliers_invoice_;

      }else{
     
     	echo $gwauthenticate_suppliers_invoice_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");


     }  
    }
   
    //======== qsuppliers_invoice_data qsingle query function   
        
    //======== qsuppliers_invoice_ddata qsingle query function    
    function qsuppliers_invoice_ddata($data_id_col, $qdata_id_key)
    {
     
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "qddata","");
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {    
    	return get_suppliers_invoice("*", "WHERE $data_id_col='$qdata_id_key'", "r");

		//echo $gwauthenticate_suppliers_invoice_;

     }else{
     
     	echo $gwauthenticate_suppliers_invoice_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");


     }   
    }
    //======== qsuppliers_invoice_ddata qsingle query function

    //======== count suppliers_invoice data function
    
    function count_suppliers_invoice($suppliers_invoice_wherestr)
    {
     
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "count_data","");
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {    
      $clean_suppliers_invoice_where_str="";
  
      if($suppliers_invoice_wherestr!='')
      {
        $clean_suppliers_invoice_where_str="Where ".$suppliers_invoice_wherestr;
      }

      return get_suppliers_invoice("count(*) as return_result", " ".$clean_suppliers_invoice_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_suppliers_invoice_;

      }else{
     
     	echo $gwauthenticate_suppliers_invoice_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");


     }    
    }
    //======== count suppliers_invoice data function

    //======== sum  suppliers_invoice data function
    
    function sum_suppliers_invoice($suppliers_invoice_sumcol, $suppliers_invoice_wherestr)
    {
     
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "sum_data","");
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {    
      $clean_suppliers_invoice_where_str="";
  
      if($suppliers_invoice_wherestr!='')
      {
        $clean_suppliers_invoice_where_str="Where ".$suppliers_invoice_wherestr;
      }

      return get_suppliers_invoice("sum($suppliers_invoice_sumcol) as return_result", " ".$clean_suppliers_invoice_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_suppliers_invoice_;


      }else{
     
     	echo $gwauthenticate_suppliers_invoice_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");
        


     }    
    }
    
    //======== sum  suppliers_invoice data function   
    
    
    //Start drop  suppliers_invoice Data ===============
    
    function drop_suppliers_invoice($where_str)
    {
     
     $gwauthenticate_suppliers_invoice_=gw_oauth("table", magic_current_url(), "suppliers_invoice", "drop_data","");
     
     $gwauthenticate_suppliers_invoice_json=json_decode($gwauthenticate_suppliers_invoice_, true);
     
     if($gwauthenticate_suppliers_invoice_json["response"]=="ok")
     {    
    	return magic_sql_delete("suppliers_invoice", $where_str);

		//echo $gwauthenticate_suppliers_invoice_;

      }else{
     
     	echo $gwauthenticate_suppliers_invoice_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_suppliers_invoice_)."");
		

     }
    }
    //End drop  suppliers_invoice Data ===============    
    
    
   

    
 	//Start Add users_tbl Data ===============
 	function add_users_tbl($users_tbl_arr_)
    {
     $gw_users_tbl_cols=array();
     
     foreach($users_tbl_arr_ as $users_tbl_arr_gw => $users_tbl_arr_gw_val)
     {
     
     	$gw_users_tbl_cols[]=$users_tbl_arr_gw;
        
     }
     
     $gw_users_tbl_cols_str=implode(",", $gw_users_tbl_cols);
     
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "insert",$gw_users_tbl_cols_str);
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("users_tbl", $users_tbl_arr_);
     
     	//echo $gwauthenticate_users_tbl_;

     }else{
     
     	echo $gwauthenticate_users_tbl_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");

     }
     
    }
    
       function initialize_users_tbl()
        {
        
         global $users_tbl_uptoken;
             
         $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "select","");

         $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
         	
          //echo $gwauthenticate_users_tbl_;

         if($gwauthenticate_users_tbl_json["response"]=="ok")
         {
         
         	return get_users_tbl("*", "WHERE primkey='$users_tbl_uptoken'", "r");
         
            echo $gwauthenticate_users_tbl_;

         }else{

         	echo $gwauthenticate_users_tbl_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");
         
         }
        }   
    //End Add users_tbl Data ===============
                
    //Start Update users_tbl Data ===============
    
 	function update_users_tbl($users_tbl_arr_, $where_str)
    {
         $gw_users_tbl_cols=array();
     
     foreach($users_tbl_arr_ as $users_tbl_arr_gw => $users_tbl_arr_gw_val)
     {
     
     	$gw_users_tbl_cols[]=$users_tbl_arr_gw;
        
     }
     
     $gw_users_tbl_cols_str=implode(",", $gw_users_tbl_cols);
     
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "update",$gw_users_tbl_cols_str);
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("users_tbl", $users_tbl_arr_, $where_str);

       // echo $gwauthenticate_users_tbl_;
        
        exit;

     }else{

        echo $gwauthenticate_users_tbl_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");


      }
    
    }
 	
    
    //End Update users_tbl Data ===============

    //Start get  users_tbl Data ===============
    
    function get_users_tbl($colstr, $where_str, $type)
    {
          
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "select","");
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {
    	return mosyflex_sel("users_tbl", $colstr, $where_str, $type);

        //echo $gwauthenticate_users_tbl_;

	  }else{
     
     	echo $gwauthenticate_users_tbl_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");


     }    
    }
    //End get  users_tbl Data ===============
    
    
    //======== qusers_tbl_data qsingle query function
    
    function qusers_tbl_data($quser_id_key)
    {
          
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "qdata","");
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {    
    	return get_users_tbl("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_users_tbl_;

      }else{
     
     	echo $gwauthenticate_users_tbl_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");


     }  
    }
   
    //======== qusers_tbl_data qsingle query function
    
    
     //======== users_tbl data to array
    
    function users_tbl_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "data_array","");
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {  
     	$append_users_tbl_arr=array();
    
    	$array_users_tbl_q=get_users_tbl($colstr, $where_str, "l");
        while($array_users_tbl_res=mysqli_fetch_array($array_users_tbl_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_users_tbl_arr[]=$array_users_tbl_res[$tbl_col];
            }
          }else{
          	          
               $append_users_tbl_arr[]=$array_users_tbl_res;

          }
        }
        
        return $append_users_tbl_arr;

		//echo $gwauthenticate_users_tbl_;

      }else{
     
     	echo $gwauthenticate_users_tbl_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");


     }  
    }
   
    //======== qusers_tbl_data qsingle query function   
        
    //======== qusers_tbl_ddata qsingle query function    
    function qusers_tbl_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "qddata","");
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {    
    	return get_users_tbl("*", "WHERE $user_id_col='$quser_id_key'", "r");

		//echo $gwauthenticate_users_tbl_;

     }else{
     
     	echo $gwauthenticate_users_tbl_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");


     }   
    }
    //======== qusers_tbl_ddata qsingle query function

    //======== count users_tbl data function
    
    function count_users_tbl($users_tbl_wherestr)
    {
     
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "count_data","");
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {    
      $clean_users_tbl_where_str="";
  
      if($users_tbl_wherestr!='')
      {
        $clean_users_tbl_where_str="Where ".$users_tbl_wherestr;
      }

      return get_users_tbl("count(*) as return_result", " ".$clean_users_tbl_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_users_tbl_;

      }else{
     
     	echo $gwauthenticate_users_tbl_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");


     }    
    }
    //======== count users_tbl data function

    //======== sum  users_tbl data function
    
    function sum_users_tbl($users_tbl_sumcol, $users_tbl_wherestr)
    {
     
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "sum_data","");
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {    
      $clean_users_tbl_where_str="";
  
      if($users_tbl_wherestr!='')
      {
        $clean_users_tbl_where_str="Where ".$users_tbl_wherestr;
      }

      return get_users_tbl("sum($users_tbl_sumcol) as return_result", " ".$clean_users_tbl_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_users_tbl_;


      }else{
     
     	echo $gwauthenticate_users_tbl_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");
        


     }    
    }
    
    //======== sum  users_tbl data function   
    
    
    //Start drop  users_tbl Data ===============
    
    function drop_users_tbl($where_str)
    {
     
     $gwauthenticate_users_tbl_=gw_oauth("table", magic_current_url(), "users_tbl", "drop_data","");
     
     $gwauthenticate_users_tbl_json=json_decode($gwauthenticate_users_tbl_, true);
     
     if($gwauthenticate_users_tbl_json["response"]=="ok")
     {    
    	return magic_sql_delete("users_tbl", $where_str);

		//echo $gwauthenticate_users_tbl_;

      }else{
     
     	echo $gwauthenticate_users_tbl_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_users_tbl_)."");
		

     }
    }
    //End drop  users_tbl Data ===============    
    
    
            //Start Upload users_tbl_user_pic Function 
            function upload_users_tbl_user_pic($txt_users_tbl_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_users_tbl_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/users_tbl_user_pic')) @mkdir('./img/users_tbl_user_pic');

                $cur_item_photos=magic_upload_file('./img/users_tbl_user_pic/', $txt_users_tbl_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $users_tbl_node=get_users_tbl("*", "WHERE ".$where_str."", "r");

                  if (file_exists($users_tbl_node["user_pic"]))
                  {

                      unlink($users_tbl_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('users_tbl', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload users_tbl_user_pic Function 

            
  //===============End Mosy queries-============

//============= Start Sql chart  Script =====================

function mosy_sql_rollback($tbl, $where, $type)
{
  $sql_fun="get_".$tbl;

  $curr_sql_ret_=$sql_fun("*", " where ".$where." ", "r");
  
  $json_sql_str=json_encode($curr_sql_ret_, true);
  
  //------- begin mosy_sql_roll_back_post_arr --> 
  $mosy_sql_roll_back_post_arr_=array(

  "primkey"=>"NULL",
  "roll_bk_key"=>mmres(magic_random_str(20)),
  "table_name"=>mmres($tbl),
  "where_str"=>mmres($where),
  "roll_type"=>mmres($type),
  "roll_timestamp"=>date("Y-m-d H:i:s"),
  "value_entries"=>mmres($json_sql_str)

  );
  //===-- End mosy_sql_roll_back_post_arr -->

  add_mosy_sql_roll_back($mosy_sql_roll_back_post_arr_);
  
  return $json_sql_str;
  
}


function get_mosychart_data($tbl, $colstr, $where_str, $xcol, $ycol, $groupby)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str="";
   $groupby_cols="";
   
   if($where_str!='')
   {
     $fun_where_str=" WHERE ".$where_str;
   }
   
   if($groupby!='')
   {
     $groupby_cols=" GROUP BY ".$groupby;
   }
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ".$groupby_cols." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================


//============= Start   mosy flex select script =====================

function mosyflex_sel($tbl, $colstr, $where_str, $loop_or_row_l_r)
{
   global $single_conn;
   global $single_db;
   global $flex_result;
   global $datalimit;
  
  $paginate_q="";
  $paginate_state="";
  
  $pagination_token=$tbl."_mpgtkn";
  
  $loop_or_row_l_rtype=$loop_or_row_l_r;
  
  if (strpos($loop_or_row_l_r, ':') !== false)
  {
    $loop_or_row_l_r_str=explode(":", $loop_or_row_l_r);

    $pagination_token=$loop_or_row_l_r_str[1];

    $loop_or_row_l_rtype=$loop_or_row_l_r_str[0];

    $paginate_state="paginate";
    
    $pagination_sql="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";
    
    ///echo $pagination_sql;
    
    $process_pagination=mysqli_query($single_conn, $pagination_sql) or die(mysqli_error($single_conn));

    $paginate_q=mosy_paginate($process_pagination, $datalimit, $pagination_token);

    $new_where_str=$where_str." LIMIT ".$paginate_q[0].", $datalimit ";

    $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_str."";
    
    ///echo $sql_str;
  }else{
    
      $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

  }
   
    
  $flex_result_q=mysqli_query($single_conn, $sql_str) or die(mysqli_error($single_conn));
  
  $flex_result=$flex_result_q;

  if($loop_or_row_l_rtype=='r')
  {
    $flex_result_r=mysqli_fetch_array($flex_result_q);
    
    $flex_result=$flex_result_r;
    
  }
  
  if($paginate_state=='paginate')
  {
  	$flex_result=array($flex_result_q, $paginate_q[1], $paginate_q[0], $sql_str, $pagination_sql);  
  }
  
  return $flex_result;
  
}

function mosy_paginate($sqlstring, $reclimit, $token_name)
{

  $requested_page = isset($_GET[$token_name]) ? intval(base64_decode($_GET[$token_name])) : 1;

  $rows_count = mysqli_num_rows($sqlstring);

  $items_per_page = $reclimit;

  $page_count = ceil($rows_count / $items_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_row = ($requested_page - 1) * $items_per_page;

  $recordperpage_data=array($first_row,$page_count);

  return $recordperpage_data;
  
}
//============= End  mosy flex select script =====================

  function tonum($number_str, $decplaces=0)
  {
	if($number_str=='')
    {
      $number_str=0;
    }
  	return number_format($number_str, $decplaces, ".", ",");
  	

  }
  
//checkblank fuction

function checkblank($value, $return_val)
{
  
  global $fun_resonse;

  if($value!='')
  {
  $fun_resonse=$value;
  }else{
    $fun_resonse=$return_val;

  }
  return $fun_resonse;

}

//get date foramrt

function ftime($time_st, $type)
{
  	global $timeresp;
    
  $timeresp=date("l, jS, M, y, @ H:i:s");

  if($time_st=="") 
  {
    $timeresp=date("l, jS, M, y, @ H:i:s");

  	if($type=="date")
    {
    $timeresp=date("l, jS, M, y");
    }
    
  }
  
  if($time_st!=""){
  
     $timeresp=date("l, jS, M, y, @ H:i:s", strtotime($time_st));

    if($type=="date")
    {
    	$timeresp=date("l, jS, M, y", strtotime($time_st));
    }
    
  }
	return $timeresp;
}

function date_time_input($time_st, $full_date_time)
{
  	global $timeresp;
    
    $date_form="Y-m-d\TH:i:s";
    
    if($full_date_time=="date")
    {
    $date_form="Y-m-d";
    }
    
    if($full_date_time=="time")
    {
    $date_form="H:i:s";
    }
    
  if($time_st==""){
  	$timeresp=date($date_form);
  }else{
   
   $timeresp=date($date_form, strtotime($time_st));

  }
	return $timeresp;
}
function daytime()
{
  global $daytime;

  $daytime='Hello';

  $fromdate=date('A');

  if($fromdate=='AM'){
 	 $daytime='Morning';
  }

  if($fromdate=='PM'){
  	$daytime='Evening';
  }

  return $daytime;
}
function time_elapsed_string($datetime, $full = false) 
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        "y" => "year",
        "m" => "month",
        "w" => "week",
        "d" => "day",
        "h" => "hour",
        "i" => "minute",
        "s" => "second",
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . " " . $v . ($diff->$k > 1 ? "s" : "");
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(", ", $string) . " ago" : "just now";
}

if (file_exists("./mosy_paginate.php")){
include("./mosy_paginate.php");
}

function pdf_url($current, $pdfurl)
{
  
  $filter_param=str_replace($current."", $pdfurl."", (magic_current_url()));

  if(strpos($filter_param, '?') !== false) 
  {
    $filter_param=str_replace($current."?", $pdfurl."?", (magic_current_url()));

  }

  if(strpos($filter_param, '.php?') !== false) 
  {
    $filter_param=str_replace($current.".php?", $pdfurl."?", (magic_current_url()));

  }

  return $filter_param;
  
}


function mosy_send_mail($to_email, $from_email, $sender_name, $subject, $message, $use_api="")
{
	// create email headers
	$replyto_mail="";
	$returnpath="";
	$headers="";

	if($from_email!='')
	{
    	$replyto_mail='Reply-To: ' .$sender_name." <".$from_email.">\r\n";
    	$returnpath='Return-Path: ' .$sender_name." <".$from_email.">\r\n";
	}

	$busmail=$from_email;
	$bus_name=$sender_name;

	if($to_email=='')
	{
		$busmail='info@clearphrases.com';
	}

	if($sender_name=='')
	{
		$bus_name="";
	}

    $headers = 'From: '.$bus_name.'<'.$busmail.'>' . "\r\n" .
    $headers.=$replyto_mail;
    $headers.=$returnpath;
    $headers .= "Organization: ".$bus_name."\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers.='Content-type: text/html; charset=UTF-8'. "\r\n";
    $headers .= "X-Priority: 3\r\n";
    $headers .= "X-Mailer: PHP". phpversion() ."\r\n";
   
  if($use_api=="yes")
  {
    
    $curlopt_url="https://origin.clearphrases.com/api/email/mosy_mail.php";
    
    $email_attr="send_mosy_email&to_email=".rawurlencode($to_email)."&from_email=".rawurlencode($from_email)."&sender_name=".rawurlencode($sender_name)."&subject=".rawurlencode($subject)."&message=".rawurlencode($message)."";
    
   return magic_post_curl($curlopt_url, "", "", $email_attr, "POST");

  }else{
    
  return mail($to_email, $subject, $message, $headers);        
  }
}


function mosy_push_sms($recp, $sms_body, $smsapi_url="")
{

  
  if($smsapi_url=="")
  {
    $smsapi_url="https://origin.clearphrases.com/api/sms/adminsmsgateway.php";
  }
  
  $sms_request="pushsms&recp=".$recp."&body=".$sms_body."";

  return magic_post_curl($smsapi_url, '', '', $sms_request, 'POST');

}
function add_url_param( $key, $value, $passed_url) 
{
  $url=$passed_url;
  if($passed_url=='')
  {
    $url=magic_current_url();
  }
  
  $info = parse_url( $url );

  if(isset($info['query']))
  {
    parse_str( $info['query'], $query );
  }else{
    $query="";
  }
    return $info['scheme'] . '://' . $info['host'] . $info['path'] . '?' . http_build_query( $query ? array_merge( $query, array($key => $value ) ) : array( $key => $value ) );
}

//<--ncgh-->
?>