<?php 
$mosy_nav___username="Jeremy Alex";
$mosy_nav___user_avatar="img/useravatar.png";
$mosy_nav___user_notifi_count="0";
$mosy_nav___user_role="User";
?>
<div class="header ">
  <div class="header-left">
  <a class="mobile_btn" id="mobile_btn">
  	<i class="fa fa-bars"></i>
  </a>  
  <a href="javascript:void(0);" id="toggle_btn">
  	<i class="fe fe-text-align-left"></i>
  </a>  
    <a href="index.php" class="logo logo-small" style="margin-left:-100px;">
    	<img src="<?php echo $mep_app_logo ?>" alt="Logo" width="30" height="30">
          <span class="bold h5"><?php echo $mep_app_name ?></span>
    </a>
  </div>
  <div class="top-nav-search pt-2">
   <a href="index.php" class="logo">
    	<img src="<?php echo $mep_app_logo ?>" style="<?php echo $mep_app_logo_style ?>" alt="Logo"> 
        <span class="bold h5"><?php echo $mep_app_name ?></span>
    </a>
  </div>
  <ul class="nav user-menu">

    <li class="nav-item dropdown noti-dropdown">
    <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
    <i class="fa fa-bell text-success "></i> <span class="badge badge-pill text-white"><?php echo $mosy_nav___user_notifi_count ?></span>
    </a>
    <div class="dropdown-menu notifications">
      <div class="topnav-dropdown-header">
        <span class="notification-title">Notifications</span>
        <a href="javascript:void(0)" class="clear-noti"></a>
      </div>
      <div class="noti-content">
      <ul class="notification-list">

       <template id="nav_notification_nodes">
          <li class="notification-message">
            <a href="{{notification_link}}">
            <div class="media d-flex">
              <span class="avatar avatar-sm flex-shrink-0">
                  <img class="avatar-img rounded-circle" alt="User Image" src="{{notification_icon}}">
              </span>
              <div class="media-body flex-grow-1">
                <p class="noti-details text-dark">{{notif_remark}}</p>
                <p class="noti-time"><span class="notification-time">{{notification_time_stamp}}</span></p>
              </div>
            </div>
            </a>
          </li>
        </template>
      </ul>
      </div>
      <div class="topnav-dropdown-footer">
      	<a href="mosy_notific">View all Notifications</a>
      </div>
    </div>
    </li>


    <li class="nav-item dropdown has-arrow">
      <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
        <span class="text-primary mr-2"><?php echo daytime()." ".explode(" ", $mosy_nav___username)[0] ?></span>
      	<span class="user-img"><img class="rounded-circle" src="<?php echo $mosy_nav___user_avatar?>" onerror="this.src='img/useravatar.png'" width="31"></span>
      </a>
      <div class="dropdown-menu">
        <div class="user-header">
          <div class="avatar avatar-sm">
          	<img src="<?php echo $mosy_nav___user_avatar ?>" onerror="this.src='img/useravatar.png'" alt="User Image" class="avatar-img rounded-circle">
          </div>
          <div class="user-text">
          	<h6><?php echo $mosy_nav___username ?></h6>
          	<p class="text-muted mb-0"><?php echo $mosy_nav___user_role?></p>
        </div>
        </div>
        <a class="dropdown-item d-none" href="adminaccount">My Profile</a>
        <a class="dropdown-item d-none" href="adminaccount">Account Settings</a>
        <a class="dropdown-item" href="olm_sessionlogout.php">Logout</a>
      </div>
    </li>

  </ul>

</div>

<div class="sidebar" id="sidebar">
  <div class="sidebar-inner slimscroll">
    <div id="sidebar-menu" class="sidebar-menu">
      <ul>
        <li class="menu-title">  </li>
        <li><a href="index"><i class="fe fe-home"></i> <span>Dashboard</span></a></li>                       

			      
        <li class="submenu">
          <a href="#"><i class="fa fa-car"></i> <span> Client & Vehicles</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="vehicles">  Client Vehicles Report</a></li>
            <li><a class="nav-link d-none" href="vehicles:Client Vehicles Report_profile">Add Vehicles:client Vehicles Report</a></li>               
            <li><a class="nav-link" href="cars_list_list">  Cars List</a></li>
            <li><a class="nav-link d-none" href="cars_list_profile">Add Cars List</a></li>               
            <li><a class="nav-link" href="customers_list">  Customers</a></li>
            <li><a class="nav-link d-none" href="customers_profile">Add Customers</a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-search"></i> <span> Vehicle Inspections</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="defect_report_">  Record Inspection</a></li>
            <li><a class="nav-link d-none" href="defect_report_:Record Inspection_profile">Add Defect Report :record Inspection</a></li>               
            <li><a class="nav-link" href="vehicle_booking_check_list">  Booking Check List</a></li>
            <li><a class="nav-link d-none" href="vehicle_booking_check_list:Booking Check List_profile">Add Vehicle Booking Check List:booking Check List</a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-copy"></i> <span> Estimates & Invoices</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="defect_report_">  Invoices</a></li>
            <li><a class="nav-link d-none" href="defect_report_:Invoices_profile">Add Defect Report :invoices</a></li>               
            <li><a class="nav-link" href="payment_vouchers_list">  Payment Vouchers</a></li>
            <li><a class="nav-link d-none" href="payment_vouchers_profile">Add Payment Vouchers</a></li>               
            <li><a class="nav-link" href="jv_list_list">  Jv List</a></li>
            <li><a class="nav-link d-none" href="jv_list_profile">Add Jv List</a></li>               
            <li><a class="nav-link" href="dr_cr_table_list">  Dr Cr Table</a></li>
            <li><a class="nav-link d-none" href="dr_cr_table_profile">Add Dr Cr Table</a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-edit"></i> <span> Vehicle Booking</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="_list">  </a></li>
            <li><a class="nav-link d-none" href="_profile">Add </a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-bolt"></i> <span> Repair Tracker</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="_list">  </a></li>
            <li><a class="nav-link d-none" href="_profile">Add </a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-edit"></i> <span> Gatepass & Dispatch</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="_list">  </a></li>
            <li><a class="nav-link d-none" href="_profile">Add </a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-gear"></i> <span> Mechanics</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="_list">  </a></li>
            <li><a class="nav-link d-none" href="_profile">Add </a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-shopping-cart"></i> <span> Ecommerce</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="_list">  </a></li>
            <li><a class="nav-link d-none" href="_profile">Add </a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-book"></i> <span> Accounts</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="_list">  </a></li>
            <li><a class="nav-link d-none" href="_profile">Add </a></li>
           </ul>
        </li>       
        <li class="submenu">
          <a href="#"><i class="fa fa-shield"></i> <span> System admins</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">               
            <li><a class="nav-link" href="_list">  </a></li>
            <li><a class="nav-link d-none" href="_profile">Add </a></li>
           </ul>
        </li> 
  
  	   </ul>
    </div>
  </div>
</div>