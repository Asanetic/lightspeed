<style type="text/css">
.chart_tray{
  height:400px;
}
</style>
<?php
$skinclr=$ctn_bg;
$buttonclr=$btn_bg;
$gentxtclr=$ctn_txt;
$buttontxtclr=$btn_txt;
?>
<script type="text/javascript" src="./gstatic/loader.js"></script>
<script>google.charts.load('current', {'packages':['corechart']});</script>

<script type="text/javascript">
      
      function draw_mosy_chart(data_array, container, chart_type, chart_title) 
      {

  			var processed_array=(data_array);
  
            var index = processed_array[0].indexOf("{ role: 'style' }");

            if (index !== -1) {
                processed_array[0][index] = { role: 'style' };
            }
  
        var data = google.visualization.arrayToDataTable(processed_array);
  		
  		var pieHole_size=0;
  
  		if(chart_type=='Doughnut')
        {
        	var pieHole_size = 0.4;
        }
  
        var options = {
          title: chart_title,
		  pieHole:pieHole_size, 
		 curveType: 'function',
      backgroundColor: {
        fill: '<?php echo $skinclr;?>',
        fillOpacity: 0.6
      },
		hAxis: {
    textStyle:{color: '<?php echo $gentxtclr;?>'}
			},
		vAxis: {
    	textStyle:{color: '<?php echo $gentxtclr;?>'}
		},
    legendTextStyle: { color: '<?php echo $gentxtclr;?>' },
    titleTextStyle: { color: '<?php echo $gentxtclr;?>' },
	        slices: {0: {color: '<?php echo $buttonclr;?>'},},
        };

        if(chart_type=='ColumnChart')
        {
        	var chart = new google.visualization.ColumnChart(document.getElementById(container));
        }
        
  		
  		if(chart_type=='LineChart')
        {
        	var chart = new google.visualization.LineChart(document.getElementById(container));
        }
  
        if(chart_type=='BarChart')
        {
        	var chart = new google.visualization.BarChart(document.getElementById(container));
        }
        
  		if(chart_type=='PieChart')
        {
        	var chart = new google.visualization.PieChart(document.getElementById(container));
        }
    
  		if(chart_type=='Doughnut')
        {
        	var chart = new google.visualization.PieChart(document.getElementById(container));
        }
    	
  		if(chart_type=='AreaChart')
        {
        	var chart = new google.visualization.AreaChart(document.getElementById(container));
        }


        chart.draw(data, options);
      }
</script>