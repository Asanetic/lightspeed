<?php
//*******************************  app Settings
if(!isset($common_root)){$common_root = ".";}

//Name and Logo
$mosy_app_name="Demo app";
$mep_app_name=$mosy_app_name;
$mep_app_logo=$common_root."/img/logo/logo.png?v=9d7";
$mep_app_logo_style="width: auto; height: 50px;";
///$mep_app_name_2='<span class="text-light">Spot</span><span style="color:#E559EA"> Light</span>';
$mep_app_name_2='<span class="text-light">$mosy_app_name</span>';
//App color Scheme
//------------------------------

$theme_name="Mosy"; //-Theme Name - Default - Modular Operating system (Mosy)
$btn_bg="#000000"; //-Button color
$btn_txt="#fff"; //-Button text color
$ctn_bg="#fff"; //-Container color
$ctn_txt="#000"; //-Container text color - $ctn_txt
$body_color="rgba(255, 255, 255, 0.9)"; //-Body color - $body_color
$body_txt="#000"; //-Body text - $body_txt
$nav_bar_bg_color="#FFF"; //-nav_bar_bg_color
$navbar_border_color="#ccc"; //-navbar_border_color
$navbar_border_size="1"; //-navbar_border_size
$nav_shadow_class="shadow-sm"; // -nav_shadow_class
$gen_border_color="#000000";
$gen_border_size="1";
$wild_color="";
$skin_plasma="rgba(255, 255, 255, 0.0)"; //-Body color - $body_color
$body_skin_css="#f8f9fa";

$side_bar_bg="#634400";
$side_bar_txt=$btn_txt;

$side_bar_chip_bg=$side_bar_bg;
$side_bar_chip_txt=$side_bar_txt;
  
 $side_bar_type="mini-sidebar"; //mini-sidebar || ""

//Gradient colors
//------------------
 $btn_first_color="#000000";
 $btn_second_color="#EE8133";

//*******************************  app Settings
$skinclr=$ctn_bg;
$buttonclr=$btn_bg;
$gentxtclr=$ctn_txt;
$buttontxtclr=$btn_txt;
?>
    <link rel="stylesheet" href="<?php echo $common_root ?>/css/designer.css">
    <link rel="stylesheet" href="<?php echo $common_root ?>/css/fonts.css">
    <link type=text/css href="https://fonts.googleapis.com/css?family=Poppins:400,300" rel=stylesheet>
    <link rel="icon" href="<?php echo $mep_app_logo;?>?v=<?php echo date('dmysa');?>">
    <link rel="stylesheet" href="<?php echo $common_root ?>/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $common_root ?>/assets/css/feathericon.min.css">
    <link rel="stylesheet" href="<?php echo $common_root ?>/assets/plugins/morris/morris.css">
    <link rel="stylesheet" href="<?php echo $common_root ?>/assets/css/style.css?v=9797900lp"> 
  
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<?php echo magic_css();?>

<style>
/*------------------------custom theme color scheme  ------------------------------*/
 p{
     padding:0px;
     margin:0px;
 } 
  
.title_text{
 letter-spacing:-0.80px;
}

.paragraph_text{

  font-size:;

}

thead{
  background-color:<?php echo $btn_second_color; ?>10;
}

.description_text{
font-size:12px;
}

::placeholder{
 font-size:14px;
 /*color:#19162c!important;*/
}


.form-control{
height:48px !important;
border-radius:20px!important;
}

.label_text{
font-size:14px;
font-weight:600 !important;
}

body{
line-height:1.6
}

.btn{
height:48px!important;
line-height:37px!important;
}

  /* ---------------------------------------------------- Modern Ui --------------------- */ 
  .header .header-left
  {
    background-color: <?php echo $side_bar_chip_bg; ?>;
    box-shadow: 0 4px 4px rgb(66 11 161/20%);
    border-top-right-radius: 70px;    
  }

  #toggle_btn {
	color:<?php echo $side_bar_chip_txt; ?>;
    margin-left:0px;
  }

  .sidebar-inner {
      background: <?php echo $side_bar_bg ?>;
  }

  .sidebar-menu>ul>li:hover {
      background-color: <?php echo  $side_bar_bg;?>;
  }

  .sidebar-menu li a {
      color: <?php echo $side_bar_txt;?>;
  }

  .nav-link:focus, .nav-link:hover {
      color: #ccc;
  }
    .table thead th 
  {
  	white-space: nowrap;
    vertical-align: center;
    border-top: 1px solid #dee2e6;
    font-size: 14px;
  }
  .table tbody td 
  {
  	white-space: nowrap;
    vertical-align: center;
    border-top: 1px solid #dee2e6;
    font-size: 14px;
  }

.mosy_modal {
    position: fixed;
    z-index: 1;
    left: 30%;
    top: 29%;
    width: 40%;
    height: 50%;
    overflow: auto;
}

@media screen and (max-width: 700px)
{
  .mosy_modal {
    width:99%;
    left:1%;
  }
  
   .header .header-left
  {
    background-color: <?php echo $side_bar_chip_txt; ?>;
  }

  #toggle_btn {
	color:<?php echo $side_bar_chip_bg; ?>;
  }
}  
  
.table-search button {
    background-color: <?php echo $btn_bg ?>;
    color:<?php echo $btn_txt ?>!important;
}

.table-search button  span {
    background-color: <?php echo $btn_bg ?>;
    color:<?php echo $btn_txt ?>!important;
}
.navbar-light .navbar-nav .nav-link {
    color: #FFF;
}
.navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover {
    color: <?php echo  $btn_bg?>;
}
.primary_clr{
  color:<?php echo  $btn_bg?>
}
.trim_text {
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.overflow_y{
overflow-y:auto;
}

.max_height_350{
max-height:350px;
overflow-y:auto;
}

.desk_font
{
 font-size:14px; 
} 

.large_icon{
 font-size:50px!important; 
}  
.medium_icon{
 font-size:30px!important; 
}                           
.rounded_big
{
border-radius:30px!important; 
 overflow:hidden;
} 

.rounded_medium
{
border-radius:10px; 
 overflow:hidden;
} 

.useravatar_small{
width:50px;
height:50px;
border-radius:50%;
}

.useravatar_90{
width:80px;
height:80px;
border-radius:50%;
}


.useravatar_120{
width:120px;
height:120px;
border-radius:50%;
}


.card-img-overlay{
background:rgba(255, 255, 255, 0.8);
}

.bg_w_img_overlay{
background:rgba(255, 255, 255, 0.8);

}
.shadow{
  box-shadow: 0 20px 27px 0 rgb(0 0 0 / 5%)!important;
}
  
  .slanted_tray{
clip-path: polygon(0 0, 95% 0%, 100% 100%, 0% 100%);
padding-right:30px;
} 
.sticky_scroll{
  position:sticky;
  top:0px;
}

.stats_knob{
  border: 3px solid <?php echo $btn_bg?>;
  border-bottom-color: #F8DD83;
  border-left-color: #F8DD83;
}
.bg-warning {
    background-color: #f7c72f!important;
}
@keyframes zoom_in_out_anime {
    0% {
        transform: scale(1,1);
    }
    50% {
        transform: scale(1.2,1.2);
    }
    100% {
        transform: scale(1,1);
    }
}
@keyframes spin {
    from {
        transform:rotate(0deg);
    }
    to {
        transform:rotate(360deg);
    }
}
.btn:hover {
	animation: zoom_in_out_anime 1s linear ;
}

.bounce_up_down:hover {
  animation: bounce_anime 2s linear alternate;
  -webkit-animation: bounce_anime 2s linear alternate;
}

.zoom_in_out:hover {
  animation: zoom_in_out_anime 2s linear alternate;
  -webkit-animation: zoom_in_out_anime 2s linear alternate;
}

.badge:hover{
  animation: zoom_in_out_anime 2s linear alternate;
  -webkit-animation: zoom_in_out_anime 2s linear alternate;
}
.badge-primary
{
margin-bottom:10px; 
  color:<?php echo $btn_txt ?>;

}

.badge{
  color:<?php echo $body_txt ?>;

}
@-webkit-keyframes bounce_anime {
  0%, 100% {
    -webkit-transform: translateY(0);
  }
  50% {
    -webkit-transform: translateY(-10px);
  }
}


@keyframes bounce_anime {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
}


@-webkit-keyframes bounce_left_right_anime {
  0%, 100% {
    -webkit-transform: translateX(0);
  }
  50% {
    -webkit-transform: translateX(-10px);
  }
}


@keyframes bounce_left_right_anime {
  0%, 100% {
    transform: translateX(0);
  }
  50% {
    transform: translateX(-10px);
  }
}

.bounce_left_right:hover{
  animation: bounce_left_right_anime 2s linear alternate;
  -webkit-animation: bounce_left_right_anime 2s linear alternate;
}
.auto_bounce_left_right{
  animation: bounce_left_right_anime 2s linear alternate;
  -webkit-animation: bounce_left_right_anime 2s linear alternate;
}
.tr:hover{
  animation: bounce_left_right_anime 2s linear alternate;
  -webkit-animation: bounce_left_right_anime 2s linear alternate;
}        
         @-webkit-keyframes fadeindown {
            0% {
               opacity: 0;
               -webkit-transform: translateY(-10px);
            }
            100% {
               opacity: 1;
               -webkit-transform: translateY(0);
            }
         }
         
         @keyframes fadeindown {
            0% {
               opacity: 0;
               transform: translateY(-10px);
            }
            100% {
               opacity: 1;
               transform: tr.anslateY(0);
            }
         }
         
         .fadeindown {
            -webkit-animation: fadeindown;
            animation: fadeindown ease 2s;
         }


.table_cell_dropdown-content a {
    font-size: 13px;
  padding-top:6px!important;
  padding-bottom:6px!important;
  z-index:999;
  
}

.bg_w_img{
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    background-image: url('./img/loginbg.jpg?v=32e3');
}
body
{
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    /*background-image: url('./img/bg.jpg');*/
    background:<?php echo $body_skin_css ?>;
    font-family: "Poppins","Helvetica Neue","Open Sans","Arial","sans-serif"; 
  	line-height:30px;
  	font-weight:400;
  	font-size:16px;
    color:<?php echo $body_txt  ?>;
}
.msg_alert_modal{
  animation: bounce_anime 1s linear alternate;
  -webkit-animation: bounce_anime 1s linear alternate;
  border-radius:4px;
            
}                            
.msg_modal-content {
    border-top: 7px solid <?php echo $btn_bg; ?>!important;
    text-align: center;
  	background-color:<?php echo $nav_bar_bg_color; ?>!important;
  border-radius:15px;
  color:<?php echo $body_txt ?>;
}
.auto_bounce{
    animation: bounce_anime 1s linear alternate;
  -webkit-animation: bounce_anime 1s linear alternate;
}
.command_pic_ring{
width:100px;
height:100px;
border-radius:50%;
padding:0px;
display:inline-block;
margin:50px;
    border-top:1px solid #000;
    animation-name: spin;
    animation-duration: 17000ms;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
}
.command_pic_ring2{
width:200px;
height:200px;
border-radius:50%;
box-shadow:1px 1px 1px 1px <?php echo $btn_bg ?>;
padding:0px;
display:inline-block;
    border-top:1px solid #000;
    animation-name: spin;
    animation-duration: 13000ms;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
}



.toast_card 
{
	z-index:99999;   
}
.toast {
    background-color:<?php echo $btn_first_color ?>!important;

}

::-webkit-file-upload-button {
  border-radius: 4px;
  background: linear-gradient(225deg, <?php echo $btn_first_color ?>, <?php echo $btn_second_color?>);
  border:0px;  
  color:<?php echo $btn_txt; ?>;
  padding:4px;
  padding-right:7px;
  padding-left:7px;
}

.border_set{
  border-color:<?php echo $gen_border_color?>!important;
  border-width:<?php echo $gen_border_size; ?>px!important;
}  
.btn_neo{
  border-radius: 4px;
  background: linear-gradient(225deg, <?php echo $btn_first_color ?>, <?php echo $btn_second_color?>);
  border:0px; 
  color:<?php echo $btn_txt ?>;
}

.text-primary{
  color:<?php echo $body_txt;?>!important;
}

.btn_neoo2{
      color:<?php echo $btn_txt ?>;
	border-radius: 4px;
	background: linear-gradient(225deg, <?php echo $btn_first_color ?>, <?php echo $btn_second_color?>);
	/*box-shadow:  -10px 10px 90px <?php echo $btn_first_color ?>,
             10px -10px 50px #ffffff;*/
}

.btn-primary{
  background: linear-gradient(225deg, <?php echo $btn_first_color ?>, <?php echo $btn_second_color?>);
	/*box-shadow:  -10px 10px 90px <?php echo $btn_first_color ?>,
             10px -10px 50px #ffffff;*/
  border:2px;                            
}

.nav-pills .nav-link.active, .nav-pills .show>.nav-link {
  border-radius: 0px;
  background: linear-gradient(225deg, <?php echo $btn_first_color ?>, <?php echo $btn_second_color?>);
	/*box-shadow:  -10px 10px 90px <?php echo $btn_first_color ?>,
             10px -10px 50px #ffffff;*/
  border:0px;  
}
  
.ctn_set
{
   background-color:<?php echo $ctn_bg;?>; 
   color:<?php echo $ctn_txt?>;
}

.btn_set
{
 	background-color:<?php echo $btn_bg;?>; 
 	color:<?php echo $btn_txt?>;
}

.body_set
{
   background-color:<?php echo $body_color;?>; 
   color:<?php echo $body_txt?>;
}
.nav_bar_set
{
 background-color:<?php echo $nav_bar_bg_color;?>; 
 border-bottom:<?php echo $navbar_border_size?>px solid <?php echo $navbar_border_color?>;  
}

.page-item.active .page-link 
{
  color: <?php echo $btn_txt?>;
  background-color: <?php echo  $btn_bg?>;
  border-color: <?php echo  $btn_bg?>;
}

.skin_plasma
{
	height: auto;
	background-color: <?php echo $skin_plasma;?>
}
   /* width */
::-webkit-scrollbar 
{
  width: 8px;
}

/* Track */
::-webkit-scrollbar-track {
  background: <?php echo "#ccc";?>; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: <?php echo $btn_bg; ?>; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
/*------------------------custom theme color scheme  ------------------------------*/
                                
.form-control{
  background-color:transparent;
  border:1px solid <?php echo $gen_border_color?>90!important;
  color:<?php echo $body_txt?>;
}

.form-control:focus {
    color: #495057;
    background-color: #fff;
    border-color: #80bdff!important;
    box-shadow: 0 0 0 .2rem rgba(0, 123, 255, .25);
}


.table {
color:<?php echo "#343a40"?>;
}
.form-group label
{
font-size:14px;
font-weight:600 !important;
padding:0px!important;
margin:0px!important;
}

.cpointer{
    cursor: pointer;
}

.padding_row_gen
{
margin-top: 0px!important;
}
.padding_row
{
margin-top: 0px!important;
}
.navbar-brand{
    font-size:27px;
}

.s_show_title
{

  margin-top:15%;
  
}

@media screen and (max-width: 700px)
{
 

.s_show_title
{

  margin-top:30%;
  
}
 
.badge-primary{
 margin-bottom:10px; 
 color:<?php echo $btn_txt ?>;
}
.msg_alert_modal{
  padding-top:60px!important;
} 

/* width */
::-webkit-scrollbar {
  width: 1px;
}

.padding_row
{
margin-top: 50px!important;
}
    
.navbar-brand{
    font-size:14px;
}

.padding_row_gen
{
margin-top: 50px!important;
}

.skin_plasma
{
height: auto;
}

.text_center_mobi{
text-align:center!important;
}

}
    
</style>
<style type="text/css">
  
.title_text{
 letter-spacing:-0.80px;
}

.paragraph_text{

  font-size:;

}

.description_text{
font-size:12px;
}

::placeholder{
 font-size:14px;
 /*color:#19162c!important;*/
}


.form-control{
height:48px !important;
}

.label_text{
font-size:14px;
font-weight:600 !important;
}

body{
line-height:1.6
}

.btn{
height:48px!important;
line-height:37px!important;
border-radius:20px;
}

  
.table thead tr th {
    box-sizing: border-box;
    text-overflow: ellipsis;
    outline: none;
    text-align: left;
}

.table thead tr{
    height: 56px;
}

.table tbody tr{
    height: 52px;
}

.table tbody tr td{
    box-sizing: border-box;
    text-align: left;
    text-overflow: ellipsis;
    vertical-align:middle
}

.search_input{
  border:1px solid #ccc;
  padding:7px;
  border-radius:20px;
}

.custom-search-input {
  width: 100%;
  border: 1px solid #ccc;
  border-radius: 100px;
  padding: 10px 100px 10px 20px; 
  line-height: 1;
  box-sizing: border-box;
  outline: none;
}
.custom-search-botton {
  position: absolute;
  right: 3px; 
  top: 3px;
  bottom: 3px;
  border: 0;
  background: transparent;
  color: <?php echo $btn_bg?>;
  outline: none;
  margin: 0;
  padding: 0 10px;
  border-radius: 0.5rem !important;
  z-index: 2;
}

.medium_btn{
  display:inline-block;
  padding:10px;
  font-size:14px;
  border-radius:100px;
  white-space:nowrap;
}

  .hive_data_cell{
    padding-right:15px;
    padding-left:15px;
  }
  
  .hive_list_nav_tray{
    padding-top:0px!important;
  }
  .hive_list_search_divider{
      padding-top:10px!important;
  }
@media screen and (max-width: 700px)
{
 
  .medium_btn{
    padding:7px;
    font-size:12px;
    margin-top:0px;
  }
  
  .hive_list_nav_refresh{
   margin-top:0px;
  }
  
  .hive_list_nav_new{
   margin-top:0px;
   margin-left:0px!important;
  }  
  
  .hive_list_nav_tray{
    padding-left:0px!important;
    padding-top:10px!important;
  }
  
  .hive_profile_nav_add_new_tray {
    padding-top: 17px!important;
    text-align: left!important;
    padding-bottom: 12px!important;
    padding-left: 0px;  
    padding-right: 0px;  
  }
  
  .hive_profile_nav_del_btn{
      margin-left:0px!important;
  }
  .hive_profile_navigation{
    
    padding-left:0px!important;
  }
  .hive_profile_navigation{
    padding-top: 0px!important;
    margin-bottom: 0px!important;    
  }
  
  .hive_list_search_divider{
    display:none;
  }
  
  .hive_profile_navigation_divider{
    display:none;
  }
  
  .hive_profile_nav_back_to_list_tray{
    border-bottom: 1px solid;
    border-color:<?php echo "#ccc" ?>;
  }
  .hive_list_search_tray{
      margin-bottom:10px;
  }
  .title_text{
    font-size:18px;
  }
  
  .hive_data_cell{
    padding-right:0px;
    padding-left:0px;
  }
  
}


</style>
<script type="text/javascript">
 	var ajaxw=" WHERE ";
	var ajaxl=" LIKE ";
	var ajaxo =" OR ";
	var ajaxa=" AND ";
	var ajaxe="=";
	var ajaxgb=" group by ";
	var ajaxob=" order by ";
    var ajaxvl ="  \'%' magic_clean_str(this.value) '%\' ";
	var ajaxij= " INNER JOIN ";
	var ajaxon= " ON ";
</script>
