 
//===============Start Mosy queries-============ 

    //Start get  mosy_sql_roll_back Data ===============
    
      function get_mosy_sql_roll_back(mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col, mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination)
      {
        mosyflex_sel("mosy_sql_roll_back", mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col , mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination);
        
      }
    //End get  mosy_sql_roll_back Data ===============

    //Start insert  mosy_sql_roll_back Data ===============

	function add_mosy_sql_roll_back(mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string)
    {
		
        mosyajax_create_data("mosy_sql_roll_back", mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string);
     }
     
    //End insert  mosy_sql_roll_back Data ===============

    
    //Start update  mosy_sql_roll_back Data ===============

    function update_mosy_sql_roll_back(mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string){
    
		mosyajax_update("mosy_sql_roll_back", mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    
    }
    //end  update  mosy_sql_roll_back Data ===============

	//Start drop  mosy_sql_roll_back Data ===============
    function mosy_sql_roll_back_drop(mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    {
        mosyajax_drop("mosy_sql_roll_back", mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)

    }
	//End drop  mosy_sql_roll_back Data ===============
    
    function initialize_mosy_sql_roll_back(qstr="", mosy_sql_roll_back_callback_function_string="")
    {
    
    ///alert(qstr);
      var mosy_sql_roll_back_token_query =qstr;
      if(qstr=="")
      {
       var mosy_sql_roll_back_token_query_param="";
       var mosy_sql_roll_back_js_uptoken=mosy_get_param("mosy_sql_roll_back_uptoken");
       //alert(mosy_sql_roll_back_js_uptoken);
       if(mosy_sql_roll_back_js_uptoken!==undefined)
       {
       
        mosy_sql_roll_back_token_query_param = atob(mosy_sql_roll_back_js_uptoken);
       }
        mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_token_query_param)+"'";
        
           if (document.getElementById("mosy_sql_roll_back_uptoken") !==null) {
           	if(document.getElementById("mosy_sql_roll_back_uptoken").value!="")
            {
            
            var mosy_sql_roll_back_atob_tbl_key =atob(document.getElementById("mosy_sql_roll_back_uptoken").value);
            
                   
            mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_atob_tbl_key)+"'";

            }
           }
      }
      
      var mosy_sql_roll_back_push_ui_data_to =mosy_sql_roll_back_callback_function_string;
      if(mosy_sql_roll_back_callback_function_string=="")
      {
      mosy_sql_roll_back_push_ui_data_to = "add_mosy_sql_roll_back_ui_data";
      }
                
      console.log(mosy_sql_roll_back_token_query+" -- "+mosy_sql_roll_back_js_uptoken);

	  //alert(mosy_sql_roll_back_push_ui_data_to);

     get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    }
    
    function add_mosy_sql_roll_back_ui_data(mosy_sql_roll_back_server_resp) 
    {
    
    ///alert(mosy_sql_roll_back_server_resp);
    
    var json_decoded_str=JSON.parse(mosy_sql_roll_back_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load mosy_sql_roll_back data on the fly ==============
    
	var gft_mosy_sql_roll_back_str="(roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
    
    function  gft_mosy_sql_roll_back(qmosy_sql_roll_back_str)
    {
        	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(qmosy_sql_roll_back_str));
            
            return  clean_mosy_sql_roll_back_filter_str;

    }
    
    function load_mosy_sql_roll_back(mosy_sql_roll_back_qstr, mosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, mosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray)
    {
    
    var fmosy_sql_roll_back_result_function="push_result";
      
    if(mosy_sql_roll_back_result_function!="")
    {
          var fmosy_sql_roll_back_result_function=mosy_sql_roll_back_result_function;

    }
    	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(mosy_sql_roll_back_qstr));
        
        var fmosy_sql_roll_back_where_str=" where "+clean_mosy_sql_roll_back_filter_str;

    if(mosy_sql_roll_back_where_str!="")
    {
          var fmosy_sql_roll_back_where_str=" "+mosy_sql_roll_back_where_str;

    }
       
      get_mosy_sql_roll_back("*", fmosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, fmosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray);
      
    }
    ///=============== load mosy_sql_roll_back data on the fly ==============


 ///=quick load 
 
function qkload_mosy_sql_roll_back(qstr, push_fun="", ui_card="", and_query="", additional_cols="", mosy_sql_roll_back_pagination="")
{

	var mosy_sql_roll_back_list_nodes_str=mosy_sql_roll_back_list_nodes;
  
   if(ui_card!="")
   {
      mosy_sql_roll_back_list_nodes_str=ui_card;
   }
   
   var mosy_sql_roll_back_qret_fun="push_grid_result:mosy_sql_roll_back_tbl_list";
   
   if(push_fun!="")
   {
    mosy_sql_roll_back_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_mosy_sql_roll_back("*", ajaxw+" ("+gft_mosy_sql_roll_back(qstr)+") "+combined_query+"  order by primkey desc ", mosy_sql_roll_back_list_cols+additional_cols_str, "",mosy_sql_roll_back_qret_fun, "c=>"+mosy_sql_roll_back_list_nodes_str, mosy_sql_roll_back_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_mosy_sql_roll_back(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_mosy_sql_roll_back("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmosy_sql_roll_back_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_mosy_sql_roll_back("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    

}



//sum 

function sum_mosy_sql_roll_back(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_mosy_sql_roll_back("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function mosy_sql_roll_back_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function mosy_sql_roll_back_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function mosy_sql_roll_back_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemosy_sql_roll_back&mosy_sql_roll_back_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_mosy_sql_roll_back_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('mosy_sql_roll_back')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  notification_manifest_ Data ===============
    
      function get_notification_manifest_(notification_manifest__colstr, notification_manifest__filter_col, notification_manifest__cols, notification_manifest__node_function_name, notification_manifest__callback_function_string, notification_manifest__ui_tag, notification_manifest__pagination)
      {
        mosyflex_sel("notification_manifest_", notification_manifest__colstr, notification_manifest__filter_col , notification_manifest__cols, notification_manifest__node_function_name, notification_manifest__callback_function_string, notification_manifest__ui_tag, notification_manifest__pagination);
        
      }
    //End get  notification_manifest_ Data ===============

    //Start insert  notification_manifest_ Data ===============

	function add_notification_manifest_(notification_manifest__cols, notification_manifest__vals, notification_manifest__callback_function_string)
    {
		
        mosyajax_create_data("notification_manifest_", notification_manifest__cols, notification_manifest__vals, notification_manifest__callback_function_string);
     }
     
    //End insert  notification_manifest_ Data ===============

    
    //Start update  notification_manifest_ Data ===============

    function update_notification_manifest_(notification_manifest__update_str, notification_manifest__where_str, notification_manifest__callback_function_string){
    
		mosyajax_update("notification_manifest_", notification_manifest__update_str, notification_manifest__where_str, notification_manifest__callback_function_string)
    
    }
    //end  update  notification_manifest_ Data ===============

	//Start drop  notification_manifest_ Data ===============
    function notification_manifest__drop(notification_manifest__where_str, notification_manifest__callback_function_string)
    {
        mosyajax_drop("notification_manifest_", notification_manifest__where_str, notification_manifest__callback_function_string)

    }
	//End drop  notification_manifest_ Data ===============
    
    function initialize_notification_manifest_(qstr="", notification_manifest__callback_function_string="")
    {
    
    ///alert(qstr);
      var notification_manifest__token_query =qstr;
      if(qstr=="")
      {
       var notification_manifest__token_query_param="";
       var notification_manifest__js_uptoken=mosy_get_param("notification_manifest__uptoken");
       //alert(notification_manifest__js_uptoken);
       if(notification_manifest__js_uptoken!==undefined)
       {
       
        notification_manifest__token_query_param = atob(notification_manifest__js_uptoken);
       }
        notification_manifest__token_query = " where primkey='"+(notification_manifest__token_query_param)+"'";
        
           if (document.getElementById("notification_manifest__uptoken") !==null) {
           	if(document.getElementById("notification_manifest__uptoken").value!="")
            {
            
            var notification_manifest__atob_tbl_key =atob(document.getElementById("notification_manifest__uptoken").value);
            
                   
            notification_manifest__token_query = " where primkey='"+(notification_manifest__atob_tbl_key)+"'";

            }
           }
      }
      
      var notification_manifest__push_ui_data_to =notification_manifest__callback_function_string;
      if(notification_manifest__callback_function_string=="")
      {
      notification_manifest__push_ui_data_to = "add_notification_manifest__ui_data";
      }
                
      console.log(notification_manifest__token_query+" -- "+notification_manifest__js_uptoken);

	  //alert(notification_manifest__push_ui_data_to);

     get_notification_manifest_("*", notification_manifest__token_query, "primkey", "blackhole", notification_manifest__push_ui_data_to, "");
    }
    
    function add_notification_manifest__ui_data(notification_manifest__server_resp) 
    {
    
    ///alert(notification_manifest__server_resp);
    
    var json_decoded_str=JSON.parse(notification_manifest__server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load notification_manifest_ data on the fly ==============
    
	var gft_notification_manifest__str="(notific_key LIKE '%{{qnotification_manifest_}}%' OR  notification_type LIKE '%{{qnotification_manifest_}}%' OR  notification_state LIKE '%{{qnotification_manifest_}}%' OR  notification_icon LIKE '%{{qnotification_manifest_}}%' OR  notification_title LIKE '%{{qnotification_manifest_}}%' OR  notification_link LIKE '%{{qnotification_manifest_}}%' OR  notification_read_state LIKE '%{{qnotification_manifest_}}%' OR  notification_time_stamp LIKE '%{{qnotification_manifest_}}%' OR  notif_remark LIKE '%{{qnotification_manifest_}}%')";
    
    function  gft_notification_manifest_(qnotification_manifest__str)
    {
        	var clean_notification_manifest__filter_str=gft_notification_manifest__str.replace(/{{qnotification_manifest_}}/g, magic_clean_str(qnotification_manifest__str));
            
            return  clean_notification_manifest__filter_str;

    }
    
    function load_notification_manifest_(notification_manifest__qstr, notification_manifest__where_str, notification_manifest__ret_cols, notification_manifest__user_function, notification_manifest__result_function, notification_manifest__data_tray)
    {
    
    var fnotification_manifest__result_function="push_result";
      
    if(notification_manifest__result_function!="")
    {
          var fnotification_manifest__result_function=notification_manifest__result_function;

    }
    	var clean_notification_manifest__filter_str=gft_notification_manifest__str.replace(/{{qnotification_manifest_}}/g, magic_clean_str(notification_manifest__qstr));
        
        var fnotification_manifest__where_str=" where "+clean_notification_manifest__filter_str;

    if(notification_manifest__where_str!="")
    {
          var fnotification_manifest__where_str=" "+notification_manifest__where_str;

    }
       
      get_notification_manifest_("*", fnotification_manifest__where_str, notification_manifest__ret_cols, notification_manifest__user_function, fnotification_manifest__result_function, notification_manifest__data_tray);
      
    }
    ///=============== load notification_manifest_ data on the fly ==============


 ///=quick load 
 
function qkload_notification_manifest_(qstr, push_fun="", ui_card="", and_query="", additional_cols="", notification_manifest__pagination="")
{

	var notification_manifest__list_nodes_str=notification_manifest__list_nodes;
  
   if(ui_card!="")
   {
      notification_manifest__list_nodes_str=ui_card;
   }
   
   var notification_manifest__qret_fun="push_grid_result:notification_manifest__tbl_list";
   
   if(push_fun!="")
   {
    notification_manifest__qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_notification_manifest_("*", ajaxw+" ("+gft_notification_manifest_(qstr)+") "+combined_query+"  order by primkey desc ", notification_manifest__list_cols+additional_cols_str, "",notification_manifest__qret_fun, "c=>"+notification_manifest__list_nodes_str, notification_manifest__pagination);
                  
}


////////////// arithmetic function 


//count 

function count_notification_manifest_(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_notification_manifest_("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qnotification_manifest__ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_notification_manifest_("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_notification_manifest_("*", notification_manifest__token_query, "primkey", "blackhole", notification_manifest__push_ui_data_to, "");
    

}



//sum 

function sum_notification_manifest_(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_notification_manifest_("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function notification_manifest__ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "notification_manifest__insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function notification_manifest__updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "notification_manifest__update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function notification_manifest__rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletenotification_manifest_&notification_manifest__uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_notification_manifest__updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('notification_manifest_')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
  //===============End Mosy queries-============

const mosy_msdn_elem = document.querySelectorAll('.mosy_msdn');

mosy_msdn_elem.forEach(el => el.addEventListener('click', event => {

var arguments = event.target.getAttribute("data-mosy_msdn");
  
eval(arguments);

}));

const mosy_tup_elem = document.querySelectorAll('.mosy_tup');

mosy_tup_elem.forEach(el => el.addEventListener('keyup', event => {

var arguments = event.target.getAttribute("data-mosy_tup");
  
eval(arguments);

}));
  
var ajax_url ="./ajaxreqhandler.php";
var mosyajax_sql_url=ajax_url;
   //Ajax Manager
function mosyflex_sel(tbl, colstr, filter_col , cols, node_function_name, callback_function_string, ui_tag, pagination="")
{
//alert(filter_col);
///alert(pagination);

    var clean_ui1=ui_tag.replace(/</g, "{{<}}");
    var clean_ui2=clean_ui1.replace(/>/g, "{{>}}");
    var clean_ui3=clean_ui2.replace(/onclick/g, "{{on click}}");
    var clean_ui4=clean_ui3.replace(/onkeyup/g, "{{on keyup}}");
    var clean_ui5=clean_ui4.replace(/onchange/g, "{{on change}}");
    var clean_ui=btoa(clean_ui5);
    
  	var pagination_token=1;
    var pagination_name=pagination;
    
    if(pagination.indexOf(":") >= 0)
  	{
      pagination_token_expl=pagination.split(":");
      pagination_token=pagination_token_expl[1];
      pagination_name=pagination_token_expl[0];
    }
    
  
    var json_params_str={"mosyajax_sql_data":filter_col, "colstr":colstr, "cols":cols, "node_function_name":node_function_name, "tbl":tbl, "ui_tag":clean_ui,"pagination":pagination_name};
   
  	//alert(clean_ui);
  
  //alert(pagination_name);
  //alert(pagination_token);
  
    if(pagination_token>1)
    {
		mosy_ajax_post(ajax_url+"?"+pagination_name+"="+btoa(pagination_token), json_params_str, callback_function_string, "");
    }else{
		mosy_ajax_post(ajax_url, json_params_str, callback_function_string, "");

    }
}


function mosy_next_page(elem_id)
{
  if(get_newval(elem_id)=="")
  {
  	push_newval(elem_id,0)
  }
  var next_token_no=parseInt(get_newval(elem_id))+1;
  
  push_newval(elem_id, next_token_no);
  
  return next_token_no;
}

function mosy_prev_page(elem_id)
{
  if(get_newval(elem_id)=="")
  {
  	push_newval(elem_id,0)
  }
  var next_token_no=parseInt(get_newval(elem_id))-1;
  
  if(next_token_no<=0)
  {
  next_token_no=1;
  }
  
  push_newval(elem_id, next_token_no);
  
  return next_token_no;
}

function push_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp+'<div class="col-md-12 p-0 text-right"><span class="badge cpointer" style="font-size:10px;"><i class="fa fa-times-circle"></i> Close</span></div>';
  
  if(server_resp.toString().trim()=='')
  {
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray"> <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
  }
  
  
  if (document.getElementById(additional_callbacks) !==null) {
        
  document.getElementById(additional_callbacks).style.display="block";
  document.getElementById(additional_callbacks).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}



function push_grid_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp;
  
  var tbl_col_str="";
  var tbl_colspan ="";
  var elem_id=additional_callbacks;

  var empty_state_str="";
  
  if(additional_callbacks.indexOf(":") >= 0)
  {
     tbl_col_str=additional_callbacks.split(":");
     
     tbl_colspan=tbl_col_str[1];
     
     elem_id=tbl_col_str[0];

	if(typeof tbl_col_str[2] !== 'undefined') 
    {
     var empty_state_str = tbl_col_str[2];
    }

  }
///alert(additional_callbacks);
  if(server_resp.toString().trim()=='')
  {
  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid" > <td colspan="'+tbl_colspan+'" style="text-align:center;"><div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div></td> </tr>';
    if(empty_state_str!="")
    {
    var str_to_display =window[empty_state_str];
    
    }
    }else{
        
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
    
    if(empty_state_str!="")
    {
    var str_to_display =window[empty_state_str];
    
    }
    }
  }
  
  
  if (document.getElementById(elem_id) !==null) {
        
  ///document.getElementById(elem_id).style.display="block";
  document.getElementById(elem_id).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}

function mosy_empty_state(top_msg="", btm_msg="", tbl_colspan="")
{

    var str_to_display="";

  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid " > <td colspan="'+tbl_colspan+'" style="text-align:center;">'+top_msg+'<hr><div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"> '+btm_msg+'</div></td> </tr>';
 
    }else{
        
  	 str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12">'+top_msg+'<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"> '+btm_msg+'</div> </div>';
    
 
    }


///alert(str_to_display);

  return str_to_display;

}


function push_val(arrkeys, arrvalues)
{
    var r = {},i;
    
    for (let i = 0; i < arrkeys.length; i++) {
        r[arrkeys[i]] = arrvalues[i];
      document.getElementById(arrvalues[i]).value=[arrkeys[i]];
    }

}

    function qddata(server_resp,callbacks)
    {
    //alert(server_resp);
    var retjson = JSON.parse(server_resp)[0];
    
        ///alert(retjson.name);


    return retjson;
    
    
    }
function mosy_ajax_post(post_url, json_params, callback_function_string, additional_callbacks)
{


	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
         split_fun_str=callback_function_string.split(/:(.*)/s);
         
		 fcall_back_function =  split_fun_str[0];
        
         fadditional_callbacks =  split_fun_str[1] ;
    
    }
    
    if (document.getElementById(fadditional_callbacks) !==null) {
      ////  document.getElementById(fadditional_callbacks).style.display="block";
    	///document.getElementById(fadditional_callbacks).innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... '+document.getElementById(fadditional_callbacks).innerHTML;
        
    }
    
       if (document.getElementById("ajax_spinner") !==null) 
       {
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';

       }else{
       	mosy_snack_wgt("Processing request...", "top", "ajax_snack", "200px", "ajax_snack_id", "#000",  "#fff", "");
    
    	mosytoggle_class("ajax_snack_id", "show");
        
       }
       
       
  	var formData = ((json_params)); //Array 
  
      $.ajax({ 
      url: post_url,
      type: "POST",
      data:formData,

      success: function (data) 
      {
        //alert(data);
       if (document.getElementById("ajax_spinner") !==null) 
       {
       
         var result_response_='<i class="fa fa-info-circle"></i> Request Processed Succesfully.';
		
        	if(data=='')
            {
            
        		var result_response_='<i class="fa fa-info-circle"></i> No data .';
            
            }
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML=result_response_;

       } 
       
       push_html("ajax_snack", "");                                          

        window[fcall_back_function](data, fadditional_callbacks);

      }

  })
  
}  


   //Ajax Manager

function mosyajax_create_data(tbl, tbl_cols, tbl_vals, callback_function_string)
{
  ///alert(tbl_cols+" - "+tbl_vals);
  
    var json_params_str={"mosyajax_create":"ok", "tbl_cols":tbl_cols, "tbl_vals":tbl_vals, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

   //Ajax Exe
function mosyajax_update(tbl, update_str, where_str, callback_function_string)
{
  //alert(update_str);
  
    var json_params_str={"mosyajax_update":"ok", "update_str":update_str, "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

function mosyajax_drop(tbl, where_str, callback_function_string)
{
  //alert(where_str);
  
    var json_params_str={"mosyajax_drop":"ok", "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}


function mosyajax_get(getstr, callback_function_string)
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = "";
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
    if (document.getElementById("ajax_spinner") !==null) 
    {
        
      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

  	}

    $.ajax({
      url: ajax_url+"?"+getstr,
      type: 'GET',
      success: function(res) {
       if (document.getElementById("ajax_spinner") !==null) {

          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

       }              
            //alert(res);
        window[fcall_back_function](res, fadditional_callbacks);

          }
      });
}


function mosy_validate_required(required_inp=null, show_dial='yes')
{
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+"</b><br>";
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, "False")=="False")
      {
      
       var required_state="1";
      
      }else{
      
        var required_state="0";
        if(show_dial=='yes')
        {

          magic_message(validate_msg, 'dialog_box');

        }
      }
  
  return required_state ;
}

function mosy_form_data(form_id,  save_action, callback_function_string, additional_callbacks, required_inp="")
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
	var formData = new FormData(document.getElementById(form_id));
  
    if (document.getElementById("ajax_spinner") !==null) {
        
    	document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';
        
    }
    
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
   ///alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
    {

	formData.append(save_action, "ok");
	formData.append('mosyrequest_type', "ajax");
        $.ajax({
            type: "POST",
            url: ajax_url,
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
                  if (document.getElementById("ajax_spinner") !==null) {
        
                      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

                  }
              ///alert(data);
        		window[fcall_back_function](data, fadditional_callbacks);
            },
	    complete: function(){
			//alert("Data uploaded successfully.");
	    },
	    error: function (jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
	    } 
        });
      // Display the key/value pairs
      for (var pair of formData.entries()) {
          ///console.log(pair[0]+ ", " + pair[1]); 
      }
        	  
     }else{
        magic_message(validate_msg, 'dialog_box');
      }
      
      
}

function blackhole(data)
{

}

function show_password(input_name) 
{
  var x = document.getElementById(input_name);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}


function get_newval(elemid)
{
    if (document.getElementById(elemid) !==null) {

	  return document.getElementById(elemid).value;
    }else{
  
  return "";
  }
}

function mosy_response(server_resp, callbacks)
{

	alert("server_resp"+server_resp+" -- Callbacks "+callbacks);

}

function get_html(elemid)
{
    if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).innerHTML;
  }else{
  
  return "";
  }
}

function get_src(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).src;
  }else{
  
  return "";
  }
}

function get_href(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).href;
  }else{
  
  return "";
  }
}


function push_ddown(server_items, selelem)
{

	$('#'+selelem+' option:not(:first)').remove();

	document.getElementById(selelem).innerHTML=document.getElementById(selelem).innerHTML+server_items;

}
//========= formart to num =================

function tonum(req_number, decplc=0)
{

///alert(req_number);

n = parseFloat(req_number).toFixed(decplc)
var withCommas = Number(n).toLocaleString('en');


return withCommas;
}

//========= formart to num =================

function mosy_qstr(string, query_str)
{
    
   if(string.indexOf(query_str)==-1)
    {
      
      var q_str_state="False";
      
    }else{
    
	  var q_str_state="True";
     
	}
    
  return q_str_state;
    
}
function mosy_refresh(new_location)
{

var new_location_str=window.location.href;

  window.location=new_location_str.replace("table_alert", "tbl_alert_old");

}

function mosy_srefresh(server_resp, new_location)
{

  window.location=new_location;

}
////////////////// ===================  js action listener ================  

  var _js_msdn=document.querySelectorAll('js_msdn');
  
  _js_msdn.forEach(el => el.addEventListener('click', event => {
  
  var _mosy_jsmsdn_event_trgt= event.currentTarget;

  
	 _mosy_jsmsdn_jsaction="";
	 _mosy_jsmsdn_arg="";
     
  if (!_mosy_jsmsdn_event_trgt.hasAttribute("data-mosy_js")) 
  {
    // data attribute doesnt exist
  }else{
  
	 _mosy_jsmsdn_jsaction=_mosy_jsmsdn_event_trgt.getAttribute("data-mosy_js");
	 _mosy_jsmsdn_arg=_mosy_jsmsdn_event_trgt.getAttribute("data-_mosy_jsmsdn_arg");
     
  }

     window[_mosy_jsmsdn_jsaction](_mosy_jsmsdn_arg);

  
}));
  
  
  
////////////////// ==================  js action listener ================  



function pop_filter_tray (data_src, card_title, where_str_req,cols,returnfun)
{
  magic_screen(pop_data_filter_card, "alert_box");
        
  var where_str =" and "+(where_str_req);
  var where_str_inp =" and "+magic_clean_str(where_str_req);
  
  if(where_str_req=="")
  {
    var where_str="";
    var where_str_inp ="";
  }
  
  var load_data_set ="load_"+data_src;
  var gft_data_str="gft_"+data_src;
  ///alert(where_str);
  window[load_data_set]("", ajaxw+" "+window[gft_data_str]("")+where_str, cols, returnfun, "push_result:result","card");
  
  //alert(cols);
  var textbox ='<input type="text" class="form-control" onkeyup="'+load_data_set+'(this.value, \''+ajaxw+' \'+'+gft_data_str+'(this.value)+\''+where_str_inp+'\', \''+magic_clean_str(cols)+'\', \''+returnfun+'\', \'push_result:result\',\'card\')" placeholder="Type your search here"/>';
        
  document.getElementById('card_title').innerHTML=card_title;
  document.getElementById('dope_text').innerHTML=textbox;

        
}


function mosytoggle_elem(elemid, new_val)
{
  if(new_val=='')
  {
  if(document.getElementById(elemid).style.display!='none')
  {
    document.getElementById(elemid).style.display='none';
  }else{
    document.getElementById(elemid).style.display='block';
  }
  }else{
    document.getElementById(elemid).style.display=new_val;
  }
}

function tray_uptoken(datakey,callbacks)
{
  
  window.location=callbacks[0]+'?'+callbacks[1]+'_uptoken='+btoa(datakey[0]);
}

var pop_data_filter_card=`
    <h5><i class="fa fa-search mr-2"></i><span id="card_title"></span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  	<div id="dope_text" class="col-md-12"></div>
	<div id="result" class="col-md-12" style="max-height:300px; overflow-y:auto;" onclick="this.style.display='none'"></div>
    
  	<div id="r" class="col-md-12 row justify-content-center m-0 p-0 mt-3">
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5 mr-lg-3" id="pop_tray_location"> 
        	View All <i class="fa fa-arrow-right"></i> 
        </a>
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5" id="new_pop_tray_location"> 
        	<i class="fa fa-plus" id="newclass"></i> 
        	<span id="new_record_label"> Add new </span> 
        </a>
    </div>
  </div>`;
  
function push_link(new_link,anchor_el)
{

	//alert(new_link);
	document.getElementById(anchor_el).href=new_link;

}


function push_html(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

	  document.getElementById(elemid).innerHTML=new_val;
      
      }
}

function push_newval(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

  		document.getElementById(elemid).value=new_val;
  
  }
}

function push_src(elemid, new_val)
{
	  if (document.getElementById(elemid) !==null) 
      {

	  		document.getElementById(elemid).src=new_val;
      
      }
}

function mosytoggle_class(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_addclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    //document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_remclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }
  
}


function mosyhide_elem(elemid, new_class="")
{
    var curr_class="none";
    if(new_class!="")
    {
    curr_class=new_class;
    }
    	
   if (document.getElementById(elemid) !==null) 
   {
   	document.getElementById(elemid).style.display=curr_class;
   }
}

function mosyshow_elem(elemid, new_class="")
{
    var curr_class="block";
    if(new_class!="")
    {
    curr_class=new_class;
    }
   if (document.getElementById(elemid) !==null) 
   {
   	document.getElementById(elemid).style.display=curr_class;
   }
}

function mosy_get_param(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}


function mosy_push_data(elemid,data)
{
	var elem_state ="false";
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      
      push_newval(elemid, data);
      push_html(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, "<option>"+data+"</option>"+get_html(elemid));
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  
}

function check_elem(elemid)
{
    if (document.getElementById(elemid) ===null) 
    {
    alert("element_"+elemid+" Not available");
    }
}

function push_shtml(server_res, callback)
{
  
  magic_message(callback, "dialog_box");
  
}
function mosy_push_num_ddata(_server_resp, elemid_str)
{
	//alert(_server_resp);
    
	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = (elemid_arr[0]);
        
          data_str = elemid_arr[1];
          
          console.log(elemid+" state "+ data_str+" serep "+_server_resp);

         data = tonum(json_decoded_str[data_str]);
        
    }
    
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
            
      push_html(elemid, data);
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function mosy_push_ddata(_server_resp, elemid_str)
{

///alert(_server_resp);

	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = elemid_arr[0];
        
          data_str = elemid_arr[1];
          

         var data = json_decoded_str[data_str];
        
    }else{

		var data = json_decoded_str[data_str];

    }
              
    console.log(elemid+" state "+ data_str+" serep "+_server_resp);

    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      push_html(elemid, data);      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function dope_token(token_url="", token_key="")
{
window.history.replaceState(null, null, "?"+token_url+"="+token_key+"");
}

function mosyrename_elem(elemid, newname)
{
    if (document.getElementById(elemid) !==null) 
    {
      document.getElementById(elemid).id=newname;
      document.getElementById(newname).setAttribute("name",newname);
    }
}
///////////////  slide show 
function mosy_slide_wgt(image_arr_n_captions, img_style, img_class, extra_attr, slide_indicators_yes_no)
{
  
const rem_array = image_arr_n_captions.slice(0, 0).concat(image_arr_n_captions.slice(0+1, image_arr_n_captions.length));
  
var curr_slide_id =magic_random_str(10);
    
var img_string =  image_arr_n_captions[0];
var caption_str = ""
var caption_str_div="";
var datakey = "";
  
if(image_arr_n_captions[0].includes(":"))
{
 img_string =  image_arr_n_captions[0].substring(0, image_arr_n_captions[0].indexOf(':')); 
 datakey_1 = image_arr_n_captions[0].substring(image_arr_n_captions[0].indexOf(':')+1); 
 datakey = datakey_1.substring(0, datakey_1.indexOf(':'));
 datakey_2 = datakey_1.substring(datakey_1.indexOf(':')+1);
 caption_str = datakey_2.substring(datakey_2.indexOf(':'));
 caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${caption_str} </div>`;
}
  ///alert("dkey1 -- "+datakey_2);
 var slide_node="";
 var slidecounter="";
 var i=0;
  
 if(slide_indicators_yes_no=='yes')
 {
   slidecounter=`<li data-target="#slide_s${curr_slide_id}" data-slide-to="0" class="active"></li>`;
 }
 for(img_arr of rem_array)
 {
   i++;
   
	if(slide_indicators_yes_no=='yes'){
 slidecounter+=`
        <li data-target="#slide_s${curr_slide_id}" data-slide-to="${i}" class="active"></li>
   `;  
    }
   
   var loop_img_string =  img_arr;
   var loop_caption_str = "";
   var loop_caption_str_div="";
   var loop_datakey="";
   
   if(img_arr.includes(":")){
 	loop_img_string =  img_arr.substring(0, img_arr.indexOf(':')); 
 	loop_datakey_1 = img_arr.substring(img_arr.indexOf(':')+1); 
 	loop_datakey = loop_datakey_1.substring(0, loop_datakey_1.indexOf(':'));
 	loop_datakey_2 = loop_datakey_1.substring(loop_datakey_1.indexOf(':')+1);
 	loop_caption_str = loop_datakey_2.substring(loop_datakey_2.indexOf(':'));
 	loop_caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${loop_caption_str} </div>`;
   }
   
   slide_node+=`   
            <!-- carousel item -->
            <div class="carousel-item">
             <div class="row pt-3 justify-content-center">
     			${loop_caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${loop_img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${loop_datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->`;
   
 }
  
var slide_tray=`
      <!--------------- Start carousel ---------->
      <div id="slide_s${curr_slide_id}" class="carousel slide w-100" data-ride="carousel" data-interval="2000">
        <ol class="carousel-indicators mt-2">
  		${slidecounter}
        </ol>
        <!-- carousel inner -->
          <div class="carousel-inner">
            <!-- carousel item -->
            <div class="carousel-item active">
             <div class="row pt-3 justify-content-center">
          	   ${caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->
		   ${slide_node}
            <!-- carousel inner -->
            <a class="carousel-control-prev" href="#slide_s${curr_slide_id}" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a class="carousel-control-next" href="#slide_s${curr_slide_id}" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a> 
          </div>
             
      </div>
      <!--------------- End carousel ---------->
        `;
  
return [slide_tray, curr_slide_id];  
}
///////////////  slide show 

//////////////  image alert 
function mosy_img_pop(img_src,img_style, img_class,  extra_attr, slide_show_yes_no)
{
  var img_tray=
    `
    <img src="${img_src}" style="${img_style}" class="${img_class}"/>
    
    `;
  
  if(slide_show_yes_no=='yes')
  {
    
    var pop_tray_carousel = mosy_slide_wgt(img_src, img_style, img_class, extra_attr)[0];
    
    magic_screen(pop_tray_carousel, 'alert_box');
    
  }else{
  	magic_screen(img_tray, 'alert_box');
  }
  
}  

//////////////  image alert \

function mosy_snack_wgt(content, curr_position, push_to, snack_pos, snackid, color, bg, onclick_fun)
{
              
var snack_cont=`
<style>
/* The snackbar - position it at the bottom and in the middle of the screen */
#${snackid} {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background:${bg}; /* Black background color */
  color: ${color}; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 9999; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  ${curr_position}: ${snack_pos}; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#${snackid}.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}

@keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}
</style>
  
  <div id="${snackid}" onclick="${onclick_fun};push_html('${push_to}', '')">${content}</div>

  `;


push_html(push_to, snack_cont);


} 

function new_location(new_location_str)
{
window.location=new_location_str;
}

function mosy_reload()
{
   document.location.reload()

} 

function glass_modal()
{
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("background-color", "transparent", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border-top", "0px solid", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border", "0px solid", "important");;
}

function mosy_card(card_title="", card_content, attach_To)
{
	var mosy_card_title="";
    if(card_title!="")
    {
    var mosy_card_title=`
                          <!-- Start  Title ribbon-->
                      <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                        <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                        <div class="col-md-8 text-center"><b> ${card_title}</b></div>
                        <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                      </h5>
                      <!-- End Title ribbon--> 
    `;
    }
    var link_pop=`
    <div class="row justify-content-center m-0 p-0 col-md-12">
						${mosy_card_title}
                      <div class="row justify-content-center m-0 p-0 col-md-12 mt-3 mb-3">
                        ${card_content}
                      </div>
      </div>
    </div>

    `;

    if(attach_To=='' || attach_To==undefined)
    {
    magic_screen(link_pop, 'alert_box');
    }else{
      push_html(attach_To, link_pop);
    }

    return link_pop;
 
}

  
function filter_by_date(card_title,filter_link,filter_col,and_query='',trailing_space="")
{

var def_date = mosy_ymd();
var pop_filter_date=`
    <h5>Filter by <span id="filter_title"> ${card_title} </span></h5>
  <div class="row justify-content-center m-0 p-0 col-md-12">
	<div class="form-group col-md-6">
		<label >Start Date</label>
		<input class="form-control" id="txt_start_date" name="" value="${def_date}" placeholder="Your Name" type="date">
	</div>
  	<div class="form-group col-md-6">
		<label >End Date</label>
		<input class="form-control" id="txt_end_date"  name="" value="${def_date}" placeholder="Your Name" type="date">
	</div>
    <input type="hidden" id="txt_mosy_filter_q" value="${filter_col}" />
    <input type="hidden" id="txt_mosy_and_query" value="${and_query}" />
  <div class="col-md-7 cpointer btn_neoo2 btn-primary text-center" onclick=" go_to_date('${filter_link}', get_newval('txt_start_date'), get_newval('txt_end_date'), get_newval('txt_mosy_filter_q'), get_newval('txt_mosy_and_query'), '${trailing_space}')"><i class="fa fa-arrow-right"></i> Proceed </div>
  </div>
  `;
  
  mosy_card('', pop_filter_date);
  
  return pop_filter_date;
  
}
  
function go_to_date(filter_link, start_date, end_date, filter_col, and_query, trailing_space)
{
  var filter_location=filter_link+"="+btoa(trailing_space+"DATE_FORMAT("+filter_col+", '%Y-%m-%d') >='" +start_date+"' AND DATE_FORMAT("+filter_col+", '%Y-%m-%d') <='" +end_date+ "' "+and_query+" ");
  ///alert(filter_location);
  window.location=filter_location;
  
}

function mosy_ymd(date='') {
return new Date().toISOString().slice(0, 10);

}


function mosy_modal(modal_content, attach_To="alert_box", parent_id="")
{

  if(attach_To=="")
  {
  	attach_To="alert_box"
  }
  var mosy_modal_tray =`
  <div class="col-md-12 mosy_modal rounded_big p-0 m-0 bg-white shadow  border border_set ">
    <div class="col-md-12 pt-2 text-right"><span class="cpointer "  onclick="push_html('${attach_To}','')"><i class="fa fa-times-circle"></i></span></div>
    <div class="row justify-content-center m-0 p-0 col-md-12" id="${parent_id}">
    	${modal_content}
    </div>
  </div>`;

  ///alert(mosy_modal_tray);

  push_html(attach_To, mosy_modal_tray);

  return mosy_modal_tray;

}


  function mosy_print_elem(print_div,doc_title="", header_layout="") 
  {
  
  		var print_title=`
        <h3 class="col-md-12 p-3">${doc_title}</h3>
        `;
        //Get the HTML of div
        var divElements = header_layout+print_title+document.getElementById(print_div).innerHTML;
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //Reset the pages HTML with divs HTML only
        document.body.innerHTML = 
          `<html><head><title></title>
          <style>

            .table thead th 
            {
              white-space: nowrap;
              padding: 1px;
              vertical-align: top;
              border-top: 1px solid #dee2e6;
              font-size: 12px;
            }
            .table tbody td 
            {
              white-space: nowrap;
              padding: 1px;
              vertical-align: top;
              border-top: 1px solid #dee2e6;
              font-size: 12px;
            }
            a{
            color:#000;
            }    
           </style>
          </head>
         <body>` + 
          divElements + "</body>";
        //Print Page
        window.print();
        //Restore orignal HTML
        document.body.innerHTML = oldPage;
        mosy_reload();

    }


function mosy_decode_json(json_server_resp, arr_node)
{
  var decode_resp=JSON.parse(json_server_resp);
    
  if(arr_node.indexOf("|") >= 0)
  {
   
   		var elemid_arr = arr_node.split("|");
        
		var elemid = (elemid_arr[1]);
        
        var data_str = elemid_arr[0]; 
    
        mosy_push_data(elemid, decode_resp[data_str]);
        
        var ret_data = decode_resp[data_str];
  }else{
    
	var ret_data = decode_resp[arr_node];
    
  }
  
  return ret_data ;
  ////alert(decode_resp[arr_node]);
}
//<--ncgh-->
