<?php 
include('./be/data_control/phpmagicbits.php');
include('./appdna/blueprint.php');

if(isset($_GET['export_feature']))
{
 $feature_code=$_GET['export_feature'];
  
 echo file_get_contents(str_replace("../","./",$features_folder).'/'.$feature_code);
  
}

?>