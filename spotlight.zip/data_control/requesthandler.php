<?php 
//===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section mosy_sql_roll_back
  //************************************************* START  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize mosy_sql_roll_back edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['mosy_sql_roll_back_table_alert']))
              	{	
                  if(isset($mosy_sql_roll_back_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$mosy_sql_roll_back_uptoken="";

		if(isset($_GET["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_GET["mosy_sql_roll_back_uptoken"]);
		}
        
        if(isset($_POST["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_POST["mosy_sql_roll_back_uptoken"]);
		}
        //
        
          $mosy_sql_roll_back_alias_name="MOSY SQL ROLL BACK";

          if(isset($mosy_sql_roll_back_alias))
          {
             $mosy_sql_roll_back_alias_name=$mosy_sql_roll_back_alias;

          }
          
        //get single data record query with $mosy_sql_roll_back_uptoken
        
        ///$mosy_sql_roll_back_node=get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
        
	
//************* START INSERT  mosy_sql_roll_back QUERY 
if(isset($_POST["mosy_sql_roll_back_insert_btn"])){
//------- begin mosy_sql_roll_back_arr_ins --> 
$mosy_sql_roll_back_arr_ins_=array(

"primkey"=>"NULL",
"roll_bk_key"=>magic_random_str(7),
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_ins -->


          
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {

              $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_arr_ins_;

              if(isset($mosy_sql_roll_back_ins_inputs))
              {
                $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_ins_inputs;	
              }

              if(empty($mosy_sql_roll_back_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name." request cannot be empty. Record not added");
              }else{
                $mosy_sql_roll_back_return_key=add_mosy_sql_roll_back($mosy_sql_roll_back_validated_ins_str);
                
                mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$mosy_sql_roll_back_mosy_rest_req_vars=http_build_query($_POST);
                echo $mosy_sql_roll_back_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $mosy_sql_roll_back_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
      
}
//************* END  mosy_sql_roll_back INSERT QUERY 	
	

//************* START mosy_sql_roll_back  UPDATE QUERY 
if(isset($_POST["mosy_sql_roll_back_update_btn"])){
//------- begin mosy_sql_roll_back_arr_updt --> 
$mosy_sql_roll_back_arr_updt_=array(
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_updt -->
                     
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
            $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_arr_updt_;

            if(isset($mosy_sql_roll_back_updt_inputs))
            {
              $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_updt_inputs;	
            }

            if(empty($mosy_sql_roll_back_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$mosy_sql_roll_back_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
            
              update_mosy_sql_roll_back($mosy_sql_roll_back_validated_updt_str, "primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_key_salt'");
				

			 mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $mosy_sql_roll_back_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $mosy_sql_roll_back_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $mosy_sql_roll_back_uptoken; 

                    } 

                  }else{ 

                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_uptoken), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_updated",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }

      

      
}
//************* END mosy_sql_roll_back  UPDATE QUERY 

    
    
      //== Start mosy_sql_roll_back delete record

      if(isset($_GET["deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_request","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"]."&conf_deletemosy_sql_roll_back&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_mosy_sql_roll_back_btn." ".$cancel_del_mosy_sql_roll_back_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_confirm","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $mosy_sql_roll_back_del_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
      mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "DELETE");
      drop_mosy_sql_roll_back("primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

      }
      }

      //== End mosy_sql_roll_back delete record  
    
       ///SELECT STRING FOR mosy_sql_roll_back============================
              
       if(isset($_POST["qmosy_sql_roll_back_btn"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qmosy_sql_roll_back_btn","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
            $current_mosy_sql_roll_back_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'?qmosy_sql_roll_back=';
            if (strpos($current_mosy_sql_roll_back_url_params, '?') !== false) {

                $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'&qmosy_sql_roll_back=';

            }
            if (strpos($current_mosy_sql_roll_back_url_params, '?qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "?qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'?qmosy_sql_roll_back=';

            }
            if(strpos($current_mosy_sql_roll_back_url_params, '&qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "&qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'&qmosy_sql_roll_back=';

            }
        $qmosy_sql_roll_back_str=base64_encode($_POST["txt_mosy_sql_roll_back"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str);
            } 

          }else{ 
             header('location:'.$clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }
        $qmosy_sql_roll_back="";
		if(isset($_GET["mosy_sql_roll_back_mosyfilter"]) && isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter_n_query","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
         
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
         
         $mosyfilter_mosy_sql_roll_back_queries_str=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%') AND ".$mosyfilter_mosy_sql_roll_back_queries_str."";
         
         }
         
		 $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
        }
        }elseif(isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "get_qmosy_sql_roll_back","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
		 $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }elseif(isset($_GET["mosy_sql_roll_back_mosyfilter"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $gft_mosy_sql_roll_back_where_query="";
         $gft_mosy_sql_roll_back="";

         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
          $gft_mosy_sql_roll_back_where_query=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
          $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         }
         
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }else{
         $gft_mosy_sql_roll_back="";
         $gft_mosy_sql_roll_back_and="";
         $gft_mosy_sql_roll_back_where_query="";
        }
       
    //************************************************* END  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section notification_manifest_
  //************************************************* START  notification_manifest_ OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize notification_manifest_ edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['notification_manifest__table_alert']))
              	{	
                  if(isset($notification_manifest__custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$notification_manifest__uptoken="";

		if(isset($_GET["notification_manifest__uptoken"]))
		{
		$notification_manifest__uptoken=base64_decode($_GET["notification_manifest__uptoken"]);
		}
        
        if(isset($_POST["notification_manifest__uptoken"]))
		{
		$notification_manifest__uptoken=base64_decode($_POST["notification_manifest__uptoken"]);
		}
        //
        
          $notification_manifest__alias_name="NOTIFICATION MANIFEST ";

          if(isset($notification_manifest__alias))
          {
             $notification_manifest__alias_name=$notification_manifest__alias;

          }
          
        //get single data record query with $notification_manifest__uptoken
        
        ///$notification_manifest__node=get_notification_manifest_("*", "WHERE primkey='$notification_manifest__uptoken'", "r");
        
	
//************* START INSERT  notification_manifest_ QUERY 
if(isset($_POST["notification_manifest__insert_btn"])){
//------- begin notification_manifest__arr_ins --> 
$notification_manifest__arr_ins_=array(

"primkey"=>"NULL",
"notific_key"=>magic_random_str(7),
"notification_type"=>"?",
"notification_state"=>"?",
"notification_icon"=>"?",
"notification_title"=>"?",
"notification_link"=>"?",
"notification_read_state"=>"?",
"notification_time_stamp"=>"?",
"notif_remark"=>"?"

);
//===-- End notification_manifest__arr_ins -->


          
         $gwauthenticate_notification_manifest__=gw_oauth("table", magic_current_url(), "notification_manifest_", "insert","");

         $gwauthenticate_notification_manifest__json=json_decode($gwauthenticate_notification_manifest__, true);
         	
          //echo $gwauthenticate_notification_manifest__;

         if($gwauthenticate_notification_manifest__json["response"]=="ok")
         {

              $notification_manifest__validated_ins_str=$notification_manifest__arr_ins_;

              if(isset($notification_manifest__ins_inputs))
              {
                $notification_manifest__validated_ins_str=$notification_manifest__ins_inputs;	
              }

              if(empty($notification_manifest__validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$notification_manifest__alias_name." request cannot be empty. Record not added");
              }else{
                $notification_manifest__return_key=add_notification_manifest_($notification_manifest__validated_ins_str);
                
                mosy_sql_rollback("notification_manifest_", "primkey='$notification_manifest__return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$notification_manifest__mosy_rest_req_vars=http_build_query($_POST);
                echo $notification_manifest__mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $notification_manifest__mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $notification_manifest__return_key; 

                      } 

                    }else{ 

                                    
                $notification_manifest__custom_redir1=add_url_param ("notification_manifest__uptoken", base64_encode($notification_manifest__return_key), "");
                $notification_manifest__custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$notification_manifest__custom_redir1);
                $notification_manifest__custom_redir3=add_url_param ("notification_manifest__table_alert", "notification_manifest__added",$notification_manifest__custom_redir2);
                
                ///echo magic_message($notification_manifest__custom_redir1." -- ".$notification_manifest__custom_redir2."--".$notification_manifest__custom_redir3);
                
                $notification_manifest__custom_redir=$notification_manifest__custom_redir3;
                
               header('location:'.$notification_manifest__custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_notification_manifest__);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notification_manifest__)."");
         
         }
      
}
//************* END  notification_manifest_ INSERT QUERY 	
	

//************* START notification_manifest_  UPDATE QUERY 
if(isset($_POST["notification_manifest__update_btn"])){
//------- begin notification_manifest__arr_updt --> 
$notification_manifest__arr_updt_=array(
"notification_type"=>"?",
"notification_state"=>"?",
"notification_icon"=>"?",
"notification_title"=>"?",
"notification_link"=>"?",
"notification_read_state"=>"?",
"notification_time_stamp"=>"?",
"notif_remark"=>"?"

);
//===-- End notification_manifest__arr_updt -->
                     
         $gwauthenticate_notification_manifest__=gw_oauth("table", magic_current_url(), "notification_manifest_", "update","");

         $gwauthenticate_notification_manifest__json=json_decode($gwauthenticate_notification_manifest__, true);
         	
          //echo $gwauthenticate_notification_manifest__;

         if($gwauthenticate_notification_manifest__json["response"]=="ok")
         {
         
            $notification_manifest__validated_updt_str=$notification_manifest__arr_updt_;

            if(isset($notification_manifest__updt_inputs))
            {
              $notification_manifest__validated_updt_str=$notification_manifest__updt_inputs;	
            }

            if(empty($notification_manifest__validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$notification_manifest__alias_name."  input cannot be empty. Record not Updated");

            }else{
			$notification_manifest__key_salt=initialize_notification_manifest_()["notific_key"];
            
              update_notification_manifest_($notification_manifest__validated_updt_str, "primkey='$notification_manifest__uptoken' and notific_key='$notification_manifest__key_salt'");
				

			 mosy_sql_rollback("notification_manifest_", "primkey='$notification_manifest__uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $notification_manifest__mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $notification_manifest__mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $notification_manifest__uptoken; 

                    } 

                  }else{ 

                $notification_manifest__custom_redir1=add_url_param ("notification_manifest__uptoken", base64_encode($notification_manifest__uptoken), "");
                $notification_manifest__custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$notification_manifest__custom_redir1);
                $notification_manifest__custom_redir3=add_url_param ("notification_manifest__table_alert", "notification_manifest__updated",$notification_manifest__custom_redir2);
                
                ///echo magic_message($notification_manifest__custom_redir1." -- ".$notification_manifest__custom_redir2."--".$notification_manifest__custom_redir3);
                
                $notification_manifest__custom_redir=$notification_manifest__custom_redir3;
                
               header('location:'.$notification_manifest__custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_notification_manifest__);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notification_manifest__)."");
         
         }

      

      
}
//************* END notification_manifest_  UPDATE QUERY 

    
    
      //== Start notification_manifest_ delete record

      if(isset($_GET["deletenotification_manifest_"]))
      {
         $gwauthenticate_notification_manifest__=gw_oauth("table", magic_current_url(), "notification_manifest_", "super_delete_request","");

         $gwauthenticate_notification_manifest__json=json_decode($gwauthenticate_notification_manifest__, true);
         	
          //echo $gwauthenticate_notification_manifest__;

         if($gwauthenticate_notification_manifest__json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_notification_manifest__btn=magic_button_link("./".$current_file_url."?notification_manifest__uptoken=".$_GET["notification_manifest__uptoken"]."&conf_deletenotification_manifest_&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_notification_manifest__btn=magic_button_link("./".$current_file_url."?notification_manifest__uptoken=".$_GET["notification_manifest__uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_notification_manifest__btn." ".$cancel_del_notification_manifest__btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_notification_manifest__);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletenotification_manifest_"]))
      {
         $gwauthenticate_notification_manifest__=gw_oauth("table", magic_current_url(), "notification_manifest_", "super_delete_confirm","");

         $gwauthenticate_notification_manifest__json=json_decode($gwauthenticate_notification_manifest__, true);
         	
          //echo $gwauthenticate_notification_manifest__;

         if($gwauthenticate_notification_manifest__json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $notification_manifest__del_key_salt=initialize_notification_manifest_()["notific_key"];
      mosy_sql_rollback("notification_manifest_", "primkey='$notification_manifest__uptoken'", "DELETE");
      drop_notification_manifest_("primkey='$notification_manifest__uptoken' and notific_key='$notification_manifest__del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_notification_manifest__);

      }
      }

      //== End notification_manifest_ delete record  
    
       ///SELECT STRING FOR notification_manifest_============================
              
       if(isset($_POST["qnotification_manifest__btn"])){
         $gwauthenticate_notification_manifest__=gw_oauth("table", magic_current_url(), "notification_manifest_", "qnotification_manifest__btn","");

         $gwauthenticate_notification_manifest__json=json_decode($gwauthenticate_notification_manifest__, true);
         	
          //echo $gwauthenticate_notification_manifest__;

         if($gwauthenticate_notification_manifest__json["response"]=="ok")
         {
            $current_notification_manifest__url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_notification_manifest__current_url=$current_notification_manifest__url_params.'?qnotification_manifest_=';
            if (strpos($current_notification_manifest__url_params, '?') !== false) {

                $clean_notification_manifest__current_url=$current_notification_manifest__url_params.'&qnotification_manifest_=';

            }
            if (strpos($current_notification_manifest__url_params, '?qnotification_manifest_')) {

                $remove_notification_manifest__old_token = substr($current_notification_manifest__url_params, 0, strpos($current_notification_manifest__url_params, "?qnotification_manifest_"));

                $clean_notification_manifest__current_url=$remove_notification_manifest__old_token.'?qnotification_manifest_=';

            }
            if(strpos($current_notification_manifest__url_params, '&qnotification_manifest_')) {

                $remove_notification_manifest__old_token = substr($current_notification_manifest__url_params, 0, strpos($current_notification_manifest__url_params, "&qnotification_manifest_"));

                $clean_notification_manifest__current_url=$remove_notification_manifest__old_token.'&qnotification_manifest_=';

            }
        $qnotification_manifest__str=base64_encode($_POST["txt_notification_manifest_"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_notification_manifest__current_url.($qnotification_manifest__str);
            } 

          }else{ 
             header('location:'.$clean_notification_manifest__current_url.($qnotification_manifest__str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_notification_manifest__);

        }
        }
        $qnotification_manifest_="";
		if(isset($_GET["notification_manifest__mosyfilter"]) && isset($_GET["qnotification_manifest_"])){
         $gwauthenticate_notification_manifest__=gw_oauth("table", magic_current_url(), "notification_manifest_", "notification_manifest__mosyfilter_n_query","");

         $gwauthenticate_notification_manifest__json=json_decode($gwauthenticate_notification_manifest__, true);
         	
          //echo $gwauthenticate_notification_manifest__;

         if($gwauthenticate_notification_manifest__json["response"]=="ok")
         {
         $qnotification_manifest_=mmres(base64_decode($_GET["qnotification_manifest_"]));
         
         $gft_notification_manifest__where_query="(`notific_key` LIKE '%".$qnotification_manifest_."%' OR  `notification_type` LIKE '%".$qnotification_manifest_."%' OR  `notification_state` LIKE '%".$qnotification_manifest_."%' OR  `notification_icon` LIKE '%".$qnotification_manifest_."%' OR  `notification_title` LIKE '%".$qnotification_manifest_."%' OR  `notification_link` LIKE '%".$qnotification_manifest_."%' OR  `notification_read_state` LIKE '%".$qnotification_manifest_."%' OR  `notification_time_stamp` LIKE '%".$qnotification_manifest_."%' OR  `notif_remark` LIKE '%".$qnotification_manifest_."%')";
         
         if($_GET["notification_manifest__mosyfilter"]!=""){
         
         $mosyfilter_notification_manifest__queries_str=(base64_decode($_GET["notification_manifest__mosyfilter"]));
        
         $gft_notification_manifest__where_query="(`notific_key` LIKE '%".$qnotification_manifest_."%' OR  `notification_type` LIKE '%".$qnotification_manifest_."%' OR  `notification_state` LIKE '%".$qnotification_manifest_."%' OR  `notification_icon` LIKE '%".$qnotification_manifest_."%' OR  `notification_title` LIKE '%".$qnotification_manifest_."%' OR  `notification_link` LIKE '%".$qnotification_manifest_."%' OR  `notification_read_state` LIKE '%".$qnotification_manifest_."%' OR  `notification_time_stamp` LIKE '%".$qnotification_manifest_."%' OR  `notif_remark` LIKE '%".$qnotification_manifest_."%') AND ".$mosyfilter_notification_manifest__queries_str."";
         
         }
         
		 $gft_notification_manifest_="WHERE ".$gft_notification_manifest__where_query;
         
         $gft_notification_manifest__and=$gft_notification_manifest__where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_notification_manifest__);
        }
        }elseif(isset($_GET["qnotification_manifest_"])){
         $gwauthenticate_notification_manifest__=gw_oauth("table", magic_current_url(), "notification_manifest_", "get_qnotification_manifest_","");

         $gwauthenticate_notification_manifest__json=json_decode($gwauthenticate_notification_manifest__, true);
         	
          //echo $gwauthenticate_notification_manifest__;

         if($gwauthenticate_notification_manifest__json["response"]=="ok")
         {
		 $qnotification_manifest_=mmres(base64_decode($_GET["qnotification_manifest_"]));
        
         $gft_notification_manifest__where_query="(`notific_key` LIKE '%".$qnotification_manifest_."%' OR  `notification_type` LIKE '%".$qnotification_manifest_."%' OR  `notification_state` LIKE '%".$qnotification_manifest_."%' OR  `notification_icon` LIKE '%".$qnotification_manifest_."%' OR  `notification_title` LIKE '%".$qnotification_manifest_."%' OR  `notification_link` LIKE '%".$qnotification_manifest_."%' OR  `notification_read_state` LIKE '%".$qnotification_manifest_."%' OR  `notification_time_stamp` LIKE '%".$qnotification_manifest_."%' OR  `notif_remark` LIKE '%".$qnotification_manifest_."%')";
         
         $gft_notification_manifest_="WHERE ".$gft_notification_manifest__where_query;
         
         $gft_notification_manifest__and=$gft_notification_manifest__where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_notification_manifest__);

        }
        }elseif(isset($_GET["notification_manifest__mosyfilter"])){
         $gwauthenticate_notification_manifest__=gw_oauth("table", magic_current_url(), "notification_manifest_", "notification_manifest__mosyfilter","");

         $gwauthenticate_notification_manifest__json=json_decode($gwauthenticate_notification_manifest__, true);
         	
          //echo $gwauthenticate_notification_manifest__;

         if($gwauthenticate_notification_manifest__json["response"]=="ok")
         {
         $gft_notification_manifest__where_query="";
         $gft_notification_manifest_="";

         if($_GET["notification_manifest__mosyfilter"]!=""){
          $gft_notification_manifest__where_query=(base64_decode($_GET["notification_manifest__mosyfilter"]));
          $gft_notification_manifest_="WHERE ".$gft_notification_manifest__where_query;
         }
         
         
         $gft_notification_manifest__and=$gft_notification_manifest__where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_notification_manifest__);

        }
        }else{
         $gft_notification_manifest_="";
         $gft_notification_manifest__and="";
         $gft_notification_manifest__where_query="";
        }
       
    //************************************************* END  notification_manifest_ OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  

//<--ncgh-->

?>