<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


 $parent_path=[
'http://localhost/origin/spotlight/',
//{{next_root_str}}
];

$active_parent_dir=date('dmyhisa');
if(isset($_SESSION[$mosy_gw_appname.'active_parent_dir'])){
 $active_parent_dir=$_SESSION[$mosy_gw_appname.'active_parent_dir'];
 ///echo $active_parent_dir;
}
$access_arr=[

    ///start access clearance array for $active_parent_dir.'mosy_sql_roll_back_list.php
    $active_parent_dir.'mosy_sql_roll_back_list.php'=>
      [
      'mosy_sql_roll_back'=>['select','{{next_mosy_sql_roll_back_list.php_mosy_sql_roll_back}}'],
        //next_mosy_sql_roll_back_list.php_access

      ],
      ///end access clearance array for $active_parent_dir.'mosy_sql_roll_back_list.php

      //{{next_file_block}}

];
?>