
     <div class="m-0 pt-3 col-md-12 skin_plasma p-0" style="min-height:100vh;">
       <div class="row justify-content-center m-0 pt-3 col-md-12 ">
				
            <div class="col-md-12 row justify-content-left m-0  p-0">
               
        <div class="form-group col-md-4">
          <label >Table Name</label>
          <input class="form-control" id="txt_table_name" name="txt_table_name" value="<?php echo $mosy_sql_roll_back_node["table_name"];?>" placeholder="Table Name" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Roll Type</label>
          <input class="form-control" id="txt_roll_type" name="txt_roll_type" value="<?php echo $mosy_sql_roll_back_node["roll_type"];?>" placeholder="Roll Type" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Where Str</label>
          <input class="form-control" id="txt_where_str" name="txt_where_str" value="<?php echo $mosy_sql_roll_back_node["where_str"];?>" placeholder="Where Str" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Roll Timestamp</label>
          <input class="form-control" id="txt_roll_timestamp" name="txt_roll_timestamp" value="<?php echo $mosy_sql_roll_back_node["roll_timestamp"];?>" placeholder="Roll Timestamp" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Value Entries</label>
          <input class="form-control" id="txt_value_entries" name="txt_value_entries" value="<?php echo $mosy_sql_roll_back_node["value_entries"];?>" placeholder="Value Entries" type="text">
        </div>

               
      <div class="col-md-12 text-center">
      <?php if(!isset($_GET['mosy_sql_roll_back_uptoken'])){?> 
            <button type="submit" id="mosy_sql_roll_back_insert_btn" name="mosy_sql_roll_back_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET['mosy_sql_roll_back_uptoken'])) {?>
            <button type="submit" id="mosy_sql_roll_back_update_btn" name="mosy_sql_roll_back_update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="mosy_sql_roll_back_insert_btn" name="mosy_sql_roll_back_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>          
            <?php } ?>
    </div>
  
            </div>
          </div>
          <div class="row justify-content-center m-0 p-0 col-md-12 mt-3">
                            <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                    <div class="col-md-3 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                    <div class="col-md-5 text-center"> More Mosy Sql Roll Back</div>
                    <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>
                  </h5>
                  <div class="row justify-content-left col-md-12 mt-3">

                    <input type="text" class="col-md-2 mb-2 ml-2 bg-transparent" placeholder="Search Mosy Sql Roll Back" name="txt_mosy_sql_roll_back" style="color:<?php echo $body_txt ?>; border:none; border-bottom:1px solid <?php echo $btn_bg ?>;"/>
                         <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="qmosy_sql_roll_back_btn"><i class="fa fa-search"></i> Go</button>                  
                    </div>
     
                  <!-- End Title ribbon-->
          <?php include("./data_ui/mosy_sql_roll_back_list_wgt.php");?>
          
          </div>
      </div>