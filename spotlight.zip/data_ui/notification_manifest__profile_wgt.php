
     <div class="m-0 pt-3 col-md-12 skin_plasma p-0" style="min-height:100vh;">
       <div class="row justify-content-center m-0 pt-3 col-md-12 ">
				
            <div class="col-md-12 row justify-content-left m-0  p-0">
               
        <div class="form-group col-md-4">
          <label >Notification Type</label>
          <input class="form-control" id="txt_notification_type" name="txt_notification_type" value="<?php echo $notification_manifest__node["notification_type"];?>" placeholder="Notification Type" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Notification State</label>
          <input class="form-control" id="txt_notification_state" name="txt_notification_state" value="<?php echo $notification_manifest__node["notification_state"];?>" placeholder="Notification State" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Notification Icon</label>
          <input class="form-control" id="txt_notification_icon" name="txt_notification_icon" value="<?php echo $notification_manifest__node["notification_icon"];?>" placeholder="Notification Icon" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Notification Title</label>
          <input class="form-control" id="txt_notification_title" name="txt_notification_title" value="<?php echo $notification_manifest__node["notification_title"];?>" placeholder="Notification Title" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Notification Link</label>
          <input class="form-control" id="txt_notification_link" name="txt_notification_link" value="<?php echo $notification_manifest__node["notification_link"];?>" placeholder="Notification Link" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Notification Read State</label>
          <input class="form-control" id="txt_notification_read_state" name="txt_notification_read_state" value="<?php echo $notification_manifest__node["notification_read_state"];?>" placeholder="Notification Read State" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Notification Time Stamp</label>
          <input class="form-control" id="txt_notification_time_stamp" name="txt_notification_time_stamp" value="<?php echo $notification_manifest__node["notification_time_stamp"];?>" placeholder="Notification Time Stamp" type="text">
        </div>

        <div class="form-group col-md-4">
          <label >Notif Remark</label>
          <input class="form-control" id="txt_notif_remark" name="txt_notif_remark" value="<?php echo $notification_manifest__node["notif_remark"];?>" placeholder="Notif Remark" type="text">
        </div>

               
      <div class="col-md-12 text-center">
      <?php if(!isset($_GET['notification_manifest__uptoken'])){?> 
            <button type="submit" id="notification_manifest__insert_btn" name="notification_manifest__insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET['notification_manifest__uptoken'])) {?>
            <button type="submit" id="notification_manifest__update_btn" name="notification_manifest__update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="notification_manifest__insert_btn" name="notification_manifest__insert_btn" class="btn btn-primary" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>          
            <?php } ?>
    </div>
  
            </div>
          </div>
          <div class="row justify-content-center m-0 p-0 col-md-12 mt-3">
                            <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                    <div class="col-md-3 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                    <div class="col-md-5 text-center"> More Notification Manifest </div>
                    <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>
                  </h5>
                  <div class="row justify-content-left col-md-12 mt-3">

                    <input type="text" class="col-md-2 mb-2 ml-2 bg-transparent" placeholder="Search Notification Manifest " name="txt_notification_manifest_" style="color:<?php echo $body_txt ?>; border:none; border-bottom:1px solid <?php echo $btn_bg ?>;"/>
                         <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="qnotification_manifest__btn"><i class="fa fa-search"></i> Go</button>                  
                    </div>
     
                  <!-- End Title ribbon-->
          <?php include("./data_ui/notification_manifest__list_wgt.php");?>
          
          </div>
      </div>