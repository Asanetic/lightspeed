
  <style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="notification_manifest__data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Notification Type</th>
             <th scope="col">Notification State</th>
             <th scope="col">Notification Icon</th>
             <th scope="col">Notification Title</th>
             <th scope="col">Notification Link</th>
             <th scope="col">Notification Read State</th>
             <th scope="col">Notification Time Stamp</th>
             <th scope="col">Notif Remark</th>

		   </tr>
	    </thead>
	    <tbody>
      <?php 
          $default_notification_manifest__profile="./notification_manifest__profile.php";
          if(isset($notification_manifest__profile))
          {
          $default_notification_manifest__profile=$notification_manifest__profile;
          } 
          
          $default_notification_manifest__listing="./notification_manifest__list.php";
          if(isset($notification_manifest__listing))
          {
          $default_notification_manifest__listing=$notification_manifest__listing;
          } 
          
          $default_notification_manifest__show_edit_btn="yes";
          if(isset($notification_manifest__show_edit_btn))
          {
          $default_notification_manifest__show_edit_btn=$notification_manifest__show_edit_btn;
          } 
      	
          echo drop_css();
        
          $i=0;

		  
          
        //<--outloop-dope-->
 
 	   while($listnotification_manifest__result=mysqli_fetch_array($notification_manifest__list_query[0]))
    	{
        
        $i++;
		
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_notification_manifest__show_edit_btn=="yes"){
          $edit_drop_link=magic_link($default_notification_manifest__profile.'?notification_manifest__uptoken='.base64_encode($listnotification_manifest__result["primkey"]).'', '<i class="fa fa-edit"></i> View More', '');
          }
          
           //{{edit_drop_link}}
           if($default_notification_manifest__show_edit_btn=="yes")
           {
            $delete_drop_link=magic_link($default_notification_manifest__profile.'?after_delete='.base64_encode(magic_current_url()).'&notification_manifest__uptoken='.base64_encode($listnotification_manifest__result["primkey"]).'&deletenotification_manifest_','<i class="fa fa-trash"></i> Delete', '');
		   }
	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr>
              <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
            
                         <td scope="col"><span title="<?php echo $listnotification_manifest__result["notification_type"] ?>"><?php echo magic_strip_if($listnotification_manifest__result["notification_type"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listnotification_manifest__result["notification_state"] ?>"><?php echo magic_strip_if($listnotification_manifest__result["notification_state"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listnotification_manifest__result["notification_icon"] ?>"><?php echo magic_strip_if($listnotification_manifest__result["notification_icon"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listnotification_manifest__result["notification_title"] ?>"><?php echo magic_strip_if($listnotification_manifest__result["notification_title"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listnotification_manifest__result["notification_link"] ?>"><?php echo magic_strip_if($listnotification_manifest__result["notification_link"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listnotification_manifest__result["notification_read_state"] ?>"><?php echo magic_strip_if($listnotification_manifest__result["notification_read_state"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listnotification_manifest__result["notification_time_stamp"] ?>"><?php echo magic_strip_if($listnotification_manifest__result["notification_time_stamp"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listnotification_manifest__result["notif_remark"] ?>"><?php echo magic_strip_if($listnotification_manifest__result["notif_remark"], 10, 10);?></span></td>

			</tr>
       <?php }?>

          <tr>
          <th></th>
          
                       <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>

          </tr>
  <!--add_new_row_here-->
	    </tbody>
	    </table>
             <?php if($i==0){?>
            <h4 class="col-md-12 text-center p-3"><i class="fa fa-search"></i> Sorry, no notification manifest  records found</h4>
            <div class="col-md-12 text-center">
            	<?php $search_notification_manifest__class="ml-0"; if($default_notification_manifest__show_edit_btn=="yes"){
                $search_notification_manifest__class="ml-4";
                ?>
            	<a href="<?php echo $default_notification_manifest__profile ?>" class="badge badge-primary mb-3 btn_neo p-2"><i class="fa fa-plus"></i>  Add new </a>
                <?php }?>
            	<a href="<?php echo  $default_notification_manifest__listing?>" class="badge badge-primary mb-3 <?php echo $search_notification_manifest__class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
            </div>
          <?php }?>
         <?php echo mosy_paginate_ui($notification_manifest__list_query[1], $datalimit, "qnotification_manifest__token")?>
        </div>
       