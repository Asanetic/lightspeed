
  <style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="mosy_sql_roll_back_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Table Name</th>
             <th scope="col">Roll Type</th>
             <th scope="col">Where Str</th>
             <th scope="col">Roll Timestamp</th>
             <th scope="col">Value Entries</th>

		   </tr>
	    </thead>
	    <tbody>
      <?php 
          $default_mosy_sql_roll_back_profile="./mosy_sql_roll_back_profile.php";
          if(isset($mosy_sql_roll_back_profile))
          {
          $default_mosy_sql_roll_back_profile=$mosy_sql_roll_back_profile;
          } 
          
          $default_mosy_sql_roll_back_listing="./mosy_sql_roll_back_list.php";
          if(isset($mosy_sql_roll_back_listing))
          {
          $default_mosy_sql_roll_back_listing=$mosy_sql_roll_back_listing;
          } 
          
          $default_mosy_sql_roll_back_show_edit_btn="yes";
          if(isset($mosy_sql_roll_back_show_edit_btn))
          {
          $default_mosy_sql_roll_back_show_edit_btn=$mosy_sql_roll_back_show_edit_btn;
          } 
      	
          echo drop_css();
        
          $i=0;

		  
          
        //<--outloop-dope-->
 
 	   while($listmosy_sql_roll_back_result=mysqli_fetch_array($mosy_sql_roll_back_list_query[0]))
    	{
        
        $i++;
		
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_mosy_sql_roll_back_show_edit_btn=="yes"){
          $edit_drop_link=magic_link($default_mosy_sql_roll_back_profile.'?mosy_sql_roll_back_uptoken='.base64_encode($listmosy_sql_roll_back_result["primkey"]).'', '<i class="fa fa-edit"></i> View More', '');
          }
          
           //{{edit_drop_link}}
           if($default_mosy_sql_roll_back_show_edit_btn=="yes")
           {
            $delete_drop_link=magic_link($default_mosy_sql_roll_back_profile.'?after_delete='.base64_encode(magic_current_url()).'&mosy_sql_roll_back_uptoken='.base64_encode($listmosy_sql_roll_back_result["primkey"]).'&deletemosy_sql_roll_back','<i class="fa fa-trash"></i> Delete', '');
		   }
	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr>
              <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, 'no')?></td>
            
                         <td scope="col"><span title="<?php echo $listmosy_sql_roll_back_result["table_name"] ?>"><?php echo magic_strip_if($listmosy_sql_roll_back_result["table_name"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listmosy_sql_roll_back_result["roll_type"] ?>"><?php echo magic_strip_if($listmosy_sql_roll_back_result["roll_type"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listmosy_sql_roll_back_result["where_str"] ?>"><?php echo magic_strip_if($listmosy_sql_roll_back_result["where_str"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listmosy_sql_roll_back_result["roll_timestamp"] ?>"><?php echo magic_strip_if($listmosy_sql_roll_back_result["roll_timestamp"], 10, 10);?></span></td>
             <td scope="col"><span title="<?php echo $listmosy_sql_roll_back_result["value_entries"] ?>"><?php echo magic_strip_if($listmosy_sql_roll_back_result["value_entries"], 10, 10);?></span></td>

			</tr>
       <?php }?>

          <tr>
          <th></th>
          
                       <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>
             <th scope="col"></th>

          </tr>
  <!--add_new_row_here-->
	    </tbody>
	    </table>
             <?php if($i==0){?>
            <h4 class="col-md-12 text-center p-3"><i class="fa fa-search"></i> Sorry, no mosy sql roll back records found</h4>
            <div class="col-md-12 text-center">
            	<?php $search_mosy_sql_roll_back_class="ml-0"; if($default_mosy_sql_roll_back_show_edit_btn=="yes"){
                $search_mosy_sql_roll_back_class="ml-4";
                ?>
            	<a href="<?php echo $default_mosy_sql_roll_back_profile ?>" class="badge badge-primary mb-3 btn_neo p-2"><i class="fa fa-plus"></i>  Add new </a>
                <?php }?>
            	<a href="<?php echo  $default_mosy_sql_roll_back_listing?>" class="badge badge-primary mb-3 <?php echo $search_mosy_sql_roll_back_class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
            </div>
          <?php }?>
         <?php echo mosy_paginate_ui($mosy_sql_roll_back_list_query[1], $datalimit, "qmosy_sql_roll_back_token")?>
        </div>
       