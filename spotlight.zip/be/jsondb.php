<?php 
ob_start();
include('./data_control/conn.php');  
  
// Retrieve table and column information
$tables = array();


  if(isset($_GET['table']))
  {
    $single_table=$_GET['table'];
    
    $query = "SHOW TABLES FROM `$db`  where Tables_in_$db ='$single_table'";
  }else{
    $query = "SHOW TABLES FROM `$db` ";
  }


$result = mysqli_query($single_conn, $query) or die(mysqli_error($single_conn));

while ($row = mysqli_fetch_row($result)) {
    $tableName = $row[0];
    $columns = array();

    // Retrieve column information for each table
    $query = "SHOW FULL COLUMNS FROM $db.$tableName";
    $result2 = mysqli_query($single_conn, $query);

    while ($columnRow = mysqli_fetch_assoc($result2)) {
        $columnInfo = array(
            'name' => $columnRow['Field'],
            'type' => $columnRow['Type'],
            'nullable' => $columnRow['Null'],
            'default' => $columnRow['Default'],
            'extra' => $columnRow['Extra']
        );

        $columns[] = $columnInfo;
    }

    $tables[$tableName] = $columns;
}

// Convert the table and column information to JSON
$jsonData = json_encode($tables, JSON_PRETTY_PRINT);

// Output the JSON data
header('Content-Type: application/json');
echo $jsonData;

// Close the database connection
mysqli_close($single_conn);

?>