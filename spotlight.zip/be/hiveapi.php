<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');
include('./data_control/customfunctions.php');

if(isset($_GET['mosyget_']))
{

    $date_source_tbl=$_GET['tbl'];
    $sql_first_section_=base64_decode($_GET['colstr']);
    $where_filter_sql_str=base64_decode($_GET['where_str']);
    $pagination_or_loop_str=$_GET['pagination'];
    $function_cols=base64_decode($_GET['function_cols']);
    
    if($function_cols!="")
    {
     $function_data_cols=json_decode($function_cols, true);
    }
  
	$get_fun_exe_name=('get_'.$date_source_tbl);
 
	$ajax_loop_curr_tbl_q=$get_fun_exe_name($sql_first_section_, $where_filter_sql_str, $pagination_or_loop_str);
    $ajax_loop_curr_tbl_q_str=$ajax_loop_curr_tbl_q;
  
    ///echo $get_fun_exe_name." ".$sql_first_section_." wstr ". $where_filter_sql_str." pagination ". $pagination_or_loop_str." funcols ".$function_cols;
  
    $first_row="";
    $page_count="";
    $sql_str="";
    if($pagination_or_loop_str!="l")
    {
      $ajax_loop_curr_tbl_q_str=$ajax_loop_curr_tbl_q[0];
      
      $first_row=$ajax_loop_curr_tbl_q[2];
      $page_count=$ajax_loop_curr_tbl_q[1];
      $sql_str=$ajax_loop_curr_tbl_q[3];
    }
  
    $ajax_loop_curr_tbl_arr=array();  
    $ajax_function_data=array();
    $row_count_arr=array();
    $row_count=0;
  	while($ajax_loop_curr_tbl_res=mysqli_fetch_array($ajax_loop_curr_tbl_q_str))
    {
  	  $data_res=$ajax_loop_curr_tbl_res;
      $row_count++;
      if($function_cols!="")
      {
        foreach($function_data_cols as $key=>$value)
        {
          ///$custom_data_point=explode("|", $key);  

          eval(("\$ajax_function_data[\$key] =".$value.";"));

        }
      }
      $row_count_arr['row_count']=$row_count;
      $ajax_loop_curr_tbl_arr[]=array_merge($ajax_loop_curr_tbl_res, $ajax_function_data, $row_count_arr);
  	  
      
  	}
    

    $flex_result=(array("data"=>$ajax_loop_curr_tbl_arr, "first_row"=>$first_row, "page_count"=>$page_count,"sql_str"=>$sql_str));  

  
    echo json_encode($flex_result, true);
}


if(isset($_GET['pagination_ui']))
{
  $req_url=base64_decode($_GET['requrl']);
  
  echo mosy_paginate_ui($_GET['pagination_ui'], $_GET['datalimit'], $_GET['page_label'], "skip", $req_url);
}

if(isset($_POST["mosyajax_sql_data"]))
{
  	$curr_tbl=base64_decode($_POST['tbl']);
    $col_str_=base64_decode($_POST['colstr']);
  
	$sql_function_name=('get_'.$curr_tbl);
  
  	$pagination="l";

   if(isset($_POST['pagination']))
   {

    if($_POST['pagination']!='')
    {
      $pagination="l:".$_POST['pagination'];
    }
  }
  	$check_oauth=gw_oauth('table', $_SERVER['HTTP_REFERER'], $curr_tbl, "select", "");
  	$check_oauth_resp=json_decode($check_oauth, true);
  
  	if($check_oauth_resp['response']=='ok')
    {
    //=== start packages select  Like Query String packages list  
	$ajax_loop_curr_tbl_q=$sql_function_name($col_str_, base64_decode($_POST['mosyajax_sql_data']), $pagination);
	$return_no_tag=$sql_function_name($col_str_, base64_decode($_POST['mosyajax_sql_data']), "l");
    $return_no_tag_res=array();
  

    $ajax_loop_curr_tbl_q_str=$ajax_loop_curr_tbl_q;
      
    if($pagination!="l")
    {
      $ajax_loop_curr_tbl_q_str=$ajax_loop_curr_tbl_q[0];
    }
  
  //echo magic_message($_POST['mosyajax_sql_data']);
  	while($return_no_tag_r=mysqli_fetch_array($return_no_tag))
    {
  	
      $return_no_tag_res[]=$return_no_tag_r;
  	
  	}
  	$node_function_name_str=$_POST['node_function_name'];
  
    if (strpos($node_function_name_str, ':') !== false) 
    {
      $explode_user_function=explode(":", $node_function_name_str);
      $node_function_name=$explode_user_function[0];
      $additional_user_function_str=$explode_user_function[1];
      
      $explode_additional_params=explode(",", $additional_user_function_str);
      $function_array=array();
      
      foreach($explode_additional_params as $param_str)
      {
      	$function_array[]="'".$param_str."'";  
      }
      
      $additional_user_function=", [".implode(",", $function_array)."]";
      
    }else{
      $node_function_name=$node_function_name_str;
      $additional_user_function="";
    }
  
   	$ui_tag1=base64_decode($_POST['ui_tag']);
    $ui_tag2=str_replace("{{<}}", "<", $ui_tag1);
    $ui_tag3=str_replace("{{>}}", ">", $ui_tag2);
    $ui_tag4=str_replace("{{on click}}", "onclick", $ui_tag3);
    $ui_tag5=str_replace("{{on keyup}}", "onkeyup", $ui_tag4);   
    $ui_tag=str_replace("{{on error}}", "onerror", $ui_tag5);   
  
    if (strpos($ui_tag, '=>') !== false) 
    {
  
      //$ui_template=explode("=>", $ui_tag)[1];
              
    }
  
  	$js_columns=array();  
	$name_col_arr=array();
  	$name_label_arr=array();
  


  	$ui_columns="";
    $card_str="";
  
  	$exploded_cols=explode(",", base64_decode($_POST["cols"]));

       foreach($exploded_cols as $colname)
    	{
          
          if (strpos($colname, ':') !== false) 
          {
			$label_str=explode(":", $colname);            
            $name_label_arr[]=$label_str[1];
           	$name_col_arr[]=$label_str[0];
            
            if(array_key_exists(2, $label_str) )
            {
            $name_label_arr[]=$label_str[1].":".$label_str[2];  
            }
			

          }else{
            
            $js_columns[]=magic_clean_str($colname);

          }
           
    	}
	
      $i=0;
  
    while($data_res=mysqli_fetch_array($ajax_loop_curr_tbl_q_str))
    {
    $i++;
      
    $custom_ui_search_data_point=array();
	$custom_ui_replace_data_point=array();
	$custom_ui_search_label_point=array();
	$custom_ui_replace_label_point=array();
      
      $node_card_len=count($name_label_arr)-1;
      $js_cols_len=count($js_columns)-1;
      
      $data_node_card_c=-1;
      $data_node_card='';
      
      while($data_node_card_c<=$node_card_len)
      {
        $data_node_card_c++;
        
        
        if($data_node_card_c<$node_card_len+1)
        {

          if (strpos($name_label_arr[$data_node_card_c], '|') !== false) 
          {
         
          $custom_data_point=explode("|", $name_label_arr[$data_node_card_c]);  
          $custom_data_node1=eval(("\$custom_data_node= ".$custom_data_point[1].";"));;  
          $custom_label_node=$custom_data_point[0];
  
            //echo $custom_data_node;
          }else{
                     
            $custom_data_node=$data_res[$name_col_arr[$data_node_card_c]];
            $custom_label_node=$name_label_arr[$data_node_card_c];

          }
          
          
          if($ui_tag=='card')
          {
              $data_node_card.='<div class="col-md-12 p-1 m-0"> <b> '.$custom_label_node.'</b> : '.$custom_data_node.'</div>';
          }
          
          if($ui_tag=='option')
          {
              $data_node_card.=$custom_data_node;
          }  
          
          if($ui_tag=='tr')
          {
              $data_node_card.='<td class="">'.$custom_data_node.'</td>';
          }

			$custom_ui_search_data_point[]="{{".$name_col_arr[$data_node_card_c]."}}";
          	$custom_ui_replace_data_point[]=$data_res[$name_col_arr[$data_node_card_c]];
          
          	$custom_ui_search_label_point[]="{{".$custom_label_node."}}";
            $custom_ui_replace_label_point[]=$custom_data_node;
          
 
        }
        
      }
   
                
          if (strpos($ui_tag, '=>') !== false) 
          {
	
              $ui_template=explode("=>", $ui_tag)[1];
              $search_data_points_str =$custom_ui_search_data_point;            
         	  $replace_data_points_str =$custom_ui_replace_data_point;
            
              $search_label_points_str =$custom_ui_search_label_point;            
         	  $replace_label_points_str =$custom_ui_replace_label_point;

              
              $data_node_card1= str_replace($search_data_points_str, magic_clean_str($replace_data_points_str), $ui_template);
              $data_node_card2= str_replace($search_label_points_str, magic_clean_str($replace_label_points_str), $data_node_card1);                          
              $data_node_card.= str_replace("{{row_count}}", magic_clean_str($i), $data_node_card2);

            
          }

      $jsexe_node_card_c=-1;
      $jsexe_node_card=array();
      $option_inner_val_str=array();
      
      while($jsexe_node_card_c<=$js_cols_len)
      {
        $jsexe_node_card_c++;
                
        if($jsexe_node_card_c<$js_cols_len+1)
        {
              $jsexe_node_card[]='\''.magic_clean_str($data_res[$js_columns[$jsexe_node_card_c]]).'\'';
              $option_inner_val_str[]=magic_clean_str($data_res[$js_columns[$jsexe_node_card_c]]);
          
        }
        
      }
      
      $js_function_data_node="[".implode(",", $jsexe_node_card)."]".$additional_user_function;
      $option_inner_value=implode(",", $option_inner_val_str);
      
      if($option_inner_value=='')
      {
        $option_inner_value=$data_node_card;
      }
      
          if($ui_tag=='card')
          {
            
          $card_str.='
              <div class="col-md-12 p-0 text-left mr-0 cpointer border-bottom border_set" onclick="'.$node_function_name.'('.$js_function_data_node.')">  
				<span class="badge">'.$data_node_card.'</span>
			  </div>';
            
            
          }

          if($ui_tag=='option')
          {
            
          $card_str.='
              <option value="'.$option_inner_value.'" >'.$data_node_card.'</option>';
          }

          if($ui_tag=='tr')
          {
            $card_str.='
              <tr class="" style="cursor:pointer;" onclick="'.$node_function_name.'('.$js_function_data_node.')">  
				'.$data_node_card.'
			  </tr>';
          }
      
          if (strpos($ui_tag, '=>') !== false) 
          {
              $card_str.=str_replace("{{".$node_function_name."}}", $node_function_name.'('.$js_function_data_node.')', $data_node_card);

              
              
          }


    }	

          if($ui_tag=='')
          {
			echo json_encode($return_no_tag_res, true);
          }else{
    		echo  $card_str;
          }
    }else{
      echo $check_oauth;
    }
}

?>