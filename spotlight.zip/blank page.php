<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');  
 
include('./data_control/customfunctions.php');

$page_title=" Page title ";

$mosy_sql_roll_back_list_query=get_mosy_sql_roll_back("*", "$gft_mosy_sql_roll_back ", "l:qmosy_sql_roll_back_token");
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title> <?php echo $page_title ?></title>
<?php include('./includes/admin_css_scripts.php');?>
</head>
<body class="mini-sidebar">
    
<form method="post" enctype="multipart/form-data" id="mosy_form">
  <div class="main-wrapper">
  <?php include('./includes/adminnav.php'); ?>
    <div class="page-wrapper">
      <div class="content container-fluid">
        <div class="page-header p-0 m-0 ">
          <div class="row m-0 p-0  col-md-12  ">
            <div class="col-md-12 p-0 m-0">
              <h3 class="page-title"> <?php echo $page_title ?> </h3>
               <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active"> <?php echo $page_title ?></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12">
			<div class="col-md-12 p-3 "></div>
			<!-- Start body content -->
             
			<!-- End body content -->     
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include('./includes/admin_footer.php');?>  
</form>
</body> 
</html>