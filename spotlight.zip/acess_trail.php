<?php
ob_start();
include("./data_control/conn.php");
include("./data_control/phpmagicbits.php");
include("./data_control/gwdna.php");

  gw_oauth("tbl", "http://localhost/origin/spotlight/mosy_sql_roll_back_list.php","mosy_sql_roll_back","select");
//{{next_gw_oauth}}
    
  ?>  
  