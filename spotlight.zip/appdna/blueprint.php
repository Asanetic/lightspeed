<?php  
/// 1. - set up the tables list 
$tables_array_="mosy_sql_roll_back";

$run_create_tbls="no";   //yes | no
$show_jsontbl_keys="yes"; //yes | no

$write_conn_file="yes";  //yes | no
$write_backend_files="no"; //yes | no

//  2.  --- create navigation bar 
$node_group=
[
  "Client & Vehicles"=>["car","vehicles:Client Vehicles Report","cars_list","customers"],
  "Vehicle Inspections"=>['search','defect_report_:Record Inspection','vehicle_booking_check_list:Booking Check List'], 
  "Estimates & Invoices"=>['copy','defect_report_:Invoices','payment_vouchers','jv_list','dr_cr_table'], 
  "Vehicle Booking"=>["edit",""],
  "Repair Tracker"=>["bolt",""],
  "Gatepass & Dispatch"=>["edit",""],
  "Mechanics"=>["gear",""],
  "Ecommerce"=>["shopping-cart",""],
  "Accounts"=>["book",""],
  "System admins"=>["shield",""]
];


$write_navbar___="yes";


/// 3. set aut tables and nav bars to yes 

/// 4. search and run app exe


$app_links_=[
  'ticketnow'=>'http://localhost/hive/ticketnow/be/jsondb.php',
  'chatty'=>'http://localhost/hive/chatty/be/jsondb.php',
  'invoices'=>'http://localhost/hive/invoices/be/jsondb.php',
  'garagepro'=>'http://localhost/hive/garagepro/be/jsondb.php'
];

$jsondb_url=$app_links_['garagepro'];

$appname = array_search($jsondb_url, $app_links_);

$root_folder="../";
$parent_hive_js_folder_="../aero/assets/js/hives";
$hive_js_folder_=$parent_hive_js_folder_."/".$appname;
$js_nodes_control=$parent_hive_js_folder_."/hive_node_control.js";
$js_folder="./js/";

$cc_folder=$hive_js_folder_."/cc";
$behive_folder=$hive_js_folder_."/behive";
$chive_folder=$hive_js_folder_."/cohive";
$features_folder=$root_folder."/features";

$db_tables_list=json_decode(magic_post_curl($jsondb_url), true);

?>