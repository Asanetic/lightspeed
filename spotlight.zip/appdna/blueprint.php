<?php  
/// 1. - set up the tables list 
$tables_array_="mosy_sql_roll_back,app_users";

$run_create_tbls="yes";   //yes | no
$show_jsontbl_keys="yes"; //yes | no

$write_conn_file="yes";  //yes | no
$write_backend_files="no"; //yes | no

//  2.  --- create navigation bar 
$node_group=
[
  "Client & Vehicles"=>["car","vehicles:Client Vehicles Report","cars_list","customers"],
];


$write_navbar___="yes";


/// 3. set aut tables and nav bars to yes 

/// 4. search and run app exe


$app_links_=[
  'superauth'=>'http://localhost/hive/superauth/be/jsondb.php',
  'dashy'=>'http://localhost/hive/dashy/be/jsondb.php',
  'mpesaengine'=>'http://localhost/hive/mpesaengine/be/jsondb.php'
];


$desired_column_order_bp=[
    'system_users' => ['login_password', 'client_tel', 'client_name'],
];


if(isset($desired_column_order))
{
 $desired_column_order_bp=$desired_column_order;
}


$jsondb_url=$app_links_['superauth'];

$single_table_call="";

$reorder_cols="?desired_col_order=".base64_encode(json_encode($desired_column_order_bp, true))."";
$jsondb_url_call=$jsondb_url.$reorder_cols;

if($single_table_call!="")
{
  $jsondb_url_call=$jsondb_url.$reorder_cols."&table=$single_table_call";
}

$appname = array_search($jsondb_url, $app_links_);

$root_folder="../";
$parent_hive_js_folder_="../js/hives";
$hive_js_folder_=$parent_hive_js_folder_."/".$appname;
$js_nodes_control=$parent_hive_js_folder_."/hive_node_control.js";
$js_folder="./js/";
$hive_control="../hive_control";

$cc_folder=$hive_js_folder_."/cc";
$behive_folder=$hive_js_folder_."/behive";
$chive_folder=$hive_js_folder_."/cohive";
$features_folder=$root_folder."/features";

$db_tables_list=json_decode(magic_post_curl($jsondb_url_call), true);

?>