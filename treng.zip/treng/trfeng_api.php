<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');
include('./data_control/customfunctions.php');


if(isset($_POST['create_meta_tag']) || isset($_POST['show_post']))
{
  
 $admin_id=mmres($_POST['admin_id']);
 $post_id=mmres($_POST['post_id']);
  
 $meta_attr_q=get_posts('*', " where admin_id ='$admin_id' and msgid='$post_id'", "r");
  
 ///===landing page 
	$linkid=$meta_attr_q['link'];

  	$msg_id=$meta_attr_q['msgid'];

  	$tokennid=$meta_attr_q['page'];

	$landing_page=get_page_links("*", " where link_id='$linkid'", "r");
  
  	$camplinknavar1=$landing_page['linkurl']."?campid=".base64_encode($msg_id)."&markid=".base64_encode($tokennid);

    if(strpos($landing_page['linkurl'], '?')!==false){
	$camplinknavar1=$landing_page['linkurl']."&campid=".base64_encode($msg_id)."&markid=".base64_encode($tokennid);

    }

  ///===landing page 
  
  $meta_img=magic_rel2abs($meta_attr_q['post_image'], magic_current_url());
  
  $meta_descr=magic_strip_if(strip_tags($meta_attr_q['details']),300, 300);
  
  $meta_str='<meta property="og:image" content="'.$meta_img.'"/>'.PHP_EOL;
  $meta_str.='<meta property="og:description" content="'.$meta_descr.'"/>'.PHP_EOL;
  $meta_str.='<meta property="og:url" content="'.$camplinknavar1.'"/>'.PHP_EOL;
  $meta_str.='<title>'.$meta_attr_q['msg_titile'].'</title>';
  
    $jumbotron='           
  			<!--- Start jumbotron -->
           	<!-- Start  Title ribbon-->
             <h4 class="col-md-12 text-center p-0 d-lg-block d-none">'.$meta_attr_q['msg_titile'].'</h4>
             <h5 class="col-md-12 text-center p-0 d-lg-none">'.$meta_attr_q['msg_titile'].' </h5>
            <!-- End Title ribbon-->
            <div class="col-md-12 text-center mt-4">
           		<img src="'.$meta_img.'"  class="auto_bounce cpointer" style="max-width:100%; max-height:400px;" onclick="mosy_img_pop(this.src, \'max-width:100%\', \'\'); glass_modal()"/>
            </div>
             <div class="col-md-12 mt-3 p-0">
              <div class="col-md-12 p-2 text-left">Sharing is caring '.magic_share_button("").'</div>             
              <div class="col-md-12 mt-2 text-left p-0" style="line-height:35px;">
           	   '.$meta_attr_q['details'].'
              </div>
             </div>
             <!--- end jumbotron -->';
  
        if($meta_attr_q['details']=='')
        {
          $jumbotron="";
          $meta_str="";
        }  
  
  $meta_attr=['meta_title'=>$meta_attr_q['msg_titile'], 'meta_description'=>$meta_descr,'meta_img'=>$meta_img, 'meta_url'=>$camplinknavar1, 'post_details'=>$meta_attr_q['details'], 'full_meta_tags'=>rawurlencode($meta_str), 'jumbotron'=>rawurlencode($jumbotron)];
  
  echo json_encode($meta_attr, true);
  
}


if(isset($_POST['loop_posts']))
{
  
  $post_cards_q=posts_data_array("*", " where admin_id='".$_POST['admin_id']."' order by primkey desc", "");
  $post_card="";
  foreach($post_cards_q as $post_node)
  {
   $post_img=magic_rel2abs($post_node['post_image'], magic_current_url());
  $post_card.='                
  <!-- Start side bar image card list -->
                <a href="?post_token='.base64_encode($post_node['msgid']).'" class="row mb-2  text-dark mb-2 pt-2 pb-2 justify-content-center m-0 col-md-7  border-bottom shadow-sm bounce_up_down" style="border-left:6px solid #ccc;">
                  <div class="col-lg-2 col-12 p-0">
                    <img src="'.$post_img.'" class="col-12 p-0 m-0 mr-1" id="" style="min-height:100px"/>
                  </div>
                  <div class="col-lg-10 col-12  text-left p-0 pl-2" style="font-size:13px">
                    <h5 class="border-bottom border_set p-2"><span>'.$post_node['msg_titile'].'</span></h5>
                    <div ><span>'.magic_strip_if($post_node['details'],150, 150).'</span></div>
                  </div>
                </a>
                <!-- End side bar image card list-->';
  
  }
  echo $post_card;
}
  
if(isset($_GET['qtraffic']))
{
  $admin_id=base64_decode($_GET['admin_id']);
  $query_str=base64_decode($_GET['qstr']);
  $query_str_and="";
  
  if($query_str!='')
  {
  	$query_str_and=" and ";  
  }

  $traffic_log_list_query=get_traffic_log("*", " where  ".$query_str." ".$query_str_and." admin_id='$admin_id'   ", "l");

  $trf_arr=[];

  while($trf_arr_res=mysqli_fetch_array($traffic_log_list_query))
  {

  $trf_arr[]=$trf_arr_res;

  }
  echo json_encode($trf_arr, true);
  
}  
  
if(isset($_GET['count_traffic']))
{
  $admin_id=base64_decode($_GET['admin_id']);
  $query_str=base64_decode($_GET['qstr']);
  $query_str_and="";
  
  if($query_str!='')
  {
  	$query_str_and=" and ";  
  }

  $traffic_log_list_query=count_traffic_log(" ".$query_str." ".$query_str_and." admin_id='$admin_id'   ");

  echo $traffic_log_list_query;
  
} 
?>