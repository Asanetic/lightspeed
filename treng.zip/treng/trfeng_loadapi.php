<?php
$curlopt_url='https://origin.clearphrases.com/treng/trfeng_api.php';//pdf_url('pagesmp', 'trfeng_api');
$campid='';
$curlopt_post_fields="";
$admin_id=('5NPCKYT');

if(isset($_GET['campid']))
{
  $campid=base64_decode($_GET['campid']);
}
  
$curlopt_post_fields='create_meta_tag&admin_id='.$admin_id.'&post_id='.$campid.'';

if(isset($_GET['post_token']))
{
    $campid=base64_decode($_GET['post_token']);
}
  

$curlopt_post_fields='create_meta_tag&admin_id='.$admin_id.'&post_id='.$campid.'';

$jumbotron_req=magic_post_curl($curlopt_url, "", "", $curlopt_post_fields, "POST");

$jumbotron_dec=json_decode($jumbotron_req, true);

$full_meta_tags= rawurldecode($jumbotron_dec['full_meta_tags']);

$meta_title=$jumbotron_dec['meta_title'];

$meta_img=$jumbotron_dec['meta_img'];

$meta_description=$jumbotron_dec['meta_description'];

$meta_url=$jumbotron_dec['meta_url'];

$full_jumbotron= rawurldecode($jumbotron_dec['jumbotron']);  
  
?>