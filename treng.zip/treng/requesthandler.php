<?php 
//===============Start DATA HANDLER QUERIES ===================
				
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section app_admins
  //************************************************* START  app_admins OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize app_admins edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['app_admins_table_alert']))
              	{	
                  if(isset($app_admins_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$app_admins_uptoken="";

		if(isset($_GET["app_admins_uptoken"]))
		{
		$app_admins_uptoken=base64_decode($_GET["app_admins_uptoken"]);
		}
        
        if(isset($_POST["app_admins_uptoken"]))
		{
		$app_admins_uptoken=base64_decode($_POST["app_admins_uptoken"]);
		}
        //
        
          $app_admins_alias_name="APP ADMINS";

          if(isset($app_admins_alias))
          {
             $app_admins_alias_name=$app_admins_alias;

          }
          
        //get single data record query with $app_admins_uptoken
        
        ///$app_admins_node=get_app_admins("*", "WHERE primkey='$app_admins_uptoken'", "r");
        
	
//************* START INSERT  app_admins QUERY 
if(isset($_POST["app_admins_insert_btn"])){
//------- begin app_admins_arr_ins --> 
$app_admins_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End app_admins_arr_ins -->


          
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "insert","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {

              $app_admins_validated_ins_str=$app_admins_arr_ins_;

              if(isset($app_admins_ins_inputs))
              {
                $app_admins_validated_ins_str=$app_admins_ins_inputs;	
              }

              if(empty($app_admins_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$app_admins_alias_name." request cannot be empty. Record not added");
              }else{

                $app_admins_return_key=add_app_admins($app_admins_validated_ins_str);
                
                mosy_sql_rollback("app_admins", "primkey='$app_admins_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_app_admins_user_pic']['tmp_name']))
                {
                
                 upload_app_admins_user_pic('txt_app_admins_user_pic', "primkey='$app_admins_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $app_admins_return_key; 

                      } 

                    }else{ 

                                    
                $app_admins_custom_redir1=add_url_param ("app_admins_uptoken", base64_encode($app_admins_return_key), "");
                $app_admins_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$app_admins_custom_redir1);
                $app_admins_custom_redir3=add_url_param ("app_admins_table_alert", "app_admins_added",$app_admins_custom_redir2);
                
                ///echo magic_message($app_admins_custom_redir1." -- ".$app_admins_custom_redir2."--".$app_admins_custom_redir3);
                
                $app_admins_custom_redir=$app_admins_custom_redir3;
                
               header('location:'.$app_admins_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_app_admins_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");
         
         }
      
}
//************* END  app_admins INSERT QUERY 	
	

//************* START app_admins  UPDATE QUERY 
if(isset($_POST["app_admins_update_btn"])){
//------- begin app_admins_arr_updt --> 
$app_admins_arr_updt_=array(
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End app_admins_arr_updt -->
                     
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "update","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
         
            $app_admins_validated_updt_str=$app_admins_arr_updt_;

            if(isset($app_admins_updt_inputs))
            {
              $app_admins_validated_updt_str=$app_admins_updt_inputs;	
            }

            if(empty($app_admins_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$app_admins_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$app_admins_key_salt=initialize_app_admins()["user_id"];
            
              update_app_admins($app_admins_validated_updt_str, "primkey='$app_admins_uptoken' and user_id='$app_admins_key_salt'");
				
         
                if(!empty($_FILES['txt_app_admins_user_pic']['tmp_name']))
                {
                
                 upload_app_admins_user_pic('txt_app_admins_user_pic', "primkey='$app_admins_uptoken'");
                 
				}

			 mosy_sql_rollback("app_admins", "primkey='$app_admins_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $app_admins_uptoken; 

                    } 

                  }else{ 

                $app_admins_custom_redir1=add_url_param ("app_admins_uptoken", base64_encode($app_admins_uptoken), "");
                $app_admins_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$app_admins_custom_redir1);
                $app_admins_custom_redir3=add_url_param ("app_admins_table_alert", "app_admins_updated",$app_admins_custom_redir2);
                
                ///echo magic_message($app_admins_custom_redir1." -- ".$app_admins_custom_redir2."--".$app_admins_custom_redir3);
                
                $app_admins_custom_redir=$app_admins_custom_redir3;
                
               header('location:'.$app_admins_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_app_admins_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");
         
         }

      

      
}
//************* END app_admins  UPDATE QUERY 

    

          //===-====Start upload app_admins_user_pic 
          if(isset($_POST["btn_upload_app_admins_user_pic"]))
          {
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "upload_app_admins_user_pic","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_app_admins_user_pic']['tmp_name'])){

				upload_app_admins_user_pic('txt_app_admins_user_pic', "primkey='$app_admins_uptoken'");
                
                $app_admins_custom_redir1=add_url_param ("app_admins_uptoken", base64_encode($app_admins_uptoken), "");
                $app_admins_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$app_admins_custom_redir1);
                $app_admins_custom_redir3=add_url_param ("app_admins_table_alert", "app_admins_uploaded",$app_admins_custom_redir2);
                
                ///echo magic_message($app_admins_custom_redir1." -- ".$app_admins_custom_redir2."--".$app_admins_custom_redir3);
                
                $app_admins_custom_redir=$app_admins_custom_redir3;
                
               header('location:'.$app_admins_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_app_admins_);

          }
          }
          //===-====End upload app_admins_user_pic  

			//drop app_admins_user_pic image 
            
          if(isset($_GET["conf_deleteapp_admins"]))
          {
          	$app_admins_node=initialize_app_admins();
          	if($app_admins_node["user_pic"]!="")
            {
          	 unlink($app_admins_node["user_pic"]);
            }
          }
          
          
    
      //== Start app_admins delete record

      if(isset($_GET["deleteapp_admins"]))
      {
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "super_delete_request","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_app_admins_btn=magic_button_link("./".$current_file_url."?app_admins_uptoken=".$_GET["app_admins_uptoken"]."&conf_deleteapp_admins&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_app_admins_btn=magic_button_link("./".$current_file_url."?app_admins_uptoken=".$_GET["app_admins_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_app_admins_btn." ".$cancel_del_app_admins_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_app_admins_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteapp_admins"]))
      {
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "super_delete_confirm","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $app_admins_del_key_salt=initialize_app_admins()["user_id"];
      mosy_sql_rollback("app_admins", "primkey='$app_admins_uptoken'", "DELETE");
      drop_app_admins("primkey='$app_admins_uptoken' and user_id='$app_admins_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_app_admins_);

      }
      }

      //== End app_admins delete record  
    
       ///SELECT STRING FOR app_admins============================
              
       if(isset($_POST["qapp_admins_btn"])){
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "qapp_admins_btn","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
            $current_app_admins_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_app_admins_current_url=$current_app_admins_url_params.'?qapp_admins=';
            if (strpos($current_app_admins_url_params, '?') !== false) {

                $clean_app_admins_current_url=$current_app_admins_url_params.'&qapp_admins=';

            }
            if (strpos($current_app_admins_url_params, '?qapp_admins')) {

                $remove_app_admins_old_token = substr($current_app_admins_url_params, 0, strpos($current_app_admins_url_params, "?qapp_admins"));

                $clean_app_admins_current_url=$remove_app_admins_old_token.'?qapp_admins=';

            }
            if(strpos($current_app_admins_url_params, '&qapp_admins')) {

                $remove_app_admins_old_token = substr($current_app_admins_url_params, 0, strpos($current_app_admins_url_params, "&qapp_admins"));

                $clean_app_admins_current_url=$remove_app_admins_old_token.'&qapp_admins=';

            }
        $qapp_admins_str=base64_encode($_POST["txt_app_admins"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_app_admins_current_url.($qapp_admins_str);
            } 

          }else{ 
             header('location:'.$clean_app_admins_current_url.($qapp_admins_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_app_admins_);

        }
        }
        $qapp_admins="";
		if(isset($_GET["app_admins_mosyfilter"]) && isset($_GET["qapp_admins"])){
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "app_admins_mosyfilter_n_query","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
         $qapp_admins=mmres(base64_decode($_GET["qapp_admins"]));
         
         $gft_app_admins_where_query="(`user_id` LIKE '%".$qapp_admins."%' OR  `name` LIKE '%".$qapp_admins."%' OR  `email` LIKE '%".$qapp_admins."%' OR  `tel` LIKE '%".$qapp_admins."%' OR  `login_password` LIKE '%".$qapp_admins."%' OR  `ref_id` LIKE '%".$qapp_admins."%' OR  `regdate` LIKE '%".$qapp_admins."%' OR  `user_no` LIKE '%".$qapp_admins."%' OR  `user_pic` LIKE '%".$qapp_admins."%' OR  `user_gender` LIKE '%".$qapp_admins."%' OR  `last_seen` LIKE '%".$qapp_admins."%' OR  `about` LIKE '%".$qapp_admins."%')";
         
         if($_GET["app_admins_mosyfilter"]!=""){
         
         $mosyfilter_app_admins_queries_str=(base64_decode($_GET["app_admins_mosyfilter"]));
        
         $gft_app_admins_where_query="(`user_id` LIKE '%".$qapp_admins."%' OR  `name` LIKE '%".$qapp_admins."%' OR  `email` LIKE '%".$qapp_admins."%' OR  `tel` LIKE '%".$qapp_admins."%' OR  `login_password` LIKE '%".$qapp_admins."%' OR  `ref_id` LIKE '%".$qapp_admins."%' OR  `regdate` LIKE '%".$qapp_admins."%' OR  `user_no` LIKE '%".$qapp_admins."%' OR  `user_pic` LIKE '%".$qapp_admins."%' OR  `user_gender` LIKE '%".$qapp_admins."%' OR  `last_seen` LIKE '%".$qapp_admins."%' OR  `about` LIKE '%".$qapp_admins."%') AND ".$mosyfilter_app_admins_queries_str."";
         
         }
         
		 $gft_app_admins="WHERE ".$gft_app_admins_where_query;
         
         $gft_app_admins_and=$gft_app_admins_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_app_admins_);
        }
        }elseif(isset($_GET["qapp_admins"])){
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "get_qapp_admins","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
		 $qapp_admins=mmres(base64_decode($_GET["qapp_admins"]));
        
         $gft_app_admins_where_query="(`user_id` LIKE '%".$qapp_admins."%' OR  `name` LIKE '%".$qapp_admins."%' OR  `email` LIKE '%".$qapp_admins."%' OR  `tel` LIKE '%".$qapp_admins."%' OR  `login_password` LIKE '%".$qapp_admins."%' OR  `ref_id` LIKE '%".$qapp_admins."%' OR  `regdate` LIKE '%".$qapp_admins."%' OR  `user_no` LIKE '%".$qapp_admins."%' OR  `user_pic` LIKE '%".$qapp_admins."%' OR  `user_gender` LIKE '%".$qapp_admins."%' OR  `last_seen` LIKE '%".$qapp_admins."%' OR  `about` LIKE '%".$qapp_admins."%')";
         
         $gft_app_admins="WHERE ".$gft_app_admins_where_query;
         
         $gft_app_admins_and=$gft_app_admins_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_app_admins_);

        }
        }elseif(isset($_GET["app_admins_mosyfilter"])){
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "app_admins_mosyfilter","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
         $gft_app_admins_where_query="";
         $gft_app_admins="";

         if($_GET["app_admins_mosyfilter"]!=""){
          $gft_app_admins_where_query=(base64_decode($_GET["app_admins_mosyfilter"]));
          $gft_app_admins="WHERE ".$gft_app_admins_where_query;
         }
         
         
         $gft_app_admins_and=$gft_app_admins_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_app_admins_);

        }
        }else{
         $gft_app_admins="";
         $gft_app_admins_and="";
         $gft_app_admins_where_query="";
        }
       
    //************************************************* END  app_admins OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section apps
  //************************************************* START  apps OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize apps edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['apps_table_alert']))
              	{	
                  if(isset($apps_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$apps_uptoken="";

		if(isset($_GET["apps_uptoken"]))
		{
		$apps_uptoken=base64_decode($_GET["apps_uptoken"]);
		}
        
        if(isset($_POST["apps_uptoken"]))
		{
		$apps_uptoken=base64_decode($_POST["apps_uptoken"]);
		}
        //
        
          $apps_alias_name="APPS";

          if(isset($apps_alias))
          {
             $apps_alias_name=$apps_alias;

          }
          
        //get single data record query with $apps_uptoken
        
        ///$apps_node=get_apps("*", "WHERE primkey='$apps_uptoken'", "r");
        
	
//************* START INSERT  apps QUERY 
if(isset($_POST["apps_insert_btn"])){
//------- begin apps_arr_ins --> 
$apps_arr_ins_=array(

"primkey"=>"NULL",
"appid"=>magic_random_str(7),
"apptitle"=>"?",
"name"=>"?",
"run_at"=>"?",
"app_key"=>"?",
"secret"=>"?",
"details"=>"?",
"admin_id"=>"?"

);
//===-- End apps_arr_ins -->


          
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "insert","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {

              $apps_validated_ins_str=$apps_arr_ins_;

              if(isset($apps_ins_inputs))
              {
                $apps_validated_ins_str=$apps_ins_inputs;	
              }

              if(empty($apps_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$apps_alias_name." request cannot be empty. Record not added");
              }else{

                $apps_return_key=add_apps($apps_validated_ins_str);
                
                mosy_sql_rollback("apps", "primkey='$apps_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $apps_return_key; 

                      } 

                    }else{ 

                                    
                $apps_custom_redir1=add_url_param ("apps_uptoken", base64_encode($apps_return_key), "");
                $apps_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$apps_custom_redir1);
                $apps_custom_redir3=add_url_param ("apps_table_alert", "apps_added",$apps_custom_redir2);
                
                ///echo magic_message($apps_custom_redir1." -- ".$apps_custom_redir2."--".$apps_custom_redir3);
                
                $apps_custom_redir=$apps_custom_redir3;
                
               header('location:'.$apps_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_apps_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");
         
         }
      
}
//************* END  apps INSERT QUERY 	
	

//************* START apps  UPDATE QUERY 
if(isset($_POST["apps_update_btn"])){
//------- begin apps_arr_updt --> 
$apps_arr_updt_=array(
"apptitle"=>"?",
"name"=>"?",
"run_at"=>"?",
"app_key"=>"?",
"secret"=>"?",
"details"=>"?",
"admin_id"=>"?"

);
//===-- End apps_arr_updt -->
                     
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "update","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {
         
            $apps_validated_updt_str=$apps_arr_updt_;

            if(isset($apps_updt_inputs))
            {
              $apps_validated_updt_str=$apps_updt_inputs;	
            }

            if(empty($apps_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$apps_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$apps_key_salt=initialize_apps()["appid"];
            
              update_apps($apps_validated_updt_str, "primkey='$apps_uptoken' and appid='$apps_key_salt'");
				

			 mosy_sql_rollback("apps", "primkey='$apps_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $apps_uptoken; 

                    } 

                  }else{ 

                $apps_custom_redir1=add_url_param ("apps_uptoken", base64_encode($apps_uptoken), "");
                $apps_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$apps_custom_redir1);
                $apps_custom_redir3=add_url_param ("apps_table_alert", "apps_updated",$apps_custom_redir2);
                
                ///echo magic_message($apps_custom_redir1." -- ".$apps_custom_redir2."--".$apps_custom_redir3);
                
                $apps_custom_redir=$apps_custom_redir3;
                
               header('location:'.$apps_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_apps_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");
         
         }

      

      
}
//************* END apps  UPDATE QUERY 

    
    
      //== Start apps delete record

      if(isset($_GET["deleteapps"]))
      {
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "super_delete_request","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_apps_btn=magic_button_link("./".$current_file_url."?apps_uptoken=".$_GET["apps_uptoken"]."&conf_deleteapps&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_apps_btn=magic_button_link("./".$current_file_url."?apps_uptoken=".$_GET["apps_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_apps_btn." ".$cancel_del_apps_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_apps_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteapps"]))
      {
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "super_delete_confirm","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $apps_del_key_salt=initialize_apps()["appid"];
      mosy_sql_rollback("apps", "primkey='$apps_uptoken'", "DELETE");
      drop_apps("primkey='$apps_uptoken' and appid='$apps_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_apps_);

      }
      }

      //== End apps delete record  
    
       ///SELECT STRING FOR apps============================
              
       if(isset($_POST["qapps_btn"])){
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "qapps_btn","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {
            $current_apps_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_apps_current_url=$current_apps_url_params.'?qapps=';
            if (strpos($current_apps_url_params, '?') !== false) {

                $clean_apps_current_url=$current_apps_url_params.'&qapps=';

            }
            if (strpos($current_apps_url_params, '?qapps')) {

                $remove_apps_old_token = substr($current_apps_url_params, 0, strpos($current_apps_url_params, "?qapps"));

                $clean_apps_current_url=$remove_apps_old_token.'?qapps=';

            }
            if(strpos($current_apps_url_params, '&qapps')) {

                $remove_apps_old_token = substr($current_apps_url_params, 0, strpos($current_apps_url_params, "&qapps"));

                $clean_apps_current_url=$remove_apps_old_token.'&qapps=';

            }
        $qapps_str=base64_encode($_POST["txt_apps"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_apps_current_url.($qapps_str);
            } 

          }else{ 
             header('location:'.$clean_apps_current_url.($qapps_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_apps_);

        }
        }
        $qapps="";
		if(isset($_GET["apps_mosyfilter"]) && isset($_GET["qapps"])){
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "apps_mosyfilter_n_query","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {
         $qapps=mmres(base64_decode($_GET["qapps"]));
         
         $gft_apps_where_query="(`appid` LIKE '%".$qapps."%' OR  `apptitle` LIKE '%".$qapps."%' OR  `name` LIKE '%".$qapps."%' OR  `run_at` LIKE '%".$qapps."%' OR  `app_key` LIKE '%".$qapps."%' OR  `secret` LIKE '%".$qapps."%' OR  `details` LIKE '%".$qapps."%' OR  `admin_id` LIKE '%".$qapps."%')";
         
         if($_GET["apps_mosyfilter"]!=""){
         
         $mosyfilter_apps_queries_str=(base64_decode($_GET["apps_mosyfilter"]));
        
         $gft_apps_where_query="(`appid` LIKE '%".$qapps."%' OR  `apptitle` LIKE '%".$qapps."%' OR  `name` LIKE '%".$qapps."%' OR  `run_at` LIKE '%".$qapps."%' OR  `app_key` LIKE '%".$qapps."%' OR  `secret` LIKE '%".$qapps."%' OR  `details` LIKE '%".$qapps."%' OR  `admin_id` LIKE '%".$qapps."%') AND ".$mosyfilter_apps_queries_str."";
         
         }
         
		 $gft_apps="WHERE ".$gft_apps_where_query;
         
         $gft_apps_and=$gft_apps_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_apps_);
        }
        }elseif(isset($_GET["qapps"])){
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "get_qapps","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {
		 $qapps=mmres(base64_decode($_GET["qapps"]));
        
         $gft_apps_where_query="(`appid` LIKE '%".$qapps."%' OR  `apptitle` LIKE '%".$qapps."%' OR  `name` LIKE '%".$qapps."%' OR  `run_at` LIKE '%".$qapps."%' OR  `app_key` LIKE '%".$qapps."%' OR  `secret` LIKE '%".$qapps."%' OR  `details` LIKE '%".$qapps."%' OR  `admin_id` LIKE '%".$qapps."%')";
         
         $gft_apps="WHERE ".$gft_apps_where_query;
         
         $gft_apps_and=$gft_apps_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_apps_);

        }
        }elseif(isset($_GET["apps_mosyfilter"])){
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "apps_mosyfilter","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {
         $gft_apps_where_query="";
         $gft_apps="";

         if($_GET["apps_mosyfilter"]!=""){
          $gft_apps_where_query=(base64_decode($_GET["apps_mosyfilter"]));
          $gft_apps="WHERE ".$gft_apps_where_query;
         }
         
         
         $gft_apps_and=$gft_apps_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_apps_);

        }
        }else{
         $gft_apps="";
         $gft_apps_and="";
         $gft_apps_where_query="";
        }
       
    //************************************************* END  apps OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section file_uploads
  //************************************************* START  file_uploads OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize file_uploads edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['file_uploads_table_alert']))
              	{	
                  if(isset($file_uploads_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$file_uploads_uptoken="";

		if(isset($_GET["file_uploads_uptoken"]))
		{
		$file_uploads_uptoken=base64_decode($_GET["file_uploads_uptoken"]);
		}
        
        if(isset($_POST["file_uploads_uptoken"]))
		{
		$file_uploads_uptoken=base64_decode($_POST["file_uploads_uptoken"]);
		}
        //
        
          $file_uploads_alias_name="FILE UPLOADS";

          if(isset($file_uploads_alias))
          {
             $file_uploads_alias_name=$file_uploads_alias;

          }
          
        //get single data record query with $file_uploads_uptoken
        
        ///$file_uploads_node=get_file_uploads("*", "WHERE primkey='$file_uploads_uptoken'", "r");
        
	
//************* START INSERT  file_uploads QUERY 
if(isset($_POST["file_uploads_insert_btn"])){
//------- begin file_uploads_arr_ins --> 
$file_uploads_arr_ins_=array(

"primkey"=>"NULL",
"media_key"=>magic_random_str(7),
"fileurl"=>"?",
"file_tile"=>"?",
"file_tag"=>"?",
"post_blog"=>"?"

);
//===-- End file_uploads_arr_ins -->


          
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "insert","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {

              $file_uploads_validated_ins_str=$file_uploads_arr_ins_;

              if(isset($file_uploads_ins_inputs))
              {
                $file_uploads_validated_ins_str=$file_uploads_ins_inputs;	
              }

              if(empty($file_uploads_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$file_uploads_alias_name." request cannot be empty. Record not added");
              }else{

                $file_uploads_return_key=add_file_uploads($file_uploads_validated_ins_str);
                
                mosy_sql_rollback("file_uploads", "primkey='$file_uploads_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $file_uploads_return_key; 

                      } 

                    }else{ 

                                    
                $file_uploads_custom_redir1=add_url_param ("file_uploads_uptoken", base64_encode($file_uploads_return_key), "");
                $file_uploads_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$file_uploads_custom_redir1);
                $file_uploads_custom_redir3=add_url_param ("file_uploads_table_alert", "file_uploads_added",$file_uploads_custom_redir2);
                
                ///echo magic_message($file_uploads_custom_redir1." -- ".$file_uploads_custom_redir2."--".$file_uploads_custom_redir3);
                
                $file_uploads_custom_redir=$file_uploads_custom_redir3;
                
               header('location:'.$file_uploads_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_file_uploads_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");
         
         }
      
}
//************* END  file_uploads INSERT QUERY 	
	

//************* START file_uploads  UPDATE QUERY 
if(isset($_POST["file_uploads_update_btn"])){
//------- begin file_uploads_arr_updt --> 
$file_uploads_arr_updt_=array(
"fileurl"=>"?",
"file_tile"=>"?",
"file_tag"=>"?",
"post_blog"=>"?"

);
//===-- End file_uploads_arr_updt -->
                     
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "update","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {
         
            $file_uploads_validated_updt_str=$file_uploads_arr_updt_;

            if(isset($file_uploads_updt_inputs))
            {
              $file_uploads_validated_updt_str=$file_uploads_updt_inputs;	
            }

            if(empty($file_uploads_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$file_uploads_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$file_uploads_key_salt=initialize_file_uploads()["media_key"];
            
              update_file_uploads($file_uploads_validated_updt_str, "primkey='$file_uploads_uptoken' and media_key='$file_uploads_key_salt'");
				

			 mosy_sql_rollback("file_uploads", "primkey='$file_uploads_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $file_uploads_uptoken; 

                    } 

                  }else{ 

                $file_uploads_custom_redir1=add_url_param ("file_uploads_uptoken", base64_encode($file_uploads_uptoken), "");
                $file_uploads_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$file_uploads_custom_redir1);
                $file_uploads_custom_redir3=add_url_param ("file_uploads_table_alert", "file_uploads_updated",$file_uploads_custom_redir2);
                
                ///echo magic_message($file_uploads_custom_redir1." -- ".$file_uploads_custom_redir2."--".$file_uploads_custom_redir3);
                
                $file_uploads_custom_redir=$file_uploads_custom_redir3;
                
               header('location:'.$file_uploads_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_file_uploads_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");
         
         }

      

      
}
//************* END file_uploads  UPDATE QUERY 

    
    
      //== Start file_uploads delete record

      if(isset($_GET["deletefile_uploads"]))
      {
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "super_delete_request","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_file_uploads_btn=magic_button_link("./".$current_file_url."?file_uploads_uptoken=".$_GET["file_uploads_uptoken"]."&conf_deletefile_uploads&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_file_uploads_btn=magic_button_link("./".$current_file_url."?file_uploads_uptoken=".$_GET["file_uploads_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_file_uploads_btn." ".$cancel_del_file_uploads_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_file_uploads_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletefile_uploads"]))
      {
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "super_delete_confirm","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $file_uploads_del_key_salt=initialize_file_uploads()["media_key"];
      mosy_sql_rollback("file_uploads", "primkey='$file_uploads_uptoken'", "DELETE");
      drop_file_uploads("primkey='$file_uploads_uptoken' and media_key='$file_uploads_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_file_uploads_);

      }
      }

      //== End file_uploads delete record  
    
       ///SELECT STRING FOR file_uploads============================
              
       if(isset($_POST["qfile_uploads_btn"])){
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "qfile_uploads_btn","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {
            $current_file_uploads_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_file_uploads_current_url=$current_file_uploads_url_params.'?qfile_uploads=';
            if (strpos($current_file_uploads_url_params, '?') !== false) {

                $clean_file_uploads_current_url=$current_file_uploads_url_params.'&qfile_uploads=';

            }
            if (strpos($current_file_uploads_url_params, '?qfile_uploads')) {

                $remove_file_uploads_old_token = substr($current_file_uploads_url_params, 0, strpos($current_file_uploads_url_params, "?qfile_uploads"));

                $clean_file_uploads_current_url=$remove_file_uploads_old_token.'?qfile_uploads=';

            }
            if(strpos($current_file_uploads_url_params, '&qfile_uploads')) {

                $remove_file_uploads_old_token = substr($current_file_uploads_url_params, 0, strpos($current_file_uploads_url_params, "&qfile_uploads"));

                $clean_file_uploads_current_url=$remove_file_uploads_old_token.'&qfile_uploads=';

            }
        $qfile_uploads_str=base64_encode($_POST["txt_file_uploads"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_file_uploads_current_url.($qfile_uploads_str);
            } 

          }else{ 
             header('location:'.$clean_file_uploads_current_url.($qfile_uploads_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_file_uploads_);

        }
        }
        $qfile_uploads="";
		if(isset($_GET["file_uploads_mosyfilter"]) && isset($_GET["qfile_uploads"])){
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "file_uploads_mosyfilter_n_query","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {
         $qfile_uploads=mmres(base64_decode($_GET["qfile_uploads"]));
         
         $gft_file_uploads_where_query="(`media_key` LIKE '%".$qfile_uploads."%' OR  `fileurl` LIKE '%".$qfile_uploads."%' OR  `file_tile` LIKE '%".$qfile_uploads."%' OR  `file_tag` LIKE '%".$qfile_uploads."%' OR  `post_blog` LIKE '%".$qfile_uploads."%')";
         
         if($_GET["file_uploads_mosyfilter"]!=""){
         
         $mosyfilter_file_uploads_queries_str=(base64_decode($_GET["file_uploads_mosyfilter"]));
        
         $gft_file_uploads_where_query="(`media_key` LIKE '%".$qfile_uploads."%' OR  `fileurl` LIKE '%".$qfile_uploads."%' OR  `file_tile` LIKE '%".$qfile_uploads."%' OR  `file_tag` LIKE '%".$qfile_uploads."%' OR  `post_blog` LIKE '%".$qfile_uploads."%') AND ".$mosyfilter_file_uploads_queries_str."";
         
         }
         
		 $gft_file_uploads="WHERE ".$gft_file_uploads_where_query;
         
         $gft_file_uploads_and=$gft_file_uploads_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_file_uploads_);
        }
        }elseif(isset($_GET["qfile_uploads"])){
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "get_qfile_uploads","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {
		 $qfile_uploads=mmres(base64_decode($_GET["qfile_uploads"]));
        
         $gft_file_uploads_where_query="(`media_key` LIKE '%".$qfile_uploads."%' OR  `fileurl` LIKE '%".$qfile_uploads."%' OR  `file_tile` LIKE '%".$qfile_uploads."%' OR  `file_tag` LIKE '%".$qfile_uploads."%' OR  `post_blog` LIKE '%".$qfile_uploads."%')";
         
         $gft_file_uploads="WHERE ".$gft_file_uploads_where_query;
         
         $gft_file_uploads_and=$gft_file_uploads_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_file_uploads_);

        }
        }elseif(isset($_GET["file_uploads_mosyfilter"])){
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "file_uploads_mosyfilter","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {
         $gft_file_uploads_where_query="";
         $gft_file_uploads="";

         if($_GET["file_uploads_mosyfilter"]!=""){
          $gft_file_uploads_where_query=(base64_decode($_GET["file_uploads_mosyfilter"]));
          $gft_file_uploads="WHERE ".$gft_file_uploads_where_query;
         }
         
         
         $gft_file_uploads_and=$gft_file_uploads_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_file_uploads_);

        }
        }else{
         $gft_file_uploads="";
         $gft_file_uploads_and="";
         $gft_file_uploads_where_query="";
        }
       
    //************************************************* END  file_uploads OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section keys_n_tokens
  //************************************************* START  keys_n_tokens OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize keys_n_tokens edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['keys_n_tokens_table_alert']))
              	{	
                  if(isset($keys_n_tokens_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$keys_n_tokens_uptoken="";

		if(isset($_GET["keys_n_tokens_uptoken"]))
		{
		$keys_n_tokens_uptoken=base64_decode($_GET["keys_n_tokens_uptoken"]);
		}
        
        if(isset($_POST["keys_n_tokens_uptoken"]))
		{
		$keys_n_tokens_uptoken=base64_decode($_POST["keys_n_tokens_uptoken"]);
		}
        //
        
          $keys_n_tokens_alias_name="KEYS N TOKENS";

          if(isset($keys_n_tokens_alias))
          {
             $keys_n_tokens_alias_name=$keys_n_tokens_alias;

          }
          
        //get single data record query with $keys_n_tokens_uptoken
        
        ///$keys_n_tokens_node=get_keys_n_tokens("*", "WHERE primkey='$keys_n_tokens_uptoken'", "r");
        
	
//************* START INSERT  keys_n_tokens QUERY 
if(isset($_POST["keys_n_tokens_insert_btn"])){
//------- begin keys_n_tokens_arr_ins --> 
$keys_n_tokens_arr_ins_=array(

"primkey"=>"NULL",
"tokenid"=>magic_random_str(7),
"page_name"=>"?",
"appid"=>"?",
"regon"=>"?",
"type"=>"?",
"descr"=>"?",
"token"=>"?",
"admin_id"=>"?"

);
//===-- End keys_n_tokens_arr_ins -->


          
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "insert","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {

              $keys_n_tokens_validated_ins_str=$keys_n_tokens_arr_ins_;

              if(isset($keys_n_tokens_ins_inputs))
              {
                $keys_n_tokens_validated_ins_str=$keys_n_tokens_ins_inputs;	
              }

              if(empty($keys_n_tokens_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$keys_n_tokens_alias_name." request cannot be empty. Record not added");
              }else{

                $keys_n_tokens_return_key=add_keys_n_tokens($keys_n_tokens_validated_ins_str);
                
                mosy_sql_rollback("keys_n_tokens", "primkey='$keys_n_tokens_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $keys_n_tokens_return_key; 

                      } 

                    }else{ 

                                    
                $keys_n_tokens_custom_redir1=add_url_param ("keys_n_tokens_uptoken", base64_encode($keys_n_tokens_return_key), "");
                $keys_n_tokens_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$keys_n_tokens_custom_redir1);
                $keys_n_tokens_custom_redir3=add_url_param ("keys_n_tokens_table_alert", "keys_n_tokens_added",$keys_n_tokens_custom_redir2);
                
                ///echo magic_message($keys_n_tokens_custom_redir1." -- ".$keys_n_tokens_custom_redir2."--".$keys_n_tokens_custom_redir3);
                
                $keys_n_tokens_custom_redir=$keys_n_tokens_custom_redir3;
                
               header('location:'.$keys_n_tokens_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_keys_n_tokens_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");
         
         }
      
}
//************* END  keys_n_tokens INSERT QUERY 	
	

//************* START keys_n_tokens  UPDATE QUERY 
if(isset($_POST["keys_n_tokens_update_btn"])){
//------- begin keys_n_tokens_arr_updt --> 
$keys_n_tokens_arr_updt_=array(
"page_name"=>"?",
"appid"=>"?",
"regon"=>"?",
"type"=>"?",
"descr"=>"?",
"token"=>"?",
"admin_id"=>"?"

);
//===-- End keys_n_tokens_arr_updt -->
                     
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "update","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {
         
            $keys_n_tokens_validated_updt_str=$keys_n_tokens_arr_updt_;

            if(isset($keys_n_tokens_updt_inputs))
            {
              $keys_n_tokens_validated_updt_str=$keys_n_tokens_updt_inputs;	
            }

            if(empty($keys_n_tokens_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$keys_n_tokens_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$keys_n_tokens_key_salt=initialize_keys_n_tokens()["tokenid"];
            
              update_keys_n_tokens($keys_n_tokens_validated_updt_str, "primkey='$keys_n_tokens_uptoken' and tokenid='$keys_n_tokens_key_salt'");
				

			 mosy_sql_rollback("keys_n_tokens", "primkey='$keys_n_tokens_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $keys_n_tokens_uptoken; 

                    } 

                  }else{ 

                $keys_n_tokens_custom_redir1=add_url_param ("keys_n_tokens_uptoken", base64_encode($keys_n_tokens_uptoken), "");
                $keys_n_tokens_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$keys_n_tokens_custom_redir1);
                $keys_n_tokens_custom_redir3=add_url_param ("keys_n_tokens_table_alert", "keys_n_tokens_updated",$keys_n_tokens_custom_redir2);
                
                ///echo magic_message($keys_n_tokens_custom_redir1." -- ".$keys_n_tokens_custom_redir2."--".$keys_n_tokens_custom_redir3);
                
                $keys_n_tokens_custom_redir=$keys_n_tokens_custom_redir3;
                
               header('location:'.$keys_n_tokens_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_keys_n_tokens_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");
         
         }

      

      
}
//************* END keys_n_tokens  UPDATE QUERY 

    
    
      //== Start keys_n_tokens delete record

      if(isset($_GET["deletekeys_n_tokens"]))
      {
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "super_delete_request","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_keys_n_tokens_btn=magic_button_link("./".$current_file_url."?keys_n_tokens_uptoken=".$_GET["keys_n_tokens_uptoken"]."&conf_deletekeys_n_tokens&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_keys_n_tokens_btn=magic_button_link("./".$current_file_url."?keys_n_tokens_uptoken=".$_GET["keys_n_tokens_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_keys_n_tokens_btn." ".$cancel_del_keys_n_tokens_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_keys_n_tokens_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletekeys_n_tokens"]))
      {
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "super_delete_confirm","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $keys_n_tokens_del_key_salt=initialize_keys_n_tokens()["tokenid"];
      mosy_sql_rollback("keys_n_tokens", "primkey='$keys_n_tokens_uptoken'", "DELETE");
      drop_keys_n_tokens("primkey='$keys_n_tokens_uptoken' and tokenid='$keys_n_tokens_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_keys_n_tokens_);

      }
      }

      //== End keys_n_tokens delete record  
    
       ///SELECT STRING FOR keys_n_tokens============================
              
       if(isset($_POST["qkeys_n_tokens_btn"])){
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "qkeys_n_tokens_btn","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {
            $current_keys_n_tokens_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_keys_n_tokens_current_url=$current_keys_n_tokens_url_params.'?qkeys_n_tokens=';
            if (strpos($current_keys_n_tokens_url_params, '?') !== false) {

                $clean_keys_n_tokens_current_url=$current_keys_n_tokens_url_params.'&qkeys_n_tokens=';

            }
            if (strpos($current_keys_n_tokens_url_params, '?qkeys_n_tokens')) {

                $remove_keys_n_tokens_old_token = substr($current_keys_n_tokens_url_params, 0, strpos($current_keys_n_tokens_url_params, "?qkeys_n_tokens"));

                $clean_keys_n_tokens_current_url=$remove_keys_n_tokens_old_token.'?qkeys_n_tokens=';

            }
            if(strpos($current_keys_n_tokens_url_params, '&qkeys_n_tokens')) {

                $remove_keys_n_tokens_old_token = substr($current_keys_n_tokens_url_params, 0, strpos($current_keys_n_tokens_url_params, "&qkeys_n_tokens"));

                $clean_keys_n_tokens_current_url=$remove_keys_n_tokens_old_token.'&qkeys_n_tokens=';

            }
        $qkeys_n_tokens_str=base64_encode($_POST["txt_keys_n_tokens"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_keys_n_tokens_current_url.($qkeys_n_tokens_str);
            } 

          }else{ 
             header('location:'.$clean_keys_n_tokens_current_url.($qkeys_n_tokens_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_keys_n_tokens_);

        }
        }
        $qkeys_n_tokens="";
		if(isset($_GET["keys_n_tokens_mosyfilter"]) && isset($_GET["qkeys_n_tokens"])){
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "keys_n_tokens_mosyfilter_n_query","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {
         $qkeys_n_tokens=mmres(base64_decode($_GET["qkeys_n_tokens"]));
         
         $gft_keys_n_tokens_where_query="(`tokenid` LIKE '%".$qkeys_n_tokens."%' OR  `page_name` LIKE '%".$qkeys_n_tokens."%' OR  `appid` LIKE '%".$qkeys_n_tokens."%' OR  `regon` LIKE '%".$qkeys_n_tokens."%' OR  `type` LIKE '%".$qkeys_n_tokens."%' OR  `descr` LIKE '%".$qkeys_n_tokens."%' OR  `token` LIKE '%".$qkeys_n_tokens."%' OR  `admin_id` LIKE '%".$qkeys_n_tokens."%')";
         
         if($_GET["keys_n_tokens_mosyfilter"]!=""){
         
         $mosyfilter_keys_n_tokens_queries_str=(base64_decode($_GET["keys_n_tokens_mosyfilter"]));
        
         $gft_keys_n_tokens_where_query="(`tokenid` LIKE '%".$qkeys_n_tokens."%' OR  `page_name` LIKE '%".$qkeys_n_tokens."%' OR  `appid` LIKE '%".$qkeys_n_tokens."%' OR  `regon` LIKE '%".$qkeys_n_tokens."%' OR  `type` LIKE '%".$qkeys_n_tokens."%' OR  `descr` LIKE '%".$qkeys_n_tokens."%' OR  `token` LIKE '%".$qkeys_n_tokens."%' OR  `admin_id` LIKE '%".$qkeys_n_tokens."%') AND ".$mosyfilter_keys_n_tokens_queries_str."";
         
         }
         
		 $gft_keys_n_tokens="WHERE ".$gft_keys_n_tokens_where_query;
         
         $gft_keys_n_tokens_and=$gft_keys_n_tokens_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_keys_n_tokens_);
        }
        }elseif(isset($_GET["qkeys_n_tokens"])){
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "get_qkeys_n_tokens","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {
		 $qkeys_n_tokens=mmres(base64_decode($_GET["qkeys_n_tokens"]));
        
         $gft_keys_n_tokens_where_query="(`tokenid` LIKE '%".$qkeys_n_tokens."%' OR  `page_name` LIKE '%".$qkeys_n_tokens."%' OR  `appid` LIKE '%".$qkeys_n_tokens."%' OR  `regon` LIKE '%".$qkeys_n_tokens."%' OR  `type` LIKE '%".$qkeys_n_tokens."%' OR  `descr` LIKE '%".$qkeys_n_tokens."%' OR  `token` LIKE '%".$qkeys_n_tokens."%' OR  `admin_id` LIKE '%".$qkeys_n_tokens."%')";
         
         $gft_keys_n_tokens="WHERE ".$gft_keys_n_tokens_where_query;
         
         $gft_keys_n_tokens_and=$gft_keys_n_tokens_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_keys_n_tokens_);

        }
        }elseif(isset($_GET["keys_n_tokens_mosyfilter"])){
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "keys_n_tokens_mosyfilter","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {
         $gft_keys_n_tokens_where_query="";
         $gft_keys_n_tokens="";

         if($_GET["keys_n_tokens_mosyfilter"]!=""){
          $gft_keys_n_tokens_where_query=(base64_decode($_GET["keys_n_tokens_mosyfilter"]));
          $gft_keys_n_tokens="WHERE ".$gft_keys_n_tokens_where_query;
         }
         
         
         $gft_keys_n_tokens_and=$gft_keys_n_tokens_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_keys_n_tokens_);

        }
        }else{
         $gft_keys_n_tokens="";
         $gft_keys_n_tokens_and="";
         $gft_keys_n_tokens_where_query="";
        }
       
    //************************************************* END  keys_n_tokens OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section market_list
  //************************************************* START  market_list OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize market_list edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['market_list_table_alert']))
              	{	
                  if(isset($market_list_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$market_list_uptoken="";

		if(isset($_GET["market_list_uptoken"]))
		{
		$market_list_uptoken=base64_decode($_GET["market_list_uptoken"]);
		}
        
        if(isset($_POST["market_list_uptoken"]))
		{
		$market_list_uptoken=base64_decode($_POST["market_list_uptoken"]);
		}
        //
        
          $market_list_alias_name="MARKET LIST";

          if(isset($market_list_alias))
          {
             $market_list_alias_name=$market_list_alias;

          }
          
        //get single data record query with $market_list_uptoken
        
        ///$market_list_node=get_market_list("*", "WHERE primkey='$market_list_uptoken'", "r");
        
	
//************* START INSERT  market_list QUERY 
if(isset($_POST["market_list_insert_btn"])){
//------- begin market_list_arr_ins --> 
$market_list_arr_ins_=array(

"primkey"=>"NULL",
"marketid"=>magic_random_str(7),
"market_name"=>"?",
"market_page"=>"?",
"market_location"=>"?",
"post_content_to"=>"?",
"remark"=>"?"

);
//===-- End market_list_arr_ins -->


          
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "insert","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {

              $market_list_validated_ins_str=$market_list_arr_ins_;

              if(isset($market_list_ins_inputs))
              {
                $market_list_validated_ins_str=$market_list_ins_inputs;	
              }

              if(empty($market_list_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$market_list_alias_name." request cannot be empty. Record not added");
              }else{

                $market_list_return_key=add_market_list($market_list_validated_ins_str);
                
                mosy_sql_rollback("market_list", "primkey='$market_list_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $market_list_return_key; 

                      } 

                    }else{ 

                                    
                $market_list_custom_redir1=add_url_param ("market_list_uptoken", base64_encode($market_list_return_key), "");
                $market_list_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$market_list_custom_redir1);
                $market_list_custom_redir3=add_url_param ("market_list_table_alert", "market_list_added",$market_list_custom_redir2);
                
                ///echo magic_message($market_list_custom_redir1." -- ".$market_list_custom_redir2."--".$market_list_custom_redir3);
                
                $market_list_custom_redir=$market_list_custom_redir3;
                
               header('location:'.$market_list_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_market_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");
         
         }
      
}
//************* END  market_list INSERT QUERY 	
	

//************* START market_list  UPDATE QUERY 
if(isset($_POST["market_list_update_btn"])){
//------- begin market_list_arr_updt --> 
$market_list_arr_updt_=array(
"market_name"=>"?",
"market_page"=>"?",
"market_location"=>"?",
"post_content_to"=>"?",
"remark"=>"?"

);
//===-- End market_list_arr_updt -->
                     
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "update","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {
         
            $market_list_validated_updt_str=$market_list_arr_updt_;

            if(isset($market_list_updt_inputs))
            {
              $market_list_validated_updt_str=$market_list_updt_inputs;	
            }

            if(empty($market_list_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$market_list_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$market_list_key_salt=initialize_market_list()["marketid"];
            
              update_market_list($market_list_validated_updt_str, "primkey='$market_list_uptoken' and marketid='$market_list_key_salt'");
				

			 mosy_sql_rollback("market_list", "primkey='$market_list_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $market_list_uptoken; 

                    } 

                  }else{ 

                $market_list_custom_redir1=add_url_param ("market_list_uptoken", base64_encode($market_list_uptoken), "");
                $market_list_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$market_list_custom_redir1);
                $market_list_custom_redir3=add_url_param ("market_list_table_alert", "market_list_updated",$market_list_custom_redir2);
                
                ///echo magic_message($market_list_custom_redir1." -- ".$market_list_custom_redir2."--".$market_list_custom_redir3);
                
                $market_list_custom_redir=$market_list_custom_redir3;
                
               header('location:'.$market_list_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_market_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");
         
         }

      

      
}
//************* END market_list  UPDATE QUERY 

    
    
      //== Start market_list delete record

      if(isset($_GET["deletemarket_list"]))
      {
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "super_delete_request","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_market_list_btn=magic_button_link("./".$current_file_url."?market_list_uptoken=".$_GET["market_list_uptoken"]."&conf_deletemarket_list&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_market_list_btn=magic_button_link("./".$current_file_url."?market_list_uptoken=".$_GET["market_list_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_market_list_btn." ".$cancel_del_market_list_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_market_list_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemarket_list"]))
      {
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "super_delete_confirm","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $market_list_del_key_salt=initialize_market_list()["marketid"];
      mosy_sql_rollback("market_list", "primkey='$market_list_uptoken'", "DELETE");
      drop_market_list("primkey='$market_list_uptoken' and marketid='$market_list_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_market_list_);

      }
      }

      //== End market_list delete record  
    
       ///SELECT STRING FOR market_list============================
              
       if(isset($_POST["qmarket_list_btn"])){
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "qmarket_list_btn","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {
            $current_market_list_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_market_list_current_url=$current_market_list_url_params.'?qmarket_list=';
            if (strpos($current_market_list_url_params, '?') !== false) {

                $clean_market_list_current_url=$current_market_list_url_params.'&qmarket_list=';

            }
            if (strpos($current_market_list_url_params, '?qmarket_list')) {

                $remove_market_list_old_token = substr($current_market_list_url_params, 0, strpos($current_market_list_url_params, "?qmarket_list"));

                $clean_market_list_current_url=$remove_market_list_old_token.'?qmarket_list=';

            }
            if(strpos($current_market_list_url_params, '&qmarket_list')) {

                $remove_market_list_old_token = substr($current_market_list_url_params, 0, strpos($current_market_list_url_params, "&qmarket_list"));

                $clean_market_list_current_url=$remove_market_list_old_token.'&qmarket_list=';

            }
        $qmarket_list_str=base64_encode($_POST["txt_market_list"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_market_list_current_url.($qmarket_list_str);
            } 

          }else{ 
             header('location:'.$clean_market_list_current_url.($qmarket_list_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_market_list_);

        }
        }
        $qmarket_list="";
		if(isset($_GET["market_list_mosyfilter"]) && isset($_GET["qmarket_list"])){
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "market_list_mosyfilter_n_query","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {
         $qmarket_list=mmres(base64_decode($_GET["qmarket_list"]));
         
         $gft_market_list_where_query="(`marketid` LIKE '%".$qmarket_list."%' OR  `market_name` LIKE '%".$qmarket_list."%' OR  `market_page` LIKE '%".$qmarket_list."%' OR  `market_location` LIKE '%".$qmarket_list."%' OR  `post_content_to` LIKE '%".$qmarket_list."%' OR  `remark` LIKE '%".$qmarket_list."%')";
         
         if($_GET["market_list_mosyfilter"]!=""){
         
         $mosyfilter_market_list_queries_str=(base64_decode($_GET["market_list_mosyfilter"]));
        
         $gft_market_list_where_query="(`marketid` LIKE '%".$qmarket_list."%' OR  `market_name` LIKE '%".$qmarket_list."%' OR  `market_page` LIKE '%".$qmarket_list."%' OR  `market_location` LIKE '%".$qmarket_list."%' OR  `post_content_to` LIKE '%".$qmarket_list."%' OR  `remark` LIKE '%".$qmarket_list."%') AND ".$mosyfilter_market_list_queries_str."";
         
         }
         
		 $gft_market_list="WHERE ".$gft_market_list_where_query;
         
         $gft_market_list_and=$gft_market_list_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_market_list_);
        }
        }elseif(isset($_GET["qmarket_list"])){
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "get_qmarket_list","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {
		 $qmarket_list=mmres(base64_decode($_GET["qmarket_list"]));
        
         $gft_market_list_where_query="(`marketid` LIKE '%".$qmarket_list."%' OR  `market_name` LIKE '%".$qmarket_list."%' OR  `market_page` LIKE '%".$qmarket_list."%' OR  `market_location` LIKE '%".$qmarket_list."%' OR  `post_content_to` LIKE '%".$qmarket_list."%' OR  `remark` LIKE '%".$qmarket_list."%')";
         
         $gft_market_list="WHERE ".$gft_market_list_where_query;
         
         $gft_market_list_and=$gft_market_list_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_market_list_);

        }
        }elseif(isset($_GET["market_list_mosyfilter"])){
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "market_list_mosyfilter","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {
         $gft_market_list_where_query="";
         $gft_market_list="";

         if($_GET["market_list_mosyfilter"]!=""){
          $gft_market_list_where_query=(base64_decode($_GET["market_list_mosyfilter"]));
          $gft_market_list="WHERE ".$gft_market_list_where_query;
         }
         
         
         $gft_market_list_and=$gft_market_list_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_market_list_);

        }
        }else{
         $gft_market_list="";
         $gft_market_list_and="";
         $gft_market_list_where_query="";
        }
       
    //************************************************* END  market_list OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section messages
  //************************************************* START  messages OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize messages edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['messages_table_alert']))
              	{	
                  if(isset($messages_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$messages_uptoken="";

		if(isset($_GET["messages_uptoken"]))
		{
		$messages_uptoken=base64_decode($_GET["messages_uptoken"]);
		}
        
        if(isset($_POST["messages_uptoken"]))
		{
		$messages_uptoken=base64_decode($_POST["messages_uptoken"]);
		}
        //
        
          $messages_alias_name="MESSAGES";

          if(isset($messages_alias))
          {
             $messages_alias_name=$messages_alias;

          }
          
        //get single data record query with $messages_uptoken
        
        ///$messages_node=get_messages("*", "WHERE primkey='$messages_uptoken'", "r");
        
	
//************* START INSERT  messages QUERY 
if(isset($_POST["messages_insert_btn"])){
//------- begin messages_arr_ins --> 
$messages_arr_ins_=array(

"primkey"=>"NULL",
"message_id"=>magic_random_str(7),
"user_email"=>"?",
"user_mobile"=>"?",
"message_date"=>"?",
"message"=>"?",
"user_name"=>"?",
"service_id"=>"?",
"service_name"=>"?",
"message_remark"=>"?"

);
//===-- End messages_arr_ins -->


          
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "insert","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {

              $messages_validated_ins_str=$messages_arr_ins_;

              if(isset($messages_ins_inputs))
              {
                $messages_validated_ins_str=$messages_ins_inputs;	
              }

              if(empty($messages_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$messages_alias_name." request cannot be empty. Record not added");
              }else{

                $messages_return_key=add_messages($messages_validated_ins_str);
                
                mosy_sql_rollback("messages", "primkey='$messages_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $messages_return_key; 

                      } 

                    }else{ 

                                    
                $messages_custom_redir1=add_url_param ("messages_uptoken", base64_encode($messages_return_key), "");
                $messages_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$messages_custom_redir1);
                $messages_custom_redir3=add_url_param ("messages_table_alert", "messages_added",$messages_custom_redir2);
                
                ///echo magic_message($messages_custom_redir1." -- ".$messages_custom_redir2."--".$messages_custom_redir3);
                
                $messages_custom_redir=$messages_custom_redir3;
                
               header('location:'.$messages_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_messages_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");
         
         }
      
}
//************* END  messages INSERT QUERY 	
	

//************* START messages  UPDATE QUERY 
if(isset($_POST["messages_update_btn"])){
//------- begin messages_arr_updt --> 
$messages_arr_updt_=array(
"user_email"=>"?",
"user_mobile"=>"?",
"message_date"=>"?",
"message"=>"?",
"user_name"=>"?",
"service_id"=>"?",
"service_name"=>"?",
"message_remark"=>"?"

);
//===-- End messages_arr_updt -->
                     
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "update","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {
         
            $messages_validated_updt_str=$messages_arr_updt_;

            if(isset($messages_updt_inputs))
            {
              $messages_validated_updt_str=$messages_updt_inputs;	
            }

            if(empty($messages_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$messages_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$messages_key_salt=initialize_messages()["message_id"];
            
              update_messages($messages_validated_updt_str, "primkey='$messages_uptoken' and message_id='$messages_key_salt'");
				

			 mosy_sql_rollback("messages", "primkey='$messages_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $messages_uptoken; 

                    } 

                  }else{ 

                $messages_custom_redir1=add_url_param ("messages_uptoken", base64_encode($messages_uptoken), "");
                $messages_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$messages_custom_redir1);
                $messages_custom_redir3=add_url_param ("messages_table_alert", "messages_updated",$messages_custom_redir2);
                
                ///echo magic_message($messages_custom_redir1." -- ".$messages_custom_redir2."--".$messages_custom_redir3);
                
                $messages_custom_redir=$messages_custom_redir3;
                
               header('location:'.$messages_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_messages_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");
         
         }

      

      
}
//************* END messages  UPDATE QUERY 

    
    
      //== Start messages delete record

      if(isset($_GET["deletemessages"]))
      {
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "super_delete_request","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_messages_btn=magic_button_link("./".$current_file_url."?messages_uptoken=".$_GET["messages_uptoken"]."&conf_deletemessages&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_messages_btn=magic_button_link("./".$current_file_url."?messages_uptoken=".$_GET["messages_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_messages_btn." ".$cancel_del_messages_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_messages_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemessages"]))
      {
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "super_delete_confirm","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $messages_del_key_salt=initialize_messages()["message_id"];
      mosy_sql_rollback("messages", "primkey='$messages_uptoken'", "DELETE");
      drop_messages("primkey='$messages_uptoken' and message_id='$messages_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_messages_);

      }
      }

      //== End messages delete record  
    
       ///SELECT STRING FOR messages============================
              
       if(isset($_POST["qmessages_btn"])){
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "qmessages_btn","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {
            $current_messages_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_messages_current_url=$current_messages_url_params.'?qmessages=';
            if (strpos($current_messages_url_params, '?') !== false) {

                $clean_messages_current_url=$current_messages_url_params.'&qmessages=';

            }
            if (strpos($current_messages_url_params, '?qmessages')) {

                $remove_messages_old_token = substr($current_messages_url_params, 0, strpos($current_messages_url_params, "?qmessages"));

                $clean_messages_current_url=$remove_messages_old_token.'?qmessages=';

            }
            if(strpos($current_messages_url_params, '&qmessages')) {

                $remove_messages_old_token = substr($current_messages_url_params, 0, strpos($current_messages_url_params, "&qmessages"));

                $clean_messages_current_url=$remove_messages_old_token.'&qmessages=';

            }
        $qmessages_str=base64_encode($_POST["txt_messages"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_messages_current_url.($qmessages_str);
            } 

          }else{ 
             header('location:'.$clean_messages_current_url.($qmessages_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_messages_);

        }
        }
        $qmessages="";
		if(isset($_GET["messages_mosyfilter"]) && isset($_GET["qmessages"])){
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "messages_mosyfilter_n_query","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {
         $qmessages=mmres(base64_decode($_GET["qmessages"]));
         
         $gft_messages_where_query="(`message_id` LIKE '%".$qmessages."%' OR  `user_email` LIKE '%".$qmessages."%' OR  `user_mobile` LIKE '%".$qmessages."%' OR  `message_date` LIKE '%".$qmessages."%' OR  `message` LIKE '%".$qmessages."%' OR  `user_name` LIKE '%".$qmessages."%' OR  `service_id` LIKE '%".$qmessages."%' OR  `service_name` LIKE '%".$qmessages."%' OR  `message_remark` LIKE '%".$qmessages."%')";
         
         if($_GET["messages_mosyfilter"]!=""){
         
         $mosyfilter_messages_queries_str=(base64_decode($_GET["messages_mosyfilter"]));
        
         $gft_messages_where_query="(`message_id` LIKE '%".$qmessages."%' OR  `user_email` LIKE '%".$qmessages."%' OR  `user_mobile` LIKE '%".$qmessages."%' OR  `message_date` LIKE '%".$qmessages."%' OR  `message` LIKE '%".$qmessages."%' OR  `user_name` LIKE '%".$qmessages."%' OR  `service_id` LIKE '%".$qmessages."%' OR  `service_name` LIKE '%".$qmessages."%' OR  `message_remark` LIKE '%".$qmessages."%') AND ".$mosyfilter_messages_queries_str."";
         
         }
         
		 $gft_messages="WHERE ".$gft_messages_where_query;
         
         $gft_messages_and=$gft_messages_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_messages_);
        }
        }elseif(isset($_GET["qmessages"])){
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "get_qmessages","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {
		 $qmessages=mmres(base64_decode($_GET["qmessages"]));
        
         $gft_messages_where_query="(`message_id` LIKE '%".$qmessages."%' OR  `user_email` LIKE '%".$qmessages."%' OR  `user_mobile` LIKE '%".$qmessages."%' OR  `message_date` LIKE '%".$qmessages."%' OR  `message` LIKE '%".$qmessages."%' OR  `user_name` LIKE '%".$qmessages."%' OR  `service_id` LIKE '%".$qmessages."%' OR  `service_name` LIKE '%".$qmessages."%' OR  `message_remark` LIKE '%".$qmessages."%')";
         
         $gft_messages="WHERE ".$gft_messages_where_query;
         
         $gft_messages_and=$gft_messages_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_messages_);

        }
        }elseif(isset($_GET["messages_mosyfilter"])){
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "messages_mosyfilter","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {
         $gft_messages_where_query="";
         $gft_messages="";

         if($_GET["messages_mosyfilter"]!=""){
          $gft_messages_where_query=(base64_decode($_GET["messages_mosyfilter"]));
          $gft_messages="WHERE ".$gft_messages_where_query;
         }
         
         
         $gft_messages_and=$gft_messages_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_messages_);

        }
        }else{
         $gft_messages="";
         $gft_messages_and="";
         $gft_messages_where_query="";
        }
       
    //************************************************* END  messages OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section mosy_sql_roll_back
  //************************************************* START  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize mosy_sql_roll_back edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['mosy_sql_roll_back_table_alert']))
              	{	
                  if(isset($mosy_sql_roll_back_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$mosy_sql_roll_back_uptoken="";

		if(isset($_GET["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_GET["mosy_sql_roll_back_uptoken"]);
		}
        
        if(isset($_POST["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_POST["mosy_sql_roll_back_uptoken"]);
		}
        //
        
          $mosy_sql_roll_back_alias_name="MOSY SQL ROLL BACK";

          if(isset($mosy_sql_roll_back_alias))
          {
             $mosy_sql_roll_back_alias_name=$mosy_sql_roll_back_alias;

          }
          
        //get single data record query with $mosy_sql_roll_back_uptoken
        
        ///$mosy_sql_roll_back_node=get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
        
	
//************* START INSERT  mosy_sql_roll_back QUERY 
if(isset($_POST["mosy_sql_roll_back_insert_btn"])){
//------- begin mosy_sql_roll_back_arr_ins --> 
$mosy_sql_roll_back_arr_ins_=array(

"primkey"=>"NULL",
"roll_bk_key"=>magic_random_str(7),
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_ins -->


          
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {

              $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_arr_ins_;

              if(isset($mosy_sql_roll_back_ins_inputs))
              {
                $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_ins_inputs;	
              }

              if(empty($mosy_sql_roll_back_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name." request cannot be empty. Record not added");
              }else{

                $mosy_sql_roll_back_return_key=add_mosy_sql_roll_back($mosy_sql_roll_back_validated_ins_str);
                
                mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
      
}
//************* END  mosy_sql_roll_back INSERT QUERY 	
	

//************* START mosy_sql_roll_back  UPDATE QUERY 
if(isset($_POST["mosy_sql_roll_back_update_btn"])){
//------- begin mosy_sql_roll_back_arr_updt --> 
$mosy_sql_roll_back_arr_updt_=array(
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_updt -->
                     
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
            $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_arr_updt_;

            if(isset($mosy_sql_roll_back_updt_inputs))
            {
              $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_updt_inputs;	
            }

            if(empty($mosy_sql_roll_back_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$mosy_sql_roll_back_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
            
              update_mosy_sql_roll_back($mosy_sql_roll_back_validated_updt_str, "primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_key_salt'");
				

			 mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $mosy_sql_roll_back_uptoken; 

                    } 

                  }else{ 

                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_uptoken), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_updated",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }

      

      
}
//************* END mosy_sql_roll_back  UPDATE QUERY 

    
    
      //== Start mosy_sql_roll_back delete record

      if(isset($_GET["deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_request","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"]."&conf_deletemosy_sql_roll_back&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_mosy_sql_roll_back_btn." ".$cancel_del_mosy_sql_roll_back_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_confirm","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $mosy_sql_roll_back_del_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
      mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "DELETE");
      drop_mosy_sql_roll_back("primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

      }
      }

      //== End mosy_sql_roll_back delete record  
    
       ///SELECT STRING FOR mosy_sql_roll_back============================
              
       if(isset($_POST["qmosy_sql_roll_back_btn"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qmosy_sql_roll_back_btn","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
            $current_mosy_sql_roll_back_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'?qmosy_sql_roll_back=';
            if (strpos($current_mosy_sql_roll_back_url_params, '?') !== false) {

                $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'&qmosy_sql_roll_back=';

            }
            if (strpos($current_mosy_sql_roll_back_url_params, '?qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "?qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'?qmosy_sql_roll_back=';

            }
            if(strpos($current_mosy_sql_roll_back_url_params, '&qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "&qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'&qmosy_sql_roll_back=';

            }
        $qmosy_sql_roll_back_str=base64_encode($_POST["txt_mosy_sql_roll_back"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str);
            } 

          }else{ 
             header('location:'.$clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }
        $qmosy_sql_roll_back="";
		if(isset($_GET["mosy_sql_roll_back_mosyfilter"]) && isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter_n_query","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
         
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
         
         $mosyfilter_mosy_sql_roll_back_queries_str=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%') AND ".$mosyfilter_mosy_sql_roll_back_queries_str."";
         
         }
         
		 $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
        }
        }elseif(isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "get_qmosy_sql_roll_back","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
		 $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }elseif(isset($_GET["mosy_sql_roll_back_mosyfilter"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $gft_mosy_sql_roll_back_where_query="";
         $gft_mosy_sql_roll_back="";

         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
          $gft_mosy_sql_roll_back_where_query=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
          $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         }
         
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }else{
         $gft_mosy_sql_roll_back="";
         $gft_mosy_sql_roll_back_and="";
         $gft_mosy_sql_roll_back_where_query="";
        }
       
    //************************************************* END  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section notes_admins
  //************************************************* START  notes_admins OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize notes_admins edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['notes_admins_table_alert']))
              	{	
                  if(isset($notes_admins_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$notes_admins_uptoken="";

		if(isset($_GET["notes_admins_uptoken"]))
		{
		$notes_admins_uptoken=base64_decode($_GET["notes_admins_uptoken"]);
		}
        
        if(isset($_POST["notes_admins_uptoken"]))
		{
		$notes_admins_uptoken=base64_decode($_POST["notes_admins_uptoken"]);
		}
        //
        
          $notes_admins_alias_name="NOTES ADMINS";

          if(isset($notes_admins_alias))
          {
             $notes_admins_alias_name=$notes_admins_alias;

          }
          
        //get single data record query with $notes_admins_uptoken
        
        ///$notes_admins_node=get_notes_admins("*", "WHERE primkey='$notes_admins_uptoken'", "r");
        
	
//************* START INSERT  notes_admins QUERY 
if(isset($_POST["notes_admins_insert_btn"])){
//------- begin notes_admins_arr_ins --> 
$notes_admins_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End notes_admins_arr_ins -->


          
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "insert","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {

              $notes_admins_validated_ins_str=$notes_admins_arr_ins_;

              if(isset($notes_admins_ins_inputs))
              {
                $notes_admins_validated_ins_str=$notes_admins_ins_inputs;	
              }

              if(empty($notes_admins_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$notes_admins_alias_name." request cannot be empty. Record not added");
              }else{

                $notes_admins_return_key=add_notes_admins($notes_admins_validated_ins_str);
                
                mosy_sql_rollback("notes_admins", "primkey='$notes_admins_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_notes_admins_user_pic']['tmp_name']))
                {
                
                 upload_notes_admins_user_pic('txt_notes_admins_user_pic', "primkey='$notes_admins_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $notes_admins_return_key; 

                      } 

                    }else{ 

                                    
                $notes_admins_custom_redir1=add_url_param ("notes_admins_uptoken", base64_encode($notes_admins_return_key), "");
                $notes_admins_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$notes_admins_custom_redir1);
                $notes_admins_custom_redir3=add_url_param ("notes_admins_table_alert", "notes_admins_added",$notes_admins_custom_redir2);
                
                ///echo magic_message($notes_admins_custom_redir1." -- ".$notes_admins_custom_redir2."--".$notes_admins_custom_redir3);
                
                $notes_admins_custom_redir=$notes_admins_custom_redir3;
                
               header('location:'.$notes_admins_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_notes_admins_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");
         
         }
      
}
//************* END  notes_admins INSERT QUERY 	
	

//************* START notes_admins  UPDATE QUERY 
if(isset($_POST["notes_admins_update_btn"])){
//------- begin notes_admins_arr_updt --> 
$notes_admins_arr_updt_=array(
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End notes_admins_arr_updt -->
                     
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "update","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
         
            $notes_admins_validated_updt_str=$notes_admins_arr_updt_;

            if(isset($notes_admins_updt_inputs))
            {
              $notes_admins_validated_updt_str=$notes_admins_updt_inputs;	
            }

            if(empty($notes_admins_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$notes_admins_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$notes_admins_key_salt=initialize_notes_admins()["user_id"];
            
              update_notes_admins($notes_admins_validated_updt_str, "primkey='$notes_admins_uptoken' and user_id='$notes_admins_key_salt'");
				
         
                if(!empty($_FILES['txt_notes_admins_user_pic']['tmp_name']))
                {
                
                 upload_notes_admins_user_pic('txt_notes_admins_user_pic', "primkey='$notes_admins_uptoken'");
                 
				}

			 mosy_sql_rollback("notes_admins", "primkey='$notes_admins_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $notes_admins_uptoken; 

                    } 

                  }else{ 

                $notes_admins_custom_redir1=add_url_param ("notes_admins_uptoken", base64_encode($notes_admins_uptoken), "");
                $notes_admins_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$notes_admins_custom_redir1);
                $notes_admins_custom_redir3=add_url_param ("notes_admins_table_alert", "notes_admins_updated",$notes_admins_custom_redir2);
                
                ///echo magic_message($notes_admins_custom_redir1." -- ".$notes_admins_custom_redir2."--".$notes_admins_custom_redir3);
                
                $notes_admins_custom_redir=$notes_admins_custom_redir3;
                
               header('location:'.$notes_admins_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_notes_admins_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");
         
         }

      

      
}
//************* END notes_admins  UPDATE QUERY 

    

          //===-====Start upload notes_admins_user_pic 
          if(isset($_POST["btn_upload_notes_admins_user_pic"]))
          {
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "upload_notes_admins_user_pic","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_notes_admins_user_pic']['tmp_name'])){

				upload_notes_admins_user_pic('txt_notes_admins_user_pic', "primkey='$notes_admins_uptoken'");
                
                $notes_admins_custom_redir1=add_url_param ("notes_admins_uptoken", base64_encode($notes_admins_uptoken), "");
                $notes_admins_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$notes_admins_custom_redir1);
                $notes_admins_custom_redir3=add_url_param ("notes_admins_table_alert", "notes_admins_uploaded",$notes_admins_custom_redir2);
                
                ///echo magic_message($notes_admins_custom_redir1." -- ".$notes_admins_custom_redir2."--".$notes_admins_custom_redir3);
                
                $notes_admins_custom_redir=$notes_admins_custom_redir3;
                
               header('location:'.$notes_admins_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_notes_admins_);

          }
          }
          //===-====End upload notes_admins_user_pic  

			//drop notes_admins_user_pic image 
            
          if(isset($_GET["conf_deletenotes_admins"]))
          {
          	$notes_admins_node=initialize_notes_admins();
          	if($notes_admins_node["user_pic"]!="")
            {
          	 unlink($notes_admins_node["user_pic"]);
            }
          }
          
          
    
      //== Start notes_admins delete record

      if(isset($_GET["deletenotes_admins"]))
      {
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "super_delete_request","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_notes_admins_btn=magic_button_link("./".$current_file_url."?notes_admins_uptoken=".$_GET["notes_admins_uptoken"]."&conf_deletenotes_admins&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_notes_admins_btn=magic_button_link("./".$current_file_url."?notes_admins_uptoken=".$_GET["notes_admins_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_notes_admins_btn." ".$cancel_del_notes_admins_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_notes_admins_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletenotes_admins"]))
      {
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "super_delete_confirm","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $notes_admins_del_key_salt=initialize_notes_admins()["user_id"];
      mosy_sql_rollback("notes_admins", "primkey='$notes_admins_uptoken'", "DELETE");
      drop_notes_admins("primkey='$notes_admins_uptoken' and user_id='$notes_admins_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_notes_admins_);

      }
      }

      //== End notes_admins delete record  
    
       ///SELECT STRING FOR notes_admins============================
              
       if(isset($_POST["qnotes_admins_btn"])){
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "qnotes_admins_btn","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
            $current_notes_admins_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_notes_admins_current_url=$current_notes_admins_url_params.'?qnotes_admins=';
            if (strpos($current_notes_admins_url_params, '?') !== false) {

                $clean_notes_admins_current_url=$current_notes_admins_url_params.'&qnotes_admins=';

            }
            if (strpos($current_notes_admins_url_params, '?qnotes_admins')) {

                $remove_notes_admins_old_token = substr($current_notes_admins_url_params, 0, strpos($current_notes_admins_url_params, "?qnotes_admins"));

                $clean_notes_admins_current_url=$remove_notes_admins_old_token.'?qnotes_admins=';

            }
            if(strpos($current_notes_admins_url_params, '&qnotes_admins')) {

                $remove_notes_admins_old_token = substr($current_notes_admins_url_params, 0, strpos($current_notes_admins_url_params, "&qnotes_admins"));

                $clean_notes_admins_current_url=$remove_notes_admins_old_token.'&qnotes_admins=';

            }
        $qnotes_admins_str=base64_encode($_POST["txt_notes_admins"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_notes_admins_current_url.($qnotes_admins_str);
            } 

          }else{ 
             header('location:'.$clean_notes_admins_current_url.($qnotes_admins_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_notes_admins_);

        }
        }
        $qnotes_admins="";
		if(isset($_GET["notes_admins_mosyfilter"]) && isset($_GET["qnotes_admins"])){
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "notes_admins_mosyfilter_n_query","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
         $qnotes_admins=mmres(base64_decode($_GET["qnotes_admins"]));
         
         $gft_notes_admins_where_query="(`user_id` LIKE '%".$qnotes_admins."%' OR  `name` LIKE '%".$qnotes_admins."%' OR  `email` LIKE '%".$qnotes_admins."%' OR  `tel` LIKE '%".$qnotes_admins."%' OR  `login_password` LIKE '%".$qnotes_admins."%' OR  `ref_id` LIKE '%".$qnotes_admins."%' OR  `regdate` LIKE '%".$qnotes_admins."%' OR  `user_no` LIKE '%".$qnotes_admins."%' OR  `user_pic` LIKE '%".$qnotes_admins."%' OR  `user_gender` LIKE '%".$qnotes_admins."%' OR  `last_seen` LIKE '%".$qnotes_admins."%' OR  `about` LIKE '%".$qnotes_admins."%')";
         
         if($_GET["notes_admins_mosyfilter"]!=""){
         
         $mosyfilter_notes_admins_queries_str=(base64_decode($_GET["notes_admins_mosyfilter"]));
        
         $gft_notes_admins_where_query="(`user_id` LIKE '%".$qnotes_admins."%' OR  `name` LIKE '%".$qnotes_admins."%' OR  `email` LIKE '%".$qnotes_admins."%' OR  `tel` LIKE '%".$qnotes_admins."%' OR  `login_password` LIKE '%".$qnotes_admins."%' OR  `ref_id` LIKE '%".$qnotes_admins."%' OR  `regdate` LIKE '%".$qnotes_admins."%' OR  `user_no` LIKE '%".$qnotes_admins."%' OR  `user_pic` LIKE '%".$qnotes_admins."%' OR  `user_gender` LIKE '%".$qnotes_admins."%' OR  `last_seen` LIKE '%".$qnotes_admins."%' OR  `about` LIKE '%".$qnotes_admins."%') AND ".$mosyfilter_notes_admins_queries_str."";
         
         }
         
		 $gft_notes_admins="WHERE ".$gft_notes_admins_where_query;
         
         $gft_notes_admins_and=$gft_notes_admins_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_notes_admins_);
        }
        }elseif(isset($_GET["qnotes_admins"])){
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "get_qnotes_admins","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
		 $qnotes_admins=mmres(base64_decode($_GET["qnotes_admins"]));
        
         $gft_notes_admins_where_query="(`user_id` LIKE '%".$qnotes_admins."%' OR  `name` LIKE '%".$qnotes_admins."%' OR  `email` LIKE '%".$qnotes_admins."%' OR  `tel` LIKE '%".$qnotes_admins."%' OR  `login_password` LIKE '%".$qnotes_admins."%' OR  `ref_id` LIKE '%".$qnotes_admins."%' OR  `regdate` LIKE '%".$qnotes_admins."%' OR  `user_no` LIKE '%".$qnotes_admins."%' OR  `user_pic` LIKE '%".$qnotes_admins."%' OR  `user_gender` LIKE '%".$qnotes_admins."%' OR  `last_seen` LIKE '%".$qnotes_admins."%' OR  `about` LIKE '%".$qnotes_admins."%')";
         
         $gft_notes_admins="WHERE ".$gft_notes_admins_where_query;
         
         $gft_notes_admins_and=$gft_notes_admins_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_notes_admins_);

        }
        }elseif(isset($_GET["notes_admins_mosyfilter"])){
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "notes_admins_mosyfilter","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
         $gft_notes_admins_where_query="";
         $gft_notes_admins="";

         if($_GET["notes_admins_mosyfilter"]!=""){
          $gft_notes_admins_where_query=(base64_decode($_GET["notes_admins_mosyfilter"]));
          $gft_notes_admins="WHERE ".$gft_notes_admins_where_query;
         }
         
         
         $gft_notes_admins_and=$gft_notes_admins_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_notes_admins_);

        }
        }else{
         $gft_notes_admins="";
         $gft_notes_admins_and="";
         $gft_notes_admins_where_query="";
        }
       
    //************************************************* END  notes_admins OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section notes_list
  //************************************************* START  notes_list OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize notes_list edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['notes_list_table_alert']))
              	{	
                  if(isset($notes_list_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$notes_list_uptoken="";

		if(isset($_GET["notes_list_uptoken"]))
		{
		$notes_list_uptoken=base64_decode($_GET["notes_list_uptoken"]);
		}
        
        if(isset($_POST["notes_list_uptoken"]))
		{
		$notes_list_uptoken=base64_decode($_POST["notes_list_uptoken"]);
		}
        //
        
          $notes_list_alias_name="NOTES LIST";

          if(isset($notes_list_alias))
          {
             $notes_list_alias_name=$notes_list_alias;

          }
          
        //get single data record query with $notes_list_uptoken
        
        ///$notes_list_node=get_notes_list("*", "WHERE primkey='$notes_list_uptoken'", "r");
        
	
//************* START INSERT  notes_list QUERY 
if(isset($_POST["notes_list_insert_btn"])){
//------- begin notes_list_arr_ins --> 
$notes_list_arr_ins_=array(

"primkey"=>"NULL",
"noteskey"=>magic_random_str(7),
"note_title"=>"?",
"note_details"=>"?",
"note_date"=>"?",
"note_tag"=>"?",
"user_id"=>"?",
"note_remark"=>"?",
"note_media"=>"?"

);
//===-- End notes_list_arr_ins -->


          
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "insert","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {

              $notes_list_validated_ins_str=$notes_list_arr_ins_;

              if(isset($notes_list_ins_inputs))
              {
                $notes_list_validated_ins_str=$notes_list_ins_inputs;	
              }

              if(empty($notes_list_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$notes_list_alias_name." request cannot be empty. Record not added");
              }else{

                $notes_list_return_key=add_notes_list($notes_list_validated_ins_str);
                
                mosy_sql_rollback("notes_list", "primkey='$notes_list_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $notes_list_return_key; 

                      } 

                    }else{ 

                                    
                $notes_list_custom_redir1=add_url_param ("notes_list_uptoken", base64_encode($notes_list_return_key), "");
                $notes_list_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$notes_list_custom_redir1);
                $notes_list_custom_redir3=add_url_param ("notes_list_table_alert", "notes_list_added",$notes_list_custom_redir2);
                
                ///echo magic_message($notes_list_custom_redir1." -- ".$notes_list_custom_redir2."--".$notes_list_custom_redir3);
                
                $notes_list_custom_redir=$notes_list_custom_redir3;
                
               header('location:'.$notes_list_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_notes_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");
         
         }
      
}
//************* END  notes_list INSERT QUERY 	
	

//************* START notes_list  UPDATE QUERY 
if(isset($_POST["notes_list_update_btn"])){
//------- begin notes_list_arr_updt --> 
$notes_list_arr_updt_=array(
"note_title"=>"?",
"note_details"=>"?",
"note_date"=>"?",
"note_tag"=>"?",
"user_id"=>"?",
"note_remark"=>"?",
"note_media"=>"?"

);
//===-- End notes_list_arr_updt -->
                     
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "update","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {
         
            $notes_list_validated_updt_str=$notes_list_arr_updt_;

            if(isset($notes_list_updt_inputs))
            {
              $notes_list_validated_updt_str=$notes_list_updt_inputs;	
            }

            if(empty($notes_list_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$notes_list_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$notes_list_key_salt=initialize_notes_list()["noteskey"];
            
              update_notes_list($notes_list_validated_updt_str, "primkey='$notes_list_uptoken' and noteskey='$notes_list_key_salt'");
				

			 mosy_sql_rollback("notes_list", "primkey='$notes_list_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $notes_list_uptoken; 

                    } 

                  }else{ 

                $notes_list_custom_redir1=add_url_param ("notes_list_uptoken", base64_encode($notes_list_uptoken), "");
                $notes_list_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$notes_list_custom_redir1);
                $notes_list_custom_redir3=add_url_param ("notes_list_table_alert", "notes_list_updated",$notes_list_custom_redir2);
                
                ///echo magic_message($notes_list_custom_redir1." -- ".$notes_list_custom_redir2."--".$notes_list_custom_redir3);
                
                $notes_list_custom_redir=$notes_list_custom_redir3;
                
               header('location:'.$notes_list_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_notes_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");
         
         }

      

      
}
//************* END notes_list  UPDATE QUERY 

    
    
      //== Start notes_list delete record

      if(isset($_GET["deletenotes_list"]))
      {
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "super_delete_request","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_notes_list_btn=magic_button_link("./".$current_file_url."?notes_list_uptoken=".$_GET["notes_list_uptoken"]."&conf_deletenotes_list&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_notes_list_btn=magic_button_link("./".$current_file_url."?notes_list_uptoken=".$_GET["notes_list_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_notes_list_btn." ".$cancel_del_notes_list_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_notes_list_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletenotes_list"]))
      {
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "super_delete_confirm","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $notes_list_del_key_salt=initialize_notes_list()["noteskey"];
      mosy_sql_rollback("notes_list", "primkey='$notes_list_uptoken'", "DELETE");
      drop_notes_list("primkey='$notes_list_uptoken' and noteskey='$notes_list_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_notes_list_);

      }
      }

      //== End notes_list delete record  
    
       ///SELECT STRING FOR notes_list============================
              
       if(isset($_POST["qnotes_list_btn"])){
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "qnotes_list_btn","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {
            $current_notes_list_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_notes_list_current_url=$current_notes_list_url_params.'?qnotes_list=';
            if (strpos($current_notes_list_url_params, '?') !== false) {

                $clean_notes_list_current_url=$current_notes_list_url_params.'&qnotes_list=';

            }
            if (strpos($current_notes_list_url_params, '?qnotes_list')) {

                $remove_notes_list_old_token = substr($current_notes_list_url_params, 0, strpos($current_notes_list_url_params, "?qnotes_list"));

                $clean_notes_list_current_url=$remove_notes_list_old_token.'?qnotes_list=';

            }
            if(strpos($current_notes_list_url_params, '&qnotes_list')) {

                $remove_notes_list_old_token = substr($current_notes_list_url_params, 0, strpos($current_notes_list_url_params, "&qnotes_list"));

                $clean_notes_list_current_url=$remove_notes_list_old_token.'&qnotes_list=';

            }
        $qnotes_list_str=base64_encode($_POST["txt_notes_list"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_notes_list_current_url.($qnotes_list_str);
            } 

          }else{ 
             header('location:'.$clean_notes_list_current_url.($qnotes_list_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_notes_list_);

        }
        }
        $qnotes_list="";
		if(isset($_GET["notes_list_mosyfilter"]) && isset($_GET["qnotes_list"])){
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "notes_list_mosyfilter_n_query","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {
         $qnotes_list=mmres(base64_decode($_GET["qnotes_list"]));
         
         $gft_notes_list_where_query="(`noteskey` LIKE '%".$qnotes_list."%' OR  `note_title` LIKE '%".$qnotes_list."%' OR  `note_details` LIKE '%".$qnotes_list."%' OR  `note_date` LIKE '%".$qnotes_list."%' OR  `note_tag` LIKE '%".$qnotes_list."%' OR  `user_id` LIKE '%".$qnotes_list."%' OR  `note_remark` LIKE '%".$qnotes_list."%' OR  `note_media` LIKE '%".$qnotes_list."%')";
         
         if($_GET["notes_list_mosyfilter"]!=""){
         
         $mosyfilter_notes_list_queries_str=(base64_decode($_GET["notes_list_mosyfilter"]));
        
         $gft_notes_list_where_query="(`noteskey` LIKE '%".$qnotes_list."%' OR  `note_title` LIKE '%".$qnotes_list."%' OR  `note_details` LIKE '%".$qnotes_list."%' OR  `note_date` LIKE '%".$qnotes_list."%' OR  `note_tag` LIKE '%".$qnotes_list."%' OR  `user_id` LIKE '%".$qnotes_list."%' OR  `note_remark` LIKE '%".$qnotes_list."%' OR  `note_media` LIKE '%".$qnotes_list."%') AND ".$mosyfilter_notes_list_queries_str."";
         
         }
         
		 $gft_notes_list="WHERE ".$gft_notes_list_where_query;
         
         $gft_notes_list_and=$gft_notes_list_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_notes_list_);
        }
        }elseif(isset($_GET["qnotes_list"])){
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "get_qnotes_list","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {
		 $qnotes_list=mmres(base64_decode($_GET["qnotes_list"]));
        
         $gft_notes_list_where_query="(`noteskey` LIKE '%".$qnotes_list."%' OR  `note_title` LIKE '%".$qnotes_list."%' OR  `note_details` LIKE '%".$qnotes_list."%' OR  `note_date` LIKE '%".$qnotes_list."%' OR  `note_tag` LIKE '%".$qnotes_list."%' OR  `user_id` LIKE '%".$qnotes_list."%' OR  `note_remark` LIKE '%".$qnotes_list."%' OR  `note_media` LIKE '%".$qnotes_list."%')";
         
         $gft_notes_list="WHERE ".$gft_notes_list_where_query;
         
         $gft_notes_list_and=$gft_notes_list_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_notes_list_);

        }
        }elseif(isset($_GET["notes_list_mosyfilter"])){
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "notes_list_mosyfilter","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {
         $gft_notes_list_where_query="";
         $gft_notes_list="";

         if($_GET["notes_list_mosyfilter"]!=""){
          $gft_notes_list_where_query=(base64_decode($_GET["notes_list_mosyfilter"]));
          $gft_notes_list="WHERE ".$gft_notes_list_where_query;
         }
         
         
         $gft_notes_list_and=$gft_notes_list_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_notes_list_);

        }
        }else{
         $gft_notes_list="";
         $gft_notes_list_and="";
         $gft_notes_list_where_query="";
        }
       
    //************************************************* END  notes_list OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section online_reception
  //************************************************* START  online_reception OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize online_reception edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['online_reception_table_alert']))
              	{	
                  if(isset($online_reception_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$online_reception_uptoken="";

		if(isset($_GET["online_reception_uptoken"]))
		{
		$online_reception_uptoken=base64_decode($_GET["online_reception_uptoken"]);
		}
        
        if(isset($_POST["online_reception_uptoken"]))
		{
		$online_reception_uptoken=base64_decode($_POST["online_reception_uptoken"]);
		}
        //
        
          $online_reception_alias_name="ONLINE RECEPTION";

          if(isset($online_reception_alias))
          {
             $online_reception_alias_name=$online_reception_alias;

          }
          
        //get single data record query with $online_reception_uptoken
        
        ///$online_reception_node=get_online_reception("*", "WHERE primkey='$online_reception_uptoken'", "r");
        
	
//************* START INSERT  online_reception QUERY 
if(isset($_POST["online_reception_insert_btn"])){
//------- begin online_reception_arr_ins --> 
$online_reception_arr_ins_=array(

"primkey"=>"NULL",
"reckey"=>magic_random_str(7),
"page_logo"=>"?",
"bg_image"=>"?",
"page_name"=>"?",
"btn_clr"=>"?",
"btn_txt_clr"=>"?",
"wild_clr"=>"?",
"action_link"=>"?",
"owner_id"=>"?",
"page_descr"=>"?",
"background_clr"=>"?",
"background_text_clr"=>"?",
"send_msg_title"=>"?",
"send_btn_title"=>"?",
"border_radius"=>"?",
"navbar_clr"=>"?",
"navbar_txt_clr"=>"?",
"telephone_"=>"?"

);
//===-- End online_reception_arr_ins -->


          
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "insert","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {

              $online_reception_validated_ins_str=$online_reception_arr_ins_;

              if(isset($online_reception_ins_inputs))
              {
                $online_reception_validated_ins_str=$online_reception_ins_inputs;	
              }

              if(empty($online_reception_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$online_reception_alias_name." request cannot be empty. Record not added");
              }else{

                $online_reception_return_key=add_online_reception($online_reception_validated_ins_str);
                
                mosy_sql_rollback("online_reception", "primkey='$online_reception_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_online_reception_page_logo']['tmp_name']))
                {
                
                 upload_online_reception_page_logo('txt_online_reception_page_logo', "primkey='$online_reception_return_key'");
                 
				}
                
         
         
                if(!empty($_FILES['txt_online_reception_bg_image']['tmp_name']))
                {
                
                 upload_online_reception_bg_image('txt_online_reception_bg_image', "primkey='$online_reception_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $online_reception_return_key; 

                      } 

                    }else{ 

                                    
                $online_reception_custom_redir1=add_url_param ("online_reception_uptoken", base64_encode($online_reception_return_key), "");
                $online_reception_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$online_reception_custom_redir1);
                $online_reception_custom_redir3=add_url_param ("online_reception_table_alert", "online_reception_added",$online_reception_custom_redir2);
                
                ///echo magic_message($online_reception_custom_redir1." -- ".$online_reception_custom_redir2."--".$online_reception_custom_redir3);
                
                $online_reception_custom_redir=$online_reception_custom_redir3;
                
               header('location:'.$online_reception_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_online_reception_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");
         
         }
      
}
//************* END  online_reception INSERT QUERY 	
	

//************* START online_reception  UPDATE QUERY 
if(isset($_POST["online_reception_update_btn"])){
//------- begin online_reception_arr_updt --> 
$online_reception_arr_updt_=array(
"page_logo"=>"?",
"bg_image"=>"?",
"page_name"=>"?",
"btn_clr"=>"?",
"btn_txt_clr"=>"?",
"wild_clr"=>"?",
"action_link"=>"?",
"owner_id"=>"?",
"page_descr"=>"?",
"background_clr"=>"?",
"background_text_clr"=>"?",
"send_msg_title"=>"?",
"send_btn_title"=>"?",
"border_radius"=>"?",
"navbar_clr"=>"?",
"navbar_txt_clr"=>"?",
"telephone_"=>"?"

);
//===-- End online_reception_arr_updt -->
                     
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "update","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
         
            $online_reception_validated_updt_str=$online_reception_arr_updt_;

            if(isset($online_reception_updt_inputs))
            {
              $online_reception_validated_updt_str=$online_reception_updt_inputs;	
            }

            if(empty($online_reception_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$online_reception_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$online_reception_key_salt=initialize_online_reception()["reckey"];
            
              update_online_reception($online_reception_validated_updt_str, "primkey='$online_reception_uptoken' and reckey='$online_reception_key_salt'");
				
         
                if(!empty($_FILES['txt_online_reception_page_logo']['tmp_name']))
                {
                
                 upload_online_reception_page_logo('txt_online_reception_page_logo', "primkey='$online_reception_uptoken'");
                 
				}
         
                if(!empty($_FILES['txt_online_reception_bg_image']['tmp_name']))
                {
                
                 upload_online_reception_bg_image('txt_online_reception_bg_image', "primkey='$online_reception_uptoken'");
                 
				}

			 mosy_sql_rollback("online_reception", "primkey='$online_reception_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $online_reception_uptoken; 

                    } 

                  }else{ 

                $online_reception_custom_redir1=add_url_param ("online_reception_uptoken", base64_encode($online_reception_uptoken), "");
                $online_reception_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$online_reception_custom_redir1);
                $online_reception_custom_redir3=add_url_param ("online_reception_table_alert", "online_reception_updated",$online_reception_custom_redir2);
                
                ///echo magic_message($online_reception_custom_redir1." -- ".$online_reception_custom_redir2."--".$online_reception_custom_redir3);
                
                $online_reception_custom_redir=$online_reception_custom_redir3;
                
               header('location:'.$online_reception_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_online_reception_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");
         
         }

      

      
}
//************* END online_reception  UPDATE QUERY 

    

          //===-====Start upload online_reception_page_logo 
          if(isset($_POST["btn_upload_online_reception_page_logo"]))
          {
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "upload_online_reception_page_logo","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_online_reception_page_logo']['tmp_name'])){

				upload_online_reception_page_logo('txt_online_reception_page_logo', "primkey='$online_reception_uptoken'");
                
                $online_reception_custom_redir1=add_url_param ("online_reception_uptoken", base64_encode($online_reception_uptoken), "");
                $online_reception_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$online_reception_custom_redir1);
                $online_reception_custom_redir3=add_url_param ("online_reception_table_alert", "online_reception_uploaded",$online_reception_custom_redir2);
                
                ///echo magic_message($online_reception_custom_redir1." -- ".$online_reception_custom_redir2."--".$online_reception_custom_redir3);
                
                $online_reception_custom_redir=$online_reception_custom_redir3;
                
               header('location:'.$online_reception_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_online_reception_);

          }
          }
          //===-====End upload online_reception_page_logo  

			//drop online_reception_page_logo image 
            
          if(isset($_GET["conf_deleteonline_reception"]))
          {
          	$online_reception_node=initialize_online_reception();
          	if($online_reception_node["page_logo"]!="")
            {
          	 unlink($online_reception_node["page_logo"]);
            }
          }
          
          

          //===-====Start upload online_reception_bg_image 
          if(isset($_POST["btn_upload_online_reception_bg_image"]))
          {
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "upload_online_reception_bg_image","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_online_reception_bg_image']['tmp_name'])){

				upload_online_reception_bg_image('txt_online_reception_bg_image', "primkey='$online_reception_uptoken'");
                
                $online_reception_custom_redir1=add_url_param ("online_reception_uptoken", base64_encode($online_reception_uptoken), "");
                $online_reception_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$online_reception_custom_redir1);
                $online_reception_custom_redir3=add_url_param ("online_reception_table_alert", "online_reception_uploaded",$online_reception_custom_redir2);
                
                ///echo magic_message($online_reception_custom_redir1." -- ".$online_reception_custom_redir2."--".$online_reception_custom_redir3);
                
                $online_reception_custom_redir=$online_reception_custom_redir3;
                
               header('location:'.$online_reception_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_online_reception_);

          }
          }
          //===-====End upload online_reception_bg_image  

			//drop online_reception_bg_image image 
            
          if(isset($_GET["conf_deleteonline_reception"]))
          {
          	$online_reception_node=initialize_online_reception();
          	if($online_reception_node["bg_image"]!="")
            {
          	 unlink($online_reception_node["bg_image"]);
            }
          }
          
          
    
      //== Start online_reception delete record

      if(isset($_GET["deleteonline_reception"]))
      {
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "super_delete_request","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_online_reception_btn=magic_button_link("./".$current_file_url."?online_reception_uptoken=".$_GET["online_reception_uptoken"]."&conf_deleteonline_reception&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_online_reception_btn=magic_button_link("./".$current_file_url."?online_reception_uptoken=".$_GET["online_reception_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_online_reception_btn." ".$cancel_del_online_reception_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_online_reception_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteonline_reception"]))
      {
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "super_delete_confirm","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $online_reception_del_key_salt=initialize_online_reception()["reckey"];
      mosy_sql_rollback("online_reception", "primkey='$online_reception_uptoken'", "DELETE");
      drop_online_reception("primkey='$online_reception_uptoken' and reckey='$online_reception_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_online_reception_);

      }
      }

      //== End online_reception delete record  
    
       ///SELECT STRING FOR online_reception============================
              
       if(isset($_POST["qonline_reception_btn"])){
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "qonline_reception_btn","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
            $current_online_reception_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_online_reception_current_url=$current_online_reception_url_params.'?qonline_reception=';
            if (strpos($current_online_reception_url_params, '?') !== false) {

                $clean_online_reception_current_url=$current_online_reception_url_params.'&qonline_reception=';

            }
            if (strpos($current_online_reception_url_params, '?qonline_reception')) {

                $remove_online_reception_old_token = substr($current_online_reception_url_params, 0, strpos($current_online_reception_url_params, "?qonline_reception"));

                $clean_online_reception_current_url=$remove_online_reception_old_token.'?qonline_reception=';

            }
            if(strpos($current_online_reception_url_params, '&qonline_reception')) {

                $remove_online_reception_old_token = substr($current_online_reception_url_params, 0, strpos($current_online_reception_url_params, "&qonline_reception"));

                $clean_online_reception_current_url=$remove_online_reception_old_token.'&qonline_reception=';

            }
        $qonline_reception_str=base64_encode($_POST["txt_online_reception"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_online_reception_current_url.($qonline_reception_str);
            } 

          }else{ 
             header('location:'.$clean_online_reception_current_url.($qonline_reception_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_online_reception_);

        }
        }
        $qonline_reception="";
		if(isset($_GET["online_reception_mosyfilter"]) && isset($_GET["qonline_reception"])){
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "online_reception_mosyfilter_n_query","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
         $qonline_reception=mmres(base64_decode($_GET["qonline_reception"]));
         
         $gft_online_reception_where_query="(`reckey` LIKE '%".$qonline_reception."%' OR  `page_logo` LIKE '%".$qonline_reception."%' OR  `bg_image` LIKE '%".$qonline_reception."%' OR  `page_name` LIKE '%".$qonline_reception."%' OR  `btn_clr` LIKE '%".$qonline_reception."%' OR  `btn_txt_clr` LIKE '%".$qonline_reception."%' OR  `wild_clr` LIKE '%".$qonline_reception."%' OR  `action_link` LIKE '%".$qonline_reception."%' OR  `owner_id` LIKE '%".$qonline_reception."%' OR  `page_descr` LIKE '%".$qonline_reception."%' OR  `background_clr` LIKE '%".$qonline_reception."%' OR  `background_text_clr` LIKE '%".$qonline_reception."%' OR  `send_msg_title` LIKE '%".$qonline_reception."%' OR  `send_btn_title` LIKE '%".$qonline_reception."%' OR  `border_radius` LIKE '%".$qonline_reception."%' OR  `navbar_clr` LIKE '%".$qonline_reception."%' OR  `navbar_txt_clr` LIKE '%".$qonline_reception."%' OR  `telephone_` LIKE '%".$qonline_reception."%')";
         
         if($_GET["online_reception_mosyfilter"]!=""){
         
         $mosyfilter_online_reception_queries_str=(base64_decode($_GET["online_reception_mosyfilter"]));
        
         $gft_online_reception_where_query="(`reckey` LIKE '%".$qonline_reception."%' OR  `page_logo` LIKE '%".$qonline_reception."%' OR  `bg_image` LIKE '%".$qonline_reception."%' OR  `page_name` LIKE '%".$qonline_reception."%' OR  `btn_clr` LIKE '%".$qonline_reception."%' OR  `btn_txt_clr` LIKE '%".$qonline_reception."%' OR  `wild_clr` LIKE '%".$qonline_reception."%' OR  `action_link` LIKE '%".$qonline_reception."%' OR  `owner_id` LIKE '%".$qonline_reception."%' OR  `page_descr` LIKE '%".$qonline_reception."%' OR  `background_clr` LIKE '%".$qonline_reception."%' OR  `background_text_clr` LIKE '%".$qonline_reception."%' OR  `send_msg_title` LIKE '%".$qonline_reception."%' OR  `send_btn_title` LIKE '%".$qonline_reception."%' OR  `border_radius` LIKE '%".$qonline_reception."%' OR  `navbar_clr` LIKE '%".$qonline_reception."%' OR  `navbar_txt_clr` LIKE '%".$qonline_reception."%' OR  `telephone_` LIKE '%".$qonline_reception."%') AND ".$mosyfilter_online_reception_queries_str."";
         
         }
         
		 $gft_online_reception="WHERE ".$gft_online_reception_where_query;
         
         $gft_online_reception_and=$gft_online_reception_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_online_reception_);
        }
        }elseif(isset($_GET["qonline_reception"])){
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "get_qonline_reception","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
		 $qonline_reception=mmres(base64_decode($_GET["qonline_reception"]));
        
         $gft_online_reception_where_query="(`reckey` LIKE '%".$qonline_reception."%' OR  `page_logo` LIKE '%".$qonline_reception."%' OR  `bg_image` LIKE '%".$qonline_reception."%' OR  `page_name` LIKE '%".$qonline_reception."%' OR  `btn_clr` LIKE '%".$qonline_reception."%' OR  `btn_txt_clr` LIKE '%".$qonline_reception."%' OR  `wild_clr` LIKE '%".$qonline_reception."%' OR  `action_link` LIKE '%".$qonline_reception."%' OR  `owner_id` LIKE '%".$qonline_reception."%' OR  `page_descr` LIKE '%".$qonline_reception."%' OR  `background_clr` LIKE '%".$qonline_reception."%' OR  `background_text_clr` LIKE '%".$qonline_reception."%' OR  `send_msg_title` LIKE '%".$qonline_reception."%' OR  `send_btn_title` LIKE '%".$qonline_reception."%' OR  `border_radius` LIKE '%".$qonline_reception."%' OR  `navbar_clr` LIKE '%".$qonline_reception."%' OR  `navbar_txt_clr` LIKE '%".$qonline_reception."%' OR  `telephone_` LIKE '%".$qonline_reception."%')";
         
         $gft_online_reception="WHERE ".$gft_online_reception_where_query;
         
         $gft_online_reception_and=$gft_online_reception_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_online_reception_);

        }
        }elseif(isset($_GET["online_reception_mosyfilter"])){
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "online_reception_mosyfilter","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
         $gft_online_reception_where_query="";
         $gft_online_reception="";

         if($_GET["online_reception_mosyfilter"]!=""){
          $gft_online_reception_where_query=(base64_decode($_GET["online_reception_mosyfilter"]));
          $gft_online_reception="WHERE ".$gft_online_reception_where_query;
         }
         
         
         $gft_online_reception_and=$gft_online_reception_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_online_reception_);

        }
        }else{
         $gft_online_reception="";
         $gft_online_reception_and="";
         $gft_online_reception_where_query="";
        }
       
    //************************************************* END  online_reception OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section page_links
  //************************************************* START  page_links OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize page_links edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['page_links_table_alert']))
              	{	
                  if(isset($page_links_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$page_links_uptoken="";

		if(isset($_GET["page_links_uptoken"]))
		{
		$page_links_uptoken=base64_decode($_GET["page_links_uptoken"]);
		}
        
        if(isset($_POST["page_links_uptoken"]))
		{
		$page_links_uptoken=base64_decode($_POST["page_links_uptoken"]);
		}
        //
        
          $page_links_alias_name="PAGE LINKS";

          if(isset($page_links_alias))
          {
             $page_links_alias_name=$page_links_alias;

          }
          
        //get single data record query with $page_links_uptoken
        
        ///$page_links_node=get_page_links("*", "WHERE primkey='$page_links_uptoken'", "r");
        
	
//************* START INSERT  page_links QUERY 
if(isset($_POST["page_links_insert_btn"])){
//------- begin page_links_arr_ins --> 
$page_links_arr_ins_=array(

"primkey"=>"NULL",
"link_id"=>magic_random_str(7),
"link_name"=>"?",
"linkurl"=>"?",
"descr"=>"?",
"signature"=>"?",
"admin_id"=>"?"

);
//===-- End page_links_arr_ins -->


          
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "insert","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {

              $page_links_validated_ins_str=$page_links_arr_ins_;

              if(isset($page_links_ins_inputs))
              {
                $page_links_validated_ins_str=$page_links_ins_inputs;	
              }

              if(empty($page_links_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$page_links_alias_name." request cannot be empty. Record not added");
              }else{

                $page_links_return_key=add_page_links($page_links_validated_ins_str);
                
                mosy_sql_rollback("page_links", "primkey='$page_links_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $page_links_return_key; 

                      } 

                    }else{ 

                                    
                $page_links_custom_redir1=add_url_param ("page_links_uptoken", base64_encode($page_links_return_key), "");
                $page_links_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$page_links_custom_redir1);
                $page_links_custom_redir3=add_url_param ("page_links_table_alert", "page_links_added",$page_links_custom_redir2);
                
                ///echo magic_message($page_links_custom_redir1." -- ".$page_links_custom_redir2."--".$page_links_custom_redir3);
                
                $page_links_custom_redir=$page_links_custom_redir3;
                
               header('location:'.$page_links_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_page_links_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");
         
         }
      
}
//************* END  page_links INSERT QUERY 	
	

//************* START page_links  UPDATE QUERY 
if(isset($_POST["page_links_update_btn"])){
//------- begin page_links_arr_updt --> 
$page_links_arr_updt_=array(
"link_name"=>"?",
"linkurl"=>"?",
"descr"=>"?",
"signature"=>"?",
"admin_id"=>"?"

);
//===-- End page_links_arr_updt -->
                     
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "update","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {
         
            $page_links_validated_updt_str=$page_links_arr_updt_;

            if(isset($page_links_updt_inputs))
            {
              $page_links_validated_updt_str=$page_links_updt_inputs;	
            }

            if(empty($page_links_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$page_links_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$page_links_key_salt=initialize_page_links()["link_id"];
            
              update_page_links($page_links_validated_updt_str, "primkey='$page_links_uptoken' and link_id='$page_links_key_salt'");
				

			 mosy_sql_rollback("page_links", "primkey='$page_links_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $page_links_uptoken; 

                    } 

                  }else{ 

                $page_links_custom_redir1=add_url_param ("page_links_uptoken", base64_encode($page_links_uptoken), "");
                $page_links_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$page_links_custom_redir1);
                $page_links_custom_redir3=add_url_param ("page_links_table_alert", "page_links_updated",$page_links_custom_redir2);
                
                ///echo magic_message($page_links_custom_redir1." -- ".$page_links_custom_redir2."--".$page_links_custom_redir3);
                
                $page_links_custom_redir=$page_links_custom_redir3;
                
               header('location:'.$page_links_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_page_links_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");
         
         }

      

      
}
//************* END page_links  UPDATE QUERY 

    
    
      //== Start page_links delete record

      if(isset($_GET["deletepage_links"]))
      {
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "super_delete_request","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_page_links_btn=magic_button_link("./".$current_file_url."?page_links_uptoken=".$_GET["page_links_uptoken"]."&conf_deletepage_links&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_page_links_btn=magic_button_link("./".$current_file_url."?page_links_uptoken=".$_GET["page_links_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_page_links_btn." ".$cancel_del_page_links_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_page_links_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletepage_links"]))
      {
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "super_delete_confirm","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $page_links_del_key_salt=initialize_page_links()["link_id"];
      mosy_sql_rollback("page_links", "primkey='$page_links_uptoken'", "DELETE");
      drop_page_links("primkey='$page_links_uptoken' and link_id='$page_links_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_page_links_);

      }
      }

      //== End page_links delete record  
    
       ///SELECT STRING FOR page_links============================
              
       if(isset($_POST["qpage_links_btn"])){
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "qpage_links_btn","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {
            $current_page_links_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_page_links_current_url=$current_page_links_url_params.'?qpage_links=';
            if (strpos($current_page_links_url_params, '?') !== false) {

                $clean_page_links_current_url=$current_page_links_url_params.'&qpage_links=';

            }
            if (strpos($current_page_links_url_params, '?qpage_links')) {

                $remove_page_links_old_token = substr($current_page_links_url_params, 0, strpos($current_page_links_url_params, "?qpage_links"));

                $clean_page_links_current_url=$remove_page_links_old_token.'?qpage_links=';

            }
            if(strpos($current_page_links_url_params, '&qpage_links')) {

                $remove_page_links_old_token = substr($current_page_links_url_params, 0, strpos($current_page_links_url_params, "&qpage_links"));

                $clean_page_links_current_url=$remove_page_links_old_token.'&qpage_links=';

            }
        $qpage_links_str=base64_encode($_POST["txt_page_links"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_page_links_current_url.($qpage_links_str);
            } 

          }else{ 
             header('location:'.$clean_page_links_current_url.($qpage_links_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_page_links_);

        }
        }
        $qpage_links="";
		if(isset($_GET["page_links_mosyfilter"]) && isset($_GET["qpage_links"])){
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "page_links_mosyfilter_n_query","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {
         $qpage_links=mmres(base64_decode($_GET["qpage_links"]));
         
         $gft_page_links_where_query="(`link_id` LIKE '%".$qpage_links."%' OR  `link_name` LIKE '%".$qpage_links."%' OR  `linkurl` LIKE '%".$qpage_links."%' OR  `descr` LIKE '%".$qpage_links."%' OR  `signature` LIKE '%".$qpage_links."%' OR  `admin_id` LIKE '%".$qpage_links."%')";
         
         if($_GET["page_links_mosyfilter"]!=""){
         
         $mosyfilter_page_links_queries_str=(base64_decode($_GET["page_links_mosyfilter"]));
        
         $gft_page_links_where_query="(`link_id` LIKE '%".$qpage_links."%' OR  `link_name` LIKE '%".$qpage_links."%' OR  `linkurl` LIKE '%".$qpage_links."%' OR  `descr` LIKE '%".$qpage_links."%' OR  `signature` LIKE '%".$qpage_links."%' OR  `admin_id` LIKE '%".$qpage_links."%') AND ".$mosyfilter_page_links_queries_str."";
         
         }
         
		 $gft_page_links="WHERE ".$gft_page_links_where_query;
         
         $gft_page_links_and=$gft_page_links_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_page_links_);
        }
        }elseif(isset($_GET["qpage_links"])){
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "get_qpage_links","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {
		 $qpage_links=mmres(base64_decode($_GET["qpage_links"]));
        
         $gft_page_links_where_query="(`link_id` LIKE '%".$qpage_links."%' OR  `link_name` LIKE '%".$qpage_links."%' OR  `linkurl` LIKE '%".$qpage_links."%' OR  `descr` LIKE '%".$qpage_links."%' OR  `signature` LIKE '%".$qpage_links."%' OR  `admin_id` LIKE '%".$qpage_links."%')";
         
         $gft_page_links="WHERE ".$gft_page_links_where_query;
         
         $gft_page_links_and=$gft_page_links_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_page_links_);

        }
        }elseif(isset($_GET["page_links_mosyfilter"])){
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "page_links_mosyfilter","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {
         $gft_page_links_where_query="";
         $gft_page_links="";

         if($_GET["page_links_mosyfilter"]!=""){
          $gft_page_links_where_query=(base64_decode($_GET["page_links_mosyfilter"]));
          $gft_page_links="WHERE ".$gft_page_links_where_query;
         }
         
         
         $gft_page_links_and=$gft_page_links_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_page_links_);

        }
        }else{
         $gft_page_links="";
         $gft_page_links_and="";
         $gft_page_links_where_query="";
        }
       
    //************************************************* END  page_links OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section posting_log
  //************************************************* START  posting_log OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize posting_log edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['posting_log_table_alert']))
              	{	
                  if(isset($posting_log_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$posting_log_uptoken="";

		if(isset($_GET["posting_log_uptoken"]))
		{
		$posting_log_uptoken=base64_decode($_GET["posting_log_uptoken"]);
		}
        
        if(isset($_POST["posting_log_uptoken"]))
		{
		$posting_log_uptoken=base64_decode($_POST["posting_log_uptoken"]);
		}
        //
        
          $posting_log_alias_name="POSTING LOG";

          if(isset($posting_log_alias))
          {
             $posting_log_alias_name=$posting_log_alias;

          }
          
        //get single data record query with $posting_log_uptoken
        
        ///$posting_log_node=get_posting_log("*", "WHERE primkey='$posting_log_uptoken'", "r");
        
	
//************* START INSERT  posting_log QUERY 
if(isset($_POST["posting_log_insert_btn"])){
//------- begin posting_log_arr_ins --> 
$posting_log_arr_ins_=array(

"primkey"=>"NULL",
"postkey"=>magic_random_str(7),
"admin_id"=>"?",
"marketid"=>"?",
"post_id"=>"?",
"ref_id"=>"?",
"request_date"=>"?"

);
//===-- End posting_log_arr_ins -->


          
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "insert","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {

              $posting_log_validated_ins_str=$posting_log_arr_ins_;

              if(isset($posting_log_ins_inputs))
              {
                $posting_log_validated_ins_str=$posting_log_ins_inputs;	
              }

              if(empty($posting_log_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$posting_log_alias_name." request cannot be empty. Record not added");
              }else{

                $posting_log_return_key=add_posting_log($posting_log_validated_ins_str);
                
                mosy_sql_rollback("posting_log", "primkey='$posting_log_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $posting_log_return_key; 

                      } 

                    }else{ 

                                    
                $posting_log_custom_redir1=add_url_param ("posting_log_uptoken", base64_encode($posting_log_return_key), "");
                $posting_log_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$posting_log_custom_redir1);
                $posting_log_custom_redir3=add_url_param ("posting_log_table_alert", "posting_log_added",$posting_log_custom_redir2);
                
                ///echo magic_message($posting_log_custom_redir1." -- ".$posting_log_custom_redir2."--".$posting_log_custom_redir3);
                
                $posting_log_custom_redir=$posting_log_custom_redir3;
                
               header('location:'.$posting_log_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_posting_log_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");
         
         }
      
}
//************* END  posting_log INSERT QUERY 	
	

//************* START posting_log  UPDATE QUERY 
if(isset($_POST["posting_log_update_btn"])){
//------- begin posting_log_arr_updt --> 
$posting_log_arr_updt_=array(
"admin_id"=>"?",
"marketid"=>"?",
"post_id"=>"?",
"ref_id"=>"?",
"request_date"=>"?"

);
//===-- End posting_log_arr_updt -->
                     
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "update","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {
         
            $posting_log_validated_updt_str=$posting_log_arr_updt_;

            if(isset($posting_log_updt_inputs))
            {
              $posting_log_validated_updt_str=$posting_log_updt_inputs;	
            }

            if(empty($posting_log_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$posting_log_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$posting_log_key_salt=initialize_posting_log()["postkey"];
            
              update_posting_log($posting_log_validated_updt_str, "primkey='$posting_log_uptoken' and postkey='$posting_log_key_salt'");
				

			 mosy_sql_rollback("posting_log", "primkey='$posting_log_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $posting_log_uptoken; 

                    } 

                  }else{ 

                $posting_log_custom_redir1=add_url_param ("posting_log_uptoken", base64_encode($posting_log_uptoken), "");
                $posting_log_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$posting_log_custom_redir1);
                $posting_log_custom_redir3=add_url_param ("posting_log_table_alert", "posting_log_updated",$posting_log_custom_redir2);
                
                ///echo magic_message($posting_log_custom_redir1." -- ".$posting_log_custom_redir2."--".$posting_log_custom_redir3);
                
                $posting_log_custom_redir=$posting_log_custom_redir3;
                
               header('location:'.$posting_log_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_posting_log_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");
         
         }

      

      
}
//************* END posting_log  UPDATE QUERY 

    
    
      //== Start posting_log delete record

      if(isset($_GET["deleteposting_log"]))
      {
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "super_delete_request","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_posting_log_btn=magic_button_link("./".$current_file_url."?posting_log_uptoken=".$_GET["posting_log_uptoken"]."&conf_deleteposting_log&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_posting_log_btn=magic_button_link("./".$current_file_url."?posting_log_uptoken=".$_GET["posting_log_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_posting_log_btn." ".$cancel_del_posting_log_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_posting_log_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteposting_log"]))
      {
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "super_delete_confirm","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $posting_log_del_key_salt=initialize_posting_log()["postkey"];
      mosy_sql_rollback("posting_log", "primkey='$posting_log_uptoken'", "DELETE");
      drop_posting_log("primkey='$posting_log_uptoken' and postkey='$posting_log_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_posting_log_);

      }
      }

      //== End posting_log delete record  
    
       ///SELECT STRING FOR posting_log============================
              
       if(isset($_POST["qposting_log_btn"])){
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "qposting_log_btn","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {
            $current_posting_log_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_posting_log_current_url=$current_posting_log_url_params.'?qposting_log=';
            if (strpos($current_posting_log_url_params, '?') !== false) {

                $clean_posting_log_current_url=$current_posting_log_url_params.'&qposting_log=';

            }
            if (strpos($current_posting_log_url_params, '?qposting_log')) {

                $remove_posting_log_old_token = substr($current_posting_log_url_params, 0, strpos($current_posting_log_url_params, "?qposting_log"));

                $clean_posting_log_current_url=$remove_posting_log_old_token.'?qposting_log=';

            }
            if(strpos($current_posting_log_url_params, '&qposting_log')) {

                $remove_posting_log_old_token = substr($current_posting_log_url_params, 0, strpos($current_posting_log_url_params, "&qposting_log"));

                $clean_posting_log_current_url=$remove_posting_log_old_token.'&qposting_log=';

            }
        $qposting_log_str=base64_encode($_POST["txt_posting_log"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_posting_log_current_url.($qposting_log_str);
            } 

          }else{ 
             header('location:'.$clean_posting_log_current_url.($qposting_log_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_posting_log_);

        }
        }
        $qposting_log="";
		if(isset($_GET["posting_log_mosyfilter"]) && isset($_GET["qposting_log"])){
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "posting_log_mosyfilter_n_query","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {
         $qposting_log=mmres(base64_decode($_GET["qposting_log"]));
         
         $gft_posting_log_where_query="(`postkey` LIKE '%".$qposting_log."%' OR  `admin_id` LIKE '%".$qposting_log."%' OR  `marketid` LIKE '%".$qposting_log."%' OR  `post_id` LIKE '%".$qposting_log."%' OR  `ref_id` LIKE '%".$qposting_log."%' OR  `request_date` LIKE '%".$qposting_log."%')";
         
         if($_GET["posting_log_mosyfilter"]!=""){
         
         $mosyfilter_posting_log_queries_str=(base64_decode($_GET["posting_log_mosyfilter"]));
        
         $gft_posting_log_where_query="(`postkey` LIKE '%".$qposting_log."%' OR  `admin_id` LIKE '%".$qposting_log."%' OR  `marketid` LIKE '%".$qposting_log."%' OR  `post_id` LIKE '%".$qposting_log."%' OR  `ref_id` LIKE '%".$qposting_log."%' OR  `request_date` LIKE '%".$qposting_log."%') AND ".$mosyfilter_posting_log_queries_str."";
         
         }
         
		 $gft_posting_log="WHERE ".$gft_posting_log_where_query;
         
         $gft_posting_log_and=$gft_posting_log_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_posting_log_);
        }
        }elseif(isset($_GET["qposting_log"])){
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "get_qposting_log","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {
		 $qposting_log=mmres(base64_decode($_GET["qposting_log"]));
        
         $gft_posting_log_where_query="(`postkey` LIKE '%".$qposting_log."%' OR  `admin_id` LIKE '%".$qposting_log."%' OR  `marketid` LIKE '%".$qposting_log."%' OR  `post_id` LIKE '%".$qposting_log."%' OR  `ref_id` LIKE '%".$qposting_log."%' OR  `request_date` LIKE '%".$qposting_log."%')";
         
         $gft_posting_log="WHERE ".$gft_posting_log_where_query;
         
         $gft_posting_log_and=$gft_posting_log_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_posting_log_);

        }
        }elseif(isset($_GET["posting_log_mosyfilter"])){
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "posting_log_mosyfilter","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {
         $gft_posting_log_where_query="";
         $gft_posting_log="";

         if($_GET["posting_log_mosyfilter"]!=""){
          $gft_posting_log_where_query=(base64_decode($_GET["posting_log_mosyfilter"]));
          $gft_posting_log="WHERE ".$gft_posting_log_where_query;
         }
         
         
         $gft_posting_log_and=$gft_posting_log_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_posting_log_);

        }
        }else{
         $gft_posting_log="";
         $gft_posting_log_and="";
         $gft_posting_log_where_query="";
        }
       
    //************************************************* END  posting_log OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section posts
  //************************************************* START  posts OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize posts edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['posts_table_alert']))
              	{	
                  if(isset($posts_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$posts_uptoken="";

		if(isset($_GET["posts_uptoken"]))
		{
		$posts_uptoken=base64_decode($_GET["posts_uptoken"]);
		}
        
        if(isset($_POST["posts_uptoken"]))
		{
		$posts_uptoken=base64_decode($_POST["posts_uptoken"]);
		}
        //
        
          $posts_alias_name="POSTS";

          if(isset($posts_alias))
          {
             $posts_alias_name=$posts_alias;

          }
          
        //get single data record query with $posts_uptoken
        
        ///$posts_node=get_posts("*", "WHERE primkey='$posts_uptoken'", "r");
        
	
//************* START INSERT  posts QUERY 
if(isset($_POST["posts_insert_btn"])){
//------- begin posts_arr_ins --> 
$posts_arr_ins_=array(

"primkey"=>"NULL",
"msgid"=>magic_random_str(7),
"msg_titile"=>"?",
"msgposted"=>"?",
"run_at"=>"?",
"page"=>"?",
"link"=>"?",
"details"=>"?",
"post_response"=>"?",
"signature"=>"?",
"tweeted"=>"?",
"admin_id"=>"?",
"post_image"=>"?",
"sharable_link"=>"?"

);
//===-- End posts_arr_ins -->


          
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "insert","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {

              $posts_validated_ins_str=$posts_arr_ins_;

              if(isset($posts_ins_inputs))
              {
                $posts_validated_ins_str=$posts_ins_inputs;	
              }

              if(empty($posts_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$posts_alias_name." request cannot be empty. Record not added");
              }else{

                $posts_return_key=add_posts($posts_validated_ins_str);
                
                mosy_sql_rollback("posts", "primkey='$posts_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_posts_post_image']['tmp_name']))
                {
                
                 upload_posts_post_image('txt_posts_post_image', "primkey='$posts_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $posts_return_key; 

                      } 

                    }else{ 

                                    
                $posts_custom_redir1=add_url_param ("posts_uptoken", base64_encode($posts_return_key), "");
                $posts_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$posts_custom_redir1);
                $posts_custom_redir3=add_url_param ("posts_table_alert", "posts_added",$posts_custom_redir2);
                
                ///echo magic_message($posts_custom_redir1." -- ".$posts_custom_redir2."--".$posts_custom_redir3);
                
                $posts_custom_redir=$posts_custom_redir3;
                
               header('location:'.$posts_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_posts_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");
         
         }
      
}
//************* END  posts INSERT QUERY 	
	

//************* START posts  UPDATE QUERY 
if(isset($_POST["posts_update_btn"])){
//------- begin posts_arr_updt --> 
$posts_arr_updt_=array(
"msg_titile"=>"?",
"msgposted"=>"?",
"run_at"=>"?",
"page"=>"?",
"link"=>"?",
"details"=>"?",
"post_response"=>"?",
"signature"=>"?",
"tweeted"=>"?",
"admin_id"=>"?",
"post_image"=>"?",
"sharable_link"=>"?"

);
//===-- End posts_arr_updt -->
                     
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "update","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
         
            $posts_validated_updt_str=$posts_arr_updt_;

            if(isset($posts_updt_inputs))
            {
              $posts_validated_updt_str=$posts_updt_inputs;	
            }

            if(empty($posts_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$posts_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$posts_key_salt=initialize_posts()["msgid"];
            
              update_posts($posts_validated_updt_str, "primkey='$posts_uptoken' and msgid='$posts_key_salt'");
				
         
                if(!empty($_FILES['txt_posts_post_image']['tmp_name']))
                {
                
                 upload_posts_post_image('txt_posts_post_image', "primkey='$posts_uptoken'");
                 
				}

			 mosy_sql_rollback("posts", "primkey='$posts_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $posts_uptoken; 

                    } 

                  }else{ 

                $posts_custom_redir1=add_url_param ("posts_uptoken", base64_encode($posts_uptoken), "");
                $posts_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$posts_custom_redir1);
                $posts_custom_redir3=add_url_param ("posts_table_alert", "posts_updated",$posts_custom_redir2);
                
                ///echo magic_message($posts_custom_redir1." -- ".$posts_custom_redir2."--".$posts_custom_redir3);
                
                $posts_custom_redir=$posts_custom_redir3;
                
               header('location:'.$posts_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_posts_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");
         
         }

      

      
}
//************* END posts  UPDATE QUERY 

    

          //===-====Start upload posts_post_image 
          if(isset($_POST["btn_upload_posts_post_image"]))
          {
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "upload_posts_post_image","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_posts_post_image']['tmp_name'])){

				upload_posts_post_image('txt_posts_post_image', "primkey='$posts_uptoken'");
                
                $posts_custom_redir1=add_url_param ("posts_uptoken", base64_encode($posts_uptoken), "");
                $posts_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$posts_custom_redir1);
                $posts_custom_redir3=add_url_param ("posts_table_alert", "posts_uploaded",$posts_custom_redir2);
                
                ///echo magic_message($posts_custom_redir1." -- ".$posts_custom_redir2."--".$posts_custom_redir3);
                
                $posts_custom_redir=$posts_custom_redir3;
                
               header('location:'.$posts_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_posts_);

          }
          }
          //===-====End upload posts_post_image  

			//drop posts_post_image image 
            
          if(isset($_GET["conf_deleteposts"]))
          {
          	$posts_node=initialize_posts();
          	if($posts_node["post_image"]!="")
            {
          	 unlink($posts_node["post_image"]);
            }
          }
          
          
    
      //== Start posts delete record

      if(isset($_GET["deleteposts"]))
      {
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "super_delete_request","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_posts_btn=magic_button_link("./".$current_file_url."?posts_uptoken=".$_GET["posts_uptoken"]."&conf_deleteposts&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_posts_btn=magic_button_link("./".$current_file_url."?posts_uptoken=".$_GET["posts_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_posts_btn." ".$cancel_del_posts_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_posts_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteposts"]))
      {
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "super_delete_confirm","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $posts_del_key_salt=initialize_posts()["msgid"];
      mosy_sql_rollback("posts", "primkey='$posts_uptoken'", "DELETE");
      drop_posts("primkey='$posts_uptoken' and msgid='$posts_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_posts_);

      }
      }

      //== End posts delete record  
    
       ///SELECT STRING FOR posts============================
              
       if(isset($_POST["qposts_btn"])){
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "qposts_btn","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
            $current_posts_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_posts_current_url=$current_posts_url_params.'?qposts=';
            if (strpos($current_posts_url_params, '?') !== false) {

                $clean_posts_current_url=$current_posts_url_params.'&qposts=';

            }
            if (strpos($current_posts_url_params, '?qposts')) {

                $remove_posts_old_token = substr($current_posts_url_params, 0, strpos($current_posts_url_params, "?qposts"));

                $clean_posts_current_url=$remove_posts_old_token.'?qposts=';

            }
            if(strpos($current_posts_url_params, '&qposts')) {

                $remove_posts_old_token = substr($current_posts_url_params, 0, strpos($current_posts_url_params, "&qposts"));

                $clean_posts_current_url=$remove_posts_old_token.'&qposts=';

            }
        $qposts_str=base64_encode($_POST["txt_posts"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_posts_current_url.($qposts_str);
            } 

          }else{ 
             header('location:'.$clean_posts_current_url.($qposts_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_posts_);

        }
        }
        $qposts="";
		if(isset($_GET["posts_mosyfilter"]) && isset($_GET["qposts"])){
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "posts_mosyfilter_n_query","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
         $qposts=mmres(base64_decode($_GET["qposts"]));
         
         $gft_posts_where_query="(`msgid` LIKE '%".$qposts."%' OR  `msg_titile` LIKE '%".$qposts."%' OR  `msgposted` LIKE '%".$qposts."%' OR  `run_at` LIKE '%".$qposts."%' OR  `page` LIKE '%".$qposts."%' OR  `link` LIKE '%".$qposts."%' OR  `details` LIKE '%".$qposts."%' OR  `post_response` LIKE '%".$qposts."%' OR  `signature` LIKE '%".$qposts."%' OR  `tweeted` LIKE '%".$qposts."%' OR  `admin_id` LIKE '%".$qposts."%' OR  `post_image` LIKE '%".$qposts."%' OR  `sharable_link` LIKE '%".$qposts."%')";
         
         if($_GET["posts_mosyfilter"]!=""){
         
         $mosyfilter_posts_queries_str=(base64_decode($_GET["posts_mosyfilter"]));
        
         $gft_posts_where_query="(`msgid` LIKE '%".$qposts."%' OR  `msg_titile` LIKE '%".$qposts."%' OR  `msgposted` LIKE '%".$qposts."%' OR  `run_at` LIKE '%".$qposts."%' OR  `page` LIKE '%".$qposts."%' OR  `link` LIKE '%".$qposts."%' OR  `details` LIKE '%".$qposts."%' OR  `post_response` LIKE '%".$qposts."%' OR  `signature` LIKE '%".$qposts."%' OR  `tweeted` LIKE '%".$qposts."%' OR  `admin_id` LIKE '%".$qposts."%' OR  `post_image` LIKE '%".$qposts."%' OR  `sharable_link` LIKE '%".$qposts."%') AND ".$mosyfilter_posts_queries_str."";
         
         }
         
		 $gft_posts="WHERE ".$gft_posts_where_query;
         
         $gft_posts_and=$gft_posts_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_posts_);
        }
        }elseif(isset($_GET["qposts"])){
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "get_qposts","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
		 $qposts=mmres(base64_decode($_GET["qposts"]));
        
         $gft_posts_where_query="(`msgid` LIKE '%".$qposts."%' OR  `msg_titile` LIKE '%".$qposts."%' OR  `msgposted` LIKE '%".$qposts."%' OR  `run_at` LIKE '%".$qposts."%' OR  `page` LIKE '%".$qposts."%' OR  `link` LIKE '%".$qposts."%' OR  `details` LIKE '%".$qposts."%' OR  `post_response` LIKE '%".$qposts."%' OR  `signature` LIKE '%".$qposts."%' OR  `tweeted` LIKE '%".$qposts."%' OR  `admin_id` LIKE '%".$qposts."%' OR  `post_image` LIKE '%".$qposts."%' OR  `sharable_link` LIKE '%".$qposts."%')";
         
         $gft_posts="WHERE ".$gft_posts_where_query;
         
         $gft_posts_and=$gft_posts_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_posts_);

        }
        }elseif(isset($_GET["posts_mosyfilter"])){
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "posts_mosyfilter","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
         $gft_posts_where_query="";
         $gft_posts="";

         if($_GET["posts_mosyfilter"]!=""){
          $gft_posts_where_query=(base64_decode($_GET["posts_mosyfilter"]));
          $gft_posts="WHERE ".$gft_posts_where_query;
         }
         
         
         $gft_posts_and=$gft_posts_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_posts_);

        }
        }else{
         $gft_posts="";
         $gft_posts_and="";
         $gft_posts_where_query="";
        }
       
    //************************************************* END  posts OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section task_manager
  //************************************************* START  task_manager OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize task_manager edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['task_manager_table_alert']))
              	{	
                  if(isset($task_manager_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$task_manager_uptoken="";

		if(isset($_GET["task_manager_uptoken"]))
		{
		$task_manager_uptoken=base64_decode($_GET["task_manager_uptoken"]);
		}
        
        if(isset($_POST["task_manager_uptoken"]))
		{
		$task_manager_uptoken=base64_decode($_POST["task_manager_uptoken"]);
		}
        //
        
          $task_manager_alias_name="TASK MANAGER";

          if(isset($task_manager_alias))
          {
             $task_manager_alias_name=$task_manager_alias;

          }
          
        //get single data record query with $task_manager_uptoken
        
        ///$task_manager_node=get_task_manager("*", "WHERE primkey='$task_manager_uptoken'", "r");
        
	
//************* START INSERT  task_manager QUERY 
if(isset($_POST["task_manager_insert_btn"])){
//------- begin task_manager_arr_ins --> 
$task_manager_arr_ins_=array(

"primkey"=>"NULL",
"task_id"=>magic_random_str(7),
"project_id"=>"?",
"task_name"=>"?",
"task_status"=>"?",
"task_date"=>"?",
"task_remark"=>"?",
"test_column"=>"?",
"assigned_to"=>"?",
"task_comments"=>"?",
"admin_remark"=>"?"

);
//===-- End task_manager_arr_ins -->


          
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "insert","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {

              $task_manager_validated_ins_str=$task_manager_arr_ins_;

              if(isset($task_manager_ins_inputs))
              {
                $task_manager_validated_ins_str=$task_manager_ins_inputs;	
              }

              if(empty($task_manager_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$task_manager_alias_name." request cannot be empty. Record not added");
              }else{

                $task_manager_return_key=add_task_manager($task_manager_validated_ins_str);
                
                mosy_sql_rollback("task_manager", "primkey='$task_manager_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $task_manager_return_key; 

                      } 

                    }else{ 

                                    
                $task_manager_custom_redir1=add_url_param ("task_manager_uptoken", base64_encode($task_manager_return_key), "");
                $task_manager_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$task_manager_custom_redir1);
                $task_manager_custom_redir3=add_url_param ("task_manager_table_alert", "task_manager_added",$task_manager_custom_redir2);
                
                ///echo magic_message($task_manager_custom_redir1." -- ".$task_manager_custom_redir2."--".$task_manager_custom_redir3);
                
                $task_manager_custom_redir=$task_manager_custom_redir3;
                
               header('location:'.$task_manager_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_task_manager_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");
         
         }
      
}
//************* END  task_manager INSERT QUERY 	
	

//************* START task_manager  UPDATE QUERY 
if(isset($_POST["task_manager_update_btn"])){
//------- begin task_manager_arr_updt --> 
$task_manager_arr_updt_=array(
"project_id"=>"?",
"task_name"=>"?",
"task_status"=>"?",
"task_date"=>"?",
"task_remark"=>"?",
"test_column"=>"?",
"assigned_to"=>"?",
"task_comments"=>"?",
"admin_remark"=>"?"

);
//===-- End task_manager_arr_updt -->
                     
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "update","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {
         
            $task_manager_validated_updt_str=$task_manager_arr_updt_;

            if(isset($task_manager_updt_inputs))
            {
              $task_manager_validated_updt_str=$task_manager_updt_inputs;	
            }

            if(empty($task_manager_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$task_manager_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$task_manager_key_salt=initialize_task_manager()["task_id"];
            
              update_task_manager($task_manager_validated_updt_str, "primkey='$task_manager_uptoken' and task_id='$task_manager_key_salt'");
				

			 mosy_sql_rollback("task_manager", "primkey='$task_manager_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $task_manager_uptoken; 

                    } 

                  }else{ 

                $task_manager_custom_redir1=add_url_param ("task_manager_uptoken", base64_encode($task_manager_uptoken), "");
                $task_manager_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$task_manager_custom_redir1);
                $task_manager_custom_redir3=add_url_param ("task_manager_table_alert", "task_manager_updated",$task_manager_custom_redir2);
                
                ///echo magic_message($task_manager_custom_redir1." -- ".$task_manager_custom_redir2."--".$task_manager_custom_redir3);
                
                $task_manager_custom_redir=$task_manager_custom_redir3;
                
               header('location:'.$task_manager_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_task_manager_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");
         
         }

      

      
}
//************* END task_manager  UPDATE QUERY 

    
    
      //== Start task_manager delete record

      if(isset($_GET["deletetask_manager"]))
      {
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "super_delete_request","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_task_manager_btn=magic_button_link("./".$current_file_url."?task_manager_uptoken=".$_GET["task_manager_uptoken"]."&conf_deletetask_manager&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_task_manager_btn=magic_button_link("./".$current_file_url."?task_manager_uptoken=".$_GET["task_manager_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_task_manager_btn." ".$cancel_del_task_manager_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_task_manager_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletetask_manager"]))
      {
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "super_delete_confirm","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $task_manager_del_key_salt=initialize_task_manager()["task_id"];
      mosy_sql_rollback("task_manager", "primkey='$task_manager_uptoken'", "DELETE");
      drop_task_manager("primkey='$task_manager_uptoken' and task_id='$task_manager_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_task_manager_);

      }
      }

      //== End task_manager delete record  
    
       ///SELECT STRING FOR task_manager============================
              
       if(isset($_POST["qtask_manager_btn"])){
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "qtask_manager_btn","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {
            $current_task_manager_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_task_manager_current_url=$current_task_manager_url_params.'?qtask_manager=';
            if (strpos($current_task_manager_url_params, '?') !== false) {

                $clean_task_manager_current_url=$current_task_manager_url_params.'&qtask_manager=';

            }
            if (strpos($current_task_manager_url_params, '?qtask_manager')) {

                $remove_task_manager_old_token = substr($current_task_manager_url_params, 0, strpos($current_task_manager_url_params, "?qtask_manager"));

                $clean_task_manager_current_url=$remove_task_manager_old_token.'?qtask_manager=';

            }
            if(strpos($current_task_manager_url_params, '&qtask_manager')) {

                $remove_task_manager_old_token = substr($current_task_manager_url_params, 0, strpos($current_task_manager_url_params, "&qtask_manager"));

                $clean_task_manager_current_url=$remove_task_manager_old_token.'&qtask_manager=';

            }
        $qtask_manager_str=base64_encode($_POST["txt_task_manager"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_task_manager_current_url.($qtask_manager_str);
            } 

          }else{ 
             header('location:'.$clean_task_manager_current_url.($qtask_manager_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_task_manager_);

        }
        }
        $qtask_manager="";
		if(isset($_GET["task_manager_mosyfilter"]) && isset($_GET["qtask_manager"])){
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "task_manager_mosyfilter_n_query","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {
         $qtask_manager=mmres(base64_decode($_GET["qtask_manager"]));
         
         $gft_task_manager_where_query="(`task_id` LIKE '%".$qtask_manager."%' OR  `project_id` LIKE '%".$qtask_manager."%' OR  `task_name` LIKE '%".$qtask_manager."%' OR  `task_status` LIKE '%".$qtask_manager."%' OR  `task_date` LIKE '%".$qtask_manager."%' OR  `task_remark` LIKE '%".$qtask_manager."%' OR  `test_column` LIKE '%".$qtask_manager."%' OR  `assigned_to` LIKE '%".$qtask_manager."%' OR  `task_comments` LIKE '%".$qtask_manager."%' OR  `admin_remark` LIKE '%".$qtask_manager."%')";
         
         if($_GET["task_manager_mosyfilter"]!=""){
         
         $mosyfilter_task_manager_queries_str=(base64_decode($_GET["task_manager_mosyfilter"]));
        
         $gft_task_manager_where_query="(`task_id` LIKE '%".$qtask_manager."%' OR  `project_id` LIKE '%".$qtask_manager."%' OR  `task_name` LIKE '%".$qtask_manager."%' OR  `task_status` LIKE '%".$qtask_manager."%' OR  `task_date` LIKE '%".$qtask_manager."%' OR  `task_remark` LIKE '%".$qtask_manager."%' OR  `test_column` LIKE '%".$qtask_manager."%' OR  `assigned_to` LIKE '%".$qtask_manager."%' OR  `task_comments` LIKE '%".$qtask_manager."%' OR  `admin_remark` LIKE '%".$qtask_manager."%') AND ".$mosyfilter_task_manager_queries_str."";
         
         }
         
		 $gft_task_manager="WHERE ".$gft_task_manager_where_query;
         
         $gft_task_manager_and=$gft_task_manager_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_task_manager_);
        }
        }elseif(isset($_GET["qtask_manager"])){
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "get_qtask_manager","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {
		 $qtask_manager=mmres(base64_decode($_GET["qtask_manager"]));
        
         $gft_task_manager_where_query="(`task_id` LIKE '%".$qtask_manager."%' OR  `project_id` LIKE '%".$qtask_manager."%' OR  `task_name` LIKE '%".$qtask_manager."%' OR  `task_status` LIKE '%".$qtask_manager."%' OR  `task_date` LIKE '%".$qtask_manager."%' OR  `task_remark` LIKE '%".$qtask_manager."%' OR  `test_column` LIKE '%".$qtask_manager."%' OR  `assigned_to` LIKE '%".$qtask_manager."%' OR  `task_comments` LIKE '%".$qtask_manager."%' OR  `admin_remark` LIKE '%".$qtask_manager."%')";
         
         $gft_task_manager="WHERE ".$gft_task_manager_where_query;
         
         $gft_task_manager_and=$gft_task_manager_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_task_manager_);

        }
        }elseif(isset($_GET["task_manager_mosyfilter"])){
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "task_manager_mosyfilter","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {
         $gft_task_manager_where_query="";
         $gft_task_manager="";

         if($_GET["task_manager_mosyfilter"]!=""){
          $gft_task_manager_where_query=(base64_decode($_GET["task_manager_mosyfilter"]));
          $gft_task_manager="WHERE ".$gft_task_manager_where_query;
         }
         
         
         $gft_task_manager_and=$gft_task_manager_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_task_manager_);

        }
        }else{
         $gft_task_manager="";
         $gft_task_manager_and="";
         $gft_task_manager_where_query="";
        }
       
    //************************************************* END  task_manager OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section traffic_log
  //************************************************* START  traffic_log OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize traffic_log edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['traffic_log_table_alert']))
              	{	
                  if(isset($traffic_log_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$traffic_log_uptoken="";

		if(isset($_GET["traffic_log_uptoken"]))
		{
		$traffic_log_uptoken=base64_decode($_GET["traffic_log_uptoken"]);
		}
        
        if(isset($_POST["traffic_log_uptoken"]))
		{
		$traffic_log_uptoken=base64_decode($_POST["traffic_log_uptoken"]);
		}
        //
        
          $traffic_log_alias_name="TRAFFIC LOG";

          if(isset($traffic_log_alias))
          {
             $traffic_log_alias_name=$traffic_log_alias;

          }
          
        //get single data record query with $traffic_log_uptoken
        
        ///$traffic_log_node=get_traffic_log("*", "WHERE primkey='$traffic_log_uptoken'", "r");
        
	
//************* START INSERT  traffic_log QUERY 
if(isset($_POST["traffic_log_insert_btn"])){
//------- begin traffic_log_arr_ins --> 
$traffic_log_arr_ins_=array(

"primkey"=>"NULL",
"schedule_id"=>magic_random_str(7),
"campaign_id"=>"?",
"channel_node"=>"?",
"visit_time"=>"?",
"visit_date"=>"?",
"visitor_name"=>"?",
"page_visited"=>"?",
"page_url"=>"?",
"admin_id"=>"?",
"source_url"=>"?",
"month_year"=>"?",
"ip_address"=>"?",
"comment"=>"?",
"source_page"=>"?",
"time_stamp"=>"?",
"user_id"=>"?",
"log_data"=>"?",
"device"=>"?",
"browser"=>"?"

);
//===-- End traffic_log_arr_ins -->


          
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "insert","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {

              $traffic_log_validated_ins_str=$traffic_log_arr_ins_;

              if(isset($traffic_log_ins_inputs))
              {
                $traffic_log_validated_ins_str=$traffic_log_ins_inputs;	
              }

              if(empty($traffic_log_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$traffic_log_alias_name." request cannot be empty. Record not added");
              }else{

                $traffic_log_return_key=add_traffic_log($traffic_log_validated_ins_str);
                
                mosy_sql_rollback("traffic_log", "primkey='$traffic_log_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $traffic_log_return_key; 

                      } 

                    }else{ 

                                    
                $traffic_log_custom_redir1=add_url_param ("traffic_log_uptoken", base64_encode($traffic_log_return_key), "");
                $traffic_log_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$traffic_log_custom_redir1);
                $traffic_log_custom_redir3=add_url_param ("traffic_log_table_alert", "traffic_log_added",$traffic_log_custom_redir2);
                
                ///echo magic_message($traffic_log_custom_redir1." -- ".$traffic_log_custom_redir2."--".$traffic_log_custom_redir3);
                
                $traffic_log_custom_redir=$traffic_log_custom_redir3;
                
               header('location:'.$traffic_log_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_traffic_log_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");
         
         }
      
}
//************* END  traffic_log INSERT QUERY 	
	

//************* START traffic_log  UPDATE QUERY 
if(isset($_POST["traffic_log_update_btn"])){
//------- begin traffic_log_arr_updt --> 
$traffic_log_arr_updt_=array(
"campaign_id"=>"?",
"channel_node"=>"?",
"visit_time"=>"?",
"visit_date"=>"?",
"visitor_name"=>"?",
"page_visited"=>"?",
"page_url"=>"?",
"admin_id"=>"?",
"source_url"=>"?",
"month_year"=>"?",
"ip_address"=>"?",
"comment"=>"?",
"source_page"=>"?",
"time_stamp"=>"?",
"user_id"=>"?",
"log_data"=>"?",
"device"=>"?",
"browser"=>"?"

);
//===-- End traffic_log_arr_updt -->
                     
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "update","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {
         
            $traffic_log_validated_updt_str=$traffic_log_arr_updt_;

            if(isset($traffic_log_updt_inputs))
            {
              $traffic_log_validated_updt_str=$traffic_log_updt_inputs;	
            }

            if(empty($traffic_log_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$traffic_log_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$traffic_log_key_salt=initialize_traffic_log()["schedule_id"];
            
              update_traffic_log($traffic_log_validated_updt_str, "primkey='$traffic_log_uptoken' and schedule_id='$traffic_log_key_salt'");
				

			 mosy_sql_rollback("traffic_log", "primkey='$traffic_log_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $traffic_log_uptoken; 

                    } 

                  }else{ 

                $traffic_log_custom_redir1=add_url_param ("traffic_log_uptoken", base64_encode($traffic_log_uptoken), "");
                $traffic_log_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$traffic_log_custom_redir1);
                $traffic_log_custom_redir3=add_url_param ("traffic_log_table_alert", "traffic_log_updated",$traffic_log_custom_redir2);
                
                ///echo magic_message($traffic_log_custom_redir1." -- ".$traffic_log_custom_redir2."--".$traffic_log_custom_redir3);
                
                $traffic_log_custom_redir=$traffic_log_custom_redir3;
                
               header('location:'.$traffic_log_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_traffic_log_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");
         
         }

      

      
}
//************* END traffic_log  UPDATE QUERY 

    
    
      //== Start traffic_log delete record

      if(isset($_GET["deletetraffic_log"]))
      {
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "super_delete_request","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_traffic_log_btn=magic_button_link("./".$current_file_url."?traffic_log_uptoken=".$_GET["traffic_log_uptoken"]."&conf_deletetraffic_log&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_traffic_log_btn=magic_button_link("./".$current_file_url."?traffic_log_uptoken=".$_GET["traffic_log_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_traffic_log_btn." ".$cancel_del_traffic_log_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_traffic_log_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletetraffic_log"]))
      {
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "super_delete_confirm","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $traffic_log_del_key_salt=initialize_traffic_log()["schedule_id"];
      mosy_sql_rollback("traffic_log", "primkey='$traffic_log_uptoken'", "DELETE");
      drop_traffic_log("primkey='$traffic_log_uptoken' and schedule_id='$traffic_log_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_traffic_log_);

      }
      }

      //== End traffic_log delete record  
    
       ///SELECT STRING FOR traffic_log============================
              
       if(isset($_POST["qtraffic_log_btn"])){
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "qtraffic_log_btn","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {
            $current_traffic_log_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_traffic_log_current_url=$current_traffic_log_url_params.'?qtraffic_log=';
            if (strpos($current_traffic_log_url_params, '?') !== false) {

                $clean_traffic_log_current_url=$current_traffic_log_url_params.'&qtraffic_log=';

            }
            if (strpos($current_traffic_log_url_params, '?qtraffic_log')) {

                $remove_traffic_log_old_token = substr($current_traffic_log_url_params, 0, strpos($current_traffic_log_url_params, "?qtraffic_log"));

                $clean_traffic_log_current_url=$remove_traffic_log_old_token.'?qtraffic_log=';

            }
            if(strpos($current_traffic_log_url_params, '&qtraffic_log')) {

                $remove_traffic_log_old_token = substr($current_traffic_log_url_params, 0, strpos($current_traffic_log_url_params, "&qtraffic_log"));

                $clean_traffic_log_current_url=$remove_traffic_log_old_token.'&qtraffic_log=';

            }
        $qtraffic_log_str=base64_encode($_POST["txt_traffic_log"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_traffic_log_current_url.($qtraffic_log_str);
            } 

          }else{ 
             header('location:'.$clean_traffic_log_current_url.($qtraffic_log_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_traffic_log_);

        }
        }
        $qtraffic_log="";
		if(isset($_GET["traffic_log_mosyfilter"]) && isset($_GET["qtraffic_log"])){
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "traffic_log_mosyfilter_n_query","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {
         $qtraffic_log=mmres(base64_decode($_GET["qtraffic_log"]));
         
         $gft_traffic_log_where_query="(`schedule_id` LIKE '%".$qtraffic_log."%' OR  `campaign_id` LIKE '%".$qtraffic_log."%' OR  `channel_node` LIKE '%".$qtraffic_log."%' OR  `visit_time` LIKE '%".$qtraffic_log."%' OR  `visit_date` LIKE '%".$qtraffic_log."%' OR  `visitor_name` LIKE '%".$qtraffic_log."%' OR  `page_visited` LIKE '%".$qtraffic_log."%' OR  `page_url` LIKE '%".$qtraffic_log."%' OR  `admin_id` LIKE '%".$qtraffic_log."%' OR  `source_url` LIKE '%".$qtraffic_log."%' OR  `month_year` LIKE '%".$qtraffic_log."%' OR  `ip_address` LIKE '%".$qtraffic_log."%' OR  `comment` LIKE '%".$qtraffic_log."%' OR  `source_page` LIKE '%".$qtraffic_log."%' OR  `time_stamp` LIKE '%".$qtraffic_log."%' OR  `user_id` LIKE '%".$qtraffic_log."%' OR  `log_data` LIKE '%".$qtraffic_log."%' OR  `device` LIKE '%".$qtraffic_log."%' OR  `browser` LIKE '%".$qtraffic_log."%')";
         
         if($_GET["traffic_log_mosyfilter"]!=""){
         
         $mosyfilter_traffic_log_queries_str=(base64_decode($_GET["traffic_log_mosyfilter"]));
        
         $gft_traffic_log_where_query="(`schedule_id` LIKE '%".$qtraffic_log."%' OR  `campaign_id` LIKE '%".$qtraffic_log."%' OR  `channel_node` LIKE '%".$qtraffic_log."%' OR  `visit_time` LIKE '%".$qtraffic_log."%' OR  `visit_date` LIKE '%".$qtraffic_log."%' OR  `visitor_name` LIKE '%".$qtraffic_log."%' OR  `page_visited` LIKE '%".$qtraffic_log."%' OR  `page_url` LIKE '%".$qtraffic_log."%' OR  `admin_id` LIKE '%".$qtraffic_log."%' OR  `source_url` LIKE '%".$qtraffic_log."%' OR  `month_year` LIKE '%".$qtraffic_log."%' OR  `ip_address` LIKE '%".$qtraffic_log."%' OR  `comment` LIKE '%".$qtraffic_log."%' OR  `source_page` LIKE '%".$qtraffic_log."%' OR  `time_stamp` LIKE '%".$qtraffic_log."%' OR  `user_id` LIKE '%".$qtraffic_log."%' OR  `log_data` LIKE '%".$qtraffic_log."%' OR  `device` LIKE '%".$qtraffic_log."%' OR  `browser` LIKE '%".$qtraffic_log."%') AND ".$mosyfilter_traffic_log_queries_str."";
         
         }
         
		 $gft_traffic_log="WHERE ".$gft_traffic_log_where_query;
         
         $gft_traffic_log_and=$gft_traffic_log_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_traffic_log_);
        }
        }elseif(isset($_GET["qtraffic_log"])){
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "get_qtraffic_log","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {
		 $qtraffic_log=mmres(base64_decode($_GET["qtraffic_log"]));
        
         $gft_traffic_log_where_query="(`schedule_id` LIKE '%".$qtraffic_log."%' OR  `campaign_id` LIKE '%".$qtraffic_log."%' OR  `channel_node` LIKE '%".$qtraffic_log."%' OR  `visit_time` LIKE '%".$qtraffic_log."%' OR  `visit_date` LIKE '%".$qtraffic_log."%' OR  `visitor_name` LIKE '%".$qtraffic_log."%' OR  `page_visited` LIKE '%".$qtraffic_log."%' OR  `page_url` LIKE '%".$qtraffic_log."%' OR  `admin_id` LIKE '%".$qtraffic_log."%' OR  `source_url` LIKE '%".$qtraffic_log."%' OR  `month_year` LIKE '%".$qtraffic_log."%' OR  `ip_address` LIKE '%".$qtraffic_log."%' OR  `comment` LIKE '%".$qtraffic_log."%' OR  `source_page` LIKE '%".$qtraffic_log."%' OR  `time_stamp` LIKE '%".$qtraffic_log."%' OR  `user_id` LIKE '%".$qtraffic_log."%' OR  `log_data` LIKE '%".$qtraffic_log."%' OR  `device` LIKE '%".$qtraffic_log."%' OR  `browser` LIKE '%".$qtraffic_log."%')";
         
         $gft_traffic_log="WHERE ".$gft_traffic_log_where_query;
         
         $gft_traffic_log_and=$gft_traffic_log_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_traffic_log_);

        }
        }elseif(isset($_GET["traffic_log_mosyfilter"])){
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "traffic_log_mosyfilter","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {
         $gft_traffic_log_where_query="";
         $gft_traffic_log="";

         if($_GET["traffic_log_mosyfilter"]!=""){
          $gft_traffic_log_where_query=(base64_decode($_GET["traffic_log_mosyfilter"]));
          $gft_traffic_log="WHERE ".$gft_traffic_log_where_query;
         }
         
         
         $gft_traffic_log_and=$gft_traffic_log_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_traffic_log_);

        }
        }else{
         $gft_traffic_log="";
         $gft_traffic_log_and="";
         $gft_traffic_log_where_query="";
        }
       
    //************************************************* END  traffic_log OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  

//<--ncgh-->

?>