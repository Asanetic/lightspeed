////document.write('<script type="text/javascript" src="https://newafamily.org/socialapi/js/jsfunctions.js"></script>');
var adminid='AD5QGFY';

$(document).ready(function () { 
    //==
        
var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function() {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};

//if( isMobile.any() ) alert('Mobile');

function myFunction() { 
     if((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1 ) 
    {
        return 'Opera';
    }
    else if(navigator.userAgent.indexOf("Chrome") != -1 )
    {
        return 'Chrome';
    }
    else if(navigator.userAgent.indexOf("Safari") != -1)
    {
        return 'Safari';
    }
    else if(navigator.userAgent.indexOf("Firefox") != -1 ) 
    {
        return 'FireFox';
    }
    else if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
    {
        return 'IE';
    }  
    else 
    {
        return 'Others';
    }
    }
  var browser_type = myFunction();  
 
if( isMobile.any() ) 
{
var device_type="Mobile";
}else{
var device_type="Desktop";

}

    //==
    var wordoutmarkid = magic_get_url_param('markid');
    var wordouttaskid = magic_get_url_param('taskid');
    var wordoutcampid = magic_get_url_param('campid');
    
    if(wordoutmarkid=='null')
    {
    var wordoutmarkid = '';
    var wordouttaskid = '';
    var wordoutcampid = '';
    }
    
    /////alert(wordoutcampid);
    
	var trflgdt= btoa('{"markid":"'+(wordoutmarkid)+'", "schedid":"'+(wordouttaskid)+'","campid":"'+(wordoutcampid)+'","pagetitle":"'+(document.title)+'","pageurl":"'+(window.location.href)+'","refurl":"'+(document.referrer)+'","admin_id":"'+(adminid)+'", "device_type":"'+device_type+'", "browser_type":"'+browser_type+'","wo_uid":"'+magic_cookie_value('wo_uid')
+'"}');

    var pixelurl='<img src="https://origin.clearphrases.com/treng/trflg.php?post_name=trflg&post_data='+trflgdt+'" style="width:1px; height:1px;"/>';
    
    var wo_anly_node = document.createElement("div"); 
    wo_anly_node.setAttribute("id", "wo_node_trk");

    document.body.appendChild(wo_anly_node); 
    
    document.getElementById('wo_node_trk').innerHTML=pixelurl;
    
    
}); 



	
	
