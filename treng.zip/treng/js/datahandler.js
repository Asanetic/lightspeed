 
//===============Start Mosy queries-============ 

    //Start get  app_admins Data ===============
    
      function get_app_admins(app_admins_colstr, app_admins_filter_col, app_admins_cols, app_admins_node_function_name, app_admins_callback_function_string, app_admins_ui_tag, app_admins_pagination)
      {
        mosyflex_sel("app_admins", app_admins_colstr, app_admins_filter_col , app_admins_cols, app_admins_node_function_name, app_admins_callback_function_string, app_admins_ui_tag, app_admins_pagination);
        
      }
    //End get  app_admins Data ===============

    //Start insert  app_admins Data ===============

	function add_app_admins(app_admins_cols, app_admins_vals, app_admins_callback_function_string)
    {
		
        mosyajax_create_data("app_admins", app_admins_cols, app_admins_vals, app_admins_callback_function_string);
     }
     
    //End insert  app_admins Data ===============

    
    //Start update  app_admins Data ===============

    function update_app_admins(app_admins_update_str, app_admins_where_str, app_admins_callback_function_string){
    
		mosyajax_update("app_admins", app_admins_update_str, app_admins_where_str, app_admins_callback_function_string)
    
    }
    //end  update  app_admins Data ===============

	//Start drop  app_admins Data ===============
    function app_admins_drop(app_admins_where_str, app_admins_callback_function_string)
    {
        mosyajax_drop("app_admins", app_admins_where_str, app_admins_callback_function_string)

    }
	//End drop  app_admins Data ===============
    
    function initialize_app_admins(qstr="", app_admins_callback_function_string="")
    {
    
    ///alert(qstr);
      var app_admins_token_query =qstr;
      if(qstr=="")
      {
       var app_admins_token_query_param="";
       var app_admins_js_uptoken=mosy_get_param("app_admins_uptoken");
       //alert(app_admins_js_uptoken);
       if(app_admins_js_uptoken!==undefined)
       {
       
        app_admins_token_query_param = atob(app_admins_js_uptoken);
       }
        app_admins_token_query = " where primkey='"+(app_admins_token_query_param)+"'";
        
           if (document.getElementById("app_admins_uptoken") !==null) {
           	if(document.getElementById("app_admins_uptoken").value!="")
            {
            
            var app_admins_atob_tbl_key =atob(document.getElementById("app_admins_uptoken").value);
            
                   
            app_admins_token_query = " where primkey='"+(app_admins_atob_tbl_key)+"'";

            }
           }
      }
      
      var app_admins_push_ui_data_to =app_admins_callback_function_string;
      if(app_admins_callback_function_string=="")
      {
      app_admins_push_ui_data_to = "add_app_admins_ui_data";
      }
                
      console.log(app_admins_token_query+" -- "+app_admins_js_uptoken);

	  //alert(app_admins_push_ui_data_to);

     get_app_admins("*", app_admins_token_query, "primkey", "blackhole", app_admins_push_ui_data_to, "");
    }
    
    function add_app_admins_ui_data(app_admins_server_resp) 
    {
    
    ///alert(app_admins_server_resp);
    
    var json_decoded_str=JSON.parse(app_admins_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load app_admins data on the fly ==============
    
	var gft_app_admins_str="(user_id LIKE '%{{qapp_admins}}%' OR  name LIKE '%{{qapp_admins}}%' OR  email LIKE '%{{qapp_admins}}%' OR  tel LIKE '%{{qapp_admins}}%' OR  login_password LIKE '%{{qapp_admins}}%' OR  ref_id LIKE '%{{qapp_admins}}%' OR  regdate LIKE '%{{qapp_admins}}%' OR  user_no LIKE '%{{qapp_admins}}%' OR  user_pic LIKE '%{{qapp_admins}}%' OR  user_gender LIKE '%{{qapp_admins}}%' OR  last_seen LIKE '%{{qapp_admins}}%' OR  about LIKE '%{{qapp_admins}}%')";
    
    function  gft_app_admins(qapp_admins_str)
    {
        	var clean_app_admins_filter_str=gft_app_admins_str.replace(/{{qapp_admins}}/g, magic_clean_str(qapp_admins_str));
            
            return  clean_app_admins_filter_str;

    }
    
    function load_app_admins(app_admins_qstr, app_admins_where_str, app_admins_ret_cols, app_admins_user_function, app_admins_result_function, app_admins_data_tray)
    {
    
    var fapp_admins_result_function="push_result";
      
    if(app_admins_result_function!="")
    {
          var fapp_admins_result_function=app_admins_result_function;

    }
    	var clean_app_admins_filter_str=gft_app_admins_str.replace(/{{qapp_admins}}/g, magic_clean_str(app_admins_qstr));
        
        var fapp_admins_where_str=" where "+clean_app_admins_filter_str;

    if(app_admins_where_str!="")
    {
          var fapp_admins_where_str=" "+app_admins_where_str;

    }
       
      get_app_admins("*", fapp_admins_where_str, app_admins_ret_cols, app_admins_user_function, fapp_admins_result_function, app_admins_data_tray);
      
    }
    ///=============== load app_admins data on the fly ==============


 ///=quick load 
 
function qkload_app_admins(qstr, push_fun="", ui_card="", and_query="", additional_cols="", app_admins_pagination="")
{

	var app_admins_list_nodes_str=app_admins_list_nodes;
  
   if(ui_card!="")
   {
      app_admins_list_nodes_str=ui_card;
   }
   
   var app_admins_qret_fun="push_grid_result:app_admins_tbl_list";
   
   if(push_fun!="")
   {
    app_admins_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_app_admins("*", ajaxw+" ("+gft_app_admins(qstr)+") "+combined_query+"  order by primkey desc ", app_admins_list_cols+additional_cols_str, "",app_admins_qret_fun, "c=>"+app_admins_list_nodes_str, app_admins_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_app_admins(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_app_admins("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qapp_admins_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_app_admins("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_app_admins("*", app_admins_token_query, "primkey", "blackhole", app_admins_push_ui_data_to, "");
    

}



//sum 

function sum_app_admins(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_app_admins("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function app_admins_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "app_admins_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function app_admins_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "app_admins_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function app_admins_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteapp_admins&app_admins_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_app_admins_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('app_admins')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  apps Data ===============
    
      function get_apps(apps_colstr, apps_filter_col, apps_cols, apps_node_function_name, apps_callback_function_string, apps_ui_tag, apps_pagination)
      {
        mosyflex_sel("apps", apps_colstr, apps_filter_col , apps_cols, apps_node_function_name, apps_callback_function_string, apps_ui_tag, apps_pagination);
        
      }
    //End get  apps Data ===============

    //Start insert  apps Data ===============

	function add_apps(apps_cols, apps_vals, apps_callback_function_string)
    {
		
        mosyajax_create_data("apps", apps_cols, apps_vals, apps_callback_function_string);
     }
     
    //End insert  apps Data ===============

    
    //Start update  apps Data ===============

    function update_apps(apps_update_str, apps_where_str, apps_callback_function_string){
    
		mosyajax_update("apps", apps_update_str, apps_where_str, apps_callback_function_string)
    
    }
    //end  update  apps Data ===============

	//Start drop  apps Data ===============
    function apps_drop(apps_where_str, apps_callback_function_string)
    {
        mosyajax_drop("apps", apps_where_str, apps_callback_function_string)

    }
	//End drop  apps Data ===============
    
    function initialize_apps(qstr="", apps_callback_function_string="")
    {
    
    ///alert(qstr);
      var apps_token_query =qstr;
      if(qstr=="")
      {
       var apps_token_query_param="";
       var apps_js_uptoken=mosy_get_param("apps_uptoken");
       //alert(apps_js_uptoken);
       if(apps_js_uptoken!==undefined)
       {
       
        apps_token_query_param = atob(apps_js_uptoken);
       }
        apps_token_query = " where primkey='"+(apps_token_query_param)+"'";
        
           if (document.getElementById("apps_uptoken") !==null) {
           	if(document.getElementById("apps_uptoken").value!="")
            {
            
            var apps_atob_tbl_key =atob(document.getElementById("apps_uptoken").value);
            
                   
            apps_token_query = " where primkey='"+(apps_atob_tbl_key)+"'";

            }
           }
      }
      
      var apps_push_ui_data_to =apps_callback_function_string;
      if(apps_callback_function_string=="")
      {
      apps_push_ui_data_to = "add_apps_ui_data";
      }
                
      console.log(apps_token_query+" -- "+apps_js_uptoken);

	  //alert(apps_push_ui_data_to);

     get_apps("*", apps_token_query, "primkey", "blackhole", apps_push_ui_data_to, "");
    }
    
    function add_apps_ui_data(apps_server_resp) 
    {
    
    ///alert(apps_server_resp);
    
    var json_decoded_str=JSON.parse(apps_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load apps data on the fly ==============
    
	var gft_apps_str="(appid LIKE '%{{qapps}}%' OR  apptitle LIKE '%{{qapps}}%' OR  name LIKE '%{{qapps}}%' OR  run_at LIKE '%{{qapps}}%' OR  app_key LIKE '%{{qapps}}%' OR  secret LIKE '%{{qapps}}%' OR  details LIKE '%{{qapps}}%' OR  admin_id LIKE '%{{qapps}}%')";
    
    function  gft_apps(qapps_str)
    {
        	var clean_apps_filter_str=gft_apps_str.replace(/{{qapps}}/g, magic_clean_str(qapps_str));
            
            return  clean_apps_filter_str;

    }
    
    function load_apps(apps_qstr, apps_where_str, apps_ret_cols, apps_user_function, apps_result_function, apps_data_tray)
    {
    
    var fapps_result_function="push_result";
      
    if(apps_result_function!="")
    {
          var fapps_result_function=apps_result_function;

    }
    	var clean_apps_filter_str=gft_apps_str.replace(/{{qapps}}/g, magic_clean_str(apps_qstr));
        
        var fapps_where_str=" where "+clean_apps_filter_str;

    if(apps_where_str!="")
    {
          var fapps_where_str=" "+apps_where_str;

    }
       
      get_apps("*", fapps_where_str, apps_ret_cols, apps_user_function, fapps_result_function, apps_data_tray);
      
    }
    ///=============== load apps data on the fly ==============


 ///=quick load 
 
function qkload_apps(qstr, push_fun="", ui_card="", and_query="", additional_cols="", apps_pagination="")
{

	var apps_list_nodes_str=apps_list_nodes;
  
   if(ui_card!="")
   {
      apps_list_nodes_str=ui_card;
   }
   
   var apps_qret_fun="push_grid_result:apps_tbl_list";
   
   if(push_fun!="")
   {
    apps_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_apps("*", ajaxw+" ("+gft_apps(qstr)+") "+combined_query+"  order by primkey desc ", apps_list_cols+additional_cols_str, "",apps_qret_fun, "c=>"+apps_list_nodes_str, apps_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_apps(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_apps("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qapps_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_apps("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_apps("*", apps_token_query, "primkey", "blackhole", apps_push_ui_data_to, "");
    

}



//sum 

function sum_apps(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_apps("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function apps_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "apps_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function apps_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "apps_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function apps_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteapps&apps_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_apps_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('apps')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  file_uploads Data ===============
    
      function get_file_uploads(file_uploads_colstr, file_uploads_filter_col, file_uploads_cols, file_uploads_node_function_name, file_uploads_callback_function_string, file_uploads_ui_tag, file_uploads_pagination)
      {
        mosyflex_sel("file_uploads", file_uploads_colstr, file_uploads_filter_col , file_uploads_cols, file_uploads_node_function_name, file_uploads_callback_function_string, file_uploads_ui_tag, file_uploads_pagination);
        
      }
    //End get  file_uploads Data ===============

    //Start insert  file_uploads Data ===============

	function add_file_uploads(file_uploads_cols, file_uploads_vals, file_uploads_callback_function_string)
    {
		
        mosyajax_create_data("file_uploads", file_uploads_cols, file_uploads_vals, file_uploads_callback_function_string);
     }
     
    //End insert  file_uploads Data ===============

    
    //Start update  file_uploads Data ===============

    function update_file_uploads(file_uploads_update_str, file_uploads_where_str, file_uploads_callback_function_string){
    
		mosyajax_update("file_uploads", file_uploads_update_str, file_uploads_where_str, file_uploads_callback_function_string)
    
    }
    //end  update  file_uploads Data ===============

	//Start drop  file_uploads Data ===============
    function file_uploads_drop(file_uploads_where_str, file_uploads_callback_function_string)
    {
        mosyajax_drop("file_uploads", file_uploads_where_str, file_uploads_callback_function_string)

    }
	//End drop  file_uploads Data ===============
    
    function initialize_file_uploads(qstr="", file_uploads_callback_function_string="")
    {
    
    ///alert(qstr);
      var file_uploads_token_query =qstr;
      if(qstr=="")
      {
       var file_uploads_token_query_param="";
       var file_uploads_js_uptoken=mosy_get_param("file_uploads_uptoken");
       //alert(file_uploads_js_uptoken);
       if(file_uploads_js_uptoken!==undefined)
       {
       
        file_uploads_token_query_param = atob(file_uploads_js_uptoken);
       }
        file_uploads_token_query = " where primkey='"+(file_uploads_token_query_param)+"'";
        
           if (document.getElementById("file_uploads_uptoken") !==null) {
           	if(document.getElementById("file_uploads_uptoken").value!="")
            {
            
            var file_uploads_atob_tbl_key =atob(document.getElementById("file_uploads_uptoken").value);
            
                   
            file_uploads_token_query = " where primkey='"+(file_uploads_atob_tbl_key)+"'";

            }
           }
      }
      
      var file_uploads_push_ui_data_to =file_uploads_callback_function_string;
      if(file_uploads_callback_function_string=="")
      {
      file_uploads_push_ui_data_to = "add_file_uploads_ui_data";
      }
                
      console.log(file_uploads_token_query+" -- "+file_uploads_js_uptoken);

	  //alert(file_uploads_push_ui_data_to);

     get_file_uploads("*", file_uploads_token_query, "primkey", "blackhole", file_uploads_push_ui_data_to, "");
    }
    
    function add_file_uploads_ui_data(file_uploads_server_resp) 
    {
    
    ///alert(file_uploads_server_resp);
    
    var json_decoded_str=JSON.parse(file_uploads_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load file_uploads data on the fly ==============
    
	var gft_file_uploads_str="(media_key LIKE '%{{qfile_uploads}}%' OR  fileurl LIKE '%{{qfile_uploads}}%' OR  file_tile LIKE '%{{qfile_uploads}}%' OR  file_tag LIKE '%{{qfile_uploads}}%' OR  post_blog LIKE '%{{qfile_uploads}}%')";
    
    function  gft_file_uploads(qfile_uploads_str)
    {
        	var clean_file_uploads_filter_str=gft_file_uploads_str.replace(/{{qfile_uploads}}/g, magic_clean_str(qfile_uploads_str));
            
            return  clean_file_uploads_filter_str;

    }
    
    function load_file_uploads(file_uploads_qstr, file_uploads_where_str, file_uploads_ret_cols, file_uploads_user_function, file_uploads_result_function, file_uploads_data_tray)
    {
    
    var ffile_uploads_result_function="push_result";
      
    if(file_uploads_result_function!="")
    {
          var ffile_uploads_result_function=file_uploads_result_function;

    }
    	var clean_file_uploads_filter_str=gft_file_uploads_str.replace(/{{qfile_uploads}}/g, magic_clean_str(file_uploads_qstr));
        
        var ffile_uploads_where_str=" where "+clean_file_uploads_filter_str;

    if(file_uploads_where_str!="")
    {
          var ffile_uploads_where_str=" "+file_uploads_where_str;

    }
       
      get_file_uploads("*", ffile_uploads_where_str, file_uploads_ret_cols, file_uploads_user_function, ffile_uploads_result_function, file_uploads_data_tray);
      
    }
    ///=============== load file_uploads data on the fly ==============


 ///=quick load 
 
function qkload_file_uploads(qstr, push_fun="", ui_card="", and_query="", additional_cols="", file_uploads_pagination="")
{

	var file_uploads_list_nodes_str=file_uploads_list_nodes;
  
   if(ui_card!="")
   {
      file_uploads_list_nodes_str=ui_card;
   }
   
   var file_uploads_qret_fun="push_grid_result:file_uploads_tbl_list";
   
   if(push_fun!="")
   {
    file_uploads_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_file_uploads("*", ajaxw+" ("+gft_file_uploads(qstr)+") "+combined_query+"  order by primkey desc ", file_uploads_list_cols+additional_cols_str, "",file_uploads_qret_fun, "c=>"+file_uploads_list_nodes_str, file_uploads_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_file_uploads(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_file_uploads("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qfile_uploads_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_file_uploads("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_file_uploads("*", file_uploads_token_query, "primkey", "blackhole", file_uploads_push_ui_data_to, "");
    

}



//sum 

function sum_file_uploads(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_file_uploads("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function file_uploads_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "file_uploads_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function file_uploads_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "file_uploads_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function file_uploads_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletefile_uploads&file_uploads_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_file_uploads_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('file_uploads')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  keys_n_tokens Data ===============
    
      function get_keys_n_tokens(keys_n_tokens_colstr, keys_n_tokens_filter_col, keys_n_tokens_cols, keys_n_tokens_node_function_name, keys_n_tokens_callback_function_string, keys_n_tokens_ui_tag, keys_n_tokens_pagination)
      {
        mosyflex_sel("keys_n_tokens", keys_n_tokens_colstr, keys_n_tokens_filter_col , keys_n_tokens_cols, keys_n_tokens_node_function_name, keys_n_tokens_callback_function_string, keys_n_tokens_ui_tag, keys_n_tokens_pagination);
        
      }
    //End get  keys_n_tokens Data ===============

    //Start insert  keys_n_tokens Data ===============

	function add_keys_n_tokens(keys_n_tokens_cols, keys_n_tokens_vals, keys_n_tokens_callback_function_string)
    {
		
        mosyajax_create_data("keys_n_tokens", keys_n_tokens_cols, keys_n_tokens_vals, keys_n_tokens_callback_function_string);
     }
     
    //End insert  keys_n_tokens Data ===============

    
    //Start update  keys_n_tokens Data ===============

    function update_keys_n_tokens(keys_n_tokens_update_str, keys_n_tokens_where_str, keys_n_tokens_callback_function_string){
    
		mosyajax_update("keys_n_tokens", keys_n_tokens_update_str, keys_n_tokens_where_str, keys_n_tokens_callback_function_string)
    
    }
    //end  update  keys_n_tokens Data ===============

	//Start drop  keys_n_tokens Data ===============
    function keys_n_tokens_drop(keys_n_tokens_where_str, keys_n_tokens_callback_function_string)
    {
        mosyajax_drop("keys_n_tokens", keys_n_tokens_where_str, keys_n_tokens_callback_function_string)

    }
	//End drop  keys_n_tokens Data ===============
    
    function initialize_keys_n_tokens(qstr="", keys_n_tokens_callback_function_string="")
    {
    
    ///alert(qstr);
      var keys_n_tokens_token_query =qstr;
      if(qstr=="")
      {
       var keys_n_tokens_token_query_param="";
       var keys_n_tokens_js_uptoken=mosy_get_param("keys_n_tokens_uptoken");
       //alert(keys_n_tokens_js_uptoken);
       if(keys_n_tokens_js_uptoken!==undefined)
       {
       
        keys_n_tokens_token_query_param = atob(keys_n_tokens_js_uptoken);
       }
        keys_n_tokens_token_query = " where primkey='"+(keys_n_tokens_token_query_param)+"'";
        
           if (document.getElementById("keys_n_tokens_uptoken") !==null) {
           	if(document.getElementById("keys_n_tokens_uptoken").value!="")
            {
            
            var keys_n_tokens_atob_tbl_key =atob(document.getElementById("keys_n_tokens_uptoken").value);
            
                   
            keys_n_tokens_token_query = " where primkey='"+(keys_n_tokens_atob_tbl_key)+"'";

            }
           }
      }
      
      var keys_n_tokens_push_ui_data_to =keys_n_tokens_callback_function_string;
      if(keys_n_tokens_callback_function_string=="")
      {
      keys_n_tokens_push_ui_data_to = "add_keys_n_tokens_ui_data";
      }
                
      console.log(keys_n_tokens_token_query+" -- "+keys_n_tokens_js_uptoken);

	  //alert(keys_n_tokens_push_ui_data_to);

     get_keys_n_tokens("*", keys_n_tokens_token_query, "primkey", "blackhole", keys_n_tokens_push_ui_data_to, "");
    }
    
    function add_keys_n_tokens_ui_data(keys_n_tokens_server_resp) 
    {
    
    ///alert(keys_n_tokens_server_resp);
    
    var json_decoded_str=JSON.parse(keys_n_tokens_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load keys_n_tokens data on the fly ==============
    
	var gft_keys_n_tokens_str="(tokenid LIKE '%{{qkeys_n_tokens}}%' OR  page_name LIKE '%{{qkeys_n_tokens}}%' OR  appid LIKE '%{{qkeys_n_tokens}}%' OR  regon LIKE '%{{qkeys_n_tokens}}%' OR  type LIKE '%{{qkeys_n_tokens}}%' OR  descr LIKE '%{{qkeys_n_tokens}}%' OR  token LIKE '%{{qkeys_n_tokens}}%' OR  admin_id LIKE '%{{qkeys_n_tokens}}%')";
    
    function  gft_keys_n_tokens(qkeys_n_tokens_str)
    {
        	var clean_keys_n_tokens_filter_str=gft_keys_n_tokens_str.replace(/{{qkeys_n_tokens}}/g, magic_clean_str(qkeys_n_tokens_str));
            
            return  clean_keys_n_tokens_filter_str;

    }
    
    function load_keys_n_tokens(keys_n_tokens_qstr, keys_n_tokens_where_str, keys_n_tokens_ret_cols, keys_n_tokens_user_function, keys_n_tokens_result_function, keys_n_tokens_data_tray)
    {
    
    var fkeys_n_tokens_result_function="push_result";
      
    if(keys_n_tokens_result_function!="")
    {
          var fkeys_n_tokens_result_function=keys_n_tokens_result_function;

    }
    	var clean_keys_n_tokens_filter_str=gft_keys_n_tokens_str.replace(/{{qkeys_n_tokens}}/g, magic_clean_str(keys_n_tokens_qstr));
        
        var fkeys_n_tokens_where_str=" where "+clean_keys_n_tokens_filter_str;

    if(keys_n_tokens_where_str!="")
    {
          var fkeys_n_tokens_where_str=" "+keys_n_tokens_where_str;

    }
       
      get_keys_n_tokens("*", fkeys_n_tokens_where_str, keys_n_tokens_ret_cols, keys_n_tokens_user_function, fkeys_n_tokens_result_function, keys_n_tokens_data_tray);
      
    }
    ///=============== load keys_n_tokens data on the fly ==============


 ///=quick load 
 
function qkload_keys_n_tokens(qstr, push_fun="", ui_card="", and_query="", additional_cols="", keys_n_tokens_pagination="")
{

	var keys_n_tokens_list_nodes_str=keys_n_tokens_list_nodes;
  
   if(ui_card!="")
   {
      keys_n_tokens_list_nodes_str=ui_card;
   }
   
   var keys_n_tokens_qret_fun="push_grid_result:keys_n_tokens_tbl_list";
   
   if(push_fun!="")
   {
    keys_n_tokens_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_keys_n_tokens("*", ajaxw+" ("+gft_keys_n_tokens(qstr)+") "+combined_query+"  order by primkey desc ", keys_n_tokens_list_cols+additional_cols_str, "",keys_n_tokens_qret_fun, "c=>"+keys_n_tokens_list_nodes_str, keys_n_tokens_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_keys_n_tokens(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_keys_n_tokens("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qkeys_n_tokens_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_keys_n_tokens("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_keys_n_tokens("*", keys_n_tokens_token_query, "primkey", "blackhole", keys_n_tokens_push_ui_data_to, "");
    

}



//sum 

function sum_keys_n_tokens(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_keys_n_tokens("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function keys_n_tokens_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "keys_n_tokens_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function keys_n_tokens_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "keys_n_tokens_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function keys_n_tokens_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletekeys_n_tokens&keys_n_tokens_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_keys_n_tokens_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('keys_n_tokens')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  market_list Data ===============
    
      function get_market_list(market_list_colstr, market_list_filter_col, market_list_cols, market_list_node_function_name, market_list_callback_function_string, market_list_ui_tag, market_list_pagination)
      {
        mosyflex_sel("market_list", market_list_colstr, market_list_filter_col , market_list_cols, market_list_node_function_name, market_list_callback_function_string, market_list_ui_tag, market_list_pagination);
        
      }
    //End get  market_list Data ===============

    //Start insert  market_list Data ===============

	function add_market_list(market_list_cols, market_list_vals, market_list_callback_function_string)
    {
		
        mosyajax_create_data("market_list", market_list_cols, market_list_vals, market_list_callback_function_string);
     }
     
    //End insert  market_list Data ===============

    
    //Start update  market_list Data ===============

    function update_market_list(market_list_update_str, market_list_where_str, market_list_callback_function_string){
    
		mosyajax_update("market_list", market_list_update_str, market_list_where_str, market_list_callback_function_string)
    
    }
    //end  update  market_list Data ===============

	//Start drop  market_list Data ===============
    function market_list_drop(market_list_where_str, market_list_callback_function_string)
    {
        mosyajax_drop("market_list", market_list_where_str, market_list_callback_function_string)

    }
	//End drop  market_list Data ===============
    
    function initialize_market_list(qstr="", market_list_callback_function_string="")
    {
    
    ///alert(qstr);
      var market_list_token_query =qstr;
      if(qstr=="")
      {
       var market_list_token_query_param="";
       var market_list_js_uptoken=mosy_get_param("market_list_uptoken");
       //alert(market_list_js_uptoken);
       if(market_list_js_uptoken!==undefined)
       {
       
        market_list_token_query_param = atob(market_list_js_uptoken);
       }
        market_list_token_query = " where primkey='"+(market_list_token_query_param)+"'";
        
           if (document.getElementById("market_list_uptoken") !==null) {
           	if(document.getElementById("market_list_uptoken").value!="")
            {
            
            var market_list_atob_tbl_key =atob(document.getElementById("market_list_uptoken").value);
            
                   
            market_list_token_query = " where primkey='"+(market_list_atob_tbl_key)+"'";

            }
           }
      }
      
      var market_list_push_ui_data_to =market_list_callback_function_string;
      if(market_list_callback_function_string=="")
      {
      market_list_push_ui_data_to = "add_market_list_ui_data";
      }
                
      console.log(market_list_token_query+" -- "+market_list_js_uptoken);

	  //alert(market_list_push_ui_data_to);

     get_market_list("*", market_list_token_query, "primkey", "blackhole", market_list_push_ui_data_to, "");
    }
    
    function add_market_list_ui_data(market_list_server_resp) 
    {
    
    ///alert(market_list_server_resp);
    
    var json_decoded_str=JSON.parse(market_list_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load market_list data on the fly ==============
    
	var gft_market_list_str="(marketid LIKE '%{{qmarket_list}}%' OR  market_name LIKE '%{{qmarket_list}}%' OR  market_page LIKE '%{{qmarket_list}}%' OR  market_location LIKE '%{{qmarket_list}}%' OR  post_content_to LIKE '%{{qmarket_list}}%' OR  remark LIKE '%{{qmarket_list}}%')";
    
    function  gft_market_list(qmarket_list_str)
    {
        	var clean_market_list_filter_str=gft_market_list_str.replace(/{{qmarket_list}}/g, magic_clean_str(qmarket_list_str));
            
            return  clean_market_list_filter_str;

    }
    
    function load_market_list(market_list_qstr, market_list_where_str, market_list_ret_cols, market_list_user_function, market_list_result_function, market_list_data_tray)
    {
    
    var fmarket_list_result_function="push_result";
      
    if(market_list_result_function!="")
    {
          var fmarket_list_result_function=market_list_result_function;

    }
    	var clean_market_list_filter_str=gft_market_list_str.replace(/{{qmarket_list}}/g, magic_clean_str(market_list_qstr));
        
        var fmarket_list_where_str=" where "+clean_market_list_filter_str;

    if(market_list_where_str!="")
    {
          var fmarket_list_where_str=" "+market_list_where_str;

    }
       
      get_market_list("*", fmarket_list_where_str, market_list_ret_cols, market_list_user_function, fmarket_list_result_function, market_list_data_tray);
      
    }
    ///=============== load market_list data on the fly ==============


 ///=quick load 
 
function qkload_market_list(qstr, push_fun="", ui_card="", and_query="", additional_cols="", market_list_pagination="")
{

	var market_list_list_nodes_str=market_list_list_nodes;
  
   if(ui_card!="")
   {
      market_list_list_nodes_str=ui_card;
   }
   
   var market_list_qret_fun="push_grid_result:market_list_tbl_list";
   
   if(push_fun!="")
   {
    market_list_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_market_list("*", ajaxw+" ("+gft_market_list(qstr)+") "+combined_query+"  order by primkey desc ", market_list_list_cols+additional_cols_str, "",market_list_qret_fun, "c=>"+market_list_list_nodes_str, market_list_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_market_list(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_market_list("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmarket_list_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_market_list("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_market_list("*", market_list_token_query, "primkey", "blackhole", market_list_push_ui_data_to, "");
    

}



//sum 

function sum_market_list(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_market_list("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function market_list_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "market_list_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function market_list_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "market_list_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function market_list_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemarket_list&market_list_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_market_list_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('market_list')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  messages Data ===============
    
      function get_messages(messages_colstr, messages_filter_col, messages_cols, messages_node_function_name, messages_callback_function_string, messages_ui_tag, messages_pagination)
      {
        mosyflex_sel("messages", messages_colstr, messages_filter_col , messages_cols, messages_node_function_name, messages_callback_function_string, messages_ui_tag, messages_pagination);
        
      }
    //End get  messages Data ===============

    //Start insert  messages Data ===============

	function add_messages(messages_cols, messages_vals, messages_callback_function_string)
    {
		
        mosyajax_create_data("messages", messages_cols, messages_vals, messages_callback_function_string);
     }
     
    //End insert  messages Data ===============

    
    //Start update  messages Data ===============

    function update_messages(messages_update_str, messages_where_str, messages_callback_function_string){
    
		mosyajax_update("messages", messages_update_str, messages_where_str, messages_callback_function_string)
    
    }
    //end  update  messages Data ===============

	//Start drop  messages Data ===============
    function messages_drop(messages_where_str, messages_callback_function_string)
    {
        mosyajax_drop("messages", messages_where_str, messages_callback_function_string)

    }
	//End drop  messages Data ===============
    
    function initialize_messages(qstr="", messages_callback_function_string="")
    {
    
    ///alert(qstr);
      var messages_token_query =qstr;
      if(qstr=="")
      {
       var messages_token_query_param="";
       var messages_js_uptoken=mosy_get_param("messages_uptoken");
       //alert(messages_js_uptoken);
       if(messages_js_uptoken!==undefined)
       {
       
        messages_token_query_param = atob(messages_js_uptoken);
       }
        messages_token_query = " where primkey='"+(messages_token_query_param)+"'";
        
           if (document.getElementById("messages_uptoken") !==null) {
           	if(document.getElementById("messages_uptoken").value!="")
            {
            
            var messages_atob_tbl_key =atob(document.getElementById("messages_uptoken").value);
            
                   
            messages_token_query = " where primkey='"+(messages_atob_tbl_key)+"'";

            }
           }
      }
      
      var messages_push_ui_data_to =messages_callback_function_string;
      if(messages_callback_function_string=="")
      {
      messages_push_ui_data_to = "add_messages_ui_data";
      }
                
      console.log(messages_token_query+" -- "+messages_js_uptoken);

	  //alert(messages_push_ui_data_to);

     get_messages("*", messages_token_query, "primkey", "blackhole", messages_push_ui_data_to, "");
    }
    
    function add_messages_ui_data(messages_server_resp) 
    {
    
    ///alert(messages_server_resp);
    
    var json_decoded_str=JSON.parse(messages_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load messages data on the fly ==============
    
	var gft_messages_str="(message_id LIKE '%{{qmessages}}%' OR  user_email LIKE '%{{qmessages}}%' OR  user_mobile LIKE '%{{qmessages}}%' OR  message_date LIKE '%{{qmessages}}%' OR  message LIKE '%{{qmessages}}%' OR  user_name LIKE '%{{qmessages}}%' OR  service_id LIKE '%{{qmessages}}%' OR  service_name LIKE '%{{qmessages}}%' OR  message_remark LIKE '%{{qmessages}}%')";
    
    function  gft_messages(qmessages_str)
    {
        	var clean_messages_filter_str=gft_messages_str.replace(/{{qmessages}}/g, magic_clean_str(qmessages_str));
            
            return  clean_messages_filter_str;

    }
    
    function load_messages(messages_qstr, messages_where_str, messages_ret_cols, messages_user_function, messages_result_function, messages_data_tray)
    {
    
    var fmessages_result_function="push_result";
      
    if(messages_result_function!="")
    {
          var fmessages_result_function=messages_result_function;

    }
    	var clean_messages_filter_str=gft_messages_str.replace(/{{qmessages}}/g, magic_clean_str(messages_qstr));
        
        var fmessages_where_str=" where "+clean_messages_filter_str;

    if(messages_where_str!="")
    {
          var fmessages_where_str=" "+messages_where_str;

    }
       
      get_messages("*", fmessages_where_str, messages_ret_cols, messages_user_function, fmessages_result_function, messages_data_tray);
      
    }
    ///=============== load messages data on the fly ==============


 ///=quick load 
 
function qkload_messages(qstr, push_fun="", ui_card="", and_query="", additional_cols="", messages_pagination="")
{

	var messages_list_nodes_str=messages_list_nodes;
  
   if(ui_card!="")
   {
      messages_list_nodes_str=ui_card;
   }
   
   var messages_qret_fun="push_grid_result:messages_tbl_list";
   
   if(push_fun!="")
   {
    messages_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_messages("*", ajaxw+" ("+gft_messages(qstr)+") "+combined_query+"  order by primkey desc ", messages_list_cols+additional_cols_str, "",messages_qret_fun, "c=>"+messages_list_nodes_str, messages_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_messages(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_messages("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmessages_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_messages("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_messages("*", messages_token_query, "primkey", "blackhole", messages_push_ui_data_to, "");
    

}



//sum 

function sum_messages(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_messages("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function messages_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "messages_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function messages_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "messages_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function messages_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemessages&messages_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_messages_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('messages')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  mosy_sql_roll_back Data ===============
    
      function get_mosy_sql_roll_back(mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col, mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination)
      {
        mosyflex_sel("mosy_sql_roll_back", mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col , mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag, mosy_sql_roll_back_pagination);
        
      }
    //End get  mosy_sql_roll_back Data ===============

    //Start insert  mosy_sql_roll_back Data ===============

	function add_mosy_sql_roll_back(mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string)
    {
		
        mosyajax_create_data("mosy_sql_roll_back", mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string);
     }
     
    //End insert  mosy_sql_roll_back Data ===============

    
    //Start update  mosy_sql_roll_back Data ===============

    function update_mosy_sql_roll_back(mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string){
    
		mosyajax_update("mosy_sql_roll_back", mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    
    }
    //end  update  mosy_sql_roll_back Data ===============

	//Start drop  mosy_sql_roll_back Data ===============
    function mosy_sql_roll_back_drop(mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    {
        mosyajax_drop("mosy_sql_roll_back", mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)

    }
	//End drop  mosy_sql_roll_back Data ===============
    
    function initialize_mosy_sql_roll_back(qstr="", mosy_sql_roll_back_callback_function_string="")
    {
    
    ///alert(qstr);
      var mosy_sql_roll_back_token_query =qstr;
      if(qstr=="")
      {
       var mosy_sql_roll_back_token_query_param="";
       var mosy_sql_roll_back_js_uptoken=mosy_get_param("mosy_sql_roll_back_uptoken");
       //alert(mosy_sql_roll_back_js_uptoken);
       if(mosy_sql_roll_back_js_uptoken!==undefined)
       {
       
        mosy_sql_roll_back_token_query_param = atob(mosy_sql_roll_back_js_uptoken);
       }
        mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_token_query_param)+"'";
        
           if (document.getElementById("mosy_sql_roll_back_uptoken") !==null) {
           	if(document.getElementById("mosy_sql_roll_back_uptoken").value!="")
            {
            
            var mosy_sql_roll_back_atob_tbl_key =atob(document.getElementById("mosy_sql_roll_back_uptoken").value);
            
                   
            mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_atob_tbl_key)+"'";

            }
           }
      }
      
      var mosy_sql_roll_back_push_ui_data_to =mosy_sql_roll_back_callback_function_string;
      if(mosy_sql_roll_back_callback_function_string=="")
      {
      mosy_sql_roll_back_push_ui_data_to = "add_mosy_sql_roll_back_ui_data";
      }
                
      console.log(mosy_sql_roll_back_token_query+" -- "+mosy_sql_roll_back_js_uptoken);

	  //alert(mosy_sql_roll_back_push_ui_data_to);

     get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    }
    
    function add_mosy_sql_roll_back_ui_data(mosy_sql_roll_back_server_resp) 
    {
    
    ///alert(mosy_sql_roll_back_server_resp);
    
    var json_decoded_str=JSON.parse(mosy_sql_roll_back_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load mosy_sql_roll_back data on the fly ==============
    
	var gft_mosy_sql_roll_back_str="(roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
    
    function  gft_mosy_sql_roll_back(qmosy_sql_roll_back_str)
    {
        	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(qmosy_sql_roll_back_str));
            
            return  clean_mosy_sql_roll_back_filter_str;

    }
    
    function load_mosy_sql_roll_back(mosy_sql_roll_back_qstr, mosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, mosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray)
    {
    
    var fmosy_sql_roll_back_result_function="push_result";
      
    if(mosy_sql_roll_back_result_function!="")
    {
          var fmosy_sql_roll_back_result_function=mosy_sql_roll_back_result_function;

    }
    	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(mosy_sql_roll_back_qstr));
        
        var fmosy_sql_roll_back_where_str=" where "+clean_mosy_sql_roll_back_filter_str;

    if(mosy_sql_roll_back_where_str!="")
    {
          var fmosy_sql_roll_back_where_str=" "+mosy_sql_roll_back_where_str;

    }
       
      get_mosy_sql_roll_back("*", fmosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, fmosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray);
      
    }
    ///=============== load mosy_sql_roll_back data on the fly ==============


 ///=quick load 
 
function qkload_mosy_sql_roll_back(qstr, push_fun="", ui_card="", and_query="", additional_cols="", mosy_sql_roll_back_pagination="")
{

	var mosy_sql_roll_back_list_nodes_str=mosy_sql_roll_back_list_nodes;
  
   if(ui_card!="")
   {
      mosy_sql_roll_back_list_nodes_str=ui_card;
   }
   
   var mosy_sql_roll_back_qret_fun="push_grid_result:mosy_sql_roll_back_tbl_list";
   
   if(push_fun!="")
   {
    mosy_sql_roll_back_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_mosy_sql_roll_back("*", ajaxw+" ("+gft_mosy_sql_roll_back(qstr)+") "+combined_query+"  order by primkey desc ", mosy_sql_roll_back_list_cols+additional_cols_str, "",mosy_sql_roll_back_qret_fun, "c=>"+mosy_sql_roll_back_list_nodes_str, mosy_sql_roll_back_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_mosy_sql_roll_back(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_mosy_sql_roll_back("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmosy_sql_roll_back_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_mosy_sql_roll_back("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    

}



//sum 

function sum_mosy_sql_roll_back(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_mosy_sql_roll_back("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function mosy_sql_roll_back_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function mosy_sql_roll_back_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function mosy_sql_roll_back_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemosy_sql_roll_back&mosy_sql_roll_back_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_mosy_sql_roll_back_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('mosy_sql_roll_back')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  notes_admins Data ===============
    
      function get_notes_admins(notes_admins_colstr, notes_admins_filter_col, notes_admins_cols, notes_admins_node_function_name, notes_admins_callback_function_string, notes_admins_ui_tag, notes_admins_pagination)
      {
        mosyflex_sel("notes_admins", notes_admins_colstr, notes_admins_filter_col , notes_admins_cols, notes_admins_node_function_name, notes_admins_callback_function_string, notes_admins_ui_tag, notes_admins_pagination);
        
      }
    //End get  notes_admins Data ===============

    //Start insert  notes_admins Data ===============

	function add_notes_admins(notes_admins_cols, notes_admins_vals, notes_admins_callback_function_string)
    {
		
        mosyajax_create_data("notes_admins", notes_admins_cols, notes_admins_vals, notes_admins_callback_function_string);
     }
     
    //End insert  notes_admins Data ===============

    
    //Start update  notes_admins Data ===============

    function update_notes_admins(notes_admins_update_str, notes_admins_where_str, notes_admins_callback_function_string){
    
		mosyajax_update("notes_admins", notes_admins_update_str, notes_admins_where_str, notes_admins_callback_function_string)
    
    }
    //end  update  notes_admins Data ===============

	//Start drop  notes_admins Data ===============
    function notes_admins_drop(notes_admins_where_str, notes_admins_callback_function_string)
    {
        mosyajax_drop("notes_admins", notes_admins_where_str, notes_admins_callback_function_string)

    }
	//End drop  notes_admins Data ===============
    
    function initialize_notes_admins(qstr="", notes_admins_callback_function_string="")
    {
    
    ///alert(qstr);
      var notes_admins_token_query =qstr;
      if(qstr=="")
      {
       var notes_admins_token_query_param="";
       var notes_admins_js_uptoken=mosy_get_param("notes_admins_uptoken");
       //alert(notes_admins_js_uptoken);
       if(notes_admins_js_uptoken!==undefined)
       {
       
        notes_admins_token_query_param = atob(notes_admins_js_uptoken);
       }
        notes_admins_token_query = " where primkey='"+(notes_admins_token_query_param)+"'";
        
           if (document.getElementById("notes_admins_uptoken") !==null) {
           	if(document.getElementById("notes_admins_uptoken").value!="")
            {
            
            var notes_admins_atob_tbl_key =atob(document.getElementById("notes_admins_uptoken").value);
            
                   
            notes_admins_token_query = " where primkey='"+(notes_admins_atob_tbl_key)+"'";

            }
           }
      }
      
      var notes_admins_push_ui_data_to =notes_admins_callback_function_string;
      if(notes_admins_callback_function_string=="")
      {
      notes_admins_push_ui_data_to = "add_notes_admins_ui_data";
      }
                
      console.log(notes_admins_token_query+" -- "+notes_admins_js_uptoken);

	  //alert(notes_admins_push_ui_data_to);

     get_notes_admins("*", notes_admins_token_query, "primkey", "blackhole", notes_admins_push_ui_data_to, "");
    }
    
    function add_notes_admins_ui_data(notes_admins_server_resp) 
    {
    
    ///alert(notes_admins_server_resp);
    
    var json_decoded_str=JSON.parse(notes_admins_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load notes_admins data on the fly ==============
    
	var gft_notes_admins_str="(user_id LIKE '%{{qnotes_admins}}%' OR  name LIKE '%{{qnotes_admins}}%' OR  email LIKE '%{{qnotes_admins}}%' OR  tel LIKE '%{{qnotes_admins}}%' OR  login_password LIKE '%{{qnotes_admins}}%' OR  ref_id LIKE '%{{qnotes_admins}}%' OR  regdate LIKE '%{{qnotes_admins}}%' OR  user_no LIKE '%{{qnotes_admins}}%' OR  user_pic LIKE '%{{qnotes_admins}}%' OR  user_gender LIKE '%{{qnotes_admins}}%' OR  last_seen LIKE '%{{qnotes_admins}}%' OR  about LIKE '%{{qnotes_admins}}%')";
    
    function  gft_notes_admins(qnotes_admins_str)
    {
        	var clean_notes_admins_filter_str=gft_notes_admins_str.replace(/{{qnotes_admins}}/g, magic_clean_str(qnotes_admins_str));
            
            return  clean_notes_admins_filter_str;

    }
    
    function load_notes_admins(notes_admins_qstr, notes_admins_where_str, notes_admins_ret_cols, notes_admins_user_function, notes_admins_result_function, notes_admins_data_tray)
    {
    
    var fnotes_admins_result_function="push_result";
      
    if(notes_admins_result_function!="")
    {
          var fnotes_admins_result_function=notes_admins_result_function;

    }
    	var clean_notes_admins_filter_str=gft_notes_admins_str.replace(/{{qnotes_admins}}/g, magic_clean_str(notes_admins_qstr));
        
        var fnotes_admins_where_str=" where "+clean_notes_admins_filter_str;

    if(notes_admins_where_str!="")
    {
          var fnotes_admins_where_str=" "+notes_admins_where_str;

    }
       
      get_notes_admins("*", fnotes_admins_where_str, notes_admins_ret_cols, notes_admins_user_function, fnotes_admins_result_function, notes_admins_data_tray);
      
    }
    ///=============== load notes_admins data on the fly ==============


 ///=quick load 
 
function qkload_notes_admins(qstr, push_fun="", ui_card="", and_query="", additional_cols="", notes_admins_pagination="")
{

	var notes_admins_list_nodes_str=notes_admins_list_nodes;
  
   if(ui_card!="")
   {
      notes_admins_list_nodes_str=ui_card;
   }
   
   var notes_admins_qret_fun="push_grid_result:notes_admins_tbl_list";
   
   if(push_fun!="")
   {
    notes_admins_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_notes_admins("*", ajaxw+" ("+gft_notes_admins(qstr)+") "+combined_query+"  order by primkey desc ", notes_admins_list_cols+additional_cols_str, "",notes_admins_qret_fun, "c=>"+notes_admins_list_nodes_str, notes_admins_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_notes_admins(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_notes_admins("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qnotes_admins_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_notes_admins("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_notes_admins("*", notes_admins_token_query, "primkey", "blackhole", notes_admins_push_ui_data_to, "");
    

}



//sum 

function sum_notes_admins(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_notes_admins("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function notes_admins_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "notes_admins_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function notes_admins_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "notes_admins_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function notes_admins_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletenotes_admins&notes_admins_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_notes_admins_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('notes_admins')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  notes_list Data ===============
    
      function get_notes_list(notes_list_colstr, notes_list_filter_col, notes_list_cols, notes_list_node_function_name, notes_list_callback_function_string, notes_list_ui_tag, notes_list_pagination)
      {
        mosyflex_sel("notes_list", notes_list_colstr, notes_list_filter_col , notes_list_cols, notes_list_node_function_name, notes_list_callback_function_string, notes_list_ui_tag, notes_list_pagination);
        
      }
    //End get  notes_list Data ===============

    //Start insert  notes_list Data ===============

	function add_notes_list(notes_list_cols, notes_list_vals, notes_list_callback_function_string)
    {
		
        mosyajax_create_data("notes_list", notes_list_cols, notes_list_vals, notes_list_callback_function_string);
     }
     
    //End insert  notes_list Data ===============

    
    //Start update  notes_list Data ===============

    function update_notes_list(notes_list_update_str, notes_list_where_str, notes_list_callback_function_string){
    
		mosyajax_update("notes_list", notes_list_update_str, notes_list_where_str, notes_list_callback_function_string)
    
    }
    //end  update  notes_list Data ===============

	//Start drop  notes_list Data ===============
    function notes_list_drop(notes_list_where_str, notes_list_callback_function_string)
    {
        mosyajax_drop("notes_list", notes_list_where_str, notes_list_callback_function_string)

    }
	//End drop  notes_list Data ===============
    
    function initialize_notes_list(qstr="", notes_list_callback_function_string="")
    {
    
    ///alert(qstr);
      var notes_list_token_query =qstr;
      if(qstr=="")
      {
       var notes_list_token_query_param="";
       var notes_list_js_uptoken=mosy_get_param("notes_list_uptoken");
       //alert(notes_list_js_uptoken);
       if(notes_list_js_uptoken!==undefined)
       {
       
        notes_list_token_query_param = atob(notes_list_js_uptoken);
       }
        notes_list_token_query = " where primkey='"+(notes_list_token_query_param)+"'";
        
           if (document.getElementById("notes_list_uptoken") !==null) {
           	if(document.getElementById("notes_list_uptoken").value!="")
            {
            
            var notes_list_atob_tbl_key =atob(document.getElementById("notes_list_uptoken").value);
            
                   
            notes_list_token_query = " where primkey='"+(notes_list_atob_tbl_key)+"'";

            }
           }
      }
      
      var notes_list_push_ui_data_to =notes_list_callback_function_string;
      if(notes_list_callback_function_string=="")
      {
      notes_list_push_ui_data_to = "add_notes_list_ui_data";
      }
                
      console.log(notes_list_token_query+" -- "+notes_list_js_uptoken);

	  //alert(notes_list_push_ui_data_to);

     get_notes_list("*", notes_list_token_query, "primkey", "blackhole", notes_list_push_ui_data_to, "");
    }
    
    function add_notes_list_ui_data(notes_list_server_resp) 
    {
    
    ///alert(notes_list_server_resp);
    
    var json_decoded_str=JSON.parse(notes_list_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load notes_list data on the fly ==============
    
	var gft_notes_list_str="(noteskey LIKE '%{{qnotes_list}}%' OR  note_title LIKE '%{{qnotes_list}}%' OR  note_details LIKE '%{{qnotes_list}}%' OR  note_date LIKE '%{{qnotes_list}}%' OR  note_tag LIKE '%{{qnotes_list}}%' OR  user_id LIKE '%{{qnotes_list}}%' OR  note_remark LIKE '%{{qnotes_list}}%' OR  note_media LIKE '%{{qnotes_list}}%')";
    
    function  gft_notes_list(qnotes_list_str)
    {
        	var clean_notes_list_filter_str=gft_notes_list_str.replace(/{{qnotes_list}}/g, magic_clean_str(qnotes_list_str));
            
            return  clean_notes_list_filter_str;

    }
    
    function load_notes_list(notes_list_qstr, notes_list_where_str, notes_list_ret_cols, notes_list_user_function, notes_list_result_function, notes_list_data_tray)
    {
    
    var fnotes_list_result_function="push_result";
      
    if(notes_list_result_function!="")
    {
          var fnotes_list_result_function=notes_list_result_function;

    }
    	var clean_notes_list_filter_str=gft_notes_list_str.replace(/{{qnotes_list}}/g, magic_clean_str(notes_list_qstr));
        
        var fnotes_list_where_str=" where "+clean_notes_list_filter_str;

    if(notes_list_where_str!="")
    {
          var fnotes_list_where_str=" "+notes_list_where_str;

    }
       
      get_notes_list("*", fnotes_list_where_str, notes_list_ret_cols, notes_list_user_function, fnotes_list_result_function, notes_list_data_tray);
      
    }
    ///=============== load notes_list data on the fly ==============


 ///=quick load 
 
function qkload_notes_list(qstr, push_fun="", ui_card="", and_query="", additional_cols="", notes_list_pagination="")
{

	var notes_list_list_nodes_str=notes_list_list_nodes;
  
   if(ui_card!="")
   {
      notes_list_list_nodes_str=ui_card;
   }
   
   var notes_list_qret_fun="push_grid_result:notes_list_tbl_list";
   
   if(push_fun!="")
   {
    notes_list_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_notes_list("*", ajaxw+" ("+gft_notes_list(qstr)+") "+combined_query+"  order by primkey desc ", notes_list_list_cols+additional_cols_str, "",notes_list_qret_fun, "c=>"+notes_list_list_nodes_str, notes_list_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_notes_list(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_notes_list("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qnotes_list_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_notes_list("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_notes_list("*", notes_list_token_query, "primkey", "blackhole", notes_list_push_ui_data_to, "");
    

}



//sum 

function sum_notes_list(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_notes_list("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function notes_list_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "notes_list_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function notes_list_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "notes_list_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function notes_list_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletenotes_list&notes_list_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_notes_list_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('notes_list')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  online_reception Data ===============
    
      function get_online_reception(online_reception_colstr, online_reception_filter_col, online_reception_cols, online_reception_node_function_name, online_reception_callback_function_string, online_reception_ui_tag, online_reception_pagination)
      {
        mosyflex_sel("online_reception", online_reception_colstr, online_reception_filter_col , online_reception_cols, online_reception_node_function_name, online_reception_callback_function_string, online_reception_ui_tag, online_reception_pagination);
        
      }
    //End get  online_reception Data ===============

    //Start insert  online_reception Data ===============

	function add_online_reception(online_reception_cols, online_reception_vals, online_reception_callback_function_string)
    {
		
        mosyajax_create_data("online_reception", online_reception_cols, online_reception_vals, online_reception_callback_function_string);
     }
     
    //End insert  online_reception Data ===============

    
    //Start update  online_reception Data ===============

    function update_online_reception(online_reception_update_str, online_reception_where_str, online_reception_callback_function_string){
    
		mosyajax_update("online_reception", online_reception_update_str, online_reception_where_str, online_reception_callback_function_string)
    
    }
    //end  update  online_reception Data ===============

	//Start drop  online_reception Data ===============
    function online_reception_drop(online_reception_where_str, online_reception_callback_function_string)
    {
        mosyajax_drop("online_reception", online_reception_where_str, online_reception_callback_function_string)

    }
	//End drop  online_reception Data ===============
    
    function initialize_online_reception(qstr="", online_reception_callback_function_string="")
    {
    
    ///alert(qstr);
      var online_reception_token_query =qstr;
      if(qstr=="")
      {
       var online_reception_token_query_param="";
       var online_reception_js_uptoken=mosy_get_param("online_reception_uptoken");
       //alert(online_reception_js_uptoken);
       if(online_reception_js_uptoken!==undefined)
       {
       
        online_reception_token_query_param = atob(online_reception_js_uptoken);
       }
        online_reception_token_query = " where primkey='"+(online_reception_token_query_param)+"'";
        
           if (document.getElementById("online_reception_uptoken") !==null) {
           	if(document.getElementById("online_reception_uptoken").value!="")
            {
            
            var online_reception_atob_tbl_key =atob(document.getElementById("online_reception_uptoken").value);
            
                   
            online_reception_token_query = " where primkey='"+(online_reception_atob_tbl_key)+"'";

            }
           }
      }
      
      var online_reception_push_ui_data_to =online_reception_callback_function_string;
      if(online_reception_callback_function_string=="")
      {
      online_reception_push_ui_data_to = "add_online_reception_ui_data";
      }
                
      console.log(online_reception_token_query+" -- "+online_reception_js_uptoken);

	  //alert(online_reception_push_ui_data_to);

     get_online_reception("*", online_reception_token_query, "primkey", "blackhole", online_reception_push_ui_data_to, "");
    }
    
    function add_online_reception_ui_data(online_reception_server_resp) 
    {
    
    ///alert(online_reception_server_resp);
    
    var json_decoded_str=JSON.parse(online_reception_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load online_reception data on the fly ==============
    
	var gft_online_reception_str="(reckey LIKE '%{{qonline_reception}}%' OR  page_logo LIKE '%{{qonline_reception}}%' OR  bg_image LIKE '%{{qonline_reception}}%' OR  page_name LIKE '%{{qonline_reception}}%' OR  btn_clr LIKE '%{{qonline_reception}}%' OR  btn_txt_clr LIKE '%{{qonline_reception}}%' OR  wild_clr LIKE '%{{qonline_reception}}%' OR  action_link LIKE '%{{qonline_reception}}%' OR  owner_id LIKE '%{{qonline_reception}}%' OR  page_descr LIKE '%{{qonline_reception}}%' OR  background_clr LIKE '%{{qonline_reception}}%' OR  background_text_clr LIKE '%{{qonline_reception}}%' OR  send_msg_title LIKE '%{{qonline_reception}}%' OR  send_btn_title LIKE '%{{qonline_reception}}%' OR  border_radius LIKE '%{{qonline_reception}}%' OR  navbar_clr LIKE '%{{qonline_reception}}%' OR  navbar_txt_clr LIKE '%{{qonline_reception}}%' OR  telephone_ LIKE '%{{qonline_reception}}%')";
    
    function  gft_online_reception(qonline_reception_str)
    {
        	var clean_online_reception_filter_str=gft_online_reception_str.replace(/{{qonline_reception}}/g, magic_clean_str(qonline_reception_str));
            
            return  clean_online_reception_filter_str;

    }
    
    function load_online_reception(online_reception_qstr, online_reception_where_str, online_reception_ret_cols, online_reception_user_function, online_reception_result_function, online_reception_data_tray)
    {
    
    var fonline_reception_result_function="push_result";
      
    if(online_reception_result_function!="")
    {
          var fonline_reception_result_function=online_reception_result_function;

    }
    	var clean_online_reception_filter_str=gft_online_reception_str.replace(/{{qonline_reception}}/g, magic_clean_str(online_reception_qstr));
        
        var fonline_reception_where_str=" where "+clean_online_reception_filter_str;

    if(online_reception_where_str!="")
    {
          var fonline_reception_where_str=" "+online_reception_where_str;

    }
       
      get_online_reception("*", fonline_reception_where_str, online_reception_ret_cols, online_reception_user_function, fonline_reception_result_function, online_reception_data_tray);
      
    }
    ///=============== load online_reception data on the fly ==============


 ///=quick load 
 
function qkload_online_reception(qstr, push_fun="", ui_card="", and_query="", additional_cols="", online_reception_pagination="")
{

	var online_reception_list_nodes_str=online_reception_list_nodes;
  
   if(ui_card!="")
   {
      online_reception_list_nodes_str=ui_card;
   }
   
   var online_reception_qret_fun="push_grid_result:online_reception_tbl_list";
   
   if(push_fun!="")
   {
    online_reception_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_online_reception("*", ajaxw+" ("+gft_online_reception(qstr)+") "+combined_query+"  order by primkey desc ", online_reception_list_cols+additional_cols_str, "",online_reception_qret_fun, "c=>"+online_reception_list_nodes_str, online_reception_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_online_reception(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_online_reception("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qonline_reception_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_online_reception("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_online_reception("*", online_reception_token_query, "primkey", "blackhole", online_reception_push_ui_data_to, "");
    

}



//sum 

function sum_online_reception(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_online_reception("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function online_reception_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "online_reception_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function online_reception_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "online_reception_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function online_reception_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteonline_reception&online_reception_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_online_reception_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('online_reception')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  page_links Data ===============
    
      function get_page_links(page_links_colstr, page_links_filter_col, page_links_cols, page_links_node_function_name, page_links_callback_function_string, page_links_ui_tag, page_links_pagination)
      {
        mosyflex_sel("page_links", page_links_colstr, page_links_filter_col , page_links_cols, page_links_node_function_name, page_links_callback_function_string, page_links_ui_tag, page_links_pagination);
        
      }
    //End get  page_links Data ===============

    //Start insert  page_links Data ===============

	function add_page_links(page_links_cols, page_links_vals, page_links_callback_function_string)
    {
		
        mosyajax_create_data("page_links", page_links_cols, page_links_vals, page_links_callback_function_string);
     }
     
    //End insert  page_links Data ===============

    
    //Start update  page_links Data ===============

    function update_page_links(page_links_update_str, page_links_where_str, page_links_callback_function_string){
    
		mosyajax_update("page_links", page_links_update_str, page_links_where_str, page_links_callback_function_string)
    
    }
    //end  update  page_links Data ===============

	//Start drop  page_links Data ===============
    function page_links_drop(page_links_where_str, page_links_callback_function_string)
    {
        mosyajax_drop("page_links", page_links_where_str, page_links_callback_function_string)

    }
	//End drop  page_links Data ===============
    
    function initialize_page_links(qstr="", page_links_callback_function_string="")
    {
    
    ///alert(qstr);
      var page_links_token_query =qstr;
      if(qstr=="")
      {
       var page_links_token_query_param="";
       var page_links_js_uptoken=mosy_get_param("page_links_uptoken");
       //alert(page_links_js_uptoken);
       if(page_links_js_uptoken!==undefined)
       {
       
        page_links_token_query_param = atob(page_links_js_uptoken);
       }
        page_links_token_query = " where primkey='"+(page_links_token_query_param)+"'";
        
           if (document.getElementById("page_links_uptoken") !==null) {
           	if(document.getElementById("page_links_uptoken").value!="")
            {
            
            var page_links_atob_tbl_key =atob(document.getElementById("page_links_uptoken").value);
            
                   
            page_links_token_query = " where primkey='"+(page_links_atob_tbl_key)+"'";

            }
           }
      }
      
      var page_links_push_ui_data_to =page_links_callback_function_string;
      if(page_links_callback_function_string=="")
      {
      page_links_push_ui_data_to = "add_page_links_ui_data";
      }
                
      console.log(page_links_token_query+" -- "+page_links_js_uptoken);

	  //alert(page_links_push_ui_data_to);

     get_page_links("*", page_links_token_query, "primkey", "blackhole", page_links_push_ui_data_to, "");
    }
    
    function add_page_links_ui_data(page_links_server_resp) 
    {
    
    ///alert(page_links_server_resp);
    
    var json_decoded_str=JSON.parse(page_links_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load page_links data on the fly ==============
    
	var gft_page_links_str="(link_id LIKE '%{{qpage_links}}%' OR  link_name LIKE '%{{qpage_links}}%' OR  linkurl LIKE '%{{qpage_links}}%' OR  descr LIKE '%{{qpage_links}}%' OR  signature LIKE '%{{qpage_links}}%' OR  admin_id LIKE '%{{qpage_links}}%')";
    
    function  gft_page_links(qpage_links_str)
    {
        	var clean_page_links_filter_str=gft_page_links_str.replace(/{{qpage_links}}/g, magic_clean_str(qpage_links_str));
            
            return  clean_page_links_filter_str;

    }
    
    function load_page_links(page_links_qstr, page_links_where_str, page_links_ret_cols, page_links_user_function, page_links_result_function, page_links_data_tray)
    {
    
    var fpage_links_result_function="push_result";
      
    if(page_links_result_function!="")
    {
          var fpage_links_result_function=page_links_result_function;

    }
    	var clean_page_links_filter_str=gft_page_links_str.replace(/{{qpage_links}}/g, magic_clean_str(page_links_qstr));
        
        var fpage_links_where_str=" where "+clean_page_links_filter_str;

    if(page_links_where_str!="")
    {
          var fpage_links_where_str=" "+page_links_where_str;

    }
       
      get_page_links("*", fpage_links_where_str, page_links_ret_cols, page_links_user_function, fpage_links_result_function, page_links_data_tray);
      
    }
    ///=============== load page_links data on the fly ==============


 ///=quick load 
 
function qkload_page_links(qstr, push_fun="", ui_card="", and_query="", additional_cols="", page_links_pagination="")
{

	var page_links_list_nodes_str=page_links_list_nodes;
  
   if(ui_card!="")
   {
      page_links_list_nodes_str=ui_card;
   }
   
   var page_links_qret_fun="push_grid_result:page_links_tbl_list";
   
   if(push_fun!="")
   {
    page_links_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_page_links("*", ajaxw+" ("+gft_page_links(qstr)+") "+combined_query+"  order by primkey desc ", page_links_list_cols+additional_cols_str, "",page_links_qret_fun, "c=>"+page_links_list_nodes_str, page_links_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_page_links(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_page_links("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qpage_links_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_page_links("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_page_links("*", page_links_token_query, "primkey", "blackhole", page_links_push_ui_data_to, "");
    

}



//sum 

function sum_page_links(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_page_links("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function page_links_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "page_links_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function page_links_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "page_links_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function page_links_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletepage_links&page_links_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_page_links_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('page_links')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  posting_log Data ===============
    
      function get_posting_log(posting_log_colstr, posting_log_filter_col, posting_log_cols, posting_log_node_function_name, posting_log_callback_function_string, posting_log_ui_tag, posting_log_pagination)
      {
        mosyflex_sel("posting_log", posting_log_colstr, posting_log_filter_col , posting_log_cols, posting_log_node_function_name, posting_log_callback_function_string, posting_log_ui_tag, posting_log_pagination);
        
      }
    //End get  posting_log Data ===============

    //Start insert  posting_log Data ===============

	function add_posting_log(posting_log_cols, posting_log_vals, posting_log_callback_function_string)
    {
		
        mosyajax_create_data("posting_log", posting_log_cols, posting_log_vals, posting_log_callback_function_string);
     }
     
    //End insert  posting_log Data ===============

    
    //Start update  posting_log Data ===============

    function update_posting_log(posting_log_update_str, posting_log_where_str, posting_log_callback_function_string){
    
		mosyajax_update("posting_log", posting_log_update_str, posting_log_where_str, posting_log_callback_function_string)
    
    }
    //end  update  posting_log Data ===============

	//Start drop  posting_log Data ===============
    function posting_log_drop(posting_log_where_str, posting_log_callback_function_string)
    {
        mosyajax_drop("posting_log", posting_log_where_str, posting_log_callback_function_string)

    }
	//End drop  posting_log Data ===============
    
    function initialize_posting_log(qstr="", posting_log_callback_function_string="")
    {
    
    ///alert(qstr);
      var posting_log_token_query =qstr;
      if(qstr=="")
      {
       var posting_log_token_query_param="";
       var posting_log_js_uptoken=mosy_get_param("posting_log_uptoken");
       //alert(posting_log_js_uptoken);
       if(posting_log_js_uptoken!==undefined)
       {
       
        posting_log_token_query_param = atob(posting_log_js_uptoken);
       }
        posting_log_token_query = " where primkey='"+(posting_log_token_query_param)+"'";
        
           if (document.getElementById("posting_log_uptoken") !==null) {
           	if(document.getElementById("posting_log_uptoken").value!="")
            {
            
            var posting_log_atob_tbl_key =atob(document.getElementById("posting_log_uptoken").value);
            
                   
            posting_log_token_query = " where primkey='"+(posting_log_atob_tbl_key)+"'";

            }
           }
      }
      
      var posting_log_push_ui_data_to =posting_log_callback_function_string;
      if(posting_log_callback_function_string=="")
      {
      posting_log_push_ui_data_to = "add_posting_log_ui_data";
      }
                
      console.log(posting_log_token_query+" -- "+posting_log_js_uptoken);

	  //alert(posting_log_push_ui_data_to);

     get_posting_log("*", posting_log_token_query, "primkey", "blackhole", posting_log_push_ui_data_to, "");
    }
    
    function add_posting_log_ui_data(posting_log_server_resp) 
    {
    
    ///alert(posting_log_server_resp);
    
    var json_decoded_str=JSON.parse(posting_log_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load posting_log data on the fly ==============
    
	var gft_posting_log_str="(postkey LIKE '%{{qposting_log}}%' OR  admin_id LIKE '%{{qposting_log}}%' OR  marketid LIKE '%{{qposting_log}}%' OR  post_id LIKE '%{{qposting_log}}%' OR  ref_id LIKE '%{{qposting_log}}%' OR  request_date LIKE '%{{qposting_log}}%')";
    
    function  gft_posting_log(qposting_log_str)
    {
        	var clean_posting_log_filter_str=gft_posting_log_str.replace(/{{qposting_log}}/g, magic_clean_str(qposting_log_str));
            
            return  clean_posting_log_filter_str;

    }
    
    function load_posting_log(posting_log_qstr, posting_log_where_str, posting_log_ret_cols, posting_log_user_function, posting_log_result_function, posting_log_data_tray)
    {
    
    var fposting_log_result_function="push_result";
      
    if(posting_log_result_function!="")
    {
          var fposting_log_result_function=posting_log_result_function;

    }
    	var clean_posting_log_filter_str=gft_posting_log_str.replace(/{{qposting_log}}/g, magic_clean_str(posting_log_qstr));
        
        var fposting_log_where_str=" where "+clean_posting_log_filter_str;

    if(posting_log_where_str!="")
    {
          var fposting_log_where_str=" "+posting_log_where_str;

    }
       
      get_posting_log("*", fposting_log_where_str, posting_log_ret_cols, posting_log_user_function, fposting_log_result_function, posting_log_data_tray);
      
    }
    ///=============== load posting_log data on the fly ==============


 ///=quick load 
 
function qkload_posting_log(qstr, push_fun="", ui_card="", and_query="", additional_cols="", posting_log_pagination="")
{

	var posting_log_list_nodes_str=posting_log_list_nodes;
  
   if(ui_card!="")
   {
      posting_log_list_nodes_str=ui_card;
   }
   
   var posting_log_qret_fun="push_grid_result:posting_log_tbl_list";
   
   if(push_fun!="")
   {
    posting_log_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_posting_log("*", ajaxw+" ("+gft_posting_log(qstr)+") "+combined_query+"  order by primkey desc ", posting_log_list_cols+additional_cols_str, "",posting_log_qret_fun, "c=>"+posting_log_list_nodes_str, posting_log_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_posting_log(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_posting_log("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qposting_log_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_posting_log("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_posting_log("*", posting_log_token_query, "primkey", "blackhole", posting_log_push_ui_data_to, "");
    

}



//sum 

function sum_posting_log(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_posting_log("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function posting_log_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "posting_log_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function posting_log_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "posting_log_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function posting_log_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteposting_log&posting_log_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_posting_log_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('posting_log')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  posts Data ===============
    
      function get_posts(posts_colstr, posts_filter_col, posts_cols, posts_node_function_name, posts_callback_function_string, posts_ui_tag, posts_pagination)
      {
        mosyflex_sel("posts", posts_colstr, posts_filter_col , posts_cols, posts_node_function_name, posts_callback_function_string, posts_ui_tag, posts_pagination);
        
      }
    //End get  posts Data ===============

    //Start insert  posts Data ===============

	function add_posts(posts_cols, posts_vals, posts_callback_function_string)
    {
		
        mosyajax_create_data("posts", posts_cols, posts_vals, posts_callback_function_string);
     }
     
    //End insert  posts Data ===============

    
    //Start update  posts Data ===============

    function update_posts(posts_update_str, posts_where_str, posts_callback_function_string){
    
		mosyajax_update("posts", posts_update_str, posts_where_str, posts_callback_function_string)
    
    }
    //end  update  posts Data ===============

	//Start drop  posts Data ===============
    function posts_drop(posts_where_str, posts_callback_function_string)
    {
        mosyajax_drop("posts", posts_where_str, posts_callback_function_string)

    }
	//End drop  posts Data ===============
    
    function initialize_posts(qstr="", posts_callback_function_string="")
    {
    
    ///alert(qstr);
      var posts_token_query =qstr;
      if(qstr=="")
      {
       var posts_token_query_param="";
       var posts_js_uptoken=mosy_get_param("posts_uptoken");
       //alert(posts_js_uptoken);
       if(posts_js_uptoken!==undefined)
       {
       
        posts_token_query_param = atob(posts_js_uptoken);
       }
        posts_token_query = " where primkey='"+(posts_token_query_param)+"'";
        
           if (document.getElementById("posts_uptoken") !==null) {
           	if(document.getElementById("posts_uptoken").value!="")
            {
            
            var posts_atob_tbl_key =atob(document.getElementById("posts_uptoken").value);
            
                   
            posts_token_query = " where primkey='"+(posts_atob_tbl_key)+"'";

            }
           }
      }
      
      var posts_push_ui_data_to =posts_callback_function_string;
      if(posts_callback_function_string=="")
      {
      posts_push_ui_data_to = "add_posts_ui_data";
      }
                
      console.log(posts_token_query+" -- "+posts_js_uptoken);

	  //alert(posts_push_ui_data_to);

     get_posts("*", posts_token_query, "primkey", "blackhole", posts_push_ui_data_to, "");
    }
    
    function add_posts_ui_data(posts_server_resp) 
    {
    
    ///alert(posts_server_resp);
    
    var json_decoded_str=JSON.parse(posts_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load posts data on the fly ==============
    
	var gft_posts_str="(msgid LIKE '%{{qposts}}%' OR  msg_titile LIKE '%{{qposts}}%' OR  msgposted LIKE '%{{qposts}}%' OR  run_at LIKE '%{{qposts}}%' OR  page LIKE '%{{qposts}}%' OR  link LIKE '%{{qposts}}%' OR  details LIKE '%{{qposts}}%' OR  post_response LIKE '%{{qposts}}%' OR  signature LIKE '%{{qposts}}%' OR  tweeted LIKE '%{{qposts}}%' OR  admin_id LIKE '%{{qposts}}%' OR  post_image LIKE '%{{qposts}}%' OR  sharable_link LIKE '%{{qposts}}%')";
    
    function  gft_posts(qposts_str)
    {
        	var clean_posts_filter_str=gft_posts_str.replace(/{{qposts}}/g, magic_clean_str(qposts_str));
            
            return  clean_posts_filter_str;

    }
    
    function load_posts(posts_qstr, posts_where_str, posts_ret_cols, posts_user_function, posts_result_function, posts_data_tray)
    {
    
    var fposts_result_function="push_result";
      
    if(posts_result_function!="")
    {
          var fposts_result_function=posts_result_function;

    }
    	var clean_posts_filter_str=gft_posts_str.replace(/{{qposts}}/g, magic_clean_str(posts_qstr));
        
        var fposts_where_str=" where "+clean_posts_filter_str;

    if(posts_where_str!="")
    {
          var fposts_where_str=" "+posts_where_str;

    }
       
      get_posts("*", fposts_where_str, posts_ret_cols, posts_user_function, fposts_result_function, posts_data_tray);
      
    }
    ///=============== load posts data on the fly ==============


 ///=quick load 
 
function qkload_posts(qstr, push_fun="", ui_card="", and_query="", additional_cols="", posts_pagination="")
{

	var posts_list_nodes_str=posts_list_nodes;
  
   if(ui_card!="")
   {
      posts_list_nodes_str=ui_card;
   }
   
   var posts_qret_fun="push_grid_result:posts_tbl_list";
   
   if(push_fun!="")
   {
    posts_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_posts("*", ajaxw+" ("+gft_posts(qstr)+") "+combined_query+"  order by primkey desc ", posts_list_cols+additional_cols_str, "",posts_qret_fun, "c=>"+posts_list_nodes_str, posts_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_posts(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_posts("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qposts_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_posts("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_posts("*", posts_token_query, "primkey", "blackhole", posts_push_ui_data_to, "");
    

}



//sum 

function sum_posts(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_posts("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function posts_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "posts_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function posts_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "posts_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function posts_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteposts&posts_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_posts_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('posts')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  task_manager Data ===============
    
      function get_task_manager(task_manager_colstr, task_manager_filter_col, task_manager_cols, task_manager_node_function_name, task_manager_callback_function_string, task_manager_ui_tag, task_manager_pagination)
      {
        mosyflex_sel("task_manager", task_manager_colstr, task_manager_filter_col , task_manager_cols, task_manager_node_function_name, task_manager_callback_function_string, task_manager_ui_tag, task_manager_pagination);
        
      }
    //End get  task_manager Data ===============

    //Start insert  task_manager Data ===============

	function add_task_manager(task_manager_cols, task_manager_vals, task_manager_callback_function_string)
    {
		
        mosyajax_create_data("task_manager", task_manager_cols, task_manager_vals, task_manager_callback_function_string);
     }
     
    //End insert  task_manager Data ===============

    
    //Start update  task_manager Data ===============

    function update_task_manager(task_manager_update_str, task_manager_where_str, task_manager_callback_function_string){
    
		mosyajax_update("task_manager", task_manager_update_str, task_manager_where_str, task_manager_callback_function_string)
    
    }
    //end  update  task_manager Data ===============

	//Start drop  task_manager Data ===============
    function task_manager_drop(task_manager_where_str, task_manager_callback_function_string)
    {
        mosyajax_drop("task_manager", task_manager_where_str, task_manager_callback_function_string)

    }
	//End drop  task_manager Data ===============
    
    function initialize_task_manager(qstr="", task_manager_callback_function_string="")
    {
    
    ///alert(qstr);
      var task_manager_token_query =qstr;
      if(qstr=="")
      {
       var task_manager_token_query_param="";
       var task_manager_js_uptoken=mosy_get_param("task_manager_uptoken");
       //alert(task_manager_js_uptoken);
       if(task_manager_js_uptoken!==undefined)
       {
       
        task_manager_token_query_param = atob(task_manager_js_uptoken);
       }
        task_manager_token_query = " where primkey='"+(task_manager_token_query_param)+"'";
        
           if (document.getElementById("task_manager_uptoken") !==null) {
           	if(document.getElementById("task_manager_uptoken").value!="")
            {
            
            var task_manager_atob_tbl_key =atob(document.getElementById("task_manager_uptoken").value);
            
                   
            task_manager_token_query = " where primkey='"+(task_manager_atob_tbl_key)+"'";

            }
           }
      }
      
      var task_manager_push_ui_data_to =task_manager_callback_function_string;
      if(task_manager_callback_function_string=="")
      {
      task_manager_push_ui_data_to = "add_task_manager_ui_data";
      }
                
      console.log(task_manager_token_query+" -- "+task_manager_js_uptoken);

	  //alert(task_manager_push_ui_data_to);

     get_task_manager("*", task_manager_token_query, "primkey", "blackhole", task_manager_push_ui_data_to, "");
    }
    
    function add_task_manager_ui_data(task_manager_server_resp) 
    {
    
    ///alert(task_manager_server_resp);
    
    var json_decoded_str=JSON.parse(task_manager_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load task_manager data on the fly ==============
    
	var gft_task_manager_str="(task_id LIKE '%{{qtask_manager}}%' OR  project_id LIKE '%{{qtask_manager}}%' OR  task_name LIKE '%{{qtask_manager}}%' OR  task_status LIKE '%{{qtask_manager}}%' OR  task_date LIKE '%{{qtask_manager}}%' OR  task_remark LIKE '%{{qtask_manager}}%' OR  test_column LIKE '%{{qtask_manager}}%' OR  assigned_to LIKE '%{{qtask_manager}}%' OR  task_comments LIKE '%{{qtask_manager}}%' OR  admin_remark LIKE '%{{qtask_manager}}%')";
    
    function  gft_task_manager(qtask_manager_str)
    {
        	var clean_task_manager_filter_str=gft_task_manager_str.replace(/{{qtask_manager}}/g, magic_clean_str(qtask_manager_str));
            
            return  clean_task_manager_filter_str;

    }
    
    function load_task_manager(task_manager_qstr, task_manager_where_str, task_manager_ret_cols, task_manager_user_function, task_manager_result_function, task_manager_data_tray)
    {
    
    var ftask_manager_result_function="push_result";
      
    if(task_manager_result_function!="")
    {
          var ftask_manager_result_function=task_manager_result_function;

    }
    	var clean_task_manager_filter_str=gft_task_manager_str.replace(/{{qtask_manager}}/g, magic_clean_str(task_manager_qstr));
        
        var ftask_manager_where_str=" where "+clean_task_manager_filter_str;

    if(task_manager_where_str!="")
    {
          var ftask_manager_where_str=" "+task_manager_where_str;

    }
       
      get_task_manager("*", ftask_manager_where_str, task_manager_ret_cols, task_manager_user_function, ftask_manager_result_function, task_manager_data_tray);
      
    }
    ///=============== load task_manager data on the fly ==============


 ///=quick load 
 
function qkload_task_manager(qstr, push_fun="", ui_card="", and_query="", additional_cols="", task_manager_pagination="")
{

	var task_manager_list_nodes_str=task_manager_list_nodes;
  
   if(ui_card!="")
   {
      task_manager_list_nodes_str=ui_card;
   }
   
   var task_manager_qret_fun="push_grid_result:task_manager_tbl_list";
   
   if(push_fun!="")
   {
    task_manager_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_task_manager("*", ajaxw+" ("+gft_task_manager(qstr)+") "+combined_query+"  order by primkey desc ", task_manager_list_cols+additional_cols_str, "",task_manager_qret_fun, "c=>"+task_manager_list_nodes_str, task_manager_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_task_manager(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_task_manager("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qtask_manager_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_task_manager("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_task_manager("*", task_manager_token_query, "primkey", "blackhole", task_manager_push_ui_data_to, "");
    

}



//sum 

function sum_task_manager(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_task_manager("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function task_manager_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "task_manager_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function task_manager_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "task_manager_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function task_manager_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletetask_manager&task_manager_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_task_manager_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('task_manager')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
   

    //Start get  traffic_log Data ===============
    
      function get_traffic_log(traffic_log_colstr, traffic_log_filter_col, traffic_log_cols, traffic_log_node_function_name, traffic_log_callback_function_string, traffic_log_ui_tag, traffic_log_pagination)
      {
        mosyflex_sel("traffic_log", traffic_log_colstr, traffic_log_filter_col , traffic_log_cols, traffic_log_node_function_name, traffic_log_callback_function_string, traffic_log_ui_tag, traffic_log_pagination);
        
      }
    //End get  traffic_log Data ===============

    //Start insert  traffic_log Data ===============

	function add_traffic_log(traffic_log_cols, traffic_log_vals, traffic_log_callback_function_string)
    {
		
        mosyajax_create_data("traffic_log", traffic_log_cols, traffic_log_vals, traffic_log_callback_function_string);
     }
     
    //End insert  traffic_log Data ===============

    
    //Start update  traffic_log Data ===============

    function update_traffic_log(traffic_log_update_str, traffic_log_where_str, traffic_log_callback_function_string){
    
		mosyajax_update("traffic_log", traffic_log_update_str, traffic_log_where_str, traffic_log_callback_function_string)
    
    }
    //end  update  traffic_log Data ===============

	//Start drop  traffic_log Data ===============
    function traffic_log_drop(traffic_log_where_str, traffic_log_callback_function_string)
    {
        mosyajax_drop("traffic_log", traffic_log_where_str, traffic_log_callback_function_string)

    }
	//End drop  traffic_log Data ===============
    
    function initialize_traffic_log(qstr="", traffic_log_callback_function_string="")
    {
    
    ///alert(qstr);
      var traffic_log_token_query =qstr;
      if(qstr=="")
      {
       var traffic_log_token_query_param="";
       var traffic_log_js_uptoken=mosy_get_param("traffic_log_uptoken");
       //alert(traffic_log_js_uptoken);
       if(traffic_log_js_uptoken!==undefined)
       {
       
        traffic_log_token_query_param = atob(traffic_log_js_uptoken);
       }
        traffic_log_token_query = " where primkey='"+(traffic_log_token_query_param)+"'";
        
           if (document.getElementById("traffic_log_uptoken") !==null) {
           	if(document.getElementById("traffic_log_uptoken").value!="")
            {
            
            var traffic_log_atob_tbl_key =atob(document.getElementById("traffic_log_uptoken").value);
            
                   
            traffic_log_token_query = " where primkey='"+(traffic_log_atob_tbl_key)+"'";

            }
           }
      }
      
      var traffic_log_push_ui_data_to =traffic_log_callback_function_string;
      if(traffic_log_callback_function_string=="")
      {
      traffic_log_push_ui_data_to = "add_traffic_log_ui_data";
      }
                
      console.log(traffic_log_token_query+" -- "+traffic_log_js_uptoken);

	  //alert(traffic_log_push_ui_data_to);

     get_traffic_log("*", traffic_log_token_query, "primkey", "blackhole", traffic_log_push_ui_data_to, "");
    }
    
    function add_traffic_log_ui_data(traffic_log_server_resp) 
    {
    
    ///alert(traffic_log_server_resp);
    
    var json_decoded_str=JSON.parse(traffic_log_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load traffic_log data on the fly ==============
    
	var gft_traffic_log_str="(schedule_id LIKE '%{{qtraffic_log}}%' OR  campaign_id LIKE '%{{qtraffic_log}}%' OR  channel_node LIKE '%{{qtraffic_log}}%' OR  visit_time LIKE '%{{qtraffic_log}}%' OR  visit_date LIKE '%{{qtraffic_log}}%' OR  visitor_name LIKE '%{{qtraffic_log}}%' OR  page_visited LIKE '%{{qtraffic_log}}%' OR  page_url LIKE '%{{qtraffic_log}}%' OR  admin_id LIKE '%{{qtraffic_log}}%' OR  source_url LIKE '%{{qtraffic_log}}%' OR  month_year LIKE '%{{qtraffic_log}}%' OR  ip_address LIKE '%{{qtraffic_log}}%' OR  comment LIKE '%{{qtraffic_log}}%' OR  source_page LIKE '%{{qtraffic_log}}%' OR  time_stamp LIKE '%{{qtraffic_log}}%' OR  user_id LIKE '%{{qtraffic_log}}%' OR  log_data LIKE '%{{qtraffic_log}}%' OR  device LIKE '%{{qtraffic_log}}%' OR  browser LIKE '%{{qtraffic_log}}%')";
    
    function  gft_traffic_log(qtraffic_log_str)
    {
        	var clean_traffic_log_filter_str=gft_traffic_log_str.replace(/{{qtraffic_log}}/g, magic_clean_str(qtraffic_log_str));
            
            return  clean_traffic_log_filter_str;

    }
    
    function load_traffic_log(traffic_log_qstr, traffic_log_where_str, traffic_log_ret_cols, traffic_log_user_function, traffic_log_result_function, traffic_log_data_tray)
    {
    
    var ftraffic_log_result_function="push_result";
      
    if(traffic_log_result_function!="")
    {
          var ftraffic_log_result_function=traffic_log_result_function;

    }
    	var clean_traffic_log_filter_str=gft_traffic_log_str.replace(/{{qtraffic_log}}/g, magic_clean_str(traffic_log_qstr));
        
        var ftraffic_log_where_str=" where "+clean_traffic_log_filter_str;

    if(traffic_log_where_str!="")
    {
          var ftraffic_log_where_str=" "+traffic_log_where_str;

    }
       
      get_traffic_log("*", ftraffic_log_where_str, traffic_log_ret_cols, traffic_log_user_function, ftraffic_log_result_function, traffic_log_data_tray);
      
    }
    ///=============== load traffic_log data on the fly ==============


 ///=quick load 
 
function qkload_traffic_log(qstr, push_fun="", ui_card="", and_query="", additional_cols="", traffic_log_pagination="")
{

	var traffic_log_list_nodes_str=traffic_log_list_nodes;
  
   if(ui_card!="")
   {
      traffic_log_list_nodes_str=ui_card;
   }
   
   var traffic_log_qret_fun="push_grid_result:traffic_log_tbl_list";
   
   if(push_fun!="")
   {
    traffic_log_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_traffic_log("*", ajaxw+" ("+gft_traffic_log(qstr)+") "+combined_query+"  order by primkey desc ", traffic_log_list_cols+additional_cols_str, "",traffic_log_qret_fun, "c=>"+traffic_log_list_nodes_str, traffic_log_pagination);
                  
}


////////////// arithmetic function 


//count 

function count_traffic_log(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_traffic_log("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qtraffic_log_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_traffic_log("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_traffic_log("*", traffic_log_token_query, "primkey", "blackhole", traffic_log_push_ui_data_to, "");
    

}



//sum 

function sum_traffic_log(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
      
   get_traffic_log("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function traffic_log_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "traffic_log_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function traffic_log_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "traffic_log_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function traffic_log_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletetraffic_log&traffic_log_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


function grid_traffic_log_updt_(updt_key,colstr,newcolval, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get("_grid_updt_="+btoa('traffic_log')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str);

}
  //===============End Mosy queries-============

const mosy_msdn_elem = document.querySelectorAll('.mosy_msdn');

mosy_msdn_elem.forEach(el => el.addEventListener('click', event => {

var arguments = event.target.getAttribute("data-mosy_msdn");
  
eval(arguments);

}));

const mosy_tup_elem = document.querySelectorAll('.mosy_tup');

mosy_tup_elem.forEach(el => el.addEventListener('keyup', event => {

var arguments = event.target.getAttribute("data-mosy_tup");
  
eval(arguments);

}));
  
var ajax_url ="./treng/ajaxreqhandler.php";
var mosyajax_sql_url=ajax_url;
   //Ajax Manager
function mosyflex_sel(tbl, colstr, filter_col , cols, node_function_name, callback_function_string, ui_tag, pagination="")
{
//alert(filter_col);
///alert(pagination);

    var clean_ui1=ui_tag.replace(/</g, "{{<}}");
    var clean_ui2=clean_ui1.replace(/>/g, "{{>}}");
    var clean_ui3=clean_ui2.replace(/onclick/g, "{{on click}}");
    var clean_ui4=clean_ui3.replace(/onkeyup/g, "{{on keyup}}");
    var clean_ui=clean_ui4.replace(/onchange/g, "{{on change}}");
    
  	var pagination_token=1;
    var pagination_name=pagination;
    
    if(pagination.indexOf(":") >= 0)
  	{
      pagination_token_expl=pagination.split(":");
      pagination_token=pagination_token_expl[1];
      pagination_name=pagination_token_expl[0];
    }
    
  
    var json_params_str={"mosyajax_sql_data":filter_col, "colstr":colstr, "cols":cols, "node_function_name":node_function_name, "tbl":tbl, "ui_tag":clean_ui,"pagination":pagination_name};
   
  	//alert(clean_ui);
  
  //alert(pagination_name);
  //alert(pagination_token);
  
    if(pagination_token>1)
    {
		mosy_ajax_post(ajax_url+"?"+pagination_name+"="+btoa(pagination_token), json_params_str, callback_function_string, "");
    }else{
		mosy_ajax_post(ajax_url, json_params_str, callback_function_string, "");

    }
}


function mosy_next_page(elem_id)
{
  if(get_newval(elem_id)=="")
  {
  	push_newval(elem_id,0)
  }
  var next_token_no=parseInt(get_newval(elem_id))+1;
  
  push_newval(elem_id, next_token_no);
  
  return next_token_no;
}

function mosy_prev_page(elem_id)
{
  if(get_newval(elem_id)=="")
  {
  	push_newval(elem_id,0)
  }
  var next_token_no=parseInt(get_newval(elem_id))-1;
  
  if(next_token_no<=0)
  {
  next_token_no=1;
  }
  
  push_newval(elem_id, next_token_no);
  
  return next_token_no;
}

function push_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp+'<div class="col-md-12 p-0 text-right"><span class="badge cpointer" style="font-size:10px;"><i class="fa fa-times-circle"></i> Close</span></div>';
  
  if(server_resp.toString().trim()=='')
  {
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray"> <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
  }
  
  
  if (document.getElementById(additional_callbacks) !==null) {
        
  document.getElementById(additional_callbacks).style.display="block";
  document.getElementById(additional_callbacks).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}



function push_grid_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp;
  
  var tbl_col_str="";
  var tbl_colspan ="";
  var elem_id=additional_callbacks;

  var empty_state_str="";
  
  if(additional_callbacks.indexOf(":") >= 0)
  {
     tbl_col_str=additional_callbacks.split(":");
     
     tbl_colspan=tbl_col_str[1];
     
     elem_id=tbl_col_str[0];

	if(typeof tbl_col_str[2] !== 'undefined') 
    {
     var empty_state_str = tbl_col_str[2];
    }

  }
///alert(additional_callbacks);
  if(server_resp.toString().trim()=='')
  {
  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid" > <td colspan="'+tbl_colspan+'" style="text-align:center;"><div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div></td> </tr>';
    if(empty_state_str!="")
    {
    var str_to_display =window[empty_state_str];
    
    }
    }else{
        
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
    
    if(empty_state_str!="")
    {
    var str_to_display =window[empty_state_str];
    
    }
    }
  }
  
  
  if (document.getElementById(elem_id) !==null) {
        
  ///document.getElementById(elem_id).style.display="block";
  document.getElementById(elem_id).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}

function mosy_empty_state(top_msg="", btm_msg="", tbl_colspan="")
{

    var str_to_display="";

  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid " > <td colspan="'+tbl_colspan+'" style="text-align:center;">'+top_msg+'<hr><div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"> '+btm_msg+'</div></td> </tr>';
 
    }else{
        
  	 str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12">'+top_msg+'<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"> '+btm_msg+'</div> </div>';
    
 
    }


///alert(str_to_display);

  return str_to_display;

}


function push_val(arrkeys, arrvalues)
{
    var r = {},i;
    
    for (let i = 0; i < arrkeys.length; i++) {
        r[arrkeys[i]] = arrvalues[i];
      document.getElementById(arrvalues[i]).value=[arrkeys[i]];
    }

}

    function qddata(server_resp,callbacks)
    {
    //alert(server_resp);
    var retjson = JSON.parse(server_resp)[0];
    
        ///alert(retjson.name);


    return retjson;
    
    
    }
function mosy_ajax_post(post_url, json_params, callback_function_string, additional_callbacks)
{


	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
         split_fun_str=callback_function_string.split(/:(.*)/s);
         
		 fcall_back_function =  split_fun_str[0];
        
         fadditional_callbacks =  split_fun_str[1] ;
    
    }
    
    if (document.getElementById(fadditional_callbacks) !==null) {
      ////  document.getElementById(fadditional_callbacks).style.display="block";
    	///document.getElementById(fadditional_callbacks).innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... '+document.getElementById(fadditional_callbacks).innerHTML;
        
    }
    
       if (document.getElementById("ajax_spinner") !==null) 
       {
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';

       }else{
       	mosy_snack_wgt("Processing request...", "top", "ajax_snack", "200px", "ajax_snack_id", "#000",  "#fff", "");
    
    	mosytoggle_class("ajax_snack_id", "show");
        
       }
       
       
  	var formData = ((json_params)); //Array 
  
      $.ajax({ 
      url: post_url,
      type: "POST",
      data:formData,

      success: function (data) 
      {
        //alert(data);
       if (document.getElementById("ajax_spinner") !==null) 
       {
       
         var result_response_='<i class="fa fa-info-circle"></i> Request Processed Succesfully.';
		
        	if(data=='')
            {
            
        		var result_response_='<i class="fa fa-info-circle"></i> No data .';
            
            }
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML=result_response_;

       } 
       
       push_html("ajax_snack", "");                                          

        window[fcall_back_function](data, fadditional_callbacks);

      }

  })
  
}  


   //Ajax Manager

function mosyajax_create_data(tbl, tbl_cols, tbl_vals, callback_function_string)
{
  ///alert(tbl_cols+" - "+tbl_vals);
  
    var json_params_str={"mosyajax_create":"ok", "tbl_cols":tbl_cols, "tbl_vals":tbl_vals, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

   //Ajax Exe
function mosyajax_update(tbl, update_str, where_str, callback_function_string)
{
  //alert(update_str);
  
    var json_params_str={"mosyajax_update":"ok", "update_str":update_str, "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

function mosyajax_drop(tbl, where_str, callback_function_string)
{
  //alert(where_str);
  
    var json_params_str={"mosyajax_drop":"ok", "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}


function mosyajax_get(getstr, callback_function_string)
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = "";
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
    if (document.getElementById("ajax_spinner") !==null) 
    {
        
      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

  	}

    $.ajax({
      url: ajax_url+"?"+getstr,
      type: 'GET',
      success: function(res) {
       if (document.getElementById("ajax_spinner") !==null) {

          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

       }              
            //alert(res);
        window[fcall_back_function](res, fadditional_callbacks);

          }
      });
}


function mosy_validate_required(required_inp=null)
{
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+"</b><br>";
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, "False")=="False")
      {
      
       var required_state="False";
      
      }else{
      
      var required_state="False";
      
      }
  
  return required_state ;
}

function mosy_form_data(form_id,  save_action, callback_function_string, additional_callbacks, required_inp="")
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
	var formData = new FormData(document.getElementById(form_id));
  
    if (document.getElementById("ajax_spinner") !==null) {
        
    	document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';
        
    }
    
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
   ///alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
    {

	formData.append(save_action, "ok");
	formData.append('mosyrequest_type', "ajax");
        $.ajax({
            type: "POST",
            url: ajax_url,
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
                  if (document.getElementById("ajax_spinner") !==null) {
        
                      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

                  }
              ///alert(data);
        		window[fcall_back_function](data, fadditional_callbacks);
            },
	    complete: function(){
			//alert("Data uploaded successfully.");
	    },
	    error: function (jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
	    } 
        });
      // Display the key/value pairs
      for (var pair of formData.entries()) {
          ///console.log(pair[0]+ ", " + pair[1]); 
      }
        	  
     }else{
        magic_message(validate_msg, 'dialog_box');
      }
      
      
}

function blackhole(data)
{

}

function show_password(input_name) 
{
  var x = document.getElementById(input_name);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}


function get_newval(elemid)
{
    if (document.getElementById(elemid) !==null) {

	  return document.getElementById(elemid).value;
    }else{
  
  return "";
  }
}

function mosy_response(server_resp, callbacks)
{

	alert("server_resp"+server_resp+" -- Callbacks "+callbacks);

}

function get_html(elemid)
{
    if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).innerHTML;
  }else{
  
  return "";
  }
}

function get_src(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).src;
  }else{
  
  return "";
  }
}

function get_href(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).href;
  }else{
  
  return "";
  }
}


function push_ddown(server_items, selelem)
{

	$('#'+selelem+' option:not(:first)').remove();

	document.getElementById(selelem).innerHTML=document.getElementById(selelem).innerHTML+server_items;

}
//========= formart to num =================

function tonum(req_number, decplc=0)
{

///alert(req_number);

n = parseFloat(req_number).toFixed(decplc)
var withCommas = Number(n).toLocaleString('en');


return withCommas;
}

//========= formart to num =================

function mosy_qstr(string, query_str)
{
    
   if(string.indexOf(query_str)==-1)
    {
      
      var q_str_state="False";
      
    }else{
    
	  var q_str_state="True";
     
	}
    
  return q_str_state;
    
}
function mosy_refresh(new_location)
{

var new_location_str=window.location.href;

  window.location=new_location_str.replace("table_alert", "tbl_alert_old");

}

function mosy_srefresh(server_resp, new_location)
{

  window.location=new_location;

}
////////////////// ===================  js action listener ================  

  var _js_msdn=document.querySelectorAll('js_msdn');
  
  _js_msdn.forEach(el => el.addEventListener('click', event => {
  
  var _mosy_jsmsdn_event_trgt= event.currentTarget;

  
	 _mosy_jsmsdn_jsaction="";
	 _mosy_jsmsdn_arg="";
     
  if (!_mosy_jsmsdn_event_trgt.hasAttribute("data-mosy_js")) 
  {
    // data attribute doesnt exist
  }else{
  
	 _mosy_jsmsdn_jsaction=_mosy_jsmsdn_event_trgt.getAttribute("data-mosy_js");
	 _mosy_jsmsdn_arg=_mosy_jsmsdn_event_trgt.getAttribute("data-_mosy_jsmsdn_arg");
     
  }

     window[_mosy_jsmsdn_jsaction](_mosy_jsmsdn_arg);

  
}));
  
  
  
////////////////// ==================  js action listener ================  



function pop_filter_tray (data_src, card_title, where_str_req,cols,returnfun)
{
  magic_screen(pop_data_filter_card, "alert_box");
        
  var where_str =" and "+(where_str_req);
  var where_str_inp =" and "+magic_clean_str(where_str_req);
  
  if(where_str_req=="")
  {
    var where_str="";
    var where_str_inp ="";
  }
  
  var load_data_set ="load_"+data_src;
  var gft_data_str="gft_"+data_src;
  ///alert(where_str);
  window[load_data_set]("", ajaxw+" "+window[gft_data_str]("")+where_str, cols, returnfun, "push_result:result","card");
  
  //alert(cols);
  var textbox ='<input type="text" class="form-control" onkeyup="'+load_data_set+'(this.value, \''+ajaxw+' \'+'+gft_data_str+'(this.value)+\''+where_str_inp+'\', \''+magic_clean_str(cols)+'\', \''+returnfun+'\', \'push_result:result\',\'card\')" placeholder="Type your search here"/>';
        
  document.getElementById('card_title').innerHTML=card_title;
  document.getElementById('dope_text').innerHTML=textbox;

        
}


function mosytoggle_elem(elemid, new_val)
{
  if(new_val=='')
  {
  if(document.getElementById(elemid).style.display!='none')
  {
    document.getElementById(elemid).style.display='none';
  }else{
    document.getElementById(elemid).style.display='block';
  }
  }else{
    document.getElementById(elemid).style.display=new_val;
  }
}

function tray_uptoken(datakey,callbacks)
{
  
  window.location=callbacks[0]+'?'+callbacks[1]+'_uptoken='+btoa(datakey[0]);
}

var pop_data_filter_card=`
    <h5><i class="fa fa-search mr-2"></i><span id="card_title"></span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  	<div id="dope_text" class="col-md-12"></div>
	<div id="result" class="col-md-12" style="max-height:300px; overflow-y:auto;" onclick="this.style.display='none'"></div>
    
  	<div id="r" class="col-md-12 row justify-content-center m-0 p-0 mt-3">
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5 mr-lg-3" id="pop_tray_location"> 
        	View All <i class="fa fa-arrow-right"></i> 
        </a>
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5" id="new_pop_tray_location"> 
        	<i class="fa fa-plus" id="newclass"></i> 
        	<span id="new_record_label"> Add new </span> 
        </a>
    </div>
  </div>`;
  
function push_link(new_link,anchor_el)
{

	//alert(new_link);
	document.getElementById(anchor_el).href=new_link;

}


function push_html(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

	  document.getElementById(elemid).innerHTML=new_val;
      
      }
}

function push_newval(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

  		document.getElementById(elemid).value=new_val;
  
  }
}

function push_src(elemid, new_val)
{
	  if (document.getElementById(elemid) !==null) 
      {

	  		document.getElementById(elemid).src=new_val;
      
      }
}

function mosytoggle_class(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_addclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    //document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_remclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }
  
}


function mosyhide_elem(elemid, new_class="")
{
    var curr_class="none";
    if(new_class!="")
    {
    curr_class=new_class;
    }
    	
   if (document.getElementById(elemid) !==null) 
   {
   	document.getElementById(elemid).style.display=curr_class;
   }
}

function mosyshow_elem(elemid, new_class="")
{
    var curr_class="block";
    if(new_class!="")
    {
    curr_class=new_class;
    }
   if (document.getElementById(elemid) !==null) 
   {
   	document.getElementById(elemid).style.display=curr_class;
   }
}

function mosy_get_param(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}


function mosy_push_data(elemid,data)
{
	var elem_state ="false";
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      
      push_newval(elemid, data);
      push_html(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, "<option>"+data+"</option>"+get_html(elemid));
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  
}

function check_elem(elemid)
{
    if (document.getElementById(elemid) ===null) 
    {
    alert("element_"+elemid+" Not available");
    }
}

function push_shtml(server_res, callback)
{
  
  magic_message(callback, "dialog_box");
  
}
function mosy_push_num_ddata(_server_resp, elemid_str)
{
	//alert(_server_resp);
    
	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = (elemid_arr[0]);
        
          data_str = elemid_arr[1];
          
          console.log(elemid+" state "+ data_str+" serep "+_server_resp);

         data = tonum(json_decoded_str[data_str]);
        
    }
    
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
            
      push_html(elemid, data);
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function mosy_push_ddata(_server_resp, elemid_str)
{

///alert(_server_resp);

	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = elemid_arr[0];
        
          data_str = elemid_arr[1];
          

         var data = json_decoded_str[data_str];
        
    }else{

		var data = json_decoded_str[data_str];

    }
              
    console.log(elemid+" state "+ data_str+" serep "+_server_resp);

    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      push_html(elemid, data);      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function dope_token(token_url="", token_key="")
{
window.history.replaceState(null, null, "?"+token_url+"="+token_key+"");
}

function mosyrename_elem(elemid, newname)
{
    if (document.getElementById(elemid) !==null) 
    {
      document.getElementById(elemid).id=newname;
      document.getElementById(newname).setAttribute("name",newname);
    }
}
///////////////  slide show 
function mosy_slide_wgt(image_arr_n_captions, img_style, img_class, extra_attr, slide_indicators_yes_no)
{
  
const rem_array = image_arr_n_captions.slice(0, 0).concat(image_arr_n_captions.slice(0+1, image_arr_n_captions.length));
  
var curr_slide_id =magic_random_str(10);
    
var img_string =  image_arr_n_captions[0];
var caption_str = ""
var caption_str_div="";
var datakey = "";
  
if(image_arr_n_captions[0].includes(":"))
{
 img_string =  image_arr_n_captions[0].substring(0, image_arr_n_captions[0].indexOf(':')); 
 datakey_1 = image_arr_n_captions[0].substring(image_arr_n_captions[0].indexOf(':')+1); 
 datakey = datakey_1.substring(0, datakey_1.indexOf(':'));
 datakey_2 = datakey_1.substring(datakey_1.indexOf(':')+1);
 caption_str = datakey_2.substring(datakey_2.indexOf(':'));
 caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${caption_str} </div>`;
}
  ///alert("dkey1 -- "+datakey_2);
 var slide_node="";
 var slidecounter="";
 var i=0;
  
 if(slide_indicators_yes_no=='yes')
 {
   slidecounter=`<li data-target="#slide_s${curr_slide_id}" data-slide-to="0" class="active"></li>`;
 }
 for(img_arr of rem_array)
 {
   i++;
   
	if(slide_indicators_yes_no=='yes'){
 slidecounter+=`
        <li data-target="#slide_s${curr_slide_id}" data-slide-to="${i}" class="active"></li>
   `;  
    }
   
   var loop_img_string =  img_arr;
   var loop_caption_str = "";
   var loop_caption_str_div="";
   var loop_datakey="";
   
   if(img_arr.includes(":")){
 	loop_img_string =  img_arr.substring(0, img_arr.indexOf(':')); 
 	loop_datakey_1 = img_arr.substring(img_arr.indexOf(':')+1); 
 	loop_datakey = loop_datakey_1.substring(0, loop_datakey_1.indexOf(':'));
 	loop_datakey_2 = loop_datakey_1.substring(loop_datakey_1.indexOf(':')+1);
 	loop_caption_str = loop_datakey_2.substring(loop_datakey_2.indexOf(':'));
 	loop_caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${loop_caption_str} </div>`;
   }
   
   slide_node+=`   
            <!-- carousel item -->
            <div class="carousel-item">
             <div class="row pt-3 justify-content-center">
     			${loop_caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${loop_img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${loop_datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->`;
   
 }
  
var slide_tray=`
      <!--------------- Start carousel ---------->
      <div id="slide_s${curr_slide_id}" class="carousel slide w-100" data-ride="carousel" data-interval="2000">
        <ol class="carousel-indicators mt-2">
  		${slidecounter}
        </ol>
        <!-- carousel inner -->
          <div class="carousel-inner">
            <!-- carousel item -->
            <div class="carousel-item active">
             <div class="row pt-3 justify-content-center">
          	   ${caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->
		   ${slide_node}
            <!-- carousel inner -->
            <a class="carousel-control-prev" href="#slide_s${curr_slide_id}" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a class="carousel-control-next" href="#slide_s${curr_slide_id}" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a> 
          </div>
             
      </div>
      <!--------------- End carousel ---------->
        `;
  
return [slide_tray, curr_slide_id];  
}
///////////////  slide show 

//////////////  image alert 
function mosy_img_pop(img_src,img_style, img_class,  extra_attr, slide_show_yes_no)
{
  var img_tray=
    `
    <img src="${img_src}" style="${img_style}" class="${img_class}"/>
    
    `;
  
  if(slide_show_yes_no=='yes')
  {
    
    var pop_tray_carousel = mosy_slide_wgt(img_src, img_style, img_class, extra_attr)[0];
    
    magic_screen(pop_tray_carousel, 'alert_box');
    
  }else{
  	magic_screen(img_tray, 'alert_box');
  }
  
}  

//////////////  image alert \

function mosy_snack_wgt(content, curr_position, push_to, snack_pos, snackid, color, bg, onclick_fun)
{
              
var snack_cont=`
<style>
/* The snackbar - position it at the bottom and in the middle of the screen */
#${snackid} {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background:${bg}; /* Black background color */
  color: ${color}; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 9999; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  ${curr_position}: ${snack_pos}; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#${snackid}.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}

@keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}
</style>
  
  <div id="${snackid}" onclick="${onclick_fun};push_html('${push_to}', '')">${content}</div>

  `;


push_html(push_to, snack_cont);


} 

function new_location(new_location_str)
{
window.location=new_location_str;
}

function mosy_reload()
{
   document.location.reload()

} 

function glass_modal()
{
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("background-color", "transparent", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border-top", "0px solid", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border", "0px solid", "important");;
}

function mosy_card(card_title="", card_content, attach_To)
{
	var mosy_card_title="";
    if(card_title!="")
    {
    var mosy_card_title=`
                          <!-- Start  Title ribbon-->
                      <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                        <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                        <div class="col-md-8 text-center"><b> ${card_title}</b></div>
                        <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                      </h5>
                      <!-- End Title ribbon--> 
    `;
    }
    var link_pop=`
    <div class="row justify-content-center m-0 p-0 col-md-12">
						${mosy_card_title}
                      <div class="row justify-content-center m-0 p-0 col-md-12 mt-3 mb-3">
                        ${card_content}
                      </div>
      </div>
    </div>

    `;

    if(attach_To=='' || attach_To==undefined)
    {
    magic_screen(link_pop, 'alert_box');
    }else{
      push_html(attach_To, link_pop);
    }

    return link_pop;
 
}

  
function filter_by_date(card_title,filter_link,filter_col,and_query='',trailing_space="")
{

var def_date = mosy_ymd();
var pop_filter_date=`
    <h5>Filter by <span id="filter_title"> ${card_title} </span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
	<div class="form-group col-md-6">
		<label >Start Date</label>
		<input class="form-control" id="txt_start_date" name="" value="${def_date}" placeholder="Your Name" type="date">
	</div>
  	<div class="form-group col-md-6">
		<label >End Date</label>
		<input class="form-control" id="txt_end_date"  name="" value="${def_date}" placeholder="Your Name" type="date">
	</div>
    <input type="hidden" id="txt_mosy_filter_q" value="${filter_col}" />
    <input type="hidden" id="txt_mosy_and_query" value="${and_query}" />
  <div class="col-md-7 cpointer btn_neoo2 btn-primary text-center" onclick=" go_to_date('${filter_link}', get_newval('txt_start_date'), get_newval('txt_end_date'), get_newval('txt_mosy_filter_q'), get_newval('txt_mosy_and_query'), '${trailing_space}')"><i class="fa fa-arrow-right"></i> Proceed </div>
  </div>
  `;
  
  mosy_card('', pop_filter_date);
  
  return pop_filter_date;
  
}
  
function go_to_date(filter_link, start_date, end_date, filter_col, and_query, trailing_space)
{
  var filter_location=filter_link+"="+btoa(trailing_space+"DATE_FORMAT("+filter_col+", '%Y-%m-%d') >='" +start_date+"' AND DATE_FORMAT("+filter_col+", '%Y-%m-%d') <='" +end_date+ "' "+and_query+" ");
  ///alert(filter_location);
  window.location=filter_location;
  
}

function mosy_ymd(date='') {
return new Date().toISOString().slice(0, 10);

}


function mosy_modal(modal_content, attach_To="alert_box", parent_id="")
{

  if(attach_To=="")
  {
  	attach_To="alert_box"
  }
  var mosy_modal_tray =`
  <div class="col-md-12 mosy_modal rounded_big p-0 m-0 bg-white shadow  border border_set ">
    <div class="col-md-12 pt-2 text-right"><span class="cpointer "  onclick="push_html('${attach_To}','')"><i class="fa fa-times-circle"></i></span></div>
    <div class="row justify-content-center m-0 p-0 col-md-12" id="${parent_id}">
    	${modal_content}
    </div>
  </div>`;

  ///alert(mosy_modal_tray);

  push_html(attach_To, mosy_modal_tray);

  return mosy_modal_tray;

}

//<--ncgh-->
