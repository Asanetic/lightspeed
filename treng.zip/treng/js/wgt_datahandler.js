
  
  
////========================= start app_admins inputs widget 



function app_admins_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, app_admins_input_wgt(app_admins_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== app_admins ========================

 var app_admins_js_input=["txt_name:Name:text:col-md-6","txt_email:Email:text:col-md-6","txt_tel:Tel:text:col-md-6","txt_login_password:Login Password:password:col-md-6","txt_ref_id:Payment Reference No.:text:col-md-6","txt_regdate:Date:datetime-local:col-md-6","txt_user_no:User No:text:col-md-6","txt_app_admins_user_pic:User Pic:file:col-md-6","txt_user_gender:User Gender:text:col-md-6","txt_last_seen:Last Seen:datetime-local:col-md-6","txt_about:About:textarea:col-md-12",];


function app_admins_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_name":"Name:text:col-md-6","txt_email":"Email:text:col-md-6","txt_tel":"Tel:text:col-md-6","txt_login_password":"Login Password:password:col-md-6","txt_ref_id":"Payment Reference No.:text:col-md-6","txt_regdate":"Date:datetime-local:col-md-6","txt_user_no":"User No:text:col-md-6","txt_app_admins_user_pic":"User Pic:file:col-md-6","txt_user_gender":"User Gender:text:col-md-6","txt_last_seen":"Last Seen:datetime-local:col-md-6","txt_about":"About:textarea:col-md-12",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== app_admins UI widget listener ================

app_admins_click_ui_class=document.querySelectorAll('.app_admins_prf_wgt');
  
app_admins_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var app_admins_click_ui_class_event_trgt= event.currentTarget;
  
  var app_admins_wgt_card_title="";
  var app_admins_wgt_card_prof_cols="";
  var app_admins_wgt_card_data_btn="";

  if (!app_admins_click_ui_class_event_trgt.hasAttribute("data-app_admins_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 app_admins_wgt_card_title=app_admins_click_ui_class_event_trgt.getAttribute("data-app_admins_card_title");
     
  }
  
  if (!app_admins_click_ui_class_event_trgt.hasAttribute("data-app_admins_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 app_admins_wgt_card_prof_cols=app_admins_click_ui_class_event_trgt.getAttribute("data-app_admins_prof_cols");
  }


  
  if (!app_admins_click_ui_class_event_trgt.hasAttribute("data-app_admins_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 app_admins_wgt_card_data_btn=app_admins_click_ui_class_event_trgt.getAttribute("data-app_admins_data_btn");
  }
  
  var app_admins_act_inp=app_admins_input_wgt(app_admins_wgt_card_prof_cols.split(','), app_admins_wgt_card_data_btn,  app_admins_wgt_card_title);
  
  push_html('actv_div',  app_admins_act_inp); 
  
}));
  
////////////////// =================== app_admins UI widget listener ================  


  
  
////========================= start apps inputs widget 



function apps_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, apps_input_wgt(apps_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== apps ========================

 var apps_js_input=["txt_apptitle:Apptitle:text:col-md-6","txt_name:Name:text:col-md-6","txt_run_at:Schedule date:datetime-local:col-md-6","txt_app_key:App Key:text:col-md-6","txt_secret:Secret:text:col-md-6","txt_details:Post Details:contenteditable:col-md-12","txt_admin_id:Admin Id:apps_user_id_ajax_search:col-md-6",];


function apps_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_apptitle":"Apptitle:text:col-md-6","txt_name":"Name:text:col-md-6","txt_run_at":"Schedule date:datetime-local:col-md-6","txt_app_key":"App Key:text:col-md-6","txt_secret":"Secret:text:col-md-6","txt_details":"Post Details:contenteditable:col-md-12","txt_admin_id":"Admin Id:apps_user_id_ajax_search:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
                  var apps_user_id_qstr="";
    
                   if (typeof apps_user_id_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _user_id="";//apps_node["admin_id"]; 
                   
                  if(mosy_get_param("user_id")!==undefined){_user_id=atob(mosy_get_param("user_id"));}

                  if(input_type=="apps_user_id_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_admin_id_disp" id="txt_admin_id_disp" class="form-control" onkeyup="check_elem('txt_admin_id');load_app_admins(this.value, '${apps_user_id_qstr}','user_id,name,name:Admin Id','push_val:txt_admin_id,txt_admin_id_disp', 'push_result:apps_user_id_tray', 'card')" class="form-control" placeholder="Search Admin Id"  value="" />
              <!--<input type="hidden" name="txt_admin_id" id="txt_admin_id"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display='none';" id="apps_user_id_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== apps UI widget listener ================

apps_click_ui_class=document.querySelectorAll('.apps_prf_wgt');
  
apps_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var apps_click_ui_class_event_trgt= event.currentTarget;
  
  var apps_wgt_card_title="";
  var apps_wgt_card_prof_cols="";
  var apps_wgt_card_data_btn="";

  if (!apps_click_ui_class_event_trgt.hasAttribute("data-apps_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 apps_wgt_card_title=apps_click_ui_class_event_trgt.getAttribute("data-apps_card_title");
     
  }
  
  if (!apps_click_ui_class_event_trgt.hasAttribute("data-apps_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 apps_wgt_card_prof_cols=apps_click_ui_class_event_trgt.getAttribute("data-apps_prof_cols");
  }


  
  if (!apps_click_ui_class_event_trgt.hasAttribute("data-apps_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 apps_wgt_card_data_btn=apps_click_ui_class_event_trgt.getAttribute("data-apps_data_btn");
  }
  
  var apps_act_inp=apps_input_wgt(apps_wgt_card_prof_cols.split(','), apps_wgt_card_data_btn,  apps_wgt_card_title);
  
  push_html('actv_div',  apps_act_inp); 
  
}));
  
////////////////// =================== apps UI widget listener ================  


  
  
////========================= start file_uploads inputs widget 



function file_uploads_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, file_uploads_input_wgt(file_uploads_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== file_uploads ========================

 var file_uploads_js_input=["txt_fileurl:Fileurl:text:col-md-6","txt_file_tile:File Tile:text:col-md-6","txt_file_tag:File Tag:text:col-md-6","txt_post_blog:Post Blog:text:col-md-6",];


function file_uploads_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_fileurl":"Fileurl:text:col-md-6","txt_file_tile":"File Tile:text:col-md-6","txt_file_tag":"File Tag:text:col-md-6","txt_post_blog":"Post Blog:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== file_uploads UI widget listener ================

file_uploads_click_ui_class=document.querySelectorAll('.file_uploads_prf_wgt');
  
file_uploads_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var file_uploads_click_ui_class_event_trgt= event.currentTarget;
  
  var file_uploads_wgt_card_title="";
  var file_uploads_wgt_card_prof_cols="";
  var file_uploads_wgt_card_data_btn="";

  if (!file_uploads_click_ui_class_event_trgt.hasAttribute("data-file_uploads_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 file_uploads_wgt_card_title=file_uploads_click_ui_class_event_trgt.getAttribute("data-file_uploads_card_title");
     
  }
  
  if (!file_uploads_click_ui_class_event_trgt.hasAttribute("data-file_uploads_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 file_uploads_wgt_card_prof_cols=file_uploads_click_ui_class_event_trgt.getAttribute("data-file_uploads_prof_cols");
  }


  
  if (!file_uploads_click_ui_class_event_trgt.hasAttribute("data-file_uploads_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 file_uploads_wgt_card_data_btn=file_uploads_click_ui_class_event_trgt.getAttribute("data-file_uploads_data_btn");
  }
  
  var file_uploads_act_inp=file_uploads_input_wgt(file_uploads_wgt_card_prof_cols.split(','), file_uploads_wgt_card_data_btn,  file_uploads_wgt_card_title);
  
  push_html('actv_div',  file_uploads_act_inp); 
  
}));
  
////////////////// =================== file_uploads UI widget listener ================  


  
  
////========================= start keys_n_tokens inputs widget 



function keys_n_tokens_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, keys_n_tokens_input_wgt(keys_n_tokens_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== keys_n_tokens ========================

 var keys_n_tokens_js_input=["txt_page_name:Page Name:text:col-md-6","txt_appid:Appid:keys_n_tokens_appid_ajax_search:col-md-6","txt_regon:Regon:date:col-md-6","txt_type:Type:type_dynamic_drop_down:col-md-6","txt_descr:Descr:text:col-md-6","txt_token:Token:textarea:col-md-12","txt_admin_id:Admin Id:keys_n_tokens_user_id_ajax_search:col-md-6",];


function keys_n_tokens_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_page_name":"Page Name:text:col-md-6","txt_appid":"Appid:keys_n_tokens_appid_ajax_search:col-md-6","txt_regon":"Regon:date:col-md-6","txt_type":"Type:type_dynamic_drop_down:col-md-6","txt_descr":"Descr:text:col-md-6","txt_token":"Token:textarea:col-md-12","txt_admin_id":"Admin Id:keys_n_tokens_user_id_ajax_search:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
                  var keys_n_tokens_appid_qstr="";
    
                   if (typeof keys_n_tokens_appid_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _appid="";//keys_n_tokens_node["appid"]; 
                   
                  if(mosy_get_param("appid")!==undefined){_appid=atob(mosy_get_param("appid"));}

                  if(input_type=="keys_n_tokens_appid_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_appid_disp" id="txt_appid_disp" class="form-control" onkeyup="check_elem('txt_appid');load_apps(this.value, '${keys_n_tokens_appid_qstr}','appid,apptitle,apptitle:Appid','push_val:txt_appid,txt_appid_disp', 'push_result:keys_n_tokens_appid_tray', 'card')" class="form-control" placeholder="Search Appid"  value="" />
              <!--<input type="hidden" name="txt_appid" id="txt_appid"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display='none';" id="keys_n_tokens_appid_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                
                  var keys_n_tokens_user_id_qstr="";
    
                   if (typeof keys_n_tokens_user_id_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _user_id="";//keys_n_tokens_node["admin_id"]; 
                   
                  if(mosy_get_param("user_id")!==undefined){_user_id=atob(mosy_get_param("user_id"));}

                  if(input_type=="keys_n_tokens_user_id_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_admin_id_disp" id="txt_admin_id_disp" class="form-control" onkeyup="check_elem('txt_admin_id');load_app_admins(this.value, '${keys_n_tokens_user_id_qstr}','user_id,name,name:Admin Id','push_val:txt_admin_id,txt_admin_id_disp', 'push_result:keys_n_tokens_user_id_tray', 'card')" class="form-control" placeholder="Search Admin Id"  value="" />
              <!--<input type="hidden" name="txt_admin_id" id="txt_admin_id"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display='none';" id="keys_n_tokens_user_id_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                
    
    
          				
                  if(input_type=="type_dynamic_drop_down")
                  {
                  label_tag ="";
                  input_tag =`
         			 <label ><span>Type</span> 
              			<span  id="_toggle_on_type"   onclick="document.getElementById(\'txt_type\').type=\'text\';document.getElementById(\'txt_type\').value=\'\';document.getElementById(\'sel_type\').style.display=\'none\';this.style.display=\'none\';document.getElementById(\'_toggle_off_type\').style.display=\'inline-block\';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              			<span style="display:none" id="_toggle_off_type"   onclick="document.getElementById(\'txt_type\').type=\'hidden\';document.getElementById(\'sel_type\').style.display=\'block\';this.style.display=\'none\';document.getElementById(\'_toggle_on_type\').style.display=\'inline-block\';if(document.getElementById(\'txt_type\').value==\'\') document.getElementById(\'txt_type\').value=document.getElementById(\'sel_type\').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_type" id="txt_type" class="form-control" placeholder="Type new Type" /> 
              <select name="sel_type" id="sel_type" class="form-control" onchange="document.getElementById('txt_type').value=this.value;"></select>
              `
              
              };
          
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  
           function load_keys_n_tokens_type_dyn_items(qstr)
           {
           get_keys_n_tokens("*", ""+qstr+" group by type", 'type,type:type','', 'push_result:sel_type', 'option');
           }
          
          


////////////////// =================== keys_n_tokens UI widget listener ================

keys_n_tokens_click_ui_class=document.querySelectorAll('.keys_n_tokens_prf_wgt');
  
keys_n_tokens_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var keys_n_tokens_click_ui_class_event_trgt= event.currentTarget;
  
  var keys_n_tokens_wgt_card_title="";
  var keys_n_tokens_wgt_card_prof_cols="";
  var keys_n_tokens_wgt_card_data_btn="";

  if (!keys_n_tokens_click_ui_class_event_trgt.hasAttribute("data-keys_n_tokens_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 keys_n_tokens_wgt_card_title=keys_n_tokens_click_ui_class_event_trgt.getAttribute("data-keys_n_tokens_card_title");
     
  }
  
  if (!keys_n_tokens_click_ui_class_event_trgt.hasAttribute("data-keys_n_tokens_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 keys_n_tokens_wgt_card_prof_cols=keys_n_tokens_click_ui_class_event_trgt.getAttribute("data-keys_n_tokens_prof_cols");
  }


  
  if (!keys_n_tokens_click_ui_class_event_trgt.hasAttribute("data-keys_n_tokens_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 keys_n_tokens_wgt_card_data_btn=keys_n_tokens_click_ui_class_event_trgt.getAttribute("data-keys_n_tokens_data_btn");
  }
  
  var keys_n_tokens_act_inp=keys_n_tokens_input_wgt(keys_n_tokens_wgt_card_prof_cols.split(','), keys_n_tokens_wgt_card_data_btn,  keys_n_tokens_wgt_card_title);
  
  push_html('actv_div',  keys_n_tokens_act_inp); 
  
}));
  
////////////////// =================== keys_n_tokens UI widget listener ================  


  
  
////========================= start market_list inputs widget 



function market_list_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, market_list_input_wgt(market_list_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== market_list ========================

 var market_list_js_input=["txt_market_name:Market Name:text:col-md-6","txt_market_page:Market Page:text:col-md-6","txt_market_location:Market Location:text:col-md-6","txt_post_content_to:Post Content To:text:col-md-6","txt_remark:Remark:textarea:col-md-12",];


function market_list_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_market_name":"Market Name:text:col-md-6","txt_market_page":"Market Page:text:col-md-6","txt_market_location":"Market Location:text:col-md-6","txt_post_content_to":"Post Content To:text:col-md-6","txt_remark":"Remark:textarea:col-md-12",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== market_list UI widget listener ================

market_list_click_ui_class=document.querySelectorAll('.market_list_prf_wgt');
  
market_list_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var market_list_click_ui_class_event_trgt= event.currentTarget;
  
  var market_list_wgt_card_title="";
  var market_list_wgt_card_prof_cols="";
  var market_list_wgt_card_data_btn="";

  if (!market_list_click_ui_class_event_trgt.hasAttribute("data-market_list_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 market_list_wgt_card_title=market_list_click_ui_class_event_trgt.getAttribute("data-market_list_card_title");
     
  }
  
  if (!market_list_click_ui_class_event_trgt.hasAttribute("data-market_list_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 market_list_wgt_card_prof_cols=market_list_click_ui_class_event_trgt.getAttribute("data-market_list_prof_cols");
  }


  
  if (!market_list_click_ui_class_event_trgt.hasAttribute("data-market_list_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 market_list_wgt_card_data_btn=market_list_click_ui_class_event_trgt.getAttribute("data-market_list_data_btn");
  }
  
  var market_list_act_inp=market_list_input_wgt(market_list_wgt_card_prof_cols.split(','), market_list_wgt_card_data_btn,  market_list_wgt_card_title);
  
  push_html('actv_div',  market_list_act_inp); 
  
}));
  
////////////////// =================== market_list UI widget listener ================  


  
  
////========================= start messages inputs widget 



function messages_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, messages_input_wgt(messages_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== messages ========================

 var messages_js_input=["txt_user_email:User Email:text:col-md-6","txt_user_mobile:User Mobile:text:col-md-6","txt_message_date:Message Date:text:col-md-6","txt_message:Message:text:col-md-6","txt_user_name:User Name:text:col-md-6","txt_service_id:Service Id:text:col-md-6","txt_service_name:Service Name:text:col-md-6","txt_message_remark:Message Remark:text:col-md-6",];


function messages_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_user_email":"User Email:text:col-md-6","txt_user_mobile":"User Mobile:text:col-md-6","txt_message_date":"Message Date:text:col-md-6","txt_message":"Message:text:col-md-6","txt_user_name":"User Name:text:col-md-6","txt_service_id":"Service Id:text:col-md-6","txt_service_name":"Service Name:text:col-md-6","txt_message_remark":"Message Remark:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== messages UI widget listener ================

messages_click_ui_class=document.querySelectorAll('.messages_prf_wgt');
  
messages_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var messages_click_ui_class_event_trgt= event.currentTarget;
  
  var messages_wgt_card_title="";
  var messages_wgt_card_prof_cols="";
  var messages_wgt_card_data_btn="";

  if (!messages_click_ui_class_event_trgt.hasAttribute("data-messages_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 messages_wgt_card_title=messages_click_ui_class_event_trgt.getAttribute("data-messages_card_title");
     
  }
  
  if (!messages_click_ui_class_event_trgt.hasAttribute("data-messages_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 messages_wgt_card_prof_cols=messages_click_ui_class_event_trgt.getAttribute("data-messages_prof_cols");
  }


  
  if (!messages_click_ui_class_event_trgt.hasAttribute("data-messages_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 messages_wgt_card_data_btn=messages_click_ui_class_event_trgt.getAttribute("data-messages_data_btn");
  }
  
  var messages_act_inp=messages_input_wgt(messages_wgt_card_prof_cols.split(','), messages_wgt_card_data_btn,  messages_wgt_card_title);
  
  push_html('actv_div',  messages_act_inp); 
  
}));
  
////////////////// =================== messages UI widget listener ================  


  
  
////========================= start mosy_sql_roll_back inputs widget 



function mosy_sql_roll_back_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== mosy_sql_roll_back ========================

 var mosy_sql_roll_back_js_input=["txt_table_name:Table Name:text:col-md-6","txt_roll_type:Roll Type:text:col-md-6","txt_where_str:Where Str:text:col-md-6","txt_roll_timestamp:Roll Timestamp:text:col-md-6","txt_value_entries:Value Entries:text:col-md-6",];


function mosy_sql_roll_back_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_table_name":"Table Name:text:col-md-6","txt_roll_type":"Roll Type:text:col-md-6","txt_where_str":"Where Str:text:col-md-6","txt_roll_timestamp":"Roll Timestamp:text:col-md-6","txt_value_entries":"Value Entries:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== mosy_sql_roll_back UI widget listener ================

mosy_sql_roll_back_click_ui_class=document.querySelectorAll('.mosy_sql_roll_back_prf_wgt');
  
mosy_sql_roll_back_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var mosy_sql_roll_back_click_ui_class_event_trgt= event.currentTarget;
  
  var mosy_sql_roll_back_wgt_card_title="";
  var mosy_sql_roll_back_wgt_card_prof_cols="";
  var mosy_sql_roll_back_wgt_card_data_btn="";

  if (!mosy_sql_roll_back_click_ui_class_event_trgt.hasAttribute("data-mosy_sql_roll_back_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 mosy_sql_roll_back_wgt_card_title=mosy_sql_roll_back_click_ui_class_event_trgt.getAttribute("data-mosy_sql_roll_back_card_title");
     
  }
  
  if (!mosy_sql_roll_back_click_ui_class_event_trgt.hasAttribute("data-mosy_sql_roll_back_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 mosy_sql_roll_back_wgt_card_prof_cols=mosy_sql_roll_back_click_ui_class_event_trgt.getAttribute("data-mosy_sql_roll_back_prof_cols");
  }


  
  if (!mosy_sql_roll_back_click_ui_class_event_trgt.hasAttribute("data-mosy_sql_roll_back_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 mosy_sql_roll_back_wgt_card_data_btn=mosy_sql_roll_back_click_ui_class_event_trgt.getAttribute("data-mosy_sql_roll_back_data_btn");
  }
  
  var mosy_sql_roll_back_act_inp=mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_wgt_card_prof_cols.split(','), mosy_sql_roll_back_wgt_card_data_btn,  mosy_sql_roll_back_wgt_card_title);
  
  push_html('actv_div',  mosy_sql_roll_back_act_inp); 
  
}));
  
////////////////// =================== mosy_sql_roll_back UI widget listener ================  


  
  
////========================= start notes_admins inputs widget 



function notes_admins_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, notes_admins_input_wgt(notes_admins_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== notes_admins ========================

 var notes_admins_js_input=["txt_name:Name:text:col-md-6","txt_email:Email:text:col-md-6","txt_tel:Tel:text:col-md-6","txt_login_password:Login Password:password:col-md-6","txt_ref_id:Payment Reference No.:text:col-md-6","txt_regdate:Date:datetime-local:col-md-6","txt_user_no:User No:text:col-md-6","txt_notes_admins_user_pic:User Pic:file:col-md-6","txt_user_gender:User Gender:text:col-md-6","txt_last_seen:Last Seen:datetime-local:col-md-6","txt_about:About:textarea:col-md-12",];


function notes_admins_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_name":"Name:text:col-md-6","txt_email":"Email:text:col-md-6","txt_tel":"Tel:text:col-md-6","txt_login_password":"Login Password:password:col-md-6","txt_ref_id":"Payment Reference No.:text:col-md-6","txt_regdate":"Date:datetime-local:col-md-6","txt_user_no":"User No:text:col-md-6","txt_notes_admins_user_pic":"User Pic:file:col-md-6","txt_user_gender":"User Gender:text:col-md-6","txt_last_seen":"Last Seen:datetime-local:col-md-6","txt_about":"About:textarea:col-md-12",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== notes_admins UI widget listener ================

notes_admins_click_ui_class=document.querySelectorAll('.notes_admins_prf_wgt');
  
notes_admins_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var notes_admins_click_ui_class_event_trgt= event.currentTarget;
  
  var notes_admins_wgt_card_title="";
  var notes_admins_wgt_card_prof_cols="";
  var notes_admins_wgt_card_data_btn="";

  if (!notes_admins_click_ui_class_event_trgt.hasAttribute("data-notes_admins_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 notes_admins_wgt_card_title=notes_admins_click_ui_class_event_trgt.getAttribute("data-notes_admins_card_title");
     
  }
  
  if (!notes_admins_click_ui_class_event_trgt.hasAttribute("data-notes_admins_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 notes_admins_wgt_card_prof_cols=notes_admins_click_ui_class_event_trgt.getAttribute("data-notes_admins_prof_cols");
  }


  
  if (!notes_admins_click_ui_class_event_trgt.hasAttribute("data-notes_admins_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 notes_admins_wgt_card_data_btn=notes_admins_click_ui_class_event_trgt.getAttribute("data-notes_admins_data_btn");
  }
  
  var notes_admins_act_inp=notes_admins_input_wgt(notes_admins_wgt_card_prof_cols.split(','), notes_admins_wgt_card_data_btn,  notes_admins_wgt_card_title);
  
  push_html('actv_div',  notes_admins_act_inp); 
  
}));
  
////////////////// =================== notes_admins UI widget listener ================  


  
  
////========================= start notes_list inputs widget 



function notes_list_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, notes_list_input_wgt(notes_list_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== notes_list ========================

 var notes_list_js_input=["txt_note_title:Note Title:text:col-md-6","txt_note_details:Note Details:text:col-md-6","txt_note_date:Note Date:text:col-md-6","txt_note_tag:Note Tag:text:col-md-6","txt_user_id:User Id:text:col-md-6","txt_note_remark:Note Remark:text:col-md-6","txt_note_media:Note Media:text:col-md-6",];


function notes_list_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_note_title":"Note Title:text:col-md-6","txt_note_details":"Note Details:text:col-md-6","txt_note_date":"Note Date:text:col-md-6","txt_note_tag":"Note Tag:text:col-md-6","txt_user_id":"User Id:text:col-md-6","txt_note_remark":"Note Remark:text:col-md-6","txt_note_media":"Note Media:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== notes_list UI widget listener ================

notes_list_click_ui_class=document.querySelectorAll('.notes_list_prf_wgt');
  
notes_list_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var notes_list_click_ui_class_event_trgt= event.currentTarget;
  
  var notes_list_wgt_card_title="";
  var notes_list_wgt_card_prof_cols="";
  var notes_list_wgt_card_data_btn="";

  if (!notes_list_click_ui_class_event_trgt.hasAttribute("data-notes_list_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 notes_list_wgt_card_title=notes_list_click_ui_class_event_trgt.getAttribute("data-notes_list_card_title");
     
  }
  
  if (!notes_list_click_ui_class_event_trgt.hasAttribute("data-notes_list_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 notes_list_wgt_card_prof_cols=notes_list_click_ui_class_event_trgt.getAttribute("data-notes_list_prof_cols");
  }


  
  if (!notes_list_click_ui_class_event_trgt.hasAttribute("data-notes_list_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 notes_list_wgt_card_data_btn=notes_list_click_ui_class_event_trgt.getAttribute("data-notes_list_data_btn");
  }
  
  var notes_list_act_inp=notes_list_input_wgt(notes_list_wgt_card_prof_cols.split(','), notes_list_wgt_card_data_btn,  notes_list_wgt_card_title);
  
  push_html('actv_div',  notes_list_act_inp); 
  
}));
  
////////////////// =================== notes_list UI widget listener ================  


  
  
////========================= start online_reception inputs widget 



function online_reception_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, online_reception_input_wgt(online_reception_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== online_reception ========================

 var online_reception_js_input=["txt_page_logo:Page Logo:text:col-md-6","txt_bg_image:Bg Image:text:col-md-6","txt_page_name:Page Name:text:col-md-6","txt_btn_clr:Btn Clr:text:col-md-6","txt_btn_txt_clr:Btn Txt Clr:text:col-md-6","txt_wild_clr:Wild Clr:text:col-md-6","txt_action_link:Action Link:text:col-md-6","txt_owner_id:Owner Id:text:col-md-6","txt_page_descr:Page Descr:text:col-md-6","txt_background_clr:Background Clr:text:col-md-6","txt_background_text_clr:Background Text Clr:text:col-md-6","txt_send_msg_title:Send Msg Title:text:col-md-6","txt_send_btn_title:Send Btn Title:text:col-md-6","txt_border_radius:Border Radius:text:col-md-6","txt_navbar_clr:Navbar Clr:text:col-md-6","txt_navbar_txt_clr:Navbar Txt Clr:text:col-md-6","txt_telephone_:Telephone :text:col-md-6",];


function online_reception_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_page_logo":"Page Logo:text:col-md-6","txt_bg_image":"Bg Image:text:col-md-6","txt_page_name":"Page Name:text:col-md-6","txt_btn_clr":"Btn Clr:text:col-md-6","txt_btn_txt_clr":"Btn Txt Clr:text:col-md-6","txt_wild_clr":"Wild Clr:text:col-md-6","txt_action_link":"Action Link:text:col-md-6","txt_owner_id":"Owner Id:text:col-md-6","txt_page_descr":"Page Descr:text:col-md-6","txt_background_clr":"Background Clr:text:col-md-6","txt_background_text_clr":"Background Text Clr:text:col-md-6","txt_send_msg_title":"Send Msg Title:text:col-md-6","txt_send_btn_title":"Send Btn Title:text:col-md-6","txt_border_radius":"Border Radius:text:col-md-6","txt_navbar_clr":"Navbar Clr:text:col-md-6","txt_navbar_txt_clr":"Navbar Txt Clr:text:col-md-6","txt_telephone_":"Telephone :text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== online_reception UI widget listener ================

online_reception_click_ui_class=document.querySelectorAll('.online_reception_prf_wgt');
  
online_reception_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var online_reception_click_ui_class_event_trgt= event.currentTarget;
  
  var online_reception_wgt_card_title="";
  var online_reception_wgt_card_prof_cols="";
  var online_reception_wgt_card_data_btn="";

  if (!online_reception_click_ui_class_event_trgt.hasAttribute("data-online_reception_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 online_reception_wgt_card_title=online_reception_click_ui_class_event_trgt.getAttribute("data-online_reception_card_title");
     
  }
  
  if (!online_reception_click_ui_class_event_trgt.hasAttribute("data-online_reception_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 online_reception_wgt_card_prof_cols=online_reception_click_ui_class_event_trgt.getAttribute("data-online_reception_prof_cols");
  }


  
  if (!online_reception_click_ui_class_event_trgt.hasAttribute("data-online_reception_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 online_reception_wgt_card_data_btn=online_reception_click_ui_class_event_trgt.getAttribute("data-online_reception_data_btn");
  }
  
  var online_reception_act_inp=online_reception_input_wgt(online_reception_wgt_card_prof_cols.split(','), online_reception_wgt_card_data_btn,  online_reception_wgt_card_title);
  
  push_html('actv_div',  online_reception_act_inp); 
  
}));
  
////////////////// =================== online_reception UI widget listener ================  


  
  
////========================= start page_links inputs widget 



function page_links_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, page_links_input_wgt(page_links_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== page_links ========================

 var page_links_js_input=["txt_link_name:Link Name:textarea:col-md-12","txt_linkurl:Linkurl:contenteditable:col-md-12","txt_descr:Descr:text:col-md-6","txt_signature:Signature:signature_dynamic_drop_down:col-md-6","txt_admin_id:Admin Id:page_links_user_id_ajax_search:col-md-6",];


function page_links_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_link_name":"Link Name:textarea:col-md-12","txt_linkurl":"Linkurl:contenteditable:col-md-12","txt_descr":"Descr:text:col-md-6","txt_signature":"Signature:signature_dynamic_drop_down:col-md-6","txt_admin_id":"Admin Id:page_links_user_id_ajax_search:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
                  var page_links_user_id_qstr="";
    
                   if (typeof page_links_user_id_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _user_id="";//page_links_node["admin_id"]; 
                   
                  if(mosy_get_param("user_id")!==undefined){_user_id=atob(mosy_get_param("user_id"));}

                  if(input_type=="page_links_user_id_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_admin_id_disp" id="txt_admin_id_disp" class="form-control" onkeyup="check_elem('txt_admin_id');load_app_admins(this.value, '${page_links_user_id_qstr}','user_id,name,name:Admin Id','push_val:txt_admin_id,txt_admin_id_disp', 'push_result:page_links_user_id_tray', 'card')" class="form-control" placeholder="Search Admin Id"  value="" />
              <!--<input type="hidden" name="txt_admin_id" id="txt_admin_id"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display='none';" id="page_links_user_id_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                
    
    
          				
                  if(input_type=="signature_dynamic_drop_down")
                  {
                  label_tag ="";
                  input_tag =`
         			 <label ><span>Signature</span> 
              			<span  id="_toggle_on_signature"   onclick="document.getElementById(\'txt_signature\').type=\'text\';document.getElementById(\'txt_signature\').value=\'\';document.getElementById(\'sel_signature\').style.display=\'none\';this.style.display=\'none\';document.getElementById(\'_toggle_off_signature\').style.display=\'inline-block\';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              			<span style="display:none" id="_toggle_off_signature"   onclick="document.getElementById(\'txt_signature\').type=\'hidden\';document.getElementById(\'sel_signature\').style.display=\'block\';this.style.display=\'none\';document.getElementById(\'_toggle_on_signature\').style.display=\'inline-block\';if(document.getElementById(\'txt_signature\').value==\'\') document.getElementById(\'txt_signature\').value=document.getElementById(\'sel_signature\').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_signature" id="txt_signature" class="form-control" placeholder="Type new Signature" /> 
              <select name="sel_signature" id="sel_signature" class="form-control" onchange="document.getElementById('txt_signature').value=this.value;"></select>
              `
              
              };
          
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  
           function load_page_links_signature_dyn_items(qstr)
           {
           get_page_links("*", ""+qstr+" group by signature", 'signature,signature:signature','', 'push_result:sel_signature', 'option');
           }
          
          


////////////////// =================== page_links UI widget listener ================

page_links_click_ui_class=document.querySelectorAll('.page_links_prf_wgt');
  
page_links_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var page_links_click_ui_class_event_trgt= event.currentTarget;
  
  var page_links_wgt_card_title="";
  var page_links_wgt_card_prof_cols="";
  var page_links_wgt_card_data_btn="";

  if (!page_links_click_ui_class_event_trgt.hasAttribute("data-page_links_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 page_links_wgt_card_title=page_links_click_ui_class_event_trgt.getAttribute("data-page_links_card_title");
     
  }
  
  if (!page_links_click_ui_class_event_trgt.hasAttribute("data-page_links_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 page_links_wgt_card_prof_cols=page_links_click_ui_class_event_trgt.getAttribute("data-page_links_prof_cols");
  }


  
  if (!page_links_click_ui_class_event_trgt.hasAttribute("data-page_links_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 page_links_wgt_card_data_btn=page_links_click_ui_class_event_trgt.getAttribute("data-page_links_data_btn");
  }
  
  var page_links_act_inp=page_links_input_wgt(page_links_wgt_card_prof_cols.split(','), page_links_wgt_card_data_btn,  page_links_wgt_card_title);
  
  push_html('actv_div',  page_links_act_inp); 
  
}));
  
////////////////// =================== page_links UI widget listener ================  


  
  
////========================= start posting_log inputs widget 



function posting_log_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, posting_log_input_wgt(posting_log_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== posting_log ========================

 var posting_log_js_input=["txt_admin_id:Admin Id:posting_log_user_id_ajax_search:col-md-6","txt_marketid:Marketid:text:col-md-6","txt_post_id:Post Id:text:col-md-6","txt_ref_id:Payment Reference No.:text:col-md-6","txt_request_date:Request Date:text:col-md-6",];


function posting_log_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_admin_id":"Admin Id:posting_log_user_id_ajax_search:col-md-6","txt_marketid":"Marketid:text:col-md-6","txt_post_id":"Post Id:text:col-md-6","txt_ref_id":"Payment Reference No.:text:col-md-6","txt_request_date":"Request Date:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
                  var posting_log_user_id_qstr="";
    
                   if (typeof posting_log_user_id_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _user_id="";//posting_log_node["admin_id"]; 
                   
                  if(mosy_get_param("user_id")!==undefined){_user_id=atob(mosy_get_param("user_id"));}

                  if(input_type=="posting_log_user_id_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_admin_id_disp" id="txt_admin_id_disp" class="form-control" onkeyup="check_elem('txt_admin_id');load_app_admins(this.value, '${posting_log_user_id_qstr}','user_id,name,name:Admin Id','push_val:txt_admin_id,txt_admin_id_disp', 'push_result:posting_log_user_id_tray', 'card')" class="form-control" placeholder="Search Admin Id"  value="" />
              <!--<input type="hidden" name="txt_admin_id" id="txt_admin_id"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display='none';" id="posting_log_user_id_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== posting_log UI widget listener ================

posting_log_click_ui_class=document.querySelectorAll('.posting_log_prf_wgt');
  
posting_log_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var posting_log_click_ui_class_event_trgt= event.currentTarget;
  
  var posting_log_wgt_card_title="";
  var posting_log_wgt_card_prof_cols="";
  var posting_log_wgt_card_data_btn="";

  if (!posting_log_click_ui_class_event_trgt.hasAttribute("data-posting_log_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 posting_log_wgt_card_title=posting_log_click_ui_class_event_trgt.getAttribute("data-posting_log_card_title");
     
  }
  
  if (!posting_log_click_ui_class_event_trgt.hasAttribute("data-posting_log_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 posting_log_wgt_card_prof_cols=posting_log_click_ui_class_event_trgt.getAttribute("data-posting_log_prof_cols");
  }


  
  if (!posting_log_click_ui_class_event_trgt.hasAttribute("data-posting_log_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 posting_log_wgt_card_data_btn=posting_log_click_ui_class_event_trgt.getAttribute("data-posting_log_data_btn");
  }
  
  var posting_log_act_inp=posting_log_input_wgt(posting_log_wgt_card_prof_cols.split(','), posting_log_wgt_card_data_btn,  posting_log_wgt_card_title);
  
  push_html('actv_div',  posting_log_act_inp); 
  
}));
  
////////////////// =================== posting_log UI widget listener ================  


  
  
////========================= start posts inputs widget 



function posts_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, posts_input_wgt(posts_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== posts ========================

 var posts_js_input=["txt_msg_titile:Message Title:text:col-md-6","txt_msgposted:Msgposted:text:col-md-6","txt_run_at:Schedule date:datetime-local:col-md-6","txt_page:Social Media Page:posts_tokenid_ajax_search:col-md-6","txt_link:Landing Page:text:col-md-6","txt_details:Post Details:contenteditable:col-md-12","txt_post_response:Post Response:contenteditable:col-md-12","txt_signature:Signature:signature_dynamic_drop_down:col-md-6","txt_tweeted:Tweeted:tweeted_dynamic_drop_down:col-md-6","txt_admin_id:Admin Id:posts_user_id_ajax_search:col-md-6","txt_post_image:Post Image:text:col-md-6","txt_sharable_link:Sharable Link:text:col-md-6",];


function posts_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_msg_titile":"Message Title:text:col-md-6","txt_msgposted":"Msgposted:text:col-md-6","txt_run_at":"Schedule date:datetime-local:col-md-6","txt_page":"Social Media Page:posts_tokenid_ajax_search:col-md-6","txt_link":"Landing Page:text:col-md-6","txt_details":"Post Details:contenteditable:col-md-12","txt_post_response":"Post Response:contenteditable:col-md-12","txt_signature":"Signature:signature_dynamic_drop_down:col-md-6","txt_tweeted":"Tweeted:tweeted_dynamic_drop_down:col-md-6","txt_admin_id":"Admin Id:posts_user_id_ajax_search:col-md-6","txt_post_image":"Post Image:text:col-md-6","txt_sharable_link":"Sharable Link:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
                  var posts_tokenid_qstr="";
    
                   if (typeof posts_tokenid_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _tokenid="";//posts_node["page"]; 
                   
                  if(mosy_get_param("tokenid")!==undefined){_tokenid=atob(mosy_get_param("tokenid"));}

                  if(input_type=="posts_tokenid_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_page_disp" id="txt_page_disp" class="form-control" onkeyup="check_elem('txt_page');load_keys_n_tokens(this.value, '${posts_tokenid_qstr}','tokenid,page_name,page_name:Social Media Page','push_val:txt_page,txt_page_disp', 'push_result:posts_tokenid_tray', 'card')" class="form-control" placeholder="Search Social Media Page"  value="" />
              <!--<input type="hidden" name="txt_page" id="txt_page"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display='none';" id="posts_tokenid_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                
                  var posts_user_id_qstr="";
    
                   if (typeof posts_user_id_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _user_id="";//posts_node["admin_id"]; 
                   
                  if(mosy_get_param("user_id")!==undefined){_user_id=atob(mosy_get_param("user_id"));}

                  if(input_type=="posts_user_id_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_admin_id_disp" id="txt_admin_id_disp" class="form-control" onkeyup="check_elem('txt_admin_id');load_app_admins(this.value, '${posts_user_id_qstr}','user_id,name,name:Admin Id','push_val:txt_admin_id,txt_admin_id_disp', 'push_result:posts_user_id_tray', 'card')" class="form-control" placeholder="Search Admin Id"  value="" />
              <!--<input type="hidden" name="txt_admin_id" id="txt_admin_id"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display='none';" id="posts_user_id_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                
    
    
          				
                  if(input_type=="signature_dynamic_drop_down")
                  {
                  label_tag ="";
                  input_tag =`
         			 <label ><span>Signature</span> 
              			<span  id="_toggle_on_signature"   onclick="document.getElementById(\'txt_signature\').type=\'text\';document.getElementById(\'txt_signature\').value=\'\';document.getElementById(\'sel_signature\').style.display=\'none\';this.style.display=\'none\';document.getElementById(\'_toggle_off_signature\').style.display=\'inline-block\';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              			<span style="display:none" id="_toggle_off_signature"   onclick="document.getElementById(\'txt_signature\').type=\'hidden\';document.getElementById(\'sel_signature\').style.display=\'block\';this.style.display=\'none\';document.getElementById(\'_toggle_on_signature\').style.display=\'inline-block\';if(document.getElementById(\'txt_signature\').value==\'\') document.getElementById(\'txt_signature\').value=document.getElementById(\'sel_signature\').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_signature" id="txt_signature" class="form-control" placeholder="Type new Signature" /> 
              <select name="sel_signature" id="sel_signature" class="form-control" onchange="document.getElementById('txt_signature').value=this.value;"></select>
              `
              
              };
          
          				
                  if(input_type=="tweeted_dynamic_drop_down")
                  {
                  label_tag ="";
                  input_tag =`
         			 <label ><span>Tweeted</span> 
              			<span  id="_toggle_on_tweeted"   onclick="document.getElementById(\'txt_tweeted\').type=\'text\';document.getElementById(\'txt_tweeted\').value=\'\';document.getElementById(\'sel_tweeted\').style.display=\'none\';this.style.display=\'none\';document.getElementById(\'_toggle_off_tweeted\').style.display=\'inline-block\';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              			<span style="display:none" id="_toggle_off_tweeted"   onclick="document.getElementById(\'txt_tweeted\').type=\'hidden\';document.getElementById(\'sel_tweeted\').style.display=\'block\';this.style.display=\'none\';document.getElementById(\'_toggle_on_tweeted\').style.display=\'inline-block\';if(document.getElementById(\'txt_tweeted\').value==\'\') document.getElementById(\'txt_tweeted\').value=document.getElementById(\'sel_tweeted\').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_tweeted" id="txt_tweeted" class="form-control" placeholder="Type new Tweeted" /> 
              <select name="sel_tweeted" id="sel_tweeted" class="form-control" onchange="document.getElementById('txt_tweeted').value=this.value;"></select>
              `
              
              };
          
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  
           function load_posts_signature_dyn_items(qstr)
           {
           get_posts("*", ""+qstr+" group by signature", 'signature,signature:signature','', 'push_result:sel_signature', 'option');
           }
          
          
           function load_posts_tweeted_dyn_items(qstr)
           {
           get_posts("*", ""+qstr+" group by tweeted", 'tweeted,tweeted:tweeted','', 'push_result:sel_tweeted', 'option');
           }
          
          


////////////////// =================== posts UI widget listener ================

posts_click_ui_class=document.querySelectorAll('.posts_prf_wgt');
  
posts_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var posts_click_ui_class_event_trgt= event.currentTarget;
  
  var posts_wgt_card_title="";
  var posts_wgt_card_prof_cols="";
  var posts_wgt_card_data_btn="";

  if (!posts_click_ui_class_event_trgt.hasAttribute("data-posts_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 posts_wgt_card_title=posts_click_ui_class_event_trgt.getAttribute("data-posts_card_title");
     
  }
  
  if (!posts_click_ui_class_event_trgt.hasAttribute("data-posts_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 posts_wgt_card_prof_cols=posts_click_ui_class_event_trgt.getAttribute("data-posts_prof_cols");
  }


  
  if (!posts_click_ui_class_event_trgt.hasAttribute("data-posts_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 posts_wgt_card_data_btn=posts_click_ui_class_event_trgt.getAttribute("data-posts_data_btn");
  }
  
  var posts_act_inp=posts_input_wgt(posts_wgt_card_prof_cols.split(','), posts_wgt_card_data_btn,  posts_wgt_card_title);
  
  push_html('actv_div',  posts_act_inp); 
  
}));
  
////////////////// =================== posts UI widget listener ================  


  
  
////========================= start task_manager inputs widget 



function task_manager_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, task_manager_input_wgt(task_manager_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== task_manager ========================

 var task_manager_js_input=["txt_project_id:Project Id:text:col-md-6","txt_task_name:Task Name:text:col-md-6","txt_task_status:Task Status:text:col-md-6","txt_task_date:Task Date:text:col-md-6","txt_task_remark:Task Remark:text:col-md-6","txt_test_column:Test Column:text:col-md-6","txt_assigned_to:Assigned To:text:col-md-6","txt_task_comments:Task Comments:text:col-md-6","txt_admin_remark:Admin Remark:text:col-md-6",];


function task_manager_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_project_id":"Project Id:text:col-md-6","txt_task_name":"Task Name:text:col-md-6","txt_task_status":"Task Status:text:col-md-6","txt_task_date":"Task Date:text:col-md-6","txt_task_remark":"Task Remark:text:col-md-6","txt_test_column":"Test Column:text:col-md-6","txt_assigned_to":"Assigned To:text:col-md-6","txt_task_comments":"Task Comments:text:col-md-6","txt_admin_remark":"Admin Remark:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== task_manager UI widget listener ================

task_manager_click_ui_class=document.querySelectorAll('.task_manager_prf_wgt');
  
task_manager_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var task_manager_click_ui_class_event_trgt= event.currentTarget;
  
  var task_manager_wgt_card_title="";
  var task_manager_wgt_card_prof_cols="";
  var task_manager_wgt_card_data_btn="";

  if (!task_manager_click_ui_class_event_trgt.hasAttribute("data-task_manager_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 task_manager_wgt_card_title=task_manager_click_ui_class_event_trgt.getAttribute("data-task_manager_card_title");
     
  }
  
  if (!task_manager_click_ui_class_event_trgt.hasAttribute("data-task_manager_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 task_manager_wgt_card_prof_cols=task_manager_click_ui_class_event_trgt.getAttribute("data-task_manager_prof_cols");
  }


  
  if (!task_manager_click_ui_class_event_trgt.hasAttribute("data-task_manager_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 task_manager_wgt_card_data_btn=task_manager_click_ui_class_event_trgt.getAttribute("data-task_manager_data_btn");
  }
  
  var task_manager_act_inp=task_manager_input_wgt(task_manager_wgt_card_prof_cols.split(','), task_manager_wgt_card_data_btn,  task_manager_wgt_card_title);
  
  push_html('actv_div',  task_manager_act_inp); 
  
}));
  
////////////////// =================== task_manager UI widget listener ================  


  
  
////========================= start traffic_log inputs widget 



function traffic_log_js_ui(card_title="", btn_str="", skip="", push_to="")
{
     
    mosy_card(card_title, traffic_log_input_wgt(traffic_log_js_input, btn_str, "", skip), push_to);

}


//////////////////////=================== traffic_log ========================

 var traffic_log_js_input=["txt_campaign_id:Campaign Id:text:col-md-6","txt_channel_node:Channel Node:text:col-md-6","txt_visit_time:Visit Time:text:col-md-6","txt_visit_date:Visit Date:text:col-md-6","txt_visitor_name:Visitor Name:text:col-md-6","txt_page_visited:Page Visited:text:col-md-6","txt_page_url:Page Url:contenteditable:col-md-12","txt_admin_id:Admin Id:traffic_log_user_id_ajax_search:col-md-6","txt_source_url:Source Url:contenteditable:col-md-12","txt_ip_address:Ip Address:text:col-md-6","txt_comment:Comment:text:col-md-6","txt_source_page:Source Page:text:col-md-6","txt_time_stamp:Time Stamp:datetime-local:col-md-6","txt_user_id:User Id:text:col-md-6","txt_log_data:Log Data:text:col-md-6","txt_device:Device:text:col-md-6","txt_browser:Browser:text:col-md-6",];


function traffic_log_input_wgt(input_array, button="", title="", skip="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_campaign_id":"Campaign Id:text:col-md-6","txt_channel_node":"Channel Node:text:col-md-6","txt_visit_time":"Visit Time:text:col-md-6","txt_visit_date":"Visit Date:text:col-md-6","txt_visitor_name":"Visitor Name:text:col-md-6","txt_page_visited":"Page Visited:text:col-md-6","txt_page_url":"Page Url:contenteditable:col-md-12","txt_admin_id":"Admin Id:traffic_log_user_id_ajax_search:col-md-6","txt_source_url":"Source Url:contenteditable:col-md-12","txt_ip_address":"Ip Address:text:col-md-6","txt_comment":"Comment:text:col-md-6","txt_source_page":"Source Page:text:col-md-6","txt_time_stamp":"Time Stamp:datetime-local:col-md-6","txt_user_id":"User Id:text:col-md-6","txt_log_data":"Log Data:text:col-md-6","txt_device":"Device:text:col-md-6","txt_browser":"Browser:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
                  var traffic_log_user_id_qstr="";
    
                   if (typeof traffic_log_user_id_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _user_id="";//traffic_log_node["admin_id"]; 
                   
                  if(mosy_get_param("user_id")!==undefined){_user_id=atob(mosy_get_param("user_id"));}

                  if(input_type=="traffic_log_user_id_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_admin_id_disp" id="txt_admin_id_disp" class="form-control" onkeyup="check_elem('txt_admin_id');load_app_admins(this.value, '${traffic_log_user_id_qstr}','user_id,name,name:Admin Id','push_val:txt_admin_id,txt_admin_id_disp', 'push_result:traffic_log_user_id_tray', 'card')" class="form-control" placeholder="Search Admin Id"  value="" />
              <!--<input type="hidden" name="txt_admin_id" id="txt_admin_id"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display='none';" id="traffic_log_user_id_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  if(button!=""){
    input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>`;
  }

    
   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


////////////////// =================== traffic_log UI widget listener ================

traffic_log_click_ui_class=document.querySelectorAll('.traffic_log_prf_wgt');
  
traffic_log_click_ui_class.forEach(el => el.addEventListener('click', event => {
  
  var traffic_log_click_ui_class_event_trgt= event.currentTarget;
  
  var traffic_log_wgt_card_title="";
  var traffic_log_wgt_card_prof_cols="";
  var traffic_log_wgt_card_data_btn="";

  if (!traffic_log_click_ui_class_event_trgt.hasAttribute("data-traffic_log_card_title")) 
  {
    // data attribute doesnt exist
  }else{
  
	 traffic_log_wgt_card_title=traffic_log_click_ui_class_event_trgt.getAttribute("data-traffic_log_card_title");
     
  }
  
  if (!traffic_log_click_ui_class_event_trgt.hasAttribute("data-traffic_log_prof_cols")) 
  {
    // data attribute doesnt exist
  }else{
	 traffic_log_wgt_card_prof_cols=traffic_log_click_ui_class_event_trgt.getAttribute("data-traffic_log_prof_cols");
  }


  
  if (!traffic_log_click_ui_class_event_trgt.hasAttribute("data-traffic_log_data_btn")) 
  {
    // data attribute doesnt exist
  }else{
	 traffic_log_wgt_card_data_btn=traffic_log_click_ui_class_event_trgt.getAttribute("data-traffic_log_data_btn");
  }
  
  var traffic_log_act_inp=traffic_log_input_wgt(traffic_log_wgt_card_prof_cols.split(','), traffic_log_wgt_card_data_btn,  traffic_log_wgt_card_title);
  
  push_html('actv_div',  traffic_log_act_inp); 
  
}));
  
////////////////// =================== traffic_log UI widget listener ================  


 var app_admins_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,ref_id:Payment Reference No.,regdate:Date,user_no:User No,user_pic:User Pic,user_gender:User Gender,last_seen:Last Seen,about:About";

 var apps_list_cols ="primkey:Primkey,appid:conn_appid|qapps_data($data_res['appid'])['apptitle'],apptitle:Apptitle,name:Name,run_at:Schedule date,app_key:App Key,secret:Secret,details:Post Details,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name']";

 var file_uploads_list_cols ="primkey:Primkey,media_key:Media Key,fileurl:Fileurl,file_tile:File Tile,file_tag:File Tag,post_blog:Post Blog";

 var keys_n_tokens_list_cols ="primkey:Primkey,tokenid:Tokenid,page_name:Page Name,appid:conn_appid|qapps_data($data_res['appid'])['apptitle'],regon:Regon,type:Type,descr:Descr,token:Token,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name']";

 var market_list_list_cols ="primkey:Primkey,marketid:Marketid,market_name:Market Name,market_page:Market Page,market_location:Market Location,post_content_to:Post Content To,remark:Remark";

 var messages_list_cols ="primkey:Primkey,message_id:Message Id,user_email:User Email,user_mobile:User Mobile,message_date:Message Date,message:Message,user_name:User Name,service_id:Service Id,service_name:Service Name,message_remark:Message Remark";

 var mosy_sql_roll_back_list_cols ="primkey:Primkey,roll_bk_key:Roll Bk Key,table_name:Table Name,roll_type:Roll Type,where_str:Where Str,roll_timestamp:Roll Timestamp,value_entries:Value Entries";

 var notes_admins_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,ref_id:Payment Reference No.,regdate:Date,user_no:User No,user_pic:User Pic,user_gender:User Gender,last_seen:Last Seen,about:About";

 var notes_list_list_cols ="primkey:Primkey,noteskey:Noteskey,note_title:Note Title,note_details:Note Details,note_date:Note Date,note_tag:Note Tag,user_id:User Id,note_remark:Note Remark,note_media:Note Media";

 var online_reception_list_cols ="primkey:Primkey,reckey:Reckey,page_logo:Page Logo,bg_image:Bg Image,page_name:Page Name,btn_clr:Btn Clr,btn_txt_clr:Btn Txt Clr,wild_clr:Wild Clr,action_link:Action Link,owner_id:Owner Id,page_descr:Page Descr,background_clr:Background Clr,background_text_clr:Background Text Clr,send_msg_title:Send Msg Title,send_btn_title:Send Btn Title,border_radius:Border Radius,navbar_clr:Navbar Clr,navbar_txt_clr:Navbar Txt Clr,telephone_:Telephone ";

 var page_links_list_cols ="primkey:Primkey,link_id:Link Id,link_name:Link Name,linkurl:Linkurl,descr:Descr,signature:Signature,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name']";

 var posting_log_list_cols ="primkey:Primkey,postkey:Postkey,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name'],marketid:Marketid,post_id:Post Id,ref_id:Payment Reference No.,request_date:Request Date";

 var posts_list_cols ="primkey:Primkey,msgid:Msgid,msg_titile:Message Title,msgposted:Msgposted,run_at:Schedule date,page:conn_page|qkeys_n_tokens_data($data_res['page'])['page_name'],link:Landing Page,details:Post Details,post_response:Post Response,signature:Signature,tweeted:Tweeted,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name'],post_image:Post Image,sharable_link:Sharable Link";

 var task_manager_list_cols ="primkey:Primkey,task_id:Task Id,project_id:Project Id,task_name:Task Name,task_status:Task Status,task_date:Task Date,task_remark:Task Remark,test_column:Test Column,assigned_to:Assigned To,task_comments:Task Comments,admin_remark:Admin Remark";

 var traffic_log_list_cols ="primkey:Primkey,schedule_id:Schedule Id,campaign_id:Campaign Id,channel_node:Channel Node,visit_time:Visit Time,visit_date:Visit Date,visitor_name:Visitor Name,page_visited:Page Visited,page_url:Page Url,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name'],source_url:Source Url,month_year:Month Year,ip_address:Ip Address,comment:Comment,source_page:Source Page,time_stamp:Time Stamp,user_id:User Id,log_data:Log Data,device:Device,browser:Browser";



 var app_admins_list_nodes=`<tr class="cpointer" onclick="mosy_card('App Admins Profile ', app_admins_input_wgt(app_admins_js_input,'app_admins_update_btn:Update:check-circle',''), '');initialize_app_admins(&quot where primkey='{{primkey}}'&quot;);push_newval('app_admins_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{regdate}}</td>
<td scope="col">{{user_no}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
</tr>`;


 var apps_list_nodes=`<tr class="cpointer" onclick="mosy_card('Apps Profile ', apps_input_wgt(apps_js_input,'apps_update_btn:Update:check-circle',''), '');initialize_apps(&quot where primkey='{{primkey}}'&quot;);push_newval('apps_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{apptitle}}</td>
<td scope="col">{{name}}</td>
<td scope="col">{{run_at}}</td>
<td scope="col">{{app_key}}</td>
<td scope="col">{{secret}}</td>
<td scope="col">{{details}}</td>
<td scope="col">{{conn_admin_id}}</td>
</tr>`;


 var file_uploads_list_nodes=`<tr class="cpointer" onclick="mosy_card('File Uploads Profile ', file_uploads_input_wgt(file_uploads_js_input,'file_uploads_update_btn:Update:check-circle',''), '');initialize_file_uploads(&quot where primkey='{{primkey}}'&quot;);push_newval('file_uploads_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{fileurl}}</td>
<td scope="col">{{file_tile}}</td>
<td scope="col">{{file_tag}}</td>
<td scope="col">{{post_blog}}</td>
</tr>`;


 var keys_n_tokens_list_nodes=`<tr class="cpointer" onclick="mosy_card('Media Pages Profile ', keys_n_tokens_input_wgt(keys_n_tokens_js_input,'keys_n_tokens_update_btn:Update:check-circle',''), '');initialize_keys_n_tokens(&quot where primkey='{{primkey}}'&quot;);push_newval('keys_n_tokens_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{page_name}}</td>
<td scope="col">{{conn_appid}}</td>
<td scope="col">{{regon}}</td>
<td scope="col">{{type}}</td>
<td scope="col">{{descr}}</td>
<td scope="col">{{token}}</td>
<td scope="col">{{conn_admin_id}}</td>
</tr>`;


 var market_list_list_nodes=`<tr class="cpointer" onclick="mosy_card('Market List Profile ', market_list_input_wgt(market_list_js_input,'market_list_update_btn:Update:check-circle',''), '');initialize_market_list(&quot where primkey='{{primkey}}'&quot;);push_newval('market_list_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{market_name}}</td>
<td scope="col">{{market_page}}</td>
<td scope="col">{{market_location}}</td>
<td scope="col">{{post_content_to}}</td>
<td scope="col">{{remark}}</td>
</tr>`;


 var messages_list_nodes=`<tr class="cpointer" onclick="mosy_card('Messages Profile ', messages_input_wgt(messages_js_input,'messages_update_btn:Update:check-circle',''), '');initialize_messages(&quot where primkey='{{primkey}}'&quot;);push_newval('messages_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{user_email}}</td>
<td scope="col">{{user_mobile}}</td>
<td scope="col">{{message_date}}</td>
<td scope="col">{{message}}</td>
<td scope="col">{{user_name}}</td>
<td scope="col">{{service_id}}</td>
<td scope="col">{{service_name}}</td>
<td scope="col">{{message_remark}}</td>
</tr>`;


 var mosy_sql_roll_back_list_nodes=`<tr class="cpointer" onclick="mosy_card('Mosy Sql Roll Back Profile ', mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input,'mosy_sql_roll_back_update_btn:Update:check-circle',''), '');initialize_mosy_sql_roll_back(&quot where primkey='{{primkey}}'&quot;);push_newval('mosy_sql_roll_back_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{table_name}}</td>
<td scope="col">{{roll_type}}</td>
<td scope="col">{{where_str}}</td>
<td scope="col">{{roll_timestamp}}</td>
<td scope="col">{{value_entries}}</td>
</tr>`;


 var notes_admins_list_nodes=`<tr class="cpointer" onclick="mosy_card('Notes Admins Profile ', notes_admins_input_wgt(notes_admins_js_input,'notes_admins_update_btn:Update:check-circle',''), '');initialize_notes_admins(&quot where primkey='{{primkey}}'&quot;);push_newval('notes_admins_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{regdate}}</td>
<td scope="col">{{user_no}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
</tr>`;


 var notes_list_list_nodes=`<tr class="cpointer" onclick="mosy_card('Notes List Profile ', notes_list_input_wgt(notes_list_js_input,'notes_list_update_btn:Update:check-circle',''), '');initialize_notes_list(&quot where primkey='{{primkey}}'&quot;);push_newval('notes_list_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{note_title}}</td>
<td scope="col">{{note_details}}</td>
<td scope="col">{{note_date}}</td>
<td scope="col">{{note_tag}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{note_remark}}</td>
<td scope="col">{{note_media}}</td>
</tr>`;


 var online_reception_list_nodes=`<tr class="cpointer" onclick="mosy_card('Online Reception Profile ', online_reception_input_wgt(online_reception_js_input,'online_reception_update_btn:Update:check-circle',''), '');initialize_online_reception(&quot where primkey='{{primkey}}'&quot;);push_newval('online_reception_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{page_logo}}</td>
<td scope="col">{{bg_image}}</td>
<td scope="col">{{page_name}}</td>
<td scope="col">{{btn_clr}}</td>
<td scope="col">{{btn_txt_clr}}</td>
<td scope="col">{{wild_clr}}</td>
<td scope="col">{{action_link}}</td>
<td scope="col">{{owner_id}}</td>
<td scope="col">{{page_descr}}</td>
<td scope="col">{{background_clr}}</td>
<td scope="col">{{background_text_clr}}</td>
<td scope="col">{{send_msg_title}}</td>
<td scope="col">{{send_btn_title}}</td>
<td scope="col">{{border_radius}}</td>
<td scope="col">{{navbar_clr}}</td>
<td scope="col">{{navbar_txt_clr}}</td>
<td scope="col">{{telephone_}}</td>
</tr>`;


 var page_links_list_nodes=`<tr class="cpointer" onclick="mosy_card('Landing Pages Profile ', page_links_input_wgt(page_links_js_input,'page_links_update_btn:Update:check-circle',''), '');initialize_page_links(&quot where primkey='{{primkey}}'&quot;);push_newval('page_links_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{link_name}}</td>
<td scope="col">{{linkurl}}</td>
<td scope="col">{{descr}}</td>
<td scope="col">{{signature}}</td>
<td scope="col">{{conn_admin_id}}</td>
</tr>`;


 var posting_log_list_nodes=`<tr class="cpointer" onclick="mosy_card('Posting Log Profile ', posting_log_input_wgt(posting_log_js_input,'posting_log_update_btn:Update:check-circle',''), '');initialize_posting_log(&quot where primkey='{{primkey}}'&quot;);push_newval('posting_log_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{conn_admin_id}}</td>
<td scope="col">{{marketid}}</td>
<td scope="col">{{post_id}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{request_date}}</td>
</tr>`;


 var posts_list_nodes=`<tr class="cpointer" onclick="mosy_card('Posts Profile ', posts_input_wgt(posts_js_input,'posts_update_btn:Update:check-circle',''), '');initialize_posts(&quot where primkey='{{primkey}}'&quot;);push_newval('posts_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{msg_titile}}</td>
<td scope="col">{{msgposted}}</td>
<td scope="col">{{run_at}}</td>
<td scope="col">{{conn_page}}</td>
<td scope="col">{{link}}</td>
<td scope="col">{{details}}</td>
<td scope="col">{{post_response}}</td>
<td scope="col">{{signature}}</td>
<td scope="col">{{tweeted}}</td>
<td scope="col">{{conn_admin_id}}</td>
<td scope="col">{{post_image}}</td>
<td scope="col">{{sharable_link}}</td>
</tr>`;


 var task_manager_list_nodes=`<tr class="cpointer" onclick="mosy_card('Task Manager Profile ', task_manager_input_wgt(task_manager_js_input,'task_manager_update_btn:Update:check-circle',''), '');initialize_task_manager(&quot where primkey='{{primkey}}'&quot;);push_newval('task_manager_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{project_id}}</td>
<td scope="col">{{task_name}}</td>
<td scope="col">{{task_status}}</td>
<td scope="col">{{task_date}}</td>
<td scope="col">{{task_remark}}</td>
<td scope="col">{{test_column}}</td>
<td scope="col">{{assigned_to}}</td>
<td scope="col">{{task_comments}}</td>
<td scope="col">{{admin_remark}}</td>
</tr>`;


 var traffic_log_list_nodes=`<tr class="cpointer" onclick="mosy_card('Traffic Log Profile ', traffic_log_input_wgt(traffic_log_js_input,'traffic_log_update_btn:Update:check-circle',''), '');initialize_traffic_log(&quot where primkey='{{primkey}}'&quot;);push_newval('traffic_log_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{campaign_id}}</td>
<td scope="col">{{channel_node}}</td>
<td scope="col">{{visit_time}}</td>
<td scope="col">{{visit_date}}</td>
<td scope="col">{{visitor_name}}</td>
<td scope="col">{{page_visited}}</td>
<td scope="col">{{page_url}}</td>
<td scope="col">{{conn_admin_id}}</td>
<td scope="col">{{source_url}}</td>
<td scope="col">{{ip_address}}</td>
<td scope="col">{{comment}}</td>
<td scope="col">{{source_page}}</td>
<td scope="col">{{time_stamp}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{log_data}}</td>
<td scope="col">{{device}}</td>
<td scope="col">{{browser}}</td>
</tr>`;



        var app_admins_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="app_admins_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Payment Reference No.</th>
             <th scope="col">Date</th>
             <th scope="col">User No</th>
             <th scope="col">User Gender</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>

		   </tr>
	    </thead>
	    <tbody id="app_admins_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var apps_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="apps_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Apptitle</th>
             <th scope="col">Name</th>
             <th scope="col">Schedule date</th>
             <th scope="col">App Key</th>
             <th scope="col">Secret</th>
             <th scope="col">Post Details</th>
             <th scope="col">Admin Id</th>

		   </tr>
	    </thead>
	    <tbody id="apps_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var file_uploads_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="file_uploads_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Fileurl</th>
             <th scope="col">File Tile</th>
             <th scope="col">File Tag</th>
             <th scope="col">Post Blog</th>

		   </tr>
	    </thead>
	    <tbody id="file_uploads_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var keys_n_tokens_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="keys_n_tokens_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Page Name</th>
             <th scope="col">Appid</th>
             <th scope="col">Regon</th>
             <th scope="col">Type</th>
             <th scope="col">Descr</th>
             <th scope="col">Token</th>
             <th scope="col">Admin Id</th>

		   </tr>
	    </thead>
	    <tbody id="keys_n_tokens_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var market_list_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="market_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Market Name</th>
             <th scope="col">Market Page</th>
             <th scope="col">Market Location</th>
             <th scope="col">Post Content To</th>
             <th scope="col">Remark</th>

		   </tr>
	    </thead>
	    <tbody id="market_list_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var messages_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="messages_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Email</th>
             <th scope="col">User Mobile</th>
             <th scope="col">Message Date</th>
             <th scope="col">Message</th>
             <th scope="col">User Name</th>
             <th scope="col">Service Id</th>
             <th scope="col">Service Name</th>
             <th scope="col">Message Remark</th>

		   </tr>
	    </thead>
	    <tbody id="messages_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var mosy_sql_roll_back_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="mosy_sql_roll_back_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Table Name</th>
             <th scope="col">Roll Type</th>
             <th scope="col">Where Str</th>
             <th scope="col">Roll Timestamp</th>
             <th scope="col">Value Entries</th>

		   </tr>
	    </thead>
	    <tbody id="mosy_sql_roll_back_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var notes_admins_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="notes_admins_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Payment Reference No.</th>
             <th scope="col">Date</th>
             <th scope="col">User No</th>
             <th scope="col">User Gender</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>

		   </tr>
	    </thead>
	    <tbody id="notes_admins_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var notes_list_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="notes_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Note Title</th>
             <th scope="col">Note Details</th>
             <th scope="col">Note Date</th>
             <th scope="col">Note Tag</th>
             <th scope="col">User Id</th>
             <th scope="col">Note Remark</th>
             <th scope="col">Note Media</th>

		   </tr>
	    </thead>
	    <tbody id="notes_list_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var online_reception_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="online_reception_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Page Logo</th>
             <th scope="col">Bg Image</th>
             <th scope="col">Page Name</th>
             <th scope="col">Btn Clr</th>
             <th scope="col">Btn Txt Clr</th>
             <th scope="col">Wild Clr</th>
             <th scope="col">Action Link</th>
             <th scope="col">Owner Id</th>
             <th scope="col">Page Descr</th>
             <th scope="col">Background Clr</th>
             <th scope="col">Background Text Clr</th>
             <th scope="col">Send Msg Title</th>
             <th scope="col">Send Btn Title</th>
             <th scope="col">Border Radius</th>
             <th scope="col">Navbar Clr</th>
             <th scope="col">Navbar Txt Clr</th>
             <th scope="col">Telephone </th>

		   </tr>
	    </thead>
	    <tbody id="online_reception_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var page_links_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="page_links_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Link Name</th>
             <th scope="col">Linkurl</th>
             <th scope="col">Descr</th>
             <th scope="col">Signature</th>
             <th scope="col">Admin Id</th>

		   </tr>
	    </thead>
	    <tbody id="page_links_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var posting_log_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="posting_log_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Admin Id</th>
             <th scope="col">Marketid</th>
             <th scope="col">Post Id</th>
             <th scope="col">Payment Reference No.</th>
             <th scope="col">Request Date</th>

		   </tr>
	    </thead>
	    <tbody id="posting_log_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var posts_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="posts_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Message Title</th>
             <th scope="col">Msgposted</th>
             <th scope="col">Schedule date</th>
             <th scope="col">Social Media Page</th>
             <th scope="col">Landing Page</th>
             <th scope="col">Post Details</th>
             <th scope="col">Post Response</th>
             <th scope="col">Signature</th>
             <th scope="col">Tweeted</th>
             <th scope="col">Admin Id</th>
             <th scope="col">Post Image</th>
             <th scope="col">Sharable Link</th>

		   </tr>
	    </thead>
	    <tbody id="posts_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var task_manager_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="task_manager_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Project Id</th>
             <th scope="col">Task Name</th>
             <th scope="col">Task Status</th>
             <th scope="col">Task Date</th>
             <th scope="col">Task Remark</th>
             <th scope="col">Test Column</th>
             <th scope="col">Assigned To</th>
             <th scope="col">Task Comments</th>
             <th scope="col">Admin Remark</th>

		   </tr>
	    </thead>
	    <tbody id="task_manager_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var traffic_log_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="traffic_log_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Campaign Id</th>
             <th scope="col">Channel Node</th>
             <th scope="col">Visit Time</th>
             <th scope="col">Visit Date</th>
             <th scope="col">Visitor Name</th>
             <th scope="col">Page Visited</th>
             <th scope="col">Page Url</th>
             <th scope="col">Admin Id</th>
             <th scope="col">Source Url</th>
             <th scope="col">Month Year</th>
             <th scope="col">Ip Address</th>
             <th scope="col">Comment</th>
             <th scope="col">Source Page</th>
             <th scope="col">Time Stamp</th>
             <th scope="col">User Id</th>
             <th scope="col">Log Data</th>
             <th scope="col">Device</th>
             <th scope="col">Browser</th>

		   </tr>
	    </thead>
	    <tbody id="traffic_log_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
