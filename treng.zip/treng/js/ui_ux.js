//<!--next_ajax_str-->
var empty_notes =`
  <div class="row justify-content-center cpointer m-0 p-0 col-md-12" onclick="mosytoggle_class('note_tray', 'shadow-lg');mosytoggle_class('note_tray', 'auto_bounce'); " >
    <div class="col-md-12 text-center pt-4 "><span class="">No Notes Found</span></div>
    <div class="col-md-12 text-center p-2 mt-2"><span class="cpointer border border_set rounded_medium p-2" > Click <span class="text-info"> here to</span> add a note </span></div>
  </div>
`;

var empty_notes_nav =`
  <div class="row justify-content-center cpointer m-0 p-0 col-md-12" onclick="new_location('notelist')" >
    <div class="col-md-12 text-center pt-4 "><span class="">No Notes Found</span></div>
    <div class="col-md-12 text-center p-2 mt-2"><span class="cpointer border border_set rounded_medium p-2" > Click <span class="text-info"> here to</span> add a note </span></div>
  </div>
`;

function load_notes_to (load_to='', empty_ui='empty_notes')
{

  var html_qloc= `
    <div class="row justify-content-center m-0 p-0 col-md-12 ">
    <input type="text" placeholder="Search notes" id="" class="form-control mb-2" onkeyup="quser_loc_data(this.value, '${empty_ui}')"/>
                 <div class="row justify-content-end m-0 p-0 col-md-12 cpointer">
                  <span class="mr-2 col-md-5 text-dark badge p-0 cpointer " onclick="mosy_prev_page('txt_note_tkn');quser_loc_data(get_newval('qstock_list'), '${empty_ui}')"><i class="fa fa-arrow-left p-2"></i>Prev</span>
                  <span class="ml-2 col-md-5 text-dark badge p-0 cpointer " onclick="mosy_next_page('txt_note_tkn');quser_loc_data(get_newval('qstock_list'), '${empty_ui}')"><i class="fa fa-arrow-right p-2"></i>Next</span>
                  <input type="hidden" id="txt_note_tkn"/>                
                </div>
    </div>
    <div class="row justify-content-left m-0 col-md-12 mt-2 " id="stock_tray_tbl" style="max-height:80vh; overflow-y:auto;"></div>
    <template id="loop_node_">                     
  		<!-- Start side bar image card list -->
          <div onclick="push_newval('notes_list_uptoken', btoa('{{primkey}}'));initialize_notes_list();push_html('alert_box', '')" class="row mb-2 bg-white rounded_medium cpointer text-dark mb-2 pt-2 pb-2 justify-content-center m-0 col-md-12  border-bottom shadow-sm">
            <div class="col-4 p-0">
              <img src="{{note_media}}" class=" " onerror="this.src='img/logo.png'" style="width:50px; height:50px; border-radius:50%;" id="note_media_src"/>
            </div>
            <div class="col-8  text-left p-0" style="font-size:12px">
              <div class="text-muted trim_text" ><b>{{note_title}}</b></div>
              <div><div class="text-muted trim_text">{{note_details}}</div></div>
              <div class="border-top"><div class="text-muted trim_text" >{{note_date}}</div></div>
              <div class="border-top"><div class="text-muted trim_text" >{{note_tag}}</div></div>
            </div>
          </a>
          <!-- End side bar image card list-->
    </template>
    `;
  
   mosy_card('', html_qloc,load_to);
   quser_loc_data('', empty_ui);
}

function quser_loc_data(qstr="",empty_ui='empty_notes')
{
  		 var mosyfilter ="";
  
  		 var mosyfilter_get=mosy_get_param(('notes_list_mosyfilter'));
  
         if(mosyfilter_get!==undefined)
         {
           mosyfilter=atob(mosyfilter_get);
         }
///alert(empty_ui);
	qkload_notes_list(qstr, 'push_grid_result:stock_tray_tbl:0:'+empty_ui, get_html('loop_node_'), mosyfilter, 'primkey:viewmsg|base64_encode($data_res[\'primkey\'])','qnotes:'+get_newval('txt_note_tkn'));
  
}


function loan_serv_notes()
{
  
  quser_loc_data();
  
}


var upload_img_card =`
              <div class="row justify-content-center m-0 p-0 col-md-12 border  rounded_big p-1">
  				<div class="col-md-3 " >
                  <label class="  badge text-secondary cpointer pt-3">
                  <i class="fa fa-upload"></i> Upload Image <em id="txt_file_path_str" class="trim_text"></em>
                  <input type="file" id="txt_file_uploads_filr_url"  name="txt_file_uploads_filr_url" style="display: none;" onchange="push_html('txt_file_path_str', (this.value).replace('C:\\fakepath\\', ' | '))">
                </label>  
              	</div>
				<div class="row justify-content-center m-0 p-0 col-md-9">
                  <div class="col-md-12 pt-2" id="">
    				<span id="" name="" class="badge border col-md-4 cpointer rounded_medium ml-3 p-2 mosy_msdn " data-mosy_msdn="notes_list_ins_('model_form', ['txt_note_details:Note detail required','txt_note_tag'],'loan_serv_notes')" > <i class="fa fa-check-circle"></i> Add as new </span>          	  
    			          	  
                  </div>
              	</div> 
                <div class="col-md-12 ">
                 <img src="img/bg__.jpg" class="" style="max-width:100%; max-height:90vh; " id=""/>                
                </div>
  			</div>
  
  `;


var calc_ui=`
<div class="row justify-content-center m-0 p-0 col-md-12">
 <input typ="text" class="col-md-12 bg-light p-3 border mb-3 h1 text-right" title="Click To Clear Screen" id="screen"/>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+1)">1</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+2)">2</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+3)">3</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+4)">4</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+5)">5</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+6)">6</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+7)">7</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+8)">8</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+9)">9</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+0)">0</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'*')">*</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'+')">+</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'-')">-</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'/')">/</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'='+eval(get_newval('screen')));push_newval('notes', get_newval('notes')+'|'+get_newval('screen'))">=</div>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  <input class="border-0" style="" id="notes" placeholder="notes"></input> </div>
  </div>
</div>  
  
  
`;