
 var app_admins_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,ref_id:Payment Reference No.,regdate:Date,user_no:User No,user_pic:User Pic,user_gender:User Gender,last_seen:Last Seen,about:About";

 var apps_list_cols ="primkey:Primkey,appid:conn_appid|qapps_data($data_res['appid'])['apptitle'],apptitle:Apptitle,name:Name,run_at:Schedule date,app_key:App Key,secret:Secret,details:Post Details,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name']";

 var file_uploads_list_cols ="primkey:Primkey,media_key:Media Key,fileurl:Fileurl,file_tile:File Tile,file_tag:File Tag,post_blog:Post Blog";

 var keys_n_tokens_list_cols ="primkey:Primkey,tokenid:Tokenid,page_name:Page Name,appid:conn_appid|qapps_data($data_res['appid'])['apptitle'],regon:Regon,type:Type,descr:Descr,token:Token,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name']";

 var market_list_list_cols ="primkey:Primkey,marketid:Marketid,market_name:Market Name,market_page:Market Page,market_location:Market Location,post_content_to:Post Content To,remark:Remark";

 var messages_list_cols ="primkey:Primkey,message_id:Message Id,user_email:User Email,user_mobile:User Mobile,message_date:Message Date,message:Message,user_name:User Name,service_id:Service Id,service_name:Service Name,message_remark:Message Remark";

 var mosy_sql_roll_back_list_cols ="primkey:Primkey,roll_bk_key:Roll Bk Key,table_name:Table Name,roll_type:Roll Type,where_str:Where Str,roll_timestamp:Roll Timestamp,value_entries:Value Entries";

 var notes_admins_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,ref_id:Payment Reference No.,regdate:Date,user_no:User No,user_pic:User Pic,user_gender:User Gender,last_seen:Last Seen,about:About";

 var notes_list_list_cols ="primkey:Primkey,noteskey:Noteskey,note_title:Note Title,note_details:Note Details,note_date:Note Date,note_tag:Note Tag,user_id:User Id,note_remark:Note Remark,note_media:Note Media";

 var online_reception_list_cols ="primkey:Primkey,reckey:Reckey,page_logo:Page Logo,bg_image:Bg Image,page_name:Page Name,btn_clr:Btn Clr,btn_txt_clr:Btn Txt Clr,wild_clr:Wild Clr,action_link:Action Link,owner_id:Owner Id,page_descr:Page Descr,background_clr:Background Clr,background_text_clr:Background Text Clr,send_msg_title:Send Msg Title,send_btn_title:Send Btn Title,border_radius:Border Radius,navbar_clr:Navbar Clr,navbar_txt_clr:Navbar Txt Clr,telephone_:Telephone ";

 var page_links_list_cols ="primkey:Primkey,link_id:Link Id,link_name:Link Name,linkurl:Linkurl,descr:Descr,signature:Signature,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name']";

 var posting_log_list_cols ="primkey:Primkey,postkey:Postkey,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name'],marketid:Marketid,post_id:Post Id,ref_id:Payment Reference No.,request_date:Request Date";

 var posts_list_cols ="primkey:Primkey,msgid:Msgid,msg_titile:Message Title,msgposted:Msgposted,run_at:Schedule date,page:conn_page|qkeys_n_tokens_data($data_res['page'])['page_name'],link:Landing Page,details:Post Details,post_response:Post Response,signature:Signature,tweeted:Tweeted,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name'],post_image:Post Image,sharable_link:Sharable Link";

 var task_manager_list_cols ="primkey:Primkey,task_id:Task Id,project_id:Project Id,task_name:Task Name,task_status:Task Status,task_date:Task Date,task_remark:Task Remark,test_column:Test Column,assigned_to:Assigned To,task_comments:Task Comments,admin_remark:Admin Remark";

 var traffic_log_list_cols ="primkey:Primkey,schedule_id:Schedule Id,campaign_id:Campaign Id,channel_node:Channel Node,visit_time:Visit Time,visit_date:Visit Date,visitor_name:Visitor Name,page_visited:Page Visited,page_url:Page Url,admin_id:conn_admin_id|qapp_admins_data($data_res['admin_id'])['name'],source_url:Source Url,month_year:Month Year,ip_address:Ip Address,comment:Comment,source_page:Source Page,time_stamp:Time Stamp,user_id:User Id,log_data:Log Data,device:Device,browser:Browser";



 var app_admins_list_nodes=`<tr class="cpointer" onclick="mosy_card('App Admins Profile ', app_admins_input_wgt(app_admins_js_input,'app_admins_update_btn:Update:check-circle',''), '');initialize_app_admins(&quot where primkey='{{primkey}}'&quot;);push_newval('app_admins_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{regdate}}</td>
<td scope="col">{{user_no}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
</tr>`;


 var apps_list_nodes=`<tr class="cpointer" onclick="mosy_card('Apps Profile ', apps_input_wgt(apps_js_input,'apps_update_btn:Update:check-circle',''), '');initialize_apps(&quot where primkey='{{primkey}}'&quot;);push_newval('apps_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{apptitle}}</td>
<td scope="col">{{name}}</td>
<td scope="col">{{run_at}}</td>
<td scope="col">{{app_key}}</td>
<td scope="col">{{secret}}</td>
<td scope="col">{{details}}</td>
<td scope="col">{{conn_admin_id}}</td>
</tr>`;


 var file_uploads_list_nodes=`<tr class="cpointer" onclick="mosy_card('File Uploads Profile ', file_uploads_input_wgt(file_uploads_js_input,'file_uploads_update_btn:Update:check-circle',''), '');initialize_file_uploads(&quot where primkey='{{primkey}}'&quot;);push_newval('file_uploads_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{fileurl}}</td>
<td scope="col">{{file_tile}}</td>
<td scope="col">{{file_tag}}</td>
<td scope="col">{{post_blog}}</td>
</tr>`;


 var keys_n_tokens_list_nodes=`<tr class="cpointer" onclick="mosy_card('Media Pages Profile ', keys_n_tokens_input_wgt(keys_n_tokens_js_input,'keys_n_tokens_update_btn:Update:check-circle',''), '');initialize_keys_n_tokens(&quot where primkey='{{primkey}}'&quot;);push_newval('keys_n_tokens_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{page_name}}</td>
<td scope="col">{{conn_appid}}</td>
<td scope="col">{{regon}}</td>
<td scope="col">{{type}}</td>
<td scope="col">{{descr}}</td>
<td scope="col">{{token}}</td>
<td scope="col">{{conn_admin_id}}</td>
</tr>`;


 var market_list_list_nodes=`<tr class="cpointer" onclick="mosy_card('Market List Profile ', market_list_input_wgt(market_list_js_input,'market_list_update_btn:Update:check-circle',''), '');initialize_market_list(&quot where primkey='{{primkey}}'&quot;);push_newval('market_list_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{market_name}}</td>
<td scope="col">{{market_page}}</td>
<td scope="col">{{market_location}}</td>
<td scope="col">{{post_content_to}}</td>
<td scope="col">{{remark}}</td>
</tr>`;


 var messages_list_nodes=`<tr class="cpointer" onclick="mosy_card('Messages Profile ', messages_input_wgt(messages_js_input,'messages_update_btn:Update:check-circle',''), '');initialize_messages(&quot where primkey='{{primkey}}'&quot;);push_newval('messages_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{user_email}}</td>
<td scope="col">{{user_mobile}}</td>
<td scope="col">{{message_date}}</td>
<td scope="col">{{message}}</td>
<td scope="col">{{user_name}}</td>
<td scope="col">{{service_id}}</td>
<td scope="col">{{service_name}}</td>
<td scope="col">{{message_remark}}</td>
</tr>`;


 var mosy_sql_roll_back_list_nodes=`<tr class="cpointer" onclick="mosy_card('Mosy Sql Roll Back Profile ', mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input,'mosy_sql_roll_back_update_btn:Update:check-circle',''), '');initialize_mosy_sql_roll_back(&quot where primkey='{{primkey}}'&quot;);push_newval('mosy_sql_roll_back_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{table_name}}</td>
<td scope="col">{{roll_type}}</td>
<td scope="col">{{where_str}}</td>
<td scope="col">{{roll_timestamp}}</td>
<td scope="col">{{value_entries}}</td>
</tr>`;


 var notes_admins_list_nodes=`<tr class="cpointer" onclick="mosy_card('Notes Admins Profile ', notes_admins_input_wgt(notes_admins_js_input,'notes_admins_update_btn:Update:check-circle',''), '');initialize_notes_admins(&quot where primkey='{{primkey}}'&quot;);push_newval('notes_admins_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{regdate}}</td>
<td scope="col">{{user_no}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
</tr>`;


 var notes_list_list_nodes=`<tr class="cpointer" onclick="mosy_card('Notes List Profile ', notes_list_input_wgt(notes_list_js_input,'notes_list_update_btn:Update:check-circle',''), '');initialize_notes_list(&quot where primkey='{{primkey}}'&quot;);push_newval('notes_list_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{note_title}}</td>
<td scope="col">{{note_details}}</td>
<td scope="col">{{note_date}}</td>
<td scope="col">{{note_tag}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{note_remark}}</td>
<td scope="col">{{note_media}}</td>
</tr>`;


 var online_reception_list_nodes=`<tr class="cpointer" onclick="mosy_card('Online Reception Profile ', online_reception_input_wgt(online_reception_js_input,'online_reception_update_btn:Update:check-circle',''), '');initialize_online_reception(&quot where primkey='{{primkey}}'&quot;);push_newval('online_reception_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{page_logo}}</td>
<td scope="col">{{bg_image}}</td>
<td scope="col">{{page_name}}</td>
<td scope="col">{{btn_clr}}</td>
<td scope="col">{{btn_txt_clr}}</td>
<td scope="col">{{wild_clr}}</td>
<td scope="col">{{action_link}}</td>
<td scope="col">{{owner_id}}</td>
<td scope="col">{{page_descr}}</td>
<td scope="col">{{background_clr}}</td>
<td scope="col">{{background_text_clr}}</td>
<td scope="col">{{send_msg_title}}</td>
<td scope="col">{{send_btn_title}}</td>
<td scope="col">{{border_radius}}</td>
<td scope="col">{{navbar_clr}}</td>
<td scope="col">{{navbar_txt_clr}}</td>
<td scope="col">{{telephone_}}</td>
</tr>`;


 var page_links_list_nodes=`<tr class="cpointer" onclick="mosy_card('Landing Pages Profile ', page_links_input_wgt(page_links_js_input,'page_links_update_btn:Update:check-circle',''), '');initialize_page_links(&quot where primkey='{{primkey}}'&quot;);push_newval('page_links_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{link_name}}</td>
<td scope="col">{{linkurl}}</td>
<td scope="col">{{descr}}</td>
<td scope="col">{{signature}}</td>
<td scope="col">{{conn_admin_id}}</td>
</tr>`;


 var posting_log_list_nodes=`<tr class="cpointer" onclick="mosy_card('Posting Log Profile ', posting_log_input_wgt(posting_log_js_input,'posting_log_update_btn:Update:check-circle',''), '');initialize_posting_log(&quot where primkey='{{primkey}}'&quot;);push_newval('posting_log_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{conn_admin_id}}</td>
<td scope="col">{{marketid}}</td>
<td scope="col">{{post_id}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{request_date}}</td>
</tr>`;


 var posts_list_nodes=`<tr class="cpointer" onclick="mosy_card('Posts Profile ', posts_input_wgt(posts_js_input,'posts_update_btn:Update:check-circle',''), '');initialize_posts(&quot where primkey='{{primkey}}'&quot;);push_newval('posts_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{msg_titile}}</td>
<td scope="col">{{msgposted}}</td>
<td scope="col">{{run_at}}</td>
<td scope="col">{{conn_page}}</td>
<td scope="col">{{link}}</td>
<td scope="col">{{details}}</td>
<td scope="col">{{post_response}}</td>
<td scope="col">{{signature}}</td>
<td scope="col">{{tweeted}}</td>
<td scope="col">{{conn_admin_id}}</td>
<td scope="col">{{post_image}}</td>
<td scope="col">{{sharable_link}}</td>
</tr>`;


 var task_manager_list_nodes=`<tr class="cpointer" onclick="mosy_card('Task Manager Profile ', task_manager_input_wgt(task_manager_js_input,'task_manager_update_btn:Update:check-circle',''), '');initialize_task_manager(&quot where primkey='{{primkey}}'&quot;);push_newval('task_manager_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{project_id}}</td>
<td scope="col">{{task_name}}</td>
<td scope="col">{{task_status}}</td>
<td scope="col">{{task_date}}</td>
<td scope="col">{{task_remark}}</td>
<td scope="col">{{test_column}}</td>
<td scope="col">{{assigned_to}}</td>
<td scope="col">{{task_comments}}</td>
<td scope="col">{{admin_remark}}</td>
</tr>`;


 var traffic_log_list_nodes=`<tr class="cpointer" onclick="mosy_card('Traffic Log Profile ', traffic_log_input_wgt(traffic_log_js_input,'traffic_log_update_btn:Update:check-circle',''), '');initialize_traffic_log(&quot where primkey='{{primkey}}'&quot;);push_newval('traffic_log_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{campaign_id}}</td>
<td scope="col">{{channel_node}}</td>
<td scope="col">{{visit_time}}</td>
<td scope="col">{{visit_date}}</td>
<td scope="col">{{visitor_name}}</td>
<td scope="col">{{page_visited}}</td>
<td scope="col">{{page_url}}</td>
<td scope="col">{{conn_admin_id}}</td>
<td scope="col">{{source_url}}</td>
<td scope="col">{{ip_address}}</td>
<td scope="col">{{comment}}</td>
<td scope="col">{{source_page}}</td>
<td scope="col">{{time_stamp}}</td>
<td scope="col">{{user_id}}</td>
<td scope="col">{{log_data}}</td>
<td scope="col">{{device}}</td>
<td scope="col">{{browser}}</td>
</tr>`;



        var app_admins_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="app_admins_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Payment Reference No.</th>
             <th scope="col">Date</th>
             <th scope="col">User No</th>
             <th scope="col">User Gender</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>

		   </tr>
	    </thead>
	    <tbody id="app_admins_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var apps_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="apps_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Apptitle</th>
             <th scope="col">Name</th>
             <th scope="col">Schedule date</th>
             <th scope="col">App Key</th>
             <th scope="col">Secret</th>
             <th scope="col">Post Details</th>
             <th scope="col">Admin Id</th>

		   </tr>
	    </thead>
	    <tbody id="apps_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var file_uploads_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="file_uploads_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Fileurl</th>
             <th scope="col">File Tile</th>
             <th scope="col">File Tag</th>
             <th scope="col">Post Blog</th>

		   </tr>
	    </thead>
	    <tbody id="file_uploads_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var keys_n_tokens_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="keys_n_tokens_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Page Name</th>
             <th scope="col">Appid</th>
             <th scope="col">Regon</th>
             <th scope="col">Type</th>
             <th scope="col">Descr</th>
             <th scope="col">Token</th>
             <th scope="col">Admin Id</th>

		   </tr>
	    </thead>
	    <tbody id="keys_n_tokens_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var market_list_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="market_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Market Name</th>
             <th scope="col">Market Page</th>
             <th scope="col">Market Location</th>
             <th scope="col">Post Content To</th>
             <th scope="col">Remark</th>

		   </tr>
	    </thead>
	    <tbody id="market_list_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var messages_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="messages_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">User Email</th>
             <th scope="col">User Mobile</th>
             <th scope="col">Message Date</th>
             <th scope="col">Message</th>
             <th scope="col">User Name</th>
             <th scope="col">Service Id</th>
             <th scope="col">Service Name</th>
             <th scope="col">Message Remark</th>

		   </tr>
	    </thead>
	    <tbody id="messages_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var mosy_sql_roll_back_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="mosy_sql_roll_back_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Table Name</th>
             <th scope="col">Roll Type</th>
             <th scope="col">Where Str</th>
             <th scope="col">Roll Timestamp</th>
             <th scope="col">Value Entries</th>

		   </tr>
	    </thead>
	    <tbody id="mosy_sql_roll_back_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var notes_admins_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="notes_admins_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Payment Reference No.</th>
             <th scope="col">Date</th>
             <th scope="col">User No</th>
             <th scope="col">User Gender</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>

		   </tr>
	    </thead>
	    <tbody id="notes_admins_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var notes_list_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="notes_list_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Note Title</th>
             <th scope="col">Note Details</th>
             <th scope="col">Note Date</th>
             <th scope="col">Note Tag</th>
             <th scope="col">User Id</th>
             <th scope="col">Note Remark</th>
             <th scope="col">Note Media</th>

		   </tr>
	    </thead>
	    <tbody id="notes_list_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var online_reception_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="online_reception_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Page Logo</th>
             <th scope="col">Bg Image</th>
             <th scope="col">Page Name</th>
             <th scope="col">Btn Clr</th>
             <th scope="col">Btn Txt Clr</th>
             <th scope="col">Wild Clr</th>
             <th scope="col">Action Link</th>
             <th scope="col">Owner Id</th>
             <th scope="col">Page Descr</th>
             <th scope="col">Background Clr</th>
             <th scope="col">Background Text Clr</th>
             <th scope="col">Send Msg Title</th>
             <th scope="col">Send Btn Title</th>
             <th scope="col">Border Radius</th>
             <th scope="col">Navbar Clr</th>
             <th scope="col">Navbar Txt Clr</th>
             <th scope="col">Telephone </th>

		   </tr>
	    </thead>
	    <tbody id="online_reception_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var page_links_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="page_links_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Link Name</th>
             <th scope="col">Linkurl</th>
             <th scope="col">Descr</th>
             <th scope="col">Signature</th>
             <th scope="col">Admin Id</th>

		   </tr>
	    </thead>
	    <tbody id="page_links_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var posting_log_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="posting_log_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Admin Id</th>
             <th scope="col">Marketid</th>
             <th scope="col">Post Id</th>
             <th scope="col">Payment Reference No.</th>
             <th scope="col">Request Date</th>

		   </tr>
	    </thead>
	    <tbody id="posting_log_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var posts_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="posts_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Message Title</th>
             <th scope="col">Msgposted</th>
             <th scope="col">Schedule date</th>
             <th scope="col">Social Media Page</th>
             <th scope="col">Landing Page</th>
             <th scope="col">Post Details</th>
             <th scope="col">Post Response</th>
             <th scope="col">Signature</th>
             <th scope="col">Tweeted</th>
             <th scope="col">Admin Id</th>
             <th scope="col">Post Image</th>
             <th scope="col">Sharable Link</th>

		   </tr>
	    </thead>
	    <tbody id="posts_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var task_manager_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="task_manager_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Project Id</th>
             <th scope="col">Task Name</th>
             <th scope="col">Task Status</th>
             <th scope="col">Task Date</th>
             <th scope="col">Task Remark</th>
             <th scope="col">Test Column</th>
             <th scope="col">Assigned To</th>
             <th scope="col">Task Comments</th>
             <th scope="col">Admin Remark</th>

		   </tr>
	    </thead>
	    <tbody id="task_manager_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var traffic_log_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="traffic_log_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Campaign Id</th>
             <th scope="col">Channel Node</th>
             <th scope="col">Visit Time</th>
             <th scope="col">Visit Date</th>
             <th scope="col">Visitor Name</th>
             <th scope="col">Page Visited</th>
             <th scope="col">Page Url</th>
             <th scope="col">Admin Id</th>
             <th scope="col">Source Url</th>
             <th scope="col">Month Year</th>
             <th scope="col">Ip Address</th>
             <th scope="col">Comment</th>
             <th scope="col">Source Page</th>
             <th scope="col">Time Stamp</th>
             <th scope="col">User Id</th>
             <th scope="col">Log Data</th>
             <th scope="col">Device</th>
             <th scope="col">Browser</th>

		   </tr>
	    </thead>
	    <tbody id="traffic_log_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
