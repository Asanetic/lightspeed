<?php
ob_start();

$curlopt_url='https://origin.clearphrases.com/treng/landingapi.php';
$landing_page="VHF9T4D";
$curlopt_post_fields="landing_page=".$landing_page."";

$curr_page_attr= magic_post_curl($curlopt_url, "", "", $curlopt_post_fields, "POST");

$page_key=json_decode($curr_page_attr, true);

///echo $page_key['page_descr']
  

if(isset($_POST['send_msg']))
{
  
 $adminid="Meganet";
 $curlopt_post_fields="receive_message&txt_user_email=".base64_encode($_POST['txt_user_email'])."&txt_user_mobile=".base64_encode($_POST['txt_user_mobile'])."&txt_message=".base64_encode($_POST['txt_message'])."&txt_user_name=".base64_encode($_POST['txt_user_name'])."&admin_id=".base64_encode($adminid);

echo magic_post_curl($curlopt_url, "", "", $curlopt_post_fields, "POST"); 
  
}
?>