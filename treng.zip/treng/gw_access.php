<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


 $parent_path=[
'http://localhost/origin/leadspro/',
//{{next_root_str}}
];

$active_parent_dir=date('dmyhisa');
if(isset($_SESSION[$mosy_gw_appname.'active_parent_dir'])){
 $active_parent_dir=$_SESSION[$mosy_gw_appname.'active_parent_dir'];
 ///echo $active_parent_dir;
}
$access_arr=[

    ///start access clearance array for $active_parent_dir.'adminlist.php
    $active_parent_dir.'adminlist.php'=>
      [
      'notes_admins'=>['select','qnotes_admins_btn','get_qnotes_admins','insert','update','{{next_adminlist.php_notes_admins}}'],
        
      'mosy_sql_roll_back'=>['insert','{{next_adminlist.php_mosy_sql_roll_back}}'],
      
      'notes_list'=>['select','{{next_adminlist.php_notes_list}}'],
      //next_adminlist.php_access

      ],
      ///end access clearance array for $active_parent_dir.'adminlist.php

      
    ///start access clearance array for $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php
    $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php'=>
      [
      'notes_admins'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_notes_admins}}'],
        
      'notes_list'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_notes_list}}'],
      
      'file_uploads'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_file_uploads}}'],
      
      'task_manager'=>['select','{{next_load_preview_iframe_23_01_21_438pm.php_task_manager}}'],
      //next_load_preview_iframe_23_01_21_438pm.php_access

      ],
      ///end access clearance array for $active_parent_dir.'load_preview_iframe_23_01_21_438pm.php

      
    ///start access clearance array for $active_parent_dir.'notelist.php
    $active_parent_dir.'notelist.php'=>
      [
      'notes_list'=>['select','notes_list_mosyfilter','{{next_notelist.php_notes_list}}'],
        //next_notelist.php_access

      ],
      ///end access clearance array for $active_parent_dir.'notelist.php

      
    ///start access clearance array for $active_parent_dir.'ajaxreqhandler.php
    $active_parent_dir.'ajaxreqhandler.php'=>
      [
      'notes_list'=>['select','insert','update','super_delete_confirm','drop_data','{{next_ajaxreqhandler.php_notes_list}}'],
        
      'mosy_sql_roll_back'=>['insert','{{next_ajaxreqhandler.php_mosy_sql_roll_back}}'],
      
      'file_uploads'=>['insert','select','super_delete_confirm','drop_data','update','{{next_ajaxreqhandler.php_file_uploads}}'],
      
      'task_manager'=>['select','{{next_ajaxreqhandler.php_task_manager}}'],
      //next_ajaxreqhandler.php_access

      ],
      ///end access clearance array for $active_parent_dir.'ajaxreqhandler.php

      
    ///start access clearance array for $active_parent_dir.'mediapost.php
    $active_parent_dir.'mediapost.php'=>
      [
      'notes_list'=>['select','{{next_mediapost.php_notes_list}}'],
        
      'file_uploads'=>['select','{{next_mediapost.php_file_uploads}}'],
      //next_mediapost.php_access

      ],
      ///end access clearance array for $active_parent_dir.'mediapost.php

      
    ///start access clearance array for $active_parent_dir.'tasklist.php
    $active_parent_dir.'tasklist.php'=>
      [
      'notes_list'=>['select','{{next_tasklist.php_notes_list}}'],
        
      'task_manager'=>['select','task_manager_mosyfilter','{{next_tasklist.php_task_manager}}'],
      //next_tasklist.php_access

      ],
      ///end access clearance array for $active_parent_dir.'tasklist.php

      //{{next_file_block}}






];
?>