<?php 


//=== start Log in to notes_admins Login Script query 

if(isset($_POST["btn_login"]))
{
$password=mysqli_real_escape_string($mysqliconn, $_POST["txt_password"]);
$user_email=mysqli_real_escape_string($mysqliconn, $_POST["txt_username"]);

$Log_in_to_notes_admins_query=mysqli_query($mysqliconn, "SELECT * FROM `$notes_pro`.`notes_admins`  WHERE `email`='$user_email' AND `login_password`='$password'");

$Log_in_to_notes_admins_r=mysqli_fetch_array($Log_in_to_notes_admins_query);

if(!empty($Log_in_to_notes_admins_r['email']) && !empty($Log_in_to_notes_admins_r['login_password']))
{

$_SESSION['session_orn_logged']=TRUE;
$_SESSION['session_orn_logged_email']=$Log_in_to_notes_admins_r['email'];
$_SESSION['session_orn_logged_name']=$Log_in_to_notes_admins_r['name'];
$_SESSION['session_orn_logged_user_id']=$Log_in_to_notes_admins_r['user_id'];

if(isset($_GET['ref_url_go_to'])){

	$ref_url_go_to=base64_decode($_GET['ref_url_go_to']);

	header("location:".$ref_url_go_to."");


}else{

	header("location:./notelist");

}

}else{

	echo magic_message("Wrong password or user name please try again");
}

}
//=== End Log in to notes_admins Login Script query

//=========request password
if(isset($_POST['requestnewpass_btn'])){

$membusername=$_POST['email_user'];

$cpsreset_query1=mysqli_query($mysqliconn,"SELECT * FROM `$notes_pro`.`notes_admins`  WHERE email='$membusername'");

$cpsreset_res1=mysqli_fetch_array($cpsreset_query1);

$cpsreset_query=mysqli_query($mysqliconn,"SELECT * FROM `$notes_pro`.`notes_admins`   WHERE email='$membusername'");

$cpsreset_res=mysqli_num_rows($cpsreset_query);
if($cpsreset_res==1){

$showname="ClearPhrases Reset Pssword"; 
$tel="0710766390"; 

$from_email="clearphrases@gmail.com";

$to_email=$_POST['email_user'];
$client_names=$cpsreset_res1['name'];


$path1="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
//echo $path1;

$msgtosend='Hello You requested a password request. Follow this link to create a new password.<br /><br />
<a href="'.$path1.'?reset_token='.base64_encode($cpsreset_res1['primkey']).'">Reset Password</a><br /><br />';

$message=$msgtosend;
$subject="Password reset Request";
$actlink="http://www.clearphrases.com";


$replypath="http://www.clearphrases.com";


$messvars = "sendemailapi=send&mailsubj=".$subject."&showname=".$showname."&namesarray=".$client_names."&mailmessage=".$message."&sendto=".$to_email."&repmail=".$from_email."&actlink=".$actlink."&replypath=".$replypath."&imgreq=";

//echo $msgtosend;
$agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)";
$ch = curl_init( "http://clearphrases.com/clearphrases_apis/comms/emailsender.php");
curl_setopt( $ch, CURLOPT_POST, 1);

curl_setopt( $ch, CURLOPT_POSTFIELDS, $messvars);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
$sendsmsres = curl_exec( $ch );

echo magic_message("We have sent you a reset password email. Follow that link to reset your password");




}else{
echo magic_message("Sorry that email does not exist. Please Try Again");
}
}
//===================reset password request

////===========reset pass=============
if(isset($_GET['reset_token'])){

$memberkey=base64_decode($_GET['reset_token']);


$cpsresetoken_query=mysqli_query($mysqliconn,"SELECT * FROM `$notes_pro`.`notes_admins`  WHERE primkey='$memberkey'");

$cpsresetoken_res=mysqli_num_rows($cpsresetoken_query);


}
if(isset($_POST['changepass_btn'])){
$memberkey=base64_decode($_GET['reset_token']);

$cpsresetoken_query1=mysqli_query($mysqliconn,"SELECT * FROM `$notes_pro`.`notes_admins`  WHERE primkey='$memberkey'");

$cpsresetoken_res1=mysqli_fetch_array($cpsresetoken_query1);

$foundresetmail=$cpsresetoken_res1['email'];
$resetpass1=mysqli_real_escape_string($mysqliconn,$_POST['newpass_user']);
$resetpass2=mysqli_real_escape_string($mysqliconn,$_POST['confirmnewpass_user']);
if($resetpass1!=$resetpass2){

echo magic_message("Password Do Not match!!");
}else{

mysqli_query($mysqliconn,"UPDATE `$notes_pro`.`notes_admins` SET login_password='$resetpass1' WHERE email='$foundresetmail' AND primkey='$memberkey'");

echo magic_message("Password reset succesfully. Login afresh to continue.");
}
}
//===========reset pass============= 

    //====Oauth File Routes

	$login_file="./orn_login.php";
    $register_file="./orn_register.php";
    $change_password_file="./orn_change_pass.php";
    $reset_password_file="./orn_reset_password.php";
    
    //====Oauth File Routes
    
    
if(isset($_POST["create_acc"]))
{
    //------- begin Sign up User --> 
$user_id=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$name=mysqli_real_escape_string($mysqliconn, $_POST["txt_name"]);
$email=mysqli_real_escape_string($mysqliconn, $_POST["txt_email"]);
$login_password=mysqli_real_escape_string($mysqliconn, $_POST["txt_login_password"]);
//===-- End Sign up User -->


    $check_dups=magic_sql_count("notes_admins", "*", "email='$email'");

    if($check_dups==0){
        //------- begin Insert Query Sign up User --> 
//additional insert colmuns and values 
$notes_admins_dope_cols="";
$notes_admins_dope_vals="";

$notes_admins_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$notes_pro`.`notes_admins` (`primkey`,`user_id`,`name`,`email`,`login_password`  ".$notes_admins_dope_cols.") 
 VALUES 
(NULL,'$user_id','$name','$email','$login_password' ".$notes_admins_dope_vals.")");

 //--- get primary key id
$notes_admins_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
echo magic_screen('Account Created Succesfully.<hr> <a href="'.$login_file.'" class="btn btn-primary">Click Here To Login</a>');
//------- End insert Query Sign up User --> 
      }else{

      echo magic_message("Duplicate Email Found, Please try another one");

      }

}

//--<{ncgh}/>

    
?>