<?php
ob_start();
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

include('./treng/phpmagicbits.php');
include('./treng/gwdna.php');
include('./treng/datahandler.php');
include('./treng/requesthandler.php');

$default_home_crumb="";
if(isset($home_crumb))
{
$default_home_crumb=$home_crumb;
}

include('./treng/applyapi.php');
  
include('./treng/trfeng_loadapi.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="https://origin.clearphrases.com/treng/<?php echo $page_key['page_logo'] ?>">  
    <?php include("./treng/header_css_scripts.php");?>  
    <?php echo $full_meta_tags; ?>
    <?php if($meta_title==''){?>
    <meta property="og:image" content="https://origin.clearphrases.com/treng/<?php echo $page_key['page_logo'] ?>">
    <meta name="description" content="<?php echo magic_strip_if($page_key['page_descr'], 100, 100) ?>">    
    <title><?php echo checkblank($page_key['page_name'],"Homepage"); ?> - <?php echo checkblank($page_key['send_msg_title'], " Send us a message") ?></title>
    <?php }?>
    <!-- Bootstrap core CSS -->

  
<style type="text/css">
.bg_w_img{
background-image:url('https://origin.clearphrases.com/treng/<?php echo checkblank($page_key['bg_image'], "img/bg.jpg") ?>')
}
.bg_clr{
  background-color:<?php echo $page_key['background_clr'] ?>;
  color:<?php echo $page_key['background_text_clr'] ?>;
}

.btn_clr_set{
  background-color:<?php echo $page_key['btn_clr'] ?>;
  color:<?php echo $page_key['btn_txt_clr'] ?>;
}

.border_line{
  border-bottom:2px solid <?php echo $page_key['btn_clr'] ?>!important;
  
}

.border_left{
  border-left:2px solid <?php echo $page_key['btn_clr'] ?>!important;
  
}

    #myBtn2 {
  position: fixed;
  bottom: 250px;
  right: 40px;
  z-index: 99;
  border: none;
  outline: none;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 50%;
  height:20px;
  width:20px;
  text-align:center;
  
}

#myBtn:hover {
  box-shadow:2px 2px 4px 4px gray;
}
.whatsappbtn{
 display:block;   
}
.fbmsg_btn{
 display:block;   
}


.conticon {
    border-radius: 50%;
    height: 30px;
    width: 30px;
    border: 0px solid #CCCCCC;
    margin-right: 10px;
    display: inline-block;
}

.callbtn{
    bottom:300px;
}

.whatsappbtn2{
    bottom:300px;
}

.emailbtn{
    bottom: 100px;
}

@media screen and (max-width: 700px)
{
.whatsappbtn{
   display:block;   
  }  
  
  #myBtn2 img {
    max-height: 30px;
    max-width: 30px;
  }

  #myBtn2{
      padding: 1px;
      right: 7px;

  }
.callbtn{
    bottom:0px;
}

.whatsappbtn2{
    bottom:0px;
}

.emailbtn{
    bottom: 10px;
}


  .fbmsg_btn{
 display:block;   
}

.login_pg{
font-size:18px;
}
}
</style>
</head>

<body class="bg_clr">
    <form method="post" enctype="multipart/form-data" id="landing_form">
    <main role="main" class="container-fluid bg_clr p-0 m-0 " style="min-height:100vh;">
      <div class="row m-0 p-0 justify-content-center col-md-12">

          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->

    <div class="col-md-12 bg_w_img p-0 auto_bounce " style="min-height:100vh;overflow-y:auto;">
      <div class="col-md-12 p-0 text-white m-0" style="min-height:100vh;">
        <div class="col-md-12 h1 text-left p-0 m-0 bg_clr" style="">
        <div class="col-md-12 h1 text-left p-2 m-0 border_line shadow " style="background-color:<?php echo $page_key['navbar_clr'] ?>;color:<?php echo $page_key['navbar_txt_clr'] ?>">
          <img src="https://origin.clearphrases.com/treng/<?php echo $page_key['page_logo'] ?>" onerror="this.src='https://origin.clearphrases.com/treng/img/logo.png'" class=" " style="height:70px;  border-radius: <?php echo $page_key['border_radius'] ?>px;" id=""/>
          <span class="h3 login_pg  "><?php echo checkblank($page_key['page_name'], "Landing page") ?></span>
        </div>
        </div>
        <div class="col-md-12 text-center row justify-content-center m-0 p-0   ">
		  	<div class="row justify-content-center m-0 p-0 col-md-12  pt-0 bg_clr">
              <div class="col-md-6  bg_clr p-lg-3 text-left" >
              <div class="col-md-12  bg_clr p-lg-3 text-left" style="line-height:35px;max-height:100vh;overflow-y:auto;">
                   <div class="col-md-12 p-0 "> <?php echo $full_jumbotron; ?></div>    
                <?php echo nl2br($page_key['page_descr']) ?>
              </div>
              </div>
              <div class="col-md-6 p-3 bg_clr border_left pb-5" id="scroll_to_msg"  style="z-index:99;background-color:<?php echo $page_key['navbar_clr'] ?>;color:<?php echo $page_key['navbar_txt_clr'] ?>" >                                  
                <!-- Start  Title ribbon-->
                  <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                    <div class="col-md-12 bg-light mb-3 mb-lg-0 mt-lg-0" style="height: 1px"></div>
                    <div class="col-md-12 text-center"><?php echo checkblank($page_key['send_msg_title'], " Send us a message") ?></div>
                    <div class="col-md-12 bg-light mt-lg-0" style="height: 1px"></div>
                  </h5>
                  <!-- End Title ribbon-->
                	<div class="row pt-2 justify-content-center m-0 p-0 col-md-12   rounded_big">
                      <div class="form-group col-md-12 text-left">
                        <label >Name</label>
                        <input type="text" name="txt_user_name" id="txt_user_name" class="form-control" placeholder="Name" />
                      </div>
                      <div class="form-group col-md-6 text-left">
                        <label >Email</label>
                        <input type="text" name="txt_user_email" id="txt_user_email" class="form-control" placeholder="Email"/>
                      </div>
                      <div class="form-group col-md-6 text-left">
                          <label >Mobile</label>
                          <input class="form-control" id="txt_user_mobile" name="txt_user_mobile" value="" placeholder="Mobile" type="text">
                      </div>
                      <div class="form-group col-md-12 text-left">
                       <label >Message</label>
                        <textarea class="form-control" id="txt_message" style="min-height:200px;" name="txt_message"></textarea>
                      </div>
                      <div class="col-md-12 pt-3">
                        <div class="cpointer btn btn_clr_set mb-3 col-md-6 p-2 h4" onclick="send_msg()"><i class="fa fa-send "></i> <?php echo checkblank($page_key['send_btn_title'], " Send") ?> </div>
                       </div>                                          
                </div>
                
              </div>
            </div>
        </div>
      </div>
    </div> 
          <!--<{ncgh}/>-->
      </div>
<input type="hidden" name="txt_message_date" id="txt_message_date" class="form-control" placeholder="Message date"  value="<?php echo date_time_input("", "");?>" />
    <a href="https://api.whatsapp.com/send?phone=<?php echo $page_key['telephone_'] ?>&text=Write your message" target="blank"><div id="myBtn2" class="whatsappbtn" title="Whatsapp Support" style="right:40px; color:#000; bottom: 220px;" >Chat<i class=" fa fa-comment conticon  text-primary" style="font-size: 30px;"></i></div></a>

    <a href="tel:<?php echo $page_key['telephone_'] ?>" target="blank"><div id="myBtn2" class="whatsappbtn shadow-lg" title="Call" style="right:40px; bottom:200px; color:#000;margin-bottom: 94px;" >Call<i class=" fa fa-phone conticon  text-primary " style="font-size: 30px;"></i></div></a>

      <div class="row justify-content-center col-md-12 d-lg-none  m-0 p-2" style="position:fixed;  z-index:9; left:1px; bottom:1px;">
    	<div class="btn btn-primary mb-3 p-2" onclick="scroll_to('scroll_to_msg');"><i class="fa fa-send"></i> <?php echo checkblank($page_key['send_btn_title'], " Send") ?> </div>
      </div>
    </main><!-- /.container -->
 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./treng/footer.php");?>
<script type="text/javascript" src="./treng/trfeng_loadapi.js"></script> 
<script type="text/javascript">
function send_msg()
{
  if(mosy_validate_required(['txt_user_name:Names required','txt_user_email:Email required','txt_message:Message required','txt_user_mobile:Mobile required'])=='False')
    {
      magic_message('Sending...','dialog_box');
      
  	  mosy_form_data('landing_form','send_msg','msg_sent', '',['txt_user_name:Names required','txt_user_email:Email required','txt_message:Message required','txt_user_mobile:Mobile required'])
      
    }else{
      push_html('dialog_box','')
    }
}

function msg_sent()
{
  push_shtml('', 'Message Sent. We will get back to you shortly');
  push_newval('txt_user_name','');
  push_newval('txt_user_email','');
  push_newval('txt_message','');
  push_newval('txt_user_mobile','');
}
  
</script>
    </form>
</body>
</html>