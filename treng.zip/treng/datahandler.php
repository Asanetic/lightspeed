<?php 
//===============Start Mosy queries-============ 

    
 	//Start Add app_admins Data ===============
 	function add_app_admins($app_admins_arr_)
    {
     $gw_app_admins_cols=array();
     
     foreach($app_admins_arr_ as $app_admins_arr_gw => $app_admins_arr_gw_val)
     {
     
     	$gw_app_admins_cols[]=$app_admins_arr_gw;
        
     }
     
     $gw_app_admins_cols_str=implode(",", $gw_app_admins_cols);
     
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "insert",$gw_app_admins_cols_str);
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("app_admins", $app_admins_arr_);
     
     	//echo $gwauthenticate_app_admins_;

     }else{
     
     	echo $gwauthenticate_app_admins_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");

     }
     
    }
    
       function initialize_app_admins()
        {
        
         global $app_admins_uptoken;
             
         $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "select","");

         $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
         	
          //echo $gwauthenticate_app_admins_;

         if($gwauthenticate_app_admins_json["response"]=="ok")
         {
         
         	return get_app_admins("*", "WHERE primkey='$app_admins_uptoken'", "r");
         
            echo $gwauthenticate_app_admins_;

         }else{

         	echo $gwauthenticate_app_admins_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");
         
         }
        }   
    //End Add app_admins Data ===============
                
    //Start Update app_admins Data ===============
    
 	function update_app_admins($app_admins_arr_, $where_str)
    {
         $gw_app_admins_cols=array();
     
     foreach($app_admins_arr_ as $app_admins_arr_gw => $app_admins_arr_gw_val)
     {
     
     	$gw_app_admins_cols[]=$app_admins_arr_gw;
        
     }
     
     $gw_app_admins_cols_str=implode(",", $gw_app_admins_cols);
     
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "update",$gw_app_admins_cols_str);
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("app_admins", $app_admins_arr_, $where_str);

       // echo $gwauthenticate_app_admins_;
        
        exit;

     }else{

        echo $gwauthenticate_app_admins_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");


      }
    
    }
 	
    
    //End Update app_admins Data ===============

    //Start get  app_admins Data ===============
    
    function get_app_admins($colstr, $where_str, $type)
    {
          
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "select","");
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {
    	return mosyflex_sel("app_admins", $colstr, $where_str, $type);

        //echo $gwauthenticate_app_admins_;

	  }else{
     
     	echo $gwauthenticate_app_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");


     }    
    }
    //End get  app_admins Data ===============
    
    
    //======== qapp_admins_data qsingle query function
    
    function qapp_admins_data($quser_id_key)
    {
          
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "qdata","");
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {    
    	return get_app_admins("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_app_admins_;

      }else{
     
     	echo $gwauthenticate_app_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");


     }  
    }
   
    //======== qapp_admins_data qsingle query function
    
    
     //======== app_admins data to array
    
    function app_admins_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "data_array","");
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {  
     	$append_app_admins_arr=array();
    
    	$array_app_admins_q=get_app_admins($colstr, $where_str, "l");
        while($array_app_admins_res=mysqli_fetch_array($array_app_admins_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_app_admins_arr[]=$array_app_admins_res[$tbl_col];
            }
          }else{
          	          
               $append_app_admins_arr[]=$array_app_admins_res;

          }
        }
        
        return $append_app_admins_arr;

		//echo $gwauthenticate_app_admins_;

      }else{
     
     	echo $gwauthenticate_app_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");


     }  
    }
   
    //======== qapp_admins_data qsingle query function   
        
    //======== qapp_admins_ddata qsingle query function    
    function qapp_admins_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "qddata","");
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {    
    	return get_app_admins("*", "WHERE $user_id_col='$quser_id_key'", "r");

		//echo $gwauthenticate_app_admins_;

     }else{
     
     	echo $gwauthenticate_app_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");


     }   
    }
    //======== qapp_admins_ddata qsingle query function

    //======== count app_admins data function
    
    function count_app_admins($app_admins_wherestr)
    {
     
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "count_data","");
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {    
      $clean_app_admins_where_str="";
  
      if($app_admins_wherestr!='')
      {
        $clean_app_admins_where_str="Where ".$app_admins_wherestr;
      }

      return get_app_admins("count(*) as return_result", " ".$clean_app_admins_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_app_admins_;

      }else{
     
     	echo $gwauthenticate_app_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");


     }    
    }
    //======== count app_admins data function

    //======== sum  app_admins data function
    
    function sum_app_admins($app_admins_sumcol, $app_admins_wherestr)
    {
     
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "sum_data","");
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {    
      $clean_app_admins_where_str="";
  
      if($app_admins_wherestr!='')
      {
        $clean_app_admins_where_str="Where ".$app_admins_wherestr;
      }

      return get_app_admins("sum($app_admins_sumcol) as return_result", " ".$clean_app_admins_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_app_admins_;


      }else{
     
     	echo $gwauthenticate_app_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");
        


     }    
    }
    
    //======== sum  app_admins data function   
    
    
    //Start drop  app_admins Data ===============
    
    function drop_app_admins($where_str)
    {
     
     $gwauthenticate_app_admins_=gw_oauth("table", magic_current_url(), "app_admins", "drop_data","");
     
     $gwauthenticate_app_admins_json=json_decode($gwauthenticate_app_admins_, true);
     
     if($gwauthenticate_app_admins_json["response"]=="ok")
     {    
    	return magic_sql_delete("app_admins", $where_str);

		//echo $gwauthenticate_app_admins_;

      }else{
     
     	echo $gwauthenticate_app_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_admins_)."");
		

     }
    }
    //End drop  app_admins Data ===============    
    
    
            //Start Upload app_admins_user_pic Function 
            function upload_app_admins_user_pic($txt_app_admins_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_app_admins_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/app_admins_user_pic')) @mkdir('./img/app_admins_user_pic');

                $cur_item_photos=magic_upload_file('./img/app_admins_user_pic/', $txt_app_admins_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $app_admins_node=get_app_admins("*", "WHERE ".$where_str."", "r");

                  if (file_exists($app_admins_node["user_pic"]))
                  {

                      unlink($app_admins_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('app_admins', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload app_admins_user_pic Function 

            
   

    
 	//Start Add apps Data ===============
 	function add_apps($apps_arr_)
    {
     $gw_apps_cols=array();
     
     foreach($apps_arr_ as $apps_arr_gw => $apps_arr_gw_val)
     {
     
     	$gw_apps_cols[]=$apps_arr_gw;
        
     }
     
     $gw_apps_cols_str=implode(",", $gw_apps_cols);
     
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "insert",$gw_apps_cols_str);
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("apps", $apps_arr_);
     
     	//echo $gwauthenticate_apps_;

     }else{
     
     	echo $gwauthenticate_apps_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");

     }
     
    }
    
       function initialize_apps()
        {
        
         global $apps_uptoken;
             
         $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "select","");

         $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
         	
          //echo $gwauthenticate_apps_;

         if($gwauthenticate_apps_json["response"]=="ok")
         {
         
         	return get_apps("*", "WHERE primkey='$apps_uptoken'", "r");
         
            echo $gwauthenticate_apps_;

         }else{

         	echo $gwauthenticate_apps_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");
         
         }
        }   
    //End Add apps Data ===============
                
    //Start Update apps Data ===============
    
 	function update_apps($apps_arr_, $where_str)
    {
         $gw_apps_cols=array();
     
     foreach($apps_arr_ as $apps_arr_gw => $apps_arr_gw_val)
     {
     
     	$gw_apps_cols[]=$apps_arr_gw;
        
     }
     
     $gw_apps_cols_str=implode(",", $gw_apps_cols);
     
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "update",$gw_apps_cols_str);
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("apps", $apps_arr_, $where_str);

       // echo $gwauthenticate_apps_;
        
        exit;

     }else{

        echo $gwauthenticate_apps_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");


      }
    
    }
 	
    
    //End Update apps Data ===============

    //Start get  apps Data ===============
    
    function get_apps($colstr, $where_str, $type)
    {
          
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "select","");
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {
    	return mosyflex_sel("apps", $colstr, $where_str, $type);

        //echo $gwauthenticate_apps_;

	  }else{
     
     	echo $gwauthenticate_apps_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");


     }    
    }
    //End get  apps Data ===============
    
    
    //======== qapps_data qsingle query function
    
    function qapps_data($qappid_key)
    {
          
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "qdata","");
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {    
    	return get_apps("*", "WHERE appid='$qappid_key'", "r");

		//echo $gwauthenticate_apps_;

      }else{
     
     	echo $gwauthenticate_apps_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");


     }  
    }
   
    //======== qapps_data qsingle query function
    
    
     //======== apps data to array
    
    function apps_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "data_array","");
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {  
     	$append_apps_arr=array();
    
    	$array_apps_q=get_apps($colstr, $where_str, "l");
        while($array_apps_res=mysqli_fetch_array($array_apps_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_apps_arr[]=$array_apps_res[$tbl_col];
            }
          }else{
          	          
               $append_apps_arr[]=$array_apps_res;

          }
        }
        
        return $append_apps_arr;

		//echo $gwauthenticate_apps_;

      }else{
     
     	echo $gwauthenticate_apps_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");


     }  
    }
   
    //======== qapps_data qsingle query function   
        
    //======== qapps_ddata qsingle query function    
    function qapps_ddata($appid_col, $qappid_key)
    {
     
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "qddata","");
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {    
    	return get_apps("*", "WHERE $appid_col='$qappid_key'", "r");

		//echo $gwauthenticate_apps_;

     }else{
     
     	echo $gwauthenticate_apps_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");


     }   
    }
    //======== qapps_ddata qsingle query function

    //======== count apps data function
    
    function count_apps($apps_wherestr)
    {
     
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "count_data","");
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {    
      $clean_apps_where_str="";
  
      if($apps_wherestr!='')
      {
        $clean_apps_where_str="Where ".$apps_wherestr;
      }

      return get_apps("count(*) as return_result", " ".$clean_apps_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_apps_;

      }else{
     
     	echo $gwauthenticate_apps_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");


     }    
    }
    //======== count apps data function

    //======== sum  apps data function
    
    function sum_apps($apps_sumcol, $apps_wherestr)
    {
     
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "sum_data","");
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {    
      $clean_apps_where_str="";
  
      if($apps_wherestr!='')
      {
        $clean_apps_where_str="Where ".$apps_wherestr;
      }

      return get_apps("sum($apps_sumcol) as return_result", " ".$clean_apps_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_apps_;


      }else{
     
     	echo $gwauthenticate_apps_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");
        


     }    
    }
    
    //======== sum  apps data function   
    
    
    //Start drop  apps Data ===============
    
    function drop_apps($where_str)
    {
     
     $gwauthenticate_apps_=gw_oauth("table", magic_current_url(), "apps", "drop_data","");
     
     $gwauthenticate_apps_json=json_decode($gwauthenticate_apps_, true);
     
     if($gwauthenticate_apps_json["response"]=="ok")
     {    
    	return magic_sql_delete("apps", $where_str);

		//echo $gwauthenticate_apps_;

      }else{
     
     	echo $gwauthenticate_apps_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_apps_)."");
		

     }
    }
    //End drop  apps Data ===============    
    
    
   

    
 	//Start Add file_uploads Data ===============
 	function add_file_uploads($file_uploads_arr_)
    {
     $gw_file_uploads_cols=array();
     
     foreach($file_uploads_arr_ as $file_uploads_arr_gw => $file_uploads_arr_gw_val)
     {
     
     	$gw_file_uploads_cols[]=$file_uploads_arr_gw;
        
     }
     
     $gw_file_uploads_cols_str=implode(",", $gw_file_uploads_cols);
     
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "insert",$gw_file_uploads_cols_str);
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("file_uploads", $file_uploads_arr_);
     
     	//echo $gwauthenticate_file_uploads_;

     }else{
     
     	echo $gwauthenticate_file_uploads_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");

     }
     
    }
    
       function initialize_file_uploads()
        {
        
         global $file_uploads_uptoken;
             
         $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "select","");

         $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
         	
          //echo $gwauthenticate_file_uploads_;

         if($gwauthenticate_file_uploads_json["response"]=="ok")
         {
         
         	return get_file_uploads("*", "WHERE primkey='$file_uploads_uptoken'", "r");
         
            echo $gwauthenticate_file_uploads_;

         }else{

         	echo $gwauthenticate_file_uploads_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");
         
         }
        }   
    //End Add file_uploads Data ===============
                
    //Start Update file_uploads Data ===============
    
 	function update_file_uploads($file_uploads_arr_, $where_str)
    {
         $gw_file_uploads_cols=array();
     
     foreach($file_uploads_arr_ as $file_uploads_arr_gw => $file_uploads_arr_gw_val)
     {
     
     	$gw_file_uploads_cols[]=$file_uploads_arr_gw;
        
     }
     
     $gw_file_uploads_cols_str=implode(",", $gw_file_uploads_cols);
     
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "update",$gw_file_uploads_cols_str);
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("file_uploads", $file_uploads_arr_, $where_str);

       // echo $gwauthenticate_file_uploads_;
        
        exit;

     }else{

        echo $gwauthenticate_file_uploads_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");


      }
    
    }
 	
    
    //End Update file_uploads Data ===============

    //Start get  file_uploads Data ===============
    
    function get_file_uploads($colstr, $where_str, $type)
    {
          
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "select","");
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {
    	return mosyflex_sel("file_uploads", $colstr, $where_str, $type);

        //echo $gwauthenticate_file_uploads_;

	  }else{
     
     	echo $gwauthenticate_file_uploads_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");


     }    
    }
    //End get  file_uploads Data ===============
    
    
    //======== qfile_uploads_data qsingle query function
    
    function qfile_uploads_data($qmedia_key_key)
    {
          
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "qdata","");
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {    
    	return get_file_uploads("*", "WHERE media_key='$qmedia_key_key'", "r");

		//echo $gwauthenticate_file_uploads_;

      }else{
     
     	echo $gwauthenticate_file_uploads_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");


     }  
    }
   
    //======== qfile_uploads_data qsingle query function
    
    
     //======== file_uploads data to array
    
    function file_uploads_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "data_array","");
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {  
     	$append_file_uploads_arr=array();
    
    	$array_file_uploads_q=get_file_uploads($colstr, $where_str, "l");
        while($array_file_uploads_res=mysqli_fetch_array($array_file_uploads_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_file_uploads_arr[]=$array_file_uploads_res[$tbl_col];
            }
          }else{
          	          
               $append_file_uploads_arr[]=$array_file_uploads_res;

          }
        }
        
        return $append_file_uploads_arr;

		//echo $gwauthenticate_file_uploads_;

      }else{
     
     	echo $gwauthenticate_file_uploads_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");


     }  
    }
   
    //======== qfile_uploads_data qsingle query function   
        
    //======== qfile_uploads_ddata qsingle query function    
    function qfile_uploads_ddata($media_key_col, $qmedia_key_key)
    {
     
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "qddata","");
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {    
    	return get_file_uploads("*", "WHERE $media_key_col='$qmedia_key_key'", "r");

		//echo $gwauthenticate_file_uploads_;

     }else{
     
     	echo $gwauthenticate_file_uploads_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");


     }   
    }
    //======== qfile_uploads_ddata qsingle query function

    //======== count file_uploads data function
    
    function count_file_uploads($file_uploads_wherestr)
    {
     
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "count_data","");
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {    
      $clean_file_uploads_where_str="";
  
      if($file_uploads_wherestr!='')
      {
        $clean_file_uploads_where_str="Where ".$file_uploads_wherestr;
      }

      return get_file_uploads("count(*) as return_result", " ".$clean_file_uploads_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_file_uploads_;

      }else{
     
     	echo $gwauthenticate_file_uploads_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");


     }    
    }
    //======== count file_uploads data function

    //======== sum  file_uploads data function
    
    function sum_file_uploads($file_uploads_sumcol, $file_uploads_wherestr)
    {
     
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "sum_data","");
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {    
      $clean_file_uploads_where_str="";
  
      if($file_uploads_wherestr!='')
      {
        $clean_file_uploads_where_str="Where ".$file_uploads_wherestr;
      }

      return get_file_uploads("sum($file_uploads_sumcol) as return_result", " ".$clean_file_uploads_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_file_uploads_;


      }else{
     
     	echo $gwauthenticate_file_uploads_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");
        


     }    
    }
    
    //======== sum  file_uploads data function   
    
    
    //Start drop  file_uploads Data ===============
    
    function drop_file_uploads($where_str)
    {
     
     $gwauthenticate_file_uploads_=gw_oauth("table", magic_current_url(), "file_uploads", "drop_data","");
     
     $gwauthenticate_file_uploads_json=json_decode($gwauthenticate_file_uploads_, true);
     
     if($gwauthenticate_file_uploads_json["response"]=="ok")
     {    
    	return magic_sql_delete("file_uploads", $where_str);

		//echo $gwauthenticate_file_uploads_;

      }else{
     
     	echo $gwauthenticate_file_uploads_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_file_uploads_)."");
		

     }
    }
    //End drop  file_uploads Data ===============    
    
    
   

    
 	//Start Add keys_n_tokens Data ===============
 	function add_keys_n_tokens($keys_n_tokens_arr_)
    {
     $gw_keys_n_tokens_cols=array();
     
     foreach($keys_n_tokens_arr_ as $keys_n_tokens_arr_gw => $keys_n_tokens_arr_gw_val)
     {
     
     	$gw_keys_n_tokens_cols[]=$keys_n_tokens_arr_gw;
        
     }
     
     $gw_keys_n_tokens_cols_str=implode(",", $gw_keys_n_tokens_cols);
     
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "insert",$gw_keys_n_tokens_cols_str);
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("keys_n_tokens", $keys_n_tokens_arr_);
     
     	//echo $gwauthenticate_keys_n_tokens_;

     }else{
     
     	echo $gwauthenticate_keys_n_tokens_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");

     }
     
    }
    
       function initialize_keys_n_tokens()
        {
        
         global $keys_n_tokens_uptoken;
             
         $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "select","");

         $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
         	
          //echo $gwauthenticate_keys_n_tokens_;

         if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
         {
         
         	return get_keys_n_tokens("*", "WHERE primkey='$keys_n_tokens_uptoken'", "r");
         
            echo $gwauthenticate_keys_n_tokens_;

         }else{

         	echo $gwauthenticate_keys_n_tokens_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");
         
         }
        }   
    //End Add keys_n_tokens Data ===============
                
    //Start Update keys_n_tokens Data ===============
    
 	function update_keys_n_tokens($keys_n_tokens_arr_, $where_str)
    {
         $gw_keys_n_tokens_cols=array();
     
     foreach($keys_n_tokens_arr_ as $keys_n_tokens_arr_gw => $keys_n_tokens_arr_gw_val)
     {
     
     	$gw_keys_n_tokens_cols[]=$keys_n_tokens_arr_gw;
        
     }
     
     $gw_keys_n_tokens_cols_str=implode(",", $gw_keys_n_tokens_cols);
     
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "update",$gw_keys_n_tokens_cols_str);
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("keys_n_tokens", $keys_n_tokens_arr_, $where_str);

       // echo $gwauthenticate_keys_n_tokens_;
        
        exit;

     }else{

        echo $gwauthenticate_keys_n_tokens_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");


      }
    
    }
 	
    
    //End Update keys_n_tokens Data ===============

    //Start get  keys_n_tokens Data ===============
    
    function get_keys_n_tokens($colstr, $where_str, $type)
    {
          
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "select","");
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {
    	return mosyflex_sel("keys_n_tokens", $colstr, $where_str, $type);

        //echo $gwauthenticate_keys_n_tokens_;

	  }else{
     
     	echo $gwauthenticate_keys_n_tokens_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");


     }    
    }
    //End get  keys_n_tokens Data ===============
    
    
    //======== qkeys_n_tokens_data qsingle query function
    
    function qkeys_n_tokens_data($qtokenid_key)
    {
          
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "qdata","");
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {    
    	return get_keys_n_tokens("*", "WHERE tokenid='$qtokenid_key'", "r");

		//echo $gwauthenticate_keys_n_tokens_;

      }else{
     
     	echo $gwauthenticate_keys_n_tokens_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");


     }  
    }
   
    //======== qkeys_n_tokens_data qsingle query function
    
    
     //======== keys_n_tokens data to array
    
    function keys_n_tokens_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "data_array","");
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {  
     	$append_keys_n_tokens_arr=array();
    
    	$array_keys_n_tokens_q=get_keys_n_tokens($colstr, $where_str, "l");
        while($array_keys_n_tokens_res=mysqli_fetch_array($array_keys_n_tokens_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_keys_n_tokens_arr[]=$array_keys_n_tokens_res[$tbl_col];
            }
          }else{
          	          
               $append_keys_n_tokens_arr[]=$array_keys_n_tokens_res;

          }
        }
        
        return $append_keys_n_tokens_arr;

		//echo $gwauthenticate_keys_n_tokens_;

      }else{
     
     	echo $gwauthenticate_keys_n_tokens_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");


     }  
    }
   
    //======== qkeys_n_tokens_data qsingle query function   
        
    //======== qkeys_n_tokens_ddata qsingle query function    
    function qkeys_n_tokens_ddata($tokenid_col, $qtokenid_key)
    {
     
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "qddata","");
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {    
    	return get_keys_n_tokens("*", "WHERE $tokenid_col='$qtokenid_key'", "r");

		//echo $gwauthenticate_keys_n_tokens_;

     }else{
     
     	echo $gwauthenticate_keys_n_tokens_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");


     }   
    }
    //======== qkeys_n_tokens_ddata qsingle query function

    //======== count keys_n_tokens data function
    
    function count_keys_n_tokens($keys_n_tokens_wherestr)
    {
     
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "count_data","");
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {    
      $clean_keys_n_tokens_where_str="";
  
      if($keys_n_tokens_wherestr!='')
      {
        $clean_keys_n_tokens_where_str="Where ".$keys_n_tokens_wherestr;
      }

      return get_keys_n_tokens("count(*) as return_result", " ".$clean_keys_n_tokens_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_keys_n_tokens_;

      }else{
     
     	echo $gwauthenticate_keys_n_tokens_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");


     }    
    }
    //======== count keys_n_tokens data function

    //======== sum  keys_n_tokens data function
    
    function sum_keys_n_tokens($keys_n_tokens_sumcol, $keys_n_tokens_wherestr)
    {
     
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "sum_data","");
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {    
      $clean_keys_n_tokens_where_str="";
  
      if($keys_n_tokens_wherestr!='')
      {
        $clean_keys_n_tokens_where_str="Where ".$keys_n_tokens_wherestr;
      }

      return get_keys_n_tokens("sum($keys_n_tokens_sumcol) as return_result", " ".$clean_keys_n_tokens_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_keys_n_tokens_;


      }else{
     
     	echo $gwauthenticate_keys_n_tokens_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");
        


     }    
    }
    
    //======== sum  keys_n_tokens data function   
    
    
    //Start drop  keys_n_tokens Data ===============
    
    function drop_keys_n_tokens($where_str)
    {
     
     $gwauthenticate_keys_n_tokens_=gw_oauth("table", magic_current_url(), "keys_n_tokens", "drop_data","");
     
     $gwauthenticate_keys_n_tokens_json=json_decode($gwauthenticate_keys_n_tokens_, true);
     
     if($gwauthenticate_keys_n_tokens_json["response"]=="ok")
     {    
    	return magic_sql_delete("keys_n_tokens", $where_str);

		//echo $gwauthenticate_keys_n_tokens_;

      }else{
     
     	echo $gwauthenticate_keys_n_tokens_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_keys_n_tokens_)."");
		

     }
    }
    //End drop  keys_n_tokens Data ===============    
    
    
   

    
 	//Start Add market_list Data ===============
 	function add_market_list($market_list_arr_)
    {
     $gw_market_list_cols=array();
     
     foreach($market_list_arr_ as $market_list_arr_gw => $market_list_arr_gw_val)
     {
     
     	$gw_market_list_cols[]=$market_list_arr_gw;
        
     }
     
     $gw_market_list_cols_str=implode(",", $gw_market_list_cols);
     
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "insert",$gw_market_list_cols_str);
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("market_list", $market_list_arr_);
     
     	//echo $gwauthenticate_market_list_;

     }else{
     
     	echo $gwauthenticate_market_list_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");

     }
     
    }
    
       function initialize_market_list()
        {
        
         global $market_list_uptoken;
             
         $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "select","");

         $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
         	
          //echo $gwauthenticate_market_list_;

         if($gwauthenticate_market_list_json["response"]=="ok")
         {
         
         	return get_market_list("*", "WHERE primkey='$market_list_uptoken'", "r");
         
            echo $gwauthenticate_market_list_;

         }else{

         	echo $gwauthenticate_market_list_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");
         
         }
        }   
    //End Add market_list Data ===============
                
    //Start Update market_list Data ===============
    
 	function update_market_list($market_list_arr_, $where_str)
    {
         $gw_market_list_cols=array();
     
     foreach($market_list_arr_ as $market_list_arr_gw => $market_list_arr_gw_val)
     {
     
     	$gw_market_list_cols[]=$market_list_arr_gw;
        
     }
     
     $gw_market_list_cols_str=implode(",", $gw_market_list_cols);
     
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "update",$gw_market_list_cols_str);
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("market_list", $market_list_arr_, $where_str);

       // echo $gwauthenticate_market_list_;
        
        exit;

     }else{

        echo $gwauthenticate_market_list_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");


      }
    
    }
 	
    
    //End Update market_list Data ===============

    //Start get  market_list Data ===============
    
    function get_market_list($colstr, $where_str, $type)
    {
          
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "select","");
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {
    	return mosyflex_sel("market_list", $colstr, $where_str, $type);

        //echo $gwauthenticate_market_list_;

	  }else{
     
     	echo $gwauthenticate_market_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");


     }    
    }
    //End get  market_list Data ===============
    
    
    //======== qmarket_list_data qsingle query function
    
    function qmarket_list_data($qmarketid_key)
    {
          
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "qdata","");
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {    
    	return get_market_list("*", "WHERE marketid='$qmarketid_key'", "r");

		//echo $gwauthenticate_market_list_;

      }else{
     
     	echo $gwauthenticate_market_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");


     }  
    }
   
    //======== qmarket_list_data qsingle query function
    
    
     //======== market_list data to array
    
    function market_list_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "data_array","");
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {  
     	$append_market_list_arr=array();
    
    	$array_market_list_q=get_market_list($colstr, $where_str, "l");
        while($array_market_list_res=mysqli_fetch_array($array_market_list_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_market_list_arr[]=$array_market_list_res[$tbl_col];
            }
          }else{
          	          
               $append_market_list_arr[]=$array_market_list_res;

          }
        }
        
        return $append_market_list_arr;

		//echo $gwauthenticate_market_list_;

      }else{
     
     	echo $gwauthenticate_market_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");


     }  
    }
   
    //======== qmarket_list_data qsingle query function   
        
    //======== qmarket_list_ddata qsingle query function    
    function qmarket_list_ddata($marketid_col, $qmarketid_key)
    {
     
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "qddata","");
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {    
    	return get_market_list("*", "WHERE $marketid_col='$qmarketid_key'", "r");

		//echo $gwauthenticate_market_list_;

     }else{
     
     	echo $gwauthenticate_market_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");


     }   
    }
    //======== qmarket_list_ddata qsingle query function

    //======== count market_list data function
    
    function count_market_list($market_list_wherestr)
    {
     
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "count_data","");
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {    
      $clean_market_list_where_str="";
  
      if($market_list_wherestr!='')
      {
        $clean_market_list_where_str="Where ".$market_list_wherestr;
      }

      return get_market_list("count(*) as return_result", " ".$clean_market_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_market_list_;

      }else{
     
     	echo $gwauthenticate_market_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");


     }    
    }
    //======== count market_list data function

    //======== sum  market_list data function
    
    function sum_market_list($market_list_sumcol, $market_list_wherestr)
    {
     
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "sum_data","");
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {    
      $clean_market_list_where_str="";
  
      if($market_list_wherestr!='')
      {
        $clean_market_list_where_str="Where ".$market_list_wherestr;
      }

      return get_market_list("sum($market_list_sumcol) as return_result", " ".$clean_market_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_market_list_;


      }else{
     
     	echo $gwauthenticate_market_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");
        


     }    
    }
    
    //======== sum  market_list data function   
    
    
    //Start drop  market_list Data ===============
    
    function drop_market_list($where_str)
    {
     
     $gwauthenticate_market_list_=gw_oauth("table", magic_current_url(), "market_list", "drop_data","");
     
     $gwauthenticate_market_list_json=json_decode($gwauthenticate_market_list_, true);
     
     if($gwauthenticate_market_list_json["response"]=="ok")
     {    
    	return magic_sql_delete("market_list", $where_str);

		//echo $gwauthenticate_market_list_;

      }else{
     
     	echo $gwauthenticate_market_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_market_list_)."");
		

     }
    }
    //End drop  market_list Data ===============    
    
    
   

    
 	//Start Add messages Data ===============
 	function add_messages($messages_arr_)
    {
     $gw_messages_cols=array();
     
     foreach($messages_arr_ as $messages_arr_gw => $messages_arr_gw_val)
     {
     
     	$gw_messages_cols[]=$messages_arr_gw;
        
     }
     
     $gw_messages_cols_str=implode(",", $gw_messages_cols);
     
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "insert",$gw_messages_cols_str);
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("messages", $messages_arr_);
     
     	//echo $gwauthenticate_messages_;

     }else{
     
     	echo $gwauthenticate_messages_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");

     }
     
    }
    
       function initialize_messages()
        {
        
         global $messages_uptoken;
             
         $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "select","");

         $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
         	
          //echo $gwauthenticate_messages_;

         if($gwauthenticate_messages_json["response"]=="ok")
         {
         
         	return get_messages("*", "WHERE primkey='$messages_uptoken'", "r");
         
            echo $gwauthenticate_messages_;

         }else{

         	echo $gwauthenticate_messages_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");
         
         }
        }   
    //End Add messages Data ===============
                
    //Start Update messages Data ===============
    
 	function update_messages($messages_arr_, $where_str)
    {
         $gw_messages_cols=array();
     
     foreach($messages_arr_ as $messages_arr_gw => $messages_arr_gw_val)
     {
     
     	$gw_messages_cols[]=$messages_arr_gw;
        
     }
     
     $gw_messages_cols_str=implode(",", $gw_messages_cols);
     
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "update",$gw_messages_cols_str);
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("messages", $messages_arr_, $where_str);

       // echo $gwauthenticate_messages_;
        
        exit;

     }else{

        echo $gwauthenticate_messages_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");


      }
    
    }
 	
    
    //End Update messages Data ===============

    //Start get  messages Data ===============
    
    function get_messages($colstr, $where_str, $type)
    {
          
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "select","");
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {
    	return mosyflex_sel("messages", $colstr, $where_str, $type);

        //echo $gwauthenticate_messages_;

	  }else{
     
     	echo $gwauthenticate_messages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");


     }    
    }
    //End get  messages Data ===============
    
    
    //======== qmessages_data qsingle query function
    
    function qmessages_data($qmessage_id_key)
    {
          
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "qdata","");
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {    
    	return get_messages("*", "WHERE message_id='$qmessage_id_key'", "r");

		//echo $gwauthenticate_messages_;

      }else{
     
     	echo $gwauthenticate_messages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");


     }  
    }
   
    //======== qmessages_data qsingle query function
    
    
     //======== messages data to array
    
    function messages_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "data_array","");
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {  
     	$append_messages_arr=array();
    
    	$array_messages_q=get_messages($colstr, $where_str, "l");
        while($array_messages_res=mysqli_fetch_array($array_messages_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_messages_arr[]=$array_messages_res[$tbl_col];
            }
          }else{
          	          
               $append_messages_arr[]=$array_messages_res;

          }
        }
        
        return $append_messages_arr;

		//echo $gwauthenticate_messages_;

      }else{
     
     	echo $gwauthenticate_messages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");


     }  
    }
   
    //======== qmessages_data qsingle query function   
        
    //======== qmessages_ddata qsingle query function    
    function qmessages_ddata($message_id_col, $qmessage_id_key)
    {
     
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "qddata","");
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {    
    	return get_messages("*", "WHERE $message_id_col='$qmessage_id_key'", "r");

		//echo $gwauthenticate_messages_;

     }else{
     
     	echo $gwauthenticate_messages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");


     }   
    }
    //======== qmessages_ddata qsingle query function

    //======== count messages data function
    
    function count_messages($messages_wherestr)
    {
     
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "count_data","");
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {    
      $clean_messages_where_str="";
  
      if($messages_wherestr!='')
      {
        $clean_messages_where_str="Where ".$messages_wherestr;
      }

      return get_messages("count(*) as return_result", " ".$clean_messages_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_messages_;

      }else{
     
     	echo $gwauthenticate_messages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");


     }    
    }
    //======== count messages data function

    //======== sum  messages data function
    
    function sum_messages($messages_sumcol, $messages_wherestr)
    {
     
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "sum_data","");
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {    
      $clean_messages_where_str="";
  
      if($messages_wherestr!='')
      {
        $clean_messages_where_str="Where ".$messages_wherestr;
      }

      return get_messages("sum($messages_sumcol) as return_result", " ".$clean_messages_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_messages_;


      }else{
     
     	echo $gwauthenticate_messages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");
        


     }    
    }
    
    //======== sum  messages data function   
    
    
    //Start drop  messages Data ===============
    
    function drop_messages($where_str)
    {
     
     $gwauthenticate_messages_=gw_oauth("table", magic_current_url(), "messages", "drop_data","");
     
     $gwauthenticate_messages_json=json_decode($gwauthenticate_messages_, true);
     
     if($gwauthenticate_messages_json["response"]=="ok")
     {    
    	return magic_sql_delete("messages", $where_str);

		//echo $gwauthenticate_messages_;

      }else{
     
     	echo $gwauthenticate_messages_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_messages_)."");
		

     }
    }
    //End drop  messages Data ===============    
    
    
   

    
 	//Start Add mosy_sql_roll_back Data ===============
 	function add_mosy_sql_roll_back($mosy_sql_roll_back_arr_)
    {
     $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("mosy_sql_roll_back", $mosy_sql_roll_back_arr_);
     
     	//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

     }
     
    }
    
       function initialize_mosy_sql_roll_back()
        {
        
         global $mosy_sql_roll_back_uptoken;
             
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
         	return get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
         
            echo $gwauthenticate_mosy_sql_roll_back_;

         }else{

         	echo $gwauthenticate_mosy_sql_roll_back_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
        }   
    //End Add mosy_sql_roll_back Data ===============
                
    //Start Update mosy_sql_roll_back Data ===============
    
 	function update_mosy_sql_roll_back($mosy_sql_roll_back_arr_, $where_str)
    {
         $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("mosy_sql_roll_back", $mosy_sql_roll_back_arr_, $where_str);

       // echo $gwauthenticate_mosy_sql_roll_back_;
        
        exit;

     }else{

        echo $gwauthenticate_mosy_sql_roll_back_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


      }
    
    }
 	
    
    //End Update mosy_sql_roll_back Data ===============

    //Start get  mosy_sql_roll_back Data ===============
    
    function get_mosy_sql_roll_back($colstr, $where_str, $type)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
    	return mosyflex_sel("mosy_sql_roll_back", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosy_sql_roll_back_;

	  }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //End get  mosy_sql_roll_back Data ===============
    
    
    //======== qmosy_sql_roll_back_data qsingle query function
    
    function qmosy_sql_roll_back_data($qroll_bk_key_key)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qdata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE roll_bk_key='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function
    
    
     //======== mosy_sql_roll_back data to array
    
    function mosy_sql_roll_back_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "data_array","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {  
     	$append_mosy_sql_roll_back_arr=array();
    
    	$array_mosy_sql_roll_back_q=get_mosy_sql_roll_back($colstr, $where_str, "l");
        while($array_mosy_sql_roll_back_res=mysqli_fetch_array($array_mosy_sql_roll_back_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res[$tbl_col];
            }
          }else{
          	          
               $append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res;

          }
        }
        
        return $append_mosy_sql_roll_back_arr;

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function   
        
    //======== qmosy_sql_roll_back_ddata qsingle query function    
    function qmosy_sql_roll_back_ddata($roll_bk_key_col, $qroll_bk_key_key)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE $roll_bk_key_col='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }
    //======== qmosy_sql_roll_back_ddata qsingle query function

    //======== count mosy_sql_roll_back data function
    
    function count_mosy_sql_roll_back($mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "count_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("count(*) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //======== count mosy_sql_roll_back data function

    //======== sum  mosy_sql_roll_back data function
    
    function sum_mosy_sql_roll_back($mosy_sql_roll_back_sumcol, $mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "sum_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("sum($mosy_sql_roll_back_sumcol) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;


      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
        


     }    
    }
    
    //======== sum  mosy_sql_roll_back data function   
    
    
    //Start drop  mosy_sql_roll_back Data ===============
    
    function drop_mosy_sql_roll_back($where_str)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "drop_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return magic_sql_delete("mosy_sql_roll_back", $where_str);

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
		

     }
    }
    //End drop  mosy_sql_roll_back Data ===============    
    
    
   

    
 	//Start Add notes_admins Data ===============
 	function add_notes_admins($notes_admins_arr_)
    {
     $gw_notes_admins_cols=array();
     
     foreach($notes_admins_arr_ as $notes_admins_arr_gw => $notes_admins_arr_gw_val)
     {
     
     	$gw_notes_admins_cols[]=$notes_admins_arr_gw;
        
     }
     
     $gw_notes_admins_cols_str=implode(",", $gw_notes_admins_cols);
     
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "insert",$gw_notes_admins_cols_str);
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("notes_admins", $notes_admins_arr_);
     
     	//echo $gwauthenticate_notes_admins_;

     }else{
     
     	echo $gwauthenticate_notes_admins_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");

     }
     
    }
    
       function initialize_notes_admins()
        {
        
         global $notes_admins_uptoken;
             
         $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "select","");

         $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
         	
          //echo $gwauthenticate_notes_admins_;

         if($gwauthenticate_notes_admins_json["response"]=="ok")
         {
         
         	return get_notes_admins("*", "WHERE primkey='$notes_admins_uptoken'", "r");
         
            echo $gwauthenticate_notes_admins_;

         }else{

         	echo $gwauthenticate_notes_admins_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");
         
         }
        }   
    //End Add notes_admins Data ===============
                
    //Start Update notes_admins Data ===============
    
 	function update_notes_admins($notes_admins_arr_, $where_str)
    {
         $gw_notes_admins_cols=array();
     
     foreach($notes_admins_arr_ as $notes_admins_arr_gw => $notes_admins_arr_gw_val)
     {
     
     	$gw_notes_admins_cols[]=$notes_admins_arr_gw;
        
     }
     
     $gw_notes_admins_cols_str=implode(",", $gw_notes_admins_cols);
     
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "update",$gw_notes_admins_cols_str);
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("notes_admins", $notes_admins_arr_, $where_str);

       // echo $gwauthenticate_notes_admins_;
        
        exit;

     }else{

        echo $gwauthenticate_notes_admins_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");


      }
    
    }
 	
    
    //End Update notes_admins Data ===============

    //Start get  notes_admins Data ===============
    
    function get_notes_admins($colstr, $where_str, $type)
    {
          
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "select","");
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {
    	return mosyflex_sel("notes_admins", $colstr, $where_str, $type);

        //echo $gwauthenticate_notes_admins_;

	  }else{
     
     	echo $gwauthenticate_notes_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");


     }    
    }
    //End get  notes_admins Data ===============
    
    
    //======== qnotes_admins_data qsingle query function
    
    function qnotes_admins_data($quser_id_key)
    {
          
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "qdata","");
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {    
    	return get_notes_admins("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_notes_admins_;

      }else{
     
     	echo $gwauthenticate_notes_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");


     }  
    }
   
    //======== qnotes_admins_data qsingle query function
    
    
     //======== notes_admins data to array
    
    function notes_admins_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "data_array","");
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {  
     	$append_notes_admins_arr=array();
    
    	$array_notes_admins_q=get_notes_admins($colstr, $where_str, "l");
        while($array_notes_admins_res=mysqli_fetch_array($array_notes_admins_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_notes_admins_arr[]=$array_notes_admins_res[$tbl_col];
            }
          }else{
          	          
               $append_notes_admins_arr[]=$array_notes_admins_res;

          }
        }
        
        return $append_notes_admins_arr;

		//echo $gwauthenticate_notes_admins_;

      }else{
     
     	echo $gwauthenticate_notes_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");


     }  
    }
   
    //======== qnotes_admins_data qsingle query function   
        
    //======== qnotes_admins_ddata qsingle query function    
    function qnotes_admins_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "qddata","");
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {    
    	return get_notes_admins("*", "WHERE $user_id_col='$quser_id_key'", "r");

		//echo $gwauthenticate_notes_admins_;

     }else{
     
     	echo $gwauthenticate_notes_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");


     }   
    }
    //======== qnotes_admins_ddata qsingle query function

    //======== count notes_admins data function
    
    function count_notes_admins($notes_admins_wherestr)
    {
     
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "count_data","");
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {    
      $clean_notes_admins_where_str="";
  
      if($notes_admins_wherestr!='')
      {
        $clean_notes_admins_where_str="Where ".$notes_admins_wherestr;
      }

      return get_notes_admins("count(*) as return_result", " ".$clean_notes_admins_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_notes_admins_;

      }else{
     
     	echo $gwauthenticate_notes_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");


     }    
    }
    //======== count notes_admins data function

    //======== sum  notes_admins data function
    
    function sum_notes_admins($notes_admins_sumcol, $notes_admins_wherestr)
    {
     
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "sum_data","");
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {    
      $clean_notes_admins_where_str="";
  
      if($notes_admins_wherestr!='')
      {
        $clean_notes_admins_where_str="Where ".$notes_admins_wherestr;
      }

      return get_notes_admins("sum($notes_admins_sumcol) as return_result", " ".$clean_notes_admins_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_notes_admins_;


      }else{
     
     	echo $gwauthenticate_notes_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");
        


     }    
    }
    
    //======== sum  notes_admins data function   
    
    
    //Start drop  notes_admins Data ===============
    
    function drop_notes_admins($where_str)
    {
     
     $gwauthenticate_notes_admins_=gw_oauth("table", magic_current_url(), "notes_admins", "drop_data","");
     
     $gwauthenticate_notes_admins_json=json_decode($gwauthenticate_notes_admins_, true);
     
     if($gwauthenticate_notes_admins_json["response"]=="ok")
     {    
    	return magic_sql_delete("notes_admins", $where_str);

		//echo $gwauthenticate_notes_admins_;

      }else{
     
     	echo $gwauthenticate_notes_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_admins_)."");
		

     }
    }
    //End drop  notes_admins Data ===============    
    
    
            //Start Upload notes_admins_user_pic Function 
            function upload_notes_admins_user_pic($txt_notes_admins_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_notes_admins_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/notes_admins_user_pic')) @mkdir('./img/notes_admins_user_pic');

                $cur_item_photos=magic_upload_file('./img/notes_admins_user_pic/', $txt_notes_admins_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $notes_admins_node=get_notes_admins("*", "WHERE ".$where_str."", "r");

                  if (file_exists($notes_admins_node["user_pic"]))
                  {

                      unlink($notes_admins_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('notes_admins', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload notes_admins_user_pic Function 

            
   

    
 	//Start Add notes_list Data ===============
 	function add_notes_list($notes_list_arr_)
    {
     $gw_notes_list_cols=array();
     
     foreach($notes_list_arr_ as $notes_list_arr_gw => $notes_list_arr_gw_val)
     {
     
     	$gw_notes_list_cols[]=$notes_list_arr_gw;
        
     }
     
     $gw_notes_list_cols_str=implode(",", $gw_notes_list_cols);
     
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "insert",$gw_notes_list_cols_str);
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("notes_list", $notes_list_arr_);
     
     	//echo $gwauthenticate_notes_list_;

     }else{
     
     	echo $gwauthenticate_notes_list_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");

     }
     
    }
    
       function initialize_notes_list()
        {
        
         global $notes_list_uptoken;
             
         $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "select","");

         $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
         	
          //echo $gwauthenticate_notes_list_;

         if($gwauthenticate_notes_list_json["response"]=="ok")
         {
         
         	return get_notes_list("*", "WHERE primkey='$notes_list_uptoken'", "r");
         
            echo $gwauthenticate_notes_list_;

         }else{

         	echo $gwauthenticate_notes_list_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");
         
         }
        }   
    //End Add notes_list Data ===============
                
    //Start Update notes_list Data ===============
    
 	function update_notes_list($notes_list_arr_, $where_str)
    {
         $gw_notes_list_cols=array();
     
     foreach($notes_list_arr_ as $notes_list_arr_gw => $notes_list_arr_gw_val)
     {
     
     	$gw_notes_list_cols[]=$notes_list_arr_gw;
        
     }
     
     $gw_notes_list_cols_str=implode(",", $gw_notes_list_cols);
     
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "update",$gw_notes_list_cols_str);
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("notes_list", $notes_list_arr_, $where_str);

       // echo $gwauthenticate_notes_list_;
        
        exit;

     }else{

        echo $gwauthenticate_notes_list_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");


      }
    
    }
 	
    
    //End Update notes_list Data ===============

    //Start get  notes_list Data ===============
    
    function get_notes_list($colstr, $where_str, $type)
    {
          
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "select","");
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {
    	return mosyflex_sel("notes_list", $colstr, $where_str, $type);

        //echo $gwauthenticate_notes_list_;

	  }else{
     
     	echo $gwauthenticate_notes_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");


     }    
    }
    //End get  notes_list Data ===============
    
    
    //======== qnotes_list_data qsingle query function
    
    function qnotes_list_data($qnoteskey_key)
    {
          
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "qdata","");
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {    
    	return get_notes_list("*", "WHERE noteskey='$qnoteskey_key'", "r");

		//echo $gwauthenticate_notes_list_;

      }else{
     
     	echo $gwauthenticate_notes_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");


     }  
    }
   
    //======== qnotes_list_data qsingle query function
    
    
     //======== notes_list data to array
    
    function notes_list_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "data_array","");
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {  
     	$append_notes_list_arr=array();
    
    	$array_notes_list_q=get_notes_list($colstr, $where_str, "l");
        while($array_notes_list_res=mysqli_fetch_array($array_notes_list_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_notes_list_arr[]=$array_notes_list_res[$tbl_col];
            }
          }else{
          	          
               $append_notes_list_arr[]=$array_notes_list_res;

          }
        }
        
        return $append_notes_list_arr;

		//echo $gwauthenticate_notes_list_;

      }else{
     
     	echo $gwauthenticate_notes_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");


     }  
    }
   
    //======== qnotes_list_data qsingle query function   
        
    //======== qnotes_list_ddata qsingle query function    
    function qnotes_list_ddata($noteskey_col, $qnoteskey_key)
    {
     
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "qddata","");
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {    
    	return get_notes_list("*", "WHERE $noteskey_col='$qnoteskey_key'", "r");

		//echo $gwauthenticate_notes_list_;

     }else{
     
     	echo $gwauthenticate_notes_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");


     }   
    }
    //======== qnotes_list_ddata qsingle query function

    //======== count notes_list data function
    
    function count_notes_list($notes_list_wherestr)
    {
     
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "count_data","");
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {    
      $clean_notes_list_where_str="";
  
      if($notes_list_wherestr!='')
      {
        $clean_notes_list_where_str="Where ".$notes_list_wherestr;
      }

      return get_notes_list("count(*) as return_result", " ".$clean_notes_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_notes_list_;

      }else{
     
     	echo $gwauthenticate_notes_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");


     }    
    }
    //======== count notes_list data function

    //======== sum  notes_list data function
    
    function sum_notes_list($notes_list_sumcol, $notes_list_wherestr)
    {
     
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "sum_data","");
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {    
      $clean_notes_list_where_str="";
  
      if($notes_list_wherestr!='')
      {
        $clean_notes_list_where_str="Where ".$notes_list_wherestr;
      }

      return get_notes_list("sum($notes_list_sumcol) as return_result", " ".$clean_notes_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_notes_list_;


      }else{
     
     	echo $gwauthenticate_notes_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");
        


     }    
    }
    
    //======== sum  notes_list data function   
    
    
    //Start drop  notes_list Data ===============
    
    function drop_notes_list($where_str)
    {
     
     $gwauthenticate_notes_list_=gw_oauth("table", magic_current_url(), "notes_list", "drop_data","");
     
     $gwauthenticate_notes_list_json=json_decode($gwauthenticate_notes_list_, true);
     
     if($gwauthenticate_notes_list_json["response"]=="ok")
     {    
    	return magic_sql_delete("notes_list", $where_str);

		//echo $gwauthenticate_notes_list_;

      }else{
     
     	echo $gwauthenticate_notes_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_notes_list_)."");
		

     }
    }
    //End drop  notes_list Data ===============    
    
    
   

    
 	//Start Add online_reception Data ===============
 	function add_online_reception($online_reception_arr_)
    {
     $gw_online_reception_cols=array();
     
     foreach($online_reception_arr_ as $online_reception_arr_gw => $online_reception_arr_gw_val)
     {
     
     	$gw_online_reception_cols[]=$online_reception_arr_gw;
        
     }
     
     $gw_online_reception_cols_str=implode(",", $gw_online_reception_cols);
     
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "insert",$gw_online_reception_cols_str);
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("online_reception", $online_reception_arr_);
     
     	//echo $gwauthenticate_online_reception_;

     }else{
     
     	echo $gwauthenticate_online_reception_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");

     }
     
    }
    
       function initialize_online_reception()
        {
        
         global $online_reception_uptoken;
             
         $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "select","");

         $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
         	
          //echo $gwauthenticate_online_reception_;

         if($gwauthenticate_online_reception_json["response"]=="ok")
         {
         
         	return get_online_reception("*", "WHERE primkey='$online_reception_uptoken'", "r");
         
            echo $gwauthenticate_online_reception_;

         }else{

         	echo $gwauthenticate_online_reception_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");
         
         }
        }   
    //End Add online_reception Data ===============
                
    //Start Update online_reception Data ===============
    
 	function update_online_reception($online_reception_arr_, $where_str)
    {
         $gw_online_reception_cols=array();
     
     foreach($online_reception_arr_ as $online_reception_arr_gw => $online_reception_arr_gw_val)
     {
     
     	$gw_online_reception_cols[]=$online_reception_arr_gw;
        
     }
     
     $gw_online_reception_cols_str=implode(",", $gw_online_reception_cols);
     
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "update",$gw_online_reception_cols_str);
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("online_reception", $online_reception_arr_, $where_str);

       // echo $gwauthenticate_online_reception_;
        
        exit;

     }else{

        echo $gwauthenticate_online_reception_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");


      }
    
    }
 	
    
    //End Update online_reception Data ===============

    //Start get  online_reception Data ===============
    
    function get_online_reception($colstr, $where_str, $type)
    {
          
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "select","");
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {
    	return mosyflex_sel("online_reception", $colstr, $where_str, $type);

        //echo $gwauthenticate_online_reception_;

	  }else{
     
     	echo $gwauthenticate_online_reception_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");


     }    
    }
    //End get  online_reception Data ===============
    
    
    //======== qonline_reception_data qsingle query function
    
    function qonline_reception_data($qreckey_key)
    {
          
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "qdata","");
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {    
    	return get_online_reception("*", "WHERE reckey='$qreckey_key'", "r");

		//echo $gwauthenticate_online_reception_;

      }else{
     
     	echo $gwauthenticate_online_reception_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");


     }  
    }
   
    //======== qonline_reception_data qsingle query function
    
    
     //======== online_reception data to array
    
    function online_reception_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "data_array","");
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {  
     	$append_online_reception_arr=array();
    
    	$array_online_reception_q=get_online_reception($colstr, $where_str, "l");
        while($array_online_reception_res=mysqli_fetch_array($array_online_reception_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_online_reception_arr[]=$array_online_reception_res[$tbl_col];
            }
          }else{
          	          
               $append_online_reception_arr[]=$array_online_reception_res;

          }
        }
        
        return $append_online_reception_arr;

		//echo $gwauthenticate_online_reception_;

      }else{
     
     	echo $gwauthenticate_online_reception_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");


     }  
    }
   
    //======== qonline_reception_data qsingle query function   
        
    //======== qonline_reception_ddata qsingle query function    
    function qonline_reception_ddata($reckey_col, $qreckey_key)
    {
     
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "qddata","");
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {    
    	return get_online_reception("*", "WHERE $reckey_col='$qreckey_key'", "r");

		//echo $gwauthenticate_online_reception_;

     }else{
     
     	echo $gwauthenticate_online_reception_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");


     }   
    }
    //======== qonline_reception_ddata qsingle query function

    //======== count online_reception data function
    
    function count_online_reception($online_reception_wherestr)
    {
     
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "count_data","");
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {    
      $clean_online_reception_where_str="";
  
      if($online_reception_wherestr!='')
      {
        $clean_online_reception_where_str="Where ".$online_reception_wherestr;
      }

      return get_online_reception("count(*) as return_result", " ".$clean_online_reception_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_online_reception_;

      }else{
     
     	echo $gwauthenticate_online_reception_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");


     }    
    }
    //======== count online_reception data function

    //======== sum  online_reception data function
    
    function sum_online_reception($online_reception_sumcol, $online_reception_wherestr)
    {
     
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "sum_data","");
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {    
      $clean_online_reception_where_str="";
  
      if($online_reception_wherestr!='')
      {
        $clean_online_reception_where_str="Where ".$online_reception_wherestr;
      }

      return get_online_reception("sum($online_reception_sumcol) as return_result", " ".$clean_online_reception_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_online_reception_;


      }else{
     
     	echo $gwauthenticate_online_reception_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");
        


     }    
    }
    
    //======== sum  online_reception data function   
    
    
    //Start drop  online_reception Data ===============
    
    function drop_online_reception($where_str)
    {
     
     $gwauthenticate_online_reception_=gw_oauth("table", magic_current_url(), "online_reception", "drop_data","");
     
     $gwauthenticate_online_reception_json=json_decode($gwauthenticate_online_reception_, true);
     
     if($gwauthenticate_online_reception_json["response"]=="ok")
     {    
    	return magic_sql_delete("online_reception", $where_str);

		//echo $gwauthenticate_online_reception_;

      }else{
     
     	echo $gwauthenticate_online_reception_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_online_reception_)."");
		

     }
    }
    //End drop  online_reception Data ===============    
    
    
            //Start Upload online_reception_page_logo Function 
            function upload_online_reception_page_logo($txt_online_reception_page_logo, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_online_reception_page_logo]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/online_reception_page_logo')) @mkdir('./img/online_reception_page_logo');

                $cur_item_photos=magic_upload_file('./img/online_reception_page_logo/', $txt_online_reception_page_logo, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $online_reception_node=get_online_reception("*", "WHERE ".$where_str."", "r");

                  if (file_exists($online_reception_node["page_logo"]))
                  {

                      unlink($online_reception_node["page_logo"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('online_reception', '{"page_logo":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload online_reception_page_logo Function 

            
            //Start Upload online_reception_bg_image Function 
            function upload_online_reception_bg_image($txt_online_reception_bg_image, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_online_reception_bg_image]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/online_reception_bg_image')) @mkdir('./img/online_reception_bg_image');

                $cur_item_photos=magic_upload_file('./img/online_reception_bg_image/', $txt_online_reception_bg_image, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $online_reception_node=get_online_reception("*", "WHERE ".$where_str."", "r");

                  if (file_exists($online_reception_node["bg_image"]))
                  {

                      unlink($online_reception_node["bg_image"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('online_reception', '{"bg_image":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload online_reception_bg_image Function 

            
   

    
 	//Start Add page_links Data ===============
 	function add_page_links($page_links_arr_)
    {
     $gw_page_links_cols=array();
     
     foreach($page_links_arr_ as $page_links_arr_gw => $page_links_arr_gw_val)
     {
     
     	$gw_page_links_cols[]=$page_links_arr_gw;
        
     }
     
     $gw_page_links_cols_str=implode(",", $gw_page_links_cols);
     
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "insert",$gw_page_links_cols_str);
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("page_links", $page_links_arr_);
     
     	//echo $gwauthenticate_page_links_;

     }else{
     
     	echo $gwauthenticate_page_links_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");

     }
     
    }
    
       function initialize_page_links()
        {
        
         global $page_links_uptoken;
             
         $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "select","");

         $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
         	
          //echo $gwauthenticate_page_links_;

         if($gwauthenticate_page_links_json["response"]=="ok")
         {
         
         	return get_page_links("*", "WHERE primkey='$page_links_uptoken'", "r");
         
            echo $gwauthenticate_page_links_;

         }else{

         	echo $gwauthenticate_page_links_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");
         
         }
        }   
    //End Add page_links Data ===============
                
    //Start Update page_links Data ===============
    
 	function update_page_links($page_links_arr_, $where_str)
    {
         $gw_page_links_cols=array();
     
     foreach($page_links_arr_ as $page_links_arr_gw => $page_links_arr_gw_val)
     {
     
     	$gw_page_links_cols[]=$page_links_arr_gw;
        
     }
     
     $gw_page_links_cols_str=implode(",", $gw_page_links_cols);
     
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "update",$gw_page_links_cols_str);
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("page_links", $page_links_arr_, $where_str);

       // echo $gwauthenticate_page_links_;
        
        exit;

     }else{

        echo $gwauthenticate_page_links_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");


      }
    
    }
 	
    
    //End Update page_links Data ===============

    //Start get  page_links Data ===============
    
    function get_page_links($colstr, $where_str, $type)
    {
          
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "select","");
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {
    	return mosyflex_sel("page_links", $colstr, $where_str, $type);

        //echo $gwauthenticate_page_links_;

	  }else{
     
     	echo $gwauthenticate_page_links_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");


     }    
    }
    //End get  page_links Data ===============
    
    
    //======== qpage_links_data qsingle query function
    
    function qpage_links_data($qlink_id_key)
    {
          
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "qdata","");
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {    
    	return get_page_links("*", "WHERE link_id='$qlink_id_key'", "r");

		//echo $gwauthenticate_page_links_;

      }else{
     
     	echo $gwauthenticate_page_links_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");


     }  
    }
   
    //======== qpage_links_data qsingle query function
    
    
     //======== page_links data to array
    
    function page_links_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "data_array","");
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {  
     	$append_page_links_arr=array();
    
    	$array_page_links_q=get_page_links($colstr, $where_str, "l");
        while($array_page_links_res=mysqli_fetch_array($array_page_links_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_page_links_arr[]=$array_page_links_res[$tbl_col];
            }
          }else{
          	          
               $append_page_links_arr[]=$array_page_links_res;

          }
        }
        
        return $append_page_links_arr;

		//echo $gwauthenticate_page_links_;

      }else{
     
     	echo $gwauthenticate_page_links_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");


     }  
    }
   
    //======== qpage_links_data qsingle query function   
        
    //======== qpage_links_ddata qsingle query function    
    function qpage_links_ddata($link_id_col, $qlink_id_key)
    {
     
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "qddata","");
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {    
    	return get_page_links("*", "WHERE $link_id_col='$qlink_id_key'", "r");

		//echo $gwauthenticate_page_links_;

     }else{
     
     	echo $gwauthenticate_page_links_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");


     }   
    }
    //======== qpage_links_ddata qsingle query function

    //======== count page_links data function
    
    function count_page_links($page_links_wherestr)
    {
     
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "count_data","");
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {    
      $clean_page_links_where_str="";
  
      if($page_links_wherestr!='')
      {
        $clean_page_links_where_str="Where ".$page_links_wherestr;
      }

      return get_page_links("count(*) as return_result", " ".$clean_page_links_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_page_links_;

      }else{
     
     	echo $gwauthenticate_page_links_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");


     }    
    }
    //======== count page_links data function

    //======== sum  page_links data function
    
    function sum_page_links($page_links_sumcol, $page_links_wherestr)
    {
     
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "sum_data","");
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {    
      $clean_page_links_where_str="";
  
      if($page_links_wherestr!='')
      {
        $clean_page_links_where_str="Where ".$page_links_wherestr;
      }

      return get_page_links("sum($page_links_sumcol) as return_result", " ".$clean_page_links_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_page_links_;


      }else{
     
     	echo $gwauthenticate_page_links_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");
        


     }    
    }
    
    //======== sum  page_links data function   
    
    
    //Start drop  page_links Data ===============
    
    function drop_page_links($where_str)
    {
     
     $gwauthenticate_page_links_=gw_oauth("table", magic_current_url(), "page_links", "drop_data","");
     
     $gwauthenticate_page_links_json=json_decode($gwauthenticate_page_links_, true);
     
     if($gwauthenticate_page_links_json["response"]=="ok")
     {    
    	return magic_sql_delete("page_links", $where_str);

		//echo $gwauthenticate_page_links_;

      }else{
     
     	echo $gwauthenticate_page_links_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_page_links_)."");
		

     }
    }
    //End drop  page_links Data ===============    
    
    
   

    
 	//Start Add posting_log Data ===============
 	function add_posting_log($posting_log_arr_)
    {
     $gw_posting_log_cols=array();
     
     foreach($posting_log_arr_ as $posting_log_arr_gw => $posting_log_arr_gw_val)
     {
     
     	$gw_posting_log_cols[]=$posting_log_arr_gw;
        
     }
     
     $gw_posting_log_cols_str=implode(",", $gw_posting_log_cols);
     
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "insert",$gw_posting_log_cols_str);
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("posting_log", $posting_log_arr_);
     
     	//echo $gwauthenticate_posting_log_;

     }else{
     
     	echo $gwauthenticate_posting_log_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");

     }
     
    }
    
       function initialize_posting_log()
        {
        
         global $posting_log_uptoken;
             
         $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "select","");

         $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
         	
          //echo $gwauthenticate_posting_log_;

         if($gwauthenticate_posting_log_json["response"]=="ok")
         {
         
         	return get_posting_log("*", "WHERE primkey='$posting_log_uptoken'", "r");
         
            echo $gwauthenticate_posting_log_;

         }else{

         	echo $gwauthenticate_posting_log_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");
         
         }
        }   
    //End Add posting_log Data ===============
                
    //Start Update posting_log Data ===============
    
 	function update_posting_log($posting_log_arr_, $where_str)
    {
         $gw_posting_log_cols=array();
     
     foreach($posting_log_arr_ as $posting_log_arr_gw => $posting_log_arr_gw_val)
     {
     
     	$gw_posting_log_cols[]=$posting_log_arr_gw;
        
     }
     
     $gw_posting_log_cols_str=implode(",", $gw_posting_log_cols);
     
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "update",$gw_posting_log_cols_str);
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("posting_log", $posting_log_arr_, $where_str);

       // echo $gwauthenticate_posting_log_;
        
        exit;

     }else{

        echo $gwauthenticate_posting_log_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");


      }
    
    }
 	
    
    //End Update posting_log Data ===============

    //Start get  posting_log Data ===============
    
    function get_posting_log($colstr, $where_str, $type)
    {
          
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "select","");
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {
    	return mosyflex_sel("posting_log", $colstr, $where_str, $type);

        //echo $gwauthenticate_posting_log_;

	  }else{
     
     	echo $gwauthenticate_posting_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");


     }    
    }
    //End get  posting_log Data ===============
    
    
    //======== qposting_log_data qsingle query function
    
    function qposting_log_data($qpostkey_key)
    {
          
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "qdata","");
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {    
    	return get_posting_log("*", "WHERE postkey='$qpostkey_key'", "r");

		//echo $gwauthenticate_posting_log_;

      }else{
     
     	echo $gwauthenticate_posting_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");


     }  
    }
   
    //======== qposting_log_data qsingle query function
    
    
     //======== posting_log data to array
    
    function posting_log_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "data_array","");
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {  
     	$append_posting_log_arr=array();
    
    	$array_posting_log_q=get_posting_log($colstr, $where_str, "l");
        while($array_posting_log_res=mysqli_fetch_array($array_posting_log_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_posting_log_arr[]=$array_posting_log_res[$tbl_col];
            }
          }else{
          	          
               $append_posting_log_arr[]=$array_posting_log_res;

          }
        }
        
        return $append_posting_log_arr;

		//echo $gwauthenticate_posting_log_;

      }else{
     
     	echo $gwauthenticate_posting_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");


     }  
    }
   
    //======== qposting_log_data qsingle query function   
        
    //======== qposting_log_ddata qsingle query function    
    function qposting_log_ddata($postkey_col, $qpostkey_key)
    {
     
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "qddata","");
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {    
    	return get_posting_log("*", "WHERE $postkey_col='$qpostkey_key'", "r");

		//echo $gwauthenticate_posting_log_;

     }else{
     
     	echo $gwauthenticate_posting_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");


     }   
    }
    //======== qposting_log_ddata qsingle query function

    //======== count posting_log data function
    
    function count_posting_log($posting_log_wherestr)
    {
     
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "count_data","");
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {    
      $clean_posting_log_where_str="";
  
      if($posting_log_wherestr!='')
      {
        $clean_posting_log_where_str="Where ".$posting_log_wherestr;
      }

      return get_posting_log("count(*) as return_result", " ".$clean_posting_log_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_posting_log_;

      }else{
     
     	echo $gwauthenticate_posting_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");


     }    
    }
    //======== count posting_log data function

    //======== sum  posting_log data function
    
    function sum_posting_log($posting_log_sumcol, $posting_log_wherestr)
    {
     
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "sum_data","");
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {    
      $clean_posting_log_where_str="";
  
      if($posting_log_wherestr!='')
      {
        $clean_posting_log_where_str="Where ".$posting_log_wherestr;
      }

      return get_posting_log("sum($posting_log_sumcol) as return_result", " ".$clean_posting_log_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_posting_log_;


      }else{
     
     	echo $gwauthenticate_posting_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");
        


     }    
    }
    
    //======== sum  posting_log data function   
    
    
    //Start drop  posting_log Data ===============
    
    function drop_posting_log($where_str)
    {
     
     $gwauthenticate_posting_log_=gw_oauth("table", magic_current_url(), "posting_log", "drop_data","");
     
     $gwauthenticate_posting_log_json=json_decode($gwauthenticate_posting_log_, true);
     
     if($gwauthenticate_posting_log_json["response"]=="ok")
     {    
    	return magic_sql_delete("posting_log", $where_str);

		//echo $gwauthenticate_posting_log_;

      }else{
     
     	echo $gwauthenticate_posting_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posting_log_)."");
		

     }
    }
    //End drop  posting_log Data ===============    
    
    
   

    
 	//Start Add posts Data ===============
 	function add_posts($posts_arr_)
    {
     $gw_posts_cols=array();
     
     foreach($posts_arr_ as $posts_arr_gw => $posts_arr_gw_val)
     {
     
     	$gw_posts_cols[]=$posts_arr_gw;
        
     }
     
     $gw_posts_cols_str=implode(",", $gw_posts_cols);
     
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "insert",$gw_posts_cols_str);
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("posts", $posts_arr_);
     
     	//echo $gwauthenticate_posts_;

     }else{
     
     	echo $gwauthenticate_posts_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");

     }
     
    }
    
       function initialize_posts()
        {
        
         global $posts_uptoken;
             
         $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "select","");

         $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
         	
          //echo $gwauthenticate_posts_;

         if($gwauthenticate_posts_json["response"]=="ok")
         {
         
         	return get_posts("*", "WHERE primkey='$posts_uptoken'", "r");
         
            echo $gwauthenticate_posts_;

         }else{

         	echo $gwauthenticate_posts_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");
         
         }
        }   
    //End Add posts Data ===============
                
    //Start Update posts Data ===============
    
 	function update_posts($posts_arr_, $where_str)
    {
         $gw_posts_cols=array();
     
     foreach($posts_arr_ as $posts_arr_gw => $posts_arr_gw_val)
     {
     
     	$gw_posts_cols[]=$posts_arr_gw;
        
     }
     
     $gw_posts_cols_str=implode(",", $gw_posts_cols);
     
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "update",$gw_posts_cols_str);
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("posts", $posts_arr_, $where_str);

       // echo $gwauthenticate_posts_;
        
        exit;

     }else{

        echo $gwauthenticate_posts_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");


      }
    
    }
 	
    
    //End Update posts Data ===============

    //Start get  posts Data ===============
    
    function get_posts($colstr, $where_str, $type)
    {
          
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "select","");
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {
    	return mosyflex_sel("posts", $colstr, $where_str, $type);

        //echo $gwauthenticate_posts_;

	  }else{
     
     	echo $gwauthenticate_posts_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");


     }    
    }
    //End get  posts Data ===============
    
    
    //======== qposts_data qsingle query function
    
    function qposts_data($qmsgid_key)
    {
          
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "qdata","");
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {    
    	return get_posts("*", "WHERE msgid='$qmsgid_key'", "r");

		//echo $gwauthenticate_posts_;

      }else{
     
     	echo $gwauthenticate_posts_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");


     }  
    }
   
    //======== qposts_data qsingle query function
    
    
     //======== posts data to array
    
    function posts_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "data_array","");
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {  
     	$append_posts_arr=array();
    
    	$array_posts_q=get_posts($colstr, $where_str, "l");
        while($array_posts_res=mysqli_fetch_array($array_posts_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_posts_arr[]=$array_posts_res[$tbl_col];
            }
          }else{
          	          
               $append_posts_arr[]=$array_posts_res;

          }
        }
        
        return $append_posts_arr;

		//echo $gwauthenticate_posts_;

      }else{
     
     	echo $gwauthenticate_posts_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");


     }  
    }
   
    //======== qposts_data qsingle query function   
        
    //======== qposts_ddata qsingle query function    
    function qposts_ddata($msgid_col, $qmsgid_key)
    {
     
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "qddata","");
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {    
    	return get_posts("*", "WHERE $msgid_col='$qmsgid_key'", "r");

		//echo $gwauthenticate_posts_;

     }else{
     
     	echo $gwauthenticate_posts_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");


     }   
    }
    //======== qposts_ddata qsingle query function

    //======== count posts data function
    
    function count_posts($posts_wherestr)
    {
     
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "count_data","");
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {    
      $clean_posts_where_str="";
  
      if($posts_wherestr!='')
      {
        $clean_posts_where_str="Where ".$posts_wherestr;
      }

      return get_posts("count(*) as return_result", " ".$clean_posts_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_posts_;

      }else{
     
     	echo $gwauthenticate_posts_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");


     }    
    }
    //======== count posts data function

    //======== sum  posts data function
    
    function sum_posts($posts_sumcol, $posts_wherestr)
    {
     
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "sum_data","");
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {    
      $clean_posts_where_str="";
  
      if($posts_wherestr!='')
      {
        $clean_posts_where_str="Where ".$posts_wherestr;
      }

      return get_posts("sum($posts_sumcol) as return_result", " ".$clean_posts_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_posts_;


      }else{
     
     	echo $gwauthenticate_posts_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");
        


     }    
    }
    
    //======== sum  posts data function   
    
    
    //Start drop  posts Data ===============
    
    function drop_posts($where_str)
    {
     
     $gwauthenticate_posts_=gw_oauth("table", magic_current_url(), "posts", "drop_data","");
     
     $gwauthenticate_posts_json=json_decode($gwauthenticate_posts_, true);
     
     if($gwauthenticate_posts_json["response"]=="ok")
     {    
    	return magic_sql_delete("posts", $where_str);

		//echo $gwauthenticate_posts_;

      }else{
     
     	echo $gwauthenticate_posts_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_posts_)."");
		

     }
    }
    //End drop  posts Data ===============    
    
    
            //Start Upload posts_post_image Function 
            function upload_posts_post_image($txt_posts_post_image, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_posts_post_image]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/posts_post_image')) @mkdir('./img/posts_post_image');

                $cur_item_photos=magic_upload_file('./img/posts_post_image/', $txt_posts_post_image, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $posts_node=get_posts("*", "WHERE ".$where_str."", "r");

                  if (file_exists($posts_node["post_image"]))
                  {

                      unlink($posts_node["post_image"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('posts', '{"post_image":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload posts_post_image Function 

            
   

    
 	//Start Add task_manager Data ===============
 	function add_task_manager($task_manager_arr_)
    {
     $gw_task_manager_cols=array();
     
     foreach($task_manager_arr_ as $task_manager_arr_gw => $task_manager_arr_gw_val)
     {
     
     	$gw_task_manager_cols[]=$task_manager_arr_gw;
        
     }
     
     $gw_task_manager_cols_str=implode(",", $gw_task_manager_cols);
     
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "insert",$gw_task_manager_cols_str);
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("task_manager", $task_manager_arr_);
     
     	//echo $gwauthenticate_task_manager_;

     }else{
     
     	echo $gwauthenticate_task_manager_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");

     }
     
    }
    
       function initialize_task_manager()
        {
        
         global $task_manager_uptoken;
             
         $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "select","");

         $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
         	
          //echo $gwauthenticate_task_manager_;

         if($gwauthenticate_task_manager_json["response"]=="ok")
         {
         
         	return get_task_manager("*", "WHERE primkey='$task_manager_uptoken'", "r");
         
            echo $gwauthenticate_task_manager_;

         }else{

         	echo $gwauthenticate_task_manager_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");
         
         }
        }   
    //End Add task_manager Data ===============
                
    //Start Update task_manager Data ===============
    
 	function update_task_manager($task_manager_arr_, $where_str)
    {
         $gw_task_manager_cols=array();
     
     foreach($task_manager_arr_ as $task_manager_arr_gw => $task_manager_arr_gw_val)
     {
     
     	$gw_task_manager_cols[]=$task_manager_arr_gw;
        
     }
     
     $gw_task_manager_cols_str=implode(",", $gw_task_manager_cols);
     
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "update",$gw_task_manager_cols_str);
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("task_manager", $task_manager_arr_, $where_str);

       // echo $gwauthenticate_task_manager_;
        
        exit;

     }else{

        echo $gwauthenticate_task_manager_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");


      }
    
    }
 	
    
    //End Update task_manager Data ===============

    //Start get  task_manager Data ===============
    
    function get_task_manager($colstr, $where_str, $type)
    {
          
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "select","");
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {
    	return mosyflex_sel("task_manager", $colstr, $where_str, $type);

        //echo $gwauthenticate_task_manager_;

	  }else{
     
     	echo $gwauthenticate_task_manager_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");


     }    
    }
    //End get  task_manager Data ===============
    
    
    //======== qtask_manager_data qsingle query function
    
    function qtask_manager_data($qtask_id_key)
    {
          
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "qdata","");
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {    
    	return get_task_manager("*", "WHERE task_id='$qtask_id_key'", "r");

		//echo $gwauthenticate_task_manager_;

      }else{
     
     	echo $gwauthenticate_task_manager_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");


     }  
    }
   
    //======== qtask_manager_data qsingle query function
    
    
     //======== task_manager data to array
    
    function task_manager_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "data_array","");
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {  
     	$append_task_manager_arr=array();
    
    	$array_task_manager_q=get_task_manager($colstr, $where_str, "l");
        while($array_task_manager_res=mysqli_fetch_array($array_task_manager_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_task_manager_arr[]=$array_task_manager_res[$tbl_col];
            }
          }else{
          	          
               $append_task_manager_arr[]=$array_task_manager_res;

          }
        }
        
        return $append_task_manager_arr;

		//echo $gwauthenticate_task_manager_;

      }else{
     
     	echo $gwauthenticate_task_manager_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");


     }  
    }
   
    //======== qtask_manager_data qsingle query function   
        
    //======== qtask_manager_ddata qsingle query function    
    function qtask_manager_ddata($task_id_col, $qtask_id_key)
    {
     
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "qddata","");
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {    
    	return get_task_manager("*", "WHERE $task_id_col='$qtask_id_key'", "r");

		//echo $gwauthenticate_task_manager_;

     }else{
     
     	echo $gwauthenticate_task_manager_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");


     }   
    }
    //======== qtask_manager_ddata qsingle query function

    //======== count task_manager data function
    
    function count_task_manager($task_manager_wherestr)
    {
     
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "count_data","");
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {    
      $clean_task_manager_where_str="";
  
      if($task_manager_wherestr!='')
      {
        $clean_task_manager_where_str="Where ".$task_manager_wherestr;
      }

      return get_task_manager("count(*) as return_result", " ".$clean_task_manager_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_task_manager_;

      }else{
     
     	echo $gwauthenticate_task_manager_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");


     }    
    }
    //======== count task_manager data function

    //======== sum  task_manager data function
    
    function sum_task_manager($task_manager_sumcol, $task_manager_wherestr)
    {
     
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "sum_data","");
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {    
      $clean_task_manager_where_str="";
  
      if($task_manager_wherestr!='')
      {
        $clean_task_manager_where_str="Where ".$task_manager_wherestr;
      }

      return get_task_manager("sum($task_manager_sumcol) as return_result", " ".$clean_task_manager_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_task_manager_;


      }else{
     
     	echo $gwauthenticate_task_manager_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");
        


     }    
    }
    
    //======== sum  task_manager data function   
    
    
    //Start drop  task_manager Data ===============
    
    function drop_task_manager($where_str)
    {
     
     $gwauthenticate_task_manager_=gw_oauth("table", magic_current_url(), "task_manager", "drop_data","");
     
     $gwauthenticate_task_manager_json=json_decode($gwauthenticate_task_manager_, true);
     
     if($gwauthenticate_task_manager_json["response"]=="ok")
     {    
    	return magic_sql_delete("task_manager", $where_str);

		//echo $gwauthenticate_task_manager_;

      }else{
     
     	echo $gwauthenticate_task_manager_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_task_manager_)."");
		

     }
    }
    //End drop  task_manager Data ===============    
    
    
   

    
 	//Start Add traffic_log Data ===============
 	function add_traffic_log($traffic_log_arr_)
    {
     $gw_traffic_log_cols=array();
     
     foreach($traffic_log_arr_ as $traffic_log_arr_gw => $traffic_log_arr_gw_val)
     {
     
     	$gw_traffic_log_cols[]=$traffic_log_arr_gw;
        
     }
     
     $gw_traffic_log_cols_str=implode(",", $gw_traffic_log_cols);
     
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "insert",$gw_traffic_log_cols_str);
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("traffic_log", $traffic_log_arr_);
     
     	//echo $gwauthenticate_traffic_log_;

     }else{
     
     	echo $gwauthenticate_traffic_log_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");

     }
     
    }
    
       function initialize_traffic_log()
        {
        
         global $traffic_log_uptoken;
             
         $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "select","");

         $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
         	
          //echo $gwauthenticate_traffic_log_;

         if($gwauthenticate_traffic_log_json["response"]=="ok")
         {
         
         	return get_traffic_log("*", "WHERE primkey='$traffic_log_uptoken'", "r");
         
            echo $gwauthenticate_traffic_log_;

         }else{

         	echo $gwauthenticate_traffic_log_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");
         
         }
        }   
    //End Add traffic_log Data ===============
                
    //Start Update traffic_log Data ===============
    
 	function update_traffic_log($traffic_log_arr_, $where_str)
    {
         $gw_traffic_log_cols=array();
     
     foreach($traffic_log_arr_ as $traffic_log_arr_gw => $traffic_log_arr_gw_val)
     {
     
     	$gw_traffic_log_cols[]=$traffic_log_arr_gw;
        
     }
     
     $gw_traffic_log_cols_str=implode(",", $gw_traffic_log_cols);
     
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "update",$gw_traffic_log_cols_str);
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("traffic_log", $traffic_log_arr_, $where_str);

       // echo $gwauthenticate_traffic_log_;
        
        exit;

     }else{

        echo $gwauthenticate_traffic_log_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");


      }
    
    }
 	
    
    //End Update traffic_log Data ===============

    //Start get  traffic_log Data ===============
    
    function get_traffic_log($colstr, $where_str, $type)
    {
          
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "select","");
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {
    	return mosyflex_sel("traffic_log", $colstr, $where_str, $type);

        //echo $gwauthenticate_traffic_log_;

	  }else{
     
     	echo $gwauthenticate_traffic_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");


     }    
    }
    //End get  traffic_log Data ===============
    
    
    //======== qtraffic_log_data qsingle query function
    
    function qtraffic_log_data($qschedule_id_key)
    {
          
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "qdata","");
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {    
    	return get_traffic_log("*", "WHERE schedule_id='$qschedule_id_key'", "r");

		//echo $gwauthenticate_traffic_log_;

      }else{
     
     	echo $gwauthenticate_traffic_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");


     }  
    }
   
    //======== qtraffic_log_data qsingle query function
    
    
     //======== traffic_log data to array
    
    function traffic_log_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "data_array","");
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {  
     	$append_traffic_log_arr=array();
    
    	$array_traffic_log_q=get_traffic_log($colstr, $where_str, "l");
        while($array_traffic_log_res=mysqli_fetch_array($array_traffic_log_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_traffic_log_arr[]=$array_traffic_log_res[$tbl_col];
            }
          }else{
          	          
               $append_traffic_log_arr[]=$array_traffic_log_res;

          }
        }
        
        return $append_traffic_log_arr;

		//echo $gwauthenticate_traffic_log_;

      }else{
     
     	echo $gwauthenticate_traffic_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");


     }  
    }
   
    //======== qtraffic_log_data qsingle query function   
        
    //======== qtraffic_log_ddata qsingle query function    
    function qtraffic_log_ddata($schedule_id_col, $qschedule_id_key)
    {
     
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "qddata","");
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {    
    	return get_traffic_log("*", "WHERE $schedule_id_col='$qschedule_id_key'", "r");

		//echo $gwauthenticate_traffic_log_;

     }else{
     
     	echo $gwauthenticate_traffic_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");


     }   
    }
    //======== qtraffic_log_ddata qsingle query function

    //======== count traffic_log data function
    
    function count_traffic_log($traffic_log_wherestr)
    {
     
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "count_data","");
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {    
      $clean_traffic_log_where_str="";
  
      if($traffic_log_wherestr!='')
      {
        $clean_traffic_log_where_str="Where ".$traffic_log_wherestr;
      }

      return get_traffic_log("count(*) as return_result", " ".$clean_traffic_log_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_traffic_log_;

      }else{
     
     	echo $gwauthenticate_traffic_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");


     }    
    }
    //======== count traffic_log data function

    //======== sum  traffic_log data function
    
    function sum_traffic_log($traffic_log_sumcol, $traffic_log_wherestr)
    {
     
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "sum_data","");
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {    
      $clean_traffic_log_where_str="";
  
      if($traffic_log_wherestr!='')
      {
        $clean_traffic_log_where_str="Where ".$traffic_log_wherestr;
      }

      return get_traffic_log("sum($traffic_log_sumcol) as return_result", " ".$clean_traffic_log_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_traffic_log_;


      }else{
     
     	echo $gwauthenticate_traffic_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");
        


     }    
    }
    
    //======== sum  traffic_log data function   
    
    
    //Start drop  traffic_log Data ===============
    
    function drop_traffic_log($where_str)
    {
     
     $gwauthenticate_traffic_log_=gw_oauth("table", magic_current_url(), "traffic_log", "drop_data","");
     
     $gwauthenticate_traffic_log_json=json_decode($gwauthenticate_traffic_log_, true);
     
     if($gwauthenticate_traffic_log_json["response"]=="ok")
     {    
    	return magic_sql_delete("traffic_log", $where_str);

		//echo $gwauthenticate_traffic_log_;

      }else{
     
     	echo $gwauthenticate_traffic_log_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_traffic_log_)."");
		

     }
    }
    //End drop  traffic_log Data ===============    
    
    
  //===============End Mosy queries-============

//============= Start Sql chart  Script =====================

function mosy_sql_rollback($tbl, $where, $type)
{
  $sql_fun="get_".$tbl;

  $curr_sql_ret_=$sql_fun("*", " where ".$where." ", "r");
  
  $json_sql_str=json_encode($curr_sql_ret_, true);
  
  //------- begin mosy_sql_roll_back_post_arr --> 
  $mosy_sql_roll_back_post_arr_=array(

  "primkey"=>"NULL",
  "roll_bk_key"=>mmres(magic_random_str(20)),
  "table_name"=>mmres($tbl),
  "where_str"=>mmres($where),
  "roll_type"=>mmres($type),
  "roll_timestamp"=>date("Y-m-d H:i:s"),
  "value_entries"=>mmres($json_sql_str)

  );
  //===-- End mosy_sql_roll_back_post_arr -->

  add_mosy_sql_roll_back($mosy_sql_roll_back_post_arr_);
  
  return $json_sql_str;
  
}


function get_mosychart_data($tbl, $colstr, $where_str, $xcol, $ycol, $groupby)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str="";
   $groupby_cols="";
   
   if($where_str!='')
   {
     $fun_where_str=" WHERE ".$where_str;
   }
   
   if($groupby!='')
   {
     $groupby_cols=" GROUP BY ".$groupby;
   }
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ".$groupby_cols." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================


//============= Start   mosy flex select script =====================

function mosyflex_sel($tbl, $colstr, $where_str, $loop_or_row_l_r)
{
   global $single_conn;
   global $single_db;
   global $flex_result;
   global $datalimit;
  
  $paginate_q="";
  $paginate_state="";
  
  $pagination_token=$tbl."_mpgtkn";
  
  $loop_or_row_l_rtype=$loop_or_row_l_r;
  
  if (strpos($loop_or_row_l_r, ':') !== false)
  {
    $loop_or_row_l_r_str=explode(":", $loop_or_row_l_r);

    $pagination_token=$loop_or_row_l_r_str[1];

    $loop_or_row_l_rtype=$loop_or_row_l_r_str[0];

    $paginate_state="paginate";
    
    $pagination_sql="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

    $process_pagination=mysqli_query($single_conn, $pagination_sql) or die(mysqli_error($single_conn));

    $paginate_q=mosy_paginate($process_pagination, $datalimit, $pagination_token);

    $new_where_str=$where_str." LIMIT ".$paginate_q[0].", $datalimit ";

    $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_str."";
    

  }else{
    
      $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

  }
   
    
  $flex_result_q=mysqli_query($single_conn, $sql_str) or die(mysqli_error($single_conn));
  
  $flex_result=$flex_result_q;

  if($loop_or_row_l_rtype=='r')
  {
    $flex_result_r=mysqli_fetch_array($flex_result_q);
    
    $flex_result=$flex_result_r;
    
  }
  
  if($paginate_state=='paginate')
  {
  	$flex_result=array($flex_result_q, $paginate_q[1], $paginate_q[0], $sql_str, $pagination_sql);  
  }
  
  return $flex_result;
  
}

function mosy_paginate($sqlstring, $reclimit, $token_name)
{

  $requested_page = isset($_GET[$token_name]) ? intval(base64_decode($_GET[$token_name])) : 1;

  $rows_count = mysqli_num_rows($sqlstring);

  $items_per_page = $reclimit;

  $page_count = ceil($rows_count / $items_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_row = ($requested_page - 1) * $items_per_page;

  $recordperpage_data=array($first_row,$page_count);

  return $recordperpage_data;
  
}
//============= End  mosy flex select script =====================

  function tonum($number_str, $decplaces=0)
  {
	if($number_str=='')
    {
      $number_str=0;
    }
  	return number_format($number_str, $decplaces, ".", ",");
  	

  }
  
//checkblank fuction

function checkblank($value, $return_val)
{
  
  global $fun_resonse;

  if($value!='')
  {
  $fun_resonse=$value;
  }else{
    $fun_resonse=$return_val;

  }
  return $fun_resonse;

}

//get date foramrt

function ftime($time_st, $type)
{
  	global $timeresp;
    
  $timeresp=date("l, jS, M, y, @ H:i:s");

  if($time_st=="") 
  {
    $timeresp=date("l, jS, M, y, @ H:i:s");

  	if($type=="date")
    {
    $timeresp=date("l, jS, M, y");
    }
    
  }
  
  if($time_st!=""){
  
     $timeresp=date("l, jS, M, y, @ H:i:s", strtotime($time_st));

    if($type=="date")
    {
    	$timeresp=date("l, jS, M, y", strtotime($time_st));
    }
    
  }
	return $timeresp;
}

function date_time_input($time_st, $full_date_time="")
{
  	global $timeresp;
    
    $date_form="Y-m-d\TH:i:s";
    
    if($full_date_time=="date")
    {
    $date_form="Y-m-d";
    }
    
    if($full_date_time=="time")
    {
    $date_form="H:i:s";
    }
    
  if($time_st==""){
  	$timeresp=date($date_form);
  }else{
   
   $timeresp=date($date_form, strtotime($time_st));

  }
	return $timeresp;
}
function daytime()
{
  global $daytime;

  $daytime='Hello';

  $fromdate=date('A');
  $eve_aft=date("H");

  if($fromdate=='AM'){
 	 $daytime='Morning';
  }
  
  if($fromdate=='PM' && $eve_aft<17){
  	$daytime='Afternoon';
  }
  
  if($fromdate=='PM' && $eve_aft>17){
  	$daytime='Evening';
  }

  return $daytime;
}


function mosy_month_year_diff($start_date, $end_date, $myd="m")
{

  $ts1 = strtotime($start_date);
  $ts2 = strtotime($end_date);

  $year1 = date("Y", $ts1);
  $year2 = date("Y", $ts2);

  $month1 = date("m", $ts1);
  $month2 = date("m", $ts2);

  $date1=date_create($start_date);
  $date2=date_create($end_date);

  $day_diff=date_diff($date1,$date2);

  $day_diff_count=$day_diff->format("%R%a");
    
  $year_diff_=$year2 - $year1;
  $month_diff_=$month2 - $month1;

  $diff = (($year_diff_) * 12) + ($month_diff_);

  $ret_diff=$year_diff_;

  if($myd=="m")
  {
    $ret_diff=$diff;
  }
  
  if($myd=="d")
  {
    $ret_diff=$day_diff_count;
  }
  
  if($myd=="y")
  {
    $ret_diff=$year_diff_;
  }

  return $ret_diff;

}

function ifnotblank($str,$replacement)
{
	
    if($str!="")
    {
     return $replacement;
     
    }else{
    return $str;
    }

}

function time_elapsed_string($datetime, $full = false) 
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        "y" => "year",
        "m" => "month",
        "w" => "week",
        "d" => "day",
        "h" => "hour",
        "i" => "minute",
        "s" => "second",
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . " " . $v . ($diff->$k > 1 ? "s" : "");
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(", ", $string) . " ago" : "just now";
}

if (file_exists("./mosy_paginate.php")){
include("./mosy_paginate.php");
}

function pdf_url($current, $pdfurl)
{
  
  $filter_param=str_replace($current."", $pdfurl."", (magic_current_url()));

  if(strpos($filter_param, '?') !== false) 
  {
    $filter_param=str_replace($current."?", $pdfurl."?", (magic_current_url()));

  }

  if(strpos($filter_param, '.php?') !== false) 
  {
    $filter_param=str_replace($current.".php?", $pdfurl."?", (magic_current_url()));

  }

  return $filter_param;
  
}


function mosy_send_mail($to_email, $from_email, $sender_name, $subject, $message, $use_api="")
{
	// create email headers
	$replyto_mail="";
	$returnpath="";
	$headers="";

	if($from_email!='')
	{
    	$replyto_mail='Reply-To: ' .$sender_name." <".$from_email.">\r\n";
    	$returnpath='Return-Path: ' .$sender_name." <".$from_email.">\r\n";
	}

	$busmail=$from_email;
	$bus_name=$sender_name;

	if($to_email=='')
	{
		$busmail='info@clearphrases.com';
	}

	if($sender_name=='')
	{
		$bus_name="";
	}

    $headers = 'From: '.$bus_name.'<'.$busmail.'>' . "\r\n" .
    $headers.=$replyto_mail;
    $headers.=$returnpath;
    $headers .= "Organization: ".$bus_name."\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers.='Content-type: text/html; charset=UTF-8'. "\r\n";
    $headers .= "X-Priority: 3\r\n";
    $headers .= "X-Mailer: PHP". phpversion() ."\r\n";
   
  if($use_api=="yes")
  {
    
    $curlopt_url="https://origin.clearphrases.com/api/email/mosy_mail.php";
    
    $email_attr="send_mosy_email&to_email=".rawurlencode($to_email)."&from_email=".rawurlencode($from_email)."&sender_name=".rawurlencode($sender_name)."&subject=".rawurlencode($subject)."&message=".rawurlencode($message)."";
    
   return magic_post_curl($curlopt_url, "", "", $email_attr, "POST");

  }else{
    
  return mail($to_email, $subject, $message, $headers);        
  }
}


function mosy_push_sms($recp, $sms_body, $smsapi_url="")
{

  
  if($smsapi_url=="")
  {
    $smsapi_url="https://origin.clearphrases.com/api/sms/adminsmsgateway.php";
  }
  
  $sms_request="pushsms&recp=".$recp."&body=".$sms_body."";

  return magic_post_curl($smsapi_url, '', '', $sms_request, 'POST');

}
function add_url_param( $key, $value, $passed_url) 
{
  $url=$passed_url;
  if($passed_url=='')
  {
    $url=magic_current_url();
  }
  
  $info = parse_url( $url );

  if(isset($info['query']))
  {
    parse_str( $info['query'], $query );
  }else{
    $query="";
  }
    return $info['scheme'] . '://' . $info['host'] . $info['path'] . '?' . http_build_query( $query ? array_merge( $query, array($key => $value ) ) : array( $key => $value ) );
}

//<--ncgh-->
?>