<?php 
ob_start();

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
include('./conn.php');
include('./phpmagicbits.php');
//include('./gwdna.php');
include('./datahandler.php');
include('./requesthandler.php');
include('./customfunctions.php');

include('./applyapi.php');

if(isset($_POST['ajax_test']))
{
	echo '<div class="badge badge-success">this is a Test result from server</div>';
}

if(isset($_POST["mosyajax_sql_data"]))
{
  	$curr_tbl=$_POST['tbl'];
    $col_str_=$_POST['colstr'];

  
	$sql_function_name=('get_'.$curr_tbl);
  
  	$pagination="l";

   if(isset($_POST['pagination']))
   {

    if($_POST['pagination']!='')
    {
      $pagination="l:".$_POST['pagination'];
    }
  }
  	$check_oauth=gw_oauth('table', $_SERVER['HTTP_REFERER'], $curr_tbl, "select", "");
  	$check_oauth_resp=json_decode($check_oauth, true);
  
  	if($check_oauth_resp['response']=='ok')
    {
    //=== start packages select  Like Query String packages list  
	$ajax_loop_curr_tbl_q=$sql_function_name($col_str_, $_POST['mosyajax_sql_data'], $pagination);
	$return_no_tag=$sql_function_name($col_str_, $_POST['mosyajax_sql_data'], "l");
    $return_no_tag_res=array();
  

    $ajax_loop_curr_tbl_q_str=$ajax_loop_curr_tbl_q;
      
    if($pagination!="l")
    {
      $ajax_loop_curr_tbl_q_str=$ajax_loop_curr_tbl_q[0];
    }
  
  //echo magic_message($_POST['mosyajax_sql_data']);
  	while($return_no_tag_r=mysqli_fetch_array($return_no_tag))
    {
  	
      $return_no_tag_res[]=$return_no_tag_r;
  	
  	}
  	$node_function_name_str=$_POST['node_function_name'];
  
    if (strpos($node_function_name_str, ':') !== false) 
    {
      $explode_user_function=explode(":", $node_function_name_str);
      $node_function_name=$explode_user_function[0];
      $additional_user_function_str=$explode_user_function[1];
      
      $explode_additional_params=explode(",", $additional_user_function_str);
      $function_array=array();
      
      foreach($explode_additional_params as $param_str)
      {
      	$function_array[]="'".$param_str."'";  
      }
      
      $additional_user_function=", [".implode(",", $function_array)."]";
      
    }else{
      $node_function_name=$node_function_name_str;
      $additional_user_function="";
    }
  
   	$ui_tag1=$_POST['ui_tag'];
    $ui_tag2=str_replace("{{<}}", "<", $ui_tag1);
    $ui_tag3=str_replace("{{>}}", ">", $ui_tag2);
    $ui_tag4=str_replace("{{on click}}", "onclick", $ui_tag3);
    $ui_tag5=str_replace("{{on keyup}}", "onkeyup", $ui_tag4);   
    $ui_tag=str_replace("{{on error}}", "onerror", $ui_tag5);   
  
    if (strpos($ui_tag, '=>') !== false) 
    {
  
      //$ui_template=explode("=>", $ui_tag)[1];
              
    }
  
  	$js_columns=array();  
	$name_col_arr=array();
  	$name_label_arr=array();
  


  	$ui_columns="";
    $card_str="";
  
  	$exploded_cols=explode(",", $_POST["cols"]);

       foreach($exploded_cols as $colname)
    	{
          
          if (strpos($colname, ':') !== false) 
          {
			$label_str=explode(":", $colname);            
            $name_label_arr[]=$label_str[1];
           	$name_col_arr[]=$label_str[0];
            
            if(array_key_exists(2, $label_str) )
            {
            $name_label_arr[]=$label_str[1].":".$label_str[2];  
            }
			

          }else{
            
            $js_columns[]=magic_clean_str($colname);

          }
           
    	}
	
      $i=0;
  
    while($data_res=mysqli_fetch_array($ajax_loop_curr_tbl_q_str))
    {
    $i++;
      
    $custom_ui_search_data_point=array();
	$custom_ui_replace_data_point=array();
	$custom_ui_search_label_point=array();
	$custom_ui_replace_label_point=array();
      
      $node_card_len=count($name_label_arr)-1;
      $js_cols_len=count($js_columns)-1;
      
      $data_node_card_c=-1;
      $data_node_card='';
      
      while($data_node_card_c<=$node_card_len)
      {
        $data_node_card_c++;
        
        
        if($data_node_card_c<$node_card_len+1)
        {

          if (strpos($name_label_arr[$data_node_card_c], '|') !== false) 
          {
         
          $custom_data_point=explode("|", $name_label_arr[$data_node_card_c]);  
          $custom_data_node1=eval(("\$custom_data_node= ".$custom_data_point[1].";"));;  
          $custom_label_node=$custom_data_point[0];
  
            //echo $custom_data_node;
          }else{
                     
            $custom_data_node=$data_res[$name_col_arr[$data_node_card_c]];
            $custom_label_node=$name_label_arr[$data_node_card_c];

          }
          
          
          if($ui_tag=='card')
          {
              $data_node_card.='<div class="col-md-12 p-1 m-0"> <b> '.$custom_label_node.'</b> : '.$custom_data_node.'</div>';
          }
          
          if($ui_tag=='option')
          {
              $data_node_card.=$custom_data_node;
          }  
          
          if($ui_tag=='tr')
          {
              $data_node_card.='<td class="">'.$custom_data_node.'</td>';
          }

			$custom_ui_search_data_point[]="{{".$name_col_arr[$data_node_card_c]."}}";
          	$custom_ui_replace_data_point[]=$data_res[$name_col_arr[$data_node_card_c]];
          
          	$custom_ui_search_label_point[]="{{".$custom_label_node."}}";
            $custom_ui_replace_label_point[]=$custom_data_node;
          
 
        }
        
      }
   
                
          if (strpos($ui_tag, '=>') !== false) 
          {
	
              $ui_template=explode("=>", $ui_tag)[1];
              $search_data_points_str =$custom_ui_search_data_point;            
         	  $replace_data_points_str =$custom_ui_replace_data_point;
            
              $search_label_points_str =$custom_ui_search_label_point;            
         	  $replace_label_points_str =$custom_ui_replace_label_point;

              
              $data_node_card1= str_replace($search_data_points_str, magic_clean_str($replace_data_points_str), $ui_template);
              $data_node_card2= str_replace($search_label_points_str, magic_clean_str($replace_label_points_str), $data_node_card1);                          
              $data_node_card.= str_replace("{{row_count}}", magic_clean_str($i), $data_node_card2);

            
          }

      $jsexe_node_card_c=-1;
      $jsexe_node_card=array();
      $option_inner_val_str=array();
      
      while($jsexe_node_card_c<=$js_cols_len)
      {
        $jsexe_node_card_c++;
                
        if($jsexe_node_card_c<$js_cols_len+1)
        {
              $jsexe_node_card[]='\''.magic_clean_str($data_res[$js_columns[$jsexe_node_card_c]]).'\'';
              $option_inner_val_str[]=magic_clean_str($data_res[$js_columns[$jsexe_node_card_c]]);
          
        }
        
      }
      
      $js_function_data_node="[".implode(",", $jsexe_node_card)."]".$additional_user_function;
      $option_inner_value=implode(",", $option_inner_val_str);
      
      if($option_inner_value=='')
      {
        $option_inner_value=$data_node_card;
      }
      
          if($ui_tag=='card')
          {
            
          $card_str.='
              <div class="col-md-12 p-0 text-left mr-0 cpointer border-bottom border_set" onclick="'.$node_function_name.'('.$js_function_data_node.')">  
				<span class="badge">'.$data_node_card.'</span>
			  </div>';
            
            
          }

          if($ui_tag=='option')
          {
            
          $card_str.='
              <option value="'.$option_inner_value.'" >'.$data_node_card.'</option>';
          }

          if($ui_tag=='tr')
          {
            $card_str.='
              <tr class="" style="cursor:pointer;" onclick="'.$node_function_name.'('.$js_function_data_node.')">  
				'.$data_node_card.'
			  </tr>';
          }
      
          if (strpos($ui_tag, '=>') !== false) 
          {
              $card_str.=str_replace("{{".$node_function_name."}}", $node_function_name.'('.$js_function_data_node.')', $data_node_card);

              
              
          }


    }	

          if($ui_tag=='')
          {
			echo json_encode($return_no_tag_res, true);
          }else{
    		echo  $card_str;
          }
    }else{
      echo $check_oauth;
    }
}

if(isset($_POST["mosyajax_create"]))
{
  
  $tbl=$_POST['tbl'];
  
  	$check_oauth=gw_oauth('table', $_SERVER['HTTP_REFERER'], $_POST['tbl'], "insert", "");
  	$check_oauth_resp=json_decode($check_oauth, true);
  
  	if($check_oauth_resp['response']=='ok')
    {
      
      //------- begin Insert Query Vars --> 
      //additional insert colmuns and values 
      $tbl_cols_arr=explode(",", $_POST['tbl_cols']);
      $tbl_vals_arr=explode(",", $_POST['tbl_vals']);

      $tbl_cols_fin=array();

      $tbl_vals_fin=array();

      foreach($tbl_cols_arr as $cols_arr)
      {
        $tbl_cols_fin[]="`".trim($cols_arr)."`";
      }


      foreach($tbl_vals_arr as $vals_arr)
      {
        if($vals_arr!='NULL')
        {
        $tbl_vals_fin[]="'".$vals_arr."'";
        }else{
        $tbl_vals_fin[]=mmres($vals_arr);
        }
      }

      $tbl_cols=implode(",", ($tbl_cols_fin));
      $tbl_vals=implode(",", $tbl_vals_fin);

      echo $tbl_cols."-".$tbl_vals;
       mysqli_query($single_conn, "INSERT INTO `$single_db`.`".$tbl."` (".$tbl_cols.") 
       VALUES 
      (".$tbl_vals.")") or die(mysqli_error($single_conn));

       //--- get primary key id
      echo mysqli_insert_id($mysqliconn);
      
      }else{
      
      echo $check_oauth;
    }
  
}
if(isset($_GET['_grid_updt_']))
{
  
   $curr_updt_tbl=base64_decode($_GET['_grid_updt_']);  
   $curr_fun_name='update_'.$curr_updt_tbl;
   $colstr=base64_decode($_GET['colstr']);
   $newcolval=base64_decode($_GET['newcolval']);
   $editor=base64_decode($_GET['editor']);
   $updt_key=base64_decode($_GET['updt_key']);

   ///echo $curr_updt_tbl;
  
   $payload_arr=array($colstr=>$newcolval);
  
   ///print_r($payload_arr);
  
   $curr_fun_name($payload_arr, " ".$editor." = '".$updt_key."' ");
  
   
}
if(isset($_POST['mosyajax_update']))
{
  //------- begin Update Query acc_renewals Vars --> 
//additional update colmuns and values 
    $tbl_update_str=$_POST["update_str"];

    $tbl=$_POST['tbl'];
  
   	$check_oauth=gw_oauth('table', $_SERVER['HTTP_REFERER'], $_POST['tbl'], "update", "");
  	$check_oauth_resp=json_decode($check_oauth, true);
  
  	if($check_oauth_resp['response']=='ok')
    {
       
      $where_str=$_POST['where_str'];

      mysqli_query($single_conn, "UPDATE  `$single_db`.`".$tbl."` SET ".$tbl_update_str." WHERE ".$where_str."") or die(mysqli_error($single_conn));
  
    }else{
      echo $check_oauth;
    }
}

if(isset($_POST['mosyajax_drop']))
{
  //------- begin Update Query acc_renewals Vars --> 
//additional update colmuns and values   
	$tbl=$_POST['tbl'];
  
   	$check_oauth=gw_oauth('table', $_SERVER['HTTP_REFERER'], $_POST['tbl'], "delete", "");
  	$check_oauth_resp=json_decode($check_oauth, true);
  
  	if($check_oauth_resp['response']=='ok')
    {
        
    $where_str=$_POST['where_str'];

    mysqli_query($single_conn, "DELETE FROM  `$single_db`.`".$tbl."` WHERE ".$where_str."") or die(mysqli_error($single_conn));
      
    }else{
      echo $check_oauth;
    }
}



?>