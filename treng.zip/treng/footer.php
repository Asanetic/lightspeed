<div id="ajax_snack"></div>
<div id="dialog_box"></div>
<div id="alert_box"></div>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="./treng/js/jquery_main.js"></script>
    <script src="./treng/js/popper.js"></script>
    <script src="./treng/js/jsfunctions.js"></script>
    <script src="./treng/js/boot.js"></script>
    <script src="./treng/js/datahandler.js?v=<?php echo date("dmyhisa") ?>"></script>
    <script src="./treng/js/wgt_datahandler.js?v=<?php echo date("dmyhisa") ?>"></script>
    <script src="./treng/js/wgt_datahandler_list.js?v=<?php echo date("dmyhisa") ?>"></script>
    <script src="./treng/js/ui_ux.js?v=<?php echo date("dmyhisa") ?>"></script>
  
	<?php if(isset($_GET['table_alert'])){?>
	mosy_snack_wgt('<?php echo $_GET['table_alert'] ?>', "top", "snack_box", "200px", "table_alert_toast", '<?php echo $btn_txt ?>',  '<?php echo $btn_bg ?>', '');
    mosytoggle_class('table_alert_toast', 'show');
                                          
	  setTimeout(function(){ 
        
       push_html('snack_box', '');                                          

          //your code here

        }, 3000);
    <?php }?>