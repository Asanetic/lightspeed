<?php
function social_media_str($msg_cont)
{
  
    $messagecont3=str_replace('<p>','',nl2br($msg_cont));

    $messagecont2=str_replace('</p>',"\n\n",$messagecont3);
    $messagecont4=str_replace('&nbsp;'," ",$messagecont2);
    $messagecont5=str_replace('<br/>',"\n\n",$messagecont4);
    $messagecont6=str_replace('<ul>',"\n\n",$messagecont5);
    $messagecont7=str_replace('</ul>',"\n\n",$messagecont6);
    $messagecont8=str_replace('<li>',"\n\n",$messagecont7);
    $messagecont9=str_replace('</li>',"\n\n",$messagecont8);
    $messagecont10=str_replace('<br>',"\n\n",$messagecont9);
    $messagecont11=str_replace('<div>',"\n\n",$messagecont10);
    $messagecont12=str_replace('</div>',"",$messagecont11);
    $messagecont=magic_strip_if(strip_tags($messagecont12), 200, 200);
  
  return $messagecont;
  
}
  

function create_campaign_link($post_id, $market_id)
{
    $post_attr_data=qposts_data($post_id);

    if($market_id=='')
    {
      $market_id=$post_attr_data['page'];
    }
  
    $post_landing_page_=qpage_links_ddata("link_id", $post_attr_data['link'])['linkurl'];

	$camplinknavar1=$post_landing_page_."?campid=".base64_encode($post_attr_data['msgid'])."&markid=".base64_encode($market_id);
  
    if(strpos($post_landing_page_, '?')!==false){
      
	$camplinknavar1=$post_landing_page_."&campid=".base64_encode($post_attr_data['msgid'])."&markid=".base64_encode($market_id);

    }
          
       $camplinknavar=file_get_contents('http://tinyurl.com/api-create.php?url='.$camplinknavar1.'');

      if($post_attr_data['sharable_link']=='' && $post_attr_data['link'])
      {

          update_posts(['sharable_link'=>$camplinknavar], "msgid='".$post_attr_data['msgid']."'");
      }
  
  return [$camplinknavar1, $camplinknavar];
}

if(isset($_GET['create_campaign_link']))
{
  echo create_campaign_link($_GET['post_id'], $_GET['market_id'])[$_GET['arr_value']];
}

if(isset($_POST['add_read_state']))
{

  update_system_notifications(['user_read_state'=>"?"], " primkey='$system_notifications_uptoken'");
  
}


if(isset($_POST['system_notifications_insert_btn']))
{

  //echo mosy_send_mail("jereasanya@gmail.com", "info@clearphrases.com", "Traffic Engine", $_POST['txt_notification_title'], $_POST['txt_notificstion_details'], "yes");
  
  echo mosy_push_sms("0710766390", $_POST['txt_notification_title']);
  
}

function frun_time($date_str)
{
  return date_time_input($date_str, "");
}  

function trim_text($str)
{
  
  return magic_strip_if($str, 90, 90);
  
}
?>