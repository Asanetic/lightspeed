<?php
if (session_status() == PHP_SESSION_NONE) 
{
  session_start();
}

date_default_timezone_set("Africa/Nairobi");

  //local conn
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password

$db="agkks";
$ags="agkks";

$mosyapis=[
  "ags"=>"http://localhost/origin/ags/mosyapi.php"
];

$root_url=$mosyapis["ags"];
$image_root="http://localhost/origin/ags/";

$def_dashboard="index";

/*
  //online conn

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password

$db="ags";
$ags="ags";

*/

$mysqliconn=mysqli_connect("$host", "$username", "$password") or die("cannot connect"); 

mysqli_select_db($mysqliconn, $db);

$single_db=$db;
$single_conn=$mysqliconn;

$datalimit=15;

if(isset($_SESSION["filelim"]))
{
 $datalimit=$_SESSION["filelim"];
}
////=========== record per page function 
?>