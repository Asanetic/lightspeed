<?php 
//===============Start Mosy queries-============ 

    
 	//Start Add courses Data ===============
 	function add_courses($courses_arr_)
    {
     $gw_courses_cols=array();
     
     foreach($courses_arr_ as $courses_arr_gw => $courses_arr_gw_val)
     {
     
     	$gw_courses_cols[]=$courses_arr_gw;
        
     }
     
     $gw_courses_cols_str=implode(",", $gw_courses_cols);
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "insert",$gw_courses_cols_str);
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("courses", $courses_arr_);
     
     	//echo $gwauthenticate_courses_;

     }else{
     
     	echo $gwauthenticate_courses_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");

     }
     
    }
    
       function initialize_courses()
        {
        
         global $courses_uptoken;
             
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "select","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
         
         	return get_courses("*", "WHERE primkey='$courses_uptoken'", "r");
         
            echo $gwauthenticate_courses_;

         }else{

         	echo $gwauthenticate_courses_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");
         
         }
        } 
        
       function mginitialize_courses($endpoint="")
        {
        
         global $courses_uptoken;
             
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "select","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("courses", "*", "WHERE primkey='$courses_uptoken'", "l", "", $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_courses_;

         }else{

         	echo $gwauthenticate_courses_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");
         
         }
        }         
    //End Add courses Data ===============
                
    //Start Update courses Data ===============
    
 	function update_courses($courses_arr_, $where_str)
    {
         $gw_courses_cols=array();
     
     foreach($courses_arr_ as $courses_arr_gw => $courses_arr_gw_val)
     {
     
     	$gw_courses_cols[]=$courses_arr_gw;
        
     }
     
     $gw_courses_cols_str=implode(",", $gw_courses_cols);
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "update",$gw_courses_cols_str);
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("courses", $courses_arr_, $where_str);

       // echo $gwauthenticate_courses_;
        
        exit;

     }else{

        echo $gwauthenticate_courses_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


      }
    
    }
 	
    
    //End Update courses Data ===============


    //Start get  courses Data ===============
    
    function get_courses($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "select","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {
    	return mosyflex_sel("courses", $colstr, $where_str, $type);

        //echo $gwauthenticate_courses_;

	  }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }    
    }
    //End get  courses Data ===============
    
  //Start get  courses Data ===============
    
    function mgget_courses($colstr="*", $where_str="", $type="l", $endpoint="")
    {
          
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "select","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {
     
        return mosyget_("courses", $colstr, $where_str, $type, "", $endpoint);
        
        
    	//return mosyflex_sel("courses", $colstr, $where_str, $type);

        //echo $gwauthenticate_courses_;

	  }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }    
    }
    //End get  courses Data ===============
            

    //======== qcourses_data qsingle query function
    
    function qcourses_data($qcourse_id_key)
    {
          
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "qdata","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
    	return get_courses("*", "WHERE course_id='$qcourse_id_key'", "r");

		//echo $gwauthenticate_courses_;

      }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }  
    }
    
    function mgqcourses_data($qcourse_id_key, $endpoint="")
    {
          
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "qdata","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("courses", "*", "WHERE course_id='$qcourse_id_key'", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_courses_;

      }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }  
    }
   
    //======== qcourses_data qsingle query function
    
    
     //======== courses data to array
    
    function courses_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "data_array","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {  
     	$append_courses_arr=array();
    
    	$array_courses_q=get_courses($colstr, $where_str, "l");
        while($array_courses_res=mysqli_fetch_array($array_courses_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_courses_arr[]=$array_courses_res[$tbl_col];
            }
          }else{
          	          
               $append_courses_arr[]=$array_courses_res;

          }
        }
        
        return $append_courses_arr;

		//echo $gwauthenticate_courses_;

      }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }  
    }
   
    //======== qcourses_data qsingle query function   
        
    //======== qcourses_ddata qsingle query function    
    function qcourses_ddata($course_id_col, $qcourse_id_key)
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "qddata","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
    	return get_courses("*", "WHERE $course_id_col='$qcourse_id_key'", "r");



		//echo $gwauthenticate_courses_;

     }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }   
    }
    
    function mgqcourses_ddata($course_id_col, $qcourse_id_key, $endpoint="")
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "qddata","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("courses", "*", "WHERE $course_id_col='$qcourse_id_key'", "l", "", $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_courses_;

     }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }   
    }    
    //======== qcourses_ddata qsingle query function
    
        //======== qcourses_gdata qsingle query function    
    function qcourses_gdata($courses_where="")
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "gddata","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
     	$where_str="";
        if($courses_where!=="")
        {
        $where_str=" ".$courses_where;
        }
    	return get_courses("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_courses_;

     }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }   
    }
    
    function mgqcourses_gdata($courses_where="", $endpoint="")
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "gddata","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
     	$where_str="";
        if($courses_where!=="")
        {
        $where_str=" ".$courses_where;
        }
        
        $return_data_set = mosyget_("courses", "*", " ".$where_str." ", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_courses_;

     }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }   
    }
    //======== qcourses_gdata qsingle query function
    

    //======== count courses data function
    
    function count_courses($courses_wherestr)
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "count_data","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
      $clean_courses_where_str="";
  
      if($courses_wherestr!='')
      {
        $clean_courses_where_str="Where ".$courses_wherestr;
      }

      return get_courses("count(*) as return_result", " ".$clean_courses_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_courses_;

      }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }    
    }
    
    function mgcount_courses($courses_wherestr, $endpoint="")
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "count_data","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
      $clean_courses_where_str="";
  
      if($courses_wherestr!='')
      {
        $clean_courses_where_str="Where ".$courses_wherestr;
      }

         $return_data_set= mosyget_("courses", "count(*) as return_result", " ".$clean_courses_where_str."", "l", "", $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_courses_;

      }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");


     }    
    }    
    //======== count courses data function
    
    

    //======== sum  courses data function
    
    function sum_courses($courses_sumcol, $courses_wherestr)
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "sum_data","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
      $clean_courses_where_str="";
  
      if($courses_wherestr!='')
      {
        $clean_courses_where_str="Where ".$courses_wherestr;
      }

      return get_courses("sum($courses_sumcol) as return_result", " ".$clean_courses_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_courses_;


      }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");
        


     }    
    }
    
    function mgsum_courses($courses_sumcol, $courses_wherestr, $endpoint="")
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "sum_data","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
      $clean_courses_where_str="";
  
      if($courses_wherestr!='')
      {
        $clean_courses_where_str="Where ".$courses_wherestr;
      }
      
        $return_data_set = mosyget_("courses", "sum($courses_sumcol) as return_result", " ".$clean_courses_where_str."", "l", "", $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;

      //echo $gwauthenticate_courses_;


      }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");
        


     }    
    }    
    
    //======== sum  courses data function   
    
    
    //Start drop  courses Data ===============
    
    function drop_courses($where_str)
    {
     
     $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "drop_data","");
     
     $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
     
     if($gwauthenticate_courses_json["response"]=="ok")
     {    
    	return magic_sql_delete("courses", $where_str);

		//echo $gwauthenticate_courses_;

      }else{
     
     	echo $gwauthenticate_courses_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");
		

     }
    }
    //End drop  courses Data ===============    
    
    
            //Start Upload courses_user_pic Function 
            function upload_courses_user_pic($txt_courses_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_courses_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/courses_user_pic')) @mkdir('./img/courses_user_pic');

                $cur_item_photos=magic_upload_file('./img/courses_user_pic/', $txt_courses_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $courses_node=get_courses("*", "WHERE ".$where_str."", "r");

                  if (file_exists($courses_node["user_pic"]))
                  {

                      unlink($courses_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('courses', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload courses_user_pic Function 

            
   

    
 	//Start Add lessons Data ===============
 	function add_lessons($lessons_arr_)
    {
     $gw_lessons_cols=array();
     
     foreach($lessons_arr_ as $lessons_arr_gw => $lessons_arr_gw_val)
     {
     
     	$gw_lessons_cols[]=$lessons_arr_gw;
        
     }
     
     $gw_lessons_cols_str=implode(",", $gw_lessons_cols);
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "insert",$gw_lessons_cols_str);
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("lessons", $lessons_arr_);
     
     	//echo $gwauthenticate_lessons_;

     }else{
     
     	echo $gwauthenticate_lessons_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");

     }
     
    }
    
       function initialize_lessons()
        {
        
         global $lessons_uptoken;
             
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "select","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
         
         	return get_lessons("*", "WHERE primkey='$lessons_uptoken'", "r");
         
            echo $gwauthenticate_lessons_;

         }else{

         	echo $gwauthenticate_lessons_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");
         
         }
        } 
        
       function mginitialize_lessons($endpoint="")
        {
        
         global $lessons_uptoken;
             
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "select","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("lessons", "*", "WHERE primkey='$lessons_uptoken'", "l", "", $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_lessons_;

         }else{

         	echo $gwauthenticate_lessons_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");
         
         }
        }         
    //End Add lessons Data ===============
                
    //Start Update lessons Data ===============
    
 	function update_lessons($lessons_arr_, $where_str)
    {
         $gw_lessons_cols=array();
     
     foreach($lessons_arr_ as $lessons_arr_gw => $lessons_arr_gw_val)
     {
     
     	$gw_lessons_cols[]=$lessons_arr_gw;
        
     }
     
     $gw_lessons_cols_str=implode(",", $gw_lessons_cols);
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "update",$gw_lessons_cols_str);
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("lessons", $lessons_arr_, $where_str);

       // echo $gwauthenticate_lessons_;
        
        exit;

     }else{

        echo $gwauthenticate_lessons_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


      }
    
    }
 	
    
    //End Update lessons Data ===============


    //Start get  lessons Data ===============
    
    function get_lessons($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "select","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {
    	return mosyflex_sel("lessons", $colstr, $where_str, $type);

        //echo $gwauthenticate_lessons_;

	  }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }    
    }
    //End get  lessons Data ===============
    
  //Start get  lessons Data ===============
    
    function mgget_lessons($colstr="*", $where_str="", $type="l", $endpoint="")
    {
          
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "select","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {
     
        return mosyget_("lessons", $colstr, $where_str, $type, "", $endpoint);
        
        
    	//return mosyflex_sel("lessons", $colstr, $where_str, $type);

        //echo $gwauthenticate_lessons_;

	  }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }    
    }
    //End get  lessons Data ===============
            

    //======== qlessons_data qsingle query function
    
    function qlessons_data($qlesson_id_key)
    {
          
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "qdata","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
    	return get_lessons("*", "WHERE lesson_id='$qlesson_id_key'", "r");

		//echo $gwauthenticate_lessons_;

      }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }  
    }
    
    function mgqlessons_data($qlesson_id_key, $endpoint="")
    {
          
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "qdata","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("lessons", "*", "WHERE lesson_id='$qlesson_id_key'", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_lessons_;

      }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }  
    }
   
    //======== qlessons_data qsingle query function
    
    
     //======== lessons data to array
    
    function lessons_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "data_array","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {  
     	$append_lessons_arr=array();
    
    	$array_lessons_q=get_lessons($colstr, $where_str, "l");
        while($array_lessons_res=mysqli_fetch_array($array_lessons_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_lessons_arr[]=$array_lessons_res[$tbl_col];
            }
          }else{
          	          
               $append_lessons_arr[]=$array_lessons_res;

          }
        }
        
        return $append_lessons_arr;

		//echo $gwauthenticate_lessons_;

      }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }  
    }
   
    //======== qlessons_data qsingle query function   
        
    //======== qlessons_ddata qsingle query function    
    function qlessons_ddata($lesson_id_col, $qlesson_id_key)
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "qddata","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
    	return get_lessons("*", "WHERE $lesson_id_col='$qlesson_id_key'", "r");



		//echo $gwauthenticate_lessons_;

     }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }   
    }
    
    function mgqlessons_ddata($lesson_id_col, $qlesson_id_key, $endpoint="")
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "qddata","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("lessons", "*", "WHERE $lesson_id_col='$qlesson_id_key'", "l", "", $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_lessons_;

     }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }   
    }    
    //======== qlessons_ddata qsingle query function
    
        //======== qlessons_gdata qsingle query function    
    function qlessons_gdata($lessons_where="")
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "gddata","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
     	$where_str="";
        if($lessons_where!=="")
        {
        $where_str=" ".$lessons_where;
        }
    	return get_lessons("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_lessons_;

     }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }   
    }
    
    function mgqlessons_gdata($lessons_where="", $endpoint="")
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "gddata","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
     	$where_str="";
        if($lessons_where!=="")
        {
        $where_str=" ".$lessons_where;
        }
        
        $return_data_set = mosyget_("lessons", "*", " ".$where_str." ", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_lessons_;

     }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }   
    }
    //======== qlessons_gdata qsingle query function
    

    //======== count lessons data function
    
    function count_lessons($lessons_wherestr)
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "count_data","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
      $clean_lessons_where_str="";
  
      if($lessons_wherestr!='')
      {
        $clean_lessons_where_str="Where ".$lessons_wherestr;
      }

      return get_lessons("count(*) as return_result", " ".$clean_lessons_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_lessons_;

      }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }    
    }
    
    function mgcount_lessons($lessons_wherestr, $endpoint="")
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "count_data","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
      $clean_lessons_where_str="";
  
      if($lessons_wherestr!='')
      {
        $clean_lessons_where_str="Where ".$lessons_wherestr;
      }

         $return_data_set= mosyget_("lessons", "count(*) as return_result", " ".$clean_lessons_where_str."", "l", "", $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_lessons_;

      }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");


     }    
    }    
    //======== count lessons data function
    
    

    //======== sum  lessons data function
    
    function sum_lessons($lessons_sumcol, $lessons_wherestr)
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "sum_data","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
      $clean_lessons_where_str="";
  
      if($lessons_wherestr!='')
      {
        $clean_lessons_where_str="Where ".$lessons_wherestr;
      }

      return get_lessons("sum($lessons_sumcol) as return_result", " ".$clean_lessons_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_lessons_;


      }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");
        


     }    
    }
    
    function mgsum_lessons($lessons_sumcol, $lessons_wherestr, $endpoint="")
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "sum_data","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
      $clean_lessons_where_str="";
  
      if($lessons_wherestr!='')
      {
        $clean_lessons_where_str="Where ".$lessons_wherestr;
      }
      
        $return_data_set = mosyget_("lessons", "sum($lessons_sumcol) as return_result", " ".$clean_lessons_where_str."", "l", "", $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;

      //echo $gwauthenticate_lessons_;


      }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");
        


     }    
    }    
    
    //======== sum  lessons data function   
    
    
    //Start drop  lessons Data ===============
    
    function drop_lessons($where_str)
    {
     
     $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "drop_data","");
     
     $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
     
     if($gwauthenticate_lessons_json["response"]=="ok")
     {    
    	return magic_sql_delete("lessons", $where_str);

		//echo $gwauthenticate_lessons_;

      }else{
     
     	echo $gwauthenticate_lessons_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");
		

     }
    }
    //End drop  lessons Data ===============    
    
    
            //Start Upload lessons_user_pic Function 
            function upload_lessons_user_pic($txt_lessons_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_lessons_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/lessons_user_pic')) @mkdir('./img/lessons_user_pic');

                $cur_item_photos=magic_upload_file('./img/lessons_user_pic/', $txt_lessons_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $lessons_node=get_lessons("*", "WHERE ".$where_str."", "r");

                  if (file_exists($lessons_node["user_pic"]))
                  {

                      unlink($lessons_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('lessons', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload lessons_user_pic Function 

            
   

    
 	//Start Add mosy_sql_roll_back Data ===============
 	function add_mosy_sql_roll_back($mosy_sql_roll_back_arr_)
    {
     $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("mosy_sql_roll_back", $mosy_sql_roll_back_arr_);
     
     	//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

     }
     
    }
    
       function initialize_mosy_sql_roll_back()
        {
        
         global $mosy_sql_roll_back_uptoken;
             
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
         	return get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
         
            echo $gwauthenticate_mosy_sql_roll_back_;

         }else{

         	echo $gwauthenticate_mosy_sql_roll_back_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
        } 
        
       function mginitialize_mosy_sql_roll_back($endpoint="")
        {
        
         global $mosy_sql_roll_back_uptoken;
             
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("mosy_sql_roll_back", "*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "l", "", $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_mosy_sql_roll_back_;

         }else{

         	echo $gwauthenticate_mosy_sql_roll_back_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
        }         
    //End Add mosy_sql_roll_back Data ===============
                
    //Start Update mosy_sql_roll_back Data ===============
    
 	function update_mosy_sql_roll_back($mosy_sql_roll_back_arr_, $where_str)
    {
         $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("mosy_sql_roll_back", $mosy_sql_roll_back_arr_, $where_str);

       // echo $gwauthenticate_mosy_sql_roll_back_;
        
        exit;

     }else{

        echo $gwauthenticate_mosy_sql_roll_back_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


      }
    
    }
 	
    
    //End Update mosy_sql_roll_back Data ===============


    //Start get  mosy_sql_roll_back Data ===============
    
    function get_mosy_sql_roll_back($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
    	return mosyflex_sel("mosy_sql_roll_back", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosy_sql_roll_back_;

	  }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //End get  mosy_sql_roll_back Data ===============
    
  //Start get  mosy_sql_roll_back Data ===============
    
    function mgget_mosy_sql_roll_back($colstr="*", $where_str="", $type="l", $endpoint="")
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
        return mosyget_("mosy_sql_roll_back", $colstr, $where_str, $type, "", $endpoint);
        
        
    	//return mosyflex_sel("mosy_sql_roll_back", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosy_sql_roll_back_;

	  }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //End get  mosy_sql_roll_back Data ===============
            

    //======== qmosy_sql_roll_back_data qsingle query function
    
    function qmosy_sql_roll_back_data($qroll_bk_key_key)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qdata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE roll_bk_key='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
    
    function mgqmosy_sql_roll_back_data($qroll_bk_key_key, $endpoint="")
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qdata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("mosy_sql_roll_back", "*", "WHERE roll_bk_key='$qroll_bk_key_key'", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function
    
    
     //======== mosy_sql_roll_back data to array
    
    function mosy_sql_roll_back_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "data_array","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {  
     	$append_mosy_sql_roll_back_arr=array();
    
    	$array_mosy_sql_roll_back_q=get_mosy_sql_roll_back($colstr, $where_str, "l");
        while($array_mosy_sql_roll_back_res=mysqli_fetch_array($array_mosy_sql_roll_back_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res[$tbl_col];
            }
          }else{
          	          
               $append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res;

          }
        }
        
        return $append_mosy_sql_roll_back_arr;

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function   
        
    //======== qmosy_sql_roll_back_ddata qsingle query function    
    function qmosy_sql_roll_back_ddata($roll_bk_key_col, $qroll_bk_key_key)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE $roll_bk_key_col='$qroll_bk_key_key'", "r");



		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }
    
    function mgqmosy_sql_roll_back_ddata($roll_bk_key_col, $qroll_bk_key_key, $endpoint="")
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("mosy_sql_roll_back", "*", "WHERE $roll_bk_key_col='$qroll_bk_key_key'", "l", "", $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }    
    //======== qmosy_sql_roll_back_ddata qsingle query function
    
        //======== qmosy_sql_roll_back_gdata qsingle query function    
    function qmosy_sql_roll_back_gdata($mosy_sql_roll_back_where="")
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "gddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
     	$where_str="";
        if($mosy_sql_roll_back_where!=="")
        {
        $where_str=" ".$mosy_sql_roll_back_where;
        }
    	return get_mosy_sql_roll_back("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }
    
    function mgqmosy_sql_roll_back_gdata($mosy_sql_roll_back_where="", $endpoint="")
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "gddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
     	$where_str="";
        if($mosy_sql_roll_back_where!=="")
        {
        $where_str=" ".$mosy_sql_roll_back_where;
        }
        
        $return_data_set = mosyget_("mosy_sql_roll_back", "*", " ".$where_str." ", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }
    //======== qmosy_sql_roll_back_gdata qsingle query function
    

    //======== count mosy_sql_roll_back data function
    
    function count_mosy_sql_roll_back($mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "count_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("count(*) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    
    function mgcount_mosy_sql_roll_back($mosy_sql_roll_back_wherestr, $endpoint="")
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "count_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

         $return_data_set= mosyget_("mosy_sql_roll_back", "count(*) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "l", "", $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }    
    //======== count mosy_sql_roll_back data function
    
    

    //======== sum  mosy_sql_roll_back data function
    
    function sum_mosy_sql_roll_back($mosy_sql_roll_back_sumcol, $mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "sum_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("sum($mosy_sql_roll_back_sumcol) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;


      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
        


     }    
    }
    
    function mgsum_mosy_sql_roll_back($mosy_sql_roll_back_sumcol, $mosy_sql_roll_back_wherestr, $endpoint="")
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "sum_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }
      
        $return_data_set = mosyget_("mosy_sql_roll_back", "sum($mosy_sql_roll_back_sumcol) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "l", "", $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;

      //echo $gwauthenticate_mosy_sql_roll_back_;


      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
        


     }    
    }    
    
    //======== sum  mosy_sql_roll_back data function   
    
    
    //Start drop  mosy_sql_roll_back Data ===============
    
    function drop_mosy_sql_roll_back($where_str)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "drop_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return magic_sql_delete("mosy_sql_roll_back", $where_str);

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
		

     }
    }
    //End drop  mosy_sql_roll_back Data ===============    
    
    
   

    
 	//Start Add schools Data ===============
 	function add_schools($schools_arr_)
    {
     $gw_schools_cols=array();
     
     foreach($schools_arr_ as $schools_arr_gw => $schools_arr_gw_val)
     {
     
     	$gw_schools_cols[]=$schools_arr_gw;
        
     }
     
     $gw_schools_cols_str=implode(",", $gw_schools_cols);
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "insert",$gw_schools_cols_str);
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("schools", $schools_arr_);
     
     	//echo $gwauthenticate_schools_;

     }else{
     
     	echo $gwauthenticate_schools_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");

     }
     
    }
    
       function initialize_schools()
        {
        
         global $schools_uptoken;
             
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "select","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
         
         	return get_schools("*", "WHERE primkey='$schools_uptoken'", "r");
         
            echo $gwauthenticate_schools_;

         }else{

         	echo $gwauthenticate_schools_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");
         
         }
        } 
        
       function mginitialize_schools($endpoint="")
        {
        
         global $schools_uptoken;
             
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "select","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("schools", "*", "WHERE primkey='$schools_uptoken'", "l", "", $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_schools_;

         }else{

         	echo $gwauthenticate_schools_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");
         
         }
        }         
    //End Add schools Data ===============
                
    //Start Update schools Data ===============
    
 	function update_schools($schools_arr_, $where_str)
    {
         $gw_schools_cols=array();
     
     foreach($schools_arr_ as $schools_arr_gw => $schools_arr_gw_val)
     {
     
     	$gw_schools_cols[]=$schools_arr_gw;
        
     }
     
     $gw_schools_cols_str=implode(",", $gw_schools_cols);
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "update",$gw_schools_cols_str);
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("schools", $schools_arr_, $where_str);

       // echo $gwauthenticate_schools_;
        
        exit;

     }else{

        echo $gwauthenticate_schools_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


      }
    
    }
 	
    
    //End Update schools Data ===============


    //Start get  schools Data ===============
    
    function get_schools($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "select","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {
    	return mosyflex_sel("schools", $colstr, $where_str, $type);

        //echo $gwauthenticate_schools_;

	  }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }    
    }
    //End get  schools Data ===============
    
  //Start get  schools Data ===============
    
    function mgget_schools($colstr="*", $where_str="", $type="l", $endpoint="")
    {
          
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "select","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {
     
        return mosyget_("schools", $colstr, $where_str, $type, "", $endpoint);
        
        
    	//return mosyflex_sel("schools", $colstr, $where_str, $type);

        //echo $gwauthenticate_schools_;

	  }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }    
    }
    //End get  schools Data ===============
            

    //======== qschools_data qsingle query function
    
    function qschools_data($qschool_id_key)
    {
          
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "qdata","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
    	return get_schools("*", "WHERE school_id='$qschool_id_key'", "r");

		//echo $gwauthenticate_schools_;

      }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }  
    }
    
    function mgqschools_data($qschool_id_key, $endpoint="")
    {
          
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "qdata","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("schools", "*", "WHERE school_id='$qschool_id_key'", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_schools_;

      }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }  
    }
   
    //======== qschools_data qsingle query function
    
    
     //======== schools data to array
    
    function schools_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "data_array","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {  
     	$append_schools_arr=array();
    
    	$array_schools_q=get_schools($colstr, $where_str, "l");
        while($array_schools_res=mysqli_fetch_array($array_schools_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_schools_arr[]=$array_schools_res[$tbl_col];
            }
          }else{
          	          
               $append_schools_arr[]=$array_schools_res;

          }
        }
        
        return $append_schools_arr;

		//echo $gwauthenticate_schools_;

      }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }  
    }
   
    //======== qschools_data qsingle query function   
        
    //======== qschools_ddata qsingle query function    
    function qschools_ddata($school_id_col, $qschool_id_key)
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "qddata","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
    	return get_schools("*", "WHERE $school_id_col='$qschool_id_key'", "r");



		//echo $gwauthenticate_schools_;

     }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }   
    }
    
    function mgqschools_ddata($school_id_col, $qschool_id_key, $endpoint="")
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "qddata","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("schools", "*", "WHERE $school_id_col='$qschool_id_key'", "l", "", $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_schools_;

     }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }   
    }    
    //======== qschools_ddata qsingle query function
    
        //======== qschools_gdata qsingle query function    
    function qschools_gdata($schools_where="")
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "gddata","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
     	$where_str="";
        if($schools_where!=="")
        {
        $where_str=" ".$schools_where;
        }
    	return get_schools("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_schools_;

     }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }   
    }
    
    function mgqschools_gdata($schools_where="", $endpoint="")
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "gddata","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
     	$where_str="";
        if($schools_where!=="")
        {
        $where_str=" ".$schools_where;
        }
        
        $return_data_set = mosyget_("schools", "*", " ".$where_str." ", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_schools_;

     }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }   
    }
    //======== qschools_gdata qsingle query function
    

    //======== count schools data function
    
    function count_schools($schools_wherestr)
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "count_data","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
      $clean_schools_where_str="";
  
      if($schools_wherestr!='')
      {
        $clean_schools_where_str="Where ".$schools_wherestr;
      }

      return get_schools("count(*) as return_result", " ".$clean_schools_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_schools_;

      }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }    
    }
    
    function mgcount_schools($schools_wherestr, $endpoint="")
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "count_data","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
      $clean_schools_where_str="";
  
      if($schools_wherestr!='')
      {
        $clean_schools_where_str="Where ".$schools_wherestr;
      }

         $return_data_set= mosyget_("schools", "count(*) as return_result", " ".$clean_schools_where_str."", "l", "", $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_schools_;

      }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");


     }    
    }    
    //======== count schools data function
    
    

    //======== sum  schools data function
    
    function sum_schools($schools_sumcol, $schools_wherestr)
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "sum_data","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
      $clean_schools_where_str="";
  
      if($schools_wherestr!='')
      {
        $clean_schools_where_str="Where ".$schools_wherestr;
      }

      return get_schools("sum($schools_sumcol) as return_result", " ".$clean_schools_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_schools_;


      }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");
        


     }    
    }
    
    function mgsum_schools($schools_sumcol, $schools_wherestr, $endpoint="")
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "sum_data","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
      $clean_schools_where_str="";
  
      if($schools_wherestr!='')
      {
        $clean_schools_where_str="Where ".$schools_wherestr;
      }
      
        $return_data_set = mosyget_("schools", "sum($schools_sumcol) as return_result", " ".$clean_schools_where_str."", "l", "", $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;

      //echo $gwauthenticate_schools_;


      }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");
        


     }    
    }    
    
    //======== sum  schools data function   
    
    
    //Start drop  schools Data ===============
    
    function drop_schools($where_str)
    {
     
     $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "drop_data","");
     
     $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
     
     if($gwauthenticate_schools_json["response"]=="ok")
     {    
    	return magic_sql_delete("schools", $where_str);

		//echo $gwauthenticate_schools_;

      }else{
     
     	echo $gwauthenticate_schools_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");
		

     }
    }
    //End drop  schools Data ===============    
    
    
            //Start Upload schools_user_pic Function 
            function upload_schools_user_pic($txt_schools_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_schools_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/schools_user_pic')) @mkdir('./img/schools_user_pic');

                $cur_item_photos=magic_upload_file('./img/schools_user_pic/', $txt_schools_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $schools_node=get_schools("*", "WHERE ".$where_str."", "r");

                  if (file_exists($schools_node["user_pic"]))
                  {

                      unlink($schools_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('schools', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload schools_user_pic Function 

            
   

    
 	//Start Add students Data ===============
 	function add_students($students_arr_)
    {
     $gw_students_cols=array();
     
     foreach($students_arr_ as $students_arr_gw => $students_arr_gw_val)
     {
     
     	$gw_students_cols[]=$students_arr_gw;
        
     }
     
     $gw_students_cols_str=implode(",", $gw_students_cols);
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "insert",$gw_students_cols_str);
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("students", $students_arr_);
     
     	//echo $gwauthenticate_students_;

     }else{
     
     	echo $gwauthenticate_students_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");

     }
     
    }
    
       function initialize_students()
        {
        
         global $students_uptoken;
             
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "select","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
         
         	return get_students("*", "WHERE primkey='$students_uptoken'", "r");
         
            echo $gwauthenticate_students_;

         }else{

         	echo $gwauthenticate_students_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");
         
         }
        } 
        
       function mginitialize_students($endpoint="")
        {
        
         global $students_uptoken;
             
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "select","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("students", "*", "WHERE primkey='$students_uptoken'", "l", "", $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_students_;

         }else{

         	echo $gwauthenticate_students_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");
         
         }
        }         
    //End Add students Data ===============
                
    //Start Update students Data ===============
    
 	function update_students($students_arr_, $where_str)
    {
         $gw_students_cols=array();
     
     foreach($students_arr_ as $students_arr_gw => $students_arr_gw_val)
     {
     
     	$gw_students_cols[]=$students_arr_gw;
        
     }
     
     $gw_students_cols_str=implode(",", $gw_students_cols);
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "update",$gw_students_cols_str);
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("students", $students_arr_, $where_str);

       // echo $gwauthenticate_students_;
        
        exit;

     }else{

        echo $gwauthenticate_students_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


      }
    
    }
 	
    
    //End Update students Data ===============


    //Start get  students Data ===============
    
    function get_students($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "select","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {
    	return mosyflex_sel("students", $colstr, $where_str, $type);

        //echo $gwauthenticate_students_;

	  }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }    
    }
    //End get  students Data ===============
    
  //Start get  students Data ===============
    
    function mgget_students($colstr="*", $where_str="", $type="l", $endpoint="")
    {
          
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "select","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {
     
        return mosyget_("students", $colstr, $where_str, $type, "", $endpoint);
        
        
    	//return mosyflex_sel("students", $colstr, $where_str, $type);

        //echo $gwauthenticate_students_;

	  }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }    
    }
    //End get  students Data ===============
            

    //======== qstudents_data qsingle query function
    
    function qstudents_data($quser_id_key)
    {
          
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "qdata","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
    	return get_students("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_students_;

      }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }  
    }
    
    function mgqstudents_data($quser_id_key, $endpoint="")
    {
          
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "qdata","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("students", "*", "WHERE user_id='$quser_id_key'", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_students_;

      }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }  
    }
   
    //======== qstudents_data qsingle query function
    
    
     //======== students data to array
    
    function students_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "data_array","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {  
     	$append_students_arr=array();
    
    	$array_students_q=get_students($colstr, $where_str, "l");
        while($array_students_res=mysqli_fetch_array($array_students_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_students_arr[]=$array_students_res[$tbl_col];
            }
          }else{
          	          
               $append_students_arr[]=$array_students_res;

          }
        }
        
        return $append_students_arr;

		//echo $gwauthenticate_students_;

      }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }  
    }
   
    //======== qstudents_data qsingle query function   
        
    //======== qstudents_ddata qsingle query function    
    function qstudents_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "qddata","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
    	return get_students("*", "WHERE $user_id_col='$quser_id_key'", "r");



		//echo $gwauthenticate_students_;

     }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }   
    }
    
    function mgqstudents_ddata($user_id_col, $quser_id_key, $endpoint="")
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "qddata","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("students", "*", "WHERE $user_id_col='$quser_id_key'", "l", "", $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_students_;

     }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }   
    }    
    //======== qstudents_ddata qsingle query function
    
        //======== qstudents_gdata qsingle query function    
    function qstudents_gdata($students_where="")
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "gddata","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
     	$where_str="";
        if($students_where!=="")
        {
        $where_str=" ".$students_where;
        }
    	return get_students("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_students_;

     }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }   
    }
    
    function mgqstudents_gdata($students_where="", $endpoint="")
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "gddata","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
     	$where_str="";
        if($students_where!=="")
        {
        $where_str=" ".$students_where;
        }
        
        $return_data_set = mosyget_("students", "*", " ".$where_str." ", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_students_;

     }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }   
    }
    //======== qstudents_gdata qsingle query function
    

    //======== count students data function
    
    function count_students($students_wherestr)
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "count_data","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
      $clean_students_where_str="";
  
      if($students_wherestr!='')
      {
        $clean_students_where_str="Where ".$students_wherestr;
      }

      return get_students("count(*) as return_result", " ".$clean_students_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_students_;

      }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }    
    }
    
    function mgcount_students($students_wherestr, $endpoint="")
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "count_data","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
      $clean_students_where_str="";
  
      if($students_wherestr!='')
      {
        $clean_students_where_str="Where ".$students_wherestr;
      }

         $return_data_set= mosyget_("students", "count(*) as return_result", " ".$clean_students_where_str."", "l", "", $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_students_;

      }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");


     }    
    }    
    //======== count students data function
    
    

    //======== sum  students data function
    
    function sum_students($students_sumcol, $students_wherestr)
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "sum_data","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
      $clean_students_where_str="";
  
      if($students_wherestr!='')
      {
        $clean_students_where_str="Where ".$students_wherestr;
      }

      return get_students("sum($students_sumcol) as return_result", " ".$clean_students_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_students_;


      }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");
        


     }    
    }
    
    function mgsum_students($students_sumcol, $students_wherestr, $endpoint="")
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "sum_data","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
      $clean_students_where_str="";
  
      if($students_wherestr!='')
      {
        $clean_students_where_str="Where ".$students_wherestr;
      }
      
        $return_data_set = mosyget_("students", "sum($students_sumcol) as return_result", " ".$clean_students_where_str."", "l", "", $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;

      //echo $gwauthenticate_students_;


      }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");
        


     }    
    }    
    
    //======== sum  students data function   
    
    
    //Start drop  students Data ===============
    
    function drop_students($where_str)
    {
     
     $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "drop_data","");
     
     $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
     
     if($gwauthenticate_students_json["response"]=="ok")
     {    
    	return magic_sql_delete("students", $where_str);

		//echo $gwauthenticate_students_;

      }else{
     
     	echo $gwauthenticate_students_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");
		

     }
    }
    //End drop  students Data ===============    
    
    
            //Start Upload students_user_pic Function 
            function upload_students_user_pic($txt_students_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_students_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/students_user_pic')) @mkdir('./img/students_user_pic');

                $cur_item_photos=magic_upload_file('./img/students_user_pic/', $txt_students_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $students_node=get_students("*", "WHERE ".$where_str."", "r");

                  if (file_exists($students_node["user_pic"]))
                  {

                      unlink($students_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('students', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload students_user_pic Function 

            
   

    
 	//Start Add transactions_table Data ===============
 	function add_transactions_table($transactions_table_arr_)
    {
     $gw_transactions_table_cols=array();
     
     foreach($transactions_table_arr_ as $transactions_table_arr_gw => $transactions_table_arr_gw_val)
     {
     
     	$gw_transactions_table_cols[]=$transactions_table_arr_gw;
        
     }
     
     $gw_transactions_table_cols_str=implode(",", $gw_transactions_table_cols);
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "insert",$gw_transactions_table_cols_str);
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("transactions_table", $transactions_table_arr_);
     
     	//echo $gwauthenticate_transactions_table_;

     }else{
     
     	echo $gwauthenticate_transactions_table_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");

     }
     
    }
    
       function initialize_transactions_table()
        {
        
         global $transactions_table_uptoken;
             
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "select","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
         
         	return get_transactions_table("*", "WHERE primkey='$transactions_table_uptoken'", "r");
         
            echo $gwauthenticate_transactions_table_;

         }else{

         	echo $gwauthenticate_transactions_table_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");
         
         }
        } 
        
       function mginitialize_transactions_table($endpoint="")
        {
        
         global $transactions_table_uptoken;
             
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "select","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
                  
            $return_data_set=mosyget_("transactions_table", "*", "WHERE primkey='$transactions_table_uptoken'", "l", "", $endpoint);
        
            $result_node="";

            if(isset($return_data_set["data"][0]))
            {

              $result_node=$return_data_set["data"][0];

            }

            return $result_node;
        
         
            ///echo $gwauthenticate_transactions_table_;

         }else{

         	echo $gwauthenticate_transactions_table_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");
         
         }
        }         
    //End Add transactions_table Data ===============
                
    //Start Update transactions_table Data ===============
    
 	function update_transactions_table($transactions_table_arr_, $where_str)
    {
         $gw_transactions_table_cols=array();
     
     foreach($transactions_table_arr_ as $transactions_table_arr_gw => $transactions_table_arr_gw_val)
     {
     
     	$gw_transactions_table_cols[]=$transactions_table_arr_gw;
        
     }
     
     $gw_transactions_table_cols_str=implode(",", $gw_transactions_table_cols);
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "update",$gw_transactions_table_cols_str);
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("transactions_table", $transactions_table_arr_, $where_str);

       // echo $gwauthenticate_transactions_table_;
        
        exit;

     }else{

        echo $gwauthenticate_transactions_table_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


      }
    
    }
 	
    
    //End Update transactions_table Data ===============


    //Start get  transactions_table Data ===============
    
    function get_transactions_table($colstr="*", $where_str="", $type="l")
    {
          
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "select","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {
    	return mosyflex_sel("transactions_table", $colstr, $where_str, $type);

        //echo $gwauthenticate_transactions_table_;

	  }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }    
    }
    //End get  transactions_table Data ===============
    
  //Start get  transactions_table Data ===============
    
    function mgget_transactions_table($colstr="*", $where_str="", $type="l", $endpoint="")
    {
          
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "select","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {
     
        return mosyget_("transactions_table", $colstr, $where_str, $type, "", $endpoint);
        
        
    	//return mosyflex_sel("transactions_table", $colstr, $where_str, $type);

        //echo $gwauthenticate_transactions_table_;

	  }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }    
    }
    //End get  transactions_table Data ===============
            

    //======== qtransactions_table_data qsingle query function
    
    function qtransactions_table_data($qTransactionType_key)
    {
          
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "qdata","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
    	return get_transactions_table("*", "WHERE TransactionType='$qTransactionType_key'", "r");

		//echo $gwauthenticate_transactions_table_;

      }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }  
    }
    
    function mgqtransactions_table_data($qTransactionType_key, $endpoint="")
    {
          
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "qdata","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {   
        
        $return_data_set=mosyget_("transactions_table", "*", "WHERE TransactionType='$qTransactionType_key'", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_transactions_table_;

      }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }  
    }
   
    //======== qtransactions_table_data qsingle query function
    
    
     //======== transactions_table data to array
    
    function transactions_table_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "data_array","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {  
     	$append_transactions_table_arr=array();
    
    	$array_transactions_table_q=get_transactions_table($colstr, $where_str, "l");
        while($array_transactions_table_res=mysqli_fetch_array($array_transactions_table_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_transactions_table_arr[]=$array_transactions_table_res[$tbl_col];
            }
          }else{
          	          
               $append_transactions_table_arr[]=$array_transactions_table_res;

          }
        }
        
        return $append_transactions_table_arr;

		//echo $gwauthenticate_transactions_table_;

      }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }  
    }
   
    //======== qtransactions_table_data qsingle query function   
        
    //======== qtransactions_table_ddata qsingle query function    
    function qtransactions_table_ddata($TransactionType_col, $qTransactionType_key)
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "qddata","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
    	return get_transactions_table("*", "WHERE $TransactionType_col='$qTransactionType_key'", "r");



		//echo $gwauthenticate_transactions_table_;

     }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }   
    }
    
    function mgqtransactions_table_ddata($TransactionType_col, $qTransactionType_key, $endpoint="")
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "qddata","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
 
       $return_data_set= mosyget_("transactions_table", "*", "WHERE $TransactionType_col='$qTransactionType_key'", "l", "", $endpoint);
       
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_transactions_table_;

     }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }   
    }    
    //======== qtransactions_table_ddata qsingle query function
    
        //======== qtransactions_table_gdata qsingle query function    
    function qtransactions_table_gdata($transactions_table_where="")
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "gddata","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
     	$where_str="";
        if($transactions_table_where!=="")
        {
        $where_str=" ".$transactions_table_where;
        }
    	return get_transactions_table("*", " ".$where_str." ", "r");

		//echo $gwauthenticate_transactions_table_;

     }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }   
    }
    
    function mgqtransactions_table_gdata($transactions_table_where="", $endpoint="")
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "gddata","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
     	$where_str="";
        if($transactions_table_where!=="")
        {
        $where_str=" ".$transactions_table_where;
        }
        
        $return_data_set = mosyget_("transactions_table", "*", " ".$where_str." ", "l", "", $endpoint);
        
        $result_node="";
        
        if(isset($return_data_set["data"][0]))
        {
        
          $result_node=$return_data_set["data"][0];
         
        }

		return $result_node;
        
		//echo $gwauthenticate_transactions_table_;

     }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }   
    }
    //======== qtransactions_table_gdata qsingle query function
    

    //======== count transactions_table data function
    
    function count_transactions_table($transactions_table_wherestr)
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "count_data","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
      $clean_transactions_table_where_str="";
  
      if($transactions_table_wherestr!='')
      {
        $clean_transactions_table_where_str="Where ".$transactions_table_wherestr;
      }

      return get_transactions_table("count(*) as return_result", " ".$clean_transactions_table_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_transactions_table_;

      }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }    
    }
    
    function mgcount_transactions_table($transactions_table_wherestr, $endpoint="")
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "count_data","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
      $clean_transactions_table_where_str="";
  
      if($transactions_table_wherestr!='')
      {
        $clean_transactions_table_where_str="Where ".$transactions_table_wherestr;
      }

         $return_data_set= mosyget_("transactions_table", "count(*) as return_result", " ".$clean_transactions_table_where_str."", "l", "", $endpoint);

        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;
        
        
      //echo $gwauthenticate_transactions_table_;

      }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");


     }    
    }    
    //======== count transactions_table data function
    
    

    //======== sum  transactions_table data function
    
    function sum_transactions_table($transactions_table_sumcol, $transactions_table_wherestr)
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "sum_data","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
      $clean_transactions_table_where_str="";
  
      if($transactions_table_wherestr!='')
      {
        $clean_transactions_table_where_str="Where ".$transactions_table_wherestr;
      }

      return get_transactions_table("sum($transactions_table_sumcol) as return_result", " ".$clean_transactions_table_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_transactions_table_;


      }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");
        


     }    
    }
    
    function mgsum_transactions_table($transactions_table_sumcol, $transactions_table_wherestr, $endpoint="")
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "sum_data","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
      $clean_transactions_table_where_str="";
  
      if($transactions_table_wherestr!='')
      {
        $clean_transactions_table_where_str="Where ".$transactions_table_wherestr;
      }
      
        $return_data_set = mosyget_("transactions_table", "sum($transactions_table_sumcol) as return_result", " ".$clean_transactions_table_where_str."", "l", "", $endpoint);
        
        $result_node="0";
        
        if(isset($return_data_set["data"][0]["return_result"]))
        {
        
          $result_node=$return_data_set["data"][0]["return_result"];
         
        }

		return $result_node;

      //echo $gwauthenticate_transactions_table_;


      }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");
        


     }    
    }    
    
    //======== sum  transactions_table data function   
    
    
    //Start drop  transactions_table Data ===============
    
    function drop_transactions_table($where_str)
    {
     
     $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "drop_data","");
     
     $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
     
     if($gwauthenticate_transactions_table_json["response"]=="ok")
     {    
    	return magic_sql_delete("transactions_table", $where_str);

		//echo $gwauthenticate_transactions_table_;

      }else{
     
     	echo $gwauthenticate_transactions_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");
		

     }
    }
    //End drop  transactions_table Data ===============    
    
    
  //===============End Mosy queries-============

//============= Start Sql chart  Script =====================

function mosy_sql_rollback($tbl, $where, $type)
{
  $sql_fun="get_".$tbl;

  $curr_sql_ret_=$sql_fun("*", " where ".$where." ", "r");
  
  $json_sql_str=json_encode($curr_sql_ret_, true);
  
  //------- begin mosy_sql_roll_back_post_arr --> 
  $mosy_sql_roll_back_post_arr_=array(

  "primkey"=>"NULL",
  "roll_bk_key"=>mmres(magic_random_str(20)),
  "table_name"=>mmres($tbl),
  "where_str"=>mmres($where),
  "roll_type"=>mmres($type),
  "roll_timestamp"=>date("Y-m-d H:i:s"),
  "value_entries"=>mmres($json_sql_str)

  );
  //===-- End mosy_sql_roll_back_post_arr -->

  add_mosy_sql_roll_back($mosy_sql_roll_back_post_arr_);
  
  return $json_sql_str;
  
}


function get_mosychart_data($tbl, $colstr, $where_str, $xcol, $ycol, $groupby)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str="";
   $groupby_cols="";
   
   if($where_str!='')
   {
     $fun_where_str=" WHERE ".$where_str;
   }
   
   if($groupby!='')
   {
     $groupby_cols=" GROUP BY ".$groupby;
   }
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ".$groupby_cols." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================

//============= End Sql chart  Script =====================

function get_mosyflex_chart($tbl, $colstr, $where_str, $xcol, $ycol)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str=$where_str;
  
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================


//============= Start   mosy flex select script =====================

function mosyflex_sel($tbl, $colstr, $where_str, $loop_or_row_l_r,$show_str="")
{
   global $single_conn;
   global $single_db;
   global $flex_result;
   global $datalimit;
  
  $paginate_q="";
  $paginate_state="";
  
  $pagination_token=$tbl."_mpgtkn";
  
  $loop_or_row_l_rtype=$loop_or_row_l_r;
  
  if (strpos($loop_or_row_l_r, ':') !== false)
  {
    $loop_or_row_l_r_str=explode(":", $loop_or_row_l_r);

    $pagination_token=$loop_or_row_l_r_str[1];

    $loop_or_row_l_rtype=$loop_or_row_l_r_str[0];

    $paginate_state="paginate";
    
    if(isset($loop_or_row_l_r_str[2]))
    {
    $datalimit=$loop_or_row_l_r_str[2];
    }
    
    $pagination_sql="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

    $process_pagination=mysqli_query($single_conn, $pagination_sql) or die(mysqli_error($single_conn));

    $requested_page=1;
    if(isset($_GET[$pagination_token]))
    {
      $requested_page=base64_decode($_GET[$pagination_token]);
      if($requested_page=="")
      {
        $requested_page=1;
      }
      ////echo " yyyyyyyyy token ".$requested_page." isset yyyyyyy";
    }
    
    if(isset($loop_or_row_l_r_str[3]))
    {    
      $requested_page=$loop_or_row_l_r_str[3];
    }    
    
    
    $paginate_q=mosy_paginate($process_pagination, $datalimit, $pagination_token, $requested_page);

    $first_page_record_=$paginate_q[0];       
    
    $new_where_str=$where_str." LIMIT ".$first_page_record_.", $datalimit ";
    
    $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_str."";
    

  }else{
    
      $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

  }
  if($show_str=="yes")
  {
   echo $sql_str;
  } 
  $flex_result_q=mysqli_query($single_conn, $sql_str) or die(mysqli_error($single_conn));
  
  $flex_result=$flex_result_q;

  if($loop_or_row_l_rtype=='r')
  {
    $flex_result_r=mysqli_fetch_array($flex_result_q);
    
    $flex_result=$flex_result_r;
    
  }
  
  if($loop_or_row_l_rtype=="j")
  {
    $json_data_resp=array();
    
    while($flex_result_json=mysqli_fetch_array($flex_result_q)){      
    
     $json_data_resp[]=$flex_result_json;
      
    }
    
    $json_data_rows=$json_data_resp;
    
  } 
  
 /// echo $loop_or_row_l_rtype;
  
  if($paginate_state=='paginate' && $loop_or_row_l_rtype=="j")
  {
  	$flex_result=json_encode(array("data"=>$json_data_rows, "first_row"=>$paginate_q[1], "page_count"=>$paginate_q[0], "query_string"=>$sql_str, "pagination_sql"=>$pagination_sql));  
  }
  
  if($paginate_state=='' && $loop_or_row_l_rtype=="j")
  {
  	$flex_result=json_encode(array("data"=>$json_data_rows, "first_row"=>"", "page_count"=>"", "query_string"=>$sql_str, "pagination_sql"=>""));  
  }
  
  if($paginate_state=='paginate' && $loop_or_row_l_rtype=="l")
  {
  	$flex_result=array($flex_result_q, $paginate_q[1], $paginate_q[0], $sql_str, $pagination_sql);  
  }
  
  
  return $flex_result;
  
}


function mosy_paginate($sqlstring, $reclimit, $token_name,$requested_page)
{


  $rows_count = mysqli_num_rows($sqlstring);

  $items_per_page = $reclimit;

  $page_count = ceil($rows_count / $items_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_row = ($requested_page - 1) * $items_per_page;

  $recordperpage_data=array($first_row,$page_count);

  return $recordperpage_data;
  
}
//============= End  mosy flex select script =====================

  function tonum($number_str, $decplaces=0)
  {
	if($number_str=='')
    {
      $number_str=0;
    }
  	return number_format($number_str, $decplaces, ".", ",");
  	

  }
  
//checkblank fuction

function checkblank($value, $return_val)
{
  
  global $fun_resonse;

  if($value!='')
  {
  $fun_resonse=$value;
  }else{
    $fun_resonse=$return_val;

  }
  return $fun_resonse;

}

//get date foramrt

function ftime($time_st, $type)
{
  	global $timeresp;
    
  $timeresp=date("l, jS, M, y, @ H:i:s");

  if($time_st=="") 
  {
    $timeresp=date("l, jS, M, y, @ H:i:s");

  	if($type=="date")
    {
    $timeresp=date("l, jS, M, y");
    }
    
  }
  
  if($time_st!=""){
  
     $timeresp=date("l, jS, M, y, @ H:i:s", strtotime($time_st));

    if($type=="date")
    {
    	$timeresp=date("l, jS, M, y", strtotime($time_st));
    }
    
  }
	return $timeresp;
}

function date_time_input($time_st, $full_date_time="")
{
  	global $timeresp;
    
    $date_form="Y-m-d\TH:i:s";
    
    if($full_date_time=="date")
    {
    $date_form="Y-m-d";
    }
    
    if($full_date_time=="time")
    {
    $date_form="H:i:s";
    }
    
  if($time_st==""){
  	$timeresp=date($date_form);
  }else{
   
   $timeresp=date($date_form, strtotime($time_st));

  }
	return $timeresp;
}
function daytime()
{
  global $daytime;

  $daytime='Hello';

  $fromdate=date('A');
  $eve_aft=date("H");

  if($fromdate=='AM'){
 	 $daytime='Morning';
  }
  
  if($fromdate=='PM' && $eve_aft<17){
  	$daytime='Afternoon';
  }
  
  if($fromdate=='PM' && $eve_aft>=17){
  	$daytime='Evening';
  }

  return $daytime;
}

function mosy_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest)
{
	global $curl_post_response;

	$new_curl_method='POST';
	if($curlopt_customrequest!='')
	{
		$new_curl_method=$curlopt_customrequest;
	}

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $curlopt_url);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $new_curl_method); 
		curl_setopt($ch, CURLOPT_HTTPHEADER, ($curlopt_httpheader));
		curl_setopt($ch, CURLOPT_USERPWD, $curlopt_userpwd);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $curlopt_post_fields);

		$curl_post_response = curl_exec($ch);

	return $curl_post_response;
}

function mosy_month_year_diff($start_date, $end_date, $myd="m")
{

  $ts1 = strtotime($start_date);
  $ts2 = strtotime($end_date);

  $year1 = date("Y", $ts1);
  $year2 = date("Y", $ts2);

  $month1 = date("m", $ts1);
  $month2 = date("m", $ts2);

  $date1=date_create($start_date);
  $date2=date_create($end_date);

  $day_diff=date_diff($date1,$date2);

  $day_diff_count=$day_diff->format("%R%a");
    
  $year_diff_=$year2 - $year1;
  $month_diff_=$month2 - $month1;

  $diff = (($year_diff_) * 12) + ($month_diff_);

  $ret_diff=$year_diff_;

  if($myd=="m")
  {
    $ret_diff=$diff;
  }
  
  if($myd=="d")
  {
    $ret_diff=$day_diff_count;
  }
  
  if($myd=="y")
  {
    $ret_diff=$year_diff_;
  }

  return $ret_diff;

}

function ifnotblank($str,$replacement)
{
	
    if($str!="")
    {
     return $replacement;
     
    }else{
    return $str;
    }

}

function time_elapsed_string($datetime, $full = false) 
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        "y" => "year",
        "m" => "month",
        "w" => "week",
        "d" => "day",
        "h" => "hour",
        "i" => "minute",
        "s" => "second",
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . " " . $v . ($diff->$k > 1 ? "s" : "");
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(", ", $string) . " ago" : "just now";
}

if (file_exists("./mosy_paginate.php")){
include("./mosy_paginate.php");
}

function pdf_url($current, $pdfurl)
{
  
  $filter_param=str_replace($current."", $pdfurl."", (magic_current_url()));

  if(strpos($filter_param, '?') !== false) 
  {
    $filter_param=str_replace($current."?", $pdfurl."?", (magic_current_url()));

  }

  if(strpos($filter_param, '.php?') !== false) 
  {
    $filter_param=str_replace($current.".php?", $pdfurl."?", (magic_current_url()));

  }

  return $filter_param;
  
}


function mosy_send_mail($to_email, $from_email, $sender_name, $subject, $message, $use_api="")
{
	// create email headers
	$replyto_mail="";
	$returnpath="";
	$headers="";

	if($from_email!='')
	{
    	$replyto_mail='Reply-To: ' .$sender_name." <".$from_email.">\r\n";
    	$returnpath='Return-Path: ' .$sender_name." <".$from_email.">\r\n";
	}

	$busmail=$from_email;
	$bus_name=$sender_name;

	if($to_email=='')
	{
		$busmail='info@clearphrases.com';
	}

	if($sender_name=='')
	{
		$bus_name="";
	}

    $headers = 'From: '.$bus_name.'<'.$busmail.'>' . "\r\n" .
    $headers.=$replyto_mail;
    $headers.=$returnpath;
    $headers .= "Organization: ".$bus_name."\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers.='Content-type: text/html; charset=UTF-8'. "\r\n";
    $headers .= "X-Priority: 3\r\n";
    $headers .= "X-Mailer: PHP". phpversion() ."\r\n";
   
  if($use_api=="yes")
  {
    
    $curlopt_url="https://origin.clearphrases.com/api/email/mosy_mail.php";
    
    $email_attr="send_mosy_email&to_email=".rawurlencode($to_email)."&from_email=".rawurlencode($from_email)."&sender_name=".rawurlencode($sender_name)."&subject=".rawurlencode($subject)."&message=".rawurlencode($message)."";
    
   return magic_post_curl($curlopt_url, "", "", $email_attr, "POST");

  }else{
    
  return mail($to_email, $subject, $message, $headers);        
  }
}


function mosy_push_sms($recp, $sms_body, $smsapi_url="")
{

  
  if($smsapi_url=="")
  {
    $smsapi_url="https://origin.clearphrases.com/api/sms/adminsmsgateway.php";
  }
  
  $sms_request="pushsms&recp=".$recp."&body=".$sms_body."";

  return magic_post_curl($smsapi_url, '', '', $sms_request, 'POST');

}
function add_url_param( $key, $value, $passed_url) 
{
  $url=$passed_url;
  if($passed_url=='')
  {
    $url=magic_current_url();
  }
  
  $info = parse_url( $url );

  if(isset($info['query']))
  {
    parse_str( $info['query'], $query );
  }else{
    $query="";
  }
    return $info['scheme'] . '://' . $info['host'] . $info['path'] . '?' . http_build_query( $query ? array_merge( $query, array($key => $value ) ) : array( $key => $value ) );
}


function mosy_user_acc_($user_id, $access_key="")
{
  
  if($access_key=="")    
  {
    $access_key=magic_basename(magic_current_url());
  }
  
    
  $access_key=str_replace(".php", "", $access_key); 
  
  $page_group=qpage_manifest__ddata("page_url", $access_key);

  $pagegrp=$page_group['page_group'];

  $user_access_req=count_user_manifest_(" user_id='$user_id' and role_name='$pagegrp' ");

  $user_role_attr=quser_manifest__gdata(" where  user_id='$user_id' and role_name='$pagegrp' ");

  ///echo " status - ".$user_access_req;
  ///echo " Page ".$pagegrp." - user_count - ".$user_access_req." NAme - ".$user_role_attr['user_name']." acc key - ".$access_key."<br>";  
  if($user_access_req>0)
  {
    $acc_state="Allowed";
  }else{
    $acc_state="Denied";
  }

  return $acc_state;
}



function mosy_log_notific($note_title,$note_remark,$note_link="",$note_type="",$note_icon="img/logo.png")
{
  
  //------- begin notification_manifest__arr --> 
  $notification_manifest__arr_=array(

  "notific_key"=>magic_random_str(10),
  "notification_type"=>$note_type,
  "notification_state"=>"Unread",
  "notification_icon"=>$note_icon,
  "notification_title"=>$note_title,
  "notification_link"=>$note_link,
  "notification_read_state"=>"Unread",
  "notification_time_stamp"=>date("Y-m-d H:i:a"),
  "notif_remark"=>$note_remark

  );
  //===-- End notification_manifest__arr -->

  return add_notification_manifest_($notification_manifest__arr_);
  
}

function trim_text($string)
{
 return magic_strip_if($string, 90, 90);
}


function mosyget_($tbl, $colstr="*",$where_str="",$pagination="l",$function_cols="", $endpoint="")
{
  global $root_url;
  
  if($endpoint=="")
  {
    $endpoint=$root_url;
  }
  
  $pagination_token="";
  $next_page="";
  
  if (strpos($pagination, ":") !== false)
  {
    $loop_or_row_l_r_str=explode(":", $pagination);

    $pagination_token=$loop_or_row_l_r_str[1];

    ///print_r($loop_or_row_l_r_str);
      
    }
  
  if(isset($_GET[$pagination_token]))
  {
    $next_page="&".$pagination_token."=".$_GET[$pagination_token];
  }
  
  $payload="mosyget_&tbl=".$tbl."&colstr=".base64_encode($colstr)."&where_str=".base64_encode($where_str)."&pagination=".$pagination."&function_cols=".base64_encode($function_cols)."".$next_page."";

  ///echo $endpoint;
  
  //echo  $payload;
    
  $curlopt_url=$endpoint."?".$payload;
  $curlopt_httpheader="";
  $curlopt_userpwd="";
  $curlopt_post_fields="";
  $curlopt_customrequest="GET";

  $json__=magic_post_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest);
  
   ///echo $json__;
  
  $decoded_resp=json_decode($json__, true);;

  return $decoded_resp;
}



function mosypost_($post_arr, $additional_posts, $endpoint="")
{
  global $root_url;
  
  if($endpoint=="")
  {
    $endpoint=$root_url;
  }
  
  $app_users_mosy_rest_req_vars=http_build_query($post_arr);
  
  $additional_posts_str="";
  
  if($additional_posts!="")
  {
    $additional_posts_str="&".$additional_posts;
  }
  
  
  $curlopt_url=$endpoint;
  $curlopt_httpheader="";
  $curlopt_userpwd="";
  $curlopt_post_fields="mosyrequest_type=ajax&".$app_users_mosy_rest_req_vars.$additional_posts_str;
  $curlopt_customrequest="POST";

  return magic_post_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest);
  
}



function mosypost_arr_($post_arr, $additional_posts, $endpoint="")
{
  global $root_url;
  
  if($endpoint=="")
  {
    $endpoint=$root_url;
  }
  
  $ajax_arr_req=array("mosyrequest_type"=>"ajax");
  
  $post_data_arr=array_merge($ajax_arr_req, $post_arr, $additional_posts);
  
  ////print_r($post_data_arr);
  
  $curlopt_url=$endpoint;
  $curlopt_httpheader="";
  $curlopt_userpwd="";
  $curlopt_post_fields=$post_data_arr;
  $curlopt_customrequest="POST";

  return magic_post_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest);
  
}


function getarr_val_($array_, $key)
{
  $msarray_val_="";
  
  if(isset($array_[$key]))
  {
   $msarray_val_=$array_[$key];
  }
  
  return $msarray_val_;
  
}

//<--ncgh-->
?>