
  
  
  function rm_users_mosy_login($login_password,$user_name,$endpoint="")
      {

        $login_res_=mosyget_("rm_users","*"," where username='$user_name'  and admin_password=''  ")["data"][0];

        ///print_r($login_res_);

        if(!empty($login_res_['username']) && !empty($login_res_['firstname']))
        {

          $_SESSION['session_ng_logged']=TRUE;
          $_SESSION['session_ng_logged_username']=$login_res_[''];
          $_SESSION['session_ng_logged_firstname']=$login_res_['firstname'];
          $_SESSION['session_ng_logged_username']=$login_res_['username'];

        if(isset($_GET['ref_url_go_to'])){

            $ref_url_go_to=base64_decode($_GET['ref_url_go_to']);

            header("location:".$ref_url_go_to."");


        }else{

            header("location:./splash.php");

        }

        }else{

            echo magic_message("Wrong password or user name please try again");
        }

      }
      //=== End Log in to rm_users Login Script query
  
  