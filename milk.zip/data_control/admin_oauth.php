<?php  
    //====Oauth File Routes

	$login_file="./adminapplogin";
    $register_file="./adminregisterappuser";
    $change_password_file="./adminresetpassword";
    $reset_password_file="./adminresetpassword";
    
    //====Oauth File Routes
    
    
  
  ///===The script below is designed to be used by users with accounts in the system_admins table only
  
  ////user login script 
  function system_admins_mosy_login($login_password,$user_name,$endpoint="")
  {
        $login_res_=mgqsystem_admins_gdata(" where admin_email='$user_name'  and login_password='$login_password'  ");
        
        ///print_r($login_res_);

        if(!empty($login_res_['admin_email']) && !empty($login_res_['login_password']))
        {

          $_SESSION['session_admin_logged']=TRUE;
          $_SESSION['session_admin_logged_admin_email']=$login_res_['admin_email'];
          $_SESSION['session_admin_logged_admin_name']=$login_res_['admin_name'];
          $_SESSION['session_admin_logged_admin_id']=$login_res_['admin_id'];

        if(isset($_GET['ref_url_go_to'])){

            $ref_url_go_to=base64_decode($_GET['ref_url_go_to']);

            header("location:".$ref_url_go_to."");


        }else{

            header("location:./adminsplash");

        }

        }else{

            echo magic_message("Wrong password or user name please try again");
        }

    }



    if(isset($_POST["btn_login"]))
    {
     system_admins_mosy_login($_POST["txt_password"],$_POST["txt_username"]);
    }
    //=== End Log in to rm_users Login Script query
  
  

//=========request password

function system_admins_request_pass_($membusername)
{

    $login_res_=mgqsystem_admins_gdata(" where admin_email='$membusername'  ");
 
    if($login_res_["admin_email"]!="")
    {

      $sender_name="ClearPhrases Reset Pssword"; 
      $tel="0710766390"; 

      $from_email="clearphrases@gmail.com";

      $to_email=$membusername;
      $client_names=$login_res_['admin_name'];


      $path1="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
      //echo $path1;

      $msgtosend='Hello You requested a password request. Follow this link to create a new password.<br /><br />
      <a href="'.$path1.'?reset_token='.base64_encode($login_res_['primkey']).'">Reset Password</a><br /><br />';

      $message=$msgtosend;
      $subject="Password reset Request";
      $actlink="http://www.clearphrases.com";

	  mosy_send_mail($to_email, $from_email, $sender_name, $subject, $message, "yes");
      
      //echo $msgtosend;

      echo magic_message("We have sent you a reset password email to ".$to_email.".<hr> Follow that link to reset your password");

    }else{
    echo magic_message("Sorry that email does not exist. Please Try Again");
    }
}
//===================reset password request  
  
  
if(isset($_POST["request_password_reset_btn"]))
{
   system_admins_request_pass_($_POST["txt_email"]);
}

function system_admins_change_password($primkey, $pass1, $pass2, $endpoint="")
{
  if($pass1=="" || $pass2=="")
  {

    echo magic_message("Password cannot be blank!!");
  
  }else{
  
  if($pass1!=$pass2)
  {

    echo magic_message("Password Do Not match!!");
  
    }else{

      ///mysqli_query($mysqliconn,"UPDATE `$isppro`.`` SET login_password='$resetpass1' WHERE ='$foundresetmail' AND primkey='$memberkey'");

      echo magic_message("Password reset succesfully. Login afresh to continue.");

      $pass_reset_arr=["txt_login_password"=>$pass1,"system_admins_uptoken"=>base64_encode($primkey),"system_admins_update_btn"=>"ok"];

      return mosypost_($pass_reset_arr, $endpoint);
    }
  }
  
}
//===========reset pass=============   


if(isset($_POST["confirm_password_reset_btn"]))
{

  $txt_password_one=mmres($_POST["txt_password_one"]);
  $txt_password_two=mmres($_POST["txt_password_two"]);
  $reset_token=base64_decode($_GET["reset_token"]);

  system_admins_change_password($reset_token,$txt_password_one,$txt_password_two);

}

function system_admins_create_acc($user_acc_regr, $additional_arr, $endpoint="")
{
 
    return mosypost_($user_acc_regr, $additional_arr, $endpoint);
 
}


//user create account 
if(isset($_POST["create_user_acc"]))
{
  $req_email=mmres($_POST["txt_admin_email"]);
  
  $count_dup_username=mgcount_system_admins(" admin_email='$req_email' ");
  
  ///echo "dupmail".$count_dup_username;
  
  if($count_dup_username==0)
  {
     $system_admins_create_acc_request= system_admins_create_acc($_POST, "system_admins_insert_btn");
      
     if($system_admins_create_acc_request)
     {
      echo magic_screen('Account Created Succesfully.<hr> <a href="'.$login_file.'" class="btn btn-primary">Click Here To Login</a>');
     }else{
     echo magic_screen("An error Occured when creating your account. Kindy try again");
     
     }
                                            
  }else{
   
   echo magic_message("Duplicate email found. Kindy try another one.");
   
  }
}

?>
