<?php 

        if(isset($_POST["mpcourses_insert_btn"]))
        {
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "insert","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
                $courses_post_arr=$_POST;
                
				
         
                if(!empty($_FILES['txt_courses_user_pic']['tmp_name']))
                {
                                 

			 $courses_user_pic_curl_media_arr = curl_file_create($_FILES['txt_courses_user_pic']['tmp_name'],$_FILES['txt_courses_user_pic']['type'],$_FILES['txt_courses_user_pic']['name']);

		      $courses_user_pic_post_media_arr = array(
               'txt_courses_user_pic' => $courses_user_pic_curl_media_arr);
           
           
                 $courses_post_arr=array_merge($courses_user_pic_post_media_arr,$_POST); 
                 
				}
                
         
                    
                $courses_return_key=mosypost_arr_($courses_post_arr, ["courses_insert_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$courses_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $courses_return_key; 

                      } 

                    }else{ 

                                    
                $courses_custom_redir1=add_url_param ("courses_uptoken", base64_encode($courses_return_key), "");
                $courses_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$courses_custom_redir1);
                $courses_custom_redir3=add_url_param ("courses_table_alert", "courses_added",$courses_custom_redir2);
                
                ///echo magic_message($courses_custom_redir1." -- ".$courses_custom_redir2."--".$courses_custom_redir3);
                
                $courses_custom_redir=$courses_custom_redir3;
                
               header('location:'.$courses_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_courses_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");

           }

         }
      
        if(isset($_POST["mpcourses_update_btn"]))
        {
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "insert","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
                $courses_post_arr=$_POST;
                
				
         
                if(!empty($_FILES['txt_courses_user_pic']['tmp_name']))
                {
                                 

			 $courses_user_pic_curl_media_arr = curl_file_create($_FILES['txt_courses_user_pic']['tmp_name'],$_FILES['txt_courses_user_pic']['type'],$_FILES['txt_courses_user_pic']['name']);

		      $courses_user_pic_post_media_arr = array(
               'txt_courses_user_pic' => $courses_user_pic_curl_media_arr);
           
           
                 $courses_post_arr=array_merge($courses_user_pic_post_media_arr,$_POST); 
                 
				}
                
         
                    
                $courses_return_key=mosypost_arr_($courses_post_arr, ["courses_update_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$courses_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $courses_return_key; 

                      } 

                    }else{ 

                                    
                $courses_custom_redir1=add_url_param ("courses_uptoken", base64_encode($courses_return_key), "");
                $courses_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$courses_custom_redir1);
                $courses_custom_redir3=add_url_param ("courses_table_alert", "courses_added",$courses_custom_redir2);
                
                ///echo magic_message($courses_custom_redir1." -- ".$courses_custom_redir2."--".$courses_custom_redir3);
                
                $courses_custom_redir=$courses_custom_redir3;
                
               header('location:'.$courses_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_courses_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");

           }

         }
      
        if(isset($_POST["mplessons_insert_btn"]))
        {
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "insert","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
                $lessons_post_arr=$_POST;
                
				
         
                if(!empty($_FILES['txt_lessons_user_pic']['tmp_name']))
                {
                                 

			 $lessons_user_pic_curl_media_arr = curl_file_create($_FILES['txt_lessons_user_pic']['tmp_name'],$_FILES['txt_lessons_user_pic']['type'],$_FILES['txt_lessons_user_pic']['name']);

		      $lessons_user_pic_post_media_arr = array(
               'txt_lessons_user_pic' => $lessons_user_pic_curl_media_arr);
           
           
                 $lessons_post_arr=array_merge($lessons_user_pic_post_media_arr,$_POST); 
                 
				}
                
         
                    
                $lessons_return_key=mosypost_arr_($lessons_post_arr, ["lessons_insert_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$lessons_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $lessons_return_key; 

                      } 

                    }else{ 

                                    
                $lessons_custom_redir1=add_url_param ("lessons_uptoken", base64_encode($lessons_return_key), "");
                $lessons_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$lessons_custom_redir1);
                $lessons_custom_redir3=add_url_param ("lessons_table_alert", "lessons_added",$lessons_custom_redir2);
                
                ///echo magic_message($lessons_custom_redir1." -- ".$lessons_custom_redir2."--".$lessons_custom_redir3);
                
                $lessons_custom_redir=$lessons_custom_redir3;
                
               header('location:'.$lessons_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_lessons_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");

           }

         }
      
        if(isset($_POST["mplessons_update_btn"]))
        {
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "insert","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
                $lessons_post_arr=$_POST;
                
				
         
                if(!empty($_FILES['txt_lessons_user_pic']['tmp_name']))
                {
                                 

			 $lessons_user_pic_curl_media_arr = curl_file_create($_FILES['txt_lessons_user_pic']['tmp_name'],$_FILES['txt_lessons_user_pic']['type'],$_FILES['txt_lessons_user_pic']['name']);

		      $lessons_user_pic_post_media_arr = array(
               'txt_lessons_user_pic' => $lessons_user_pic_curl_media_arr);
           
           
                 $lessons_post_arr=array_merge($lessons_user_pic_post_media_arr,$_POST); 
                 
				}
                
         
                    
                $lessons_return_key=mosypost_arr_($lessons_post_arr, ["lessons_update_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$lessons_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $lessons_return_key; 

                      } 

                    }else{ 

                                    
                $lessons_custom_redir1=add_url_param ("lessons_uptoken", base64_encode($lessons_return_key), "");
                $lessons_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$lessons_custom_redir1);
                $lessons_custom_redir3=add_url_param ("lessons_table_alert", "lessons_added",$lessons_custom_redir2);
                
                ///echo magic_message($lessons_custom_redir1." -- ".$lessons_custom_redir2."--".$lessons_custom_redir3);
                
                $lessons_custom_redir=$lessons_custom_redir3;
                
               header('location:'.$lessons_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_lessons_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");

           }

         }
      
        if(isset($_POST["mpmosy_sql_roll_back_insert_btn"]))
        {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
                $mosy_sql_roll_back_post_arr=$_POST;
                
				
                    
                $mosy_sql_roll_back_return_key=mosypost_arr_($mosy_sql_roll_back_post_arr, ["mosy_sql_roll_back_insert_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$mosy_sql_roll_back_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

           }

         }
      
        if(isset($_POST["mpmosy_sql_roll_back_update_btn"]))
        {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
                $mosy_sql_roll_back_post_arr=$_POST;
                
				
                    
                $mosy_sql_roll_back_return_key=mosypost_arr_($mosy_sql_roll_back_post_arr, ["mosy_sql_roll_back_update_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$mosy_sql_roll_back_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

           }

         }
      
        if(isset($_POST["mpschools_insert_btn"]))
        {
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "insert","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
                $schools_post_arr=$_POST;
                
				
         
                if(!empty($_FILES['txt_schools_user_pic']['tmp_name']))
                {
                                 

			 $schools_user_pic_curl_media_arr = curl_file_create($_FILES['txt_schools_user_pic']['tmp_name'],$_FILES['txt_schools_user_pic']['type'],$_FILES['txt_schools_user_pic']['name']);

		      $schools_user_pic_post_media_arr = array(
               'txt_schools_user_pic' => $schools_user_pic_curl_media_arr);
           
           
                 $schools_post_arr=array_merge($schools_user_pic_post_media_arr,$_POST); 
                 
				}
                
         
                    
                $schools_return_key=mosypost_arr_($schools_post_arr, ["schools_insert_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$schools_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $schools_return_key; 

                      } 

                    }else{ 

                                    
                $schools_custom_redir1=add_url_param ("schools_uptoken", base64_encode($schools_return_key), "");
                $schools_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$schools_custom_redir1);
                $schools_custom_redir3=add_url_param ("schools_table_alert", "schools_added",$schools_custom_redir2);
                
                ///echo magic_message($schools_custom_redir1." -- ".$schools_custom_redir2."--".$schools_custom_redir3);
                
                $schools_custom_redir=$schools_custom_redir3;
                
               header('location:'.$schools_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_schools_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");

           }

         }
      
        if(isset($_POST["mpschools_update_btn"]))
        {
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "insert","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
                $schools_post_arr=$_POST;
                
				
         
                if(!empty($_FILES['txt_schools_user_pic']['tmp_name']))
                {
                                 

			 $schools_user_pic_curl_media_arr = curl_file_create($_FILES['txt_schools_user_pic']['tmp_name'],$_FILES['txt_schools_user_pic']['type'],$_FILES['txt_schools_user_pic']['name']);

		      $schools_user_pic_post_media_arr = array(
               'txt_schools_user_pic' => $schools_user_pic_curl_media_arr);
           
           
                 $schools_post_arr=array_merge($schools_user_pic_post_media_arr,$_POST); 
                 
				}
                
         
                    
                $schools_return_key=mosypost_arr_($schools_post_arr, ["schools_update_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$schools_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $schools_return_key; 

                      } 

                    }else{ 

                                    
                $schools_custom_redir1=add_url_param ("schools_uptoken", base64_encode($schools_return_key), "");
                $schools_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$schools_custom_redir1);
                $schools_custom_redir3=add_url_param ("schools_table_alert", "schools_added",$schools_custom_redir2);
                
                ///echo magic_message($schools_custom_redir1." -- ".$schools_custom_redir2."--".$schools_custom_redir3);
                
                $schools_custom_redir=$schools_custom_redir3;
                
               header('location:'.$schools_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_schools_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");

           }

         }
      
        if(isset($_POST["mpstudents_insert_btn"]))
        {
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "insert","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
                $students_post_arr=$_POST;
                
				
         
                if(!empty($_FILES['txt_students_user_pic']['tmp_name']))
                {
                                 

			 $students_user_pic_curl_media_arr = curl_file_create($_FILES['txt_students_user_pic']['tmp_name'],$_FILES['txt_students_user_pic']['type'],$_FILES['txt_students_user_pic']['name']);

		      $students_user_pic_post_media_arr = array(
               'txt_students_user_pic' => $students_user_pic_curl_media_arr);
           
           
                 $students_post_arr=array_merge($students_user_pic_post_media_arr,$_POST); 
                 
				}
                
         
                    
                $students_return_key=mosypost_arr_($students_post_arr, ["students_insert_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$students_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $students_return_key; 

                      } 

                    }else{ 

                                    
                $students_custom_redir1=add_url_param ("students_uptoken", base64_encode($students_return_key), "");
                $students_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$students_custom_redir1);
                $students_custom_redir3=add_url_param ("students_table_alert", "students_added",$students_custom_redir2);
                
                ///echo magic_message($students_custom_redir1." -- ".$students_custom_redir2."--".$students_custom_redir3);
                
                $students_custom_redir=$students_custom_redir3;
                
               header('location:'.$students_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_students_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");

           }

         }
      
        if(isset($_POST["mpstudents_update_btn"]))
        {
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "insert","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
                $students_post_arr=$_POST;
                
				
         
                if(!empty($_FILES['txt_students_user_pic']['tmp_name']))
                {
                                 

			 $students_user_pic_curl_media_arr = curl_file_create($_FILES['txt_students_user_pic']['tmp_name'],$_FILES['txt_students_user_pic']['type'],$_FILES['txt_students_user_pic']['name']);

		      $students_user_pic_post_media_arr = array(
               'txt_students_user_pic' => $students_user_pic_curl_media_arr);
           
           
                 $students_post_arr=array_merge($students_user_pic_post_media_arr,$_POST); 
                 
				}
                
         
                    
                $students_return_key=mosypost_arr_($students_post_arr, ["students_update_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$students_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $students_return_key; 

                      } 

                    }else{ 

                                    
                $students_custom_redir1=add_url_param ("students_uptoken", base64_encode($students_return_key), "");
                $students_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$students_custom_redir1);
                $students_custom_redir3=add_url_param ("students_table_alert", "students_added",$students_custom_redir2);
                
                ///echo magic_message($students_custom_redir1." -- ".$students_custom_redir2."--".$students_custom_redir3);
                
                $students_custom_redir=$students_custom_redir3;
                
               header('location:'.$students_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_students_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");

           }

         }
      
        if(isset($_POST["mptransactions_table_insert_btn"]))
        {
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "insert","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
                $transactions_table_post_arr=$_POST;
                
				
                    
                $transactions_table_return_key=mosypost_arr_($transactions_table_post_arr, ["transactions_table_insert_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$transactions_table_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $transactions_table_return_key; 

                      } 

                    }else{ 

                                    
                $transactions_table_custom_redir1=add_url_param ("transactions_table_uptoken", base64_encode($transactions_table_return_key), "");
                $transactions_table_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$transactions_table_custom_redir1);
                $transactions_table_custom_redir3=add_url_param ("transactions_table_table_alert", "transactions_table_added",$transactions_table_custom_redir2);
                
                ///echo magic_message($transactions_table_custom_redir1." -- ".$transactions_table_custom_redir2."--".$transactions_table_custom_redir3);
                
                $transactions_table_custom_redir=$transactions_table_custom_redir3;
                
               header('location:'.$transactions_table_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_transactions_table_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");

           }

         }
      
        if(isset($_POST["mptransactions_table_update_btn"]))
        {
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "insert","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
                $transactions_table_post_arr=$_POST;
                
				
                    
                $transactions_table_return_key=mosypost_arr_($transactions_table_post_arr, ["transactions_table_update_btn"=>"ok"]);
                    
                /////print_r($_POST);
                
                ////echo "ret keyyyyyyy ".$transactions_table_return_key;
 
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $transactions_table_return_key; 

                      } 

                    }else{ 

                                    
                $transactions_table_custom_redir1=add_url_param ("transactions_table_uptoken", base64_encode($transactions_table_return_key), "");
                $transactions_table_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$transactions_table_custom_redir1);
                $transactions_table_custom_redir3=add_url_param ("transactions_table_table_alert", "transactions_table_added",$transactions_table_custom_redir2);
                
                ///echo magic_message($transactions_table_custom_redir1." -- ".$transactions_table_custom_redir2."--".$transactions_table_custom_redir3);
                
                $transactions_table_custom_redir=$transactions_table_custom_redir3;
                
               header('location:'.$transactions_table_custom_redir.'');
                
                       

                   } 

             }else{

              echo magic_screen($gwauthenticate_transactions_table_);

              //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");

           }

         }
      

//<--ncgh-->

?>