<?php  
    //====Oauth File Routes

	$login_file="./applogin";
    $register_file="./registerappuser";
    $change_password_file="./resetpassword";
    $reset_password_file="./resetpassword";
    
    //====Oauth File Routes
    
    
  
  ///===The script below is designed to be used by users with accounts in the app_users table only
  
  ////user login script 
  function app_users_mosy_login($login_password,$user_name,$endpoint="")
  {
        $login_res_=mosyget_("app_users","*"," where email='$user_name'  and login_password='$login_password'  ")["data"][0];

        ///print_r($login_res_);

        if(!empty($login_res_['email']) && !empty($login_res_['login_password']))
        {

          $_SESSION['session_mrpt_logged']=TRUE;
          $_SESSION['session_mrpt_logged_email']=$login_res_['email'];
          $_SESSION['session_mrpt_logged_name']=$login_res_['name'];
          $_SESSION['session_mrpt_logged_user_id']=$login_res_['user_id'];

        if(isset($_GET['ref_url_go_to'])){

            $ref_url_go_to=base64_decode($_GET['ref_url_go_to']);

            header("location:".$ref_url_go_to."");


        }else{

            header("location:./splash");

        }

        }else{

            echo magic_message("Wrong password or user name please try again");
        }

    }



    if(isset($_POST["btn_login"]))
    {
     app_users_mosy_login($_POST["txt_password"],$_POST["txt_username"]);
    }
    //=== End Log in to rm_users Login Script query
  
  

//=========request password

function app_users_request_pass_($membusername)
{

    $login_res_=mgqapp_users_gdata(" where email='$membusername'  ");
 
    if($login_res_["email"]!="")
    {

      $sender_name="ClearPhrases Reset Pssword"; 
      $tel="0710766390"; 

      $from_email="clearphrases@gmail.com";

      $to_email=$membusername;
      $client_names=$login_res_['name'];


      $path1="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
      //echo $path1;

      $msgtosend='Hello You requested a password request. Follow this link to create a new password.<br /><br />
      <a href="'.$path1.'?reset_token='.base64_encode($login_res_['primkey']).'">Reset Password</a><br /><br />';

      $message=$msgtosend;
      $subject="Password reset Request";
      $actlink="http://www.clearphrases.com";

	  mosy_send_mail($to_email, $from_email, $sender_name, $subject, $message, "yes");
      
      //echo $msgtosend;

      echo magic_message("We have sent you a reset password email to ".$to_email.".<hr> Follow that link to reset your password");

    }else{
    echo magic_message("Sorry that email does not exist. Please Try Again");
    }
}
//===================reset password request  
  
  
if(isset($_POST["request_password_reset_btn"]))
{
   app_users_request_pass_($_POST["txt_email"]);
}

function app_users_change_password($primkey, $pass1, $pass2, $endpoint="")
{
  if($pass1=="" || $pass2=="")
  {

    echo magic_message("Password cannot be blank!!");
  
  }else{
  
  if($pass1!=$pass2)
  {

    echo magic_message("Password Do Not match!!");
  
    }else{

      ///mysqli_query($mysqliconn,"UPDATE `$isppro`.`` SET login_password='$resetpass1' WHERE ='$foundresetmail' AND primkey='$memberkey'");

      echo magic_message("Password reset succesfully. Login afresh to continue.");

      $pass_reset_arr=["txt_login_password"=>$pass1,"app_users_uptoken"=>base64_encode($primkey),"app_users_update_btn"=>"ok"];

      return mosypost_($pass_reset_arr, $endpoint);
    }
  }
  
}
//===========reset pass=============   


if(isset($_POST["confirm_password_reset_btn"]))
{

  $txt_password_one=mmres($_POST["txt_password_one"]);
  $txt_password_two=mmres($_POST["txt_password_two"]);
  $reset_token=base64_decode($_GET["reset_token"]);

  app_users_change_password($reset_token,$txt_password_one,$txt_password_two);

}

function app_users_create_acc($user_acc_regr, $additional_arr, $endpoint="")
{
 
    return mosypost_($user_acc_regr, $additional_arr, $endpoint);
 
}


//user create account 
if(isset($_POST["create_user_acc"]))
{
  $req_email=mmres($_POST["txt_email"]);
  
  $count_dup_username=mgcount_app_users(" email='$req_email' ");
  
  ///echo "dupmail".$count_dup_username;
  
  if($count_dup_username==0)
  {
     $app_users_create_acc_request= app_users_create_acc($_POST, "app_users_insert_btn");
      
     if($app_users_create_acc_request)
     {
      echo magic_screen('Account Created Succesfully.<hr> <a href="'.$login_file.'" class="btn btn-primary">Click Here To Login</a>');
     }else{
     echo magic_screen("An error Occured when creating your account. Kindy try again");
     
     }
                                            
  }else{
   
   echo magic_message("Duplicate email found. Kindy try another one.");
   
  }
}

?>
