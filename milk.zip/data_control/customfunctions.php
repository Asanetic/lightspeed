<?php
$this_month=date("Y-m");
$today=date("Y-m-d");
$right_now=date("Y-m-d H:i:s");

?>