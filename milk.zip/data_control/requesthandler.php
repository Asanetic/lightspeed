<?php 
//===============Start DATA HANDLER QUERIES ===================
				
              $run_mosy_api="no";
              $mosy_rest_url="";
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section courses
  //************************************************* START  courses OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize courses edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['courses_table_alert']))
              	{	
                  if(isset($courses_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$courses_uptoken="";

		if(isset($_GET["courses_uptoken"]))
		{
		$courses_uptoken=base64_decode($_GET["courses_uptoken"]);
		}
        
        if(isset($_POST["courses_uptoken"]))
		{
		$courses_uptoken=base64_decode($_POST["courses_uptoken"]);
		}
        //
        
          $courses_alias_name="COURSES";

          if(isset($courses_alias))
          {
             $courses_alias_name=$courses_alias;

          }
          
        //get single data record query with $courses_uptoken
        
        ///$courses_node=get_courses("*", "WHERE primkey='$courses_uptoken'", "r");
        
	
//************* START INSERT  courses QUERY 
if(isset($_POST["courses_insert_btn"])){
//------- begin courses_arr_ins --> 
$courses_arr_ins_=array(

"primkey"=>"NULL",
"course_id"=>magic_random_str(7),
"school_id"=>"?",
"school_name"=>"?",
"user_pic"=>"?",
"course_descr"=>"?",
"course_amt"=>"?",
"site_id"=>"?",
"course_name"=>"?"

);
//===-- End courses_arr_ins -->


          
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "insert","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {

              $courses_validated_ins_str=$courses_arr_ins_;

              if(isset($courses_ins_inputs))
              {
                $courses_validated_ins_str=$courses_ins_inputs;	
              }

              if(empty($courses_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$courses_alias_name." request cannot be empty. Record not added");
              }else{
                $courses_return_key=add_courses($courses_validated_ins_str);
                
                mosy_sql_rollback("courses", "primkey='$courses_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_courses_user_pic']['tmp_name']))
                {
                
                 upload_courses_user_pic('txt_courses_user_pic', "primkey='$courses_return_key'");
                 
				}
                
         

				if($run_mosy_api=="yes")
                {
				$courses_mosy_rest_req_vars=http_build_query($_POST);
                echo $courses_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $courses_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $courses_return_key; 

                      } 

                    }else{ 

                                    
                $courses_custom_redir1=add_url_param ("courses_uptoken", base64_encode($courses_return_key), "");
                $courses_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$courses_custom_redir1);
                $courses_custom_redir3=add_url_param ("courses_table_alert", "courses_added",$courses_custom_redir2);
                
                ///echo magic_message($courses_custom_redir1." -- ".$courses_custom_redir2."--".$courses_custom_redir3);
                
                $courses_custom_redir=$courses_custom_redir3;
                
               header('location:'.$courses_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_courses_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");
         
         }
      
}
//************* END  courses INSERT QUERY 	
	

//************* START courses  UPDATE QUERY 
if(isset($_POST["courses_update_btn"])){
//------- begin courses_arr_updt --> 
$courses_arr_updt_=array(
"school_id"=>"?",
"school_name"=>"?",
"user_pic"=>"?",
"course_descr"=>"?",
"course_amt"=>"?",
"site_id"=>"?",
"course_name"=>"?"

);
//===-- End courses_arr_updt -->
                     
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "update","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
         
            $courses_validated_updt_str=$courses_arr_updt_;

            if(isset($courses_updt_inputs))
            {
              $courses_validated_updt_str=$courses_updt_inputs;	
            }

            if(empty($courses_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$courses_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$courses_key_salt=initialize_courses()["course_id"];
            
              update_courses($courses_validated_updt_str, "primkey='$courses_uptoken' and course_id='$courses_key_salt'");
				
         
                if(!empty($_FILES['txt_courses_user_pic']['tmp_name']))
                {
                
                 upload_courses_user_pic('txt_courses_user_pic', "primkey='$courses_uptoken'");
                 
				}

			 mosy_sql_rollback("courses", "primkey='$courses_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $courses_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $courses_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $courses_uptoken; 

                    } 

                  }else{ 

                $courses_custom_redir1=add_url_param ("courses_uptoken", base64_encode($courses_uptoken), "");
                $courses_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$courses_custom_redir1);
                $courses_custom_redir3=add_url_param ("courses_table_alert", "courses_updated",$courses_custom_redir2);
                
                ///echo magic_message($courses_custom_redir1." -- ".$courses_custom_redir2."--".$courses_custom_redir3);
                
                $courses_custom_redir=$courses_custom_redir3;
                
               header('location:'.$courses_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_courses_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_courses_)."");
         
         }

      

      
}
//************* END courses  UPDATE QUERY 

    

          //===-====Start upload courses_user_pic 
          if(isset($_POST["btn_upload_courses_user_pic"]))
          {
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "upload_courses_user_pic","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_courses_user_pic']['tmp_name'])){

				upload_courses_user_pic('txt_courses_user_pic', "primkey='$courses_uptoken'");
                
                $courses_custom_redir1=add_url_param ("courses_uptoken", base64_encode($courses_uptoken), "");
                $courses_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$courses_custom_redir1);
                $courses_custom_redir3=add_url_param ("courses_table_alert", "courses_uploaded",$courses_custom_redir2);
                
                ///echo magic_message($courses_custom_redir1." -- ".$courses_custom_redir2."--".$courses_custom_redir3);
                
                $courses_custom_redir=$courses_custom_redir3;
                
               header('location:'.$courses_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_courses_);

          }
          }
          //===-====End upload courses_user_pic  

			//drop courses_user_pic image 
            
          if(isset($_GET["conf_deletecourses"]))
          {
          	$courses_node=initialize_courses();
          	if($courses_node["user_pic"]!="")
            {
          	 unlink($courses_node["user_pic"]);
            }
          }
          
          
    
      //== Start courses delete record

      if(isset($_GET["deletecourses"]))
      {
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "super_delete_request","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_courses_btn=magic_button_link("./".$current_file_url."?courses_uptoken=".$_GET["courses_uptoken"]."&conf_deletecourses&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_courses_btn=magic_button_link("./".$current_file_url."?courses_uptoken=".$_GET["courses_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_courses_btn." ".$cancel_del_courses_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_courses_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletecourses"]))
      {
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "super_delete_confirm","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $courses_del_key_salt=initialize_courses()["course_id"];
      mosy_sql_rollback("courses", "primkey='$courses_uptoken'", "DELETE");
      drop_courses("primkey='$courses_uptoken' and course_id='$courses_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_courses_);

      }
      }

      //== End courses delete record  
    
       ///SELECT STRING FOR courses============================
              
       if(isset($_POST["qcourses_btn"])){
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "qcourses_btn","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
            $current_courses_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_courses_current_url=$current_courses_url_params.'?qcourses=';
            if (strpos($current_courses_url_params, '?') !== false) {

                $clean_courses_current_url=$current_courses_url_params.'&qcourses=';

            }
            if (strpos($current_courses_url_params, '?qcourses')) {

                $remove_courses_old_token = substr($current_courses_url_params, 0, strpos($current_courses_url_params, "?qcourses"));

                $clean_courses_current_url=$remove_courses_old_token.'?qcourses=';

            }
            if(strpos($current_courses_url_params, '&qcourses')) {

                $remove_courses_old_token = substr($current_courses_url_params, 0, strpos($current_courses_url_params, "&qcourses"));

                $clean_courses_current_url=$remove_courses_old_token.'&qcourses=';

            }
        $qcourses_str=base64_encode($_POST["txt_courses"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_courses_current_url.($qcourses_str);
            } 

          }else{ 
             header('location:'.$clean_courses_current_url.($qcourses_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_courses_);

        }
        }
        $qcourses="";
		if(isset($_GET["courses_mosyfilter"]) && isset($_GET["qcourses"])){
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "courses_mosyfilter_n_query","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
         $qcourses=mmres(base64_decode($_GET["qcourses"]));
         
         $gft_courses_where_query="(`course_id` LIKE '%".$qcourses."%' OR  `school_id` LIKE '%".$qcourses."%' OR  `school_name` LIKE '%".$qcourses."%' OR  `user_pic` LIKE '%".$qcourses."%' OR  `course_descr` LIKE '%".$qcourses."%' OR  `course_amt` LIKE '%".$qcourses."%' OR  `site_id` LIKE '%".$qcourses."%' OR  `course_name` LIKE '%".$qcourses."%')";
         
         if($_GET["courses_mosyfilter"]!=""){
         
         $mosyfilter_courses_queries_str=(base64_decode($_GET["courses_mosyfilter"]));
        
         $gft_courses_where_query="(`course_id` LIKE '%".$qcourses."%' OR  `school_id` LIKE '%".$qcourses."%' OR  `school_name` LIKE '%".$qcourses."%' OR  `user_pic` LIKE '%".$qcourses."%' OR  `course_descr` LIKE '%".$qcourses."%' OR  `course_amt` LIKE '%".$qcourses."%' OR  `site_id` LIKE '%".$qcourses."%' OR  `course_name` LIKE '%".$qcourses."%') AND ".$mosyfilter_courses_queries_str."";
         
         }
         
		 $gft_courses="WHERE ".$gft_courses_where_query;
         
         $gft_courses_and=$gft_courses_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_courses_);
        }
        }elseif(isset($_GET["qcourses"])){
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "get_qcourses","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
		 $qcourses=mmres(base64_decode($_GET["qcourses"]));
        
         $gft_courses_where_query="(`course_id` LIKE '%".$qcourses."%' OR  `school_id` LIKE '%".$qcourses."%' OR  `school_name` LIKE '%".$qcourses."%' OR  `user_pic` LIKE '%".$qcourses."%' OR  `course_descr` LIKE '%".$qcourses."%' OR  `course_amt` LIKE '%".$qcourses."%' OR  `site_id` LIKE '%".$qcourses."%' OR  `course_name` LIKE '%".$qcourses."%')";
         
         $gft_courses="WHERE ".$gft_courses_where_query;
         
         $gft_courses_and=$gft_courses_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_courses_);

        }
        }elseif(isset($_GET["courses_mosyfilter"])){
         $gwauthenticate_courses_=gw_oauth("table", magic_current_url(), "courses", "courses_mosyfilter","");

         $gwauthenticate_courses_json=json_decode($gwauthenticate_courses_, true);
         	
          //echo $gwauthenticate_courses_;

         if($gwauthenticate_courses_json["response"]=="ok")
         {
         $gft_courses_where_query="";
         $gft_courses="";

         if($_GET["courses_mosyfilter"]!=""){
          $gft_courses_where_query=(base64_decode($_GET["courses_mosyfilter"]));
          $gft_courses="WHERE ".$gft_courses_where_query;
         }
         
         
         $gft_courses_and=$gft_courses_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_courses_);

        }
        }else{
         $gft_courses="";
         $gft_courses_and="";
         $gft_courses_where_query="";
        }
       
    //************************************************* END  courses OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section lessons
  //************************************************* START  lessons OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize lessons edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['lessons_table_alert']))
              	{	
                  if(isset($lessons_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$lessons_uptoken="";

		if(isset($_GET["lessons_uptoken"]))
		{
		$lessons_uptoken=base64_decode($_GET["lessons_uptoken"]);
		}
        
        if(isset($_POST["lessons_uptoken"]))
		{
		$lessons_uptoken=base64_decode($_POST["lessons_uptoken"]);
		}
        //
        
          $lessons_alias_name="LESSONS";

          if(isset($lessons_alias))
          {
             $lessons_alias_name=$lessons_alias;

          }
          
        //get single data record query with $lessons_uptoken
        
        ///$lessons_node=get_lessons("*", "WHERE primkey='$lessons_uptoken'", "r");
        
	
//************* START INSERT  lessons QUERY 
if(isset($_POST["lessons_insert_btn"])){
//------- begin lessons_arr_ins --> 
$lessons_arr_ins_=array(

"primkey"=>"NULL",
"lesson_id"=>magic_random_str(7),
"course_id"=>"?",
"school_id"=>"?",
"course_name"=>"?",
"school_name"=>"?",
"user_pic"=>"?",
"lesson_descr"=>"?",
"lesson_name"=>"?",
"lesson_cartegory"=>"?",
"lesson_preview"=>"?",
"lesson_video_url"=>"?",
"lesson_audio_url"=>"?",
"lesson_order"=>"?",
"lesson_type"=>"?",
"site_id"=>"?"

);
//===-- End lessons_arr_ins -->


          
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "insert","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {

              $lessons_validated_ins_str=$lessons_arr_ins_;

              if(isset($lessons_ins_inputs))
              {
                $lessons_validated_ins_str=$lessons_ins_inputs;	
              }

              if(empty($lessons_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$lessons_alias_name." request cannot be empty. Record not added");
              }else{
                $lessons_return_key=add_lessons($lessons_validated_ins_str);
                
                mosy_sql_rollback("lessons", "primkey='$lessons_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_lessons_user_pic']['tmp_name']))
                {
                
                 upload_lessons_user_pic('txt_lessons_user_pic', "primkey='$lessons_return_key'");
                 
				}
                
         

				if($run_mosy_api=="yes")
                {
				$lessons_mosy_rest_req_vars=http_build_query($_POST);
                echo $lessons_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $lessons_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $lessons_return_key; 

                      } 

                    }else{ 

                                    
                $lessons_custom_redir1=add_url_param ("lessons_uptoken", base64_encode($lessons_return_key), "");
                $lessons_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$lessons_custom_redir1);
                $lessons_custom_redir3=add_url_param ("lessons_table_alert", "lessons_added",$lessons_custom_redir2);
                
                ///echo magic_message($lessons_custom_redir1." -- ".$lessons_custom_redir2."--".$lessons_custom_redir3);
                
                $lessons_custom_redir=$lessons_custom_redir3;
                
               header('location:'.$lessons_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_lessons_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");
         
         }
      
}
//************* END  lessons INSERT QUERY 	
	

//************* START lessons  UPDATE QUERY 
if(isset($_POST["lessons_update_btn"])){
//------- begin lessons_arr_updt --> 
$lessons_arr_updt_=array(
"course_id"=>"?",
"school_id"=>"?",
"course_name"=>"?",
"school_name"=>"?",
"user_pic"=>"?",
"lesson_descr"=>"?",
"lesson_name"=>"?",
"lesson_cartegory"=>"?",
"lesson_preview"=>"?",
"lesson_video_url"=>"?",
"lesson_audio_url"=>"?",
"lesson_order"=>"?",
"lesson_type"=>"?",
"site_id"=>"?"

);
//===-- End lessons_arr_updt -->
                     
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "update","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
         
            $lessons_validated_updt_str=$lessons_arr_updt_;

            if(isset($lessons_updt_inputs))
            {
              $lessons_validated_updt_str=$lessons_updt_inputs;	
            }

            if(empty($lessons_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$lessons_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$lessons_key_salt=initialize_lessons()["lesson_id"];
            
              update_lessons($lessons_validated_updt_str, "primkey='$lessons_uptoken' and lesson_id='$lessons_key_salt'");
				
         
                if(!empty($_FILES['txt_lessons_user_pic']['tmp_name']))
                {
                
                 upload_lessons_user_pic('txt_lessons_user_pic', "primkey='$lessons_uptoken'");
                 
				}

			 mosy_sql_rollback("lessons", "primkey='$lessons_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $lessons_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $lessons_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $lessons_uptoken; 

                    } 

                  }else{ 

                $lessons_custom_redir1=add_url_param ("lessons_uptoken", base64_encode($lessons_uptoken), "");
                $lessons_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$lessons_custom_redir1);
                $lessons_custom_redir3=add_url_param ("lessons_table_alert", "lessons_updated",$lessons_custom_redir2);
                
                ///echo magic_message($lessons_custom_redir1." -- ".$lessons_custom_redir2."--".$lessons_custom_redir3);
                
                $lessons_custom_redir=$lessons_custom_redir3;
                
               header('location:'.$lessons_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_lessons_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_lessons_)."");
         
         }

      

      
}
//************* END lessons  UPDATE QUERY 

    

          //===-====Start upload lessons_user_pic 
          if(isset($_POST["btn_upload_lessons_user_pic"]))
          {
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "upload_lessons_user_pic","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_lessons_user_pic']['tmp_name'])){

				upload_lessons_user_pic('txt_lessons_user_pic', "primkey='$lessons_uptoken'");
                
                $lessons_custom_redir1=add_url_param ("lessons_uptoken", base64_encode($lessons_uptoken), "");
                $lessons_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$lessons_custom_redir1);
                $lessons_custom_redir3=add_url_param ("lessons_table_alert", "lessons_uploaded",$lessons_custom_redir2);
                
                ///echo magic_message($lessons_custom_redir1." -- ".$lessons_custom_redir2."--".$lessons_custom_redir3);
                
                $lessons_custom_redir=$lessons_custom_redir3;
                
               header('location:'.$lessons_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_lessons_);

          }
          }
          //===-====End upload lessons_user_pic  

			//drop lessons_user_pic image 
            
          if(isset($_GET["conf_deletelessons"]))
          {
          	$lessons_node=initialize_lessons();
          	if($lessons_node["user_pic"]!="")
            {
          	 unlink($lessons_node["user_pic"]);
            }
          }
          
          
    
      //== Start lessons delete record

      if(isset($_GET["deletelessons"]))
      {
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "super_delete_request","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_lessons_btn=magic_button_link("./".$current_file_url."?lessons_uptoken=".$_GET["lessons_uptoken"]."&conf_deletelessons&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_lessons_btn=magic_button_link("./".$current_file_url."?lessons_uptoken=".$_GET["lessons_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_lessons_btn." ".$cancel_del_lessons_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_lessons_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletelessons"]))
      {
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "super_delete_confirm","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $lessons_del_key_salt=initialize_lessons()["lesson_id"];
      mosy_sql_rollback("lessons", "primkey='$lessons_uptoken'", "DELETE");
      drop_lessons("primkey='$lessons_uptoken' and lesson_id='$lessons_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_lessons_);

      }
      }

      //== End lessons delete record  
    
       ///SELECT STRING FOR lessons============================
              
       if(isset($_POST["qlessons_btn"])){
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "qlessons_btn","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
            $current_lessons_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_lessons_current_url=$current_lessons_url_params.'?qlessons=';
            if (strpos($current_lessons_url_params, '?') !== false) {

                $clean_lessons_current_url=$current_lessons_url_params.'&qlessons=';

            }
            if (strpos($current_lessons_url_params, '?qlessons')) {

                $remove_lessons_old_token = substr($current_lessons_url_params, 0, strpos($current_lessons_url_params, "?qlessons"));

                $clean_lessons_current_url=$remove_lessons_old_token.'?qlessons=';

            }
            if(strpos($current_lessons_url_params, '&qlessons')) {

                $remove_lessons_old_token = substr($current_lessons_url_params, 0, strpos($current_lessons_url_params, "&qlessons"));

                $clean_lessons_current_url=$remove_lessons_old_token.'&qlessons=';

            }
        $qlessons_str=base64_encode($_POST["txt_lessons"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_lessons_current_url.($qlessons_str);
            } 

          }else{ 
             header('location:'.$clean_lessons_current_url.($qlessons_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_lessons_);

        }
        }
        $qlessons="";
		if(isset($_GET["lessons_mosyfilter"]) && isset($_GET["qlessons"])){
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "lessons_mosyfilter_n_query","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
         $qlessons=mmres(base64_decode($_GET["qlessons"]));
         
         $gft_lessons_where_query="(`lesson_id` LIKE '%".$qlessons."%' OR  `course_id` LIKE '%".$qlessons."%' OR  `school_id` LIKE '%".$qlessons."%' OR  `course_name` LIKE '%".$qlessons."%' OR  `school_name` LIKE '%".$qlessons."%' OR  `user_pic` LIKE '%".$qlessons."%' OR  `lesson_descr` LIKE '%".$qlessons."%' OR  `lesson_name` LIKE '%".$qlessons."%' OR  `lesson_cartegory` LIKE '%".$qlessons."%' OR  `lesson_preview` LIKE '%".$qlessons."%' OR  `lesson_video_url` LIKE '%".$qlessons."%' OR  `lesson_audio_url` LIKE '%".$qlessons."%' OR  `lesson_order` LIKE '%".$qlessons."%' OR  `lesson_type` LIKE '%".$qlessons."%' OR  `site_id` LIKE '%".$qlessons."%')";
         
         if($_GET["lessons_mosyfilter"]!=""){
         
         $mosyfilter_lessons_queries_str=(base64_decode($_GET["lessons_mosyfilter"]));
        
         $gft_lessons_where_query="(`lesson_id` LIKE '%".$qlessons."%' OR  `course_id` LIKE '%".$qlessons."%' OR  `school_id` LIKE '%".$qlessons."%' OR  `course_name` LIKE '%".$qlessons."%' OR  `school_name` LIKE '%".$qlessons."%' OR  `user_pic` LIKE '%".$qlessons."%' OR  `lesson_descr` LIKE '%".$qlessons."%' OR  `lesson_name` LIKE '%".$qlessons."%' OR  `lesson_cartegory` LIKE '%".$qlessons."%' OR  `lesson_preview` LIKE '%".$qlessons."%' OR  `lesson_video_url` LIKE '%".$qlessons."%' OR  `lesson_audio_url` LIKE '%".$qlessons."%' OR  `lesson_order` LIKE '%".$qlessons."%' OR  `lesson_type` LIKE '%".$qlessons."%' OR  `site_id` LIKE '%".$qlessons."%') AND ".$mosyfilter_lessons_queries_str."";
         
         }
         
		 $gft_lessons="WHERE ".$gft_lessons_where_query;
         
         $gft_lessons_and=$gft_lessons_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_lessons_);
        }
        }elseif(isset($_GET["qlessons"])){
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "get_qlessons","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
		 $qlessons=mmres(base64_decode($_GET["qlessons"]));
        
         $gft_lessons_where_query="(`lesson_id` LIKE '%".$qlessons."%' OR  `course_id` LIKE '%".$qlessons."%' OR  `school_id` LIKE '%".$qlessons."%' OR  `course_name` LIKE '%".$qlessons."%' OR  `school_name` LIKE '%".$qlessons."%' OR  `user_pic` LIKE '%".$qlessons."%' OR  `lesson_descr` LIKE '%".$qlessons."%' OR  `lesson_name` LIKE '%".$qlessons."%' OR  `lesson_cartegory` LIKE '%".$qlessons."%' OR  `lesson_preview` LIKE '%".$qlessons."%' OR  `lesson_video_url` LIKE '%".$qlessons."%' OR  `lesson_audio_url` LIKE '%".$qlessons."%' OR  `lesson_order` LIKE '%".$qlessons."%' OR  `lesson_type` LIKE '%".$qlessons."%' OR  `site_id` LIKE '%".$qlessons."%')";
         
         $gft_lessons="WHERE ".$gft_lessons_where_query;
         
         $gft_lessons_and=$gft_lessons_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_lessons_);

        }
        }elseif(isset($_GET["lessons_mosyfilter"])){
         $gwauthenticate_lessons_=gw_oauth("table", magic_current_url(), "lessons", "lessons_mosyfilter","");

         $gwauthenticate_lessons_json=json_decode($gwauthenticate_lessons_, true);
         	
          //echo $gwauthenticate_lessons_;

         if($gwauthenticate_lessons_json["response"]=="ok")
         {
         $gft_lessons_where_query="";
         $gft_lessons="";

         if($_GET["lessons_mosyfilter"]!=""){
          $gft_lessons_where_query=(base64_decode($_GET["lessons_mosyfilter"]));
          $gft_lessons="WHERE ".$gft_lessons_where_query;
         }
         
         
         $gft_lessons_and=$gft_lessons_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_lessons_);

        }
        }else{
         $gft_lessons="";
         $gft_lessons_and="";
         $gft_lessons_where_query="";
        }
       
    //************************************************* END  lessons OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section mosy_sql_roll_back
  //************************************************* START  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize mosy_sql_roll_back edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['mosy_sql_roll_back_table_alert']))
              	{	
                  if(isset($mosy_sql_roll_back_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$mosy_sql_roll_back_uptoken="";

		if(isset($_GET["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_GET["mosy_sql_roll_back_uptoken"]);
		}
        
        if(isset($_POST["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_POST["mosy_sql_roll_back_uptoken"]);
		}
        //
        
          $mosy_sql_roll_back_alias_name="MOSY SQL ROLL BACK";

          if(isset($mosy_sql_roll_back_alias))
          {
             $mosy_sql_roll_back_alias_name=$mosy_sql_roll_back_alias;

          }
          
        //get single data record query with $mosy_sql_roll_back_uptoken
        
        ///$mosy_sql_roll_back_node=get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
        
	
//************* START INSERT  mosy_sql_roll_back QUERY 
if(isset($_POST["mosy_sql_roll_back_insert_btn"])){
//------- begin mosy_sql_roll_back_arr_ins --> 
$mosy_sql_roll_back_arr_ins_=array(

"primkey"=>"NULL",
"roll_bk_key"=>magic_random_str(7),
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_ins -->


          
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {

              $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_arr_ins_;

              if(isset($mosy_sql_roll_back_ins_inputs))
              {
                $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_ins_inputs;	
              }

              if(empty($mosy_sql_roll_back_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name." request cannot be empty. Record not added");
              }else{
                $mosy_sql_roll_back_return_key=add_mosy_sql_roll_back($mosy_sql_roll_back_validated_ins_str);
                
                mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$mosy_sql_roll_back_mosy_rest_req_vars=http_build_query($_POST);
                echo $mosy_sql_roll_back_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $mosy_sql_roll_back_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
      
}
//************* END  mosy_sql_roll_back INSERT QUERY 	
	

//************* START mosy_sql_roll_back  UPDATE QUERY 
if(isset($_POST["mosy_sql_roll_back_update_btn"])){
//------- begin mosy_sql_roll_back_arr_updt --> 
$mosy_sql_roll_back_arr_updt_=array(
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_updt -->
                     
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
            $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_arr_updt_;

            if(isset($mosy_sql_roll_back_updt_inputs))
            {
              $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_updt_inputs;	
            }

            if(empty($mosy_sql_roll_back_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$mosy_sql_roll_back_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
            
              update_mosy_sql_roll_back($mosy_sql_roll_back_validated_updt_str, "primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_key_salt'");
				

			 mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $mosy_sql_roll_back_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $mosy_sql_roll_back_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $mosy_sql_roll_back_uptoken; 

                    } 

                  }else{ 

                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_uptoken), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_updated",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }

      

      
}
//************* END mosy_sql_roll_back  UPDATE QUERY 

    
    
      //== Start mosy_sql_roll_back delete record

      if(isset($_GET["deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_request","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"]."&conf_deletemosy_sql_roll_back&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_mosy_sql_roll_back_btn." ".$cancel_del_mosy_sql_roll_back_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_confirm","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $mosy_sql_roll_back_del_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
      mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "DELETE");
      drop_mosy_sql_roll_back("primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

      }
      }

      //== End mosy_sql_roll_back delete record  
    
       ///SELECT STRING FOR mosy_sql_roll_back============================
              
       if(isset($_POST["qmosy_sql_roll_back_btn"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qmosy_sql_roll_back_btn","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
            $current_mosy_sql_roll_back_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'?qmosy_sql_roll_back=';
            if (strpos($current_mosy_sql_roll_back_url_params, '?') !== false) {

                $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'&qmosy_sql_roll_back=';

            }
            if (strpos($current_mosy_sql_roll_back_url_params, '?qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "?qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'?qmosy_sql_roll_back=';

            }
            if(strpos($current_mosy_sql_roll_back_url_params, '&qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "&qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'&qmosy_sql_roll_back=';

            }
        $qmosy_sql_roll_back_str=base64_encode($_POST["txt_mosy_sql_roll_back"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str);
            } 

          }else{ 
             header('location:'.$clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }
        $qmosy_sql_roll_back="";
		if(isset($_GET["mosy_sql_roll_back_mosyfilter"]) && isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter_n_query","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
         
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
         
         $mosyfilter_mosy_sql_roll_back_queries_str=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%') AND ".$mosyfilter_mosy_sql_roll_back_queries_str."";
         
         }
         
		 $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
        }
        }elseif(isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "get_qmosy_sql_roll_back","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
		 $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }elseif(isset($_GET["mosy_sql_roll_back_mosyfilter"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $gft_mosy_sql_roll_back_where_query="";
         $gft_mosy_sql_roll_back="";

         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
          $gft_mosy_sql_roll_back_where_query=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
          $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         }
         
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }else{
         $gft_mosy_sql_roll_back="";
         $gft_mosy_sql_roll_back_and="";
         $gft_mosy_sql_roll_back_where_query="";
        }
       
    //************************************************* END  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section schools
  //************************************************* START  schools OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize schools edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['schools_table_alert']))
              	{	
                  if(isset($schools_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$schools_uptoken="";

		if(isset($_GET["schools_uptoken"]))
		{
		$schools_uptoken=base64_decode($_GET["schools_uptoken"]);
		}
        
        if(isset($_POST["schools_uptoken"]))
		{
		$schools_uptoken=base64_decode($_POST["schools_uptoken"]);
		}
        //
        
          $schools_alias_name="SCHOOLS";

          if(isset($schools_alias))
          {
             $schools_alias_name=$schools_alias;

          }
          
        //get single data record query with $schools_uptoken
        
        ///$schools_node=get_schools("*", "WHERE primkey='$schools_uptoken'", "r");
        
	
//************* START INSERT  schools QUERY 
if(isset($_POST["schools_insert_btn"])){
//------- begin schools_arr_ins --> 
$schools_arr_ins_=array(

"primkey"=>"NULL",
"school_id"=>magic_random_str(7),
"school_name"=>"?",
"user_pic"=>"?",
"school_descr"=>"?",
"school_url"=>"?",
"site_id"=>"?"

);
//===-- End schools_arr_ins -->


          
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "insert","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {

              $schools_validated_ins_str=$schools_arr_ins_;

              if(isset($schools_ins_inputs))
              {
                $schools_validated_ins_str=$schools_ins_inputs;	
              }

              if(empty($schools_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$schools_alias_name." request cannot be empty. Record not added");
              }else{
                $schools_return_key=add_schools($schools_validated_ins_str);
                
                mosy_sql_rollback("schools", "primkey='$schools_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_schools_user_pic']['tmp_name']))
                {
                
                 upload_schools_user_pic('txt_schools_user_pic', "primkey='$schools_return_key'");
                 
				}
                
         

				if($run_mosy_api=="yes")
                {
				$schools_mosy_rest_req_vars=http_build_query($_POST);
                echo $schools_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $schools_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $schools_return_key; 

                      } 

                    }else{ 

                                    
                $schools_custom_redir1=add_url_param ("schools_uptoken", base64_encode($schools_return_key), "");
                $schools_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$schools_custom_redir1);
                $schools_custom_redir3=add_url_param ("schools_table_alert", "schools_added",$schools_custom_redir2);
                
                ///echo magic_message($schools_custom_redir1." -- ".$schools_custom_redir2."--".$schools_custom_redir3);
                
                $schools_custom_redir=$schools_custom_redir3;
                
               header('location:'.$schools_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_schools_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");
         
         }
      
}
//************* END  schools INSERT QUERY 	
	

//************* START schools  UPDATE QUERY 
if(isset($_POST["schools_update_btn"])){
//------- begin schools_arr_updt --> 
$schools_arr_updt_=array(
"school_name"=>"?",
"user_pic"=>"?",
"school_descr"=>"?",
"school_url"=>"?",
"site_id"=>"?"

);
//===-- End schools_arr_updt -->
                     
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "update","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
         
            $schools_validated_updt_str=$schools_arr_updt_;

            if(isset($schools_updt_inputs))
            {
              $schools_validated_updt_str=$schools_updt_inputs;	
            }

            if(empty($schools_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$schools_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$schools_key_salt=initialize_schools()["school_id"];
            
              update_schools($schools_validated_updt_str, "primkey='$schools_uptoken' and school_id='$schools_key_salt'");
				
         
                if(!empty($_FILES['txt_schools_user_pic']['tmp_name']))
                {
                
                 upload_schools_user_pic('txt_schools_user_pic', "primkey='$schools_uptoken'");
                 
				}

			 mosy_sql_rollback("schools", "primkey='$schools_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $schools_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $schools_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $schools_uptoken; 

                    } 

                  }else{ 

                $schools_custom_redir1=add_url_param ("schools_uptoken", base64_encode($schools_uptoken), "");
                $schools_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$schools_custom_redir1);
                $schools_custom_redir3=add_url_param ("schools_table_alert", "schools_updated",$schools_custom_redir2);
                
                ///echo magic_message($schools_custom_redir1." -- ".$schools_custom_redir2."--".$schools_custom_redir3);
                
                $schools_custom_redir=$schools_custom_redir3;
                
               header('location:'.$schools_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_schools_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_schools_)."");
         
         }

      

      
}
//************* END schools  UPDATE QUERY 

    

          //===-====Start upload schools_user_pic 
          if(isset($_POST["btn_upload_schools_user_pic"]))
          {
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "upload_schools_user_pic","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_schools_user_pic']['tmp_name'])){

				upload_schools_user_pic('txt_schools_user_pic', "primkey='$schools_uptoken'");
                
                $schools_custom_redir1=add_url_param ("schools_uptoken", base64_encode($schools_uptoken), "");
                $schools_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$schools_custom_redir1);
                $schools_custom_redir3=add_url_param ("schools_table_alert", "schools_uploaded",$schools_custom_redir2);
                
                ///echo magic_message($schools_custom_redir1." -- ".$schools_custom_redir2."--".$schools_custom_redir3);
                
                $schools_custom_redir=$schools_custom_redir3;
                
               header('location:'.$schools_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_schools_);

          }
          }
          //===-====End upload schools_user_pic  

			//drop schools_user_pic image 
            
          if(isset($_GET["conf_deleteschools"]))
          {
          	$schools_node=initialize_schools();
          	if($schools_node["user_pic"]!="")
            {
          	 unlink($schools_node["user_pic"]);
            }
          }
          
          
    
      //== Start schools delete record

      if(isset($_GET["deleteschools"]))
      {
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "super_delete_request","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_schools_btn=magic_button_link("./".$current_file_url."?schools_uptoken=".$_GET["schools_uptoken"]."&conf_deleteschools&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_schools_btn=magic_button_link("./".$current_file_url."?schools_uptoken=".$_GET["schools_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_schools_btn." ".$cancel_del_schools_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_schools_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteschools"]))
      {
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "super_delete_confirm","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $schools_del_key_salt=initialize_schools()["school_id"];
      mosy_sql_rollback("schools", "primkey='$schools_uptoken'", "DELETE");
      drop_schools("primkey='$schools_uptoken' and school_id='$schools_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_schools_);

      }
      }

      //== End schools delete record  
    
       ///SELECT STRING FOR schools============================
              
       if(isset($_POST["qschools_btn"])){
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "qschools_btn","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
            $current_schools_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_schools_current_url=$current_schools_url_params.'?qschools=';
            if (strpos($current_schools_url_params, '?') !== false) {

                $clean_schools_current_url=$current_schools_url_params.'&qschools=';

            }
            if (strpos($current_schools_url_params, '?qschools')) {

                $remove_schools_old_token = substr($current_schools_url_params, 0, strpos($current_schools_url_params, "?qschools"));

                $clean_schools_current_url=$remove_schools_old_token.'?qschools=';

            }
            if(strpos($current_schools_url_params, '&qschools')) {

                $remove_schools_old_token = substr($current_schools_url_params, 0, strpos($current_schools_url_params, "&qschools"));

                $clean_schools_current_url=$remove_schools_old_token.'&qschools=';

            }
        $qschools_str=base64_encode($_POST["txt_schools"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_schools_current_url.($qschools_str);
            } 

          }else{ 
             header('location:'.$clean_schools_current_url.($qschools_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_schools_);

        }
        }
        $qschools="";
		if(isset($_GET["schools_mosyfilter"]) && isset($_GET["qschools"])){
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "schools_mosyfilter_n_query","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
         $qschools=mmres(base64_decode($_GET["qschools"]));
         
         $gft_schools_where_query="(`school_id` LIKE '%".$qschools."%' OR  `school_name` LIKE '%".$qschools."%' OR  `user_pic` LIKE '%".$qschools."%' OR  `school_descr` LIKE '%".$qschools."%' OR  `school_url` LIKE '%".$qschools."%' OR  `site_id` LIKE '%".$qschools."%')";
         
         if($_GET["schools_mosyfilter"]!=""){
         
         $mosyfilter_schools_queries_str=(base64_decode($_GET["schools_mosyfilter"]));
        
         $gft_schools_where_query="(`school_id` LIKE '%".$qschools."%' OR  `school_name` LIKE '%".$qschools."%' OR  `user_pic` LIKE '%".$qschools."%' OR  `school_descr` LIKE '%".$qschools."%' OR  `school_url` LIKE '%".$qschools."%' OR  `site_id` LIKE '%".$qschools."%') AND ".$mosyfilter_schools_queries_str."";
         
         }
         
		 $gft_schools="WHERE ".$gft_schools_where_query;
         
         $gft_schools_and=$gft_schools_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_schools_);
        }
        }elseif(isset($_GET["qschools"])){
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "get_qschools","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
		 $qschools=mmres(base64_decode($_GET["qschools"]));
        
         $gft_schools_where_query="(`school_id` LIKE '%".$qschools."%' OR  `school_name` LIKE '%".$qschools."%' OR  `user_pic` LIKE '%".$qschools."%' OR  `school_descr` LIKE '%".$qschools."%' OR  `school_url` LIKE '%".$qschools."%' OR  `site_id` LIKE '%".$qschools."%')";
         
         $gft_schools="WHERE ".$gft_schools_where_query;
         
         $gft_schools_and=$gft_schools_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_schools_);

        }
        }elseif(isset($_GET["schools_mosyfilter"])){
         $gwauthenticate_schools_=gw_oauth("table", magic_current_url(), "schools", "schools_mosyfilter","");

         $gwauthenticate_schools_json=json_decode($gwauthenticate_schools_, true);
         	
          //echo $gwauthenticate_schools_;

         if($gwauthenticate_schools_json["response"]=="ok")
         {
         $gft_schools_where_query="";
         $gft_schools="";

         if($_GET["schools_mosyfilter"]!=""){
          $gft_schools_where_query=(base64_decode($_GET["schools_mosyfilter"]));
          $gft_schools="WHERE ".$gft_schools_where_query;
         }
         
         
         $gft_schools_and=$gft_schools_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_schools_);

        }
        }else{
         $gft_schools="";
         $gft_schools_and="";
         $gft_schools_where_query="";
        }
       
    //************************************************* END  schools OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section students
  //************************************************* START  students OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize students edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['students_table_alert']))
              	{	
                  if(isset($students_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$students_uptoken="";

		if(isset($_GET["students_uptoken"]))
		{
		$students_uptoken=base64_decode($_GET["students_uptoken"]);
		}
        
        if(isset($_POST["students_uptoken"]))
		{
		$students_uptoken=base64_decode($_POST["students_uptoken"]);
		}
        //
        
          $students_alias_name="STUDENTS";

          if(isset($students_alias))
          {
             $students_alias_name=$students_alias;

          }
          
        //get single data record query with $students_uptoken
        
        ///$students_node=get_students("*", "WHERE primkey='$students_uptoken'", "r");
        
	
//************* START INSERT  students QUERY 
if(isset($_POST["students_insert_btn"])){
//------- begin students_arr_ins --> 
$students_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End students_arr_ins -->


          
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "insert","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {

              $students_validated_ins_str=$students_arr_ins_;

              if(isset($students_ins_inputs))
              {
                $students_validated_ins_str=$students_ins_inputs;	
              }

              if(empty($students_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$students_alias_name." request cannot be empty. Record not added");
              }else{
                $students_return_key=add_students($students_validated_ins_str);
                
                mosy_sql_rollback("students", "primkey='$students_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_students_user_pic']['tmp_name']))
                {
                
                 upload_students_user_pic('txt_students_user_pic', "primkey='$students_return_key'");
                 
				}
                
         

				if($run_mosy_api=="yes")
                {
				$students_mosy_rest_req_vars=http_build_query($_POST);
                echo $students_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $students_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $students_return_key; 

                      } 

                    }else{ 

                                    
                $students_custom_redir1=add_url_param ("students_uptoken", base64_encode($students_return_key), "");
                $students_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$students_custom_redir1);
                $students_custom_redir3=add_url_param ("students_table_alert", "students_added",$students_custom_redir2);
                
                ///echo magic_message($students_custom_redir1." -- ".$students_custom_redir2."--".$students_custom_redir3);
                
                $students_custom_redir=$students_custom_redir3;
                
               header('location:'.$students_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_students_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");
         
         }
      
}
//************* END  students INSERT QUERY 	
	

//************* START students  UPDATE QUERY 
if(isset($_POST["students_update_btn"])){
//------- begin students_arr_updt --> 
$students_arr_updt_=array(
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End students_arr_updt -->
                     
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "update","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
         
            $students_validated_updt_str=$students_arr_updt_;

            if(isset($students_updt_inputs))
            {
              $students_validated_updt_str=$students_updt_inputs;	
            }

            if(empty($students_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$students_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$students_key_salt=initialize_students()["user_id"];
            
              update_students($students_validated_updt_str, "primkey='$students_uptoken' and user_id='$students_key_salt'");
				
         
                if(!empty($_FILES['txt_students_user_pic']['tmp_name']))
                {
                
                 upload_students_user_pic('txt_students_user_pic', "primkey='$students_uptoken'");
                 
				}

			 mosy_sql_rollback("students", "primkey='$students_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $students_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $students_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $students_uptoken; 

                    } 

                  }else{ 

                $students_custom_redir1=add_url_param ("students_uptoken", base64_encode($students_uptoken), "");
                $students_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$students_custom_redir1);
                $students_custom_redir3=add_url_param ("students_table_alert", "students_updated",$students_custom_redir2);
                
                ///echo magic_message($students_custom_redir1." -- ".$students_custom_redir2."--".$students_custom_redir3);
                
                $students_custom_redir=$students_custom_redir3;
                
               header('location:'.$students_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_students_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_students_)."");
         
         }

      

      
}
//************* END students  UPDATE QUERY 

    

          //===-====Start upload students_user_pic 
          if(isset($_POST["btn_upload_students_user_pic"]))
          {
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "upload_students_user_pic","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_students_user_pic']['tmp_name'])){

				upload_students_user_pic('txt_students_user_pic', "primkey='$students_uptoken'");
                
                $students_custom_redir1=add_url_param ("students_uptoken", base64_encode($students_uptoken), "");
                $students_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$students_custom_redir1);
                $students_custom_redir3=add_url_param ("students_table_alert", "students_uploaded",$students_custom_redir2);
                
                ///echo magic_message($students_custom_redir1." -- ".$students_custom_redir2."--".$students_custom_redir3);
                
                $students_custom_redir=$students_custom_redir3;
                
               header('location:'.$students_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_students_);

          }
          }
          //===-====End upload students_user_pic  

			//drop students_user_pic image 
            
          if(isset($_GET["conf_deletestudents"]))
          {
          	$students_node=initialize_students();
          	if($students_node["user_pic"]!="")
            {
          	 unlink($students_node["user_pic"]);
            }
          }
          
          
    
      //== Start students delete record

      if(isset($_GET["deletestudents"]))
      {
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "super_delete_request","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_students_btn=magic_button_link("./".$current_file_url."?students_uptoken=".$_GET["students_uptoken"]."&conf_deletestudents&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_students_btn=magic_button_link("./".$current_file_url."?students_uptoken=".$_GET["students_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_students_btn." ".$cancel_del_students_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_students_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletestudents"]))
      {
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "super_delete_confirm","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $students_del_key_salt=initialize_students()["user_id"];
      mosy_sql_rollback("students", "primkey='$students_uptoken'", "DELETE");
      drop_students("primkey='$students_uptoken' and user_id='$students_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_students_);

      }
      }

      //== End students delete record  
    
       ///SELECT STRING FOR students============================
              
       if(isset($_POST["qstudents_btn"])){
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "qstudents_btn","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
            $current_students_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_students_current_url=$current_students_url_params.'?qstudents=';
            if (strpos($current_students_url_params, '?') !== false) {

                $clean_students_current_url=$current_students_url_params.'&qstudents=';

            }
            if (strpos($current_students_url_params, '?qstudents')) {

                $remove_students_old_token = substr($current_students_url_params, 0, strpos($current_students_url_params, "?qstudents"));

                $clean_students_current_url=$remove_students_old_token.'?qstudents=';

            }
            if(strpos($current_students_url_params, '&qstudents')) {

                $remove_students_old_token = substr($current_students_url_params, 0, strpos($current_students_url_params, "&qstudents"));

                $clean_students_current_url=$remove_students_old_token.'&qstudents=';

            }
        $qstudents_str=base64_encode($_POST["txt_students"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_students_current_url.($qstudents_str);
            } 

          }else{ 
             header('location:'.$clean_students_current_url.($qstudents_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_students_);

        }
        }
        $qstudents="";
		if(isset($_GET["students_mosyfilter"]) && isset($_GET["qstudents"])){
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "students_mosyfilter_n_query","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
         $qstudents=mmres(base64_decode($_GET["qstudents"]));
         
         $gft_students_where_query="(`user_id` LIKE '%".$qstudents."%' OR  `name` LIKE '%".$qstudents."%' OR  `email` LIKE '%".$qstudents."%' OR  `tel` LIKE '%".$qstudents."%' OR  `login_password` LIKE '%".$qstudents."%' OR  `ref_id` LIKE '%".$qstudents."%' OR  `regdate` LIKE '%".$qstudents."%' OR  `user_no` LIKE '%".$qstudents."%' OR  `user_pic` LIKE '%".$qstudents."%' OR  `user_gender` LIKE '%".$qstudents."%' OR  `last_seen` LIKE '%".$qstudents."%' OR  `about` LIKE '%".$qstudents."%')";
         
         if($_GET["students_mosyfilter"]!=""){
         
         $mosyfilter_students_queries_str=(base64_decode($_GET["students_mosyfilter"]));
        
         $gft_students_where_query="(`user_id` LIKE '%".$qstudents."%' OR  `name` LIKE '%".$qstudents."%' OR  `email` LIKE '%".$qstudents."%' OR  `tel` LIKE '%".$qstudents."%' OR  `login_password` LIKE '%".$qstudents."%' OR  `ref_id` LIKE '%".$qstudents."%' OR  `regdate` LIKE '%".$qstudents."%' OR  `user_no` LIKE '%".$qstudents."%' OR  `user_pic` LIKE '%".$qstudents."%' OR  `user_gender` LIKE '%".$qstudents."%' OR  `last_seen` LIKE '%".$qstudents."%' OR  `about` LIKE '%".$qstudents."%') AND ".$mosyfilter_students_queries_str."";
         
         }
         
		 $gft_students="WHERE ".$gft_students_where_query;
         
         $gft_students_and=$gft_students_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_students_);
        }
        }elseif(isset($_GET["qstudents"])){
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "get_qstudents","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
		 $qstudents=mmres(base64_decode($_GET["qstudents"]));
        
         $gft_students_where_query="(`user_id` LIKE '%".$qstudents."%' OR  `name` LIKE '%".$qstudents."%' OR  `email` LIKE '%".$qstudents."%' OR  `tel` LIKE '%".$qstudents."%' OR  `login_password` LIKE '%".$qstudents."%' OR  `ref_id` LIKE '%".$qstudents."%' OR  `regdate` LIKE '%".$qstudents."%' OR  `user_no` LIKE '%".$qstudents."%' OR  `user_pic` LIKE '%".$qstudents."%' OR  `user_gender` LIKE '%".$qstudents."%' OR  `last_seen` LIKE '%".$qstudents."%' OR  `about` LIKE '%".$qstudents."%')";
         
         $gft_students="WHERE ".$gft_students_where_query;
         
         $gft_students_and=$gft_students_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_students_);

        }
        }elseif(isset($_GET["students_mosyfilter"])){
         $gwauthenticate_students_=gw_oauth("table", magic_current_url(), "students", "students_mosyfilter","");

         $gwauthenticate_students_json=json_decode($gwauthenticate_students_, true);
         	
          //echo $gwauthenticate_students_;

         if($gwauthenticate_students_json["response"]=="ok")
         {
         $gft_students_where_query="";
         $gft_students="";

         if($_GET["students_mosyfilter"]!=""){
          $gft_students_where_query=(base64_decode($_GET["students_mosyfilter"]));
          $gft_students="WHERE ".$gft_students_where_query;
         }
         
         
         $gft_students_and=$gft_students_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_students_);

        }
        }else{
         $gft_students="";
         $gft_students_and="";
         $gft_students_where_query="";
        }
       
    //************************************************* END  students OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section transactions_table
  //************************************************* START  transactions_table OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize transactions_table edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['transactions_table_table_alert']))
              	{	
                  if(isset($transactions_table_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$transactions_table_uptoken="";

		if(isset($_GET["transactions_table_uptoken"]))
		{
		$transactions_table_uptoken=base64_decode($_GET["transactions_table_uptoken"]);
		}
        
        if(isset($_POST["transactions_table_uptoken"]))
		{
		$transactions_table_uptoken=base64_decode($_POST["transactions_table_uptoken"]);
		}
        //
        
          $transactions_table_alias_name="TRANSACTIONS TABLE";

          if(isset($transactions_table_alias))
          {
             $transactions_table_alias_name=$transactions_table_alias;

          }
          
        //get single data record query with $transactions_table_uptoken
        
        ///$transactions_table_node=get_transactions_table("*", "WHERE primkey='$transactions_table_uptoken'", "r");
        
	
//************* START INSERT  transactions_table QUERY 
if(isset($_POST["transactions_table_insert_btn"])){
//------- begin transactions_table_arr_ins --> 
$transactions_table_arr_ins_=array(

"primkey"=>"NULL",
"TransactionType"=>magic_random_str(7),
"TransID"=>"?",
"TransTime"=>"?",
"TransAmount"=>"?",
"BusinessShortCode"=>"?",
"BillRefNumber"=>"?",
"InvoiceNumber"=>"?",
"OrgAccountBalance"=>"?",
"ThirdPartyTransID"=>"?",
"MSISDN"=>"?",
"FirstName"=>"?",
"MiddleName"=>"?",
"LastName"=>"?"

);
//===-- End transactions_table_arr_ins -->


          
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "insert","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {

              $transactions_table_validated_ins_str=$transactions_table_arr_ins_;

              if(isset($transactions_table_ins_inputs))
              {
                $transactions_table_validated_ins_str=$transactions_table_ins_inputs;	
              }

              if(empty($transactions_table_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$transactions_table_alias_name." request cannot be empty. Record not added");
              }else{
                $transactions_table_return_key=add_transactions_table($transactions_table_validated_ins_str);
                
                mosy_sql_rollback("transactions_table", "primkey='$transactions_table_return_key'", "INSERT");
					

				if($run_mosy_api=="yes")
                {
				$transactions_table_mosy_rest_req_vars=http_build_query($_POST);
                echo $transactions_table_mosy_rest_req_vars;
 				echo magic_post_curl($mosy_rest_url, "", "", $transactions_table_mosy_rest_req_vars, "POST");
                
                }
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $transactions_table_return_key; 

                      } 

                    }else{ 

                                    
                $transactions_table_custom_redir1=add_url_param ("transactions_table_uptoken", base64_encode($transactions_table_return_key), "");
                $transactions_table_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$transactions_table_custom_redir1);
                $transactions_table_custom_redir3=add_url_param ("transactions_table_table_alert", "transactions_table_added",$transactions_table_custom_redir2);
                
                ///echo magic_message($transactions_table_custom_redir1." -- ".$transactions_table_custom_redir2."--".$transactions_table_custom_redir3);
                
                $transactions_table_custom_redir=$transactions_table_custom_redir3;
                
               header('location:'.$transactions_table_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_transactions_table_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");
         
         }
      
}
//************* END  transactions_table INSERT QUERY 	
	

//************* START transactions_table  UPDATE QUERY 
if(isset($_POST["transactions_table_update_btn"])){
//------- begin transactions_table_arr_updt --> 
$transactions_table_arr_updt_=array(
"TransID"=>"?",
"TransTime"=>"?",
"TransAmount"=>"?",
"BusinessShortCode"=>"?",
"BillRefNumber"=>"?",
"InvoiceNumber"=>"?",
"OrgAccountBalance"=>"?",
"ThirdPartyTransID"=>"?",
"MSISDN"=>"?",
"FirstName"=>"?",
"MiddleName"=>"?",
"LastName"=>"?"

);
//===-- End transactions_table_arr_updt -->
                     
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "update","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
         
            $transactions_table_validated_updt_str=$transactions_table_arr_updt_;

            if(isset($transactions_table_updt_inputs))
            {
              $transactions_table_validated_updt_str=$transactions_table_updt_inputs;	
            }

            if(empty($transactions_table_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$transactions_table_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$transactions_table_key_salt=initialize_transactions_table()["TransactionType"];
            
              update_transactions_table($transactions_table_validated_updt_str, "primkey='$transactions_table_uptoken' and TransactionType='$transactions_table_key_salt'");
				

			 mosy_sql_rollback("transactions_table", "primkey='$transactions_table_uptoken'", "UPDATE");
             
				if($run_mosy_api=="yes")
                {
				 $transactions_table_mosy_rest_req_vars=http_build_query($_POST);
                
 				 echo magic_post_curl($mosy_rest_url, "", "", $transactions_table_mosy_rest_req_vars, "POST");
                
                }
             
              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $transactions_table_uptoken; 

                    } 

                  }else{ 

                $transactions_table_custom_redir1=add_url_param ("transactions_table_uptoken", base64_encode($transactions_table_uptoken), "");
                $transactions_table_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$transactions_table_custom_redir1);
                $transactions_table_custom_redir3=add_url_param ("transactions_table_table_alert", "transactions_table_updated",$transactions_table_custom_redir2);
                
                ///echo magic_message($transactions_table_custom_redir1." -- ".$transactions_table_custom_redir2."--".$transactions_table_custom_redir3);
                
                $transactions_table_custom_redir=$transactions_table_custom_redir3;
                
               header('location:'.$transactions_table_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_transactions_table_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_transactions_table_)."");
         
         }

      

      
}
//************* END transactions_table  UPDATE QUERY 

    
    
      //== Start transactions_table delete record

      if(isset($_GET["deletetransactions_table"]))
      {
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "super_delete_request","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_transactions_table_btn=magic_button_link("./".$current_file_url."?transactions_table_uptoken=".$_GET["transactions_table_uptoken"]."&conf_deletetransactions_table&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_transactions_table_btn=magic_button_link("./".$current_file_url."?transactions_table_uptoken=".$_GET["transactions_table_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_transactions_table_btn." ".$cancel_del_transactions_table_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_transactions_table_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletetransactions_table"]))
      {
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "super_delete_confirm","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $transactions_table_del_key_salt=initialize_transactions_table()["TransactionType"];
      mosy_sql_rollback("transactions_table", "primkey='$transactions_table_uptoken'", "DELETE");
      drop_transactions_table("primkey='$transactions_table_uptoken' and TransactionType='$transactions_table_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_transactions_table_);

      }
      }

      //== End transactions_table delete record  
    
       ///SELECT STRING FOR transactions_table============================
              
       if(isset($_POST["qtransactions_table_btn"])){
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "qtransactions_table_btn","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
            $current_transactions_table_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_transactions_table_current_url=$current_transactions_table_url_params.'?qtransactions_table=';
            if (strpos($current_transactions_table_url_params, '?') !== false) {

                $clean_transactions_table_current_url=$current_transactions_table_url_params.'&qtransactions_table=';

            }
            if (strpos($current_transactions_table_url_params, '?qtransactions_table')) {

                $remove_transactions_table_old_token = substr($current_transactions_table_url_params, 0, strpos($current_transactions_table_url_params, "?qtransactions_table"));

                $clean_transactions_table_current_url=$remove_transactions_table_old_token.'?qtransactions_table=';

            }
            if(strpos($current_transactions_table_url_params, '&qtransactions_table')) {

                $remove_transactions_table_old_token = substr($current_transactions_table_url_params, 0, strpos($current_transactions_table_url_params, "&qtransactions_table"));

                $clean_transactions_table_current_url=$remove_transactions_table_old_token.'&qtransactions_table=';

            }
        $qtransactions_table_str=base64_encode($_POST["txt_transactions_table"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_transactions_table_current_url.($qtransactions_table_str);
            } 

          }else{ 
             header('location:'.$clean_transactions_table_current_url.($qtransactions_table_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_transactions_table_);

        }
        }
        $qtransactions_table="";
		if(isset($_GET["transactions_table_mosyfilter"]) && isset($_GET["qtransactions_table"])){
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "transactions_table_mosyfilter_n_query","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
         $qtransactions_table=mmres(base64_decode($_GET["qtransactions_table"]));
         
         $gft_transactions_table_where_query="(`TransactionType` LIKE '%".$qtransactions_table."%' OR  `TransID` LIKE '%".$qtransactions_table."%' OR  `TransTime` LIKE '%".$qtransactions_table."%' OR  `TransAmount` LIKE '%".$qtransactions_table."%' OR  `BusinessShortCode` LIKE '%".$qtransactions_table."%' OR  `BillRefNumber` LIKE '%".$qtransactions_table."%' OR  `InvoiceNumber` LIKE '%".$qtransactions_table."%' OR  `OrgAccountBalance` LIKE '%".$qtransactions_table."%' OR  `ThirdPartyTransID` LIKE '%".$qtransactions_table."%' OR  `MSISDN` LIKE '%".$qtransactions_table."%' OR  `FirstName` LIKE '%".$qtransactions_table."%' OR  `MiddleName` LIKE '%".$qtransactions_table."%' OR  `LastName` LIKE '%".$qtransactions_table."%')";
         
         if($_GET["transactions_table_mosyfilter"]!=""){
         
         $mosyfilter_transactions_table_queries_str=(base64_decode($_GET["transactions_table_mosyfilter"]));
        
         $gft_transactions_table_where_query="(`TransactionType` LIKE '%".$qtransactions_table."%' OR  `TransID` LIKE '%".$qtransactions_table."%' OR  `TransTime` LIKE '%".$qtransactions_table."%' OR  `TransAmount` LIKE '%".$qtransactions_table."%' OR  `BusinessShortCode` LIKE '%".$qtransactions_table."%' OR  `BillRefNumber` LIKE '%".$qtransactions_table."%' OR  `InvoiceNumber` LIKE '%".$qtransactions_table."%' OR  `OrgAccountBalance` LIKE '%".$qtransactions_table."%' OR  `ThirdPartyTransID` LIKE '%".$qtransactions_table."%' OR  `MSISDN` LIKE '%".$qtransactions_table."%' OR  `FirstName` LIKE '%".$qtransactions_table."%' OR  `MiddleName` LIKE '%".$qtransactions_table."%' OR  `LastName` LIKE '%".$qtransactions_table."%') AND ".$mosyfilter_transactions_table_queries_str."";
         
         }
         
		 $gft_transactions_table="WHERE ".$gft_transactions_table_where_query;
         
         $gft_transactions_table_and=$gft_transactions_table_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_transactions_table_);
        }
        }elseif(isset($_GET["qtransactions_table"])){
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "get_qtransactions_table","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
		 $qtransactions_table=mmres(base64_decode($_GET["qtransactions_table"]));
        
         $gft_transactions_table_where_query="(`TransactionType` LIKE '%".$qtransactions_table."%' OR  `TransID` LIKE '%".$qtransactions_table."%' OR  `TransTime` LIKE '%".$qtransactions_table."%' OR  `TransAmount` LIKE '%".$qtransactions_table."%' OR  `BusinessShortCode` LIKE '%".$qtransactions_table."%' OR  `BillRefNumber` LIKE '%".$qtransactions_table."%' OR  `InvoiceNumber` LIKE '%".$qtransactions_table."%' OR  `OrgAccountBalance` LIKE '%".$qtransactions_table."%' OR  `ThirdPartyTransID` LIKE '%".$qtransactions_table."%' OR  `MSISDN` LIKE '%".$qtransactions_table."%' OR  `FirstName` LIKE '%".$qtransactions_table."%' OR  `MiddleName` LIKE '%".$qtransactions_table."%' OR  `LastName` LIKE '%".$qtransactions_table."%')";
         
         $gft_transactions_table="WHERE ".$gft_transactions_table_where_query;
         
         $gft_transactions_table_and=$gft_transactions_table_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_transactions_table_);

        }
        }elseif(isset($_GET["transactions_table_mosyfilter"])){
         $gwauthenticate_transactions_table_=gw_oauth("table", magic_current_url(), "transactions_table", "transactions_table_mosyfilter","");

         $gwauthenticate_transactions_table_json=json_decode($gwauthenticate_transactions_table_, true);
         	
          //echo $gwauthenticate_transactions_table_;

         if($gwauthenticate_transactions_table_json["response"]=="ok")
         {
         $gft_transactions_table_where_query="";
         $gft_transactions_table="";

         if($_GET["transactions_table_mosyfilter"]!=""){
          $gft_transactions_table_where_query=(base64_decode($_GET["transactions_table_mosyfilter"]));
          $gft_transactions_table="WHERE ".$gft_transactions_table_where_query;
         }
         
         
         $gft_transactions_table_and=$gft_transactions_table_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_transactions_table_);

        }
        }else{
         $gft_transactions_table="";
         $gft_transactions_table_and="";
         $gft_transactions_table_where_query="";
        }
       
    //************************************************* END  transactions_table OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  

//<--ncgh-->

?>