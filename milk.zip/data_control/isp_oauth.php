<?php 


//=== start Log in to rm_users Login Script query 

if(isset($_POST["btn_login"]))
{
$password=mysqli_real_escape_string($mysqliconn, $_POST["txt_password"]);
$user_email=mysqli_real_escape_string($mysqliconn, $_POST["txt_username"]);

$Log_in_to_rm_users_query=mysqli_query($mysqliconn, "SELECT * FROM `$isppro`.`rm_users`  WHERE `username`='$user_email' AND `admin_password`='$password'");

$Log_in_to_rm_users_r=mysqli_fetch_array($Log_in_to_rm_users_query);

if(!empty($Log_in_to_rm_users_r['username']) && !empty($Log_in_to_rm_users_r['admin_password']))
{

$_SESSION['session_isp_logged']=TRUE;
$_SESSION['session_isp_logged_username']=$Log_in_to_rm_users_r['username'];
$_SESSION['session_isp_logged_firstname']=$Log_in_to_rm_users_r['firstname'];
$_SESSION['session_isp_logged_username']=$Log_in_to_rm_users_r['username'];

if(isset($_GET['ref_url_go_to'])){

	$ref_url_go_to=base64_decode($_GET['ref_url_go_to']);

	header("location:".$ref_url_go_to."");


}else{

	header("location:./splash.php");

}

}else{

	echo magic_message("Wrong password or user name please try again");
}

}
//=== End Log in to rm_users Login Script query

//=========request password
if(isset($_POST['requestnewpass_btn'])){

$membusername=$_POST['email_user'];

$cpsreset_query1=mysqli_query($mysqliconn,"SELECT * FROM `$isppro`.`rm_users`  WHERE username='$membusername'");

$cpsreset_res1=mysqli_fetch_array($cpsreset_query1);

$cpsreset_query=mysqli_query($mysqliconn,"SELECT * FROM `$isppro`.`rm_users`   WHERE username='$membusername'");

$cpsreset_res=mysqli_num_rows($cpsreset_query);
if($cpsreset_res==1){

$showname="ClearPhrases Reset Pssword"; 
$tel="0710766390"; 

$from_email="clearphrases@gmail.com";

$to_email=$_POST['email_user'];
$client_names=$cpsreset_res1['firstname'];


$path1="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
//echo $path1;

$msgtosend='Hello You requested a password request. Follow this link to create a new password.<br /><br />
<a href="'.$path1.'?reset_token='.base64_encode($cpsreset_res1['username']).'">Reset Password</a><br /><br />';

$message=$msgtosend;
$subject="Password reset Request";
$actlink="http://www.clearphrases.com";


$replypath="http://www.clearphrases.com";


$messvars = "sendemailapi=send&mailsubj=".$subject."&showname=".$showname."&namesarray=".$client_names."&mailmessage=".$message."&sendto=".$to_email."&repmail=".$from_email."&actlink=".$actlink."&replypath=".$replypath."&imgreq=";

//echo $msgtosend;
$agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)";
$ch = curl_init( "http://clearphrases.com/clearphrases_apis/comms/emailsender.php");
curl_setopt( $ch, CURLOPT_POST, 1);

curl_setopt( $ch, CURLOPT_POSTFIELDS, $messvars);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
$sendsmsres = curl_exec( $ch );

echo magic_message("We have sent you a reset password email. Follow that link to reset your password");




}else{
echo magic_message("Sorry that email does not exist. Please Try Again");
}
}
//===================reset password request

////===========reset pass=============
if(isset($_GET['reset_token'])){

$memberkey=base64_decode($_GET['reset_token']);


$cpsresetoken_query=mysqli_query($mysqliconn,"SELECT * FROM `$isppro`.`rm_users`  WHERE username='$memberkey'");

$cpsresetoken_res=mysqli_num_rows($cpsresetoken_query);


}
if(isset($_POST['changepass_btn'])){
$memberkey=base64_decode($_GET['reset_token']);

$cpsresetoken_query1=mysqli_query($mysqliconn,"SELECT * FROM `$isppro`.`rm_users`  WHERE username='$memberkey'");

$cpsresetoken_res1=mysqli_fetch_array($cpsresetoken_query1);

$foundresetmail=$cpsresetoken_res1['username'];
$resetpass1=mysqli_real_escape_string($mysqliconn,$_POST['newpass_user']);
$resetpass2=mysqli_real_escape_string($mysqliconn,$_POST['confirmnewpass_user']);
if($resetpass1!=$resetpass2){

echo magic_message("Password Do Not match!!");
}else{

mysqli_query($mysqliconn,"UPDATE `$isppro`.`rm_users` SET admin_password='$resetpass1' WHERE username='$foundresetmail' AND username='$memberkey'");

echo magic_message("Password reset succesfully. Login afresh to continue.");
}
}
//===========reset pass============= 

    //====Oauth File Routes

	$login_file="./isp_login.php";
    $register_file="./isp_register.php";
    $change_password_file="./isp_change_pass.php";
    $reset_password_file="./isp_reset_password.php";
    
    //====Oauth File Routes
    
    
if(isset($_POST["create_acc"]))
{
    //------- begin Sign up User --> 
$username=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$firstname=mysqli_real_escape_string($mysqliconn, $_POST["txt_firstname"]);
$username=mysqli_real_escape_string($mysqliconn, magic_random_str(7));
$admin_password=mysqli_real_escape_string($mysqliconn, $_POST["txt_admin_password"]);
//===-- End Sign up User -->


    $check_dups=magic_sql_count("rm_users", "*", "username='$username'");

    if($check_dups==0){
        //------- begin Insert Query Sign up User --> 
//additional insert colmuns and values 
$rm_users_dope_cols="";
$rm_users_dope_vals="";

$rm_users_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$isppro`.`rm_users` (`username`,`username`,`firstname`,`username`,`admin_password`  ".$rm_users_dope_cols.") 
 VALUES 
(NULL,NULL,'$firstname',NULL,'$admin_password' ".$rm_users_dope_vals.")");

 //--- get primary key id
$rm_users_return_key=mysqli_insert_id($mysqliconn);

 //--- Redirect to current location with primary key
echo magic_screen('Account Created Succesfully.<hr> <a href="'.$login_file.'" class="btn btn-primary">Click Here To Login</a>');
//------- End insert Query Sign up User --> 
      }else{

      echo magic_message("Duplicate Email Found, Please try another one");

      }

}

//--<{ncgh}/>

    
?>