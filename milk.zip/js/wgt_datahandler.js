
  
  
////========================= start courses inputs widget 



function courses_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, courses_input_wgt(courses_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== courses ========================

 var courses_js_input=["txt_school_id:School Id:text:col-md-6","txt_school_name:School Name:text:col-md-6","txt_courses_user_pic:User Pic:file:col-md-6","txt_course_descr:Course Descr:text:col-md-6","txt_course_amt:Course Amt:text:col-md-6","txt_site_id:Site Id:text:col-md-6","txt_course_name:Course Name:text:col-md-6",];


function courses_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_school_id":"School Id:text:col-md-6","txt_school_name":"School Name:text:col-md-6","txt_courses_user_pic":"User Pic:file:col-md-6","txt_course_descr":"Course Descr:text:col-md-6","txt_course_amt":"Course Amt:text:col-md-6","txt_site_id":"Site Id:text:col-md-6","txt_course_name":"Course Name:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start lessons inputs widget 



function lessons_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, lessons_input_wgt(lessons_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== lessons ========================

 var lessons_js_input=["txt_course_id:Course Id:text:col-md-6","txt_school_id:School Id:text:col-md-6","txt_course_name:Course Name:text:col-md-6","txt_school_name:School Name:text:col-md-6","txt_lessons_user_pic:User Pic:file:col-md-6","txt_lesson_descr:Lesson Descr:text:col-md-6","txt_lesson_name:Lesson Name:text:col-md-12","txt_lesson_cartegory:Lesson Cartegory:text:col-md-6","txt_lesson_preview:Lesson Preview:text:col-md-6","txt_lesson_video_url:Lesson Video Url:text:col-md-6","txt_lesson_audio_url:Lesson Audio Url:text:col-md-6","txt_lesson_order:Lesson Order:text:col-md-6","txt_lesson_type:Lesson Type:text:col-md-6","txt_site_id:Site Id:text:col-md-6",];


function lessons_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_course_id":"Course Id:text:col-md-6","txt_school_id":"School Id:text:col-md-6","txt_course_name":"Course Name:text:col-md-6","txt_school_name":"School Name:text:col-md-6","txt_lessons_user_pic":"User Pic:file:col-md-6","txt_lesson_descr":"Lesson Descr:text:col-md-6","txt_lesson_name":"Lesson Name:text:col-md-12","txt_lesson_cartegory":"Lesson Cartegory:text:col-md-6","txt_lesson_preview":"Lesson Preview:text:col-md-6","txt_lesson_video_url":"Lesson Video Url:text:col-md-6","txt_lesson_audio_url":"Lesson Audio Url:text:col-md-6","txt_lesson_order":"Lesson Order:text:col-md-6","txt_lesson_type":"Lesson Type:text:col-md-6","txt_site_id":"Site Id:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start mosy_sql_roll_back inputs widget 



function mosy_sql_roll_back_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== mosy_sql_roll_back ========================

 var mosy_sql_roll_back_js_input=["txt_table_name:Table Name:text:col-md-6","txt_roll_type:Roll Type:text:col-md-6","txt_where_str:Where Str:text:col-md-6","txt_roll_timestamp:Roll Timestamp:text:col-md-6","txt_value_entries:Value Entries:text:col-md-6",];


function mosy_sql_roll_back_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_table_name":"Table Name:text:col-md-6","txt_roll_type":"Roll Type:text:col-md-6","txt_where_str":"Where Str:text:col-md-6","txt_roll_timestamp":"Roll Timestamp:text:col-md-6","txt_value_entries":"Value Entries:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start schools inputs widget 



function schools_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, schools_input_wgt(schools_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== schools ========================

 var schools_js_input=["txt_school_name:School Name:text:col-md-6","txt_schools_user_pic:User Pic:file:col-md-6","txt_school_descr:School Descr:text:col-md-6","txt_school_url:School Url:text:col-md-6","txt_site_id:Site Id:text:col-md-6",];


function schools_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_school_name":"School Name:text:col-md-6","txt_schools_user_pic":"User Pic:file:col-md-6","txt_school_descr":"School Descr:text:col-md-6","txt_school_url":"School Url:text:col-md-6","txt_site_id":"Site Id:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


  
  
////========================= start students inputs widget 



function students_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, students_input_wgt(students_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== students ========================

 var students_js_input=["txt_name:Name:text:col-md-6","txt_email:Email:text:col-md-6","txt_tel:Tel:text:col-md-6","txt_login_password:Login Password:text:col-md-6","txt_ref_id:Ref Id:text:col-md-6","txt_regdate:Regdate:datetime-local:col-md-6","txt_user_no:User No:text:col-md-6","txt_students_user_pic:User Pic:file:col-md-6","txt_user_gender:User Gender:user_gender_static_drop_down:col-md-6","txt_last_seen:Last Seen:text:col-md-6","txt_about:About:text:col-md-6",];


function students_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_name":"Name:text:col-md-6","txt_email":"Email:text:col-md-6","txt_tel":"Tel:text:col-md-6","txt_login_password":"Login Password:text:col-md-6","txt_ref_id":"Ref Id:text:col-md-6","txt_regdate":"Regdate:datetime-local:col-md-6","txt_user_no":"User No:text:col-md-6","txt_students_user_pic":"User Pic:file:col-md-6","txt_user_gender":"User Gender:user_gender_static_drop_down:col-md-6","txt_last_seen":"Last Seen:text:col-md-6","txt_about":"About:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
           

                
				if(input_type=="user_gender_static_drop_down")
                  {
                input_tag=`
                   <select name="txt_user_gender" id="txt_user_gender" class="form-control">
                   <option>Male</option>
<option>Female</option>

                   </select>`;
                   }
           
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  
              function load_students_user_gender_items ()
              {
                var default_user_gender_static_drop_down_val = `                      
                <option >User Gender</option>`;
                
                var static_user_gender_drop_down_items=`<option>Male</option>
<option>Female</option>
`;
           push_html("txt_user_gender", default_user_gender_static_drop_down_val+static_user_gender_drop_down_items);
           }


  
  
////========================= start transactions_table inputs widget 



function transactions_table_js_ui(card_title="", btn_str="", skip="", push_to="", required_inp="")
{
     
    mosy_card(card_title, transactions_table_input_wgt(transactions_table_js_input, btn_str, "", skip, required_inp), push_to);

}


//////////////////////=================== transactions_table ========================

 var transactions_table_js_input=["txt_TransID:Transid:text:col-md-6","txt_TransTime:Transtime:text:col-md-6","txt_TransAmount:Transamount:text:col-md-6","txt_BusinessShortCode:Businessshortcode:text:col-md-6","txt_BillRefNumber:Billrefnumber:text:col-md-6","txt_InvoiceNumber:Invoicenumber:text:col-md-6","txt_OrgAccountBalance:Orgaccountbalance:text:col-md-6","txt_ThirdPartyTransID:Thirdpartytransid:text:col-md-6","txt_MSISDN:Msisdn:text:col-md-6","txt_FirstName:Firstname:text:col-md-6","txt_MiddleName:Middlename:text:col-md-6","txt_LastName:Lastname:text:col-md-6",];


function transactions_table_input_wgt(input_array, button="", title="", skip="", required_inp="")
{

   ////alert(input_array);
	var input_cell="";

 var input_policy={"txt_TransID":"Transid:text:col-md-6","txt_TransTime":"Transtime:text:col-md-6","txt_TransAmount":"Transamount:text:col-md-6","txt_BusinessShortCode":"Businessshortcode:text:col-md-6","txt_BillRefNumber":"Billrefnumber:text:col-md-6","txt_InvoiceNumber":"Invoicenumber:text:col-md-6","txt_OrgAccountBalance":"Orgaccountbalance:text:col-md-6","txt_ThirdPartyTransID":"Thirdpartytransid:text:col-md-6","txt_MSISDN":"Msisdn:text:col-md-6","txt_FirstName":"Firstname:text:col-md-6","txt_MiddleName":"Middlename:text:col-md-6","txt_LastName":"Lastname:text:col-md-6",};
 if(title!="")
 {
 
  input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
 } 
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    if(required_inp.includes(input_id))
    {
     additional_attr=" required ";
    }    
    
   //// alert(required_inp+" -- "+input_id+" -- "+additional_attr);
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
        
     if(skip.includes(input_id))
     {
     }else{
     
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <textarea class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></textarea>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById('${input_id}').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <textarea class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></textarea>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	
    
    
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }
}
  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  var btn_tag="";
  if(button!=""){

    btn_tag = `<button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>`;
  }
    input_cell+=`
    <div class="col-md-12 text-center" id="${button_id}_mosy_cont">
    ${btn_tag}
    </div>`;

   input_cell+=`
    </div>`;
  
  return input_cell;
}
  


 var courses_list_cols ="primkey:Primkey,course_id:Course Id,school_id:School Id,school_name:School Name,user_pic:User Pic,course_descr:Course Descr,course_amt:Course Amt,site_id:Site Id,course_name:Course Name";

 var lessons_list_cols ="primkey:Primkey,lesson_id:Lesson Id,course_id:Course Id,school_id:School Id,course_name:Course Name,school_name:School Name,user_pic:User Pic,lesson_descr:Lesson Descr,lesson_name:Lesson Name,lesson_cartegory:Lesson Cartegory,lesson_preview:Lesson Preview,lesson_video_url:Lesson Video Url,lesson_audio_url:Lesson Audio Url,lesson_order:Lesson Order,lesson_type:Lesson Type,site_id:Site Id";

 var mosy_sql_roll_back_list_cols ="primkey:Primkey,roll_bk_key:Roll Bk Key,table_name:Table Name,roll_type:Roll Type,where_str:Where Str,roll_timestamp:Roll Timestamp,value_entries:Value Entries";

 var schools_list_cols ="primkey:Primkey,school_id:School Id,school_name:School Name,user_pic:User Pic,school_descr:School Descr,school_url:School Url,site_id:Site Id";

 var students_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,ref_id:Ref Id,regdate:Regdate,user_no:User No,user_pic:User Pic,user_gender:User Gender,last_seen:Last Seen,about:About";

 var transactions_table_list_cols ="primkey:Primkey,TransactionType:Transactiontype,TransID:Transid,TransTime:Transtime,TransAmount:Transamount,BusinessShortCode:Businessshortcode,BillRefNumber:Billrefnumber,InvoiceNumber:Invoicenumber,OrgAccountBalance:Orgaccountbalance,ThirdPartyTransID:Thirdpartytransid,MSISDN:Msisdn,FirstName:Firstname,MiddleName:Middlename,LastName:Lastname";



 var courses_list_nodes=`<tr class="cpointer" onclick="mosy_card('Courses Profile ', courses_input_wgt(courses_js_input,'courses_update_btn:Update:check-circle',''), '');initialize_courses(&quot where primkey='{{primkey}}'&quot;);push_newval('courses_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{school_id}}</td>
<td scope="col">{{school_name}}</td>
<td scope="col">{{course_descr}}</td>
<td scope="col">{{course_amt}}</td>
<td scope="col">{{site_id}}</td>
<td scope="col">{{course_name}}</td>
</tr>`;


 var lessons_list_nodes=`<tr class="cpointer" onclick="mosy_card('Lessons Profile ', lessons_input_wgt(lessons_js_input,'lessons_update_btn:Update:check-circle',''), '');initialize_lessons(&quot where primkey='{{primkey}}'&quot;);push_newval('lessons_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{course_id}}</td>
<td scope="col">{{school_id}}</td>
<td scope="col">{{course_name}}</td>
<td scope="col">{{school_name}}</td>
<td scope="col">{{lesson_descr}}</td>
<td scope="col">{{lesson_name}}</td>
<td scope="col">{{lesson_cartegory}}</td>
<td scope="col">{{lesson_preview}}</td>
<td scope="col">{{lesson_video_url}}</td>
<td scope="col">{{lesson_audio_url}}</td>
<td scope="col">{{lesson_order}}</td>
<td scope="col">{{lesson_type}}</td>
<td scope="col">{{site_id}}</td>
</tr>`;


 var mosy_sql_roll_back_list_nodes=`<tr class="cpointer" onclick="mosy_card('Mosy Sql Roll Back Profile ', mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input,'mosy_sql_roll_back_update_btn:Update:check-circle',''), '');initialize_mosy_sql_roll_back(&quot where primkey='{{primkey}}'&quot;);push_newval('mosy_sql_roll_back_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{table_name}}</td>
<td scope="col">{{roll_type}}</td>
<td scope="col">{{where_str}}</td>
<td scope="col">{{roll_timestamp}}</td>
<td scope="col">{{value_entries}}</td>
</tr>`;


 var schools_list_nodes=`<tr class="cpointer" onclick="mosy_card('Schools Profile ', schools_input_wgt(schools_js_input,'schools_update_btn:Update:check-circle',''), '');initialize_schools(&quot where primkey='{{primkey}}'&quot;);push_newval('schools_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{school_name}}</td>
<td scope="col">{{school_descr}}</td>
<td scope="col">{{school_url}}</td>
<td scope="col">{{site_id}}</td>
</tr>`;


 var students_list_nodes=`<tr class="cpointer" onclick="mosy_card('Students Profile ', students_input_wgt(students_js_input,'students_update_btn:Update:check-circle',''), '');initialize_students(&quot where primkey='{{primkey}}'&quot;);push_newval('students_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{regdate}}</td>
<td scope="col">{{user_no}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
</tr>`;


 var transactions_table_list_nodes=`<tr class="cpointer" onclick="mosy_card('Transactions Table Profile ', transactions_table_input_wgt(transactions_table_js_input,'transactions_table_update_btn:Update:check-circle',''), '');initialize_transactions_table(&quot where primkey='{{primkey}}'&quot;);push_newval('transactions_table_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{TransID}}</td>
<td scope="col">{{TransTime}}</td>
<td scope="col">{{TransAmount}}</td>
<td scope="col">{{BusinessShortCode}}</td>
<td scope="col">{{BillRefNumber}}</td>
<td scope="col">{{InvoiceNumber}}</td>
<td scope="col">{{OrgAccountBalance}}</td>
<td scope="col">{{ThirdPartyTransID}}</td>
<td scope="col">{{MSISDN}}</td>
<td scope="col">{{FirstName}}</td>
<td scope="col">{{MiddleName}}</td>
<td scope="col">{{LastName}}</td>
</tr>`;



        var courses_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="courses_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">School Id</th>
             <th scope="col">School Name</th>
             <th scope="col">Course Descr</th>
             <th scope="col">Course Amt</th>
             <th scope="col">Site Id</th>
             <th scope="col">Course Name</th>

		   </tr>
	    </thead>
	    <tbody id="courses_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var lessons_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="lessons_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Course Id</th>
             <th scope="col">School Id</th>
             <th scope="col">Course Name</th>
             <th scope="col">School Name</th>
             <th scope="col">Lesson Descr</th>
             <th scope="col">Lesson Name</th>
             <th scope="col">Lesson Cartegory</th>
             <th scope="col">Lesson Preview</th>
             <th scope="col">Lesson Video Url</th>
             <th scope="col">Lesson Audio Url</th>
             <th scope="col">Lesson Order</th>
             <th scope="col">Lesson Type</th>
             <th scope="col">Site Id</th>

		   </tr>
	    </thead>
	    <tbody id="lessons_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var mosy_sql_roll_back_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="mosy_sql_roll_back_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Table Name</th>
             <th scope="col">Roll Type</th>
             <th scope="col">Where Str</th>
             <th scope="col">Roll Timestamp</th>
             <th scope="col">Value Entries</th>

		   </tr>
	    </thead>
	    <tbody id="mosy_sql_roll_back_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var schools_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="schools_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">School Name</th>
             <th scope="col">School Descr</th>
             <th scope="col">School Url</th>
             <th scope="col">Site Id</th>

		   </tr>
	    </thead>
	    <tbody id="schools_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var students_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="students_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Login Password</th>
             <th scope="col">Ref Id</th>
             <th scope="col">Regdate</th>
             <th scope="col">User No</th>
             <th scope="col">User Gender</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>

		   </tr>
	    </thead>
	    <tbody id="students_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var transactions_table_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="transactions_table_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Transid</th>
             <th scope="col">Transtime</th>
             <th scope="col">Transamount</th>
             <th scope="col">Businessshortcode</th>
             <th scope="col">Billrefnumber</th>
             <th scope="col">Invoicenumber</th>
             <th scope="col">Orgaccountbalance</th>
             <th scope="col">Thirdpartytransid</th>
             <th scope="col">Msisdn</th>
             <th scope="col">Firstname</th>
             <th scope="col">Middlename</th>
             <th scope="col">Lastname</th>

		   </tr>
	    </thead>
	    <tbody id="transactions_table_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
