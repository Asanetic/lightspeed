

var curl_url =primary_domain;
  
var mosy_limit = 100;

///courses data_nodes 
  var courses_data_nodes ='{{row_count}}|{{primkey}}|{{course_id}}|{{school_id}}|{{school_name}}|{{user_pic}}|{{course_descr}}|{{course_amt}}|{{site_id}}|{{course_name}}';


   
   ///start courses search columns 
   
   var data_nodes_gft_courses_str="(primkey LIKE '%{{qcourses}}%' OR  course_id LIKE '%{{qcourses}}%' OR  school_id LIKE '%{{qcourses}}%' OR  school_name LIKE '%{{qcourses}}%' OR  user_pic LIKE '%{{qcourses}}%' OR  course_descr LIKE '%{{qcourses}}%' OR  course_amt LIKE '%{{qcourses}}%' OR  site_id LIKE '%{{qcourses}}%' OR  course_name LIKE '%{{qcourses}}%')";
    
    function  data_nodes_gft_courses(qcourses_str)
    {
        	var data_nodes_clean_courses_filter_str=data_nodes_gft_courses_str.replace(/{{qcourses}}/g, magic_clean_str(qcourses_str));
            
            return  data_nodes_clean_courses_filter_str;

    }
       ///end courses search columns 

  function mosy_courses_ui_node (courses_json_data, courses_load_to, courses_cols_, courses_template_ui)
  {
     ////alert(courses_template_ui);
     var courses_cols_fun_cols_str ="";
     
     if(typeof courses_cols_fun_cols !== "undefined")
      {
        courses_cols_fun_cols_str=courses_cols_fun_cols;
        
        ///alert(courses_cols_fun_cols)
      } 
      
     var courses_ui__ = mosy_list_render_(courses_json_data, courses_cols_fun_cols_str+courses_cols_, courses_template_ui) 

     ////push_html(courses_load_to, courses_ui__)  

     push_grid_result(courses_ui__, courses_load_to)
  }
  
 
 ///////
 
 var courses_auto_function= '{"cbfun":"process_courses_json_data","_data_isle":"courses_data_isle","_pagination_isle":"courses_pagination_isle","_data_template":"courses_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_courses"}';

 
 
 ///============ auto renders 
 
 
function mosy_courses_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", courses_pagination_prefix_="__pgnt_courses", colstr="*")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("courses", btoa(qstr))
  }else{
    mosy_delete_get_pram("courses")
  }
  
  if(mosy_get_param("courses")!==undefined)
  {
    qstr=atob(mosy_get_param("courses"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:courses_page_no:"+mosy_limit;
  }
  
  ///courses_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_courses_json_data","_data_isle":"courses_data_isle","_pagination_isle":"courses_pagination_isle","_data_template":"courses_data_template","_payload_str":"req","_pagination_prefix":"'+courses_pagination_prefix_+'"}';
            
  }
  
  return mosyrender_courses_(response_fun," where "+gft_courses(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, courses_pagination_prefix_)
  
}


  
  function autoprocess_courses_json_data(courses_server_resp)
  {  
    mosy_courses_ui_node(courses_server_resp, "courses_data_isle", courses_data_nodes, courses_data_template,"", "l:courses_page_no:15")
    mosy_paginate_api(courses_server_resp, "courses_page_no", "courses_pagination_isle", "15")
  }
  
  function process_courses_json_data(courses_server_resp, courses_callback="")
  {  
      var courses_data_isle="courses_data_isle";
      var courses_data_node_template=courses_data_template;
      var courses_pagination_isle="courses_pagination_isle";
      var courses_payload_str="";
      var courses__pagination_prefix_str="__pgnt_courses";
      
       ///alert(courses_callback)
       ///alert(courses_server_resp)
       console.log(courses_server_resp)
              
      try {
        
           const courses_jsonObject = JSON.parse(courses_callback);
        
           courses_data_isle=courses_jsonObject._data_isle;
           courses_data_node_template=window[courses_jsonObject._data_template];
           courses_pagination_isle=courses_jsonObject._pagination_isle;
           courses_payload_str=courses_jsonObject._payload_str;
           courses__pagination_prefix_str=courses_jsonObject._pagination_prefix;

           ///console.log("paginate == : valid JSON"+courses_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+courses_callback);
        
         if(courses_callback.indexOf(",") >= 0)
         {
              courses_data_handler_ui =courses_callback.split(",");                                 

              if(courses_data_handler_ui[0]!=undefined){ courses_data_isle=courses_data_handler_ui[0];}

              if(courses_data_handler_ui[1]!=undefined){courses_data_node_template =window[courses_data_handler_ui[1]];}

              if(courses_data_handler_ui[2]!=undefined){ courses_pagination_isle=courses_data_handler_ui[2]};

              if(courses_data_handler_ui[3]!=undefined){ courses_payload_str=btoa(courses_data_handler_ui[3])};
              
              if(courses_data_handler_ui[4]!=undefined){ courses__pagination_prefix_str=btoa(courses_data_handler_ui[4])};
              
         }       
        
      }

       ///alert(" dtisle == "+courses_data_isle)
       
            mosy_courses_ui_node(courses_server_resp, courses_data_isle, courses_data_nodes, courses_data_node_template,"", "l:courses_page_no:"+mosy_limit)                       
            
             if(courses_payload_str==="req")
             {
                
                mosy_paginate_api(courses_server_resp, "courses_page_no", courses_pagination_isle, "process_courses_json_data", courses__pagination_prefix_str)

             }
           
  }
    

function mosyrender_courses_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_courses")
{
   
  if(pagination==="")
  {
    pagination="l:courses_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _courses_payload="mosyget_&tbl=courses&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_courses_payload+curl_url)
  
  var _courses_pagination_json = '{"_payload":"'+_courses_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _courses_payload_input = document.createElement("input");
                _courses_payload_input.setAttribute('type', 'hidden');
                _courses_payload_input.setAttribute('name',_txt_payload);
                _courses_payload_input.setAttribute('id', _txt_payload);

                // Add the _courses_payload_input element to the DOM
                document.body.appendChild(_courses_payload_input);
                
      }
      
  push_newval(_txt_payload, _courses_pagination_json)
  mosyajax_get(_courses_payload, response_fun, curl_url);
  
  return _courses_payload;
  
}


function mginitialize_courses(reqkey, response_fun="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _courses_payload="mosyget_&tbl=courses&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
     mosyajax_get(_courses_payload, response_fun, curl_url);


}

 

///lessons data_nodes 
  var lessons_data_nodes ='{{row_count}}|{{primkey}}|{{lesson_id}}|{{course_id}}|{{school_id}}|{{course_name}}|{{school_name}}|{{user_pic}}|{{lesson_descr}}|{{lesson_name}}|{{lesson_cartegory}}|{{lesson_preview}}|{{lesson_video_url}}|{{lesson_audio_url}}|{{lesson_order}}|{{lesson_type}}|{{site_id}}';


   
   ///start lessons search columns 
   
   var data_nodes_gft_lessons_str="(primkey LIKE '%{{qlessons}}%' OR  lesson_id LIKE '%{{qlessons}}%' OR  course_id LIKE '%{{qlessons}}%' OR  school_id LIKE '%{{qlessons}}%' OR  course_name LIKE '%{{qlessons}}%' OR  school_name LIKE '%{{qlessons}}%' OR  user_pic LIKE '%{{qlessons}}%' OR  lesson_descr LIKE '%{{qlessons}}%' OR  lesson_name LIKE '%{{qlessons}}%' OR  lesson_cartegory LIKE '%{{qlessons}}%' OR  lesson_preview LIKE '%{{qlessons}}%' OR  lesson_video_url LIKE '%{{qlessons}}%' OR  lesson_audio_url LIKE '%{{qlessons}}%' OR  lesson_order LIKE '%{{qlessons}}%' OR  lesson_type LIKE '%{{qlessons}}%' OR  site_id LIKE '%{{qlessons}}%')";
    
    function  data_nodes_gft_lessons(qlessons_str)
    {
        	var data_nodes_clean_lessons_filter_str=data_nodes_gft_lessons_str.replace(/{{qlessons}}/g, magic_clean_str(qlessons_str));
            
            return  data_nodes_clean_lessons_filter_str;

    }
       ///end lessons search columns 

  function mosy_lessons_ui_node (lessons_json_data, lessons_load_to, lessons_cols_, lessons_template_ui)
  {
     ////alert(lessons_template_ui);
     var lessons_cols_fun_cols_str ="";
     
     if(typeof lessons_cols_fun_cols !== "undefined")
      {
        lessons_cols_fun_cols_str=lessons_cols_fun_cols;
        
        ///alert(lessons_cols_fun_cols)
      } 
      
     var lessons_ui__ = mosy_list_render_(lessons_json_data, lessons_cols_fun_cols_str+lessons_cols_, lessons_template_ui) 

     ////push_html(lessons_load_to, lessons_ui__)  

     push_grid_result(lessons_ui__, lessons_load_to)
  }
  
 
 ///////
 
 var lessons_auto_function= '{"cbfun":"process_lessons_json_data","_data_isle":"lessons_data_isle","_pagination_isle":"lessons_pagination_isle","_data_template":"lessons_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_lessons"}';

 
 
 ///============ auto renders 
 
 
function mosy_lessons_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", lessons_pagination_prefix_="__pgnt_lessons", colstr="*")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("lessons", btoa(qstr))
  }else{
    mosy_delete_get_pram("lessons")
  }
  
  if(mosy_get_param("lessons")!==undefined)
  {
    qstr=atob(mosy_get_param("lessons"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:lessons_page_no:"+mosy_limit;
  }
  
  ///lessons_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_lessons_json_data","_data_isle":"lessons_data_isle","_pagination_isle":"lessons_pagination_isle","_data_template":"lessons_data_template","_payload_str":"req","_pagination_prefix":"'+lessons_pagination_prefix_+'"}';
            
  }
  
  return mosyrender_lessons_(response_fun," where "+gft_lessons(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, lessons_pagination_prefix_)
  
}


  
  function autoprocess_lessons_json_data(lessons_server_resp)
  {  
    mosy_lessons_ui_node(lessons_server_resp, "lessons_data_isle", lessons_data_nodes, lessons_data_template,"", "l:lessons_page_no:15")
    mosy_paginate_api(lessons_server_resp, "lessons_page_no", "lessons_pagination_isle", "15")
  }
  
  function process_lessons_json_data(lessons_server_resp, lessons_callback="")
  {  
      var lessons_data_isle="lessons_data_isle";
      var lessons_data_node_template=lessons_data_template;
      var lessons_pagination_isle="lessons_pagination_isle";
      var lessons_payload_str="";
      var lessons__pagination_prefix_str="__pgnt_lessons";
      
       ///alert(lessons_callback)
       ///alert(lessons_server_resp)
       console.log(lessons_server_resp)
              
      try {
        
           const lessons_jsonObject = JSON.parse(lessons_callback);
        
           lessons_data_isle=lessons_jsonObject._data_isle;
           lessons_data_node_template=window[lessons_jsonObject._data_template];
           lessons_pagination_isle=lessons_jsonObject._pagination_isle;
           lessons_payload_str=lessons_jsonObject._payload_str;
           lessons__pagination_prefix_str=lessons_jsonObject._pagination_prefix;

           ///console.log("paginate == : valid JSON"+lessons_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+lessons_callback);
        
         if(lessons_callback.indexOf(",") >= 0)
         {
              lessons_data_handler_ui =lessons_callback.split(",");                                 

              if(lessons_data_handler_ui[0]!=undefined){ lessons_data_isle=lessons_data_handler_ui[0];}

              if(lessons_data_handler_ui[1]!=undefined){lessons_data_node_template =window[lessons_data_handler_ui[1]];}

              if(lessons_data_handler_ui[2]!=undefined){ lessons_pagination_isle=lessons_data_handler_ui[2]};

              if(lessons_data_handler_ui[3]!=undefined){ lessons_payload_str=btoa(lessons_data_handler_ui[3])};
              
              if(lessons_data_handler_ui[4]!=undefined){ lessons__pagination_prefix_str=btoa(lessons_data_handler_ui[4])};
              
         }       
        
      }

       ///alert(" dtisle == "+lessons_data_isle)
       
            mosy_lessons_ui_node(lessons_server_resp, lessons_data_isle, lessons_data_nodes, lessons_data_node_template,"", "l:lessons_page_no:"+mosy_limit)                       
            
             if(lessons_payload_str==="req")
             {
                
                mosy_paginate_api(lessons_server_resp, "lessons_page_no", lessons_pagination_isle, "process_lessons_json_data", lessons__pagination_prefix_str)

             }
           
  }
    

function mosyrender_lessons_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_lessons")
{
   
  if(pagination==="")
  {
    pagination="l:lessons_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _lessons_payload="mosyget_&tbl=lessons&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_lessons_payload+curl_url)
  
  var _lessons_pagination_json = '{"_payload":"'+_lessons_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _lessons_payload_input = document.createElement("input");
                _lessons_payload_input.setAttribute('type', 'hidden');
                _lessons_payload_input.setAttribute('name',_txt_payload);
                _lessons_payload_input.setAttribute('id', _txt_payload);

                // Add the _lessons_payload_input element to the DOM
                document.body.appendChild(_lessons_payload_input);
                
      }
      
  push_newval(_txt_payload, _lessons_pagination_json)
  mosyajax_get(_lessons_payload, response_fun, curl_url);
  
  return _lessons_payload;
  
}


function mginitialize_lessons(reqkey, response_fun="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _lessons_payload="mosyget_&tbl=lessons&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
     mosyajax_get(_lessons_payload, response_fun, curl_url);


}

 

///mosy_sql_roll_back data_nodes 
  var mosy_sql_roll_back_data_nodes ='{{row_count}}|{{primkey}}|{{roll_bk_key}}|{{table_name}}|{{roll_type}}|{{where_str}}|{{roll_timestamp}}|{{value_entries}}';


   
   ///start mosy_sql_roll_back search columns 
   
   var data_nodes_gft_mosy_sql_roll_back_str="(primkey LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
    
    function  data_nodes_gft_mosy_sql_roll_back(qmosy_sql_roll_back_str)
    {
        	var data_nodes_clean_mosy_sql_roll_back_filter_str=data_nodes_gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(qmosy_sql_roll_back_str));
            
            return  data_nodes_clean_mosy_sql_roll_back_filter_str;

    }
       ///end mosy_sql_roll_back search columns 

  function mosy_mosy_sql_roll_back_ui_node (mosy_sql_roll_back_json_data, mosy_sql_roll_back_load_to, mosy_sql_roll_back_cols_, mosy_sql_roll_back_template_ui)
  {
     ////alert(mosy_sql_roll_back_template_ui);
     var mosy_sql_roll_back_cols_fun_cols_str ="";
     
     if(typeof mosy_sql_roll_back_cols_fun_cols !== "undefined")
      {
        mosy_sql_roll_back_cols_fun_cols_str=mosy_sql_roll_back_cols_fun_cols;
        
        ///alert(mosy_sql_roll_back_cols_fun_cols)
      } 
      
     var mosy_sql_roll_back_ui__ = mosy_list_render_(mosy_sql_roll_back_json_data, mosy_sql_roll_back_cols_fun_cols_str+mosy_sql_roll_back_cols_, mosy_sql_roll_back_template_ui) 

     ////push_html(mosy_sql_roll_back_load_to, mosy_sql_roll_back_ui__)  

     push_grid_result(mosy_sql_roll_back_ui__, mosy_sql_roll_back_load_to)
  }
  
 
 ///////
 
 var mosy_sql_roll_back_auto_function= '{"cbfun":"process_mosy_sql_roll_back_json_data","_data_isle":"mosy_sql_roll_back_data_isle","_pagination_isle":"mosy_sql_roll_back_pagination_isle","_data_template":"mosy_sql_roll_back_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_mosy_sql_roll_back"}';

 
 
 ///============ auto renders 
 
 
function mosy_mosy_sql_roll_back_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", mosy_sql_roll_back_pagination_prefix_="__pgnt_mosy_sql_roll_back", colstr="*")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("mosy_sql_roll_back", btoa(qstr))
  }else{
    mosy_delete_get_pram("mosy_sql_roll_back")
  }
  
  if(mosy_get_param("mosy_sql_roll_back")!==undefined)
  {
    qstr=atob(mosy_get_param("mosy_sql_roll_back"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:mosy_sql_roll_back_page_no:"+mosy_limit;
  }
  
  ///mosy_sql_roll_back_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_mosy_sql_roll_back_json_data","_data_isle":"mosy_sql_roll_back_data_isle","_pagination_isle":"mosy_sql_roll_back_pagination_isle","_data_template":"mosy_sql_roll_back_data_template","_payload_str":"req","_pagination_prefix":"'+mosy_sql_roll_back_pagination_prefix_+'"}';
            
  }
  
  return mosyrender_mosy_sql_roll_back_(response_fun," where "+gft_mosy_sql_roll_back(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, mosy_sql_roll_back_pagination_prefix_)
  
}


  
  function autoprocess_mosy_sql_roll_back_json_data(mosy_sql_roll_back_server_resp)
  {  
    mosy_mosy_sql_roll_back_ui_node(mosy_sql_roll_back_server_resp, "mosy_sql_roll_back_data_isle", mosy_sql_roll_back_data_nodes, mosy_sql_roll_back_data_template,"", "l:mosy_sql_roll_back_page_no:15")
    mosy_paginate_api(mosy_sql_roll_back_server_resp, "mosy_sql_roll_back_page_no", "mosy_sql_roll_back_pagination_isle", "15")
  }
  
  function process_mosy_sql_roll_back_json_data(mosy_sql_roll_back_server_resp, mosy_sql_roll_back_callback="")
  {  
      var mosy_sql_roll_back_data_isle="mosy_sql_roll_back_data_isle";
      var mosy_sql_roll_back_data_node_template=mosy_sql_roll_back_data_template;
      var mosy_sql_roll_back_pagination_isle="mosy_sql_roll_back_pagination_isle";
      var mosy_sql_roll_back_payload_str="";
      var mosy_sql_roll_back__pagination_prefix_str="__pgnt_mosy_sql_roll_back";
      
       ///alert(mosy_sql_roll_back_callback)
       ///alert(mosy_sql_roll_back_server_resp)
       console.log(mosy_sql_roll_back_server_resp)
              
      try {
        
           const mosy_sql_roll_back_jsonObject = JSON.parse(mosy_sql_roll_back_callback);
        
           mosy_sql_roll_back_data_isle=mosy_sql_roll_back_jsonObject._data_isle;
           mosy_sql_roll_back_data_node_template=window[mosy_sql_roll_back_jsonObject._data_template];
           mosy_sql_roll_back_pagination_isle=mosy_sql_roll_back_jsonObject._pagination_isle;
           mosy_sql_roll_back_payload_str=mosy_sql_roll_back_jsonObject._payload_str;
           mosy_sql_roll_back__pagination_prefix_str=mosy_sql_roll_back_jsonObject._pagination_prefix;

           ///console.log("paginate == : valid JSON"+mosy_sql_roll_back_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+mosy_sql_roll_back_callback);
        
         if(mosy_sql_roll_back_callback.indexOf(",") >= 0)
         {
              mosy_sql_roll_back_data_handler_ui =mosy_sql_roll_back_callback.split(",");                                 

              if(mosy_sql_roll_back_data_handler_ui[0]!=undefined){ mosy_sql_roll_back_data_isle=mosy_sql_roll_back_data_handler_ui[0];}

              if(mosy_sql_roll_back_data_handler_ui[1]!=undefined){mosy_sql_roll_back_data_node_template =window[mosy_sql_roll_back_data_handler_ui[1]];}

              if(mosy_sql_roll_back_data_handler_ui[2]!=undefined){ mosy_sql_roll_back_pagination_isle=mosy_sql_roll_back_data_handler_ui[2]};

              if(mosy_sql_roll_back_data_handler_ui[3]!=undefined){ mosy_sql_roll_back_payload_str=btoa(mosy_sql_roll_back_data_handler_ui[3])};
              
              if(mosy_sql_roll_back_data_handler_ui[4]!=undefined){ mosy_sql_roll_back__pagination_prefix_str=btoa(mosy_sql_roll_back_data_handler_ui[4])};
              
         }       
        
      }

       ///alert(" dtisle == "+mosy_sql_roll_back_data_isle)
       
            mosy_mosy_sql_roll_back_ui_node(mosy_sql_roll_back_server_resp, mosy_sql_roll_back_data_isle, mosy_sql_roll_back_data_nodes, mosy_sql_roll_back_data_node_template,"", "l:mosy_sql_roll_back_page_no:"+mosy_limit)                       
            
             if(mosy_sql_roll_back_payload_str==="req")
             {
                
                mosy_paginate_api(mosy_sql_roll_back_server_resp, "mosy_sql_roll_back_page_no", mosy_sql_roll_back_pagination_isle, "process_mosy_sql_roll_back_json_data", mosy_sql_roll_back__pagination_prefix_str)

             }
           
  }
    

function mosyrender_mosy_sql_roll_back_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_mosy_sql_roll_back")
{
   
  if(pagination==="")
  {
    pagination="l:mosy_sql_roll_back_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _mosy_sql_roll_back_payload="mosyget_&tbl=mosy_sql_roll_back&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_mosy_sql_roll_back_payload+curl_url)
  
  var _mosy_sql_roll_back_pagination_json = '{"_payload":"'+_mosy_sql_roll_back_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _mosy_sql_roll_back_payload_input = document.createElement("input");
                _mosy_sql_roll_back_payload_input.setAttribute('type', 'hidden');
                _mosy_sql_roll_back_payload_input.setAttribute('name',_txt_payload);
                _mosy_sql_roll_back_payload_input.setAttribute('id', _txt_payload);

                // Add the _mosy_sql_roll_back_payload_input element to the DOM
                document.body.appendChild(_mosy_sql_roll_back_payload_input);
                
      }
      
  push_newval(_txt_payload, _mosy_sql_roll_back_pagination_json)
  mosyajax_get(_mosy_sql_roll_back_payload, response_fun, curl_url);
  
  return _mosy_sql_roll_back_payload;
  
}


function mginitialize_mosy_sql_roll_back(reqkey, response_fun="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _mosy_sql_roll_back_payload="mosyget_&tbl=mosy_sql_roll_back&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
     mosyajax_get(_mosy_sql_roll_back_payload, response_fun, curl_url);


}

 

///schools data_nodes 
  var schools_data_nodes ='{{row_count}}|{{primkey}}|{{school_id}}|{{school_name}}|{{user_pic}}|{{school_descr}}|{{school_url}}|{{site_id}}';


   
   ///start schools search columns 
   
   var data_nodes_gft_schools_str="(primkey LIKE '%{{qschools}}%' OR  school_id LIKE '%{{qschools}}%' OR  school_name LIKE '%{{qschools}}%' OR  user_pic LIKE '%{{qschools}}%' OR  school_descr LIKE '%{{qschools}}%' OR  school_url LIKE '%{{qschools}}%' OR  site_id LIKE '%{{qschools}}%')";
    
    function  data_nodes_gft_schools(qschools_str)
    {
        	var data_nodes_clean_schools_filter_str=data_nodes_gft_schools_str.replace(/{{qschools}}/g, magic_clean_str(qschools_str));
            
            return  data_nodes_clean_schools_filter_str;

    }
       ///end schools search columns 

  function mosy_schools_ui_node (schools_json_data, schools_load_to, schools_cols_, schools_template_ui)
  {
     ////alert(schools_template_ui);
     var schools_cols_fun_cols_str ="";
     
     if(typeof schools_cols_fun_cols !== "undefined")
      {
        schools_cols_fun_cols_str=schools_cols_fun_cols;
        
        ///alert(schools_cols_fun_cols)
      } 
      
     var schools_ui__ = mosy_list_render_(schools_json_data, schools_cols_fun_cols_str+schools_cols_, schools_template_ui) 

     ////push_html(schools_load_to, schools_ui__)  

     push_grid_result(schools_ui__, schools_load_to)
  }
  
 
 ///////
 
 var schools_auto_function= '{"cbfun":"process_schools_json_data","_data_isle":"schools_data_isle","_pagination_isle":"schools_pagination_isle","_data_template":"schools_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_schools"}';

 
 
 ///============ auto renders 
 
 
function mosy_schools_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", schools_pagination_prefix_="__pgnt_schools", colstr="*")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("schools", btoa(qstr))
  }else{
    mosy_delete_get_pram("schools")
  }
  
  if(mosy_get_param("schools")!==undefined)
  {
    qstr=atob(mosy_get_param("schools"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:schools_page_no:"+mosy_limit;
  }
  
  ///schools_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_schools_json_data","_data_isle":"schools_data_isle","_pagination_isle":"schools_pagination_isle","_data_template":"schools_data_template","_payload_str":"req","_pagination_prefix":"'+schools_pagination_prefix_+'"}';
            
  }
  
  return mosyrender_schools_(response_fun," where "+gft_schools(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, schools_pagination_prefix_)
  
}


  
  function autoprocess_schools_json_data(schools_server_resp)
  {  
    mosy_schools_ui_node(schools_server_resp, "schools_data_isle", schools_data_nodes, schools_data_template,"", "l:schools_page_no:15")
    mosy_paginate_api(schools_server_resp, "schools_page_no", "schools_pagination_isle", "15")
  }
  
  function process_schools_json_data(schools_server_resp, schools_callback="")
  {  
      var schools_data_isle="schools_data_isle";
      var schools_data_node_template=schools_data_template;
      var schools_pagination_isle="schools_pagination_isle";
      var schools_payload_str="";
      var schools__pagination_prefix_str="__pgnt_schools";
      
       ///alert(schools_callback)
       ///alert(schools_server_resp)
       console.log(schools_server_resp)
              
      try {
        
           const schools_jsonObject = JSON.parse(schools_callback);
        
           schools_data_isle=schools_jsonObject._data_isle;
           schools_data_node_template=window[schools_jsonObject._data_template];
           schools_pagination_isle=schools_jsonObject._pagination_isle;
           schools_payload_str=schools_jsonObject._payload_str;
           schools__pagination_prefix_str=schools_jsonObject._pagination_prefix;

           ///console.log("paginate == : valid JSON"+schools_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+schools_callback);
        
         if(schools_callback.indexOf(",") >= 0)
         {
              schools_data_handler_ui =schools_callback.split(",");                                 

              if(schools_data_handler_ui[0]!=undefined){ schools_data_isle=schools_data_handler_ui[0];}

              if(schools_data_handler_ui[1]!=undefined){schools_data_node_template =window[schools_data_handler_ui[1]];}

              if(schools_data_handler_ui[2]!=undefined){ schools_pagination_isle=schools_data_handler_ui[2]};

              if(schools_data_handler_ui[3]!=undefined){ schools_payload_str=btoa(schools_data_handler_ui[3])};
              
              if(schools_data_handler_ui[4]!=undefined){ schools__pagination_prefix_str=btoa(schools_data_handler_ui[4])};
              
         }       
        
      }

       ///alert(" dtisle == "+schools_data_isle)
       
            mosy_schools_ui_node(schools_server_resp, schools_data_isle, schools_data_nodes, schools_data_node_template,"", "l:schools_page_no:"+mosy_limit)                       
            
             if(schools_payload_str==="req")
             {
                
                mosy_paginate_api(schools_server_resp, "schools_page_no", schools_pagination_isle, "process_schools_json_data", schools__pagination_prefix_str)

             }
           
  }
    

function mosyrender_schools_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_schools")
{
   
  if(pagination==="")
  {
    pagination="l:schools_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _schools_payload="mosyget_&tbl=schools&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_schools_payload+curl_url)
  
  var _schools_pagination_json = '{"_payload":"'+_schools_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _schools_payload_input = document.createElement("input");
                _schools_payload_input.setAttribute('type', 'hidden');
                _schools_payload_input.setAttribute('name',_txt_payload);
                _schools_payload_input.setAttribute('id', _txt_payload);

                // Add the _schools_payload_input element to the DOM
                document.body.appendChild(_schools_payload_input);
                
      }
      
  push_newval(_txt_payload, _schools_pagination_json)
  mosyajax_get(_schools_payload, response_fun, curl_url);
  
  return _schools_payload;
  
}


function mginitialize_schools(reqkey, response_fun="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _schools_payload="mosyget_&tbl=schools&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
     mosyajax_get(_schools_payload, response_fun, curl_url);


}

 

///students data_nodes 
  var students_data_nodes ='{{row_count}}|{{primkey}}|{{user_id}}|{{name}}|{{email}}|{{tel}}|{{login_password}}|{{ref_id}}|{{regdate}}|{{user_no}}|{{user_pic}}|{{user_gender}}|{{last_seen}}|{{about}}';


   
   ///start students search columns 
   
   var data_nodes_gft_students_str="(primkey LIKE '%{{qstudents}}%' OR  user_id LIKE '%{{qstudents}}%' OR  name LIKE '%{{qstudents}}%' OR  email LIKE '%{{qstudents}}%' OR  tel LIKE '%{{qstudents}}%' OR  login_password LIKE '%{{qstudents}}%' OR  ref_id LIKE '%{{qstudents}}%' OR  regdate LIKE '%{{qstudents}}%' OR  user_no LIKE '%{{qstudents}}%' OR  user_pic LIKE '%{{qstudents}}%' OR  user_gender LIKE '%{{qstudents}}%' OR  last_seen LIKE '%{{qstudents}}%' OR  about LIKE '%{{qstudents}}%')";
    
    function  data_nodes_gft_students(qstudents_str)
    {
        	var data_nodes_clean_students_filter_str=data_nodes_gft_students_str.replace(/{{qstudents}}/g, magic_clean_str(qstudents_str));
            
            return  data_nodes_clean_students_filter_str;

    }
       ///end students search columns 

  function mosy_students_ui_node (students_json_data, students_load_to, students_cols_, students_template_ui)
  {
     ////alert(students_template_ui);
     var students_cols_fun_cols_str ="";
     
     if(typeof students_cols_fun_cols !== "undefined")
      {
        students_cols_fun_cols_str=students_cols_fun_cols;
        
        ///alert(students_cols_fun_cols)
      } 
      
     var students_ui__ = mosy_list_render_(students_json_data, students_cols_fun_cols_str+students_cols_, students_template_ui) 

     ////push_html(students_load_to, students_ui__)  

     push_grid_result(students_ui__, students_load_to)
  }
  
 
 ///////
 
 var students_auto_function= '{"cbfun":"process_students_json_data","_data_isle":"students_data_isle","_pagination_isle":"students_pagination_isle","_data_template":"students_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_students"}';

 
 
 ///============ auto renders 
 
 
function mosy_students_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", students_pagination_prefix_="__pgnt_students", colstr="*")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("students", btoa(qstr))
  }else{
    mosy_delete_get_pram("students")
  }
  
  if(mosy_get_param("students")!==undefined)
  {
    qstr=atob(mosy_get_param("students"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:students_page_no:"+mosy_limit;
  }
  
  ///students_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_students_json_data","_data_isle":"students_data_isle","_pagination_isle":"students_pagination_isle","_data_template":"students_data_template","_payload_str":"req","_pagination_prefix":"'+students_pagination_prefix_+'"}';
            
  }
  
  return mosyrender_students_(response_fun," where "+gft_students(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, students_pagination_prefix_)
  
}


  
  function autoprocess_students_json_data(students_server_resp)
  {  
    mosy_students_ui_node(students_server_resp, "students_data_isle", students_data_nodes, students_data_template,"", "l:students_page_no:15")
    mosy_paginate_api(students_server_resp, "students_page_no", "students_pagination_isle", "15")
  }
  
  function process_students_json_data(students_server_resp, students_callback="")
  {  
      var students_data_isle="students_data_isle";
      var students_data_node_template=students_data_template;
      var students_pagination_isle="students_pagination_isle";
      var students_payload_str="";
      var students__pagination_prefix_str="__pgnt_students";
      
       ///alert(students_callback)
       ///alert(students_server_resp)
       console.log(students_server_resp)
              
      try {
        
           const students_jsonObject = JSON.parse(students_callback);
        
           students_data_isle=students_jsonObject._data_isle;
           students_data_node_template=window[students_jsonObject._data_template];
           students_pagination_isle=students_jsonObject._pagination_isle;
           students_payload_str=students_jsonObject._payload_str;
           students__pagination_prefix_str=students_jsonObject._pagination_prefix;

           ///console.log("paginate == : valid JSON"+students_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+students_callback);
        
         if(students_callback.indexOf(",") >= 0)
         {
              students_data_handler_ui =students_callback.split(",");                                 

              if(students_data_handler_ui[0]!=undefined){ students_data_isle=students_data_handler_ui[0];}

              if(students_data_handler_ui[1]!=undefined){students_data_node_template =window[students_data_handler_ui[1]];}

              if(students_data_handler_ui[2]!=undefined){ students_pagination_isle=students_data_handler_ui[2]};

              if(students_data_handler_ui[3]!=undefined){ students_payload_str=btoa(students_data_handler_ui[3])};
              
              if(students_data_handler_ui[4]!=undefined){ students__pagination_prefix_str=btoa(students_data_handler_ui[4])};
              
         }       
        
      }

       ///alert(" dtisle == "+students_data_isle)
       
            mosy_students_ui_node(students_server_resp, students_data_isle, students_data_nodes, students_data_node_template,"", "l:students_page_no:"+mosy_limit)                       
            
             if(students_payload_str==="req")
             {
                
                mosy_paginate_api(students_server_resp, "students_page_no", students_pagination_isle, "process_students_json_data", students__pagination_prefix_str)

             }
           
  }
    

function mosyrender_students_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_students")
{
   
  if(pagination==="")
  {
    pagination="l:students_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _students_payload="mosyget_&tbl=students&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_students_payload+curl_url)
  
  var _students_pagination_json = '{"_payload":"'+_students_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _students_payload_input = document.createElement("input");
                _students_payload_input.setAttribute('type', 'hidden');
                _students_payload_input.setAttribute('name',_txt_payload);
                _students_payload_input.setAttribute('id', _txt_payload);

                // Add the _students_payload_input element to the DOM
                document.body.appendChild(_students_payload_input);
                
      }
      
  push_newval(_txt_payload, _students_pagination_json)
  mosyajax_get(_students_payload, response_fun, curl_url);
  
  return _students_payload;
  
}


function mginitialize_students(reqkey, response_fun="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _students_payload="mosyget_&tbl=students&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
     mosyajax_get(_students_payload, response_fun, curl_url);


}

 

///transactions_table data_nodes 
  var transactions_table_data_nodes ='{{row_count}}|{{primkey}}|{{TransactionType}}|{{TransID}}|{{TransTime}}|{{TransAmount}}|{{BusinessShortCode}}|{{BillRefNumber}}|{{InvoiceNumber}}|{{OrgAccountBalance}}|{{ThirdPartyTransID}}|{{MSISDN}}|{{FirstName}}|{{MiddleName}}|{{LastName}}';


   
   ///start transactions_table search columns 
   
   var data_nodes_gft_transactions_table_str="(primkey LIKE '%{{qtransactions_table}}%' OR  TransactionType LIKE '%{{qtransactions_table}}%' OR  TransID LIKE '%{{qtransactions_table}}%' OR  TransTime LIKE '%{{qtransactions_table}}%' OR  TransAmount LIKE '%{{qtransactions_table}}%' OR  BusinessShortCode LIKE '%{{qtransactions_table}}%' OR  BillRefNumber LIKE '%{{qtransactions_table}}%' OR  InvoiceNumber LIKE '%{{qtransactions_table}}%' OR  OrgAccountBalance LIKE '%{{qtransactions_table}}%' OR  ThirdPartyTransID LIKE '%{{qtransactions_table}}%' OR  MSISDN LIKE '%{{qtransactions_table}}%' OR  FirstName LIKE '%{{qtransactions_table}}%' OR  MiddleName LIKE '%{{qtransactions_table}}%' OR  LastName LIKE '%{{qtransactions_table}}%')";
    
    function  data_nodes_gft_transactions_table(qtransactions_table_str)
    {
        	var data_nodes_clean_transactions_table_filter_str=data_nodes_gft_transactions_table_str.replace(/{{qtransactions_table}}/g, magic_clean_str(qtransactions_table_str));
            
            return  data_nodes_clean_transactions_table_filter_str;

    }
       ///end transactions_table search columns 

  function mosy_transactions_table_ui_node (transactions_table_json_data, transactions_table_load_to, transactions_table_cols_, transactions_table_template_ui)
  {
     ////alert(transactions_table_template_ui);
     var transactions_table_cols_fun_cols_str ="";
     
     if(typeof transactions_table_cols_fun_cols !== "undefined")
      {
        transactions_table_cols_fun_cols_str=transactions_table_cols_fun_cols;
        
        ///alert(transactions_table_cols_fun_cols)
      } 
      
     var transactions_table_ui__ = mosy_list_render_(transactions_table_json_data, transactions_table_cols_fun_cols_str+transactions_table_cols_, transactions_table_template_ui) 

     ////push_html(transactions_table_load_to, transactions_table_ui__)  

     push_grid_result(transactions_table_ui__, transactions_table_load_to)
  }
  
 
 ///////
 
 var transactions_table_auto_function= '{"cbfun":"process_transactions_table_json_data","_data_isle":"transactions_table_data_isle","_pagination_isle":"transactions_table_pagination_isle","_data_template":"transactions_table_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_transactions_table"}';

 
 
 ///============ auto renders 
 
 
function mosy_transactions_table_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", transactions_table_pagination_prefix_="__pgnt_transactions_table", colstr="*")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("transactions_table", btoa(qstr))
  }else{
    mosy_delete_get_pram("transactions_table")
  }
  
  if(mosy_get_param("transactions_table")!==undefined)
  {
    qstr=atob(mosy_get_param("transactions_table"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:transactions_table_page_no:"+mosy_limit;
  }
  
  ///transactions_table_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_transactions_table_json_data","_data_isle":"transactions_table_data_isle","_pagination_isle":"transactions_table_pagination_isle","_data_template":"transactions_table_data_template","_payload_str":"req","_pagination_prefix":"'+transactions_table_pagination_prefix_+'"}';
            
  }
  
  return mosyrender_transactions_table_(response_fun," where "+gft_transactions_table(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, transactions_table_pagination_prefix_)
  
}


  
  function autoprocess_transactions_table_json_data(transactions_table_server_resp)
  {  
    mosy_transactions_table_ui_node(transactions_table_server_resp, "transactions_table_data_isle", transactions_table_data_nodes, transactions_table_data_template,"", "l:transactions_table_page_no:15")
    mosy_paginate_api(transactions_table_server_resp, "transactions_table_page_no", "transactions_table_pagination_isle", "15")
  }
  
  function process_transactions_table_json_data(transactions_table_server_resp, transactions_table_callback="")
  {  
      var transactions_table_data_isle="transactions_table_data_isle";
      var transactions_table_data_node_template=transactions_table_data_template;
      var transactions_table_pagination_isle="transactions_table_pagination_isle";
      var transactions_table_payload_str="";
      var transactions_table__pagination_prefix_str="__pgnt_transactions_table";
      
       ///alert(transactions_table_callback)
       ///alert(transactions_table_server_resp)
       console.log(transactions_table_server_resp)
              
      try {
        
           const transactions_table_jsonObject = JSON.parse(transactions_table_callback);
        
           transactions_table_data_isle=transactions_table_jsonObject._data_isle;
           transactions_table_data_node_template=window[transactions_table_jsonObject._data_template];
           transactions_table_pagination_isle=transactions_table_jsonObject._pagination_isle;
           transactions_table_payload_str=transactions_table_jsonObject._payload_str;
           transactions_table__pagination_prefix_str=transactions_table_jsonObject._pagination_prefix;

           ///console.log("paginate == : valid JSON"+transactions_table_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+transactions_table_callback);
        
         if(transactions_table_callback.indexOf(",") >= 0)
         {
              transactions_table_data_handler_ui =transactions_table_callback.split(",");                                 

              if(transactions_table_data_handler_ui[0]!=undefined){ transactions_table_data_isle=transactions_table_data_handler_ui[0];}

              if(transactions_table_data_handler_ui[1]!=undefined){transactions_table_data_node_template =window[transactions_table_data_handler_ui[1]];}

              if(transactions_table_data_handler_ui[2]!=undefined){ transactions_table_pagination_isle=transactions_table_data_handler_ui[2]};

              if(transactions_table_data_handler_ui[3]!=undefined){ transactions_table_payload_str=btoa(transactions_table_data_handler_ui[3])};
              
              if(transactions_table_data_handler_ui[4]!=undefined){ transactions_table__pagination_prefix_str=btoa(transactions_table_data_handler_ui[4])};
              
         }       
        
      }

       ///alert(" dtisle == "+transactions_table_data_isle)
       
            mosy_transactions_table_ui_node(transactions_table_server_resp, transactions_table_data_isle, transactions_table_data_nodes, transactions_table_data_node_template,"", "l:transactions_table_page_no:"+mosy_limit)                       
            
             if(transactions_table_payload_str==="req")
             {
                
                mosy_paginate_api(transactions_table_server_resp, "transactions_table_page_no", transactions_table_pagination_isle, "process_transactions_table_json_data", transactions_table__pagination_prefix_str)

             }
           
  }
    

function mosyrender_transactions_table_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_transactions_table")
{
   
  if(pagination==="")
  {
    pagination="l:transactions_table_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _transactions_table_payload="mosyget_&tbl=transactions_table&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_transactions_table_payload+curl_url)
  
  var _transactions_table_pagination_json = '{"_payload":"'+_transactions_table_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _transactions_table_payload_input = document.createElement("input");
                _transactions_table_payload_input.setAttribute('type', 'hidden');
                _transactions_table_payload_input.setAttribute('name',_txt_payload);
                _transactions_table_payload_input.setAttribute('id', _txt_payload);

                // Add the _transactions_table_payload_input element to the DOM
                document.body.appendChild(_transactions_table_payload_input);
                
      }
      
  push_newval(_txt_payload, _transactions_table_pagination_json)
  mosyajax_get(_transactions_table_payload, response_fun, curl_url);
  
  return _transactions_table_payload;
  
}


function mginitialize_transactions_table(reqkey, response_fun="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _transactions_table_payload="mosyget_&tbl=transactions_table&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
     mosyajax_get(_transactions_table_payload, response_fun, curl_url);


}

 


 

function mosy_list_render_(json_data, cols_, template_ui)
{
  ///console.log(json_data)
  var parse_serv_json=JSON.parse(json_data);
   
  var str_node = "";
    
  var re = new RegExp(cols_, 'gi');

  for(datanode of parse_serv_json.data)
    {
      str_node+= template_ui.replace(re, function (node) {
     	return datanode[node.replace(/[{{}}]/g, "")].replace(/\r?\n/g, "<br>");;
      }); 
    }
  
  return str_node;
}


function mosy_ui_data_nodes(json_server_response) 
{
    
    ///alert(json_server_response);
    
    var json_decoded_str=JSON.parse(json_server_response).data[0];
    
    ///console.log("  initialize response -- "+json_decoded_str);
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) 
      {
          var val = json_decoded_str[keys[i]];
          console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    
function  mosy_paginate_api(server_resp, pagination_label, push_to, response_fun, _txt_payload)
{    
  var paginate_count=JSON.parse(server_resp);
 
  mosy_paginate_ui(paginate_count.page_count, push_to, _txt_payload)
   
}


function mosy_paginate_ui(totalPages, push_to, payload_source, currentPage=1)
{
    ///alert("af -- "+currentPage+push_to)
    ///let currentPage = 1; // Current page number
    const maxPaginationButtons = 7; // Maximum number of pagination buttons to display
    const halfMaxPaginationButtons = Math.floor(maxPaginationButtons / 2); // Half of maximum number of pagination buttons
    
    // Calculate total number of pages
    ////const totalPages = Math.ceil(totalRecords / recordsPerPage);
  
      let linkHTML = `
          <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">        
        `;
      // Generate "Previous" link
      if (currentPage > 1) {
        linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${currentPage - 1},'${push_to}', '${totalPages}', '${payload_source}', '${payload_source}')"> << </a></li>`;
      } else {
        linkHTML += `<li class="page-item disabled"><a class="page-link cpointer "  > << </a></li>`;
      }

      // Generate "First" link
      if (currentPage > 1) {
        linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(1,'${push_to}', '${totalPages}', '${payload_source}')">First</a></li>`;
      } else {
        linkHTML += `<li class="page-item disabled"><a class="page-link cpointer "  >First</a></li>`;
      }      
      // Generate numbered links
      let startPage = 1;
      let endPage = totalPages;
      if (totalPages > maxPaginationButtons) {
        if (currentPage <= halfMaxPaginationButtons) {
          endPage = maxPaginationButtons;
        } else if (currentPage >= totalPages - halfMaxPaginationButtons) {
          startPage = totalPages - maxPaginationButtons + 1;
        } else {
          startPage = currentPage - halfMaxPaginationButtons;
          endPage = currentPage + halfMaxPaginationButtons;
        }
        if (startPage > 1) {
          linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${startPage - 1},'${push_to}', '${totalPages}', '${payload_source}')">...</a></li>`;
        }
        for (let i = startPage; i <= endPage; i++) {
          if (i === currentPage) {
            linkHTML += `<li class="page-item active"><a class="page-link cpointer "  >${i}</a></li>`;
          } else {
            linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${i},'${push_to}', '${totalPages}', '${payload_source}')">${i}</a></li>`;
          }
        }
        if (endPage < totalPages) {
          linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${endPage + 1},'${push_to}', '${totalPages}', '${payload_source}')">...</a></li>`;
        }
      } else {
        for (let i = startPage; i <= endPage; i++) {
          if (i === currentPage) {
            linkHTML += `<li class="page-item active"><a class="page-link cpointer "  >${i}</a></li>`;
          } else {
            linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${i},'${push_to}', '${totalPages}', '${payload_source}')">${i}</a></li>`;
          }
        }
      }

      // Generate "Last" link
      if (currentPage < totalPages) {
        linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${totalPages},'${push_to}', '${totalPages}', '${payload_source}')">Last</a></li>`;
      } else {
        linkHTML += `<li class="page-item disabled"><a class="page-link cpointer "  >Last</a></li>`;
      }


      // Generate "Next" link
      if (currentPage < totalPages) {
        linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${currentPage + 1},'${push_to}', '${totalPages}', '${payload_source}')"> >> </a></li>`;
      } else {
        linkHTML += `<li class="page-item disabled"><a class="page-link cpointer "  > >> </a></li>`;
      }
      linkHTML +=`</ul>
        </nav>`;

     push_html(push_to, linkHTML)

      return linkHTML;
    
}

function mosy_navigate_pagination(page, push_to, total_pages, payload_source, response_fun) 
{
   currentPage = page+1;
   
   ///alert(response_fun)
   
   var parse_serv_json=JSON.parse(get_newval(payload_source));

   var pagination_label = parse_serv_json.pagination_label;
      
   ////alert(payload_source+" -- "+parse_serv_json._payload)
   
   
   var paginate_payload = (parse_serv_json._payload).replace("l:"+pagination_label+":"+mosy_limit, "l:"+pagination_label+":"+mosy_limit+":"+page+"")


   var removed_regen_pagination =delete (parse_serv_json.response_attr)._payload_str;
   
   var response_function =(JSON.stringify(parse_serv_json.response_attr))
   
  ///alert(paginate_payload +" -- "+pagination_label)
  
  ////alert(response_function)
  
   ///push_newval(payload_source, paginate_payload)
   
   mosyajax_get(paginate_payload, response_function, curl_url);
  
  mosy_paginate_ui(total_pages, push_to, payload_source, page)
  
}


