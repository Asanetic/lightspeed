    //<!--next_ajax_str-->
var calc_ui=`
<div class="row justify-content-center m-0 p-0 col-md-12">
 <input typ="text" class="col-md-12 bg-light p-3 border mb-3 h1 text-right" title="Click To Clear Screen" id="screen"/>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+1)">1</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+2)">2</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+3)">3</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+4)">4</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+5)">5</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+6)">6</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+7)">7</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+8)">8</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+9)">9</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+0)">0</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'*')">*</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'+')">+</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'-')">-</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'/')">/</div>
  <div class="col-4  h1 cpointer " onclick="push_newval('screen', get_newval('screen')+'='+eval(get_newval('screen')));push_newval('notes', get_newval('notes')+'|'+get_newval('screen'))">=</div>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  <input class="border-0" style="" id="notes" placeholder="notes"></input> </div>
  </div>
</div>  
  
  
`;


var client_list_rpt =`

<div class="col-md-12 border-bottom p-3" id="" onclick="new_location('clientprofilev2?rm_users_uptoken='+btoa('{{username}}'))">{{row_count}}. {{username}}</div>  
  `;


  var client_profile_card=`
    
           <!-- Begin user profile card  Begin user profile card  -->	
        <div class="col-md-12">
            <div class="card card-primary card-outline">
              <div class="col-md-12 ">
                <div class="text-center col-md-12 pt-2 mb-2 ">
                  <img class="useravatar_90 border border_set" src="img/useravatar.png" alt="User profile picture">
                </div>

                <h5 class="profile-username text-center">{{firstname}} {{lastname}}</h5>

                <p class="text-muted text-center">{{srvname}}</p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b> Account Name </b> <a class="float-right">{{username}}</a>
                  </li>    
                  <li class="list-group-item">
                    <b>Date Registered </b> <a class="float-right">{{createdon}}</a>
                  </li>
                  <li class="list-group-item">
                    <b>Mobile</b> <a class="float-right">{{mobile}}</a>
                  </li>
                  <li class="list-group-item">
                    <b>Email </b> <a class="float-right">{{email}}</a>
                  </li>
                  <li class="list-group-item cpointer" onclick="new_location('clientlist?rm_users_mosyfilter='+btoa(&quot; owner=\'{{owner}}\' &quot;)+'')" >
                    <b>Owner </b> <a class="float-right">{{owner}}</a>
                  </li>    
                </ul>
    <hr>
                 {{comment}}
<hr>
                <a href="#" class="btn btn-primary"><b>Follow</b></a>
              </div>
              <!-- /.card-body -->
            </div>
        </div>
       <!-- End user profile card  Begin user profile card  -->
    `;