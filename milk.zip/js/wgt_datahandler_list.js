
 var courses_list_cols ="primkey:Primkey,course_id:Course Id,school_id:School Id,school_name:School Name,user_pic:User Pic,course_descr:Course Descr,course_amt:Course Amt,site_id:Site Id,course_name:Course Name";

 var lessons_list_cols ="primkey:Primkey,lesson_id:Lesson Id,course_id:Course Id,school_id:School Id,course_name:Course Name,school_name:School Name,user_pic:User Pic,lesson_descr:Lesson Descr,lesson_name:Lesson Name,lesson_cartegory:Lesson Cartegory,lesson_preview:Lesson Preview,lesson_video_url:Lesson Video Url,lesson_audio_url:Lesson Audio Url,lesson_order:Lesson Order,lesson_type:Lesson Type,site_id:Site Id";

 var mosy_sql_roll_back_list_cols ="primkey:Primkey,roll_bk_key:Roll Bk Key,table_name:Table Name,roll_type:Roll Type,where_str:Where Str,roll_timestamp:Roll Timestamp,value_entries:Value Entries";

 var schools_list_cols ="primkey:Primkey,school_id:School Id,school_name:School Name,user_pic:User Pic,school_descr:School Descr,school_url:School Url,site_id:Site Id";

 var students_list_cols ="primkey:Primkey,user_id:User Id,name:Name,email:Email,tel:Tel,login_password:Login Password,ref_id:Ref Id,regdate:Regdate,user_no:User No,user_pic:User Pic,user_gender:User Gender,last_seen:Last Seen,about:About";

 var transactions_table_list_cols ="primkey:Primkey,TransactionType:Transactiontype,TransID:Transid,TransTime:Transtime,TransAmount:Transamount,BusinessShortCode:Businessshortcode,BillRefNumber:Billrefnumber,InvoiceNumber:Invoicenumber,OrgAccountBalance:Orgaccountbalance,ThirdPartyTransID:Thirdpartytransid,MSISDN:Msisdn,FirstName:Firstname,MiddleName:Middlename,LastName:Lastname";



 var courses_list_nodes=`<tr class="cpointer" onclick="mosy_card('Courses Profile ', courses_input_wgt(courses_js_input,'courses_update_btn:Update:check-circle',''), '');initialize_courses(&quot where primkey='{{primkey}}'&quot;);push_newval('courses_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{school_id}}</td>
<td scope="col">{{school_name}}</td>
<td scope="col">{{course_descr}}</td>
<td scope="col">{{course_amt}}</td>
<td scope="col">{{site_id}}</td>
<td scope="col">{{course_name}}</td>
</tr>`;


 var lessons_list_nodes=`<tr class="cpointer" onclick="mosy_card('Lessons Profile ', lessons_input_wgt(lessons_js_input,'lessons_update_btn:Update:check-circle',''), '');initialize_lessons(&quot where primkey='{{primkey}}'&quot;);push_newval('lessons_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{course_id}}</td>
<td scope="col">{{school_id}}</td>
<td scope="col">{{course_name}}</td>
<td scope="col">{{school_name}}</td>
<td scope="col">{{lesson_descr}}</td>
<td scope="col">{{lesson_name}}</td>
<td scope="col">{{lesson_cartegory}}</td>
<td scope="col">{{lesson_preview}}</td>
<td scope="col">{{lesson_video_url}}</td>
<td scope="col">{{lesson_audio_url}}</td>
<td scope="col">{{lesson_order}}</td>
<td scope="col">{{lesson_type}}</td>
<td scope="col">{{site_id}}</td>
</tr>`;


 var mosy_sql_roll_back_list_nodes=`<tr class="cpointer" onclick="mosy_card('Mosy Sql Roll Back Profile ', mosy_sql_roll_back_input_wgt(mosy_sql_roll_back_js_input,'mosy_sql_roll_back_update_btn:Update:check-circle',''), '');initialize_mosy_sql_roll_back(&quot where primkey='{{primkey}}'&quot;);push_newval('mosy_sql_roll_back_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{table_name}}</td>
<td scope="col">{{roll_type}}</td>
<td scope="col">{{where_str}}</td>
<td scope="col">{{roll_timestamp}}</td>
<td scope="col">{{value_entries}}</td>
</tr>`;


 var schools_list_nodes=`<tr class="cpointer" onclick="mosy_card('Schools Profile ', schools_input_wgt(schools_js_input,'schools_update_btn:Update:check-circle',''), '');initialize_schools(&quot where primkey='{{primkey}}'&quot;);push_newval('schools_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{school_name}}</td>
<td scope="col">{{school_descr}}</td>
<td scope="col">{{school_url}}</td>
<td scope="col">{{site_id}}</td>
</tr>`;


 var students_list_nodes=`<tr class="cpointer" onclick="mosy_card('Students Profile ', students_input_wgt(students_js_input,'students_update_btn:Update:check-circle',''), '');initialize_students(&quot where primkey='{{primkey}}'&quot;);push_newval('students_uptoken', btoa({{primkey}}))"><td></td>
<td scope="col"> <img src="{{user_pic}}" style="width:50px; height:50px; border-radius:50%;"/></td>

<td scope="col">{{name}}</td>
<td scope="col">{{email}}</td>
<td scope="col">{{tel}}</td>
<td scope="col">{{login_password}}</td>
<td scope="col">{{ref_id}}</td>
<td scope="col">{{regdate}}</td>
<td scope="col">{{user_no}}</td>
<td scope="col">{{user_gender}}</td>
<td scope="col">{{last_seen}}</td>
<td scope="col">{{about}}</td>
</tr>`;


 var transactions_table_list_nodes=`<tr class="cpointer" onclick="mosy_card('Transactions Table Profile ', transactions_table_input_wgt(transactions_table_js_input,'transactions_table_update_btn:Update:check-circle',''), '');initialize_transactions_table(&quot where primkey='{{primkey}}'&quot;);push_newval('transactions_table_uptoken', btoa({{primkey}}))"><td></td>

<td scope="col">{{TransID}}</td>
<td scope="col">{{TransTime}}</td>
<td scope="col">{{TransAmount}}</td>
<td scope="col">{{BusinessShortCode}}</td>
<td scope="col">{{BillRefNumber}}</td>
<td scope="col">{{InvoiceNumber}}</td>
<td scope="col">{{OrgAccountBalance}}</td>
<td scope="col">{{ThirdPartyTransID}}</td>
<td scope="col">{{MSISDN}}</td>
<td scope="col">{{FirstName}}</td>
<td scope="col">{{MiddleName}}</td>
<td scope="col">{{LastName}}</td>
</tr>`;



        var courses_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="courses_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">School Id</th>
             <th scope="col">School Name</th>
             <th scope="col">Course Descr</th>
             <th scope="col">Course Amt</th>
             <th scope="col">Site Id</th>
             <th scope="col">Course Name</th>

		   </tr>
	    </thead>
	    <tbody id="courses_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var lessons_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="lessons_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Course Id</th>
             <th scope="col">School Id</th>
             <th scope="col">Course Name</th>
             <th scope="col">School Name</th>
             <th scope="col">Lesson Descr</th>
             <th scope="col">Lesson Name</th>
             <th scope="col">Lesson Cartegory</th>
             <th scope="col">Lesson Preview</th>
             <th scope="col">Lesson Video Url</th>
             <th scope="col">Lesson Audio Url</th>
             <th scope="col">Lesson Order</th>
             <th scope="col">Lesson Type</th>
             <th scope="col">Site Id</th>

		   </tr>
	    </thead>
	    <tbody id="lessons_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var mosy_sql_roll_back_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="mosy_sql_roll_back_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Table Name</th>
             <th scope="col">Roll Type</th>
             <th scope="col">Where Str</th>
             <th scope="col">Roll Timestamp</th>
             <th scope="col">Value Entries</th>

		   </tr>
	    </thead>
	    <tbody id="mosy_sql_roll_back_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var schools_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="schools_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">School Name</th>
             <th scope="col">School Descr</th>
             <th scope="col">School Url</th>
             <th scope="col">Site Id</th>

		   </tr>
	    </thead>
	    <tbody id="schools_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var students_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="students_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      <th>User Pic</th>
				             <th scope="col">Name</th>
             <th scope="col">Email</th>
             <th scope="col">Tel</th>
             <th scope="col">Login Password</th>
             <th scope="col">Ref Id</th>
             <th scope="col">Regdate</th>
             <th scope="col">User No</th>
             <th scope="col">User Gender</th>
             <th scope="col">Last Seen</th>
             <th scope="col">About</th>

		   </tr>
	    </thead>
	    <tbody id="students_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
        var transactions_table_list_wgt =`
        <div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="transactions_table_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	      
				             <th scope="col">Transid</th>
             <th scope="col">Transtime</th>
             <th scope="col">Transamount</th>
             <th scope="col">Businessshortcode</th>
             <th scope="col">Billrefnumber</th>
             <th scope="col">Invoicenumber</th>
             <th scope="col">Orgaccountbalance</th>
             <th scope="col">Thirdpartytransid</th>
             <th scope="col">Msisdn</th>
             <th scope="col">Firstname</th>
             <th scope="col">Middlename</th>
             <th scope="col">Lastname</th>

		   </tr>
	    </thead>
	    <tbody id="transactions_table_tbl_list">

  <!--add_new_row_here-->
	    </tbody>
	    </table>
        </div>
        `;
        
        
