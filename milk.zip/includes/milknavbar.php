<?php 
$mosy_nav___username="Jeremy Alex";
$mosy_nav___user_avatar="img/useravatar.png";
$mosy_nav___user_notifi_count="0";
$mosy_nav___user_role="User";
?>
<div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar sticky">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li>
              <a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"> <i data-feather="align-justify"></i></a></li>
            <li><a href="#" class="nav-link nav-link-lg fullscreen-btn">
                <i data-feather="maximize"></i>
              </a></li>
            <li>
            </li>
          </ul>
        </div>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown"
              class="nav-link nav-link-lg message-toggle"><i data-feather="mail"></i>
              <span class="badge headerBadge1">
                6 </span> </a>
            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
              <div class="dropdown-header">
                Messages
                <div class="float-right">
                  <a href="#">Mark All As Read</a>
                </div>
              </div>
              <div class="dropdown-list-content dropdown-list-message">

              </div>
              <div class="dropdown-footer text-center">
                <a href="#">View All <i class="fas fa-chevron-right"></i></a>
              </div>
            </div>
          </li>
          <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown"
              class="nav-link notification-toggle nav-link-lg"><i data-feather="bell" class=""></i>
            </a>
            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
              <div class="dropdown-header">
                Notifications
                <div class="float-right">
                  <a href="#">Mark All As Read</a>
                </div>
              </div>
              <div class="dropdown-list-content dropdown-list-icons">

              </div>
              <div class="dropdown-footer text-center">
                <a href="#">View All <i class="fas fa-chevron-right"></i></a>
              </div>
            </div>
          </li>
          <li class="dropdown"><a href="#" data-toggle="dropdown"
              class="nav-link dropdown-toggle nav-link-lg nav-link-user"> <img alt="image" src="<?php echo $mosy_nav___user_avatar ?>"
                class="user-img-radious-style shadow-sm"> <span class="d-sm-none d-lg-inline-block"></span></a>
            <div class="dropdown-menu dropdown-menu-right pullDown">
              <div class="dropdown-title">Hello <?php echo $mosy_nav___username ?></div>
              <a href="" class="dropdown-item has-icon"> <i class="far fa-user"></i> Profile  </a> 
              <div class="dropdown-divider"></div>
              <a href="" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
                        
                    
     <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="index.php"> <img alt="image" src="<?php echo $mep_app_logo ?>" class="header-logo" /> <span
                class="logo-name"><?php echo $mep_app_name ?></span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown">
              <a href="index.php" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
                           
       <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fa fa-book"></i><span>Courses</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="courses_list">View Courses</a></li>
            <li><a class="nav-link" href="courses_profile">Add Courses</a></li>
            <li><a class="nav-link" href="courses_list">Manage Courses</a></li>
          </ul>
        </li> 
                       
       <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fa fa-copy"></i><span>Lessons</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="lessons_list">View Lessons</a></li>
            <li><a class="nav-link" href="lessons_profile">Add Lessons</a></li>
            <li><a class="nav-link" href="lessons_list">Manage Lessons</a></li>
          </ul>
        </li> 
                       
       <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fa fa-bank"></i><span>Schools</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="schools_list">View Schools</a></li>
            <li><a class="nav-link" href="schools_profile">Add Schools</a></li>
            <li><a class="nav-link" href="schools_list">Manage Schools</a></li>
          </ul>
        </li> 
                       
       <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fa fa-users"></i><span>Students</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="students_list">View Students</a></li>
            <li><a class="nav-link" href="students_profile">Add Students</a></li>
            <li><a class="nav-link" href="students_list">Manage Students</a></li>
          </ul>
        </li> 
                       
       <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fa fa-database"></i><span>Payments</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="transactions_table_list">View Payments</a></li>
            <li><a class="nav-link" href="transactions_table_profile">Add Payments</a></li>
            <li><a class="nav-link" href="transactions_table_list">Manage Payments</a></li>
          </ul>
        </li> 
        
           
          </ul>
        </aside>
      </div>
                  