<nav class="navbar navbar-expand-md navbar-light p-0 <?php echo $nav_shadow_class; ?> fixed-top nav_bar_set">
    <a class="navbar-brand <?php echo $body_txt ?>" href="#">
        <img src="<?php echo $mep_app_logo ?>" class="mr-2" style="<?php  echo $mep_app_logo_style; ?>" /> <?php echo $mep_app_name_2; ?></a>
    <button class="navbar-toggler pt-2 border btn_neo rounded_big mr-2" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fa fa-bars text-white pt-1 pb-1"></i>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto pl-3 pb-2">
            <!--<li class="nav-item">
                <a class="nav-link" href="#">KCG Home </a>
            </li>-->
			<li class="nav-item pt-lg-3">
                <a class="nav-link mr-lg-4 ml-lg-5  " href="home"> <i class="fa fa-home"></i> Home </a>
            </li>
			<li class="nav-item pt-lg-3">
                <div class="nav-link mr-lg-4 mosy_msdn cpointer " data-mosy_msdn="qby_location()" > <i class="fa fa-map-marker"></i> Locations </div>
            </li>  
			<li class="nav-item pt-lg-3">
                <div class="nav-link mr-lg-4 mosy_msdn cpointer " data-mosy_msdn="qby_services()" > <i class="fa fa-bolt"></i> Services </div>
            </li>           
			<li class="nav-item pt-lg-3">
                <a class="nav-link mr-lg-4" href="allmodels"><i class="fa fa-users"></i> Our Models </a>
            </li>  
   
			<li class="nav-item pt-lg-3">
                <a class="nav-link mr-lg-4" href="contact"><i class="fa fa-phone"></i> Contact us</a>
            </li>  
  
  			<?php if(isset($_SESSION["session_model_login_logged"])){?>
  			<li class="nav-item pt-lg-3">
                <a class="nav-link mr-lg-4" href="model_editor"><i class="fa fa-shield"></i> My Account </a>
            </li>  
            <?php }else{?>
              		
             <li class="nav-item pt-lg-3">
                <a class="nav-link mr-lg-4" href="modelreg"><i class="fa fa-user-plus"></i> Create a Model Account </a>
            </li>  
                   
            <li class="nav-item pt-lg-3">
                <a class="nav-link mr-lg-4" href="model_login_login"><i class="fa fa-key"></i> Login </a>
            </li>  
            <?php }?>
        
<?php if(isset($_SESSION["session_model_login_logged"])){?>

<?php if(isset($_SESSION["session_kca__logged"])){?>

<?php if(isset($_SESSION["session_kca__logged"])){?>
<!--nav_nodes-->

<?php } ?>


<?php } ?>


<?php } ?>

        </ul>
        <div class="mr-2 pl-2 pb-3 pb-lg-0"> 
          <!--<img src="./img/logo.png" class="border" style="width: 40px; height: 40px; border-radius: 50%;" />-->
          
<?php 
  if(isset($_SESSION["session_model_login_logged"]))
  {
  $model_login_session_id=$_SESSION['session_model_login_logged_user_id'];
  
  $model_login_session_attr=magic_sql_row_data("model_list", "user_id='$model_login_session_id'", "primkey", "DESC");
  $login_img=magic_sql_row_data("file_uploads", "user_id='$model_login_session_id'", "primkey", "DESC");
  ?>
    <img src="<?php if($login_img['file_url']==""){ echo "./img/logo.png";}else{ echo $login_img['file_url']; };?>" class="border" style="width: 40px; height: 40px; border-radius: 50%;" />

  <?php 
   		echo 'Welcome '.$model_login_session_attr["name"].'  | <a href="model_login_sessionlogout.php">Logout</a> ';

   }?>
  
        </div>
    </div>
</nav>

