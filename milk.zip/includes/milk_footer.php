
<div id="dialog_box"></div>
<div id="ajax_snack"></div>
<div id="alert_box"></div>
<div id="magic_alert"></div>
<div id="snack_box"></div>
<!-- Bootstrap core JavaScript ========================== -->

    <!-- Placed at the end of the document so the pages load faster -->
    <script src="./js/jquery_main.js"></script>
    <script src="./js/popper.js"></script>
    <script src="./js/jsfunctions.js"></script>
    <script src="./js/boot.js"></script>
    <script src="./js/datahandler.js?v=<?php echo date("dmyhisa") ?>"></script>
    <script src="./js/wgt_datahandler.js?v=<?php echo date("dmyhisa") ?>"></script>
    <script src="./js/data_nodes.js?v=<?php echo date("dmyhisa") ?>"></script>
    <script src="./js/boot.js"></script>
    <script src="./js/ui_ux.js?v=<?php echo date("dmyhisa") ?>"></script>
  <!-- General JS Scripts -->
  <script src="milk/js/app.min.js"></script>
  <!-- JS Libraies -->
  <!-- Page Specific JS File -->
  <!-- Template JS File -->
  <script src="milk/js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="milk/js/custom.js"></script>
  
  <script>
	<?php if(isset($_GET['table_alert'])){?>
	mosy_snack_wgt('<?php echo $_GET['table_alert'] ?>', "top", "snack_box", "200px", "table_alert_toast", '<?php echo $btn_txt ?>',  '<?php echo $btn_bg ?>', '');
    mosytoggle_class('table_alert_toast', 'show');
                                          
	  setTimeout(function(){ 
        
       push_html('snack_box', '');                                          

          //your code here

        }, 3000);
    <?php }?>
</script>