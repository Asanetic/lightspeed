$function_name='push_item_count';
$ajax_post_vars='{"order_id":"?"}';
$php_write_here="//<!--next_ajax_str-->";
$js_write_here="//<!--next_ajax_str-->";
$ajax_init_str='magic_message("Processing...", "alert_box")';
$ajax_success_str='
//alert(data);
magic_message(data, "alert_box");
';


$ajax_php_url="./data_control/post_ajax.php";

$ajax_js_file="../js/ui_ux.js";

$post_sql_str='
$order_id=mysqli_real_escape_string($mysqliconn, $_POST["txt_order_id"]);

$count_cart_items=magic_sql_count("shopping_cart","*", " order_id='$order_id'");

echo $count_cart_items;';


	$json_post_params_decoded = json_decode($ajax_post_vars, true);


	$json_post_params_str=array();
	$arguments=array();
	$inputs_q=array();
      
	$tab_str='';
	$i=0;
	
	foreach ($json_post_params_decoded as $key => $value) 
	{
			$i++;
      		if($i>1)
            {
            	$tab_str="\t";
  
            }
			if($json_post_params_decoded[$key]=='?'){

              $json_post_params_str[]="".$tab_str."'txt_".$key."': txt_".$key."";
              $inputs_q[]=$tab_str.'var txt_'.$key.' =document.getElementById("txt_'.$key.'").value;';

            }else{
              
              $json_post_params_str[]="".$tab_str."'txt_".$key."': ".$json_post_params_decoded[$key]."";
              $arguments[]=$key;

            }

	}


	$ajax_post_params_array=implode(", ".PHP_EOL, $json_post_params_str);
	$ajax_arguments_str=implode(", ", $arguments);
	$ajax_inputs_str=implode(" ".PHP_EOL, $inputs_q);

	$ajaxstr='
    function '.$function_name.'('.$ajax_arguments_str.')
	{		
    '.$ajax_init_str.'
    
    '.$ajax_inputs_str.'
      $.ajax({ 
      url: \''.$ajax_php_url.'\',
      type: "POST",
      data: {
      		\''.$function_name.'\':\'OK\',
      		'.$ajax_post_params_array.'
      },

      success: function (data) {
		'.$ajax_success_str.'
      }
      
        });
    }
    //<!--next_ajax_str-->
';



$ajax_php_str ='if(isset($_POST["'.$function_name.'"]))
{
  
'.$post_sql_str.'
  
}
//<!--next_ajax_str-->
';

$new_post_ajax_file_str="<?php
include('./conn.php');  
include('./phpmagicbits.php');
include('./datafeed.php');

//<!--next_ajax_str-->

?>";

$new_ajax_js_file_str='//<!--next_ajax_str-->';

$ajax_php_actual_url=str_replace("./", "../", $ajax_php_url);

//====write to file 
  if (!file_exists($ajax_js_file)){

	bend_write_to_file($ajax_js_file, $new_ajax_js_file_str);
  
  }
  if (!file_exists($ajax_php_actual_url)){

	bend_write_to_file($ajax_php_actual_url, $new_post_ajax_file_str);
  }

bend_replace_file_section($ajax_js_file, $js_write_here, $ajaxstr);

bend_replace_file_section($ajax_php_actual_url, $php_write_here, $ajax_php_str);
