//=============create a count chart 

$tile_title="Test color slad kk";
$chart_table="jobs_board";
$x_column="done_status";
$y_column="done_status";
$file_path="../dashboard.php";
$chart_db_file='../chart_db.php';

$write_here="<!--<{ncgh}/>-->";

$chart_type="BarChart"; //;Doughnut | LineChart | BarChart | PieChart | Doughnut | ColumnChart | AreaChart
  
$chart_tile_class="col-md-5 shadow border chart_tray mr-lg-2";

$where_clause_var="";
$where_clause_sql="";

$wherestr="";
$wherevars="";

//========================================

if($where_clause_sql!=''){
$wherevars=$where_clause_var.';';
$wherestr='WHERE '.$where_clause_sql;
}

$piehole="";
if($chart_type=='Doughnut'){
$piehole='pieHole: 0.4,';
$chart_type='PieChart';
}
$linecolor="";
if($chart_type=='LineChart'){
$linecolor='colors: [\'<?php echo $buttonclr;?>\'],';
}

$write_dashbrd2=$file_path;
$write_dashbrd3=$file_path
  ;

$card_tile='
<div class="count_card">
<img src="./gstatic/graphcard.png" style="width:30px; height:30px; margin-right:10px;" />
'.$tile_title.' | <?php echo $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_count_res["0"];?> </div>';


$dash_card_sql='
//===========================Chart tile card '.$chart_table.' '.strtolower(str_replace(" ","_",$tile_title)).'========================
'.$wherevars.' $'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_query=mysqli_query($mysqliconn, "SELECT COUNT('.$y_column.') AS '.$y_column.'_count,  '.$x_column.'   FROM `$'.$dbname.'`.`'.$chart_table.'`  '.$wherestr.'  GROUP BY '.$x_column.' ");
//===========================Chart tile  card '.$chart_table.'  '.strtolower(str_replace(" ","_",$tile_title)).'========================

';
//echo "dash cur ".$curr_dash_file;



$chart_tilejs='
<script type="text/javascript" i>
      google.charts.setOnLoadCallback(drawChart_'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).');

      function drawChart_'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'() {

        var data = google.visualization.arrayToDataTable([
          [\''.ucwords(str_replace("_", " ", $x_column)).'\', \''.ucwords(str_replace("_", " ", $y_column)).'\',  { role: \'style\' }],
		  <?php while($'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_res=mysqli_fetch_array($'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_query)){
          echo \'[\\\'\'.$'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_res["'.$x_column.'"].\'\\\',     \'.$'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_res["'.$y_column.'_count"].\', \\\'\'.$buttonclr.\'\\\'],\';
		  }?>
        ]);

        var options = {
          title: \''.ucwords($tile_title).'\',
		  		   '.$piehole.'
				   '.$linecolor.'
		  curveType: \'function\',
      backgroundColor: {
        fill: \'<?php echo $skinclr;?>\',
        fillOpacity: 0.6
      },
		hAxis: {
    textStyle:{color: \'<?php echo $gentxtclr;?>\'}
			},
		vAxis: {
    	textStyle:{color: \'<?php echo $gentxtclr;?>\'}
		},
    legendTextStyle: { color: \'<?php echo $gentxtclr;?>\' },
    titleTextStyle: { color: \'<?php echo $gentxtclr;?>\' },
	        slices: {0: {color: \'<?php echo $buttonclr;?>\'},},
        };

        var chart = new google.visualization.'.$chart_type.'(document.getElementById(\'chart'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'\'));

        chart.draw(data, options);
      }
    </script>';
	

$new_chart_div='<div id="chart'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'" class="'.$chart_tile_class.'"></div>';
	
//========= replace text in a file_path

  if (!file_exists($chart_db_file))
  {
    bend_write_to_file($chart_db_file, '<?php //============newdbcard_query_chart=============?>');
  };

$db_file_replace='//============newdbcard_query_chart=============';
$db_file_replace_with=$dash_card_sql.'//============newdbcard_query_chart=============';

$js_replace='<!--chartscript-->';
$js_replace_with=$chart_tilejs.'<!--chartscript-->';

$chart_div_replace=$write_here;
$chart_div_replace_with=$new_chart_div;

bend_replace_file_section($file_path, $chart_div_replace, $chart_div_replace_with.$write_here);
bend_replace_file_section($file_path, $js_replace, $js_replace_with);
bend_replace_file_section($chart_db_file, $db_file_replace, $db_file_replace_with);

