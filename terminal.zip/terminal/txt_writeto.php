$additional_functions='

function sum_gen_trx_type($trx_type)
{
  
  global $fun_resonse;
  
  $fun_resonse=  magic_sql_sum("transactions", "amount", "trx_type=\'$trx_type\'");
  
  return $fun_resonse;
}
';

$function_file='../data_control/datafeed.php';

$add_functions_string="no";

$column_name_str_inc="business_id:Tab Name:null:<i class=\"fa fa-inbox\"></i> <?php echo tonum(sum_gen_trx_type('Gross Income'))?>";
$column_name_str="business_id:Tab Name:null:<i class=\"fa fa-inbox\"></i> <?php echo tonum(sum_gen_trx_type('Gross Income'))?>";
$column_name_str_knob="business_id:Tab Name:col-md-2:70000";
$column_name_strin_knob="business_id:Gross Income:col-md-2:tonum(sum_gen_trx_type('Gross Income'))";

//============================ Start Top buttons ============================

$chart_node=magic_form_tag('dp_button', $column_name_str_inc, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_button', $column_name_str, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_button', $column_name_str, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_button', $column_name_str, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_button', $column_name_str, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_button', $column_name_str, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_button', $column_name_str, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_button', $column_name_str, '', 'node', 'no', 'no', '');
//============================ End Top buttons ============================

//============================ Start start knobs ============================
$chart_node.='<div class="row justify-content-center col-md-12 mt-4 m-0 p-0">';
$chart_node.=magic_form_tag('dp_knob', $column_name_strin_knob, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_knob', $column_name_str_knob, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_knob', $column_name_str_knob, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_knob', $column_name_str_knob, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_knob', $column_name_str_knob, '', 'node', 'no', 'no', '');
$chart_node.=magic_form_tag('dp_knob', $column_name_str_knob, '', 'node', 'no', 'no', '');
$chart_node.='</div>';
//============================ End start knobs ============================

//available chart_types ==> Doughnut | LineChart | BarChart | PieChart | Doughnut | ColumnChart | AreaChart



// ======================== Graphs ====================
$chart_node.='<div class="row justify-content-center col-md-12 mt-4 m-0 p-0">';

$chart_node.='<!-- Start Chart ui Script and container -->
  <?php $clients_by_business=get_mosychart_data("transactions", "sum(amount) AS tot_bus_clients, business_id", "business_id!=\'\'", "business_id:qbusiness_data(\$chart_r[\'business_id\'])[\'business_name\']:Business Name", "tot_bus_clients:?:Business Income", "business_id");?>
 
  <script type="text/javascript"> google.charts.setOnLoadCallback(function() { draw_mosy_chart(<?php echo ($clients_by_business);?>, "clients_by_business", "ColumnChart", "Clients By Business"); }  );</script>
  
  <div id="clients_by_business" class="col-md-12 shadow border chart_tray mr-lg-2"></div>
  <!-- End Chart ui Script and container -->';

$chart_node.='<!-- Start Chart ui Script and container -->
  <?php $trx_by_month=get_mosychart_data("transactions", "sum(amount) AS tot_trx_by_month, business_id, trx_month_year", "business_id!=\'\'", "business_id:qbusiness_data(\$chart_r[\'business_id\'])[\'business_name\'].\' - Month \'.\$chart_r[\'trx_month_year\']:Business Month", "tot_trx_by_month:?:Business Income", "trx_month_year, business_id");?>
 
  <script type="text/javascript"> google.charts.setOnLoadCallback(function() { draw_mosy_chart(<?php echo ($trx_by_month);?>, "trx_by_month", "ColumnChart", "Tranactions By Month And business"); }  );</script>
  
  <div id="trx_by_month" class="col-md-12 shadow border chart_tray mr-lg-2"></div>
  <!-- End Chart ui Script and container -->';


$chart_node.='</div>';

// ======================== Graphs ====================

$dashfile_file="../dashbrd.php";

$write_here_str="nodebtns";

$create_new_file="yes";


///================================================= exe ==============================================================

if($add_functions_string=='yes')
{

  bend_replace_file_section($function_file, '//<--ncgh-->', $additional_functions.PHP_EOL.'//<--ncgh-->');

}

	if($dashfile_file!='')
	{
	
      if($create_new_file=='yes'){

        bend_write_to_file($dashfile_file, $chart_node.PHP_EOL);

      }else{

        replace_file_section($dashfile_file, $write_here_str, $chart_node.PHP_EOL.$write_here_str.PHP_EOL);

      }

	}

///================================================= exe ==============================================================
