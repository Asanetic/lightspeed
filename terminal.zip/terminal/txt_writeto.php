//dna options==
$dna_file_name="generate_mosy_select_query_fil___"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==

$file_path="../data_control/datahandler.php";
$write_here="//<--ncgh-->";
$create_new_file="no"; // yes || no

$mosy_queries="//===============Start Mosy queries-============";

$db_tables_list = mysqli_query($single_conn, "SHOW TABLES FROM `$dbname`");

while($db_tables_list_r=mysqli_fetch_array($db_tables_list))
{
      $curr_tbl= $db_tables_list_r[0];

      $keyquery = mysqli_query($single_conn, "SHOW COLUMNS FROM `$dbname`.`$curr_tbl`");

      $key_res = mysqli_fetch_array($keyquery);

      $label_node=ucwords(str_replace("_", " ", strtolower($key_res['Field'])));

      $tbl_key_arr[]=$key_res['Field'];

      $tbl_primkey=$tbl_key_arr[0];
 
  $mosy_queries.='
   //==Start '.$curr_tbl.' select query
      
     //==Single
        
      function mosynode_'.$curr_tbl.'($where_str)
      {

        return magic_sql_row_data(\''.$curr_tbl.'\', $where_str, "'.$tbl_primkey.'", "DESC");

      }
      
          //==Loop
      function mosyloop_'.$curr_tbl.'($where_str, $limit)
      {

        return magic_sql_select(\''.$curr_tbl.'\', $where_str, $limit, "'.$tbl_primkey.'", "DESC");

      }
   //==End '.$curr_tbl.' select query
 
 	//Start Add '.$curr_tbl.' Data ===============
 	function add_'.$curr_tbl.'($'.$curr_tbl.'_arr_)
    {
    
     return mosy_sqlarr_insert("'.$curr_tbl.'", $'.$curr_tbl.'_arr_);
    
    }
    
    //End Add '.$curr_tbl.' Data ===============
        
        
    //Start Update '.$curr_tbl.' Data ===============
    
 	function update_'.$curr_tbl.'($'.$curr_tbl.'_arr_, $where_str)
    {
    
     return mosy_sqlarr_insert("'.$curr_tbl.'", $'.$curr_tbl.'_arr_, $where_str);
    
    }
 	
    //End Update '.$curr_tbl.' Data ===============

    //Start get  '.$curr_tbl.' Data ===============
    
    function get_'.$curr_tbl.'($colstr, $where_str, $type)
    {
    
    	return mosyflex_sel("'.$curr_tbl.'", $colstr, $where_str, $type);
    
    }
    //End get  '.$curr_tbl.' Data ===============
    
    
  ';
}

$mosy_queries.='//===============End Mosy queries-============

//============= Start Sql chart  Script =====================

function get_mosychart_data($tbl, $colstr, $where_str, $xcol, $ycol, $groupby)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str="";
   $groupby_cols="";
   
   if($where_str!=\'\')
   {
     $fun_where_str=" WHERE ".$where_str;
   }
   
   if($groupby!=\'\')
   {
     $groupby_cols=" GROUP BY ".$groupby;
   }
   
   if (strpos($xcol, \':\') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, \':\') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ".$groupby_cols." ", \'\');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, \'{ role: \\\'style\\\' }\'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[\'\'.$ycol_column.\'\'];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[\'\'.$xcol_column.\'\'];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point==\'\')
     {
       $xcol_custom_data_point_pr="\'\'";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point==\'\')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================


//============= Start   mosy flex select script =====================

function mosyflex_sel($tbl, $colstr, $where_str, $loop_or_row_l_r)
{
   global $single_conn;
   global $single_db;
   global $flex_result;
   global $datalimit;
  
  $paginate_q="";
  $paginate_state="";
  
  $pagination_token=$tbl."_mpgtkn";
  
  $loop_or_row_l_rtype=$loop_or_row_l_r;
  
  if (strpos($loop_or_row_l_r, \':\') !== false)
  {
    $loop_or_row_l_r_str=explode(":", $loop_or_row_l_r);

    $pagination_token=$loop_or_row_l_r_str[1];

    $loop_or_row_l_rtype=$loop_or_row_l_r_str[0];
  }

  if (strpos($where_str, \'{{mpg}}\') !== false)
  {
    $paginate_state="paginate";
    
    $new_where_paginate_str=str_replace(\'{{mpg}}\', "", $where_str);

    $pagination_sql="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_paginate_str."";

    $process_pagination=mysqli_query($single_conn, $pagination_sql) or die(mysqli_error($single_conn));

    $paginate_q=mosy_paginate($process_pagination, $datalimit, $pagination_token);

    $new_where_str=str_replace(\'{{mpg}}\', " LIMIT ".$paginate_q[0].", $datalimit ", $where_str);

    $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_str."";

  }else{
    
      $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

  }
   
    
  $flex_result_q=mysqli_query($single_conn, $sql_str) or die(mysqli_error($single_conn));
  
  $flex_result=$flex_result_q;

  if($loop_or_row_l_rtype==\'r\')
  {
    $flex_result_r=mysqli_fetch_array($flex_result_q);
    
    $flex_result=$flex_result_r;
    
  }
  
  if($paginate_state==\'paginate\')
  {
  	$flex_result=array($flex_result_q, $paginate_q[1], $paginate_q[0]);  
  }
  
  return $flex_result;
  
}

function mosy_paginate($sqlstring, $reclimit, $token_name)
{

  $requested_page = isset($_GET[$token_name]) ? intval(base64_decode($_GET[$token_name])) : 1;

  $rows_count = mysqli_num_rows($sqlstring);

  $items_per_page = $reclimit;

  $page_count = ceil($rows_count / $items_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_row = ($requested_page - 1) * $items_per_page;

  $recordperpage_data=array($first_row,$page_count);

  return $recordperpage_data;
  
}
//============= End  mosy flex select script =====================


'.$write_here.'';

if($create_new_file=='yes')
{
  
   magic_write_to_file($file_path, '<?php '.PHP_EOL.$mosy_queries.PHP_EOL.'?>');
}else{
//========= replace text in a file_path

 bend_replace_file_section($file_path, $write_here, $mosy_queries);
}


  