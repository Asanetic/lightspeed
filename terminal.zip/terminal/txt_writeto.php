//dna options==
$dna_file_name="dash_generate_stats_board___dashboa___"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==

$additional_functions='

function tot_clients($wherestr)
{
  
  global $fun_resonse;
  
   $fun_resonse=magic_sql_count("clients", "*", $wherestr);
	

  return $fun_resonse;
}

function sum_trx_by_month($month, $trx_type)
{

  global $fun_resonse;
  
   $fun_resonse=magic_sql_sum("transactions", "amount", "trx_month_year=\'$month\' AND trx_type=\'$trx_type\'");
	

  return $fun_resonse;

}

function net_month_bal($month)
{
$incstr=sum_trx_by_month($month, "Gross Income");
$deductstr=sum_trx_by_month($month, "Other Deductions");
$expstr=sum_trx_by_month($month, "Expenses");


return $incstr-($deductstr+$expstr);
}
function count_tabs()
{
  
  global $fun_resonse;
  
   $fun_resonse=magic_sql_count("businesses", "*", "");
  
  return $fun_resonse;
}
';

$function_file='../data_control/datafeed.php';

$add_functions_string="no";

//============================ Start Top buttons ============================


$chart_node='
<div class="mr-lg-2  mt-1 rounded  text-center mb-2 p-2 skin_plasma pr-4 pl-4" style="border-bottom:5px solid <?php echo $btn_bg ?>;"  >
  <i class="fa fa-users"></i> Total Clients <?php echo tonum(tot_clients("")); ?>
</div>';
$chart_node.='
<div class="mr-lg-2  mt-1 rounded  text-center mb-2 p-2 skin_plasma pr-4 pl-4" style="border-bottom:5px solid <?php echo $btn_bg ?>;"  >
  <i class="fa fa-inbox"></i>  Income <?php echo tonum(sum_all_trx_type("Gross Income")); ?>
</div>';
$chart_node.='
<div class="mr-lg-2  mt-1 rounded  text-center mb-2 p-2 skin_plasma pr-4 pl-4" style="border-bottom:5px solid <?php echo $btn_bg ?>;"  >
  <i class="fa fa-outbox"></i>  Deductions <?php echo tonum(sum_all_trx_type("Other Deductions")); ?>
</div>';
$chart_node.='
<div class="mr-lg-2  mt-1 rounded  text-center mb-2 p-2 skin_plasma pr-4 pl-4" style="border-bottom:5px solid <?php echo $btn_bg ?>;"  >
  <i class="fa fa-wrench"></i>  Expenses <?php echo tonum(sum_all_trx_type("Expenses")); ?>
</div>';

$chart_node.='
<div class="mr-lg-2  mt-1 rounded  text-center mb-2 p-2 skin_plasma pr-4 pl-4" style="border-bottom:5px solid <?php echo $btn_bg ?>;"  >
  <i class="fa fa-plus"></i> Net Deductions <?php echo tonum(sum_all_trx_type("Expenses")+sum_all_trx_type("Other Deductions")); ?>
</div>';
$chart_node.='
<div class="mr-lg-2  mt-1 rounded  text-center mb-2 p-2 skin_plasma pr-4 pl-4" style="border-bottom:5px solid <?php echo $btn_bg ?>;"  >
  <i class="fa fa-balance-scale"></i> Net Balance <?php echo tonum(all_net_trx()); ?>
</div>';



//============================ End Top buttons ============================

//============================ Start start knobs ============================
$chart_node.='<div class="row justify-content-center col-md-12 mt-4 m-0 p-0">';

$chart_node.='
  		<div class="row justify-content-center col-md-2">
			<div class=" skin_plasma p-3 text-center">
               <!-- progress circles -->
               <div class="stats_knob rounded-circle p-3 mr-lg-3 mb-4 pt-4 shadow"  style="height: 150px; width: 150px;">
  			    <h5 class="text-center pt-3"> <?php echo  tonum(count_tabs()) ?></h5>
                <h6 class="text-center">Tabs</h6>
               </div>
              <!-- progress circles -->
  			</div>
          </div>';

$chart_node.='
  		<div class="row justify-content-center col-md-2">
			<div class=" skin_plasma p-3 text-center">
               <!-- progress circles -->
               <div class="stats_knob rounded-circle p-3 mr-lg-3 mb-4 pt-4 shadow"  style="height: 150px; width: 150px;">
  			    <h5 class="text-center pt-3"><?php echo tonum(sum_trx_by_month(date("m-Y"), "Gross Income")) ?></h5>
                <h6 class="text-center">Income This Month</h6>
               </div>
              <!-- progress circles -->
  			</div>
          </div>';
$chart_node.='
  		<div class="row justify-content-center col-md-2">
			<div class=" skin_plasma p-3 text-center">
               <!-- progress circles -->
               <div class="stats_knob rounded-circle p-3 mr-lg-3 mb-4 pt-4 shadow"  style="height: 150px; width: 150px;">
  			    <h5 class="text-center pt-3"><?php echo tonum(sum_trx_by_month(date("m-Y"), "Expenses")) ?></h5>
                <h6 class="text-center">Expenses This Month</h6>
               </div>
              <!-- progress circles -->
  			</div>
          </div>';

$chart_node.='
  		<div class="row justify-content-center col-md-2">
			<div class=" skin_plasma p-3 text-center">
               <!-- progress circles -->
               <div class="stats_knob rounded-circle p-3 mr-lg-3 mb-4 pt-4 shadow"  style="height: 150px; width: 150px;">
  			    <h5 class="text-center pt-3"><?php echo tonum(sum_trx_by_month(date("m-Y"), "Other Deductions")) ?></h5>
                <h6 class="text-center">Other Deductions this Month</h6>
               </div>
              <!-- progress circles -->
  			</div>
          </div>';


$chart_node.='
  		<div class="row justify-content-center col-md-2">
			<div class=" skin_plasma p-3 text-center">
               <!-- progress circles -->
               <div class="stats_knob rounded-circle p-3 mr-lg-3 mb-4 pt-4 shadow"  style="height: 150px; width: 150px;">
  			    <h5 class="text-center pt-3"><?php echo tonum(sum_trx_by_month(date("m-Y"), "Expenses")+sum_trx_by_month(date("m-Y"), "Other Deductions")) ?></h5>
                <h6 class="text-center">Total Deductions</h6>
               </div>
              <!-- progress circles -->
  			</div>
          </div>';

$chart_node.='
  		<div class="row justify-content-center col-md-2">
			<div class=" skin_plasma p-3 text-center">
               <!-- progress circles -->
               <div class="stats_knob rounded-circle p-3 mr-lg-3 mb-4 pt-4 shadow"  style="height: 150px; width: 150px;">
  			    <h5 class="text-center pt-3"><?php echo tonum(net_month_bal(date("m-Y"))); ?></h5>
                <h6 class="text-center">Balance</h6>
               </div>
              <!-- progress circles -->
  			</div>
          </div>';

$chart_node.='</div>';
//============================ End start knobs ============================

//available chart_types ==> Doughnut | LineChart | BarChart | PieChart | Doughnut | ColumnChart | AreaChart



// ======================== Graphs ====================
$chart_node.='<div class="row justify-content-center col-md-12 mt-4 m-0 p-0">';

$chart_node.='
<!-- Start  Title ribbon-->
<h4 class="col-md-12 row p-2 justify-content-center">
  <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>
  <div class="col-md-3 mr-lg-2 ml-lg-2 text-center"> Charts</div>
  <div class="col-md-4 bg-dark mt-3" style="height: 1px"></div>
</h4>
<!-- End Title ribbon-->

<!-- Start Chart ui Script and container -->
  <?php $trxinc_bymonth=get_mosychart_data("transactions", "sum(amount) AS tot_month_trx, trx_month_year", "trx_type=\'Gross Income\'", "trx_month_year:?:Month Name", "tot_month_trx:?:Business Income", "trx_month_year  ORDER BY primkey DESC");?>
 
  <script type="text/javascript"> google.charts.setOnLoadCallback(function() { draw_mosy_chart(<?php echo ($trxinc_bymonth);?>, "trxinc_bymonth", "ColumnChart", "Income By Month"); }  );</script>
  
  <div id="trxinc_bymonth" class="col-md-12  border chart_tray"></div>
  <!-- End Chart ui Script and container -->
  
  
  <!-- Start Chart ui Script and container -->
  <?php $trxbytab=get_mosychart_data("transactions", "sum(amount) AS tot_bus_trx, business_id", "trx_type=\'Gross Income\'", "business_id:qbusiness_data(\$chart_r[\'business_id\'])[\'business_name\']:Business Name", "tot_bus_trx:?:Business Income", "business_id");?>
 
  <script type="text/javascript"> google.charts.setOnLoadCallback(function() { draw_mosy_chart(<?php echo ($trxbytab);?>, "trxbybus", "BarChart", "Income By Tab"); }  );</script>
  
  <div id="trxbybus" class="col-md-6  border chart_tray"></div>
  <!-- End Chart ui Script and container -->
  
  <!-- Start Chart ui Script and container -->
  <?php $trxbytab_exp=get_mosychart_data("transactions", "sum(amount) AS tot_bus_exp, business_id", "trx_type=\'Other Deductions\' OR trx_type=\'Expenses\'", "business_id:qbusiness_data(\$chart_r[\'business_id\'])[\'business_name\']:Business Name", "tot_bus_exp:?:Business Income", "business_id");?>
 
  <script type="text/javascript"> google.charts.setOnLoadCallback(function() { draw_mosy_chart(<?php echo ($trxbytab_exp);?>, "tot_bus_exp", "BarChart", "Expenses By Tab"); }  );</script>
  
  <div id="tot_bus_exp" class="col-md-6  border chart_tray"></div>
  <!-- End Chart ui Script and container -->
  
  <!-- Start Chart ui Script and container -->
  <?php $trxbyremark=get_mosychart_data("transactions", "sum(amount) AS tot_trx_remark, trx_remark", "trx_type=\'Gross Income\'", "trx_remark:?:Activity", "tot_trx_remark:?:Income By Activity", "trx_remark");?>
 
  <script type="text/javascript"> google.charts.setOnLoadCallback(function() { draw_mosy_chart(<?php echo ($trxbyremark);?>, "trxbyremark", "ColumnChart", "Income By Activity"); }  );</script>
  
  <div id="trxbyremark" class="col-md-6  border chart_tray"></div>
  <!-- End Chart ui Script and container -->
  
    <!-- Start Chart ui Script and container -->
  <?php $trxbyremark_exp=get_mosychart_data("transactions", "sum(amount) AS tot_trx_remark, trx_remark", "trx_type=\'Other Deductions\' OR trx_type=\'Expenses\'", "trx_remark:?:Activity", "tot_trx_remark:?:Expense By Activity", "trx_remark");?>
 
  <script type="text/javascript"> google.charts.setOnLoadCallback(function() { draw_mosy_chart(<?php echo ($trxbyremark_exp);?>, "trxbyremark_exp", "ColumnChart", "Expense By Activity"); }  );</script>
  
  <div id="trxbyremark_exp" class="col-md-6  border chart_tray"></div>
  <!-- End Chart ui Script and container -->
  ';

$chart_node.='</div>';

// ======================== Graphs ====================

$dashfile_file="../dash_stats_main.php";

$write_here_str="nodebtns";

$create_new_file="yes";


///================================================= exe ==============================================================

if($add_functions_string=='yes')
{

  bend_replace_file_section($function_file, '//<--ncgh-->', $additional_functions.PHP_EOL.'//<--ncgh-->');

}

	if($dashfile_file!='')
	{
	
      if($create_new_file=='yes'){

        bend_write_to_file($dashfile_file, $chart_node.PHP_EOL);

      }else{

        replace_file_section($dashfile_file, $write_here_str, $chart_node.PHP_EOL.$write_here_str.PHP_EOL);

      }

	}

///================================================= exe ==============================================================
