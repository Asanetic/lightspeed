<?php
header("Content-Type:application/json");

//====================== GET RESPONSE JSON DATA FROM CURL; COMMENT THIS LINE WHEN USING SAMPLE DATA ==========

//$paybilljson = file_get_contents('php://input');

//====================== GET RESPONSE JSON DATA FROM CURL; COMMENT THIS LINE WHEN USING SAMPLE DATA ==========


//====================== SAMPLE JSON DATA FROM CURL; COMMENT THIS LINE WHEN USING lIVE DATA ==========
   $paybilljson='{
             "TransactionType": "Pay Bill",
             "TransID": "TEST-SANDBOX",
             "TransTime": "'.date("d-m-Y h:i:s").'",
             "TransAmount": "10000.00",
             "BusinessShortCode": "XXX-XXX-XXX",
             "BillRefNumber": "EBK-5N02",
             "InvoiceNumber": "EBK-5N02",
             "OrgAccountBalance": "000.00",
             "ThirdPartyTransID": "0",
             "MSISDN": "+254-000-000-000",
             "FirstName": "ASANETIC",
             "MiddleName": "TECHNOLOGIES",
             "LastName": "INC."
         }';
        
//====================== SAMPLE JSON DATA FROM CURL; COMMENT THIS LINE WHEN USING lIVE DATA ==========


            
//====================== GET JSON DATA  FROM DECODED JSON ARRAY ==========

$trx_record = json_decode($paybilljson, true);

$tr_type=$trx_record['TransactionType'];
$trans_id=$trx_record['TransID'];
$TransTime=$trx_record['TransTime'];
$TransAmount=$trx_record['TransAmount'];
$BusinessShortCode=$trx_record['BusinessShortCode'];
$BillRefNumber=$trx_record['BillRefNumber'];
$OrgAccountBalance=$trx_record['OrgAccountBalance'];
$ThirdPartyTransID=$trx_record['ThirdPartyTransID'];
$MSISDN=$trx_record['MSISDN'];
$FirstName=$trx_record['FirstName'];
$MiddleName=$trx_record['MiddleName'];
$LastName=$trx_record['LastName'];

//====================== GET JSON DATA  FROM DECODED JSON ARRAY ==========


//====================== GET BillRefNumber PREFIX AND SUFFIX ==========
$explode_BillRefNumber=explode("-",$BillRefNumber);
$BillRefNumber_prefix=$explode_BillRefNumber[0];
$BillRefNumber_suffix=$explode_BillRefNumber[1];
$sub_type="N/a";
if($BillRefNumber_prefix=='C')
{
  $sub_type="Client";
}

if($BillRefNumber_prefix=='T')
{
  $sub_type="Tech";
}


//====================== GET BillRefNumber PREFIX AND SUFFIX ==========


$curlopt_post_fields ='
process_payment&txt_user_id='.$BillRefNumber.'
&txt_ref_no='.$trans_id.'
&txt_trx_date='.$TransTime.'
&txt_amount_paid='.$TransAmount.'
&txt_payment_mode=MPESA
&txt_sub_type='.$TransAmount.'';

$curlopt_url='./data_control/billingalgo.php';

magic_post_curl($curlopt_url, '', '', $curlopt_post_fields, 'POST');

?>
