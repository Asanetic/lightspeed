  //echo magic_basename(  magic_current_url());  

$url_path=explode("/", magic_current_url());

echo $url_path[2]