$_SESSION['dna_session']='dna';
