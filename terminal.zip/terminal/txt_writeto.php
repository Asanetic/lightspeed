//===create app frame
$tbl='transactions';
$page_title='User Profile';
$newfile_name='../business_profile.php';
$loop_name="user_trx";

//function to go with data if they dont exist

$additional_functions='


//======================== Start '.$tbl.' Functions =============


//======================== End '.$tbl.' Functions =============
';

$add_functions_string="no";

//************grid Values  "column_name":"Label / header title : data function"
//

$fileds_n_values_json='
{
"trx_id":"?",
"trx_date":"?",
"trx_remark":"?",
"amount":"?",
"trx_type":"?",
"business_id":"Tab Name:qbusiness_data($'.$loop_name.'_r[\'business_id\'])[\'business_name\'];",
"TransactionType":"?",
"BillRefNumber":"?",
"MSISDN":"?",
"Names":"Names:$'.$loop_name.'_r[\'FirstName\'].\' \'.$'.$loop_name.'_r[\'MiddleName\'].\' \'.$'.$loop_name.'_r[\'MiddleName\'];",
"trx_msg":"Message:magic_strip_if($'.$loop_name.'_r[\'trx_msg\'], 30, 30);"
}
';

$profile_newfile_name='./transaction_profile.php';


$mosy_table_str="transactions:User Transactions:".$loop_name.":*:WHERE business_id='\$currbusid' ORDER BY primkey DESC:".$profile_newfile_name.":\$currbusid=\$businesses_node['business_id'];";


$edit_key='primkey';
$function_file='../data_control/datafeed.php';
$add_to_cruds="yes";

//====================== handle image ui
$image_column='';
$image_style="height:80px; width:80px; border-radius:50%;";

//====================== handle image ui

$write_here='<!--<{ncgh}/>-->';

$plain_link='yes';
$linkcol='trx_id';
$create_new_file="no";


//================================= app exe 


//************************************ create grid  *******************************************

//table list 

create_table_ui($newfile_name, $fileds_n_values_json, $mosy_table_str, $create_new_file, $edit_key, $plain_link, $linkcol,$write_here);


$old_image_cell='<td scope="col"><?php echo $'.$loop_name.'_["'.$image_column.'"];?></td>';


$new_image_cell='<td scope="col">
					<img src="<?php if($list'.$tbl.'_result["'.$image_column.'"]==""){ echo $mep_app_logo; }else{ echo $list'.$tbl.'_result["'.$image_column.'"];}?>" style="'.$image_style.'"/>
                 </td>';

if($image_column!='')
{
bend_replace_file_section($file_path, $old_image_cell, $new_image_cell);
}


if($add_functions_string=='yes')
{
  
	bend_replace_file_section($function_file, '//<--ncgh-->', $additional_functions.PHP_EOL.'//<--ncgh-->');
  
}
echo "<br>Mini List Created to ".$newfile_name."- ".date('Y-m-d h:i:s A');

//***************************************************************** Create grid ********************************88

