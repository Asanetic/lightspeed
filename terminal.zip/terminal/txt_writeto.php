$file_path="../js/datahandler.js";
$write_here="//<--ncgh-->";
$create_new_file="yes"; // yes || no
$delete_existing_file="yes";

$mosy_queries="//===============Start Mosy queries-============";

$db_tables_list = mysqli_query($single_conn, "SHOW TABLES FROM `$dbname`");

while($db_tables_list_r=mysqli_fetch_array($db_tables_list))
{
  
      $curr_tbl= $db_tables_list_r[0];

      $keyquery = mysqli_query($single_conn, "SHOW COLUMNS FROM `$dbname`.`$curr_tbl`");

  		$tbl_key_arr=array();
  		$magic_where_str=array();
		$upload_function="";
  
      while($key_res = mysqli_fetch_array($keyquery)){
  
      $tbl_key_arr[]=$key_res['Field'];

      $tbl_primkey=$tbl_key_arr[0];
 
      }
  
  $mosy_queries.=' 

    //Start get  '.$curr_tbl.' Data ===============
    
      function get_'.$curr_tbl.'('.$curr_tbl.'_colstr, '.$curr_tbl.'_filter_col, '.$curr_tbl.'_cols, '.$curr_tbl.'_node_function_name, '.$curr_tbl.'_callback_function_string, '.$curr_tbl.'_ui_tag)
      {
        mosyflex_sel("'.$curr_tbl.'", '.$curr_tbl.'_colstr, '.$curr_tbl.'_filter_col , '.$curr_tbl.'_cols, '.$curr_tbl.'_node_function_name, '.$curr_tbl.'_callback_function_string, '.$curr_tbl.'_ui_tag);
        
      }
    //End get  '.$curr_tbl.' Data ===============
    

  ';
}

$mosy_queries.='//===============End Mosy queries-============


var ajax_url ="./finajax.php";

   //Ajax Manager
function mosyflex_sel(tbl, colstr, filter_col , cols, node_function_name, callback_function_string, ui_tag)
{
    var json_params_str={"mosyajax_sql_data":filter_col, "colstr":colstr, "cols":cols, "node_function_name":node_function_name, "tbl":tbl, "ui_tag":ui_tag};
   
  	//alert(json_params_str);
  
	mosy_ajax_post(ajax_url, json_params_str, callback_function_string, "");
}

function push_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  document.getElementById("result").innerHTML=server_resp;
}

function mosy_ajax_post(post_url, json_params, callback_function_string, additional_callbacks)
{

  var formData = ((json_params)); //Array 
  
      $.ajax({ 
      url: post_url,
      type: "POST",
      data:formData,

      success: function (data) 
      {
        window[callback_function_string](data, additional_callbacks);

      }

  })

}
'.$write_here.'';

if($create_new_file=='yes')
{
if($delete_existing_file=='yes')
{
  Recycle($file_path);
}
   magic_write_to_file($file_path, ' '.PHP_EOL.$mosy_queries.PHP_EOL.'');
}else{
//========= replace text in a file_path

 bend_replace_file_section($file_path, $write_here, $mosy_queries);
}


  