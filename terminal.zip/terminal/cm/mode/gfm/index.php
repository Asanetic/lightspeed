<!doctype html>

<title>CodeMirror: GFM mode</title>
<meta charset="utf-8"/>
<link rel=stylesheet href="../../doc/docs.css">

<link rel="stylesheet" href="../../lib/codemirror.css">
<script src="../../lib/codemirror.js"></script>
<script src="../../addon/mode/overlay.js"></script>
<script src="../xml/xml.js"></script>
<script src="../markdown/markdown.js"></script>
<script src="gfm.js"></script>
<script src="../javascript/javascript.js"></script>
<script src="../css/css.js"></script>
<script src="../htmlmixed/htmlmixed.js"></script>
<script src="../clike/clike.js"></script>
<script src="../meta.js"></script>
<style>
  .CodeMirror {border-top: 1px solid black; border-bottom: 1px solid black;}
  .cm-s-default .cm-emoji {color: #009688;}
</style>
<div id=nav>
  <a href="https://codemirror.net"><h1>CodeMirror</h1><img id=logo src="../../doc/logo.png" alt=""></a>

  <ul>
    <li><a href="../../index.php">Home</a>
    <li><a href="../../doc/manual.php">Manual</a>
    <li><a href="https://github.com/codemirror/codemirror">Code</a>
  </ul>
  <ul>
    <li><a href="../index.php">Language modes</a>
    <li><a class=active href="#">GFM</a>
  </ul>
</div>

<article>
<h2>GFM mode</h2>
<form><textarea id="code" name="code">
GitHub Flavored Markdown
========================

Everything from markdown plus GFM features:

## URL autolinking

Underscores_are_allowed_between_words.

## Strikethrough text

GFM adds syntax to strikethrough text, which is missing from standard Markdown.

~~Mistaken text.~~
~~**works with other formatting**~~

~~spans across
lines~~

## Fenced code blocks (and syntax highlighting)

```javascript
for (var i = 0; i &lt; items.length; i++) {
    console.log(items[i], i); // log them
}
```

## Task Lists

- [ ] Incomplete task list item
- [x] **Completed** task list item

## A bit of GitHub spice

See http://github.github.com/github-flavored-markdown/.

(Set `gitHubSpice: false` in mode options to disable):

* SHA: be6a8cc1c1ecfe9489fb51e4869af15a13fc2cd2
* User@SHA ref: mojombo@be6a8cc1c1ecfe9489fb51e4869af15a13fc2cd2
* User/Project@SHA: mojombo/god@be6a8cc1c1ecfe9489fb51e4869af15a13fc2cd2
* \#Num: #1
* User/#Num: mojombo#1
* User/Project#Num: mojombo/god#1

(Set `emoji: false` in mode options to disable):

* emoji: :smile:


</textarea></form>

    <script>
      var editor = CodeMirror.fromTextArea(document.getElementById("code"), {
        mode: {
          name: "gfm",
          tokenTypeOverrides: {
            emoji: "emoji"
          }
        },
        lineNumbers: true,
        theme: "default"
      });
    </script>

    <p>Optionally depends on other modes for properly highlighted code blocks.</p>

    <p>Gfm mode supports these options (apart those from base Markdown mode):</p>
    <ul>
      <li>
        <d1>
          <dt><code>gitHubSpice: boolean</code></dt>
          <dd>Hashes, issues... (default: <code>true</code>).</dd>
        </d1>
      </li>
      <li>
        <d1>
          <dt><code>taskLists: boolean</code></dt>
          <dd><code>- [ ]</code> syntax (default: <code>true</code>).</dd>
        </d1>
      </li>
      <li>
        <d1>
          <dt><code>strikethrough: boolean</code></dt>
          <dd><code>~~foo~~</code> syntax (default: <code>true</code>).</dd>
        </d1>
      </li>
      <li>
        <d1>
          <dt><code>emoji: boolean</code></dt>
          <dd><code>:emoji:</code> syntax (default: <code>true</code>).</dd>
        </d1>
      </li>
    </ul>

    <p><strong>Parsing/Highlighting Tests:</strong> <a href="../../test/index.php#gfm_*">normal</a>,  <a href="../../test/index.php#verbose,gfm_*">verbose</a>.</p>

  </article>
