<?php
ob_start();

include('./appdbconfig.php');

include('./svrconn.php');

include("./phpmagicbits.php");


function help()
{
return "Type echo fend_help(); for front end and echo bend_help(); for back end";
}

include("./phpmagicui.php");
include("./phpmagicbackend.php");




  //error handler function

  function customError($errno, $errstr) {
    echo "<b>Error:</b> [$errno] $errstr<hr>".help();
  }

  //set error handler
  //set_error_handler("customError");
if(isset($_POST['switch_dna_session']))
{
    $_SESSION['dna_session']=$_POST['switch_dna_input'];

}

if(isset($_POST['execute_terminal']))
{

  
      $file_to_write = fopen($_POST['txt_directory'], 'w') or die("can't open file");
      fwrite($file_to_write, "<?php ".$_POST['txt_new_code']."?>");
      fclose($file_to_write);

     // echo "Input : ".$_POST['txt_new_code'].'<hr style="border : 1px solid #7f7e7e">Output : ';
      echo '<hr style="border : 1px solid #7f7e7e">Output : <br>--------<br> ';

      include(($_POST['txt_directory']));
  
      if(isset($create_dna))
      {

      $dna_app_name=str_replace(" ", "", strtolower($ls_application_name));
      $new_dna_file_name='../appdna/'.$dna_app_name."_".$dna_file_name.'.lsdna';
      $new_dna_file_name_w_date='../appdna/'.$dna_app_name."_".$dna_file_name.'_'.date("dmyhsa").'.lsdna';

        if($create_dna=='yes')
        {
           if (!file_exists('../appdna')) @mkdir('../appdna');

       if($overwrite_dna_file=='yes')
           {
            file_put_contents($new_dna_file_name, ($_POST['txt_new_code']));
           }else{

          file_put_contents($new_dna_file_name_w_date, ($_POST['txt_new_code']));

        }
        }
    }
          

}

if(isset($_POST["pop_db_tables"])){
  
$tbl_cards="";
  
$db_tables_list = mysqli_query($single_conn, "SHOW TABLES FROM `$dbname`");

while($db_tables_list_r=mysqli_fetch_array($db_tables_list))
{

  $curr_tbl= $db_tables_list_r[0];

      $keyquery = mysqli_query($single_conn, "SHOW COLUMNS FROM `$single_db`.`$curr_tbl`");

      $key_res = mysqli_fetch_array($keyquery);

      $label_node=ucwords(str_replace("_", " ", strtolower($key_res['Field'])));

      $tbl_key_arr[]=$key_res['Field'];

      $tbl_primkey=$tbl_key_arr[0];

      $post_params=gen_sql_params("", magic_sql_array_cols($curr_tbl), $curr_tbl." Vars", 'no', 'skip_parma_write', 'post');
      $sql_insert_str= insert_update_str("", magic_sql_array_cols($curr_tbl),  $curr_tbl." Vars", $dbname, $curr_tbl, $tbl_primkey, 'no', "", "ins");
      $sql_update_str= insert_update_str("", magic_sql_array_cols($curr_tbl),  $curr_tbl." Vars", $dbname, $curr_tbl, $tbl_primkey, 'no', "", "upd");
      $select_like_str= full_bend_select_str($dbname, $curr_tbl, "",  magic_sql_array_cols($curr_tbl), "", "no", $tbl_primkey, "DESC", $curr_tbl." Select");
      $filter_sel_like_str=sql_select_strings($dbname, $curr_tbl, "", magic_sql_array_cols($curr_tbl), "", "no", $tbl_primkey, "DESC", $curr_tbl."  Single Select", 'like');
      $filter_sel_single_str=sql_select_strings($dbname, $curr_tbl, "", magic_sql_array_cols($curr_tbl), "", "no", $tbl_primkey, "DESC", $curr_tbl."  Single Select", 'single');

      $delete_log_str=create_del_str("",  $curr_tbl." Delete query", $dbname, $curr_tbl, "", $tbl_primkey, "no");


 $tbl_cards.= '<div class="function_card">
 <div class="function_card" style="margin-bottom:10px;">
         <div ><span style="font-style:italic; font-size:16px;  color:#FFF; padding:7px;"><u><b> Table - '.strtoupper($curr_tbl).'</span></b></u></div>
 <br> Table <b><span  onclick="load_to_editor(this.innerHTML)" >'.$curr_tbl.'</span></b> | <span onclick="load_to_editor(\'$'.$curr_tbl.'_uptoken\')" >Token</span> 
 | <span onclick="load_to_editor(\'$'.$curr_tbl.'_node\')" >Node </span>
 | <span onclick="load_to_editor(\'$q'.$curr_tbl.'\')" >Query </span>
 | <span onclick="load_to_editor(\'$list'.$curr_tbl.'_result\')" >List_Node </span>
 | <span onclick="load_to_editor(\''.$curr_tbl.'_mosyfilter=<?php echo base64_encode()?>\')" >Mosy_Filter </span>
 | <span onclick="load_to_editor(\''.$curr_tbl.'_mosyfilter=\\\'.base64_encode().\\\'\')" >Nt_Mosy_Filter </span>
 </div>
 <br>';
    $while_loop='
      <?php 
      $pagination_record_count=$'.$curr_tbl.'_pgcount;
          $i=0;
        
        //<--outloop-dope-->

      while($list'.$curr_tbl.'_result=mysqli_fetch_array($'.$curr_tbl.'_list_query)){
        $i++;

        //<--inloop-dope-->

        ?>
            //add your ui here;

       <?php }?>';
  $mosy_filter='if(isset($_GET[&quot;'.$curr_tbl.'_mosyfilter&quot;])){

  $'.$curr_tbl.'_passed_filter=(base64_decode($_GET[&quot;'.$curr_tbl.'_mosyfilter&quot;]));
//===== limit record value

  //echo magic_message($'.$curr_tbl.'_passed_filter);

$'.$curr_tbl.'_sqlstring=&quot;SELECT COUNT(*) FROM `$'.$dbname.'`.`'.$curr_tbl.'` WHERE &quot;.$'.$curr_tbl.'_passed_filter.&quot;&quot;;
 //===== Pagination function

$'.$curr_tbl.'_pagination= list_record_per_page($mysqliconn, $'.$curr_tbl.'_sqlstring, $datalimit);


//===== get return values


$'.$curr_tbl.'_firstproduct=$'.$curr_tbl.'_pagination[&quot;0&quot;];

$'.$curr_tbl.'_pgcount=$'.$curr_tbl.'_pagination[&quot;1&quot;];

//=== start '.$curr_tbl.' select  Like Query String '.$curr_tbl.' list  

$'.$curr_tbl.'_list_query=mysqli_query($mysqliconn, &quot;SELECT * FROM `$'.$dbname.'`.`'.$curr_tbl.'`  WHERE &quot;.$'.$curr_tbl.'_passed_filter.&quot;  ORDER BY `'.$tbl_primkey.'` DESC LIMIT $'.$curr_tbl.'_firstproduct, $datalimit&quot; );

//$'.$curr_tbl.'_list_res=mysqli_fetch_array($'.$curr_tbl.'_list_query);

//=== End '.$curr_tbl.' select  Like Query String '.$curr_tbl.' list

}';
  
  $tbl_arr=mosy_sql_arr("", magic_sql_array_cols($curr_tbl) , $curr_tbl.'_arr', "", "", "?");
  $tbl_post_arr=mosy_sql_arr("", magic_sql_array_cols($curr_tbl) , $curr_tbl.'_post_arr', "", "", "post");
  
  $insert_function_str='
  function add_'.$curr_tbl.'($'.$curr_tbl.'_arr_)
  {
    return mosy_sqlarr_insert("'.$curr_tbl.'", $'.$curr_tbl.'_arr_);
  }
  
  function update_'.$curr_tbl.'($'.$curr_tbl.'_arr_, $where_str)
  {
    return mosy_sqlarr_update("'.$curr_tbl.'", $'.$curr_tbl.'_arr_, $where_str);
  }
  
  ';
  
  $isset_function_str='
  
    //Start Execute '.$curr_tbl.' data on sql isset Command
  if(isset($_[""])){
    
    '.$tbl_arr.'
        
     //$'.$curr_tbl.'_return_key=add_'.$curr_tbl.'($'.$curr_tbl.'_arr_);
     //$'.$curr_tbl.'_return_key=update_'.$curr_tbl.'($'.$curr_tbl.'_arr_, "");
    
           header(\'location:./\'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).\'?'.$curr_tbl.'_uptoken=\'.base64_encode($'.$curr_tbl.'_return_key).\'&table_alert=Record added Succesfully\');
    
    }
      //End Execute '.$curr_tbl.' data on sql isset Command

  ';
  
  $insert_updt_ui_str='
      <div align="center" style="width: 98%">
      <?php if(!isset($_GET[\''.$curr_tbl.'_uptoken\'])){?> 
            <button type="submit" id="'.$curr_tbl.'_insert_btn" name="'.$curr_tbl.'_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET[\''.$curr_tbl.'_uptoken\'])) {?>
            <button type="submit" id="'.$curr_tbl.'_update_btn" name="'.$curr_tbl.'_update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <?php } ?>
    </div>
  ';

  $top_buttons_profile='
      <a href="" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-arrow-left"></i> Back to list</a>
      <a href="" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-plus"></i> Add New</a>
            <?php if(isset($_GET[\''.$curr_tbl.'_uptoken\']))
            {?>
      <a href="?'.$curr_tbl.'_uptoken=<?php echo $_GET["'.$curr_tbl.'_uptoken"];?>&delete'.$curr_tbl.'&after_delete=<?php echo base64_encode(\'\');?>" class="badge badge-danger p-2  ml-3 btn_neoo2">
              <i class="fa fa-trash"></i> Delete
            </a>
            <?php } ?>
            ';
  $search_ui_str='
     <input type="text" class="col-md-2 mb-2 ml-2 bg-transparent" placeholder="Search '.str_replace("_", ' ', $curr_tbl).'" name="txt_'.$curr_tbl.'" style="color:#000; border:none; border-bottom:1px solid #000;"/>
     <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="q'.$curr_tbl.'_btn"><i class="fa fa-search"></i> Go</button>
     <a href="" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3"><i class="fa fa-refresh"></i> Refresh </a>       
  ';
  $get_query_function_strl='get_'.$curr_tbl.'("*", "$gft_'.$curr_tbl.' ", "l:q'.$curr_tbl.'_token");';
  $get_query_function_strr='get_'.$curr_tbl.'("*", "", "r");';
  $paginate_string_str='<?php echo mosy_paginate_ui($'.$curr_tbl.'_list_query[1], $datalimit, "q'.$curr_tbl.'_token" );?>';
  
  $loop_str='<input type="hidden" id="'.$curr_tbl.'_loop" value="'.$while_loop.'" />';
  $mosy_filter_txt='<input type="hidden" id="'.$curr_tbl.'_mosyfilter" value="'.$mosy_filter.'" />';
  $gen_sql_params_input='<input type="hidden" id="'.$curr_tbl.'_gen_params" value="'.str_replace('"', "&quot;", $post_params).'" />';
  $gen_sql_params_arr='<input type="hidden" id="'.$curr_tbl.'_gen_params_arr" value="'.str_replace('"', "&quot;", $tbl_arr).'" />';

  $insert_function_inp='<input type="hidden" id="'.$curr_tbl.'_insert_funct" value="'.str_replace('"', "&quot;", $insert_function_str).'" />';
  $isset_function_inp='<input type="hidden" id="'.$curr_tbl.'_isset_funct" value="'.str_replace('"', "&quot;", $isset_function_str).'" />';
  $insert_updt_ui='<input type="hidden" id="'.$curr_tbl.'_insert_updt_ui" value="'.str_replace('"', "&quot;", $insert_updt_ui_str).'" />';
  $search_ui_inp='<input type="hidden" id="'.$curr_tbl.'_search_ui_str" value="'.str_replace('"', "&quot;", $search_ui_str).'" />';
  $top_buttons_profile_str='<input type="hidden" id="'.$curr_tbl.'_top_prof_buttons" value="'.str_replace('"', "&quot;", $top_buttons_profile).'" />';
  $get_query_function_inp='<input type="hidden" id="'.$curr_tbl.'_get_query_function" value="'.str_replace('"', "&quot;", $get_query_function_strl).'" />';
  $get_query_functionr_inp='<input type="hidden" id="'.$curr_tbl.'_get_query_functionr" value="'.str_replace('"', "&quot;", $get_query_function_strr).'" />';
  $paginate_string_inp='<input type="hidden" id="'.$curr_tbl.'_paginate_str" value="'.str_replace('"', "&quot;", $paginate_string_str).'" />';
  $edit_del_str_str='<a href=&quot;?'.$curr_tbl.'_uptoken=<?php echo base64_encode($list'.$curr_tbl.'_result[&quot;'.$tbl_primkey.'&quot;])?>&quot; class=&quot;text-primary&quot;><i class=&quot;fa fa-edit&quot;></i> Edit</a> | 
  <a href=&quot;?'.$curr_tbl.'_uptoken=<?php echo base64_encode($list'.$curr_tbl.'_result[&quot;'.$tbl_primkey.'&quot;])?>&delete'.$curr_tbl.'&quot; class=&quot;text-primary&quot;><i class=&quot;fa fa-trash&quot;></i> Delete</a>';

  $edit_del_str_inp='<input type="hidden" id="'.$curr_tbl.'_edit_del_str" value="'.$edit_del_str_str.'" />';

  $gen_sql_params_post_arr='<input type="hidden" id="'.$curr_tbl.'_gen_params_arr_post" value="'.str_replace('"', "&quot;", $tbl_post_arr).'" />';
 
  $gen_insert_str='<input type="hidden" id="'.$curr_tbl.'_insert_str" value="'.str_replace('"', "&quot;", $sql_insert_str).'" />';
  $gen_update_str='<input type="hidden" id="'.$curr_tbl.'_update_str" value="'.str_replace('"', "&quot;", $sql_update_str).'" />';
  $input_select_like_str='<input type="hidden" id="'.$curr_tbl.'_select_str" value="'.str_replace('"', "&quot;", $select_like_str).'" />';
  $input_delete_str='<input type="hidden" id="'.$curr_tbl.'_delete_str" value="'.str_replace('"', "&quot;", $delete_log_str).'" />';

  $ajax_gen_insert_str='<input type="hidden" id="'.$curr_tbl.'_ajax_insert_str" value="'.str_replace('"', "&quot;", str_replace("'", "\'", $sql_insert_str)).'" />';
  $ajax_gen_update_str='<input type="hidden" id="'.$curr_tbl.'_ajax_update_str" value="'.str_replace('"', "&quot;", str_replace("'", "\'", $sql_update_str)).'" />';
  $ajax_input_select_like_str='<input type="hidden" id="'.$curr_tbl.'_ajax_select_str" value="'.str_replace('"', "&quot;", str_replace("'", "\'", $filter_sel_like_str)).'" />';
  $ajax_input_select_single_str='<input type="hidden" id="'.$curr_tbl.'_ajax_select_single_str" value="'.str_replace('"', "&quot;", str_replace("'", "\'", $filter_sel_single_str)).'" />';


  $input_delete_str='<input type="hidden" id="'.$curr_tbl.'ajax_delete_str" value="'.str_replace('"', "&quot;", $delete_log_str).'" />';


  $tbl_cards.='
   <div class="function_card" style="margin-bottom:7px;">
          <div ><span style="font-style:italic; padding:7px;"><u><b>'.strtoupper($curr_tbl).' Functions</span></b></u></div>

  <div style="padding-top:15px;display:inline-block">'.$loop_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_loop\').value)" >While Loop</u></div> | ';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$gen_sql_params_arr.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_gen_params_arr\').value)" >Sql_array</u></div> | ';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$gen_sql_params_post_arr.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_gen_params_arr_post\').value)" >Sql_post_array</u></div> | ';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$gen_sql_params_input.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_gen_params\').value)" >Sql_params</u></div> | ';

  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$gen_insert_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_insert_str\').value)" >Insert_str</u></div> |';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$gen_update_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_update_str\').value)" >update_params</u></div> | ';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$input_select_like_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_select_str\').value)" >Select_str</u></div> | ';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$mosy_filter_txt.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_mosyfilter\').value)" >Mosy_Filter</u></div> | ';

  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$input_delete_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_delete_str\').value)" >Delete_params</u></div> |';


  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$ajax_gen_insert_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_ajax_insert_str\').value)" >ajax_Insert</u></div> |';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$ajax_gen_update_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_ajax_update_str\').value)" >ajax_update</u></div> | ';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$ajax_input_select_like_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_ajax_select_str\').value)" >ajax_Like_Select</u></div> | ';
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$insert_function_inp.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_insert_funct\').value)" >Insert_func</u></div> | ';  
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$isset_function_inp.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_isset_funct\').value)" >Isset_func</u></div> | ';  
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$search_ui_inp.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_search_ui_str\').value)" >Search_input</u></div> | ';  
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$edit_del_str_inp.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_edit_del_str\').value)" >Edit_del_link</u></div> | ';  
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$top_buttons_profile_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_top_prof_buttons\').value)" >Profile_top_btn</u></div> | ';  
  
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$get_query_functionr_inp.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_get_query_functionr\').value)" >row_query_function</u></div> | ';  

  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$get_query_function_inp.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_get_query_function\').value)" >loop_query_function</u></div> | ';  

  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$paginate_string_inp.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_paginate_str\').value)" >paginate_function</u></div> | ';  

  
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$insert_updt_ui.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_insert_updt_ui\').value)" >Insert_updt_ui</u></div> | ';  
  
  $tbl_cards.='<div style="padding-top:15px;display:inline-block">'.$ajax_input_select_single_str.'<u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.'_ajax_select_single_str\').value)" >ajax_Single_Select</u></div> <hr></div> ';



    $write_tbl_cols_query = mysqli_query($single_conn, "SHOW COLUMNS FROM `$single_db`.`$curr_tbl`");

  while($write_tbl_cols_res = mysqli_fetch_array($write_tbl_cols_query)){

      $label_node=ucwords(str_replace("_", " ", strtolower($write_tbl_cols_res['Field'])));

      $tbl_key_arr[]=$write_tbl_cols_res['Field'];

      $tbl_primkey=$tbl_key_arr[0];
      
      $tbl =$curr_tbl;
      $key=$write_tbl_cols_res['Field'];

      $php_data_node='<?php echo $'.$curr_tbl.'_node[&quot;'.$write_tbl_cols_res['Field'].'&quot;];?>';
      $add_tbl_cell='<td><?php echo $'.$curr_tbl.'_node[&quot;'.$write_tbl_cols_res['Field'].'&quot;];?></td>';
      $tbl_header_ui_str='<th>'.ucwords(str_replace("_", " ", $write_tbl_cols_res['Field'])).'</th>';
    

      $add_tbl_cell.='
              <td scope=&quot;col&quot; class=&quot;p-1&quot;>          
                  <input type=&quot;text&quot;  value=&quot;<?php echo $list'.$tbl.'_result[&quot;'.$key.'&quot;];?>&quot; name=&quot;txt_'.$key.'_<?php echo $list'.$tbl.'_result[&quot;'.$tbl_primkey.'&quot;];?>&quot; id=&quot;txt_'.$key.'_<?php echo $list'.$tbl.'_result[&quot;'.$tbl_primkey.'&quot;];?>&quot; placeholder=&quot;'.$label_node.'&quot; onchange=&quot; ugrid_update_'.$tbl.'(\''.$key.'\', \'<?php echo $list'.$tbl.'_result[&quot;'.$tbl_primkey.'&quot;];?>\')&quot; style=&quot;border:none; border-bottom:1px solid #fff; background-color:transparent;&quot;/>
                  </td>';

      $element_cell='<div class=&quot;form-group&quot;>'.PHP_EOL.
          '  <label >'.$label_node.'</label>'.PHP_EOL.
          '  <input class=&quot;form-control&quot; id=&quot;txt_'.$write_tbl_cols_res['Field'].'&quot; name=&quot;txt_'.$write_tbl_cols_res['Field'].'&quot; value=&quot;'.$php_data_node.'&quot; placeholder=&quot;'.$label_node.'&quot; type=&quot;text&quot;>'.PHP_EOL.
          ' </div>';
    $image_cell_name=$write_tbl_cols_res['Field'];
    $profile_pic_style="width: 200px; height:200px;  border-radius:50%;";
    $full_img_cell='
    <?php if(isset($_GET[\''.$curr_tbl.'_uptoken\'])){?> 
    <div class=&quot;col-md-4 border text-center mb-3&quot;>
    <div class=&quot;col-md-12 m-2&quot;><b>Photo File</b></div>
        <?php 
              if($'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;]!=&quot;&quot;) 
                {
                  $file_type_image=magic_if_image($'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;]);
                    if($file_type_image==\'Yes\')
                    {?>
                    
                  <img src=&quot;<?php if($'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;]==&quot;&quot;) { echo $mep_app_logo;}else{ echo $'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;];}?>&quot;  class=&quot;&quot; style=&quot;'.$profile_pic_style.'&quot;/>

                    <?php }else{
                    $actual_file_name=explode(&quot;/&quot;, $'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;]);
                    echo \'<a href=&quot;\'.$'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;].\'&quot; target=&quot;_blank&quot; class=&quot;&quot;><i class=&quot;fa fa-paperclip&quot; style=&quot;font-size:70px;&quot;></i> 
                    <br>\'.end($actual_file_name).\'<hr> <i class=&quot;fa fa-download&quot;></i> Download</a>\';
                    }
                }else{?>
                 
                 <img src=&quot;<?php if($'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;]==&quot;&quot;) { echo $mep_app_logo;}else{ echo $'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;];}?>&quot;  class=&quot;&quot; style=&quot;'.$profile_pic_style.'&quot;/>

                <?php } ?>

        <input type=&quot;file&quot; name=&quot;txt_'.$curr_tbl.'_'.$image_cell_name.'&quot; class=&quot;form-control mt-3&quot;>

        <input type=&quot;submit&quot; name=&quot;btn_upload_'.$curr_tbl.'_'.$image_cell_name.'&quot; class=&quot;btn btn-primary mt-2&quot; value=&quot;Upload&quot;>
        <input type=&quot;hidden&quot; name=&quot;txt_'.$image_cell_name.'&quot; value=&quot;<?php echo $'.$curr_tbl.'_node[&quot;'.$image_cell_name.'&quot;];?>&quot;>

    </div> 
    <?php }?>
    ';
    
  
  $mosy_insert_cell_str='`'.$write_tbl_cols_res['Field'].'`'.PHP_EOL.PHP_EOL.'\'$'.$write_tbl_cols_res['Field'].'\'';
    
        $php_echo_str='<input type="hidden" id="'.$curr_tbl.$write_tbl_cols_res['Field'].'_list_php_echo" value="<?php echo $list'.$curr_tbl.'_result[\''.$write_tbl_cols_res['Field'].'\'];?>" />';
      
        $php_node_str='<input type="hidden" id="'.$curr_tbl.$write_tbl_cols_res['Field'].'_node_php_echo" value="<?php echo $'.$curr_tbl.'_node[\''.$write_tbl_cols_res['Field'].'\'];?>" />';

        $data_ui_cell='<input type="hidden" id="'.$curr_tbl.$write_tbl_cols_res['Field'].'_element_cell" value="'.$element_cell.'" />';
        $tbl_header_ui_inp='<input type="hidden" id="'.$curr_tbl.$write_tbl_cols_res['Field'].'_tbl_ui_header" value="'.$tbl_header_ui_str.'" />';
        $image_cell_ui_inp='<input type="hidden" id="'.$curr_tbl.$write_tbl_cols_res['Field'].'_full_imagecell" value="'.$full_img_cell.'" />';
        $mosy_insert_cell='<input type="hidden" id="'.$curr_tbl.$write_tbl_cols_res['Field'].'_mosy_insert" value="'.$mosy_insert_cell_str.'" />';
        $tbl_cell='<input type="hidden" id="'.$curr_tbl.$write_tbl_cols_res['Field'].'_tbl_td" value="'.$add_tbl_cell.'" />';

    $tbl_cards.=$php_node_str.$php_echo_str.$data_ui_cell.$tbl_cell.$mosy_insert_cell.$tbl_header_ui_inp.$image_cell_ui_inp.'
        <div  class="tbl_row function_card" style="margin-bottom:10px; "> 
        <div ><span style="font-style:italic; font-size:16px;  color:#FFF; padding:7px;"><u><b>'.strtoupper($curr_tbl.' / '.$write_tbl_cols_res['Field']).'</span></b></u></div>
        <div style="display:inline-block; padding-top:15px; color:#fff;"><u  onclick="load_to_editor(this.innerHTML)" >'.$write_tbl_cols_res['Field'].'</u></div>  
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\'txt_'.$write_tbl_cols_res['Field'].'\')" >Input</u></div>  
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\''.$curr_tbl.'.'.$write_tbl_cols_res['Field'].'\')" >Join Var</u> </div> 
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\'$'.$write_tbl_cols_res['Field'].'\')" >Var</u> </div> 
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.$write_tbl_cols_res['Field'].'_list_php_echo\').value)" >Loop Node</u>  </div> 
        | <div style="display:inline-block"><u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.$write_tbl_cols_res['Field'].'_node_php_echo\').value)" >Data Node</u></div>
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\'&quot;'.$write_tbl_cols_res['Field'].'&quot;:&quot;?&quot;,\')" >Json_str</u></div>
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\'$'.$write_tbl_cols_res['Field'].'=mmres($_POST[&quot;txt_'.$write_tbl_cols_res['Field'].'&quot;]);\')" >Sql_Param</u></div>
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\' , `'.$write_tbl_cols_res['Field'].'`\')" >insert_str</u></div>
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\' , `'.$write_tbl_cols_res['Field'].'` = \&#39;$'.$write_tbl_cols_res['Field'].'\&#39;\')" >update_str</u></div>

        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\', \\\'$'.$write_tbl_cols_res['Field'].'\\\'\')" >insert_val</u>  </div> 

        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\'$list'.$curr_tbl.'_result[&quot;'.$write_tbl_cols_res['Field'].'&quot;]\')" >Nt_Loop_Node</u>  </div> 

        | <div style="display:inline-block"><u onclick="load_to_editor(\'$'.$curr_tbl.'_node[&quot;'.$write_tbl_cols_res['Field'].'&quot;]\')" >Nt_Data_Node</u></div>
        | <div style="display:inline-block"><u onclick="load_to_editor(\''.$write_tbl_cols_res['Field'].'=\\\'&quot;.(mmres($'.$curr_tbl.'_node[&quot;'.$write_tbl_cols_res['Field'].'&quot;])).&quot;\\\'\')" >Nt_Dn_Mosy_Filter</u></div>
        | <div style="display:inline-block"><u onclick="load_to_editor(\''.$write_tbl_cols_res['Field'].'=\\\'&quot;.(mmres($list'.$curr_tbl.'_result[&quot;'.$write_tbl_cols_res['Field'].'&quot;])).&quot;\\\'\')" >Nt_Ln_Mosy_Filter</u></div>
        | <div style="display:inline-block"><u onclick="load_to_editor(\'$'.$curr_tbl.'_node[&quot;'.$write_tbl_cols_res['Field'].'&quot;]\')" >Nt_Data_Node</u></div>
        
        | <div style="display:inline-block"><u onclick="magic_form_tag(\'input\', \''.$write_tbl_cols_res['Field'].'\', \''.$curr_tbl.'\', \'node\', \'yes\',\'no\', \'text\')" >text_cell</u></div>
        | <div style="display:inline-block"><u onclick="magic_form_tag(\'input\', \''.$write_tbl_cols_res['Field'].'\', \''.$curr_tbl.'\', \'node\', \'no\',\'no\', \'hidden\')" >text_box</u></div>

        | <div style="display:inline-block"><u onclick="magic_form_tag(\'select\', \''.$write_tbl_cols_res['Field'].'\', \''.$curr_tbl.'\', \'node\', \'yes\',\'yes\', \'select\')" >Dyn_Select_cell</u></div>
        | <div style="display:inline-block"><u onclick="magic_form_tag(\'select\', \''.$write_tbl_cols_res['Field'].'\', \''.$curr_tbl.'\', \'node\', \'yes\',\'no\', \'select\')" >Select_cell</u></div>
        | <div style="display:inline-block"><u onclick="magic_form_tag(\'select_options\', \''.$write_tbl_cols_res['Field'].'\', \''.$curr_tbl.'\', \'node\', \'no\',\'yes\', \'select\')">Select_Options</u></div>
        | <div style="display:inline-block"><u onclick="magic_form_tag(\'textarea\', \''.$write_tbl_cols_res['Field'].'\', \''.$curr_tbl.'\', \'node\', \'yes\',\'no\', \'textarea\')" >textarea_cell</u></div>
        | <div style="display:inline-block"><u onclick="magic_form_tag(\'img\', \''.$write_tbl_cols_res['Field'].'\', \''.$curr_tbl.'\', \'node\', \'yes\',\'no\', \'img\')" >img_cell</u></div>
        | <div style="display:inline-block"><u onclick="magic_form_tag(\'div\', \''.$write_tbl_cols_res['Field'].'\', \''.$curr_tbl.'\', \'node\', \'yes\',\'no\', \'div\')" >div_cell</u></div>

        | <div style="display:inline-block"><u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.$write_tbl_cols_res['Field'].'_element_cell\').value)" >Node_Cell</u></div>
        | <div style="display:inline-block"><u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.$write_tbl_cols_res['Field'].'_tbl_td\').value)" >TD_Cell</u></div>
        | <div style="display:inline-block"><u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.$write_tbl_cols_res['Field'].'_tbl_ui_header\').value)" >TH_Cell</u></div>
        | <div style="display:inline-block"><u onclick="load_to_editor(document.getElementById(\''.$curr_tbl.$write_tbl_cols_res['Field'].'_full_imagecell\').value)" >Full_img_cell</u></div>
        
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\''.$write_tbl_cols_res['Field'].' \\\'+ajaxindiscr+\\\' \\\\\\\'%\\\'+this.value+\\\'%\\\\\\\' \\\'+ajaxplus+\\\' \')" >Like_Ajax</u>  </div> 
        
        | <div style="display:inline-block; padding-top:15px;"><u onclick="load_to_editor(\''.$write_tbl_cols_res['Field'].' \\\'+ajaxnode+\\\' \\\\\\\'value\\\\\\\'  \\\'+ajaxstack+\\\'\')" >Equal_Ajax</u>  </div> 
             
          <div style="border:1px solid #ccc; margin-top:3px;"></div>
          </div>
          ';
  }


  $tbl_cards.='</div>';
  
}
  
echo $tbl_cards;  

}

if(isset($_POST["magic_form_tag"])){

  echo  magic_form_tag($_POST['tag_name'], $_POST['column_name'], $_POST['table'], $_POST['loop_or_node'], $_POST['full_cell_yes_no'], $_POST['dynamic_yes_no'], $_POST['type']);
  
}


if(isset($_POST['load_file']))
{
  echo file_get_contents($_POST['txt_writeto']);

}

if(isset($_POST['load_notes']))
{
  if (!file_exists($_POST['txt_writeto'])) {
      $file_to_write = fopen($_POST['txt_writeto'], 'w') or die("can't open file");
      fwrite($file_to_write, '');
      fclose($file_to_write);
  }

  echo file_get_contents($_POST['txt_writeto']);

}

if(isset($_POST['save_file']))
{

  $clean_code=$_POST['txt_new_code'];

   if (!file_exists('./edithistory')) @mkdir('./edithistory');

    if($_POST['save_file']==''){
      echo "File path cannot be empty";
    }else{
        
      if (!file_exists($_POST['txt_writeto'])){
        echo "<hr>File Not Found, Creating file...<hr>";
      }else{
        
        $backup= file_get_contents($_POST['txt_writeto']);

              $file_to_write = fopen('./edithistory/'.magic_basename($_POST['txt_writeto'])."_".date("dmyhisa").'_bkup.tmx', 'w') or die("can't open file");
              fwrite($file_to_write, $backup);
              fclose($file_to_write);
      };


         if(file_put_contents($_POST['txt_writeto'], $clean_code)){
             echo "File Saved :)";

         }else{
             echo "<hr>File Not Found, Creating file<hr>";
         }
    };

}

if(isset($_POST['formart_file']))
{
  $tidy_config = [
  'literal-attributes'=>1,
  'wrap'=>1300000,
  'wrap-attributes'=>false,
  'indent-spaces' => 4,
  'tab-size' => 4,
  'tidy-mark'=>1,
  'break-before-br'=>true,
  'force-output'=>true,
  'indent'=>true
];

  $tidy = new tidy;
	$tidy->parseString(file_get_contents($_POST['this_file']), $tidy_config, 'utf8');


   if (!file_exists('./edithistory')) @mkdir('./edithistory');

    if($_POST['this_file']==''){
      echo "File path cannot be empty";
    }else{
        
      if (!file_exists($_POST['this_file'])){
        echo "<hr>File ".$_POST['this_file']." Not Found, Creating file...<hr>";
      }else{
        
        $backup= file_get_contents($_POST['this_file']);

              $file_to_write = fopen('./edithistory/'.magic_basename($_POST['this_file'])."_".date("dmyhisa").'_bkup.fmt', 'w') or die("can't open file");
              fwrite($file_to_write, $backup);
              fclose($file_to_write);
      };

              $new_file_to_write = fopen($_POST['this_file'], 'w') or die("can't open file");
              fwrite($new_file_to_write, $tidy);
              fclose($new_file_to_write);

         if($new_file_to_write){
             echo "File Saved :)";

         }else{
             echo "<hr>File ".$_POST['this_file']." Not Found, Creating file<hr>";
         }
    };

}

if(isset($_POST['save_file_preview']))
{
$inject_scroll_set ='<style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style>
<script>
window.onscroll = function() {termial_xsendcurspos()};

function termial_xsendcurspos() {
if(document.documentElement.scrollTop>0){
  window.parent.document.getElementById("prevscroll_px").value=document.documentElement.scrollTop; 
}
}
</script>';

      $file_to_write = fopen($_POST['txt_writeto']."/load_preview_iframe_23_01_21_438pm.php", 'w') or die("can't open file");
      fwrite($file_to_write,$_POST['txt_new_code'].$inject_scroll_set);
      fclose($file_to_write);

   echo "File Preview Saved";
}


if(isset($_POST["asn_snippets_insert_btn"])){
//------- begin Create Update record from asn_snippets --> 
$snippetid=mysqli_real_escape_string($mysqliconn, magic_random_str(10));
$snippet_title=mysqli_real_escape_string($mysqliconn, $_POST["txt_snippet_title"]);
$snippet_details=mysqli_real_escape_string($mysqliconn, $_POST["txt_snippet_details"]);
//===-- End Create Update record from asn_snippets -->


$asn_snippets_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$asntag`.`asn_snippets` (`primkey`,`snippetid`,`snippet_title`,`snippet_details`) VALUES (NULL,'$snippetid','$snippet_title','$snippet_details')");

echo "Snippet Added";
}
//************* END INSERT QUERY 

if(isset($_POST["update_snippet"])){
//------- begin Create Update record from asn_snippets --> 

$snippet_title=mysqli_real_escape_string($mysqliconn, $_POST["txt_snippet_title"]);
$snippet_details=mysqli_real_escape_string($mysqliconn, $_POST["txt_snippet_details"]);
$snippet_key=mysqli_real_escape_string($mysqliconn, $_POST["snippet_key"]);
//===-- End Create Update record from asn_snippets -->


$asn_snippets_insert_query = mysqli_query($mysqliconn, "UPDATE `$asntag`.`asn_snippets` SET `snippet_title`='$snippet_title',`snippet_details`='$snippet_details' WHERE primkey='$snippet_key'");



echo "Snippet Updated";
}
//****

if(isset($_POST["delete_snippet"])){
//------- begin Create Update record from asn_snippets --> 

$snippet_key=mysqli_real_escape_string($mysqliconn, $_POST["snippet_key"]);
//===-- End Create Update record from asn_snippets -->

$asn_snippets_insert_query = mysqli_query($mysqliconn, "DELETE FROM `$asntag`.`asn_snippets`  WHERE primkey='$snippet_key'");



echo "Snippet Deleted";
}
//****




if(isset($_POST["qasn_snippets_btn"])){

$qasn_snippets=mysqli_real_escape_string($mysqliconn, ($_POST["qasn_snippets"]));

//=== start asn_snippets select  Like Query String asn_snippets list  

$asn_snippets_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`asn_snippets`  WHERE (`snippet_title` LIKE '%".$qasn_snippets."%' OR  `snippet_details` LIKE '%".$qasn_snippets."%') ORDER BY `primkey` DESC LIMIT $datalimit" );
$snippent_r="";

while($asn_snippets_list_r=mysqli_fetch_array($asn_snippets_list_query))
{
 
  $snippet_dna_title=preg_replace("/[^A-Za-z0-9 ]/", "_", str_replace(" ", "_", magic_strip_if($asn_snippets_list_r['snippet_title'], 30, 30)));
  
  $dna_options="";
  
  if($_POST['switch_dna_input']=='ON')
  {
      $dna_options='//dna options=='.PHP_EOL.'$dna_file_name="'.$snippet_dna_title.'"; '.PHP_EOL.'$create_dna="yes"; //yes | no; '.PHP_EOL.'$overwrite_dna_file="yes"; //yes | no '.PHP_EOL.'//dna options=='.PHP_EOL.PHP_EOL;

  }
  
  $snippent_r.='Snippet -- <b id="snippet_title_'.$asn_snippets_list_r['primkey'].'">'.$asn_snippets_list_r['snippet_title'].'</b> | <span style="display:inline-block; cursor:pointer;" onclick="edit_snippet(\''.$asn_snippets_list_r['primkey'].'\')"><u>Edit</u></span><br><textarea class="snippet_card" id="snippet_desc_'.$asn_snippets_list_r['primkey'].'" onclick="load_to_editor(this.value);  document.getElementById(\'msg_alert_myModal\').style.display=\'none\'" onkeydown = "if (event.keyCode == 13) {event.preventDefault();  load_to_editor(this.value);   document.getElementById(\'msg_alert_myModal\').style.display=\'none\';}">'.$dna_options.$asn_snippets_list_r['snippet_details'].'</textarea>';
}

echo '`'.$qasn_snippets.'` Results <br><br>'.$snippent_r ;

//=== End asn_snippets select  Like Query String asn_snippets list


}

if(isset($_POST["flag_search"])){

$qasn_snippets=mysqli_real_escape_string($mysqliconn, ($_POST["qasn_snippets"]));

//=== start asn_snippets select  Like Query String asn_snippets list  
$fkey_q=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`asn_snippets`  WHERE (`snippet_title` LIKE '%".$qasn_snippets."%' OR  `snippet_details` LIKE '%".$qasn_snippets."%') ORDER BY `primkey` DESC LIMIT $datalimit" ) or die("Ha, we can`t find Snippets table or database <hr> Make sure you have a database called `".$snippets_db."` with `asn_snippets` table and `code_track` table. <hr> Alternatively run this code in your Php Console on your right import_snippet_db();");

$fkey_r=mysqli_fetch_array($fkey_q);

$fkey=$fkey_r['primkey'];

$asn_snippets_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`asn_snippets`  WHERE (`snippet_title` LIKE '%".$qasn_snippets."%' OR  `snippet_details` LIKE '%".$qasn_snippets."%') ORDER BY `primkey` DESC LIMIT $datalimit" );

$snippent_f='<Input type="hidden" id="flag_focus" value="'.$fkey.'_flash_text_node"/>';


while($asn_snippets_list_r=mysqli_fetch_array($asn_snippets_list_query))
{
  
 $snippet_dna_title=preg_replace("/[^A-Za-z0-9 ]/", "_", str_replace(" ", "_", magic_strip_if($asn_snippets_list_r['snippet_title'], 30, 30)));
  
  $dna_options="";
  if($_POST['switch_dna_input']=='ON')
  {
      $dna_options='//dna options=='.PHP_EOL.'$dna_file_name="'.$snippet_dna_title.'"; '.PHP_EOL.'$create_dna="yes"; //yes | no; '.PHP_EOL.'$overwrite_dna_file="yes"; //yes | no '.PHP_EOL.'//dna options=='.PHP_EOL.PHP_EOL;

  }
  
  $snippent_f.='<b style="color:#bfccbf;">'.$asn_snippets_list_r['snippet_title'].'</b><br><textarea class="snippet_card flag_focus" onclick="load_to_editor(this.value); document.getElementById(\'flag_search_div\').style.display=\'none\'" onkeydown = "if (event.keyCode == 13){ event.preventDefault(); load_to_editor(this.value); document.getElementById(\'flag_search_div\').style.display=\'none\';}" id="'.$fkey.'_flash_text_node" style="width: 100%; height: 40px; margin-top: 8px;" readonly >'.$dna_options.$asn_snippets_list_r['snippet_details'].'</textarea>';
  
}

if($fkey!=''){
echo '<b><u>Snippets<span style="font-size:13px; font-style:italic"> (Press F2 to focus, tab to navigate, then enter to select)</span></u> </b><br><br>'.$snippent_f;

}

//=== End asn_snippets select  Like Query String asn_snippets list


}

if(isset($_POST["flag_console_search"])){

$qasn_snippets=mysqli_real_escape_string($mysqliconn, ($_POST["qasn_snippets"]));

//=== start asn_snippets select  Like Query String asn_snippets list  

$asn_snippets_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`asn_snippets`  WHERE (`snippet_title` LIKE '%".$qasn_snippets."%' OR  `snippet_details` LIKE '%".$qasn_snippets."%') ORDER BY `primkey` DESC LIMIT $datalimit" ) or die("Ha, we can`t find Snippets table or database <hr> Make sure you have a database called `".$snippets_db."` with `asn_snippets` table and `code_track` table. <hr> Alternatively run this code in your Php Console on your right  import_snippet_db();");
$snippent_f="";

while($asn_snippets_list_r=mysqli_fetch_array($asn_snippets_list_query))
{
   $snippet_dna_title=preg_replace("/[^A-Za-z0-9 ]/", "_", str_replace(" ", "_", magic_strip_if($asn_snippets_list_r['snippet_title'], 30, 30)));
  
  $dna_options="";
  if($_POST['switch_dna_input']=='ON')
  {
      $dna_options='//dna options=='.PHP_EOL.'$dna_file_name="'.$snippet_dna_title.'"; '.PHP_EOL.'$create_dna="yes"; //yes | no; '.PHP_EOL.'$overwrite_dna_file="yes"; //yes | no '.PHP_EOL.'//dna options=='.PHP_EOL.PHP_EOL;

  }
    
  $snippent_f.='<b style="color:#bfccbf;">'.$asn_snippets_list_r['snippet_title'].'</b><br><textarea class="snippet_card" onclick="load_to_console(this.value);  document.getElementById(\'flag_search_div\').style.display=\'none\'" onkeydown = "if (event.keyCode == 13){ event.preventDefault(); load_to_console(this.value); document.getElementById(\'flag_search_div\').style.display=\'none\';}" style="width: 100%; height: 40px; margin-top: 8px;" readonly >'.$dna_options.PHP_EOL.$asn_snippets_list_r['snippet_details'].'</textarea>';
}

echo $snippent_f;

//=== End asn_snippets select  Like Query String asn_snippets list


}

if(isset($_POST['refresh_vars']))
{
refresh_vars('no');
echo "Projects Vars Refreshed";
}

if(isset($_POST['add_var_file']))
{

add_terminal_vars($_POST['file_path']);
//refresh_vars('no');

echo "File Added to Projects Vars";
}

if(isset($_POST['set_proj_theme']))
{
$_SESSION['editor_proj_theme']=TRUE;
$_SESSION['new_proj_theme']=$_POST['new_proj_theme'];

echo "Project theme changed";
}

if(isset($_POST['loop_folder']))
{

$parent=$_POST['folder'];

 if (!file_exists($parent)){
  echo "DNF";
 }else{

//folder only 
   
if ($folder_handle = opendir($parent)) {

  while (false !== ($folder_str = readdir($folder_handle))) {

          if ($folder_str != "." && $folder_str != "..") 
          {
            $a = $folder_str;

            if (strpos($a, '.') == false) {
                $folderrec= '<a href="#"  onclick="document.getElementById(\'folderpath\').value=\''.$parent.'/'.$folder_str.'\';loop_open_folder(\''.$parent.'/'.$folder_str.'\')">Open Folder</a>' ;


        echo '
        <div class="function_card" style="border-bottom:1px solid #CCC; margin-bottom:9px;">
        <div style="display:inline-block; padding:3px;">
        <img src="fld.png" style="width:20px;"/>
         <span onclick="load_to_editor(\''.$folder_str.'\')">'.$folder_str.'</span>
        </div>
        <div style=" font-size:12px; margin:7px;">
        <div class="cpointer">'.$folderrec.'</div>
        </div>
        </div>';

             }
       }
    }
 
    closedir($folder_handle);
}

   
if ($handle = opendir($parent)) {

   //files only
    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
          $a = $entry;

            if (strpos($a, '.') !== false) {

              $folderrec2= '
                    <a href="'.$parent.'/'.$entry.'" target="_blank" title="View File">VF</a>  
                    | <div style="color:#FFF; cursor:pointer; text-decoration:underline; display:inline-block" onclick="load_to_editor(\''.$parent.'/'.$entry.'\')" title="Add to editor">ATE</div> 
                    | <a href="#"  onclick="load_to_path(\''.$parent.'/'.$entry.'\')" title="Load to Path">LTP</a> 
                    | <a href="#"  onclick="document.getElementById(\'setcursor\').value=\'block_set_cursor\';load_to_path(\''.$parent.'/'.$entry.'\');load_file()" title="View Source Code">VSC</a> 
                    | <a href="#"  onclick="add_to_frame(\''.$parent.'/'.$entry.'\');" title="Add to Frame">ATF</a> 
                    | <a href="./home?check_autoload='.base64_encode($parent.'/'.$entry).'" target="_blank" title="Mirror to New Window">MTW</a> 
                    | <a href="#" onclick="add_var_file(\''.$parent.'/'.$entry.'\');" title="Add to Project Variables">ATV</a> 
                    | <a href="#" onclick="load_to_editor(\'Recycle(\\\''.$parent.'/'.$entry.'\\\');\')" title="Execute Unlink">DEL</a> 
                    | <a href="#" onclick="load_to_editor(\'include(\\\''.str_replace("../", "./", ($parent.'/'.$entry)).'\\\');\')" title="include string">INC</a> 
                    | <a href="#" onclick="load_to_editor(\''.str_replace("../", "./", ($parent.'/'.$entry)).'\')" title="Add to Project ">ATP</a> 
                    | <a href="#" onclick="formart_file(\''.$parent.'/'.$entry.'\');load_to_path(\''.$parent.'/'.$entry.'\');load_file()" title="Clean HTML ">FMRT</a> 
                    ';

                  echo '
                  <div class="function_card" style="border-bottom:1px solid #CCC; margin-bottom:9px;">
                  <div style="display:inline-block; padding:3px;">
                  <img src="file.png" style="width:20px;"/>
                   <span onclick="load_to_editor(\''.$entry.'\')">'.$entry.'</span>
                  </div>
                  <div style=" font-size:12px; margin:7px;">
                  <div class="cpointer">'.$folderrec2.'</div>
                  </div>
                  </div>';
            }
      }
    }
}
   

}
}


function strip_selected_tags_by_id_or_class($array_of_id_or_class, $text,$replacewith)
{
   $name = implode('|', $array_of_id_or_class);
   $regex = '#<(\w+)\s[^>]*(class|id)\s*=\s*[\'"](' . $name .
            ')[\'"][^>]*>.*</\\1>#isU';
    //echo "curr regexed ".$regex;
   return(preg_replace($regex, $replacewith, $text));
}

if(isset($_POST['update_page_file']))
{

$array_of_id_or_class=array($_POST['element_id']);
$element_id=$_POST['element_id'];
$new_element_cont1=$_POST['new_elem_cont'];

$new_element_cont2 = str_replace("<div>", '<br>', $new_element_cont1);
$new_element_cont = str_replace("</div>", '', $new_element_cont2);

$current_file="../".$_POST['file_name'];
$getbkup=$_POST['file_name'];
$tag_start=$_POST['tag_start'];
$tagname=$_POST['tagname'];
$recreated_tag =$tag_start.PHP_EOL."\t\t".($new_element_cont).PHP_EOL."\t\t</".$tagname.">";


  $backup= file_get_contents($current_file);

   if (!file_exists('./page_edithistory')) @mkdir('./page_edithistory');

      $file_to_write = fopen('./page_edithistory/'.($getbkup)."_".date("d_m_y_h_i_s_a").'_bkup.astg', 'w') or die("can't open file");
      fwrite($file_to_write, $backup);
      fclose($file_to_write);

if($tagname=='img'){

$dom = new DOMDocument();
@$dom->loadHTML(file_get_contents($current_file), LIBXML_HTML_NODEFDTD);

$image = $dom->getElementById($element_idt_id);

$image->setAttribute('src', $new_element_cont);

$dom->removeChild($dom->doctype);  

$newfile_str1=$dom->saveHTML();

$newfile_str=str_replace('<html lang="en">', '<!DOCTYPE html>'.PHP_EOL.'<html lang="en">', $newfile_str1);
}else{
$text=file_get_contents($current_file);

$newfile_str=strip_selected_tags_by_id_or_class($array_of_id_or_class, $text, $recreated_tag);



}

  $fh2 = fopen($current_file, 'w') or die("can't open file");
  fwrite($fh2, $newfile_str);
  fclose($fh2);


}

if(isset($_POST["insert_code_time"])){

//------- begin sql_comment --> 

$entry_id=mysqli_real_escape_string($mysqliconn, date('Y-m-d H:i:s'));
$start=mysqli_real_escape_string($mysqliconn, date('Y-m-d H:i:s'));
$end=mysqli_real_escape_string($mysqliconn, date('Y-m-d H:i:s', strtotime($_POST['txt_end'])));
$folder=mysqli_real_escape_string($mysqliconn, $_POST["txt_folder"]);
$main_url=mysqli_real_escape_string($mysqliconn, $_POST["main_url"]);
$session_name=mysqli_real_escape_string($mysqliconn, "No_session");
$where_code_str="";
if(isset($_SESSION['tct_session']))
{
  $session_name=mysqli_real_escape_string($mysqliconn, $_SESSION['tct_session']);

  $where_code_str="session_name='$session_name'";
}

//===-- End sql_comment -->



//=== start code_track select  query 

$_code_track_query=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`code_track` ORDER BY `primkey` DESC LIMIT 1" );

$latest_entry=mysqli_fetch_array($_code_track_query);

//=== End code_track select   query
//--<{ncgh}/>

$code_track_uptoken=$latest_entry['primkey'];

$curr_time=strtotime('now');
$latest_entry_time=strtotime($latest_entry['end']);

$time_diff=number_format((($curr_time-$latest_entry_time)/60), 4, ".", ",");
$new_time_diff=number_format((($start-$end)/60), 4, ".", ",");

$start_beacon=strtotime($latest_entry['start']);
$latest_entry_time_up=strtotime($latest_entry['end']);

$becon_time_diff=number_format((($latest_entry_time_up-$start_beacon)/60), 4, ".", ",");

$new_record='no';

if($time_diff>2){

    $new_record="Yes";

}elseif($code_track_uptoken==''){

  $new_record="Yes";

}elseif ($main_url!=$latest_entry['main_url']){

    $new_record='Yes';

}

if($new_record=='Yes')
{
//------- begin Insert Query  --> 
$code_track_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$asntag`.`code_track` (`primkey`,`main_url`, `entry_id`,`start`,`end`,`time_diff`,`folder`, `session_name`) 
 VALUES 
(NULL,'$main_url', '$entry_id','$start','$end','$new_time_diff','$folder', '$session_name')") or die(mysqli_error($mysqliconn));
}else{
$code_track_update_query = mysqli_query($mysqliconn, "UPDATE  `$asntag`.`code_track` SET `end`='$end',`time_diff`='$becon_time_diff',`folder`='$folder', `main_url`='$main_url', `session_name`='$session_name' WHERE primkey='$code_track_uptoken'") or die(mysqli_error($mysqliconn));
//magic_sql_delete('code_track', "time_diff>1000 OR time_diff=0");

}


//------- End insert Query  --> 
$sum_tct=magic_multisql_sum($mysqliconn, $asntag, 'code_track', 'time_diff', $where_code_str);

  $sum_tct_str=format_time($sum_tct);
  
  echo $sum_tct_str;

//echo "diff => ".$time_diff." new_record ".$new_record." becon_time_diff ".$becon_time_diff." - curr_time - ".$curr_time." latest_entry_time ".$latest_entry_time." start_beacon ".$start_beacon;
}
function format_time($t,$f=':') // t = seconds, f = separator 
{
  return sprintf("%02d%s%02d%s%02d", floor(($t*60)/3600), $f, (($t*60)/60)%60, $f, ($t*60)%60);
}
?>