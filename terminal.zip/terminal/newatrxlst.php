<?php
header("Content-Type:application/json");

//====================== GET RESPONSE JSON DATA FROM CURL; COMMENT THIS LINE WHEN USING SAMPLE DATA ==========

$paybilljson = file_get_contents('php://input');

//====================== GET RESPONSE JSON DATA FROM CURL; COMMENT THIS LINE WHEN USING SAMPLE DATA ==========


//====================== SAMPLE JSON DATA FROM CURL; COMMENT THIS LINE WHEN USING lIVE DATA ==========
//   $paybilljson='{
//             "TransactionType": "Pay Bill",
//             "TransID": "TEST-SANDBOX",
//             "TransTime": "'.date("d-m-Y h:i:s").'",
//             "TransAmount": "10000.00",
//             "BusinessShortCode": "XXX-XXX-XXX",
//             "BillRefNumber": "EBK-5N02",
//             "InvoiceNumber": "EBK-5N02",
//             "OrgAccountBalance": "000.00",
//             "ThirdPartyTransID": "0",
//             "MSISDN": "+254-000-000-000",
//             "FirstName": "ASANETIC",
//             "MiddleName": "TECHNOLOGIES",
//             "LastName": "INC."
//         }';
        
//====================== SAMPLE JSON DATA FROM CURL; COMMENT THIS LINE WHEN USING lIVE DATA ==========


            
//====================== GET JSON DATA  FROM DECODED JSON ARRAY ==========

$trx_record = json_decode($paybilljson, true);

$tr_type=$trx_record['TransactionType'];
$trans_id=$trx_record['TransID'];
$TransTime=$trx_record['TransTime'];
$TransAmount=$trx_record['TransAmount'];
$BusinessShortCode=$trx_record['BusinessShortCode'];
$BillRefNumber=$trx_record['BillRefNumber'];
$OrgAccountBalance=$trx_record['OrgAccountBalance'];
$ThirdPartyTransID=$trx_record['ThirdPartyTransID'];
$MSISDN=$trx_record['MSISDN'];
$FirstName=$trx_record['FirstName'];
$MiddleName=$trx_record['MiddleName'];
$LastName=$trx_record['LastName'];

//====================== GET JSON DATA  FROM DECODED JSON ARRAY ==========


//====================== GET BillRefNumber PREFIX AND SUFFIX ==========
$explode_BillRefNumber=explode("-",$BillRefNumber);
$BillRefNumber_prefix=$explode_BillRefNumber[0];
$BillRefNumber_suffix=$explode_BillRefNumber[1];
//====================== GET BillRefNumber PREFIX AND SUFFIX ==========

//====================== INSERT INTO DB ADD, ANY RELEVANT CODE HERE ==========

$post_params='{"primkey":"NULL","transaction_id":"'.$trans_id.'","transaction_ref":"'.$BillRefNumber.'","order_no":"'.$BillRefNumber.'","date_of_transaction":"'.date("d-m-Y h:i:s A").'","month_year":"'.date("M-Y").'","client_id":"'.date("dmYAhis").'","fname":"'.$FirstName.'","mname":"'.$MiddleName.'","lname":"'.$LastName.'","email":"","mobile":"'.$MSISDN.'","amount":"'.$TransAmount.'","type":"Income","transaction_remark":"'.$tr_type.'","transaction_status":"Complete","filter_date":"","time_stamp":"'.date("d-m-Y h:i:s A").'","site_id":"","tab_type":"","receipt_no":"'.$trans_id.'","admin_id":"","payment_mode":"Paybill"}';

magic_sql_insert("transactions",$post_params);

//====================== INSERT INTO DB ADD, ANY RELEVANT CODE HERE ==========

?>