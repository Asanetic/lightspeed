var active_mirror =document.getElementsByClassName('CodeMirror');

active_mirror[0].id='active_code_window';

document.getElementById('active_code_window').focus();

function get_live_date(){

var getcurr_date =new Date();

var live_execution_time =getcurr_date.getHours()+" : "+getcurr_date.getMinutes()+":"+getcurr_date.getSeconds();

return live_execution_time;
}

var execution_time = get_live_date();

function show_mobi()
{
document.getElementById("load_mobi_iFrame").style.display='block';
document.getElementById("mobile_screen").style.display='block';
document.getElementById("close_mobile_view_btn").style.display='block';
}

function close_mobile_view()
{
document.getElementById("load_mobi_iFrame").style.display='none';
document.getElementById("mobile_screen").style.display='none';
document.getElementById("minimized_mobi_div").style.display='block';
}

function min_preview()
{
document.getElementById("preview_desk_iframe").style.display='none';
document.getElementById("load_preview_iframe0").style.display='none';
document.getElementById("load_preview_iframe1").style.display='none';
document.getElementById("load_preview_iframe_btn").style.display='none';
document.getElementById("load_preview_iframe_txt").value='no';

}


function max_preview()
{
document.getElementById("preview_desk_iframe").style.display='block';
document.getElementById("load_preview_iframe0").style.display='block';
document.getElementById("load_preview_iframe1").style.display='block';
document.getElementById("load_preview_iframe_btn").style.display='block';
document.getElementById("load_preview_iframe_txt").value='yes';
updatePreview();


}
 function loadwebpage()
 {
    if(document.getElementById('iframeurl').value==''){
   document.getElementById('iframeurl').value=document.getElementById('txt_writeto').value;
  }

  document.getElementById('load_desk_iframe').src=document.getElementById('iframeurl').value;
  document.getElementById('load_mobi_iFrame').src=document.getElementById('iframeurl').value;

  hideeditor();

 }
 function loadframes()
 {
    if(document.getElementById('iframeurl').value==''){
   document.getElementById('iframeurl').value=document.getElementById('txt_writeto').value;
  }

  document.getElementById('load_desk_iframe').src=document.getElementById('iframeurl').value;
  document.getElementById('load_mobi_iFrame').src=document.getElementById('iframeurl').value;

 }
 function execute_terminal(source)
 {

  var txt_directory = document.getElementById("txt_directory").value;
  var txt_new_code = editor.getValue();
  var switch_dna_input  = document.getElementById('switch_dna_input').value;
   
        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML="Processing...";
   
if(source=='console'){
var txt_new_code =document.getElementById('append_text').value;
}

  if(txt_new_code=='clearthis'){
     
    editor.setValue('');

  }else if(txt_new_code=='clearlog'){
    document.getElementById('log_window').innerHTML='';

  }else{

  document.getElementById('log_window').innerHTML= document.getElementById('log_window').innerHTML;

      $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'execute_terminal':'ok',
        'txt_directory':txt_directory,
        'txt_new_code':txt_new_code,
        'switch_dna_input':switch_dna_input
      },

      success: function (data) {

        var remove_exec = document.getElementById('log_window').innerHTML;

     document.getElementById('log_window').innerHTML= data+'<hr style="border : 1px solid #7f7e7e">'+remove_exec;
        document.getElementById('notification_card').style.display='none';

     //alert(data);

      }

  })
  }

}

function load_file()
{
 
 var  txt_writeto = document.getElementById('txt_writeto').value;

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'load_file':'ok',
        'txt_writeto':txt_writeto
      },

      success: function (data) {

        var remove_exec = document.getElementById('log_window').innerHTML;

     editor.setValue(data);

     //alert(data);

      }

  })
}

function refresh_vars()
{
      $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'refresh_vars':'ok'
      },

      success: function (data) {

        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;

      }

  })
}


function add_var_file(file_path)
{
      $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'add_var_file':'ok',
        'file_path':file_path
      },

      success: function (data) {

        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;
      }

  })
}

function set_proj_theme(new_proj_theme)
{
      $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'set_proj_theme':'ok',
        'new_proj_theme':new_proj_theme
      },

      success: function (data) {

        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;
      }

  })
}


function save_file()
{
 
 var  txt_writeto = document.getElementById('txt_writeto').value;
 var  txt_new_code = editor.getValue();

  document.getElementById('log_window').innerHTML=document.getElementById('log_window').innerHTML;

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'save_file':'ok',
        'txt_writeto':txt_writeto,
        'txt_new_code':txt_new_code
      },

      success: function (data) {

        var remove_exec = document.getElementById('log_window').innerHTML;

        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;

      }

  })
}


function update_snippet()
{
  
 var  snippet_title = document.getElementById('snippet_title').value;
 var  txt_snippet_details = document.getElementById('txt_snippet_details').value;

  document.getElementById('log_window').innerHTML=document.getElementById('log_window').innerHTML;

   $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'update_snippet':'ok',
        'txt_snippet_title':snippet_title,
        'snippet_key':document.getElementById('snippkey').value,
        'txt_snippet_details':txt_snippet_details
      },

      success: function (data) {

        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;
        document.getElementById('snippet_edit_tools').style.display='block';

      }

  })
}

function delete_snippet()
{
  
   $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'delete_snippet':'ok',
        'snippet_key':document.getElementById('snippkey').value
      },

      success: function (data) {

        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;
        document.getElementById('snippet_edit_tools').style.display='block';

      }

  })
}


function pop_new_snippet()
{

var snippet_bar ='<div class="">'+
'<h5>Snippet Manager<hr></h5>'+
'<div>'+
'<div style="width:100%; padding-top:6px;"><input class="input_widget" type="text" id="snippet_title" autocomplete="off"  placeholder="Snippet Title">'+
'<div class="exe_btn" onclick="add_snippet()">Add</div></div>'+
'<div style="width:100%; padding-top:6px;"><input class="input_widget" id="qsnippet" style="width:100%;" autocomplete="off" placeholder="Search Snippet" onkeyup="qsnippet(this.value)"></div>'+
'</div>'+
'<div id="qsnippet_result" style="width:100%; padding-top:8px; " class="snippres"></div>'+
'<textarea class="snippet_card" id="txt_snippet_details" placeholder="Snippet Details"></textarea>'+
'<div style"width:100%; display:none;" id="snippet_edit_tools"><a href="./snippetlisting.php" target="_blank" class="text-white m-4 exe_btn">View All</a> | <a href="#" class="exe_btn text-white m-4" onclick="update_snippet()">Update</a> | <a href="#" class="text-white m-4 exe_btn" onclick="delete_snippet()">Delete</a><div>'+
'</div>';

magic_screen(snippet_bar, 'alert_box');

document.getElementById('snippet_title').focus();

}

function pop_snippet()
{

var snippet_bar ='<div class="">'+
'<h5>Snippet Manager<hr></h5>'+
'<div>'+
'<div style="width:100%; padding-top:6px;"><input class="input_widget" type="text" style="width:70%;" id="snippet_title" autocomplete="off"  placeholder="Snippet Title">'+
'<div class="exe_btn" onclick="add_snippet()">Add</div></div>'+
'<div style="width:100%; padding-top:6px;"><input class="input_widget" id="qsnippet" style="width:100%;" autocomplete="off" placeholder="Search Snippet" onkeyup="qsnippet(this.value)"></div>'+
'</div>'+
'<div id="qsnippet_result" style="width:100%; padding-top:8px; " class="snippres"></div>'+
'<textarea class="snippet_card" id="txt_snippet_details" placeholder="Snippet Details"></textarea>'+
'<div style"width:100%; display:none;" id="snippet_edit_tools"><a href="./snippetlisting.php" target="_blank" class="text-white m-4 exe_btn">View All</a> | <a href="#" class="exe_btn text-white m-4" onclick="update_snippet()">Update</a> | <a href="#" class="text-white m-4 exe_btn" onclick="delete_snippet()">Delete</a><div>'+
'</div>';

magic_screen(snippet_bar, 'alert_box');

document.getElementById('qsnippet').focus();

}


function edit_snippet(snippet_key)
{

document.getElementById('snippet_title').value=document.getElementById('snippet_title_'+snippet_key).innerHTML;
document.getElementById('snippkey').value=snippet_key;
document.getElementById('txt_snippet_details').value=document.getElementById('snippet_desc_'+snippet_key).value;
document.getElementById('qsnippet_result').style.display='none';
document.getElementById('snippet_edit_tools').style.display='block';
}


function loadapp_plan(appnotes)
{
var note_title =appnotes;

if(appnotes=='appvars'){

var note_title ='Variables';

}
var cleansave='';

if(appnotes=='appendtextlog')
{
var cleansave = '<div onclick="document.getElementById(\'app_notes_append\').value=\'\';save_notes(\''+appnotes+'\')" class="exe_btn">Clear N Save</div>';
}
var note_tag ='<h5>App '+note_title+'<hr><h5><div id="append_to_console"  style="border:1px solid #ccc; height:200px; overflow:auto; display:none;" onclick="this.style.display=\'none\';"></div><textarea id="app_notes" style="width:100%; height:300px; background-color:rgba(0,0,0,0.5); color:#FFF; border:none" placeholder="Type here"></textarea><hr><div onclick="save_notes(\''+appnotes+'\')" class="exe_btn">Save</div><div onclick="document.getElementById(\'app_notes_append\').value=\'\';loadapp_plan(\''+appnotes+'\');load_notes(\''+appnotes+'\')" class="exe_btn">Reload</div><div onclick="document.getElementById(\'append_to_console\').style.display=\'block\';load_notes(\''+appnotes+'\')" class="exe_btn">View in tag</div>'+cleansave;


magic_screen(note_tag, 'alert_box');

load_notes(appnotes);

document.getElementById('app_notes').focus();

}

function save_notes(appnotes)
{
 
 var  txt_writeto = "./"+appnotes+".txt";
if(appnotes=='appdbconfig'){

 var  txt_writeto = "./"+appnotes+".php";

}
if(appnotes=='appendtextlog')
{
  loadapp_plan(appnotes);
  
var combo_text =document.getElementById('app_notes_append').value+document.getElementById('append_text').value;

if(combo_text!=''){
 var  txt_new_code = '<textarea class="snippet_card" onclick="load_to_editor(this.value);">\n'+document.getElementById('append_text').value+'\n</textarea>'+"\n\n//*************** note *************\n\n"+document.getElementById('app_notes_append').value;
}else{

   var  txt_new_code = "";

}

}else{

   var  txt_new_code = document.getElementById('app_notes').value;

}
    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'save_file':'ok',
        'txt_writeto':txt_writeto,
        'txt_new_code':txt_new_code
      },

      success: function (data) {

        var remove_exec = document.getElementById('log_window').innerHTML;
        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;
        if(appnotes=='appendtextlog')
        {
          document.getElementById('alert_box').innerHTML='';
        }
      }

  })
}


function switch_terminals(active_terminal)

{

  document.getElementById('active_terminal').value=active_terminal;
}


function load_notes(appnotes)
{
 
 var  txt_writeto = "./"+appnotes+".txt";
if(appnotes=='appdbconfig'){

 var  txt_writeto = "./"+appnotes+".php";

}
    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'load_notes':'ok',
        'txt_writeto':txt_writeto
      },

      success: function (data) {

    document.getElementById('app_notes_append').value=data;
     document.getElementById('app_notes').value=data;
     document.getElementById('append_to_console').innerHTML=data;


      }

  })
}

function load_app_vars()
{
 
 var  txt_writeto = "./appvars.txt";

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'load_notes':'ok',
        'txt_writeto':txt_writeto
      },

      success: function (data) {

     document.getElementById('appvars_txt').value=data;


      }

  })
}

function load_quick_vars()
{
 
 var  txt_writeto = "./quick_vars.txt";

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'load_notes':'ok',
        'txt_writeto':txt_writeto
      },

      success: function (data) {

     document.getElementById('appvars_txt').value=data;


      }

  })
}
function qsnippet(qasn_snippets)
{
    var switch_dna_input  = document.getElementById('switch_dna_input').value;

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'qasn_snippets_btn':'ok',
        'qasn_snippets':qasn_snippets,
        'switch_dna_input':switch_dna_input
      },

      success: function (data) {
        document.getElementById('qsnippet_result').style.display='block';
        document.getElementById('qsnippet_result').innerHTML=data;
     //alert(data);

      }

  })
}

function hash_text_search(hash_qstr){
  load_app_vars();
  document.getElementById('hash_text_search').value="~"+hash_qstr;

  var curr_qstr = (document.getElementById('appvars_txt').value);

  var flagged_hash_val= document.getElementById('hash_text_search').value;

  var clip_hashed = curr_qstr.replace(flagged_hash_val, "");

  var replaced_hases = clip_hashed.split(/[ ; } : " < > /> = , "\n" `` \' ]+/);

// find all strings in array containing 'thi'

const found_hashes = replaced_hases.filter(s => s.includes(hash_qstr));

let unique_hashes = [...new Set(found_hashes)];

var text_output = '<Input type="hidden" id="hash_focus" value="0_hash_text_node"/>';

var i;

for (i = 0; i < unique_hashes.length; i++) {
 text_output += '<textarea id="'+i+'_hash_text_node" class="snippet_card hash_focus" onclick="load_to_hash_editor(this.value);  document.getElementById(\'flag_search_hash\').style.display=\'none\'" onkeydown = "if (event.keyCode == 13){ event.preventDefault(); load_to_hash_editor(this.value); document.getElementById(\'flag_search_hash\').style.display=\'none\';}" style="width: 100%; height: 80px; margin-top: 8px;" readonly >'+unique_hashes[i]+'</textarea>';
}

if(i>0){

  document.getElementById('flag_search_hash').style.display='inline-block';
  
  document.getElementById('flag_search_hash').innerHTML="<b><u>Words Vars</u></b><br><br>"+text_output;
}else{

  document.getElementById('flag_search_hash').style.display='none';


}

}

//===============
function show_quick_vars()
{

  load_quick_vars();

  var curr_qstr = (document.getElementById('appvars_txt').value);

  var replaced_hases = curr_qstr.split(",");

// find all strings in array containing 'thi'

let unique_hashes = [...new Set(replaced_hases)];

var text_output = '<Input type="hidden" id="hash_focus" value="0_hash_text_node"/>';

var i;

for (i = 0; i < unique_hashes.length; i++) {
 text_output += '<div id="'+i+'_quick_vars" class="function_card" onclick="load_to_editor(this.innerHTML);" style="border-bottom:1px solid #CCC; margin-bottom:9px; display:block; border-right:1px solid #ccc; padding-right:3px;  padding-left:3px;" >'+unique_hashes[i]+'</div>';
}

  document.getElementById('quick_vars_card').style.display='inline-block';
  
  document.getElementById('quick_vars_card').innerHTML=text_output;

}


//==============

function flag_search(qasn_snippets)
{
    var switch_dna_input  = document.getElementById('switch_dna_input').value;
    
  	trigger_log_search(qasn_snippets);
  
  	var dope_card='<div id="dope_card"></div>';

  if(qasn_snippets!=''){
     document.getElementById('flag_search').value="@"+qasn_snippets;
    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'flag_search':'ok',
        'qasn_snippets':qasn_snippets,
        'switch_dna_input':switch_dna_input
      },

      success: function (data) {
        if(data!='')
        {
        document.getElementById('flag_search_div').style.display='inline-block';
        document.getElementById('flag_search_div').innerHTML=data+dope_card;
        document.getElementById('trigger_arrow_keys').value='trigger_arrow_keys';
        }else{
        document.getElementById('flag_search_div').style.display='none';
        document.getElementById('trigger_arrow_keys').value='untrigger_arrow_keys';

        }

     //alert(data);

      }

  })

  }
}


function flag_console_search(qasn_snippets)
{
      var switch_dna_input  = document.getElementById('switch_dna_input').value;  	  
     trigger_log_search(qasn_snippets);
  
  if(qasn_snippets!=''){
     document.getElementById('flag_search').value="@"+qasn_snippets;
    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'flag_console_search':'ok',
        'qasn_snippets':qasn_snippets,
        'switch_dna_input':switch_dna_input
      },

      success: function (data) {
        if(data!='')
        {
        document.getElementById('flag_search_div').style.display='inline-block';
        document.getElementById('flag_search_div').innerHTML=data;
        document.getElementById('trigger_arrow_keys').value='trigger_arrow_keys';
        }else{
        document.getElementById('flag_search_div').style.display='none';
        document.getElementById('trigger_arrow_keys').value='untrigger_arrow_keys';
        }

     //alert(data);

      }

  })

  }
}


document.getElementById('active_code_window').addEventListener('click', e => {
switch_terminals('main');
})


document.getElementById('append_text').addEventListener('keyup', e => {
var cpos =e.target.selectionStart;
var str =document.getElementById('append_text').value;

var cursorPosition = cpos;

  var preText = str.substring(0, cursorPosition);
        var words = preText.split("@");
        var lastletter = (words[words.length-1]);

   var replace_at=lastletter.replace("@", "");
   
   flag_console_search(replace_at);

  var query_hash_str = preText.split("~");

  var query_hash_str_ls = (query_hash_str[query_hash_str.length-1]);

  var replace_hash_at=query_hash_str_ls.replace("~", "");

  hash_text_search(replace_hash_at);

})

function pop_new_instance()
{

  window.open('./appview', 'newwindow', 'width=1300,height=900'); 
              return false;
              
}

//--------------------------- Start -----------------
//=========== Start Ajax 


function insert_code_time(txt_end, txt_folder)
{
  
$.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'insert_code_time': 'ok',
         'txt_end': txt_end,
         'main_url': window.location.href,
         'txt_folder': txt_folder
      },

      success: function (data) {
		document.getElementById('tct_span').innerHTML=data;
		//alert(data)

      }

  });

}


//=========== End Ajax 

//--------------------------- End -----------------

function loop_folder(folder)
{
var basepath_txt = document.getElementById('basepath_txt').value+folder;

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'loop_folder':'ok',
        'folder':basepath_txt
      },

      success: function (data) {
          if(data=='DNF'){
        //document.getElementById('notification_card').style.display='block';
        //ocument.getElementById('notification_card').innerHTML='Directory '+basepath_txt+' Not found';
          }else{
        var folder_card= '<div  class="function_card" >Directory Listing for '+basepath_txt+'<br>'+data+'<hr></div>'
        document.getElementById('flag_search_pin').innerHTML=folder_card+'<hr>'+document.getElementById('flag_search_pin').innerHTML
        document.getElementById('log_window').innerHTML=folder_card+document.getElementById('log_window').innerHTML;
        document.getElementById('notification_card').style.display='none';
        document.getElementById('minifolder').style.display='block';
        document.getElementById('qfolder_res').innerHTML=folder_card+document.getElementById('qfolder_res').innerHTML;
        document.getElementById('log_window').scrollTop=0;
        document.getElementById('minifolder').scrollTop=0;
        document.getElementById('mainsearch').focus();
          }

      }

  })
}

function load_start_folder(folder)
{
var basepath_txt = folder;

  //alert(folder);
  
    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'loop_folder':'ok',
        'folder':basepath_txt
      },

      success: function (data) {
          if(data=='DNF'){
        //document.getElementById('notification_card').style.display='block';
        //ocument.getElementById('notification_card').innerHTML='Directory '+basepath_txt+' Not found';
          }else{
        var folder_card= '<div  class="function_card" > Project Directory <br>'+data+'<hr></div>'
        document.getElementById('log_window').innerHTML=folder_card+document.getElementById('log_window').innerHTML;
        document.getElementById('flag_search_pin').innerHTML=folder_card+'<hr>'+document.getElementById('flag_search_pin').innerHTML
        document.getElementById('notification_card').style.display='none';
        document.getElementById('log_window').scrollTop=0;
        document.getElementById('active_code_window').focus();
          }

      }

  })
}



function loop_open_folder(folder)
{
var basepath_txt = folder;

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'loop_folder':'ok',
        'folder':basepath_txt
      },

      success: function (data) {
          if(data=='DNF'){
        //document.getElementById('notification_card').style.display='block';
        //ocument.getElementById('notification_card').innerHTML='Directory '+basepath_txt+' Not found';
          }else{
        var folder_card= '<div  class="function_card" >Directory Listing for '+basepath_txt+'<br>'+data+'<hr></div>'
        document.getElementById('log_window').innerHTML=folder_card+document.getElementById('log_window').innerHTML;
            
       	document.getElementById('flag_search_pin').innerHTML=folder_card+'<hr>'+document.getElementById('flag_search_pin').innerHTML
        document.getElementById('notification_card').style.display='none';
        document.getElementById('minifolder').style.display='block';
        document.getElementById('qfolder_res').innerHTML=folder_card+document.getElementById('qfolder_res').innerHTML;
        document.getElementById('log_window').scrollTop=0;
        document.getElementById('minifolder').scrollTop=0;
        document.getElementById('mainsearch').focus();
          }

      }

  })
}
function add_snippet()
{

 var  snippet_title = document.getElementById('snippet_title').value;
 var  txt_snippet_details = document.getElementById('txt_snippet_details').value;

  document.getElementById('log_window').innerHTML=document.getElementById('log_window').innerHTML;

if(snippet_title!=''){
    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'asn_snippets_insert_btn':'ok',
        'txt_snippet_title':snippet_title,
        'txt_snippet_details':txt_snippet_details
      },

      success: function (data) {

        var remove_exec = document.getElementById('log_window').innerHTML;

     alert(data);

      }

  })
}else{
  alert('add Snippet Title');
}

}


function setTextToCurrentPos(str) { 
  
var flagged_val =document.getElementById('flag_search').value;


var selection = editor.getSelection();

        if(selection.length>0){
            editor.replaceSelection(str);
        }
        else{

            var doc = editor.getDoc();
            var cursor = doc.getCursor();

            var pos = {
               line: cursor.line,
               ch: cursor.ch
            }

            doc.replaceRange(str, pos);
            
            editor.setValue(editor.getValue().replace(flagged_val, ""));

            var back_to_typed_start=(cursor.ch-(flagged_val.length))+str.length;

            var pos2 = {
               line: cursor.line,
               ch: back_to_typed_start
            }

            editor.focus();

            editor.setCursor(pos2)

        }

}
 


function load_to_editor(content)
{

//var strip_br = content.replace(/<br\s*\/?>/mg,"");
var strip_br = content;

var curr_load_to = document.getElementById('active_terminal').value;

if(curr_load_to=='console'){
load_to_console(content);
}else{
setTextToCurrentPos(strip_br);; 
}
document.getElementById('setcursor').value='';
}



function load_to_hash_editor(content)
{
  var strip_br = content.replace(/<br\s*\/?>/mg,"");

  var curr_load_to = document.getElementById('active_terminal').value;

  if(curr_load_to=='console'){
  
  load_to_hash_console(content);

    }else{

      setTextToCurrentPos_hash(strip_br);

    }

}

function setTextToCurrentPos_hash(str) { 

    
var flagged_val =document.getElementById('hash_text_search').value;

var selection = editor.getSelection();

        if(selection.length>0){
            editor.replaceSelection(str);
        }
        else{

            var doc = editor.getDoc();
            var cursor = doc.getCursor();

            var pos = {
               line: cursor.line,
               ch: cursor.ch
            }

            doc.replaceRange(str, pos);
            
            editor.setValue(editor.getValue().replace(flagged_val, ""));

            var back_to_typed_start=(cursor.ch-(flagged_val.length))+str.length;

            var pos2 = {
               line: cursor.line,
               ch: back_to_typed_start
            }

            editor.focus();

            editor.setCursor(pos2)

        }
    

 }


function load_to_console(content)
{
  var strip_br = content.replace(/<br\s*\/?>/mg,"");

setTextToCurrentPos_console(strip_br);

}

function setTextToCurrentPos_console(content) { 

    var curPos = document.getElementById("append_text").selectionStart; 
    
    var flagged_val =document.getElementById('flag_search').value;

    //let x = ($("#txt_new_code").val()).replace(flagged_val, "");

    let x = $("#append_text").val(); 

    let text_to_insert =content; 

    var back_to_typed_start=(curPos-(flagged_val.length))+content.length;
    
    $("#append_text").val( x.slice(0, curPos) + text_to_insert + x.slice(curPos)); 
    
    document.getElementById('flag_search').value="";

    document.getElementById("append_text").value = ($("#append_text").val()).replace(flagged_val, "");
    setCaretToPos(document.getElementById("append_text"), back_to_typed_start);

 }

function load_to_hash_console(content)
{
  var strip_br = content.replace(/<br\s*\/?>/mg,"");

setTextToCurrentPos_hash_console(strip_br);

}

function setTextToCurrentPos_hash_console(content) { 

    var curPos = document.getElementById("append_text").selectionStart; 
    
    var flagged_val =document.getElementById('hash_text_search').value;

    //let x = ($("#txt_new_code").val()).replace(flagged_val, "");

    let x = $("#append_text").val(); 

    let text_to_insert =content; 

    var back_to_typed_start=(curPos-(flagged_val.length))+content.length;
    
    $("#append_text").val( x.slice(0, curPos) + text_to_insert + x.slice(curPos)); 
    
    document.getElementById('hash_text_search').value="";

    document.getElementById("append_text").value = ($("#append_text").val()).replace(flagged_val, "");
    setCaretToPos(document.getElementById("append_text"), back_to_typed_start);

 }


function load_to_path(content)
{

  document.getElementById('txt_writeto').value=content;

}

function add_to_frame(filepath)
{
  document.getElementById('iframeurl').value=filepath;

  loadwebpage();
}
function showeditor(){

 document.getElementById('hideeditor').style.display='inline-block'; 
 document.getElementById('showeditor').style.display='none'; 
 document.getElementById('time').style.display='block'; 
 document.getElementById('txt_new_code').style.display='inline-block';
 document.getElementById('parent_log_window').style.display='inline-block';
 document.getElementById('active_code_window').style.display='inline-block';
  document.getElementById('active_code_window').focus();
}

function hideeditor(){

 document.getElementById('showeditor').style.display='inline-block';  
 document.getElementById('txt_new_code').style.display='none';
 document.getElementById('parent_log_window').style.display='none';
 document.getElementById('hideeditor').style.display='none'; 
 document.getElementById('active_code_window').style.display='none';
 document.getElementById('time').style.display='none'; 
 document.getElementById('active_code_window').focus();

}

function clearframeurl()
{
document.getElementById('iframeurl').value='';

loadwebpage();

}

window.onkeyup = function(e) {

        if(e.altKey  && e.keyCode=='72'){
            e.preventDefault();

            hideeditor();
        }

        if(e.altKey  && e.keyCode=='82'){
            e.preventDefault();

          var curr_path = document.getElementById('txt_writeto').value;

          document.getElementById('iframeurl').value=curr_path;

          loadwebpage();

         }
        if(e.altKey  && e.keyCode=='84'){
            e.preventDefault();
            showeditor();

            document.getElementById('txt_new_code').focus();
        }
        if(e.keyCode=='27'){
            e.preventDefault();

            document.getElementById('flag_search_div').style.display='none';
            document.getElementById('minifolder').style.display='none';
           	document.getElementById('flag_search_pin').style.display='none';


         }
  
        if(e.keyCode==115)
        {

            e.preventDefault();
            document.getElementById('folderpath').focus();

          
        }
  
        if(e.keyCode==113)
            {

            e.preventDefault();

            var flag_focus = document.getElementById('flag_focus').value;
                    var moves = $(".flag_focus");

        if(document.getElementById('flag_focused').value=='focused'){

                  for(i = 0; i <= moves.length; i++) {
                            if (moves[i] == $(".flag_focus:focus").get(0)) {
                               $(moves[i + 1]).focus();
                                break;
                            }
                        }

          }
  
  if (document.getElementById(flag_focus) != null && document.activeElement!=document.getElementById(flag_focus)){

    document.getElementById(flag_focus).focus();
    document.getElementById('flag_focused').value='focused';
  }
  }

   if(e.keyCode==114){
              e.preventDefault();

    var hash_focus = document.getElementById('hash_focus').value;

 e.preventDefault();

    var flag_focus = document.getElementById('hash_focus').value;
            var moves = $(".hash_focus");

if(document.getElementById('flag_focused').value=='hash_focused'){

          for(i = 0; i <= moves.length; i++) {
                    if (moves[i] == $(".hash_focus:focus").get(0)) {
                       $(moves[i + 1]).focus();
                        break;
                    }
                }

  }
  
  if (document.getElementById(hash_focus) != null && document.activeElement!=document.getElementById(hash_focus)){

    document.getElementById(hash_focus).focus();
    document.getElementById('flag_focused').value='hash_focused';
  }

    } 

}

        function disableScroll() { 
            // Get the current page scroll position 
            scrollTop =  
              window.pageYOffset || document.documentElement.scrollTop; 
            scrollLeft =  
              window.pageXOffset || document.documentElement.scrollLeft, 
  
                // if any scroll is attempted, 
                // set this to the previous value 
                window.onscroll = function() { 
                    window.scrollTo(scrollLeft, scrollTop); 
                }; 
        }

document.getElementById('load_desk_iframe').addEventListener('keydown', function (e){
        if(e.altKey  && e.keyCode=='72'){
            e.preventDefault();

            hideeditor();
        }

        if(e.altKey  && e.keyCode=='86'){
            e.preventDefault();

            loadapp_plan('appvars');
        }

}, false);


var onkeyup_iframe = document.getElementById("load_desk_iframe");
var iframeDoc = onkeyup_iframe.contentDocument || onkeyup_iframe.contentWindow.document;

function handleIframeKeyUp(evt) {
    //alert("Key up!");
}

if (typeof iframeDoc.addEventListener != "undefined") {
    iframeDoc.addEventListener("keyup", handleIframeKeyUp, false);
} else if (typeof iframeDoc.attachEvent != "undefined") {
    iframeDoc.attachEvent("onkeyup", handleIframeKeyUp);
}


document.getElementById('append_text').addEventListener('keydown', function (e){

    // Do your key combination detection
        if(e.altKey  && e.keyCode=='69'){
            e.preventDefault();

            execute_terminal('console');
        }
        
        if(e.altKey  && e.keyCode=='84'){
            e.preventDefault();
            showeditor();

            document.getElementById('txt_new_code').focus();
        }
        
   if(e.altKey  && e.keyCode=='87'){
            e.preventDefault();

            document.getElementById('log_window').innerHTML='';
         }

      if(e.altKey  && e.keyCode=='76'){
            e.preventDefault();

            document.getElementById('folderpath').focus();

         }
        if(e.altKey  && e.keyCode=='65'){
            e.preventDefault();
            pop_new_snippet();
           qsnippet('add new snippet dialog');


         }
        if(e.altKey  && e.keyCode=='81'){
            e.preventDefault();

            document.getElementById('mainsearch').focus();
            document.getElementById('mainsearch').value='';

         }

        if(e.altKey  && e.keyCode=='67'){
            e.preventDefault();

            document.getElementById('append_text').focus();

         }

  }, false);

function fold_mobi()
{
  document.getElementById('preview_desk_iframe').style.height='88vh';
  document.getElementById('preview_desk_iframe').style.width='400px';
  document.getElementById('load_preview_iframe0').style.width='320px';
  document.getElementById('load_preview_iframe1').style.width='320px';
  document.getElementById('fold_mobi').style.display='none';
  document.getElementById('expand_mobi').style.display='inline-block';


}

function expand_mobi()
{
  document.getElementById('preview_desk_iframe').style.height='468px';
  document.getElementById('preview_desk_iframe').style.width='1252px';
  document.getElementById('load_preview_iframe0').style.width='100%';
  document.getElementById('load_preview_iframe1').style.width='100%';
  document.getElementById('fold_mobi').style.display='inline-block';
  document.getElementById('expand_mobi').style.display='none';


}

document.getElementById('mainsearch').addEventListener('keydown', function (e){

//document.getElementById('notification_card').style.display='inline-block';
//document.getElementById('notification_card').innerHTML=e.keyCode;

    // Do your key combination detection
        if(e.keyCode=='13'){
            e.preventDefault();
            document.getElementById('mainsearch').value='';
        }

}, false);



document.getElementById('active_code_window').addEventListener('keydown', function (e){
    // Do your key combination detection
        if(e.altKey  && e.keyCode=='69'){
            e.preventDefaultault();

            execute_terminal('');
        }

        if(e.altKey  && e.keyCode=='83'){
            e.preventDefault();

            document.getElementById('function_card').focus();
        }

        if(e.altKey  && e.keyCode=='84'){
            e.preventDefault();
            showeditor();

            document.getElementById('txt_new_code').focus();
        }

        if(e.altKey  && e.keyCode=='78'){
            e.preventDefault();

      pop_snippet();
         }

      if(e.altKey  && e.keyCode=='79'){
            e.preventDefault();

      save_file();
         }
      if(e.ctrlKey  && e.keyCode=='83'){
            e.preventDefault();

      save_file();
         }
      if(e.altKey  && e.keyCode=='87'){
            e.preventDefault();

            document.getElementById('log_window').innerHTML='';
         }

      if(e.altKey  && e.keyCode=='76'){
            e.preventDefault();

            document.getElementById('folderpath').focus();

         }

      if(e.altKey  && e.keyCode=='73'){
            e.preventDefault();

            indent_line();

         }

        if(e.altKey  && e.keyCode=='82'){
            e.preventDefault();

          var curr_path = document.getElementById('txt_writeto').value;

          document.getElementById('iframeurl').value=curr_path;

          loadwebpage();

         }
        if(e.altKey  && e.keyCode=='65'){
            e.preventDefault();
            pop_new_snippet();
           qsnippet('add new snippet dialog');


         }
        if(e.altKey  && e.keyCode=='81'){
            e.preventDefault();

            document.getElementById('mainsearch').focus();
            document.getElementById('mainsearch').value='';

         }

        if(e.altKey  && e.keyCode=='67'){
            e.preventDefault();

            document.getElementById('append_text').focus();

         }

        if(e.altKey  && e.keyCode=='66'){
            e.preventDefault();

            document.getElementById('basepath_txt').focus();

         }

        if(e.altKey  && e.keyCode=='66'){
            e.preventDefault();

            document.getElementById('basepath_txt').focus();

         }
        if(e.altKey  && e.keyCode=='86'){
            e.preventDefault();

            loadapp_plan('appvars');
        }
        if(e.keyCode=='27'){
            e.preventDefault();

            document.getElementById('flag_search_div').style.display='none';
            document.getElementById('minifolder').style.display='none';
            document.getElementById('flag_search_hash').style.display='none';

         }
        if(e.altKey  && e.keyCode=='38'){
            e.preventDefault();

            scrollWinup();
        }
                if(e.altKey  && e.keyCode=='40'){
            e.preventDefault();

            scrollWindown();
        }


 
 push_title();
}, false);




function updatePreview() {

push_title();

  if(document.getElementById('load_preview_iframe_txt').value=='yes'){
  
  var ifrNo = 0;
  var ifrHidden;
  var ifr;
   var filefolder1 = document.getElementById('iframeurl').value;
   var txt_new_code = editor.getValue();

   var filefolder2 = filefolder1.split('/');
   var filefolder3 = filefolder2[filefolder2.length-1];
   var filefolder = filefolder1.replace(filefolder3, "");


  $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'save_file_preview':'ok',
        'txt_writeto':filefolder,
        'txt_new_code':txt_new_code
      },

      success: function (data) {

//alert(data);

      }

  })

  // var previewFrame = document.getElementById('load_preview_iframe');
  // var preview =  previewFrame.contentDocument ||  previewFrame.contentWindow.document;

  // preview.open();
  // preview.write(document.getElementById("txt_new_code").value);
  // preview.close();

  

      }
    }
    var ifrNo = 0;
  var ifrHidden;
  var ifr;
function swap()
{

   var filefolder1 = document.getElementById('iframeurl').value;
   var txt_new_code = editor.getValue();

   var filefolder2 = filefolder1.split('/');
   var filefolder3 = filefolder2[filefolder2.length-1];
   var filefolder = filefolder1.replace(filefolder3, "");
   var new_file_path =filefolder+"/load_preview_iframe_23_01_21_438pm.php";
check_if_file_exists(new_file_path);
var check_file = document.getElementById('foundfile').value;
  if(document.getElementById('load_preview_iframe_txt').value=='yes'){

if(check_file=='200'){

        ifr = document.getElementById('load_preview_iframe' + ifrNo);
        ifrNo = 1 - ifrNo;
        ifrHidden = document.getElementById('load_preview_iframe' + ifrNo);
       
        ifr.onload = null;

        ifrHidden.onload = function() {

        ifr.style.display = 'none';
        ifrHidden.style.display = 'block';
        var newscroll_pos =document.getElementById('prevscroll_px').value;
        if(newscroll_pos=='')
        {
        newscroll_pos=0;
        }
        ifrHidden.contentWindow.scrollTo(0, newscroll_pos);

         }

         ifrHidden.src = new_file_path;
}

}

}
setInterval(function () 
{
   swap();
}, 3000);


setInterval(function () 
{
  document.getElementById('notification_card').style.display='none';
}, 10000);


function check_if_file_exists(filepath)
{
    if(document.getElementById('load_preview_iframe_txt').value=='yes'){

  $.ajax({
    url:filepath,
    type:'HEAD',
    error: function()
    {
        //file not exists
        document.getElementById('foundfile').value='404';

    },
    success: function()
    {
        //file exists
        document.getElementById('foundfile').value='200';

     //alert(200);

    }
});
}
}

function indent_line()
{

    
    var code_line = $("#txt_new_code").val();

    var curPos = document.getElementById("txt_new_code").selectionStart; 

    $("#txt_new_code").val( code_line.slice(0, curPos) + "  " + code_line.slice(curPos)); 

    setCaretToPos(document.getElementById("txt_new_code"), curPos+2);

}


//Make the DIV element draggagle:
dragElement(document.getElementById("parent_log_window"));
dragElement(document.getElementById("preview_desk_iframe"));

function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (document.getElementById(elmnt.id + "header")) {
    /* if present, the header is where you move the DIV from:*/
    document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
  } else {
    /* otherwise, move the DIV from anywhere inside the DIV:*/
    elmnt.onmousedown = dragMouseDown;
  }

  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    // get the mouse cursor position at startup:
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();
    // calculate the new cursor position:
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    // set the element's new position:
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    /* stop moving when mouse button is released:*/
    document.onmouseup = null;
    document.onmousemove = null;
  }
}


var element = document.getElementById('parent_log_window');
var resizer = document.createElement('div');
resizer.className = 'resizer';
resizer.style.width = '10px';
resizer.style.height = '10px';
resizer.style.background = 'red';
resizer.style.position = 'absolute';
resizer.style.right = 0;
resizer.style.bottom = 0;
resizer.style.cursor = 'se-resize';
element.appendChild(resizer);
resizer.addEventListener('mousedown', initResize, false);

function initResize(e) {
   window.addEventListener('mousemove', Resize, false);
   window.addEventListener('mouseup', stopResize, false);
}
function Resize(e) {
   element.style.width = (e.clientX - element.offsetLeft) + 'px';
   element.style.height = (e.clientY - element.offsetTop) + 'px';
}
function stopResize(e) {
    window.removeEventListener('mousemove', Resize, false);
    window.removeEventListener('mouseup', stopResize, false);
}



function trigger_log_search(qstr)
{
  document.getElementById("function_card").value=qstr;

  search_log();
}


function dope_search_log(count_nodes)
{
 
  if(count_nodes=='')
  {
  document.getElementById('flag_search_pin').style.display='none';

  }else{
     
    document.getElementById('flag_search_pin').style.display='block';

  }

}

function search_log() {
  var input = document.getElementById("function_card");
  var filter = input.value.toLowerCase();
  var nodes = document.getElementsByClassName('function_card');  

  var count_nodes=0;

if(input.value=='clearlog'){

  document.getElementById('log_window').innerHTML='';
}else{
  for (i = 0; i < nodes.length; i++) {
    if (nodes[i].innerText.toLowerCase().includes(filter)) {  

      nodes[i].style.display = "block";  
      count_nodes=1;
            
    } else {
      nodes[i].style.display = "none";
    }
  }
  
 dope_search_log(count_nodes);


}
}



function setSelectionRange(input, selectionStart, selectionEnd) {
  if (input.setSelectionRange) {
    input.setSelectionRange(selectionStart, selectionEnd);
        input.focus();
  }
  else if (input.createTextRange) {
    var range = input.createTextRange();
    range.collapse(true);
    range.moveEnd('character', selectionEnd);
    range.moveStart('character', selectionStart);
    range.select();
    input.focus();


  }
}

function setCaretToPos (input, pos) {
   setSelectionRange(input, pos, pos);
}

//Catch cursor change event
  //Catch cursor change event
  editor.on('cursorActivity',function(e){

    var line = e.doc.getCursor().line;   //Cursor line
    var ch = e.doc.getCursor().ch;      //Cursor character

        //n = stringToMatch.length;

    var preText = e.doc.getLine(line).substr(0, ch);

  var words = preText.split("@");
  var lastletter = (words[words.length-1]);

  var replace_at=lastletter.replace("@", "");

  var query_hash_str = preText.split("~");

  var query_hash_str_ls = (query_hash_str[query_hash_str.length-1]);

  var replace_hash_at=query_hash_str_ls.replace("~", "");
if(words.length>1){
    flag_search(replace_at);
  }
  if(query_hash_str.length>1){
    hash_text_search(replace_hash_at);
  }

  });

document.getElementById('active_code_window').addEventListener('keyup', e => {
  
  var str =editor.getValue();

  
  updatePreview();
  
var txt_end =document.getElementById('time').innerHTML;
var txt_folder =document.getElementById('txt_writeto').value;

  insert_code_time(txt_end, txt_folder) 


  if(str=='')
  {
    document.getElementById('txt_writeto').value='';
  }

})

function move_elem_to(x_pos, y_pos, elem_id) 
{
  var d = document.getElementById(elem_id);
  //d.style.position = "absolute";
  d.style.left = x_pos+'px';
  d.style.top = y_pos+'px';
}

function resize_move_elem_to(x_pos, y_pos, elem_id, new_size) 
{
  var d = document.getElementById(elem_id);
  //d.style.position = "absolute";
  d.style.left = x_pos+'px';
  d.style.top = y_pos+'px';
  
  d.style.width=new_size;
}

function push_to_top(push_to_top)
{
  document.getElementById('alwaysontop').value =  parseInt(document.getElementById('alwaysontop').value)+99
  document.getElementById(push_to_top).style.zIndex=(document.getElementById('alwaysontop').value);
}

function switch_dna()
{
  var switch_dna_input = document.getElementById('switch_dna_input').value;
  
  if(switch_dna_input=='ON')
  {
    document.getElementById('switch_dna_input').value="OFF";
    document.getElementById('switch_dna_btn').innerHTML="DNA : OFF";
   

  }else{
    document.getElementById('switch_dna_input').value="ON";
    document.getElementById('switch_dna_btn').innerHTML="DNA : ON";

  }
  
    
      //=========== Start Ajax 
      $.ajax({ 
            url: './ajaxexe.php',
            type: "POST",
            data: {
              'switch_dna_session': 'ok',
               'switch_dna_input': document.getElementById('switch_dna_input').value
            },


            success: function (data) {

     // alert(data)

            }

        });



      //=========== End Ajax 

}

function change_scroll_bar_mobi(){
  var scrollbar_style='<style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style>';

  let mobi_frameElement = document.getElementById("load_mobi_iFrame");

  let mobi_doc = mobi_frameElement.contentDocument || mobi_frameElement.documentElement;

  mobi_doc.head.innerHTML = scrollbar_style+mobi_doc.head.innerHTML;

 }
function change_scroll_bar_desk(){
  var scrollbar_style='<style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style>';

  let desk_frameElement = document.getElementById("load_desk_iframe");
  let desk_doc = desk_frameElement.contentDocument || desk_frameElement.documentElement;
  desk_doc.head.innerHTML = scrollbar_style+desk_doc.head.innerHTML;

 }


function change_scroll_bar_prev1(){
  var scrollbar_style='<style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style> <script>window.onload = $("#prevscroll_px", parent.document).val("from frame 1 ");</script>';

  let load_preview_iframe1 = document.getElementById("load_preview_iframe1");

  let prev1 = load_preview_iframe1.contentDocument || load_preview_iframe1.documentElement;

  prev1.head.innerHTML = scrollbar_style+prev1.head.innerHTML;
 
 }

 function change_scroll_bar_prev0(){
  var scrollbar_style='<style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style> <script>window.onload = $("#prevscroll_px", parent.document).val("from frame 0 ");</script>';

  let load_preview_iframe0 = document.getElementById("load_preview_iframe0");

  let prev2 = load_preview_iframe0.contentDocument || load_preview_iframe0.documentElement;

  prev2.head.innerHTML = scrollbar_style+prev2.head.innerHTML;
 
 }

    function push_title()
    {
        document.title='Code Mirror Active File : - '+document.getElementById('txt_writeto').value ;
    }

var timeDisplay = document.getElementById("time");


function refreshTime() {
  var dateString = new Date().toLocaleString("en-US", {timeZone: "Africa/Nairobi"});
  var formattedString = dateString.replace(", ", " ");
  timeDisplay.innerHTML = formattedString;
}

setInterval(refreshTime, 1000);

//=========== Start Ajax 


function pop_db_tables()
{
$.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
      	'pop_db_tables': 'ok'
      },

      success: function (data) {

//alert(data)
		document.getElementById('log_window').innerHTML=data+'<hr>'+document.getElementById('log_window').innerHTML;
         document.getElementById('flag_search_pin').innerHTML=data+'<hr>'+document.getElementById('flag_search_pin').innerHTML
      }

  });

}


//=========== End Ajax 

function magic_form_tag(tag_name, column_name, table, loop_or_node, full_cell_yes_no, dynamic_yes_no,type)
{
$.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
      	'magic_form_tag': 'ok',
          'tag_name':tag_name,
		  'column_name':column_name,
		  'table':table,
		  'loop_or_node':loop_or_node,
		  'full_cell_yes_no':full_cell_yes_no,
          'dynamic_yes_no':dynamic_yes_no,
		  'type':type
      },

      success: function (data) {
//alert(data)
		load_to_editor(data);
      }

  });

}


//=========== End Ajax 

        // window.addEventListener('beforeunload', function (e) { 


        //     e.preventDefault();
        //     e.returnValue = ''; 
        // }); 