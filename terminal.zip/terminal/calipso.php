<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include("./data_control/datafeed.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>calipso</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">

      <div class="row mt-5 pt-5 justify-content-center">
        <h5 class="col-md-12 border-bottom border-dark pb-2 pl-0 text-white" style="text-align: left;"><span class="bg-success p-2">calipso</span></h5>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          
       <!--start accordion tray -->
       <div class="accordion col-md-12 p-0 m-0" id="dashboard_accordion">
         <!--Start  Dance_Moves accordion_item node-->
        <div class="card skin_plasma">
             <!--Start accordion_item Head -->
          <div class="card-header bg-success  p-0" id="head_Dance_Moves">
            <h2 class="mb-0">
              <button class="btn btn-link text-white btn-block text-left" type="button" data-toggle="collapse" data-target="#body_Dance_Moves" aria-expanded="true" aria-controls="body_Dance_Moves">
              <h4 class="col-md-12  pb-2 pl-0" style="text-align: left;">
                  <span class="text-white p-2 ">Dance Moves</span>
              </h4>
              </button>
            </h2>
          </div>
         <!--End Dance_Moves accordion_item Head -->
         <!--Start Dance_Moves accordion_item Body -->
          <div id="body_Dance_Moves" class="collapse" aria-labelledby="head_Dance_Moves" data-parent="#dashboard_accordion">
            <div class="card-body skin_plasma">
              <!--Start Dance_Moves Dash Cards Section-->
              <div class="row justify-content-center" style="text-align: center;">
                  <!--Start Dash icon card-->
					<!--<{next_Dance_Moves_dash__icon}/>-->
                  <!--End Dance_Moves Dash icon card-->
              </div>
             <!--End Dance_Moves Dash Cards Section-->
            </div>
          </div>
             <!--End Dance_Moves accordion_item Body -->
         </div>
            <!--End Dance_Moves accordion_item node-->

		<!--<{next_accordion_node}/>-->
       </div>
          <!--End accordion tray -->
    
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>
