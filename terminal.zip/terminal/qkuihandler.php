<?php
//$tbl_str=magic_sql_show_tables($db);
//$tbl_list=explode(",", $tbl_str);

$dbshowtbls_q = mysqli_query($single_conn, "SHOW TABLES FROM `$dbname`");

$tbl_json_res=array();

while($dbshowtbls_r=mysqli_fetch_array($dbshowtbls_q))
{
  $tbl_json_res[]='"'.$dbshowtbls_r[0].'":"?"';
}


//$tbl_list_json='{'.implode(",", $tbl_json_res).'}';

//echo "decodes string json -- > ".$tbl_list_json;

$tbl_list_json='{"'.$_POST['tblname'].'":"autoui"}';

$one_col="";

if(isset($_POST['one_col']))
{
  $one_col=$_POST['one_col'];
}

$tbl_list_arr=json_decode($tbl_list_json, true);



//============================== ====================== ============== App exe ==================================================
$js_widget_str="";
foreach($tbl_list_arr as $curr_tbl => $tbl_filename)
{
  
  
      $keyquery = mysqli_query($single_conn, "SHOW COLUMNS FROM `$dbname`.`$curr_tbl`");

  		$tbl_key_arr=array();
  		$magic_where_str=array();
		$upload_function="";
  
      while($key_res = mysqli_fetch_array($keyquery)){
  
      $tbl_key_arr[]=$key_res['Field'];

      $tbl_primkey=$tbl_key_arr[0];
      }
  
  
$pgtitle=ucwords(strtolower(str_replace("_", " ", $tbl_filename)));
$table_rename=ucwords(strtolower(str_replace("_", " ", $curr_tbl)));


 if($file_prefix=="")
 {
   $new_file_prefix='';
 }else{
  $new_file_prefix=$file_prefix."_"; 
 }
  
$page_title=$pgtitle;
$newfile_name="../".$new_file_prefix.$tbl_filename."_list.php";
        
$prof_page_title=$pgtitle." Profile";
$prof_newfile_name="../".$new_file_prefix.$tbl_filename."_profile.php";
  
//============================================================= Rename Table 
$table_icon=$default_icon;
if(isset($rename_tables_array[$curr_tbl]))
{
  $table_ren_attr=explode(":", $rename_tables_array[$curr_tbl]);
  $table_rename=$table_ren_attr[0];
  $table_icon=$table_ren_attr[1];
}
  

//============================================================= Rename Table 
  
  
  
    
if (!file_exists($prof_newfile_name))
{
  $proceed_write=1;
  
}else{
  if($overwrite_existing_file=='yes'){
  	$proceed_write=1;
  }else{
    $proceed_write=0;
  }
}
  

  
if($proceed_write>0)
{
 
if($write_files_only=='yes')
{
  //Recycle($newfile_name, 'skip');
  //Recycle($prof_newfile_name, 'skip');
  //Recycle($user_acc_table, 'skip');

  //create_appframe($page_title, $navbar_file_, $footer_path, $header_css_scripts, $newfile_name, $background_image_path, $template_path, 'skip');
  //create_appframe($prof_page_title, $navbar_file_, $footer_path, $header_css_scripts, $prof_newfile_name, $background_image_path, $template_path, 'skip');
  
}
$head_info="ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');

".PHP_EOL;


foreach ($header_files as $file_includes)
{
  $head_info.='include("'.$file_includes.'");'.PHP_EOL;
}

$profile_head_info=$head_info.'
$default_home_crumb="";
if(isset($home_crumb))
{
$default_home_crumb=$home_crumb;
}
$'.$curr_tbl.'_node=initialize_'.$curr_tbl.'();

$'.$curr_tbl.'_list_query=get_'.$curr_tbl.'("*", "$gft_'.$curr_tbl.' Order by '.$tbl_primkey.' DESC", "l:q'.$curr_tbl.'_token");

';
  

$acc_head_info=$head_info.'
$default_home_crumb="";
if(isset($home_crumb))
{
$default_home_crumb=$home_crumb;
}
$'.$curr_tbl.'_node=initialize_'.$curr_tbl.'();

$'.$curr_tbl.'_list_query=get_'.$curr_tbl.'("*", "$gft_'.$curr_tbl.' Order by '.$tbl_primkey.' DESC", "l:q'.$curr_tbl.'_token");


';
  
$list_head_info=$head_info.'
$default_home_crumb="";
if(isset($home_crumb))
{
$default_home_crumb=$home_crumb;
}
   	
$'.$curr_tbl.'_list_query=get_'.$curr_tbl.'("*", "$gft_'.$curr_tbl.' Order by '.$tbl_primkey.' DESC", "l:q'.$curr_tbl.'_token");
';



//========= replace text in a file_path
$item_to_be_replaced='ob_start();';

if($write_files_only=='yes')
{
bend_replace_file_section($newfile_name, $item_to_be_replaced, $list_head_info);
bend_replace_file_section($prof_newfile_name, $item_to_be_replaced, $profile_head_info);
}
  
  //////== add links to navbar
if(isset($navbar_links_array[$curr_tbl])){
  

$nav_title='<i class="fa fa-'.$navbar_links_array[$curr_tbl].'"></i> '.$table_rename.' ';
$nav_bar_nodes='
			<li class="nav-item ml-lg-4 pt-3">
                <a class="nav-link text-primary" href="'.str_replace('../', "./", $newfile_name).'">'.$nav_title.' </a>
            </li>';
  
$item_to_be_replaced_nav='<!--nav_nodes-->';
$item_to_replace_with_nav=$nav_bar_nodes;

bend_replace_file_section($navlinks_file, $nav_bar_nodes, "");
  
bend_replace_file_section($navlinks_file, $item_to_be_replaced_nav, $item_to_replace_with_nav.PHP_EOL.$item_to_be_replaced_nav);
  
//echo "Created ".$curr_tbl." Navbar link node <hr>";
}
/////// === add link to navbar  
            $new_btn_icon="plus";
            $new_btn_name=" Add new";  
          if(isset($new_label_buttons_arr[$curr_tbl]))
          {
            $new_btn_label_arr=explode(":", $new_label_buttons_arr[$curr_tbl]);
            $new_btn_icon=$new_btn_label_arr[0];
            $new_btn_name=$new_btn_label_arr[1];
            
          }
  
        if(in_array($curr_tbl, $view_tbl_only))
        {
  			$add_new_btn='';
          	$plain_new_btn='';
          
        }else{
          $add_new_btn='  
          <?php if(isset($_GET["'.$curr_tbl.'_uptoken"])){?>
          <a href="'.str_replace('../', "./", $prof_newfile_name).'" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-'.$new_btn_icon.'"></i> '.$new_btn_name.'</a>
            <?php } if(isset($_GET["'.$curr_tbl.'_uptoken"]))
            {?>
      <a href="'.str_replace('../', "./", $prof_newfile_name).'?'.$curr_tbl.'_uptoken=<?php echo $_GET["'.$curr_tbl.'_uptoken"];?>&delete'.$curr_tbl.'&after_delete=<?php echo base64_encode("'.str_replace('../', "./", $newfile_name).'");?>" class="badge badge-danger p-2  ml-3 btn_neoo2">
              <i class="fa fa-trash"></i> Delete
            </a>
            <?php } ?>';

                      
          $plain_new_btn='
          <a href="'.str_replace('../', "./", $prof_newfile_name).'" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-'.$new_btn_icon.'"></i> '.$new_btn_name.'</a>';

        }

      $profile_top_btns='<a href="'.str_replace('../', "./", $newfile_name).'" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-arrow-left"></i> Back to list</a>'.PHP_EOL.$add_new_btn.'';
              
              
     $list_search_str='<input type="text" class="col-md-2 mb-2 ml-2 bg-transparent" placeholder="Search '.$table_rename.'" name="txt_'.$curr_tbl.'" style="color:<?php echo $body_txt ?>; border:none; border-bottom:1px solid <?php echo $btn_bg ?>;"/>
     <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="q'.$curr_tbl.'_btn"><i class="fa fa-search"></i> Go</button>
     <a href="<?php echo magic_basename(magic_current_url()) ?>" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3"><i class="fa fa-refresh"></i> Refresh </a> '.PHP_EOL.$plain_new_btn.'';       
  
            
  
  
$pg_title_str='<h4 class="col-md-12" style="text-align: center;">'.$page_title.'<br><br></h4>';
$pg_title_str_prof='<h4 class="col-md-12" style="text-align: center;">'.$prof_page_title.'<br><br></h4>';
$new_head_str='
      <div class="col-md-12 pb-2 pl-0 text-dark " style="text-align: left;">
      	<span class="btn_neoo2 slanted_tray p-2 font-weight-bold rounded" >
        	<?php echo $default_home_crumb; ?>
        	<span class="text-white">'.$table_rename.' List </span> 
        </span>
          <div class="col-md-12 d-lg-none  mb-2"></div>
          <!--{nbuttongh}-->
          '.$list_search_str.'
      </div>';
  
$prof_new_head_str='
      <div class="col-md-12 pb-2 pl-0 text-dark" style="text-align: left;">
      	<span class="btn_neoo2 slanted_tray p-2 font-weight-bold rounded" >
        	<?php echo $default_home_crumb; ?>
        	<span class="text-white"><?php if(isset($_GET["'.$curr_tbl.'_uptoken"])){?>'.$table_rename.' Profile <?php }else{?> <i class="fa fa-'.$new_btn_icon.'"></i> '.$new_btn_name.' <?php } ?></span> 
        </span>
          <div class="col-md-12 d-lg-none  mb-2"></div>
          '.$profile_top_btns.'
          <!--{nbuttongh}-->
      </div>';
  
  $acc_prof_head='
      <div class="col-md-12 pb-2 pl-0 text-dark" style="text-align: left;">
      	<span class="btn_neoo2 slanted_tray p-2 font-weight-bold rounded" >
        	<?php echo $default_home_crumb; ?>
        	<span class="text-white"><?php if(isset($_GET["'.$curr_tbl.'_uptoken"])){?>'.$table_rename.' Profile <?php }else{?> <i class="fa fa-'.$new_btn_icon.'"></i> '.$new_btn_name.' <?php } ?></span> 
        </span>
          <div class="col-md-12 d-lg-none  mb-2"></div>
          <!--{nbuttongh}-->
      </div>';

if($write_files_only=='yes')
{
bend_replace_file_section($newfile_name, $pg_title_str, $new_head_str);
bend_replace_file_section($prof_newfile_name, $pg_title_str_prof, $prof_new_head_str);
}
	$element_cell="";
    $full_img_str="";
    $template_head_str="";
    $template_cell_str="";
  	$td_img_cell_str="";
  	$th_img_cell_str="      ";
    $template_foot_str="";
    $out_sum_cols="";
    $inner_sum_cols="";
    $template_add_foot_str ="";
    $custom_list_ui_str="";
    $smart_list_links="";
    $custom_ui_search_data_point=array();
	$custom_ui_replace_data_point=array();
    $js_widget_arr_str="";
    $ajax_search_card="";
    $ajax_static_drop_down="";
    $ajax_dynamic_drop_down="";
    $after_return_functions="";
  
    if($one_col!=''){

      $write_tbl_cols_query = mysqli_query($single_conn, "SHOW COLUMNS FROM `$dbname`.`$curr_tbl` where Field='$one_col'") or die (mysqli_error($single_conn));

    }else{
      
    	$write_tbl_cols_query = mysqli_query($single_conn, "SHOW COLUMNS FROM `$dbname`.`$curr_tbl`");
      
    }
  while($write_tbl_cols_res = mysqli_fetch_array($write_tbl_cols_query)){
    


      $label_node=ucwords(str_replace("_", " ", strtolower($write_tbl_cols_res['Field'])));
    
      if(isset($rename_cols_array[$write_tbl_cols_res['Field']]))
      {
        $label_node=$rename_cols_array[$write_tbl_cols_res['Field']];
      }

      $tbl_key_arr[]=$write_tbl_cols_res['Field'];

      $tbl_primkey=$tbl_key_arr[0];
      
      $tbl =$curr_tbl;
      $key=$write_tbl_cols_res['Field'];

      $php_data_node='<?php echo $'.$curr_tbl.'_node["'.$write_tbl_cols_res['Field'].'"];?>';
      $add_tbl_cell='<td><?php echo $'.$curr_tbl.'_node["'.$write_tbl_cols_res['Field'].'"];?></td>';
      $tbl_header_ui_str='<th>'.ucwords(str_replace("_", " ", $write_tbl_cols_res['Field'])).'</th>';


    
        if (in_array($write_tbl_cols_res['Field'], $image_cols_array)) {
                   
          //============ create image cell for profile

          $image_cell_name=$write_tbl_cols_res['Field'];
                      
            if(in_array($curr_tbl, $view_tbl_only))
            {

              $upload_btn="";

              $view_only_data_cell='

              ';

            }else{

            $upload_btn='
              <input type="file" name="txt_'.$curr_tbl.'_'.$image_cell_name.'" class="form-control mt-3">
              <?php if(isset($_GET[\''.$curr_tbl.'_uptoken\'])){?> 
              <input type="submit" name="btn_upload_'.$curr_tbl.'_'.$image_cell_name.'" class="btn btn-primary mt-2" value="Upload">
              <?php }?>
              <input type="hidden" name="txt_'.$image_cell_name.'" value="<?php echo $'.$curr_tbl.'_node["'.$image_cell_name.'"];?>">';

            }
            $full_img_str.='
                <div class="col-md-12 p-0 text-center mb-3">
                <div class="col-md-12 m-2"><b>'.$label_node.'</b></div>
                    <?php 
                          if($'.$curr_tbl.'_node["'.$image_cell_name.'"]!="") 
                            {
                              $file_type_image=magic_if_image($'.$curr_tbl.'_node["'.$image_cell_name.'"]);
                                if($file_type_image==\'Yes\')
                                {?>

                              <img src="<?php if($'.$curr_tbl.'_node["'.$image_cell_name.'"]=="") { echo $mep_app_logo;}else{ echo $'.$curr_tbl.'_node["'.$image_cell_name.'"];}?>" onclick="mosy_img_pop(this.src, \'max-width:100%; max-height:70vh\');glass_modal()" class=" cpointer border border_set" style="'.$profile_pic_style.'"/>

                                <?php }else{
                                $actual_file_name=explode("/", $'.$curr_tbl.'_node["'.$image_cell_name.'"]);
                                echo \'<a href="\'.$'.$curr_tbl.'_node["'.$image_cell_name.'"].\'" target="_blank" class=""><i class="fa fa-paperclip" style="font-size:70px;"></i> 
                                <br>\'.end($actual_file_name).\'<hr> <i class="fa fa-download"></i> Download</a>\';
                                }
                            }else{?>

                             <img src="<?php if($'.$curr_tbl.'_node["'.$image_cell_name.'"]=="") { echo $mep_app_logo;}else{ echo $'.$curr_tbl.'_node["'.$image_cell_name.'"];}?>" onclick="magic_img_pop(this.src, \'max-width:100%; max-height:70vh\');glass_modal()" class=" border border_set" style="'.$profile_pic_style.'"/>

                            <?php } ?>
                   '.$upload_btn.'
                </div> 
    ';
          ///===== image cell for data grid
          
            $td_img_cell_str.='<td><?php
            
            $file_type_image=magic_if_image($list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"]);
            if($file_type_image==\'Yes\' || $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"]==""){ ?>           
            <img src="<?php  $'.$curr_tbl.'_img=$list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"];  if($'.$curr_tbl.'_img!=""){ echo $'.$curr_tbl.'_img;}else{ echo $mep_app_logo; }?>" style="width:50px; height:50px; border-radius:50%;"/>
            <?php }else{?>
                <i class="fa fa-paperclip text-primary" style="font-size:40px;"></i>
            <?php }?>
            </td>';

          
          $th_img_cell_str.="<th>".$label_node."</th>";
          $template_add_foot_str='<th></th>';
          
        }else{
          if($write_tbl_cols_res['Field']!==$tbl_key_arr[0] && $write_tbl_cols_res['Field']!=$tbl_key_arr[1] && (!in_array($write_tbl_cols_res['Field'], $skip_cols_profile))){
            
        if (in_array($write_tbl_cols_res['Field'], $textarea_array)) 
        {

          //============ create textarea
          
          if(in_array($curr_tbl, $view_tbl_only)){
        
            $element_cell.='
            <div class="form-group col-md-12"> 
           	  <label >'.$label_node.'</label> 
              <div class="" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'" style="min-height:200px;">'.$php_data_node.'</div>
           </div>'.PHP_EOL;
            
          }else{
            
            $element_cell.='
            <div class="form-group col-md-12">
              <label >'.$label_node.'</label>
              <'.$textarea_name.' class="form-control" id="txt_'.$write_tbl_cols_res['Field'].'" name="txt_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'" style="min-height:200px;">'.$php_data_node.'</'.$textarea_name.'>
            </div>'.PHP_EOL;
           $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':textarea:col-md-12",';

          }

  
        }elseif(isset($static_drop_down_array[$write_tbl_cols_res['Field']])){

          //============ create static drop down

          $column_name=$write_tbl_cols_res['Field'];
          $column_cell_str='$'.$curr_tbl.'_node["'.$column_name.'"]';
		  $static_drop_down_attr=explode(",", $static_drop_down_array[$write_tbl_cols_res['Field']]);
          $drop_down_options="";
          foreach($static_drop_down_attr as $optionval)
          {
            $drop_down_options.='<option>'.$optionval.'</option>'.PHP_EOL;
          }
          
           
          
         if(in_array($curr_tbl, $view_tbl_only))
         {
        
         $element_cell.='<div class="form-group col-md-4">'.PHP_EOL.
            '  <label >'.$label_node.'</label>'.PHP_EOL.
            '  <div class="form-control" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'">'.$php_data_node.'</div>'.PHP_EOL.
            ' </div>'.PHP_EOL;
           
          }else{
           $element_cell.=' 
               <div class="form-group col-md-4">
                 <label >'.$label_node.'</label>
                  <select name="txt_'.$column_name.'" id="txt_'.$column_name.'" class="form-control">
                      <option  value="<?php echo '.$column_cell_str.';?>">
                       <?php if('.$column_cell_str.'==""){echo "'.$label_node.'";}else{ echo '.$column_cell_str.';}?>
                      </option>
                          '.$drop_down_options.'
                   </select>
               </div>'.PHP_EOL; 

           $ajax_static_drop_down.='
           

                
				if(input_type=="'.$column_name.'_static_drop_down")
                  {
                input_tag=`
                   <select name="txt_'.$column_name.'" id="txt_'.$column_name.'" class="form-control">
                   </select>`;
                   }
           ';
           $after_return_functions .= '
              function load_'.$curr_tbl."_".$column_name.'_items ()
              {
                var default_'.$column_name.'_static_drop_down_val = `                      
                <option >'.$label_node.'</option>`;
                
                var static_'.$column_name.'_drop_down_items=`'.$drop_down_options.'`;
           push_html("txt_'.$column_name.'", default_'.$column_name.'_static_drop_down_val+static_'.$column_name.'_drop_down_items);
           }';
           
           $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':'.$column_name.'_static_drop_down:col-md-4",';

         }
          
        }elseif (in_array($write_tbl_cols_res['Field'], $dynamic_drop_down_array)){

          //============ create static drop down

          $column_name=$write_tbl_cols_res['Field'];
          $column_cell_str='$'.$curr_tbl.'_node["'.$column_name.'"]';


          
        if(in_array($curr_tbl, $view_tbl_only))
        {
        
         $element_cell.='
         	<div class="form-group col-md-4">
              <label >'.$label_node.'</label>
              <div class="form-control" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'"  >'.$php_data_node.'</div>
            </div>'.PHP_EOL;
           
          }else{
                    
       $element_cell.='
       		<div class="form-group col-md-4">
              <label ><span>'.$label_node.'</span> 
              <span  id="_toggle_on_'.$column_name.'"   onclick="document.getElementById(\'txt_'.$column_name.'\').type=\'text\';push_newval(\'txt_'.$column_name.'\', \'\');document.getElementById(\'sel_'.$column_name.'\').style.display=\'none\';this.style.display=\'none\';document.getElementById(\'_toggle_off_'.$column_name.'\').style.display=\'inline-block\';" class="cpointer badge mosy_msdn"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              <span style="display:none" id="_toggle_off_'.$column_name.'"   onclick="document.getElementById(\'txt_'.$column_name.'\').type=\'hidden\';document.getElementById(\'sel_'.$column_name.'\').style.display=\'block\';this.style.display=\'none\';document.getElementById(\'_toggle_on_'.$column_name.'\').style.display=\'inline-block\';if(document.getElementById(\'txt_'.$column_name.'\').value==\'\') document.getElementById(\'txt_'.$column_name.'\').value=document.getElementById(\'sel_'.$column_name.'\').value" class="cpointer badge mosy_msdn"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_'.$column_name.'" id="txt_'.$column_name.'" class="form-control" placeholder="Type new '.$label_node.'"  value="<?php echo '.$column_cell_str.';?>" /> 
              <select name="sel_'.$column_name.'" id="sel_'.$column_name.'" class="form-control" onchange="document.getElementById(\'txt_'.$column_name.'\').value=this.value;">
                  <option  value="<?php echo '.$column_cell_str.';?>">
                   <?php if('.$column_cell_str.'==""){echo "'.$label_node.'";}else{ echo '.$column_cell_str.';}?>
                  </option>
                  <?php
                  $dropdown_list_'.$curr_tbl."_".$column_name.'_q = magic_sql_group("'.$curr_tbl.'", "", 100, "'.$column_name.'", "DESC", "'.$column_name.'");    
              while($dropdown_list_'.$curr_tbl."_".$column_name.'_r=mysqli_fetch_array($dropdown_list_'.$curr_tbl."_".$column_name.'_q[0])){?>
                 <option value="<?php echo $dropdown_list_'.$curr_tbl."_".$column_name.'_r["'.$column_name.'"] ?>" >
                  <?php echo $dropdown_list_'.$curr_tbl."_".$column_name.'_r["'.$column_name.'"] ?>
                 </option>
                 <?php }?>
               </select>
          </div>
         '.PHP_EOL;
          $ajax_dynamic_drop_down.='
          				
                  if(input_type=="'.$column_name.'_dynamic_drop_down")
                  {
                  label_tag ="";
                  input_tag =`
         			 <label ><span>'.$label_node.'</span> 
              			<span  id="_toggle_on_'.$column_name.'"   onclick="document.getElementById(\\\'txt_'.$column_name.'\\\').type=\\\'text\\\';document.getElementById(\\\'txt_'.$column_name.'\\\').value=\\\'\\\';document.getElementById(\\\'sel_'.$column_name.'\\\').style.display=\\\'none\\\';this.style.display=\\\'none\\\';document.getElementById(\\\'_toggle_off_'.$column_name.'\\\').style.display=\\\'inline-block\\\';" class="cpointer badge"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              			<span style="display:none" id="_toggle_off_'.$column_name.'"   onclick="document.getElementById(\\\'txt_'.$column_name.'\\\').type=\\\'hidden\\\';document.getElementById(\\\'sel_'.$column_name.'\\\').style.display=\\\'block\\\';this.style.display=\\\'none\\\';document.getElementById(\\\'_toggle_on_'.$column_name.'\\\').style.display=\\\'inline-block\\\';if(document.getElementById(\\\'txt_'.$column_name.'\\\').value==\\\'\\\') document.getElementById(\\\'txt_'.$column_name.'\\\').value=document.getElementById(\\\'sel_'.$column_name.'\\\').value" class="cpointer badge"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>
              <input type="hidden" name="txt_'.$column_name.'" id="txt_'.$column_name.'" class="form-control" placeholder="Type new '.$label_node.'" /> 
              <select name="sel_'.$column_name.'" id="sel_'.$column_name.'" class="form-control" onchange="document.getElementById(\'txt_'.$column_name.'\').value=this.value;"></select>
              `
              
              };
          ';

          $after_return_functions.='
           function load_'.$curr_tbl."_".$column_name.'_dyn_items(qstr)
           {
           get_'.$curr_tbl.'("*", ""+qstr+" group by '.$column_name.'", \''.$tbl_primkey.','.$column_name.':'.$column_name.'\',\'\', \'push_result:sel_'.$column_name.'\', \'option\');
           }
          
          ';
          $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':'.$column_name.'_dynamic_drop_down:col-md-4",';

        }
          
        }elseif(isset($connection_cols[$write_tbl_cols_res['Field']])){

          //============ create connection text box
          //'team_id'=>'team:staff_id:staff_name'
          $conn_col_keys=explode(":", $connection_cols[$write_tbl_cols_res['Field']]);
          
          $connection_tbl=$conn_col_keys[0];
          $child_tbl_col=$conn_col_keys[2];
          $conn_display_col=$conn_col_keys[2];
          $mother_table_key=$conn_col_keys[1];
          
          $column_name=$write_tbl_cols_res['Field'];
          $column_cell_str='$'.$curr_tbl.'_node["'.$column_name.'"]';

                  $rev_new_btn_icon="plus";
                  $rev_new_btn_name=" Add new";                
                  if(isset($new_label_buttons_arr[$connection_tbl]))
                  {
                    $rev_new_btn_label_arr=explode(":", $new_label_buttons_arr[$connection_tbl]);
                    $rev_new_btn_icon=$rev_new_btn_label_arr[0];
                    $rev_new_btn_name=$rev_new_btn_label_arr[1];

                  }
          //============ create connection drop down
           
               if(in_array($curr_tbl, $view_tbl_only))
                {

              $element_cell.='
                 <div class="form-group col-md-4">
                      <label >'.$label_node.'</label>
                      <div class="form-control" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'"  >'.$php_data_node.'</div>
                  </div>'.PHP_EOL;

                }else{                 
         $element_cell.='                    
           <div class="form-group col-md-4">
              <label >'.$label_node.'</label>
              <?php $_'.$mother_table_key.'=$'.$curr_tbl.'_node["'.$column_name.'"]; if(isset($_GET["'.$mother_table_key.'"])){$_'.$mother_table_key.'=base64_decode($_GET["'.$mother_table_key.'"]);}?>
              <input autocomplete="off" type="text" name="txt_'.$column_name.'_disp" id="txt_'.$column_name.'_disp" class="form-control mosy_tup" data-mosy_tup="load_'.$connection_tbl.'(get_newval(\'txt_'.$column_name.'_disp\'), \'\',\''.$mother_table_key.','.$conn_display_col.','.$conn_display_col.':'.$label_node.'\',\'push_val:txt_'.$column_name.',txt_'.$column_name.'_disp\', \'push_result:'.$curr_tbl."_".$mother_table_key.'_tray\', \'card\')" class="form-control" placeholder="Search '.$label_node.'"  value="<?php echo q'.$connection_tbl.'_ddata("'.$mother_table_key.'", $_'.$mother_table_key.')["'.$conn_display_col.'"];?>" />
              <input type="hidden" name="txt_'.$column_name.'" id="txt_'.$column_name.'" value="<?php echo $_'.$mother_table_key.';?>"/>
              <div class="col-md-12 bg-light pt-2 pb-2 " onclick="this.style.display=\'none\'" id="'.$curr_tbl."_".$mother_table_key.'_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>
           </div>
                    
                    ';
         		$ajax_search_card.='
                  var '.$curr_tbl.'_'.$mother_table_key.'_qstr="";
    
                   if (typeof '.$curr_tbl.'_'.$mother_table_key.'_qstr === "undefined") 
                   {
                    // variable is undefined
                   }
                   
                   var _'.$mother_table_key.'="";//'.$curr_tbl.'_node["'.$column_name.'"]; 
                   
                  if(mosy_get_param("'.$mother_table_key.'")!==undefined){_'.$mother_table_key.'=atob(mosy_get_param("'.$mother_table_key.'"));}

                  if(input_type=="'.$curr_tbl.'_'.$mother_table_key.'_ajax_search")
                  {
                  
                  input_tag=`
    
                              <input autocomplete="off" type="text" name="txt_'.$column_name.'_disp" id="txt_'.$column_name.'_disp" class="form-control mosy_tup" data-mosy_tup="check_elem(\'txt_'.$column_name.'\');load_'.$connection_tbl.'(this.value, \'${'.$curr_tbl.'_'.$mother_table_key.'_qstr}\',\''.$mother_table_key.','.$conn_display_col.','.$conn_display_col.':'.$label_node.'\',\'push_val:txt_'.$column_name.',txt_'.$column_name.'_disp\', \'push_result:'.$curr_tbl."_".$mother_table_key.'_tray\', \'card\')" class="form-control" placeholder="Search '.$label_node.'"  value="" />
              <!--<input type="hidden" name="txt_'.$column_name.'" id="txt_'.$column_name.'"/>-->
              <div class="col-md-12 bg-light pt-2 pb-2" onclick="this.style.display=\'none\';" id="'.$curr_tbl."_".$mother_table_key.'_tray" style="max-height:200px; overflow-y:auto; position:absolute; max-width:100%; display:none; z-index:9999"></div>`;
              }
                ';
                 $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':'.$curr_tbl.'_'.$mother_table_key.'_ajax_search:col-md-4",';
                                         
               }
          //================== create back channel buttons links
          if($write_button_link_only=='yes')
          { 
            
            $conn_table_rename=str_replace("_"," ", ucwords($connection_tbl));
  			$conn_table_icon=$default_icon;
            
            if(isset($rename_tables_array[$connection_tbl]))
            {  
              $conn_table_ren_attr=explode(":", $rename_tables_array[$connection_tbl]);

              $conn_table_rename=$conn_table_ren_attr[0];
              $conn_table_icon=$conn_table_ren_attr[1];
            }
            
            $curr_mosy_ajax_cols="";
            if(isset($ajax_tray_cols[$curr_tbl]))
            {
              $curr_mosy_ajax_cols=$ajax_tray_cols[$curr_tbl];
            }
            
            $curr_mosy_ajax_conn_cols="";
            if(isset($ajax_tray_cols[$connection_tbl]))
            {
              $curr_mosy_ajax_conn_cols=$ajax_tray_cols[$connection_tbl];
            }            
            
            if($use_pop_tray=='yes')
            {
            
             $list_conn_links='<div onclick="pop_filter_tray (\''.$connection_tbl.'\', \'Search '.str_replace("_"," ", ucwords($conn_table_rename)).'\', '.$andquote.'quot;'.$andquote.'quot;,\''.$curr_mosy_ajax_conn_cols.'\',\'tray_uptoken:'.$new_file_prefix.$connection_tbl.'_profile,'.$connection_tbl.'\');push_link(\''.$new_file_prefix.$connection_tbl.'_list\', \'pop_tray_location\');push_link(\''.$new_file_prefix.$connection_tbl.'_profile\', \'new_pop_tray_location\');push_html(\'new_record_label\', \''.$rev_new_btn_name.'\');mosytoggle_class(\'newclass\', \'fa-'.$rev_new_btn_icon.'\')" class="badge cpointer badge-primary p-2  ml-3 btn_neoo2"> <i class="fa fa-'.$conn_table_icon.'"></i>  '.str_replace("_"," ", ucwords($conn_table_rename)).' </div>';

            }else{
            $list_conn_links='<a href="'.$new_file_prefix.$connection_tbl.'_list" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-'.$conn_table_icon.'"></i>   '.str_replace("_"," ", ucwords($conn_table_rename)).'</a>';
            }
            //bend_replace_file_section($newfile_name, $list_conn_links,"");
            bend_replace_file_section($newfile_name, "<!--{nbuttongh}-->", $list_conn_links.PHP_EOL.'<!--{nbuttongh}-->');


           $profile_conn_links='<a href="'.$new_file_prefix.$connection_tbl.'_list?'.$connection_tbl.'_mosyfilter=<?php echo base64_encode("'.$mother_table_key.'=\'".mmres($'.$curr_tbl.'_node["'.$column_name.'"])."\'"); ?>" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-'.$conn_table_icon.'"></i>  '.str_replace("_"," ", ucwords($conn_table_rename)).' Profile</a>';
            
            //bend_replace_file_section($newfile_name, $profile_conn_links,"");
            bend_replace_file_section($prof_newfile_name, "<!--{nbuttongh}-->", $profile_conn_links.PHP_EOL.'<!--{nbuttongh}-->');


            if($use_pop_tray=='yes')
            {
            $reverse_conn_links='<div onclick="pop_filter_tray (\''.$curr_tbl.'\', \'Search  '.$conn_table_rename.' '.str_replace("_"," ", ucwords($table_rename)).'\', '.$andquote.'quot;'.$column_name.'=\'<?php echo mmres($'.$connection_tbl.'_node["'.$mother_table_key.'"])?>\''.$andquote.'quot;,\''.$curr_mosy_ajax_cols.'\',\'tray_uptoken:'.$curr_tbl.'_profile,'.$curr_tbl.'\');push_link(\''.$new_file_prefix.$curr_tbl.'_list?'.$curr_tbl.'_mosyfilter=<?php echo base64_encode("'.$column_name.'=\'".mmres($'.$connection_tbl.'_node["'.$mother_table_key.'"])."\'"); ?>\', \'pop_tray_location\');push_link(\''.$new_file_prefix.$curr_tbl.'_profile?'.$mother_table_key.'=<?php echo base64_encode($'.$connection_tbl.'_node["'.$mother_table_key.'"]);?>\', \'new_pop_tray_location\');push_html(\'new_record_label\', \''.$new_btn_name.'\');mosytoggle_class(\'newclass\', \'fa-'.$new_btn_icon.'\')" class="badge cpointer badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-'.$table_icon.'"></i>  '.$conn_table_rename.' '.str_replace("_"," ", ucwords($table_rename)).' </div>';
            }else{
              $reverse_conn_links='<a href="'.$new_file_prefix.$curr_tbl.'_list?'.$curr_tbl.'_mosyfilter=<?php echo base64_encode("'.$column_name.'=\'".mmres($'.$connection_tbl.'_node["'.$mother_table_key.'"])."\'"); ?>" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-'.$table_icon.'"></i>  '.$conn_table_rename.' '.str_replace("_"," ", ucwords($table_rename)).' </a>';
            
            }
            
            echo " Mother table - ".$connection_tbl." -> Child Table - ".$curr_tbl."<br>";
            
            //bend_replace_file_section($newfile_name, $reverse_conn_links,"");
            bend_replace_file_section('../'.$new_file_prefix.$connection_tbl.'_profile.php', "<!--{nbuttongh}-->", $reverse_conn_links.PHP_EOL.'<!--{nbuttongh}-->');         
            if($use_pop_tray=='yes')
            {

             $reverse_conn_links_list='<div onclick="pop_filter_tray (\''.$curr_tbl.'\', \'Search '.str_replace("_"," ", ucwords($table_rename)).'\', '.$andquote.'quot;'.$andquote.'quot;,\''.$curr_mosy_ajax_cols.'\',\'tray_uptoken:'.$curr_tbl.'_profile,'.$curr_tbl.'\');push_link(\''.$new_file_prefix.$curr_tbl.'_list\', \'pop_tray_location\');push_link(\''.$new_file_prefix.$curr_tbl.'_profile\', \'new_pop_tray_location\');push_html(\'new_record_label\', \''.$new_btn_name.'\');mosytoggle_class(\'newclass\', \'fa-'.$new_btn_icon.'\')" class="badge cpointer badge-primary p-2  ml-3 btn_neoo2"> <i class="fa fa-'.$table_icon.'"></i>    '.str_replace("_"," ", ucwords($table_rename)).'  </div>';
            }else{
            $reverse_conn_links_list='
            <a href="'.$new_file_prefix.$curr_tbl.'_list" class="badge badge-primary p-2  ml-3 btn_neoo2">
              <i class="fa fa-'.$table_icon.'"></i>  '.str_replace("_"," ", ucwords($table_rename)).' 
            </a>';
            }
            bend_replace_file_section($newfile_name, $reverse_conn_links_list,"");
            bend_replace_file_section('../'.$new_file_prefix.$connection_tbl.'_list.php', "<!--{nbuttongh}-->", $reverse_conn_links_list.PHP_EOL.'<!--{nbuttongh}-->');
               
            $drop_down_smart_list_links='$edit_drop_link.=magic_link(\''.$new_file_prefix.$curr_tbl.'_list?'.$curr_tbl.'_mosyfilter=\'.base64_encode("'.$column_name.'=\'".mmres($list'.$curr_tbl.'_result["'.$column_name.'"])."\'").\'\',\'<i class="fa fa-'.$table_icon.'"></i>   '.$conn_table_rename.' '.str_replace("_"," ", ucwords($table_rename)).'\', \'\');';
                        
            
            bend_replace_file_section('../'.$new_file_prefix.$curr_tbl.'_list.php', "//{{edit_drop_link}}", $drop_down_smart_list_links.PHP_EOL.'//{{edit_drop_link}}');                     $rev_profile_link='$edit_drop_link.=magic_link(\''.$new_file_prefix.$connection_tbl.'_list?'.$connection_tbl.'_mosyfilter=\'.base64_encode("'.$mother_table_key.'=\'".mmres($list'.$curr_tbl.'_result["'.$column_name.'"])."\'").\'\',\'<i class="fa fa-'.$conn_table_icon.'"></i> '.str_replace("_"," ", ucwords($conn_table_rename)).' Profile\', \'\');';
            
                        
            bend_replace_file_section('../'.$new_file_prefix.$curr_tbl.'_list.php', "//{{edit_drop_link}}", $rev_profile_link.PHP_EOL.'//{{edit_drop_link}}');

            $reverse_drop_down_smart_list_links='$edit_drop_link.=magic_link(\''.$new_file_prefix.$curr_tbl.'_list?'.$curr_tbl.'_mosyfilter=\'.base64_encode("'.$column_name.'=\'".mmres($list'.$connection_tbl.'_result["'.$mother_table_key.'"])."\'").\'\',\'<i class="fa fa-'.$table_icon.'"></i>   '.str_replace("_"," ", ucwords($conn_table_rename)).' '.$table_rename.'  \', \'\');';
                        
            
            bend_replace_file_section('../'.$new_file_prefix.$connection_tbl.'_list.php', "//{{edit_drop_link}}", $reverse_drop_down_smart_list_links.PHP_EOL.'//{{edit_drop_link}}');

          }
          
          
          
          //================== create back channel buttons links

              
          
        }elseif (in_array($write_tbl_cols_res['Field'], $password_col_array)){
                    
          //============ create text password box     
       
           if(in_array($curr_tbl, $view_tbl_only))
            {

             $element_cell.='
                <div class="form-group col-md-4">
                  <label >'.$label_node.'</label>
                  <div class="form-control" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'"  >'.$php_data_node.'</div>
                </div>'.PHP_EOL;

              }else{

             $element_cell.='
                 <div class="form-group col-md-4">
                   <label >'.$label_node.'</label>
                   <input class="form-control" id="txt_'.$write_tbl_cols_res['Field'].'" name="txt_'.$write_tbl_cols_res['Field'].'" value="'.$php_data_node.'" placeholder="'.$label_node.'" type="password">
                   <input type="checkbox"  onclick="show_password(\'txt_'.$write_tbl_cols_res['Field'].'\')"> <span class=""><em>Show Password</em></span>
                  </div>
              '.PHP_EOL; 
         
             $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':password:col-md-4",';

           	}
          
        }elseif (in_array($write_tbl_cols_res['Field'], $title_columns)){
                    
          //============ create text password box     
        if(in_array($curr_tbl, $view_tbl_only))
        {
        
         $element_cell.='
             <div class="form-group col-md-12">
                <label >'.$label_node.'</label>
                <div class="form-control" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'"  >'.$php_data_node.'</div>
              </div>'.PHP_EOL;
           
          }else{
          
         $element_cell.='
             <div class="form-group col-md-12">
                <label >'.$label_node.'</label>
                <input class="form-control" id="txt_'.$write_tbl_cols_res['Field'].'" name="txt_'.$write_tbl_cols_res['Field'].'" value="'.$php_data_node.'" placeholder="'.$label_node.'" type="text">'.PHP_EOL.'
              </div>
              '.PHP_EOL; 

          $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':text:col-md-12",';

        }
          
        }elseif (in_array($write_tbl_cols_res['Field'], $content_editable)){
                    
          //============ create text content editable   
        if(in_array($curr_tbl, $view_tbl_only))
        {
        
         $element_cell.='
             <div class="form-group col-md-12 skin_plasma">
               <label >'.$label_node.'</label>
               <div class="border-bottom border_set" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'" >'.$php_data_node.'</div>
             </div>'.PHP_EOL;
         $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':text:col-md-4",';

         }else{
       
        $element_cell.='
            <div class="form-group col-md-12">
                <label >'.$label_node.'</label>
                <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById(\'txt_'.$write_tbl_cols_res['Field'].'\').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_'.$write_tbl_cols_res['Field'].'" id="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'" >'.$php_data_node.'</div>
                <'.$textarea_name.' class="form-contrkol"  name="txt_'.$write_tbl_cols_res['Field'].'" id="txt_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'" style="height:0px;width:0px;">'.$php_data_node.'</'.$textarea_name.'>
             </div>'.PHP_EOL;  
                   
          $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':contenteditable:col-md-12",';

        }
          
        }elseif (in_array($write_tbl_cols_res['Field'], $datetime_col_array)){
         
          //============ create text datetime-local box        
          
        if(in_array($curr_tbl, $view_tbl_only))
        {
        
         $element_cell.='
         	<div class="form-group col-md-4">
             <label >'.$label_node.'</label>
             <div class="form-control" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'"  >'.$php_data_node.'</div>
            </div>'.PHP_EOL;
         
            $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':text:col-md-4",';

          }else{
          
         $element_cell.='
         <div class="form-group col-md-4">
           <label >'.$label_node.'</label>
           <input class="form-control" id="txt_'.$write_tbl_cols_res['Field'].'" name="txt_'.$write_tbl_cols_res['Field'].'" value="<?php echo date_time_input($'.$curr_tbl.'_node["'.$write_tbl_cols_res['Field'].'"], "full");?>" placeholder="'.$label_node.'" type="datetime-local">
         </div>'.PHP_EOL;  

          $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':datetime-local:col-md-4",';

          
        }
          
        }elseif (in_array($write_tbl_cols_res['Field'], $date_col_array)){
        
          //============ create text date box       
                  
        if(in_array($curr_tbl, $view_tbl_only))
        {
        
         $element_cell.='
         	<div class="form-group col-md-4">
             <label >'.$label_node.'</label>
             <div class="form-control" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'"  >'.$php_data_node.'</div>
            </div>'.PHP_EOL;
         $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':text:col-md-4",';
          }else{
          
         $element_cell.='
         <div class="form-group col-md-4">
          <label >'.$label_node.'</label>
          <input class="form-control" id="txt_'.$write_tbl_cols_res['Field'].'" name="txt_'.$write_tbl_cols_res['Field'].'" value="<?php echo date_time_input($'.$curr_tbl.'_node["'.$write_tbl_cols_res['Field'].'"], "date");?>" placeholder="'.$label_node.'" type="date">
         </div>'.PHP_EOL; 

          $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':date:col-md-4",';

        }
          
        }else{
          
          //============ create text input box
          
        if(in_array($curr_tbl, $view_tbl_only))
        {
        
         $element_cell.='
         <div class="form-group col-md-4">
            <label >'.$label_node.'</label>
            <div class="form-control" id="div_'.$write_tbl_cols_res['Field'].'" name="div_'.$write_tbl_cols_res['Field'].'" placeholder="'.$label_node.'"  >'.$php_data_node.'</div>
         </div>'.PHP_EOL;
         $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':text:col-md-4",';
          }else{
        $element_cell.='
        <div class="form-group col-md-4">
          <label >'.$label_node.'</label>
          <input class="form-control" id="txt_'.$write_tbl_cols_res['Field'].'" name="txt_'.$write_tbl_cols_res['Field'].'" value="'.$php_data_node.'" placeholder="'.$label_node.'" type="text">
        </div>'.PHP_EOL; 
         $js_widget_arr_str.='"txt_'.$write_tbl_cols_res['Field'].'":"'.$label_node.':text:col-md-4",';
        }
         //============ create text input box
          
        }
            
          }
        }
	
    ///======================= Listing Management
          if($write_tbl_cols_res['Field']!==$tbl_key_arr[0] && $write_tbl_cols_res['Field']!=$tbl_key_arr[1] && (!in_array($write_tbl_cols_res['Field'], $skip_cols_list)) && (!in_array($write_tbl_cols_res['Field'], $image_cols_array) )){

      if(isset($connection_cols[$write_tbl_cols_res['Field']])){

        //============ create connection cell

          $conn_col_keys=explode(":", $connection_cols[$write_tbl_cols_res['Field']]);

          $connection_tbl=$conn_col_keys[0];
          $child_tbl_col=$conn_col_keys[2];
          $conn_display_col=$conn_col_keys[2];
          $mother_table_key=$conn_col_keys[1];
        
          $conn_table_rename=str_replace("_"," ", ucwords($connection_tbl));
  		  $conn_table_icon=$default_icon;
            
          if(isset($rename_tables_array[$connection_tbl]))
          {  
            $conn_table_ren_attr=explode(":", $rename_tables_array[$connection_tbl]);

            $conn_table_rename=$conn_table_ren_attr[0];
            $conn_table_icon=$conn_table_ren_attr[1];
          }   
        
        $td_cell_str='<span title="<?php echo $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"] ?>"><?php echo magic_strip_if(q'.$connection_tbl.'_ddata("'.$mother_table_key.'", $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"])["'.$conn_display_col.'"], '.$trim_text_size.', '.$trim_text_size.');?></span>';
        
		$custom_data_node='<?php echo q'.$connection_tbl.'_ddata("'.$mother_table_key.'",  $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"])["'.$conn_display_col.'"];?>';
        $smart_list_links.='$edit_drop_link.=magic_link(\''.$new_file_prefix.$connection_tbl.'_list?'.$connection_tbl.'_mosyfilter=\'.base64_encode("'.$column_name.'=\'".mmres($list'.$curr_tbl.'_result["'.$mother_table_key.'"])."\'").\'\',\'<i class="fa fa-'.$conn_table_icon.'"></i> '.str_replace("_"," ", ucwords($conn_table_rename)).' Profile\', \'\');';

      }else{


      $td_cell_str='<span title="<?php echo $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"] ?>"><?php echo magic_strip_if($list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"], '.$trim_text_size.', '.$trim_text_size.');?></span>';
       if (in_array($write_tbl_cols_res['Field'], $textarea_array)) 
       {
       
      	$td_cell_str='<span title="<?php echo $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"] ?>"><?php echo magic_strip_if($list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"],'.$trim_text_size.', '.$trim_text_size.');?></span>';
         
       }
        
       if (in_array($write_tbl_cols_res['Field'], $content_editable)) 
       {
       
      	$td_cell_str='<span title="<?php echo $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"] ?>"><?php echo magic_strip_if($list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"],'.$trim_text_size.', '.$trim_text_size.');?></span>';
         
       }
        
      $custom_data_node='<?php echo $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"];?>';
      $smart_list_links.="";
      }
        $footer_sum="";

      //============ sum requested columns 
     
         if(in_array($write_tbl_cols_res['Field'], $sum_cols_list))
        {
          $out_sum_cols.='$sum_cols_'.$write_tbl_cols_res['Field'].'=0;';         	 $inner_sum_cols.='$sum_cols_'.$write_tbl_cols_res['Field'].'=$sum_cols_'.$write_tbl_cols_res['Field'].'+$list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"];';
          $footer_sum='<?php echo tonum($sum_cols_'.$write_tbl_cols_res['Field'].');?>';
        }            

        //============ sum requested columns 

            
   //============ combine tr columns 

    $template_head_str.=
			'             <th scope="col">'.$label_node.'</th>'.PHP_EOL;
    $template_foot_str.=
			'             <th scope="col">'.$footer_sum.'</th>'.PHP_EOL;          
	
    $template_cell_str.=
			'             <td scope="col">'.$td_cell_str.'</td>'.PHP_EOL;
            

          }
      //============ create custom listing ui 

      if(isset($connection_cols[$write_tbl_cols_res['Field']])){
                        
          $conn_col_keys=explode(":", $connection_cols[$write_tbl_cols_res['Field']]);

          $connection_tbl=$conn_col_keys[0];
          $child_tbl_col=$conn_col_keys[2];
          $conn_display_col=$conn_col_keys[2];
          $mother_table_key=$conn_col_keys[1];
        
        
		$custom_data_node='<?php echo q'.$connection_tbl.'_ddata("'.$mother_table_key.'", $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"])["'.$conn_display_col.'"];?>';

      }else{
      $custom_data_node='<?php echo $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"];?>';
      }
    
         if(in_array($write_tbl_cols_res['Field'], $image_cols_array))
         {            
            $custom_data_node='<?php
            
            $file_type_image=magic_if_image($list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"]);
            if($file_type_image==\'Yes\' || $list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"]==""){  
            $filter_shadow="";
              $'.$curr_tbl.'_img=$list'.$curr_tbl.'_result["'.$write_tbl_cols_res['Field'].'"];  if($'.$curr_tbl.'_img!=""){ echo $'.$curr_tbl.'_img;}else{ echo $mep_app_logo;}
            }else{
            $filter_shadow="filter:drop-shadow(5px 0 0px ".$btn_bg.")";
                echo "./img/paperclip.png";
            }?>';
         }
            
			$custom_ui_search_data_point[]="{{".$write_tbl_cols_res['Field']."}}";
          	$custom_ui_replace_data_point[]=$custom_data_node;     
    
      //============ create custom listing ui 


  }
  
  ////////////////////////// =================== write js widget =========================
  
  $js_widget_str.='
  
  
////========================= start '.$curr_tbl.' inputs widget 

function '.$curr_tbl.'_input_wgt(input_array, button, title)
{
 var input_policy={'.$js_widget_arr_str.'};
 if(title=="")
 {
 title ="'.$table_rename.'";
 }
 var input_cell=`<div class="row justify-content-left m-0 p-0 col-md-12">
                     <!-- Start  Title ribbon-->
                  <div class="col-md-12 row p-2 justify-content-center p-0 m-0 mb-3">
                    <h5 class="col-md-12 text-left"> ${title}</h5>
                    <div class="col-md-12 bg-light" style="height: 1px"></div>
                  </div>
                  <!-- End Title ribbon-->
   `;
  
  
  for(text_node of input_array)
  {
    
    var input_arr = text_node.split(":");
    var input_label=input_arr[1];
    var input_id = input_arr[0];
    var input_type = input_arr[2];
    var cell_width = input_arr[3];
    var additional_attr =input_arr[4];
    
    var custom_input_label=input_arr[1];
    var custom_input_id = input_arr[0];
    var custom_input_type = input_arr[2];
    var custom_cell_width = input_arr[3];
    
    if((input_id in input_policy)==true)
    {
     input_policy_arr = input_policy[input_id].split(":");
     input_label=input_policy_arr[0];
     input_type=input_policy_arr[1];
     cell_width = input_policy_arr[2];

    }
    
    if(custom_cell_width!==undefined)
    {
    cell_width = custom_cell_width;
    }
    
    if(custom_input_type!==undefined)
    {
    input_type=custom_input_type;
    }
    
    if(custom_input_label!==undefined)
    {
    input_label=custom_input_label;
    }
    
    var label_tag = `<label >${input_label}</label>`;
    input_tag =`                    
            <input class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}" type="${input_type}" ${additional_attr}>`;
    if(input_type=="textarea")
    {
    
    input_tag =`                    
            <'.$textarea_name.' class="form-control" id="${input_id}" name="${input_id}"  placeholder="${input_label}"></'.$textarea_name.'>`;    
    }
    
    if(input_type=="contenteditable")
    {
    input_tag=`
    <div class="summernote col-md-12 border-bottom border_set" onkeyup="document.getElementById(\'${input_id}\').value=this.innerHTML" style="min-height:100px;max-height:450px; overflow-y:auto;" contenteditable="true" name="div_${input_id}" id="div_${input_id}" placeholder="${input_label}" ></div>
                
  <'.$textarea_name.' class="form-contrkol"  name="${input_id}" id="${input_id}" placeholder="${input_label}" style="height:0px;width:0px;"></'.$textarea_name.'>
    `;
    }
    if(text_node.indexOf("|")>0)
    {
        var va_input_arr = text_node.split("|");
        
        input_tag=va_input_arr[1];
        label_tag="";
        cell_width=va_input_arr[0];
        
        //alert(input_tag);

    }    
	'.$ajax_search_card.'
    '.$ajax_static_drop_down.'
    '.$ajax_dynamic_drop_down.'
    
      input_cell +=`
                  <div class="form-group ${cell_width} text-left">
                   ${label_tag}
                   ${input_tag}
                  </div>
    
    `;
  }

  var btn_arr = button.split(":");
  var button_id =btn_arr[0];
  var button_label = btn_arr[1];
  var button_icon = btn_arr[2];
  
  input_cell+=`
    <div class="col-md-12 text-center">
    <button id="${button_id}" name="${button_id}" class="btn btn-primary" > <i class="fa fa-${button_icon}"></i> ${button_label} </button>
    </div>
    
    </div>`;
  
  return input_cell;
}
  '.$after_return_functions.'

  ';
  
  ////////////////////////// =================== write js widget =========================
 
        //============ table head and footer

    $tbl_str='
  <style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="table-responsive data-tables skin_plasma" style="margin-top: 20px; padding-bottom: 150px;">
<table class="table text-left" id="'.$curr_tbl.'_data_table">
	    <thead class="text-uppercase">
		   <tr>
		      <th scope="col">#</th>              
            	'.$th_img_cell_str.'
				'.$template_head_str.'
		   </tr>
	    </thead>
	    <tbody>';
    
  $tbl_bottom='
  <!--add_new_row_here-->
	    </tbody>
	    </table>
             <?php if($i==0){?>
            <h4 class="col-md-12 text-center p-3"><i class="fa fa-search"></i> Sorry, no '.strtolower($table_rename).' records found</h4>
            <div class="col-md-12 text-center">
            	<?php $search_'.$curr_tbl.'_class="ml-0"; if($default_'.$curr_tbl.'_show_edit_btn=="yes"){
                $search_'.$curr_tbl.'_class="ml-4";
                ?>
            	<a href="<?php echo $default_'.$curr_tbl.'_profile ?>" class="badge badge-primary mb-3 btn_neo p-2"><i class="fa fa-'.$new_btn_icon.'"></i> '.$new_btn_name.' </a>
                <?php }?>
            	<a href="<?php echo  $default_'.$curr_tbl.'_listing?>" class="badge badge-primary mb-3 <?php echo $search_'.$curr_tbl.'_class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
            </div>
          <?php }?>
         <?php echo mosy_paginate_ui($'.$curr_tbl.'_list_query[1], $datalimit, "q'.$curr_tbl.'_token")?>
        </div>
       ';
  
	$editdatalink=str_replace('../', "./", $prof_newfile_name);  
  

       //============ push ui to page 
 
  		if(isset($custom_list_ui[$curr_tbl])){
          
          /// for custom ui
          
          	  $ui_template=$custom_list_ui[$curr_tbl];
              $search_data_points_str =$custom_ui_search_data_point;            
         	  $replace_data_points_str =$custom_ui_replace_data_point;
            
              //$search_label_points_str =$custom_ui_search_label_point;            
         	  //$replace_label_points_str =$custom_ui_replace_label_point;
          	  $custom_edit_link='<?php echo $default_'.$curr_tbl.'_profile?>?'.$tbl.'_uptoken=<?php echo base64_encode($list'.$curr_tbl.'_result["'.$tbl_primkey.'"]);?>';
          	  $custom_del_link='<?php echo $default_'.$curr_tbl.'_profile?>?after_delete=<?php echo base64_encode(magic_current_url());?>&'.$tbl.'_uptoken=<?php echo base64_encode($list'.$curr_tbl.'_result["'.$tbl_primkey.'"]);?>&delete'.$curr_tbl.'';
          
            
              $custom_list_ui_str1= str_replace($search_data_points_str, $replace_data_points_str, $ui_template);
              $custom_list_ui_str2= str_replace('{{editlink}}' , $custom_edit_link, $custom_list_ui_str1);
              $custom_list_ui_str= str_replace('{{deletelink}}', $custom_del_link, $custom_list_ui_str2);
          
          
        $loop_str='
        <?php 
          $i=0;
          $default_'.$curr_tbl.'_profile="'.$editdatalink.'";
          if(isset($'.$curr_tbl.'_profile))
          {
          $default_'.$curr_tbl.'_profile=$'.$curr_tbl.'_profile;
          }     
          $default_'.$curr_tbl.'_listing="'.str_replace('../', "./", $newfile_name).'";
          if(isset($'.$curr_tbl.'_listing))
          {
          $default_'.$curr_tbl.'_listing=$'.$curr_tbl.'_listing;
          } 
          
          $default_'.$curr_tbl.'_show_edit_btn="yes";
          if(isset($'.$curr_tbl.'_show_edit_btn))
          {
          $default_'.$curr_tbl.'_show_edit_btn=$'.$curr_tbl.'_show_edit_btn;
          } 
          
          
        //<--outloop-dope-->
 
 	while($list'.$curr_tbl.'_result=mysqli_fetch_array($'.$curr_tbl.'_list_query[0])){
        $i++;

        //<--inloop-dope-->

        ?>
            <!--add your ui here;-->
           '.$custom_list_ui_str.'

       <?php }?>
 		 <?php if($i==0){?>
            <h4 class="col-md-12 text-center p-3"><i class="fa fa-search"></i> Sorry no '.$table_rename.' results found</h4>
            <div class="col-md-12 text-center">
            	<?php $search_'.$curr_tbl.'_class="ml-0"; if($default_'.$curr_tbl.'_show_edit_btn=="yes"){
                $search_'.$curr_tbl.'_class="ml-4";
                ?>
            	<a href="<?php echo $default_'.$curr_tbl.'_profile ?>" class="badge badge-primary mb-3 btn_neo p-2"><i class="fa fa-'.$new_btn_icon.'"></i> '.$new_btn_name.' </a>
                <?php }?>
            	<a href="<?php echo  $default_'.$curr_tbl.'_listing?>" class="badge badge-primary mb-3 <?php echo $search_'.$curr_tbl.'_class; ?> btn_neo p-2"><i class="fa fa-search"></i> Try a new Search</a>
            </div>
          <?php }?>
          <?php echo mosy_paginate_ui($'.$curr_tbl.'_list_query[1], $datalimit, "q'.$curr_tbl.'_token")?>
          ';
        }else{
          
          /// for data grid
        if(in_array($curr_tbl, $view_tbl_only))
        {
        
         $deledit_link="'';";   
          
        }else{
          $deledit_link='magic_link($default_'.$curr_tbl.'_profile.\'?after_delete=\'.base64_encode(magic_current_url()).\'&'.$curr_tbl.'_uptoken=\'.base64_encode($list'.$curr_tbl.'_result["'.$tbl_primkey.'"]).\'&delete'.$curr_tbl.'\',\'<i class="fa fa-trash"></i> Delete\', \'\');';
        }
          
          
     $loop_str=$tbl_str.'
      <?php 
          $default_'.$curr_tbl.'_profile="'.$editdatalink.'";
          if(isset($'.$curr_tbl.'_profile))
          {
          $default_'.$curr_tbl.'_profile=$'.$curr_tbl.'_profile;
          } 
          
          $default_'.$curr_tbl.'_listing="'.str_replace('../', "./", $newfile_name).'";
          if(isset($'.$curr_tbl.'_listing))
          {
          $default_'.$curr_tbl.'_listing=$'.$curr_tbl.'_listing;
          } 
          
          $default_'.$curr_tbl.'_show_edit_btn="yes";
          if(isset($'.$curr_tbl.'_show_edit_btn))
          {
          $default_'.$curr_tbl.'_show_edit_btn=$'.$curr_tbl.'_show_edit_btn;
          } 
      	
          echo drop_css();
        
          $i=0;

		  '.$out_sum_cols.'
          
        //<--outloop-dope-->
 
 	   while($list'.$curr_tbl.'_result=mysqli_fetch_array($'.$curr_tbl.'_list_query[0]))
    	{
        
        $i++;
		'.$inner_sum_cols.'
        //<--inloop-dope-->
          $edit_drop_link="";
          $delete_drop_link="";
          if($default_'.$curr_tbl.'_show_edit_btn=="yes"){
          $edit_drop_link=magic_link($default_'.$curr_tbl.'_profile.\'?'.$tbl.'_uptoken=\'.base64_encode($list'.$curr_tbl.'_result["'.$tbl_primkey.'"]).\'\', \'<i class="fa fa-edit"></i> View More\', \'\');
          }
          
           //{{edit_drop_link}}
           if($default_'.$curr_tbl.'_show_edit_btn=="yes")
           {
            $delete_drop_link='.$deledit_link.'
		   }
	        $dropdown_items =$edit_drop_link.$delete_drop_link;
        ?>
            <!--add your ui here;-->
            <tr>
              <td scope="col"><?php echo magic_dropdown($i, $dropdown_items, \'no\')?></td>
            '.$td_img_cell_str.'
            '.$template_cell_str.'
			</tr>
       <?php }?>

          <tr>
          <th></th>
          '.$template_add_foot_str.'
          '.$template_foot_str.'
          </tr>'.$tbl_bottom.'';
        }
  
///====================== Create Profile ui ===========================//

  if(in_array($curr_tbl, $view_tbl_only))
  {
  $insert_updt_ui_str="";
  }else{
  // edit update buttons
    $insert_updt_ui_str='
      <div class="col-md-12 text-center">
      <?php if(!isset($_GET[\''.$curr_tbl.'_uptoken\'])){?> 
            <button type="submit" id="'.$curr_tbl.'_insert_btn" name="'.$curr_tbl.'_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-check"></i> Proceed 
            </button>
            <?php } ?>
      <?php if(isset($_GET[\''.$curr_tbl.'_uptoken\'])) {?>
            <button type="submit" id="'.$curr_tbl.'_update_btn" name="'.$curr_tbl.'_update_btn" class="btn btn-primary" > 
              <i class="fa fa-save"></i> Save Changes 
            </button>
            <button type="submit" id="'.$curr_tbl.'_insert_btn" name="'.$curr_tbl.'_insert_btn" class="btn btn-primary" > 
              <i class="fa fa-copy"></i> Clone Record 
            </button>          
            <?php } ?>
    </div>
  ';
  }
  
  /// image cell handler 
  $img_tray="";
  $col_size_def='col-md-12';
  if($full_img_str!='')
  {
    $img_tray='            <div class="col-md-3 mr-lg-2 border-left border_set">
            '.$full_img_str.'
            </div>';
    $col_size_def='col-md-8';
  }
  
  $prof_card='
     <div class="m-0 pt-3 col-md-12 skin_plasma p-0" style="min-height:100vh;">
       <div class="row justify-content-center m-0 pt-3 col-md-12 ">
				'.$img_tray.'
            <div class="'.$col_size_def.' row justify-content-left m-0  p-0">
               '.$element_cell.'
               '.$insert_updt_ui_str.'
            </div>
          </div>
      </div>';
///====================== Create Profile ===========================//
if(isset($user_acc_table[$curr_tbl]))
{
  $acc_tbl_attr=explode(":", $user_acc_table[$curr_tbl]);
  $acc_file_name="../".$acc_tbl_attr[0].".php";
  $abs_acc_path="./".$acc_tbl_attr[0].".php";
  $acc_file_title=$acc_tbl_attr[1];
  $acc_file_user_id=$acc_tbl_attr[2];
  $acc_file_session_name=$acc_tbl_attr[3];

  $acc_red_fun=$acc_head_info.'
  if(!isset($_GET["'.$curr_tbl.'_uptoken"]))
  {
    $'.$curr_tbl.'_acc_red_key=q'.$curr_tbl.'_ddata("'.$acc_file_user_id.'", $'.$acc_file_session_name.'_'.$acc_file_user_id.')["'.$tbl_primkey.'"];
  	header("location:'.$abs_acc_path.'?'.$curr_tbl.'_uptoken=".base64_encode($'.$curr_tbl.'_acc_red_key)."");
  }';


  Recycle($acc_file_name);

  create_appframe($acc_file_title, $navbar_file_, $footer_path, $header_css_scripts, $acc_file_name, $background_image_path, $template_path);
  bend_replace_file_section($acc_file_name, '<h4 class="col-md-12" style="text-align: center;">'.$acc_file_title.'<br><br></h4>', $acc_prof_head);
  bend_replace_file_section($acc_file_name, 'ob_start();', $acc_red_fun);
  bend_replace_file_section($acc_file_name, '<!--<{ncgh}/>-->', $prof_card);

}


if($write_files_only=='yes')
{
bend_replace_file_section($newfile_name, '<!--<{ncgh}/>-->', $loop_str);
bend_replace_file_section($prof_newfile_name, '<!--<{ncgh}/>-->', $prof_card);
}
  
$table_ui='
<div class="p-0 col-md-12">

'.$list_search_str.'
</div>
'.$loop_str.'
';
 
$profile_ui='
<div class="p-0 col-md-12">

'.$profile_top_btns.'
</div>
'.$prof_card.'
';
 
  

  if($_POST['ui_type']=='table')
  {
 	echo $table_ui;
  }
  
  if($_POST['ui_type']=='profile')
  {
 	echo $profile_ui;
  }
  
  if($_POST['ui_type']=='column')
  {
 	echo $element_cell;
  }
  
}
 
}
?>