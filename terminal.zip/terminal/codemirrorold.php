<!Doctype html>

<title>Terminal X</title>
<meta charset="utf-8"/>
<link rel="stylesheet" href="./cm/lib/codemirror.css">
<link rel="stylesheet" href="./cm_terminal.css">

<link rel="stylesheet" href="./cm/theme/erlang-dark.css">

<script src="./cm/lib/codemirror.js"></script>
<script src="./cm/addon/fold/xml-fold.js"></script>
<script src="./cm/addon/edit/matchtags.js"></script>
<script src="./cm/mode/xml/xml.js"></script>
<script src="./cm/addon/mode/loadmode.js"></script>
<script src="./cm/mode/meta.js"></script>
<style type="text/css">
  .CodeMirror {
    position: fixed;
    overflow: hidden;
    z-index: 999;
    top: 35px;
    width: 100%;
    min-height: 100vh;
    background-color: rgba(0,0,0,0.9)!important;
}
}
</style>
<div class="top_nav">
  <div class="div_text">File -   
    <input type="text" value="./txt_writeto.php" onchange="change(this.value)" id="txt_writeto" name="txt_writeto" class="reg_input" placeholder="File Path">
</div>
  <div class="exe_btn" onclick="load_file()">Load File</div>

  <div class="div_text"><span id="modeinfo">text/plain</span></div>

  <input type="text" name="" id="mainsearch" class="reg_input" value="Search"  onkeyup="loop_folder(this.value); trigger_log_search(this.value);flag_search(this.value)">
  <div style="display: inline-block; width: 35%; text-align: right;">
  <div class="exe_btn" onclick="execute_terminal()" >Run</div>
  <div class="exe_btn" onclick="max_preview()">Preview</div>
  <div class="exe_btn" id="showeditor" style="display: none;" onclick="this.style.display='none';showeditor()">Code</div>
  <div class="exe_btn" id="hideeditor"  onclick="this.style.display='none';hideeditor();">Live</div>  
  <div class="exe_btn" onclick="save_file()">Save File</div>

</div>
</div>
<div style="text-align: center;">

<img src="./deskfull.png" class="screen_frame">
  <iframe src="./index" class="desk_iframe"  id="load_desk_iframe" onLoad="change_scroll_bar();"></iframe>
  <img src="./mobiview2.png" class="mobi_screen_frame" id="mobile_screen">
  <div class="close_mobile_view" onclick="close_mobile_view();this.style.display='none'" id="close_mobile_view_btn" title="Close Mobile View">X</div>
  <iframe src="./index" class="mobi_iframe"  id="load_mobi_iFrame" onLoad="change_scroll_bar();"></iframe>
  <div class="minimized_mobi" id="minimized_mobi_div" title="Show Mobile View" onclick="show_mobi(); this.style.display='none'" >
    [Show Mobile View]
  </div>
</div>
<textarea id="txt_new_code" name="txt_new_code" placeholder="Start Typing">
</textarea>
<p>Filename, mime, or mode name: <input type=text value="php" id=mode> <button type=button onclick="change(this.value)">change mode</button></p>
<div class="preview_desk_iframe" id="preview_desk_iframe" style="display: none;">
  <div class="min_cast" id="load_preview_iframe_btn">
    <div class="exe_btn"><span onclick="min_preview()"><b>Min </b></span>|<span onclick="loadwebpage()"><b> Cast </b></span> | <span id="preview_desk_iframeheader" style="cursor: pointer;"><b> Drag </b></span></div>
  </div>
  <iframe src="./prevdiv.php" style="width: 100%; height: 100%;visibility:hidden;" id="load_preview_iframe" onLoad="change_scroll_bar();this.style.visibility='visible';"></iframe>
</div>
  <div class="bottom_tray">
    <input type="text" id="iframeurl" placeholder="Url to show" class="reg_input">
    <div class="reg_input" style="    margin-left: 0px;" onclick="loadwebpage()">Go</div>
  </div>
  <div class="log_window" id="parent_log_window" style="display: block;" >
<div id="parent_log_windowheader" style="border:1px solid #FFF; cursor: move;">
< Drag >
</div>
<div style="padding:10px; font-size: 28px; display: none;" onclick="this.style.display='none'" id="notification_card">Notifications</div>

<input type="text" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="search_log()" required="" id="function_card" placeholder=" Search Window"  autocomplete="off">

<input type="text" id="folderpath" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="loop_folder(this.value)" required="" placeholder="Search Folders"  autocomplete="off">


<textarea id="append_text" style="background-color: #000; width: 100%; color: #FFF; height: 20px; margin-top: 10px;" placeholder="Append Text here"></textarea>

<div id="log_window" style="max-height: 300px; overflow-y: auto; margin-top: 12px;"></div>

</div>

    <input type="hidden" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="./terminal_exe.php" name="txt_directory" id="txt_directory" required="" placeholder=" Enter exe file path">
<input type="hidden" style="position: fixed; bottom: 72px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 99999999; color: #FFF;" id="flag_search" name="">
<input type="hidden" style="position: fixed; bottom: 72px; right: 20px; width: 40%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="trigger_arrow_keys" name="">
<div onclick="this.style.display='none'" id="flag_search_div" style="position: fixed;
    bottom: 20px;
    left: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 200px; overflow-y: auto; text-align: left; z-index: 999999">
</div>
<div id="alert_box"></div>

<script>

CodeMirror.modeURL = "./cm/mode/%N/%N.js";
var editor = CodeMirror.fromTextArea(document.getElementById("txt_new_code"), {
  lineNumbers: true,
  lineWrapping: true,
    value: "<html>\n  " + document.documentElement.innerHTML + "\n</html>",
    matchTags: {bothTags: true},
    extraKeys: {"Ctrl-J": "toMatchingTag"}

});



function change(curr_mode) {
  var val = curr_mode, m, mode, spec;
  if (m = /.+\.([^.]+)$/.exec(val)) {
    var info = CodeMirror.findModeByExtension(m[1]);
    if (info) {
      mode = info.mode;
      spec = info.mime;
    }
  } else if (/\//.test(val)) {
    var info = CodeMirror.findModeByMIME(val);
    if (info) {
      mode = info.mode;
      spec = val;
    }
  } else {
    mode = spec = val;
  }
  if (mode) {
    editor.setOption("mode", spec);
    CodeMirror.autoLoadMode(editor, mode);
    document.getElementById("modeinfo").textContent = spec;
  } else {
    alert("Could not find a mode corresponding to " + val);
  }
}
  window.onload=change('txt.php'); selectTheme('erlang-dark');

  function selectTheme(theme_name) {
    var theme = theme_name;
    editor.setOption("theme", theme);
    location.hash = "#" + theme;
  }
  var choice = (location.hash && location.hash.slice(1)) ||
               (document.location.search &&
                decodeURIComponent(document.location.search.slice(1)));
  if (choice) {
    editor.setOption("theme", choice);
  }
  CodeMirror.on(window, "hashchange", function() {
    var theme = location.hash.slice(1);
    if (theme) { selectTheme(); }
  });

</script>
<script type="text/javascript" src="./jquery.js"></script>
<script type="text/javascript" src="./cm_terminal.js"></script>
<script type="text/javascript" src="./jsfunctions.js"></script>
