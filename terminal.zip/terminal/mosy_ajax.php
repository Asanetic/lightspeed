<?php 
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php'); 

if(isset($_POST["mosyajax_loop_client_table"]))
{
    $where_str=mysqli_real_escape_string($mysqliconn, ($_POST["where_str"]));
    $cols=mysqli_real_escape_string($mysqliconn, ($_POST["cols"]));
    $function_name=mysqli_real_escape_string($mysqliconn, ($_POST["function_name"]));

    //=== start packages select  Like Query String packages list  
	$ajax_loop_clients_table_q=mosyloop_clients_table($where_str, $datalimit);
  
  	$exploded_cols=explode(",", $cols);
  	$js_columns=array();
  
    $card_str="";

    while($ajax_loop_clients_table_r=mysqli_fetch_array($ajax_loop_clients_table_q[0])){
	
      foreach($exploded_cols as $colname)
        {
  
          $js_columns[]=$ajax_loop_clients_table_r[$colname];
           
        }
          $card_str.='
              <div class="row col-md-12 p-3 text-left" onclick="'.$function_name.'('.$js_columns.')">  
              	'.$dres[$cols[$colname]].'
              </div>';
        }	

    echo $card_str;
  
}

?>