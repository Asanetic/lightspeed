<?php  $dashpath='../oakhutshop.php';
$card_title='Brands';
$card_title_ids=str_replace(" ", "_", $card_title);

	$accordion_card ='
         <!--Start  Section_Title accordion_item node-->
        <div class="card skin_plasma">
             <!--Start accordion_item Head -->
          <div class="card-header bg-success  p-0" id="head_Section_Title">
            <h2 class="mb-0">
              <button class="btn btn-link text-white btn-block text-left" type="button" data-toggle="collapse" data-target="#body_Section_Title" aria-expanded="true" aria-controls="body_Section_Title">
              <h4 class="col-md-12  pb-2 pl-0" style="text-align: left;">
                  <span class="text-white p-2 ">Main_Section_Title</span>
              </h4>
              </button>
            </h2>
          </div>
         <!--End Section_Title accordion_item Head -->
         <!--Start Section_Title accordion_item Body -->
          <div id="body_Section_Title" class="collapse" aria-labelledby="head_Section_Title" data-parent="#dashboard_accordion">
            <div class="card-body skin_plasma">
              <!--Start Section_Title Dash Cards Section-->
              <div class="row justify-content-center" style="text-align: center;">
                  <!--Start Dash icon card-->
					<!--<{next_'.$card_title_ids.'_dash__icon}/>-->
                  <!--End Section_Title Dash icon card-->
              </div>
             <!--End Section_Title Dash Cards Section-->
            </div>
          </div>
             <!--End Section_Title accordion_item Body -->
         </div>
            <!--End Section_Title accordion_item node-->

		<!--<{next_accordion_node}/>-->
    ';
$main_title=str_replace('Main_Section_Title', $card_title, $accordion_card);
$final_str=str_replace('Section_Title', $card_title_ids, $main_title);

$item_to_be_replaced='<!--<{next_accordion_node}/>-->';
$item_to_replace_with=$final_str;

bend_replace_file_section($dashpath, $item_to_be_replaced, $item_to_replace_with);?>