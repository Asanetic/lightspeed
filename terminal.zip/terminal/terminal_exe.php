<?php //dna options==
$dna_file_name="cf__Quick_table_Record_preview"; 
$create_dna="yes"; //yes | no 
$overwrite_dna_file="yes"; //yes | no 
//dna options==


$tbl="blog_posts";
$show_cell="post_img";
$primkey="primkey";

$quick_select_q=magic_sql_select($tbl,  "", "10", $primkey, "desc");

$i=0;
$records ='<div style="text-align:left; color:#FFF;"><h4> Quick Preview '.$tbl.' Data </h4>';			

while($quick_select_r=mysqli_fetch_array($quick_select_q[0])){

  $i  ;

  $records .='<div style="">'.$i." - ".$quick_select_r[$show_cell]."</div>";

}

$records.="</div>";

echo ("Showing ".$i." rows ".$records);?>