<?php //dna options==
$dna_file_name="notes_prof_mosy_javascript_mini_list_js_l___"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==

//===create app frame
$tbl='notes';
$page_title='Similar Notes';
$newfile_name='../editnote.php';
$loop_name="simnotes";

//function to go with data if they dont exist

$additional_functions='


//======================== Start '.$tbl.' Functions =============


//======================== End '.$tbl.' Functions =============
';

$add_functions_string="no";

//************grid Values  "column_name":"Label / header title : data function"
//

$fileds_n_values_json='
{
"note_title":"?",
"note":"Note Details:magic_strip_if($'.$loop_name.'_r[\'note\'], 30, 30)",
"note_date_time":"?",
"account_id":"Account ID:qaccount_data($'.$loop_name.'_r[\'account_id\'])[\'name\']",
"business_id":"Business Name:qbusiness_data($'.$loop_name.'_r[\'business_id\'])[\'business_name\']",
"client_id":"Client:qclient_data($'.$loop_name.'_r[\'client_id\'])[\'client_name\']"

}
';

$profile_newfile_name='./editnote.php';

//$mosy_table_str="table:Table title:loop_variable:sel_before_str:sel_after_str:open_profile_page:additional_variables_for dope outside loop";

$mosy_table_str="notes:Similar Notes:".$loop_name.":*:WHERE account_id ='\$accid' OR business_id='\$busid' OR client_id='\$clid' ORDER BY primkey DESC:".$profile_newfile_name.":\$accid=\$".$tbl."_node['account_id'];\$busid=\$".$tbl."_node['business_id'];\$clid=\$".$tbl."_node['client_id'];";


$edit_key='primkey';
$function_file='../data_control/datafeed.php';
$add_to_cruds="yes";

//====================== handle image ui
$image_column='';
$image_style="height:80px; width:80px; border-radius:50%;";

//====================== handle image ui

$write_here='<!--<{ncgh}/>-->';

$plain_link='yes';
$linkcol='note_title';
$create_new_file="no";


//================================= app exe 


//************************************ create grid  *******************************************

//table list 

create_table_ui($newfile_name, $fileds_n_values_json, $mosy_table_str, $create_new_file, $edit_key, $plain_link, $linkcol,$write_here);


$old_image_cell='<td scope="col"><?php echo $'.$loop_name.'_["'.$image_column.'"];?></td>';


$new_image_cell='<td scope="col">
					<img src="<?php if($list'.$tbl.'_result["'.$image_column.'"]==""){ echo $mep_app_logo; }else{ echo $list'.$tbl.'_result["'.$image_column.'"];}?>" style="'.$image_style.'"/>
                 </td>';

if($image_column!='')
{
bend_replace_file_section($file_path, $old_image_cell, $new_image_cell);
}


if($add_functions_string=='yes')
{
  
	bend_replace_file_section($function_file, '//<--ncgh-->', $additional_functions.PHP_EOL.'//<--ncgh-->');
  
}
echo "<br>Mini List Created to ".$newfile_name."- ".date('Y-m-d h:i:s A');

//***************************************************************** Create grid ********************************88

?>