<?php //dna options==
$dna_file_name="add_column_alter_table_"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==


alter_table($mysqliconn, $dbname, 'call_logs', 'ADD column `archive_state` varchar(500) not null');?>