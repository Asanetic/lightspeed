<?php //dna options==
$dna_file_name="create_conn_string"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==

create_conn_str('../data_control/conn.php', $host, $username, $password, $dbname, 'yes');?>