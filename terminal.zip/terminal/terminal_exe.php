<?php //dna options==
$dna_file_name="admin_list_system_accounts_app_page_with_headers"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==

//===create app frame

$page_title='System Admins Accounts';
$newfile_name='../system_admins.php';
$header_files=['hr_sessionmonitor.php'];

create_appframe($page_title, $navbar_path, $footer_path, $header_css_scripts, $newfile_name, $background_image_path, $template_path);

$head_info="ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');".PHP_EOL;

foreach ($header_files as $file_includes)
{
  $head_info.='include("'.$file_includes.'");'.PHP_EOL;
}

$head_info.='
$default_home_crumb="";
if(isset($admin_home_crumb))
{
$default_home_crumb=$admin_home_crumb;
}';


//========= replace text in a file_path
$item_to_be_replaced='ob_start();';
$item_to_replace_with=$head_info;

bend_replace_file_section($newfile_name, $item_to_be_replaced, $item_to_replace_with);


$pg_title_str='<h4 class="col-md-12" style="text-align: center;">'.$page_title.'<br><br></h4>';
$new_head_str='
      <div class="col-md-12 pb-2 pl-0 text-dark" style="text-align: left;">
      	<span class="bg-light p-2 font-weight-bold" >
        	<?php echo $default_home_crumb; ?>
        	<span class="text-primary">'.$page_title.'</span> 
        </span>
          <div class="col-md-12 d-lg-none  mb-2"></div>
          <!--{nbuttongh}-->
      </div>';


bend_replace_file_section($newfile_name, $pg_title_str, $new_head_str);

?>