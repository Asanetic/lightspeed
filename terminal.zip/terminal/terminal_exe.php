<?php //dna options==
$dna_file_name="clients_Image_upload_with_back_end"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==

//===============Upload pic cell ui and uplaod scritpt
$cell_name="Profile pic";
$write_here="<!--imagecell-->";
$file_path='../client_profile.php';
$tbl="clients_table";
$image_cell_name="photo";

$crud_file='../data_control/'.$tbl.'.php';
$primkey='primkey';
$folder_path="../img/client_pics";

$write_here_crud='//--<{ncgh}/>';

$show_on_insert="yes";



////================================= appp exe 
$image_cell_ui='	
	<div class="col-md-4 border text-center mb-3">
    <div class="col-md-12 m-2"><b>'.$cell_name.'</b></div>
    		<?php 
            	if($'.$tbl.'_node["'.$image_cell_name.'"]!="") 
                {
                	$file_type_image=magic_if_image($'.$tbl.'_node["'.$image_cell_name.'"]);
                    if($file_type_image==\'Yes\')
                    {?>
                    
                  <img src="<?php if($'.$tbl.'_node["'.$image_cell_name.'"]=="") { echo $mep_app_logo;}else{ echo $'.$tbl.'_node["'.$image_cell_name.'"];}?>"  class="" style="width: 260px; height:260px; border-radius:50%;"/>

                    <?php }else{
                   	$actual_file_name=explode("/", $'.$tbl.'_node["'.$image_cell_name.'"]);
                    echo \'<a href="\'.$'.$tbl.'_node["'.$image_cell_name.'"].\'" target="_blank" class=""><i class="fa fa-paperclip" style="font-size:70px;"></i> 
                    <br>\'.end($actual_file_name).\'<hr> <i class="fa fa-download"></i> Download</a>\';
                    }
                }else{?>
                 
                 <img src="<?php if($'.$tbl.'_node["'.$image_cell_name.'"]=="") { echo $mep_app_logo;}else{ echo $'.$tbl.'_node["'.$image_cell_name.'"];}?>"  class="" style="width: 260px; height:260px; border-radius:50%;"/>

                <?php } ?>

        <input type="file" name="txt_'.$tbl.'_'.$image_cell_name.'" class="form-control mt-3">

        <input type="submit" name="btn_upload_'.$tbl.'_'.$image_cell_name.'" class="btn btn-primary mt-2" value="Upload '.$cell_name.'">

    </div> ';

bend_replace_file_section($file_path, $write_here, $image_cell_ui);

$upload_script = '
//===-====Start upload '.$tbl.'_'.$image_cell_name.' '.$cell_name.' 
if(isset($_POST["btn_upload_'.$tbl.'_'.$image_cell_name.'"]))
{

if(!empty($_FILES[\'txt_'.$tbl.'_'.$image_cell_name.'\'][\'tmp_name\'])){

  	$file_name1=explode(".", basename($_FILES[\'txt_'.$tbl.'_'.$image_cell_name.'\'][\'name\']))[0];
  
	$file_name=str_replace(" ", "_", $file_name1);
    
	$cur_item_photos=magic_upload_file(\''.str_replace("../", "./", $folder_path).'/\', \'txt_'.$tbl.'_'.$image_cell_name.'\', $file_name."_".magic_random_str(5));

	$item_photo=mysqli_real_escape_string($mysqliconn, $cur_item_photos);

	magic_compress_file($cur_item_photos, $cur_item_photos, 50);

	unlink($'.$tbl.'_node["'.$image_cell_name.'"]);

	magic_sql_update(\''.$tbl.'\', \'{"'.$image_cell_name.'":"\'.$cur_item_photos.\'"}\', "'.$primkey.'=\'$'.$tbl.'_uptoken\'");

	header(\'location:./\'.basename($_SERVER["REQUEST_URI"], "?".$_SERVER["QUERY_STRING"]).\'?'.$tbl.'_uptoken=\'.base64_encode($'.$tbl.'_uptoken).\'&table_alert=Photo Uploaded Succesfully\');

}else{

	echo magic_message(\'Please Browse A valid file\');
}

}
//===-====End upload '.$tbl.'_'.$image_cell_name.'  '.$cell_name.'  

//--<{ncgh}/>
';

  if (!file_exists($folder_path)) @mkdir($folder_path);

	//bend_replace_file_section($crud_file, $write_here_crud, $upload_script);



?>