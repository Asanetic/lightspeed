<?php  magic_sql_export_db($host, $username, $password, $snippets_db, '../snippets_db', '');

///backup file
$filename='snippets_db.sql';
$contents=file_get_contents('../snippets_db.sql');
$overwrite="yes";

 backup_file($filename, $contents, $overwrite);?>