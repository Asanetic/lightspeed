<?php <?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datafeed.php');
include('./technician_sessionmonitor.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Technician Panel</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body>
    <form method="post" enctype="multipart/form-data">
	<?php include("./includes/tech_navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">
      <div class="row mt-5 pt-5 justify-content-center p-1">
        <h5 class="col-md-12 border-bottom border-dark pb-2 pl-0 text-white" style="text-align: left;"><span class="bg-success p-2">Technician Panel</span></h5>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          
       <!--start accordion tray -->
       <div class="accordion col-md-12 p-0 m-0" id="dashboard_accordion">
         <!--Start  My_Services accordion_item node-->
        <div class="card skin_plasma">
             <!--Start accordion_item Head -->
          <div class="card-header bg-success  p-0" id="head_My_Services">
            <h2 class="mb-0">
              <button class="btn btn-link text-white btn-block text-left" type="button" data-toggle="collapse" data-target="#body_My_Services" aria-expanded="true" aria-controls="body_My_Services">
              <h5 class="col-md-12  pb-2 pl-0" style="text-align: left;">
                  <span class="text-white p-2 "><i class="fa fa-wrench"></i> My Services</span>
              </h5>
              </button>
            </h2>
          </div>
         <!--End My_Services accordion_item Head -->
         <!--Start My_Services accordion_item Body -->
          <div id="body_My_Services" class="collapse show" aria-labelledby="head_My_Services" data-parent="#dashboard_accordion">
            <div class="card-body skin_plasma">
              <!--Start My_Services Dash Cards Section-->
              <div class="row justify-content-center" style="text-align: center;">
                  <!--Start Dash icon card-->
					
            <a href="./tech_onboard_two.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-list text-dark" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> My Service List</b>
              </div>
            </a>            
            <a href="./tech_chats.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-users text-dark" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> Clients Requests</b>
              </div>
            </a>
            <!--<{next_My_Services_dash__icon}/>-->
            
            
            
            
                  <!--End My_Services Dash icon card-->
              </div>
             <!--End My_Services Dash Cards Section-->
            </div>
          </div>
             <!--End My_Services accordion_item Body -->
         </div>
            <!--End My_Services accordion_item node-->

		
         <!--Start  Activity_Log accordion_item node-->
        <div class="card skin_plasma">
             <!--Start accordion_item Head -->
          <div class="card-header bg-info  p-0" id="head_Activity_Log">
            <h2 class="mb-0">
              <button class="btn btn-link text-white btn-block text-left" type="button" data-toggle="collapse" data-target="#body_Activity_Log" aria-expanded="true" aria-controls="body_Activity_Log">
              <h5 class="col-md-12  pb-2 pl-0" style="text-align: left;">
                  <span class="text-white p-2 "><i class="fa fa-list"></i> Activity Log</span>
              </h5>
              </button>
            </h2>
          </div>
         <!--End Activity_Log accordion_item Head -->
         <!--Start Activity_Log accordion_item Body -->
          <div id="body_Activity_Log" class="collapse" aria-labelledby="head_Activity_Log" data-parent="#dashboard_accordion">
            <div class="card-body skin_plasma">
              <!--Start Activity_Log Dash Cards Section-->
              <div class="row justify-content-center" style="text-align: center;">
                  <!--Start Dash icon card-->
					
            <a href="./tech_services.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-check text-info" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> Services Delivered</b>
              </div>
            </a>
            
            <a href="./tech_services.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-star text-info" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> Service Reviews</b>
              </div>
            </a>
            
            <a href="./tech_chats.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-comments text-info" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> Chats</b>
              </div>
            </a>
            
            <a href="./tech_chats.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-thumbs-up text-info" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> Clients Likes</b>
              </div>
            </a>
            <!--<{next_Activity_Log_dash__icon}/>-->
                  <!--End Activity_Log Dash icon card-->
              </div>
             <!--End Activity_Log Dash Cards Section-->
            </div>
          </div>
             <!--End Activity_Log accordion_item Body -->
         </div>
        <!--End Activity_Log accordion_item node-->
  
		
         <!--Start  Account_and_Settings accordion_item node-->
        <div class="card skin_plasma">
             <!--Start accordion_item Head -->
          <div class="card-header bg-dark  p-0" id="head_Account_and_Settings">
            <h2 class="mb-0">
              <button class="btn btn-link text-white btn-block text-left" type="button" data-toggle="collapse" data-target="#body_Account_and_Settings" aria-expanded="true" aria-controls="body_Account_and_Settings">
              <h5 class="col-md-12  pb-2 pl-0" style="text-align: left;">
                  <span class="text-white p-2 "><i class="fa fa-gear"></i> Account & Settings</span>
              </h5>
              </button>
            </h2>
          </div>
         <!--End Account_and_Settings accordion_item Head -->
         <!--Start Account_and_Settings accordion_item Body -->
          <div id="body_Account_and_Settings" class="collapse" aria-labelledby="head_Account_and_Settings" data-parent="#dashboard_accordion">
            <div class="card-body skin_plasma">
              <!--Start Account_and_Settings Dash Cards Section-->
              <div class="row justify-content-center" style="text-align: center;">
                  <!--Start Dash icon card-->
					
            <a href="./tech_account.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-shield text-dark" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> My Account</b>
              </div>
            </a>
            
            <a href="./onboard_one.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-exchange text-dark" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> Switch Accounts</b>
              </div>
            </a>
            
            <a href="./tech_account.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-phone text-dark" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> Support</b>
              </div>
            </a>
            
            <a href="./tech_account.php" class="text-dark col-lg-2 col-6 p-0 pb-3 shadow pb-md-3 mr-lg-3 mb-3 bg-white" style="border-right:5px solid rgba(0,0,0, 0.1)">
              <div class="mt-2 p-0 col-md-12">
                <b><i class="fa fa-map-marker text-dark" style="font-size:70px;"></i>
                <div class="col-md-12 pb-3"></div> Location Settings</b>
              </div>
            </a>
            <!--<{next_Account_and_Settings_dash__icon}/>-->
            
  			  <!--End Account_and_Settings Dash icon card-->
              </div>
             <!--End Account_and_Settings Dash Cards Section-->
            </div>
          </div>
             <!--End Account_and_Settings accordion_item Body -->
         </div>
            <!--End Account_and_Settings accordion_item node-->

		<!--<{next_accordion_node}/>-->
    
  
       </div>
          <!--End accordion tray -->
    
      </div>

    </main><!-- /.container -->


 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>?>