<?php //dna options==
$dna_file_name="Magic_curl_function"; 
$create_dna="yes"; //yes | no; 
$overwrite_dna_file="yes"; //yes | no 
//dna options==

$curlopt_url="https://api.goldeneyenetworks.co.ke/payapi/stkpushlive.php";
$curlopt_httpheader="";
$curlopt_userpwd="";
$curlopt_post_fields="onlinetrx&paidamt=1&accno=JEREMY&telno=0710766390";
$curlopt_customrequest="POST";

magic_post_curl($curlopt_url, $curlopt_httpheader, $curlopt_userpwd, $curlopt_post_fields, $curlopt_customrequest)
?>