<?php //===create app frame
$tbl='admin';
$page_title='System Admins';
$newfile_name='../system_managers.php';
$header_files=[];

//************grid Values 

$fileds_n_values_json='{"photo":"?","admin_name":"?","admin_tel":"?","admin_email":"?","password":"?"}';

$fileds_n_values_json_profile=$fileds_n_values_json;

$profile_newfile_name='../profile_manager.php';

$page_title_profile='Manager Profile - <?php echo $'.$tbl.'_node[\'admin_name\'];?>';

//========================================================= Map file to navigation Links

$add_to_navbar='yes'; //yes | no
$nav_title='<i class="fa fa-list"></i> '.$page_title;

$map_to_dashboard="yes"; // yes | no
$dahboard_file_path="../dashboard.php";
$tab_title=$page_title;
$tab_title_w_icon=$nav_title;
$add_to_new_tab="yes"; //yes | no

//========================================================= Map file to navigation Links

$edit_key='primkey';
$crud_path='../data_control/'.$tbl.'.php';
$create_cruds="yes";


$table_type='';
$image_column='photo';
$image_style="height:80px; width:80px; border-radius:50%;";

$write_here='<!--<{ncgh}/>-->';

$plain_link='no';
$linkcol='';
$editable='no';
$create_new_file="no";

//************************************************** Profile ui Vars ****************************


$rows_per_grid='5';
$grid_class='col-md-4';
$control_top_bottom="top";

//================================= app exe 


$edit_file_path=str_replace("../", "./", $profile_newfile_name);

$tbl_primkey=$edit_key;

$list_file_path=str_replace("../", "./", $newfile_name);

$primkey=$edit_key;

create_appframe($page_title, $navbar_path, $footer_path, $header_css_scripts, $newfile_name, $background_image_path, $template_path);

$head_info="ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
//include('./data_control/datafeed.php');
include('".str_replace("../", "./", $crud_path)."');
".PHP_EOL;

foreach ($header_files as $file_includes)
{
  $head_info.='include("'.$file_includes.'");'.PHP_EOL;
}

$head_info.='
$default_home_crumb="";
if(isset($home_crumb))
{
$default_home_crumb=$home_crumb;
}';


//========= replace text in a file_path
$item_to_be_replaced='ob_start();';
$item_to_replace_with=$head_info;

bend_replace_file_section($newfile_name, $item_to_be_replaced, $item_to_replace_with);


$pg_title_str='<h4 class="col-md-12" style="text-align: center;">'.$page_title.'<br><br></h4>';
$new_head_str='
      <div class="col-md-12 border-bottom border_set pb-2 pl-0 text-dark" style="text-align: left;">
      	<span class="body_set p-2 font-weight-bold" >
        	<?php echo $default_home_crumb; ?>
        	<span class="">'.$page_title.'</span> 
        </span>
          <div class="col-md-12 d-lg-none border mb-2"></div>
          <!--{nbuttongh}-->
      </div>';


bend_replace_file_section($newfile_name, $pg_title_str, $new_head_str);


//************************************ create grid  *******************************************

//table list 


if($table_type=='ugrid'){
create_ugrid($newfile_name, $fileds_n_values_json, $tbl, $editable, $create_new_file, $edit_key, $plain_link, $linkcol, $write_here);
			
  
  $placeholder_node=ucwords(str_replace("_", " ", strtolower($image_column)));
	
    $search_node='
          <div class="col-md-12 text-left mb-2 row justify-content-left">
			<input type="text" class="col-md-2 mb-2 bg-transparent ml-2" placeholder="Search '.str_replace("_", ' ', $tbl).'" name="txt_'.$tbl.'" style="color:#000; border:none; border-bottom:1px solid #ccc;"/>
  			<button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="q'.$tbl.'_btn"><i class="fa fa-search"></i> Go</button>
  			<a href="'.$tbl.'" class="badge badge-success mr-2 p-2 mb-2 btn_neoo2"><i class="fa fa-refresh"></i> Refresh</a>
  			<a href="edit'.$tbl.'" class="badge badge-success mr-2 p-2 mb-2 btn_neoo2"><i class="fa fa-plus"></i> Add New</a>
  			<!--<a href="" class="badge badge-info p-2 mb-2"><i class="fa fa-lock"></i> Lock Editing</a>-->
          </div>';
  
  			$old_image_cell=' <td scope="col" class="p-1 cell_width"><input type="text" value="<?php echo $list'.$tbl.'_result["'.$image_column.'"];?>" readonly style="border:none; border-bottom:1px solid #fff; background-color:transparent;"/></td>';
  
  if($editable=='yes'){
            $old_image_cell=
				' <td scope="col" class="p-1">          
                	<input type="text"  value="<?php echo $list'.$tbl.'_result["'.$image_column.'"];?>" name="txt_'.$image_column.'_<?php echo $list'.$tbl.'_result["'.$edit_key.'"];?>" id="txt_'.$image_column.'_<?php echo $list'.$tbl.'_result["'.$edit_key.'"];?>" placeholder="'.$placeholder_node.'" onchange=" ugrid_update_'.$tbl.'(\''.$image_column.'\', \'<?php echo $list'.$tbl.'_result["'.$edit_key.'"];?>\')" style="border:none; border-bottom:1px solid #fff; background-color:transparent;"/>
                  </td>'; 
  }
}else{
create_table_ui($newfile_name, $fileds_n_values_json, $tbl, $create_new_file, $edit_key, $plain_link, $linkcol,$write_here);

      	$search_node='<?php echo magic_button_link(\'./edit'.$tbl.'?newrecord\', \'<i class="fa fa-plus"></i> Add new\', \'style="display:inline-block;"\');?> 
    	<?php echo magic_button_link(\'./'.$tbl.'\', \'<i class="fa fa-refresh"></i> Refresh\', \'style="display:inline-block;"\');?> 

		<hr><input type="text" placeholder="Search '.str_replace("_", ' ', $tbl).'" name="txt_'.$tbl.'" class=" form-control col-md-9" style="display:inline-block; background-color:transparent; border-bottom:1px solid gray; "  autofocus="" />
    	<?php echo magic_button(\'q'.$tbl.'_btn\', \'Search\', \'style="display:inline-block;"\');?>';

$old_image_cell='<td scope="col"><?php echo $list'.$tbl.'_result["'.$image_column.'"];?></td>';

}

          $new_head_str='
                      <input type="text" class="col-md-2 mb-2 ml-2 bg-transparent" placeholder="Search '.str_replace("_", ' ', $tbl).'" name="txt_'.$tbl.'" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                      <button type="submit" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2" name="q'.$tbl.'_btn"><i class="fa fa-search"></i> Go</button>
                      <a href="'.str_replace("../", "./", $newfile_name).'" class="badge badge-success mr-2 p-2 mb-2 btn_neoo2"><i class="fa fa-refresh"></i> Refresh</a>
                      <a href="'.$edit_file_path.'" class="badge badge-success mr-2 p-2 mb-2 btn_neoo2"><i class="fa fa-plus"></i> Add New</a>
                      <!--<a href="" class="badge badge-info p-2 mb-2"><i class="fa fa-lock"></i> Lock Editing</a>-->
          ';

$new_image_cell='<td scope="col">
					<img src="<?php echo $list'.$tbl.'_result["'.$image_column.'"];?>" style="'.$image_style.'"/>
                 </td>';

//========= replace text in a file_path
$file_path=$newfile_name;
$item_to_be_replaced=$search_node;
//$item_to_be_replaced=file_get_contents();
$item_to_replace_with='';


bend_replace_file_section($file_path, $item_to_be_replaced, $item_to_replace_with);
bend_replace_file_section($file_path, '<!--{nbuttongh}-->', $new_head_str);

if($image_column!='')
{
bend_replace_file_section($file_path, $old_image_cell, $new_image_cell);
}


	        $edit_del_drop_ui='$edit_drop_link=magic_link(\'./edit'.$tbl.'?'.$tbl.'_uptoken=\'.base64_encode($list'.$tbl.'_result["'.$tbl_primkey.'"]).\'\',\'<i class="fa fa-edit"></i> Edit\', \'\');

	        $delete_drop_link=magic_link(\'./edit'.$tbl.'?after_delete=\'.base64_encode(magic_current_url()).\'&'.$tbl.'_uptoken=\'.base64_encode($list'.$tbl.'_result["'.$tbl_primkey.'"]).\'&delete'.$tbl.'\',\'<i class="fa fa-trash"></i> Delete\', \'\');';
            
$new_edit_del_drop_ui='$edit_drop_link=magic_link(\''.$edit_file_path.'?'.$tbl.'_uptoken=\'.base64_encode($list'.$tbl.'_result["'.$edit_key.'"]).\'\',\'<i class="fa fa-arrow-right"></i> View More\', \'\');

	        $delete_drop_link=magic_link(\''.$edit_file_path.'?after_delete=\'.base64_encode(magic_current_url()).\'&'.$tbl.'_uptoken=\'.base64_encode($list'.$tbl.'_result["'.$edit_key.'"]).\'&delete'.$tbl.'\',\'<i class="fa fa-trash"></i> Delete\', \'\');';

bend_replace_file_section($file_path, $edit_del_drop_ui, $new_edit_del_drop_ui);

//***************************************************************** Create Proflle ********************************88

//===create Table profile ui  

if($page_title=='')
{
	$page_title=ucwords((str_replace('_', " ", $tbl)));
}
if($newfile_name=='')
{
	$newfile_name='../edit'.$tbl.'.php';
}

create_appframe($page_title_profile, $navbar_path, $footer_path, $header_css_scripts, $profile_newfile_name, $background_image_path, $template_path);


//========= replace text in a file_path
$item_to_be_replaced='ob_start();';
$item_to_replace_with=$head_info;

bend_replace_file_section($profile_newfile_name, $item_to_be_replaced, $item_to_replace_with);

$pg_title_str='<h4 class="col-md-12" style="text-align: center;">'.$page_title_profile.'<br><br></h4>';
$new_head_str='
      <div class="col-md-12 border-bottom border_set pb-2 pl-0 text-dark" style="text-align: left;">
      	<span class="body_set p-2 font-weight-bold" >
        	<?php echo $default_home_crumb; ?>
        	<span class="">'.$page_title_profile.'</span> 
        </span>
          <div class="col-md-12 d-lg-none border mb-2"></div>
          <!--{nbuttongh}-->
      </div>';


bend_replace_file_section($profile_newfile_name, $pg_title_str, $new_head_str);

//create bootstrap form 

$ui_comment='Sql input For '.$page_title_profile;
$create_new_file='no';

	$elements_plate=
      		'<div class="form-group">'.PHP_EOL.
		    '  <label ><elemlabel></label>'.PHP_EOL.
		    '  <input class="form-control" <elemid> <elemname> value="<?php echo $'.$tbl.'_node[\'<elemdata>\'];?>" <elemplaceholder> type="text">'.PHP_EOL.
		  	'</div>';

create_magic_form($profile_newfile_name,  $fileds_n_values_json_profile, $tbl, $rows_per_grid, $grid_class, $elements_plate, $ui_comment, $write_here, $create_new_file);

	$edit_butons='  
	<div class="col-md-12 mb-md-3" style="text-align: center;">
         <div style="text-align: center; ">
    		<?php if(isset($_GET[\'table_alert\'])) echo magic_toast(\'Success\', $_GET[\'table_alert\'], \'darkgreen\', \'#FFF\'); ?>
    	</div>
    	<?php echo magic_button_link(\'./'.$tbl.'\', \'<i class="fa fa-arrow-left"></i> Back to list\', "");?>

    	<?php echo magic_button_link(\'./edit'.$tbl.'?newrecord\', \'<i class="fa fa-plus"></i> Add new\', "");?> 

		<?php if(isset($_GET[\''.$tbl.'_uptoken\'])) echo magic_button_link(\'./edit'.$tbl.'?after_delete=\'.base64_encode(magic_current_url()).\'&'.$tbl.'_uptoken=\'.($_GET["'.$tbl.'_uptoken"]).\'&delete'.$tbl.'\',\'<i class="fa fa-trash"></i> Delete\', \'style="background-color:red;"\');?>
	</div>';

	$top_buttons='
			<a href="'.$list_file_path.'" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-arrow-left"></i> Back to list</a>
			<a href="'.str_replace("../", "./", $profile_newfile_name).'" class="badge badge-primary p-2  ml-3 btn_neoo2"><i class="fa fa-plus"></i> Add New</a>
            <?php if(isset($_GET[\''.$tbl.'_uptoken\']))
            {?>
			<a href="'.str_replace("../", "./", $profile_newfile_name).'?'.$tbl.'_uptoken=<?php echo $_GET["'.$tbl.'_uptoken"];?>&delete'.$tbl.'&after_delete=<?php echo base64_encode(\''.$list_file_path.'\');?>" class="badge badge-danger p-2  ml-3 btn_neoo2">
            	<i class="fa fa-trash"></i> Delete
            </a>
            <?php } ?>
            <!--{nbuttongh}-->';
$sucess_alert='
		<div style="text-align: center; ">
    		<?php if(isset($_GET[\'table_alert\'])) echo magic_toast(\'Success\', $_GET[\'table_alert\'], \'darkgreen\', \'#FFF\'); ?>
    	</div>';

if($control_top_bottom=='top')
{
  bend_replace_file_section($profile_newfile_name, $edit_butons, $sucess_alert);
  bend_replace_file_section($profile_newfile_name, "<!--{nbuttongh}-->", $top_buttons);

}

if($create_cruds=='yes')
{
///============ Create select update insert and delete functions
create_cruds($crud_path, magic_sql_array_cols($tbl), $dbname, $tbl, $primkey);

//== write connection files
$remove_primkey='`primkey`=\'$primkey\',';
//========= replace text in a file_path

bend_replace_file_section($crud_path, $remove_primkey, "");
    
}

$old_tbl_skin='<div class="table-responsive data-tables" style="background-color: #FFF; margin-top: 20px; padding-bottom: 150px;">';
$new_tbl_skin=
'<style>
  .table thead th {
  white-space: nowrap;
  }
</style>
<div class="table-responsive data-tables body_set" style="margin-top: 20px; padding-bottom: 150px;">';


  bend_replace_file_section($newfile_name, $old_tbl_skin, $new_tbl_skin);

$old_profile_skin='<div class="row p-md-3 justify-content-center bg-white col-md-11">';
$new_profile_skin='
		<div class="row p-md-3 justify-content-center col-md-12 body_set">
        <!--imagecell-->';

bend_replace_file_section($profile_newfile_name, $old_profile_skin, $new_profile_skin);

echo date("h:i:s")." - Grid Created!!";

//============================ create nav link 

if($add_to_navbar=='yes')
{
  $nav_bar_nodes='
			<li class="nav-item ml-lg-4">
                <a class="nav-link text-dark" href="'.$list_file_path.'">'.$nav_title.' </a>
            </li>';

$item_to_be_replaced_nav='<!--nav_nodes-->';
$item_to_replace_with_nav=$nav_bar_nodes;

bend_replace_file_section('.'.$navbar_path, $item_to_be_replaced_nav, $item_to_replace_with_nav.PHP_EOL.$item_to_be_replaced_nav);
 
}







if($map_to_dashboard=='yes')
{
  if($add_to_new_tab='yes'){

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++ Create Mosy Dashboard App exe +++++++++++++++++++++++++++++++++++
$node_str=str_replace(" ", "_", strtolower($tab_title));

$pill_btn='
              <!-- Start '.$tab_title.' pill btn-->
              <li class="nav-item" role="presentation">
                <a class="nav-link btn_set mr-2" id="pills-'.$node_str.'-tab" data-toggle="pill" href="#pills-'.$node_str.'" role="tab" aria-controls="pills-'.$node_str.'" aria-selected="true">'.$tab_title_w_icon.'</a>
              </li>
              <!-- End '.$tab_title.' pill btn-->
              
			  <!--{next_pill_btn}-->';
$pill_tray='
			<!-- Start '.$tab_title.' content container-->             
              <div class="tab-pane fade" id="pills-'.$node_str.'" role="tabpanel" aria-labelledby="pills-'.$node_str.'-tab">
               <div class="col-md-12 p-0 mb-3"><span class="font-weight-bold border-bottom border_set p-2">'.$tab_title.'</span></div>
  				<div class="row justify-content-left col-md-12 m-0 p-0">
                  <!--{next_'.$node_str.'_pill_icon}-->
				</div>
  			  </div>
             <!-- End  '.$tab_title.' content container-->
           	<!--{next_pill_tray}-->
            ';


bend_replace_file_section($dahboard_file_path, '<!--{next_pill_btn}-->', $pill_btn);
bend_replace_file_section($dahboard_file_path, '<!--{next_pill_tray}-->', $pill_tray);

echo "<br>Tab Created - ".date('Y-m-d h:i:s A');

  }


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++ Mosy Icon App exe +++++++++++++++++++++++++++++++++++
$node_str=str_replace(" ", "_", strtolower($tab_title));

$new_icon_str='
                    <!-- Start Add New '.$page_title.' icon-->
                  	<a href="'.$edit_file_path.'" class="col-md-2 p-2  text-center mr-lg-2  body_set"  style="border-bottom:3px solid <?php echo $btn_bg;?>;">
                      <div class="col-md-12"><i class="fa fa-plus" style="font-size:50px;"></i></div>
  						<h5 class="col-md-12 pt-2"> Add New </h5>
					</a>
                   <!-- End Add New '.$page_title.' icon-->
                   
                   <!-- Start Edit  '.$page_title.' icon-->
                  	<a href="'.$list_file_path.'" class="col-md-2 p-2  text-center mr-lg-2  body_set"  style="border-bottom:3px solid <?php echo $btn_bg;?>;">
                      <div class="col-md-12"><i class="fa fa-edit" style="font-size:50px;"></i></div>
  						<h5 class="col-md-12 pt-2"> Manage </h5>
					</a>
                   <!-- End Edit '.$page_title.' icon-->
                   
                    <!-- Start View All '.$page_title.' icon-->
                  	<a href="'.$list_file_path.'" class="col-md-2 p-2  text-center mr-lg-2  body_set"  style="border-bottom:3px solid <?php echo $btn_bg;?>;">
                      <div class="col-md-12"><i class="fa fa-list" style="font-size:50px;"></i></div>
  						<h5 class="col-md-12 pt-2"> View All </h5>
					</a>
                   <!-- End View All '.$page_title.' icon-->
                   
					<!--{next_'.$node_str.'_pill_icon}-->';
  

bend_replace_file_section($dahboard_file_path, '<!--{next_'.$node_str.'_pill_icon}-->', $new_icon_str);

echo "<br>".$page_title." Icon Created - ".date('Y-m-d h:i:s A');



}?>