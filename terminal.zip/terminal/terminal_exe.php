<?php //============== create mosy count button for dashboard 

//============================ Start functions vars 
$button_title='All Users Online';
$icon_title='<i class="fa fa-wrench"></i> ';
$button_link="";
$table="team";
$query_variable_str="";
$where_str=""; //x=''
$dahboard_file_path="../mosy.php";
//============================ End functions vars 


//==================================== Begin app exe ==============================
$chart_db_file="../chart_db.php";

$next_string='//============newdbcard_query_chart=============';

if (!file_exists($chart_db_file))
  {
    bend_write_to_file($chart_db_file, '<?php //============newdbcard_query_chart=============?>');
  };

$var_str=str_replace(" ", "_", strtolower($button_title));

$sql_str=''.PHP_EOL.'//============= Start '.$button_title.PHP_EOL.' '.$query_variable_str.PHP_EOL.' $count_'.$var_str.'=magic_sql_count("'.$table.'","*", "'.$where_str.'");'.PHP_EOL.PHP_EOL.'//============= End '.$button_title.PHP_EOL.PHP_EOL.$next_string.' ';

$button_str='
				<a href="'.$button_link.'" class="body_set btn btn-primary text-white p-3 shadow mb-3 mr-lg-2">
                	'.$icon_title.' <?php echo $count_'.$var_str.';?>  '.$button_title.'  
                </a>';

bend_replace_file_section($chart_db_file, $next_string, $sql_str);

bend_replace_file_section($dahboard_file_path, '<!--{next_count_btn}-->', $button_str.PHP_EOL.'<!--{next_count_btn}-->');

echo "Count Button Created - ".date('Y-m-d h:i:s A');

//==================================== End app exe ==============================
?>