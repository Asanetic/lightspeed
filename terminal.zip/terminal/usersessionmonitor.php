<?php

if(!isset($_SESSION['cbb_client_sess'])){
header('location:./userlogin');
}

?>