<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="darkgreen" fill-opacity="0.9" d="M0,224L48,234.7C96,245,192,267,288,250.7C384,235,480,181,576,160C672,139,768,149,864,170.7C960,192,1056,224,1152,197.3C1248,171,1344,85,1392,42.7L1440,0L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg><style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style>
<script>
window.onscroll = function() {termial_xsendcurspos()};

function termial_xsendcurspos() {
if(document.documentElement.scrollTop>0){
  window.parent.document.getElementById("prevscroll_px").value=document.documentElement.scrollTop; 
}
}
</script>