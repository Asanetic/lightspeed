<style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style>
<script>
window.onscroll = function() {termial_xsendcurspos()};

function termial_xsendcurspos() {
if(document.documentElement.scrollTop>0){
  window.parent.document.getElementById("prevscroll_px").value=document.documentElement.scrollTop; 
}
}
</script>