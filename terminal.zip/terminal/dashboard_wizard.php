<?php  ob_start(); session_start(); 
include('./appdbconfig.php');
include("./svrconn.php");
?>
<!Doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="./sharp-edge.css" />
<title>Dash Board Wizard</title>
</head>

<style>
.text_widgsmall{
width:200px;
}
</style>
</head>	
<body>
<form method="post" style="text-align:center;" target="_blank">
<div style="background-color:rgba(255,255,255,0.8); padding:10px;">
<div class="sharp-edge_bardiv_btn"><a href="./mstartpg">Sqlpro Home</a></div>

<br />
<h2 align="center">Dashboard Wizard</h2>
<br />

<h4 align="center">Select table to generate statistics</h4>
txt_file_path
<div class="">
	<input type="text" class="sharp-edge_textwidget text_widgsmall" name="txt_file_path" placeholder="DashBoard File">
</div>
<?php

$rettables = mysqli_query($mysqliconn, "SHOW TABLES FROM `$dbname`"); // run the query and assign the result to $result
while($table = mysqli_fetch_array($rettables)) { 
$foundtblname=$table[0];
$tblstructure = mysqli_query($mysqliconn, "SHOW COLUMNS FROM `$dbname`.`$foundtblname`");?>
<a name="<?php echo $foundtblname;?>"/>
<br>
<h3  style="color:#000099; font-size:14px;" class="sharp-edge_bardiv_btn" onClick="document.getElementById('txtcrttbl1').value='<?php echo $foundtblname;?>';document.getElementById('sub<?php echo $foundtblname;?>').style.display='block';"><?php echo $foundtblname;?> - Select </h3>
<br>
<div id="sub<?php echo $foundtblname;?>" style="display:block; border:1px solid #0066FF;">

<?php
while($tblcolnmname = mysqli_fetch_array($tblstructure)){
?>
	<div class="sharp-edge_bardiv_btn" ><a href="#proceed" onClick="popboxes('<?php echo $tblcolnmname['Field'];?>', '<?php echo $foundtblname;?>');"><?php echo $tblcolnmname['Field'];?></a>  </div>


<?php } ?>
<div class="sharp-edge_bardiv_btn" ><a href="#proceed" >
<span style="color:blue">Task Button (<strong onClick="popboxes('<?php echo str_replace("_", "-",$foundtblname)."-viewlist.php";?>', '<?php echo $foundtblname;?>');">List View </strong>| <strong onClick="popboxes('<?php echo str_replace("_", "-",$foundtblname)."-list.php";?>', '<?php echo $foundtblname;?>');">Manage List View </strong> |<strong onClick="popboxes('<?php echo str_replace("_", "-",$foundtblname)."-entry.php";?>', '<?php echo $foundtblname;?>');">Add New </strong>)</span>
</a>
</div>
</div>
<?php }?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


<div style="background-color:#FFFFFF;position: fixed;bottom: 59px;padding: 20px; box-shadow:5px 12px 6px 0px  rgba(0,0,0,0.5);border-bottom:5px solid #0066FF; width:95%;">
<input type="text" name="tile_title" id="tile_title"  placeholder="Enter Tile Title " value="<?php if(isset($_POST['tile_title'])) echo $_POST['tile_title'];?>" class="sharp-edge_textwidget text_widgsmall"  required/>
<input type="text" name="chart_table" id="chart_table" placeholder="Enter Chart Table"  value="<?php if(isset($_POST['chart_table'])) echo $_POST['chart_table'];?>" class="sharp-edge_textwidget text_widgsmall"  required/>

<input type="text" name="x_column" value="<?php if(isset($_POST['x_column'])) echo $_POST['x_column'];?>" id="x_column" placeholder="Enter X Column" class="sharp-edge_textwidget text_widgsmall"  required/>
<input type="text" name="y_column" id="y_column" value="<?php if(isset($_POST['y_column'])) echo $_POST['y_column'];?>"  placeholder="Enter Y Column" class="sharp-edge_textwidget text_widgsmall"  required/>
<select name="chart_type" id="chart_type" class="sharp-edge_textwidget text_widgsmall" onChange="changecart();">
<option value="LineChart">Chart Type</option>
<option value="LineChart">Line Chart</option>
<option value="BarChart">Bar Chart</option>
<option value="PieChart">Pie Chart</option>
<option value="Doughnut">Doughnut Chart</option>
<option value="ColumnChart">Column Chart</option>
<option value="AreaChart">Area Chart</option>
</select> 
<select name="chart_class" id="chart_class" class="sharp-edge_textwidget text_widgsmall">
<option value="chart_tile">Chart Width</option>
<option value="long_chart_tile">Banner</option>
<option value="chart_tile">Tile</option>

</select> 
<input type="text" name="txt_left_card" id="txt_left_card" placeholder="Enter Count Card Side"  value="<?php if(isset($_POST['txt_left_card'])) echo $_POST['txt_left_card'];?>" class="sharp-edge_textwidget text_widgsmall" onClick="this.value='';" />
<input type="text" name="where_clause_var" placeholder="Enter where variables"  value="<?php if(isset($_POST['where_clause_var'])) echo $_POST['where_clause_var'];?>" class="sharp-edge_textwidget text_widgsmall" />

<input type="text" name="where_clause_sql" placeholder="Enter where clause"  value="<?php if(isset($_POST['where_clause_sql'])) echo $_POST['where_clause_sql'];?>" class="sharp-edge_textwidget text_widgsmall"  />

<div class="sharp-edge_bardiv_btn" onClick="cleartxt();">Clear</div>
<div class="sharp-edge_bardiv_btn" onClick="document.getElementById('txt_left_card').value='left_cards';">Add Left Card </div>
<br>
<br>
<br>

<input type="submit" name="create_taskcard" value="Create Task Card" class="sharp-edge_buttonwidget"/>
<input type="submit" name="create_card" value="Create Count Card" class="sharp-edge_buttonwidget"/>
<input type="submit" name="create_sumcard" value="Create Sum Card" class="sharp-edge_buttonwidget"/>
<input type="submit" name="create_chart" value="Create Count Charts" class="sharp-edge_buttonwidget"/>
<input type="submit" name="create_sumchart" value="Create Sum Charts" class="sharp-edge_buttonwidget"/>
<!--<input type="submit" name="remove_card" value="Remove Stats Card" class="sharp-edge_buttonwidget"/>
<input type="submit" name="remove_chart" value="Remove Tile Charts" class="sharp-edge_buttonwidget"/>-->
<input type="submit" name="reset_dash" value="Reset DashBoard" class="sharp-edge_buttonwidget"/>
<br>
<br>chart_tile
</div>
<?php
$currdb_name=base64_decode($_GET['dbtoken']);
if(isset($_POST['reset_dash'])){

$write_dashbrd2="./apps/".$appname."/default_dash.php";


$curr_dash_file=file_get_contents($write_dashbrd2);


	
$defaultdbdash='<?php '.PHP_EOL.PHP_EOL.'$'.$dbname.'=$'.$dbname.';'.PHP_EOL.PHP_EOL.'//============newdbcard_query============='.PHP_EOL.PHP_EOL.'//============newdbcard_query_chart============='.PHP_EOL.PHP_EOL.'?>';
	
$write_dbdashbrd="../chart_db.php";
$fh_dbdashflush = fopen($write_dbdashbrd, 'w') or die("cant open file");
fwrite($fh_dbdashflush, $defaultdbdash);
fclose($fh_dbdashflush);

$write_dashbrd=$_POST['txt_file_path'];
  $fh_dashflush = fopen($write_dashbrd, 'w') or die("cant open file");
	fwrite($fh_dashflush, $curr_dash_file);
	 

  header('location:'.$_POST['txt_file_path'].'');

}

if(isset($_POST['create_taskcard'])){

$tile_title=$_POST['tile_title'];
$chart_table=$_POST['chart_table'];
$x_column=$_POST['x_column'];
$y_column=$_POST['y_column'];
$chart_type=$_POST['chart_type'];

$write_dashbrd2=$_POST['txt_file_path'];

$curr_dash_file=file_get_contents($write_dashbrd2);

$card_tile='
<a href="./'.$x_column.'" style="text-decoration:none;color:<?php echo $buttonclr;?>">
<div class="count_card" style="border:2px solid <?php echo $gentxtclr;?>; margin:20px;">
'.$tile_title.'
</div></a>';


$dashfile_update=str_replace('<newtasktile>',$card_tile.'<newtasktile>'.PHP_EOL.PHP_EOL.'',$curr_dash_file);


$write_dashbrd=$_POST['txt_file_path'];
  $fh_dashflush = fopen($write_dashbrd, 'w') or die("cant open file");
	fwrite($fh_dashflush, $dashfile_update);
	fclose($fh_dashflush);
	
 
  header('location:'.$_POST['txt_file_path'].'');

}
if(isset($_POST['create_card'])){

$tile_title=$_POST['tile_title'];
$chart_table=$_POST['chart_table'];
$x_column=$_POST['x_column'];
$y_column=$_POST['y_column'];
$chart_type=$_POST['chart_type'];

$where_clause_var=$_POST['where_clause_var'];
$where_clause_sql=$_POST['where_clause_sql'];

$wherestr="";
$wherevars="";
if($where_clause_sql!=''){
$wherevars=$where_clause_var.';';
$wherestr='WHERE '.$where_clause_sql;
}


$write_dashbrd2=$_POST['txt_file_path'];
$write_dashbrd_control="../chart_db.php";

$curr_dash_file=file_get_contents($write_dashbrd2);
$curr_dashdb_file=file_get_contents($write_dashbrd_control);

$card_tile='
<a href="./'.str_replace("_","-",$chart_table).'-viewlist.php" style="text-decoration:none;color:<?php echo $buttonclr;?>">
<div class="count_card">
<img src="./gstatic/graphcard.png" style="width:30px; height:30px; margin-right:10px;" />
'.$tile_title.' | <?php echo $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_count_res["0"];?> 
</div>
</a>';


$dash_card_sql='
//===========================count card '.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'========================
'.$wherevars.' $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_count_query=mysqli_query($mysqliconn, "SELECT COUNT('.$y_column.')  FROM `$'.$dbname.'`.`'.$chart_table.'` '.$wherestr.'");

 $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_count_res=mysqli_fetch_array($'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_count_query);
//===========================count card '.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'========================

';

$card_side_tag='<newcardtile>';

if($_POST['txt_left_card']=='left_cards'){
$card_side_tag='<left_newcardtile>';
$card_tile='
<a href="./'.str_replace("_","-",$chart_table).'-viewlist.php" style="text-decoration:none;color:<?php echo $buttonclr;?>">
<div class="count_card" style="font-size:12px;">
'.$tile_title.' : <?php echo $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_count_res["0"];?> 
</div>
</a>';
}
//echo "dash cur ".$curr_dash_file;
$dashfile_update=str_replace($card_side_tag,$card_tile.$card_side_tag.PHP_EOL.PHP_EOL.'',$curr_dash_file);

$dashdbfile_update=str_replace('//============newdbcard_query=============', $dash_card_sql.'//============newdbcard_query=============', $curr_dashdb_file);

$write_dashbrd=$_POST['txt_file_path'];
  $fh_dashflush = fopen($write_dashbrd, 'w') or die("cant open file");
	fwrite($fh_dashflush, $dashfile_update);
	fclose($fh_dashflush);
	
$write_dbdashbrd="../chart_db.php";
$fh_dbdashflush = fopen($write_dbdashbrd, 'w') or die("cant open file");
fwrite($fh_dbdashflush, $dashdbfile_update);
 
  //header('location:''.$_POST['txt_file_path'].''');

}


if(isset($_POST['create_sumcard'])){

$tile_title=$_POST['tile_title'];
$chart_table=$_POST['chart_table'];
$x_column=$_POST['x_column'];
$y_column=$_POST['y_column'];
$chart_type=$_POST['chart_type'];

$where_clause_var=$_POST['where_clause_var'];
$where_clause_sql=$_POST['where_clause_sql'];

$wherestr="";
$wherevars="";
if($where_clause_sql!=''){
$wherevars=$where_clause_var.';';
$wherestr='WHERE '.$where_clause_sql;
}

$write_dashbrd2=$_POST['txt_file_path'];
$write_dashbrd_control="../chart_db.php";

$curr_dash_file=file_get_contents($write_dashbrd2);
$curr_dashdb_file=file_get_contents($write_dashbrd_control);

$card_tile='
<a href="./'.str_replace("_","-",$chart_table).'-viewlist.php" style="text-decoration:none;color:<?php echo $buttonclr;?>">
<div class="count_card">
<img src="./gstatic/graphcard.png" style="width:30px; height:30px; margin-right:10px;" />
'.$tile_title.' | <?php echo $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_sum_res["'.$y_column.'_COUNT"];?> </div></a>';


$dash_card_sql='
//===========================sum card '.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'========================
 '.$wherevars.' $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_sum_query=mysqli_query($mysqliconn, "SELECT SUM('.$y_column.') AS '.$y_column.'_COUNT  FROM `$'.$dbname.'`.`'.$chart_table.'` '.$wherestr.'");

 $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_sum_res=mysqli_fetch_array($'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_sum_query);
//===========================sum card '.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'========================

';

$card_side_tag='<newcardtile>';

if($_POST['txt_left_card']=='left_cards'){
$card_side_tag='<left_newcardtile>';
$card_tile='
<a href="./'.str_replace("_","-",$chart_table).'-viewlist.php" style="text-decoration:none;color:<?php echo $buttonclr;?>">
<div class="count_card" style="font-size:12px;">
'.$tile_title.' : 
 <?php echo $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_sum_res["'.$y_column.'_COUNT"];?> </div></a>';

}

//echo "dash cur ".$curr_dash_file;
$dashfile_update=str_replace($card_side_tag,$card_tile.$card_side_tag.PHP_EOL.PHP_EOL.'',$curr_dash_file);

$dashdbfile_update=str_replace('//============newdbcard_query=============', $dash_card_sql.'//============newdbcard_query=============', $curr_dashdb_file);

$write_dashbrd=$_POST['txt_file_path'];
  $fh_dashflush = fopen($write_dashbrd, 'w') or die("cant open file");
	fwrite($fh_dashflush, $dashfile_update);
	fclose($fh_dashflush);
	
$write_dbdashbrd="../chart_db.php";
$fh_dbdashflush = fopen($write_dbdashbrd, 'w') or die("cant open file");
fwrite($fh_dbdashflush, $dashdbfile_update);
 
  header('location:'.$_POST['txt_file_path'].'');

}


if(isset($_POST['create_chart'])){

$tile_title=$_POST['tile_title'];
$chart_table=$_POST['chart_table'];
$x_column=$_POST['x_column'];
$y_column=$_POST['y_column'];
$chart_type=$_POST['chart_type'];
$chart_tile_class=$_POST['chart_class'];

$where_clause_var=$_POST['where_clause_var'];
$where_clause_sql=$_POST['where_clause_sql'];

$wherestr="";
$wherevars="";
if($where_clause_sql!=''){
$wherevars=$where_clause_var.';';
$wherestr='WHERE '.$where_clause_sql;
}

$piehole="";
if($chart_type=='Doughnut'){
$piehole='pieHole: 0.4,';
$chart_type='PieChart';
}
$linecolor="";
if($chart_type=='LineChart'){
$linecolor='colors: [\'<?php echo $buttonclr;?>\'],';
}

$write_dashbrd2=$_POST['txt_file_path'];
$write_dashbrd3=$_POST['txt_file_path'];
$write_dashbrd_control="../chart_db.php";

$curr_dash_file=file_get_contents($write_dashbrd2);
$curr_dashdb_file=file_get_contents($write_dashbrd_control);

$card_tile='
<div class="count_card">
<img src="./gstatic/graphcard.png" style="width:30px; height:30px; margin-right:10px;" />
'.$tile_title.' | <?php echo $'.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'_card_count_res["0"];?> </div>';


$dash_card_sql='
//===========================Chart tile card '.$chart_table.' '.strtolower(str_replace(" ","_",$tile_title)).'========================
'.$wherevars.' $'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_query=mysqli_query($mysqliconn, "SELECT COUNT('.$y_column.') AS '.$y_column.'_count,  '.$x_column.'   FROM `$'.$dbname.'`.`'.$chart_table.'`  '.$wherestr.'  GROUP BY '.$x_column.' ");
//===========================Chart tile  card '.$chart_table.'  '.strtolower(str_replace(" ","_",$tile_title)).'========================

';
//echo "dash cur ".$curr_dash_file;

$dashdbfile_update=str_replace('//============newdbcard_query_chart=============', $dash_card_sql.'//============newdbcard_query_chart=============', $curr_dashdb_file);


$chart_tilejs='
<script type="text/javascript" i>
      google.charts.setOnLoadCallback(drawChart_'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).');

      function drawChart_'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'() {

        var data = google.visualization.arrayToDataTable([
          [\''.ucwords(str_replace("_", " ", $x_column)).'\', \''.ucwords(str_replace("_", " ", $y_column)).'\'],
		  <?php while($'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_res=mysqli_fetch_array($'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_query)){
          echo \'[\\\'\'.$'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_res["'.$x_column.'"].\'\\\',     \'.$'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_res["'.$y_column.'_count"].\'],\';
		  }?>
        ]);

        var options = {
          title: \''.ucwords($tile_title).'\',
		  		   '.$piehole.'
				   '.$linecolor.'
		  curveType: \'function\',
      backgroundColor: {
        fill: \'<?php echo $skinclr;?>\',
        fillOpacity: 0.6
      },
		hAxis: {
    textStyle:{color: \'<?php echo $gentxtclr;?>\'}
			},
		vAxis: {
    	textStyle:{color: \'<?php echo $gentxtclr;?>\'}
		},
    legendTextStyle: { color: \'<?php echo $gentxtclr;?>\' },
    titleTextStyle: { color: \'<?php echo $gentxtclr;?>\' },
	        slices: {0: {color: \'<?php echo $buttonclr;?>\'},},
        };

        var chart = new google.visualization.'.$chart_type.'(document.getElementById(\'chart'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'\'));

        chart.draw(data, options);
      }
    </script>';
	
$curr_dash_file2=file_get_contents($write_dashbrd2);

$new_chart_div='<div id="chart'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'" class="'.$chart_tile_class.'"></div>';
	
$jschart_update=str_replace('<chartscript>',$chart_tilejs.'<chartscript>',$curr_dash_file);

$write_dashbrd=$_POST['txt_file_path'];
$fh_dashflush = fopen($write_dashbrd, 'w') or die("cant open file");
fwrite($fh_dashflush, $jschart_update);
fclose($fh_dashflush);
 

$write_dashbrd4=$_POST['txt_file_path'];
$curr_dash_file4=file_get_contents($write_dashbrd4);
$divchart_update=str_replace('<charthtmldiv>',$new_chart_div.'<charthtmldiv>',$curr_dash_file4);

$write_dashbrd_div=$_POST['txt_file_path'];
$fh_dashflush_div = fopen($write_dashbrd_div, 'w') or die("cant open file");
fwrite($fh_dashflush_div, $divchart_update);
fclose($fh_dashflush_div);
 


	
$write_dbdashbrd="../chart_db.php";
$fh_dbdashflush = fopen($write_dbdashbrd, 'w') or die("cant open file");
fwrite($fh_dbdashflush, $dashdbfile_update);
 
 header('location:'.$_POST['txt_file_path'].'');
}






if(isset($_POST['create_sumchart'])){

$tile_title=$_POST['tile_title'];
$chart_table=$_POST['chart_table'];
$x_column=$_POST['x_column'];
$y_column=$_POST['y_column'];
$chart_type=$_POST['chart_type'];
$chart_tile_class=$_POST['chart_class'];

$where_clause_var=$_POST['where_clause_var'];
$where_clause_sql=$_POST['where_clause_sql'];

$wherestr="";
$wherevars="";
if($where_clause_sql!=''){
$wherevars=$where_clause_var.';';
$wherestr='WHERE '.$where_clause_sql;
}

$piehole="";
if($chart_type=='Doughnut'){
$piehole='pieHole: 0.4,';
$chart_type='PieChart';
}
$linecolor="";
if($chart_type=='LineChart'){
$linecolor='colors: [\'<?php echo $buttonclr;?>\'],';
}

$write_dashbrd2=$_POST['txt_file_path'];
$write_dashbrd3=$_POST['txt_file_path'];
$write_dashbrd_control="../chart_db.php";

$curr_dash_file=file_get_contents($write_dashbrd2);
$curr_dashdb_file=file_get_contents($write_dashbrd_control);

$card_tile='
<div class="count_card">
<img src="./gstatic/graphcard.png" style="width:30px; height:30px; margin-right:10px;" />
'.$tile_title.' | <?php echo $'.$chart_table.'_card_count_res["0"];?> </div>';


$dash_card_sql='
//===========================Chart SUM tile card '.$chart_table.'_'.strtolower(str_replace(" ","_",$tile_title)).'========================
'.$wherevars.' $'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_sumquery=mysqli_query($mysqliconn, "SELECT SUM('.$y_column.') AS '.$y_column.'_sum,  '.$x_column.'   FROM `$'.$dbname.'`.`'.$chart_table.'`  '.$wherestr.' GROUP BY '.$x_column.' ");
//===========================Chart SUM tile  card '.$chart_table.'========================

';
//echo "dash cur ".$curr_dash_file;

$dashdbfile_update=str_replace('//============newdbcard_query_chart=============', $dash_card_sql.'//============newdbcard_query_chart=============', $curr_dashdb_file);


$chart_tilejs='
<script type="text/javascript" i>
      google.charts.setOnLoadCallback(drawChart_sum'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).');

      function drawChart_sum'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'() {

        var data = google.visualization.arrayToDataTable([
          [\''.ucwords(str_replace("_", " ", $x_column)).'\', \''.ucwords(str_replace("_", " ", $y_column)).'\'],
		  <?php while($'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_sumres=mysqli_fetch_array($'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_sumquery)){
          echo \'[\\\'\'.$'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_sumres["'.$x_column.'"].\'\\\',     \'.$'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'_sumres["'.$y_column.'_sum"].\'],\';
		  }?>
        ]);

        var options = {
          title: \''.ucwords($tile_title).'\',
		  		   '.$piehole.'
				   '.$linecolor.'
		  curveType: \'function\',
      backgroundColor: {
        fill: \'<?php echo $skinclr;?>\',
        fillOpacity: 0.6
      },
		hAxis: {
    textStyle:{color: \'<?php echo $gentxtclr;?>\'}
			},
		vAxis: {
    	textStyle:{color: \'<?php echo $gentxtclr;?>\'}
		},
    legendTextStyle: { color: \'<?php echo $gentxtclr;?>\' },
    titleTextStyle: { color: \'<?php echo $gentxtclr;?>\' },
	        slices: {0: {color: \'<?php echo $buttonclr;?>\'},},
        };

        var chart = new google.visualization.'.$chart_type.'(document.getElementById(\'chartsum'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'\'));

        chart.draw(data, options);
      }
    </script>';
	
$curr_dash_file2=file_get_contents($write_dashbrd2);

$new_chart_div='<div id="chartsum'.$y_column.'_'.$chart_table.'_'.$x_column.'_'.strtolower(str_replace(" ","_",$tile_title)).'" class="'.$chart_tile_class.'"></div>';
	
$jschart_update=str_replace('<chartscript>',$chart_tilejs.'<chartscript>',$curr_dash_file);

$write_dashbrd=$_POST['txt_file_path'];
$fh_dashflush = fopen($write_dashbrd, 'w') or die("cant open file");
fwrite($fh_dashflush, $jschart_update);
fclose($fh_dashflush);
 

$write_dashbrd4=$_POST['txt_file_path'];
$curr_dash_file4=file_get_contents($write_dashbrd4);
$divchart_update=str_replace('<charthtmldiv>',$new_chart_div.'<charthtmldiv>',$curr_dash_file4);

$write_dashbrd_div=$_POST['txt_file_path'];
$fh_dashflush_div = fopen($write_dashbrd_div, 'w') or die("cant open file");
fwrite($fh_dashflush_div, $divchart_update);
fclose($fh_dashflush_div);
 


	
$write_dbdashbrd="../chart_db.php";
$fh_dbdashflush = fopen($write_dbdashbrd, 'w') or die("cant open file");
fwrite($fh_dbdashflush, $dashdbfile_update);
 
 header('location:'.$_POST['txt_file_path'].'');
}


?>
</div>
</form>
<script>
function popboxes(sentcol, senttbl){

var identtxt = document.getElementById('x_column');
var second_tbl = document.getElementById('chart_table');
var secimg = document.getElementById('y_column');

second_tbl.value=senttbl;

if(identtxt.value!=''){
secimg.value=sentcol;

}else{
identtxt.value=sentcol;

}
}

function cleartxt(){
var identtxt = document.getElementById('x_column');
var secimg = document.getElementById('chart_table');
var second_tbl = document.getElementById('y_column');

second_tbl.value='';
secimg.value='';
identtxt.value='';

}
</script>
</body>
</html>
