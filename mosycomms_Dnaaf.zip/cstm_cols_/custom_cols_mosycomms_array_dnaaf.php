<?php 
$custom_tbl_cols=[
  
  "mosycomms_array"=>["receiver","msgsender_name","msgsender_address", "msgaction_link","msgaction_name"],
  
];

$custom_query_line_cols=[
  
  'stock_in'=>'sum_inventory_history(\"quantity\", \"item_id=\'\".\$data_res[\'item_id\'].\"\'  and transfer_type=\'Stock In\' \")',  
  'date_activated'=>'ftime(\$data_res[\'activated_on\'],\'date\')',  
  "activation_date"=>'date_time_input(\$data_res[\'activated_on\'],\"date\")',   
  'activated'=>'\count_acc_renewals(\"(DATE_FORMAT(activated_on, \'%Y-%m-%d\'))=\'\".date_time_input(\$data_res[\'activated_on\'],\"date\"). \"\' \")',  
  'pending'=>'\$ajax_function_data[\'expiring\']-\$ajax_function_data[\'activated\']',
  'unrealized_revenue'=>'\$ajax_function_data[\'expected_revenue\']-\$ajax_function_data[\'realized_revenue\']',

  'accounts_renewed'=>'\count_acc_renewals(\"(DATE_FORMAT(activated_on, \'%Y-%m-%d\'))=\'\".\$data_res[\'filter_date\']. \"\' \")',  
  
  'total_amount_paid'=>'\sum_transactions(\"amount\",\"filter_date=\'\". \$data_res[\'filter_date\']. \"\' \")',  
  'accounts_paid'=>'\get_transactions(\"count(distinct BillRefNumber) as tot_accs\",\"where filter_date=\'\". \$data_res[\'filter_date\']. \"\'\",\"r\")[\"tot_accs\"]',  

];


//1. mosycomms_array //"primkey" , "messageid" , "receiver_contacts" , "reciver_names" , "message_type" , "site_id" , "group_name" , "message_date" , "sent_state" , "msg_read_state" , "subject" , "message_label" , "message" , "delvery_receipt" , "sms_cost" , "page_count" , "hive_site_id" , "hive_site_name" ,


$custom_list_col_data_=[
  
  "messages_sent"=>"date('d-m-Y H:i')",
  'requesting_member'=>"?",
  
];


$custom_profile_col_data_=[
  
  'stock_in'=>"?",  
  'stock_out'=>"?",  
  'sold_qty'=>"?",
  "available_qty"=>"?",
  "leased_qty"=>"?"

];


$custom_profile_default_data_=[
  
  "receiver"=>"<?php echo getarr_val_(\$mosycomms_array_node, 'receiver_contacts'); ?>",
  
  "msgsender_name"=>"<?php echo 'Asanetic writing academy'; ?>",
  "msgsender_address"=>"<?php echo 'info@clearphrases.com'; ?>",
  "msgaction_link"=>"<?php echo ''; ?>",
  "msgaction_name"=>"<?php echo 'View file'; ?>",
  "mosycomms_dictionary"=>"<?php echo checkblank(getarr_val_(\$mosycomms_array_node,'mosycomms_dictionary'),'{}'); ?>",
  'posted_by'=>'checkblank(getarr_val_($pety_cash_post_node,"posted_by"), $session_sauth_logged_user_id)',
  'approval_status'=>'checkblank(getarr_val_($petty_cash_node,"approval_status"), "Pending Approval")',

];

?>